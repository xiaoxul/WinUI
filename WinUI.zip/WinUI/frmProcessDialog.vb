﻿Public Class frmProcessDialog

    Private Sub frmProcessDialog_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Me.Location = New Point(Me.Owner.Location.X + (Me.Owner.Width - Me.Width) \ 2, Me.Owner.Location.Y + (Me.Owner.Height - Me.Height) \ 2)

    End Sub

End Class