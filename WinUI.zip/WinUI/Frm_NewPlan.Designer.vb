﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frm_NewPlan
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim TreeNode1 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("ノード1")
        Dim TreeNode2 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("ノード2")
        Dim TreeNode3 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("ノード3")
        Dim TreeNode4 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("ノード4")
        Dim TreeNode5 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("ノード5")
        Dim TreeNode6 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("ノード6")
        Dim TreeNode7 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("ノード7")
        Dim TreeNode8 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("ノード8")
        Dim TreeNode9 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("ノード9")
        Dim TreeNode10 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("ノード10")
        Dim TreeNode11 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("ノード11")
        Dim TreeNode12 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("ノード12")
        Dim TreeNode13 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("ノード13")
        Dim TreeNode14 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("ノード14")
        Dim TreeNode15 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("ノード15")
        Me.tvPlan = New System.Windows.Forms.TreeView()
        Me.txtParentNo44 = New System.Windows.Forms.TextBox()
        Me.txtParentNo43 = New System.Windows.Forms.TextBox()
        Me.txtParentNo42 = New System.Windows.Forms.TextBox()
        Me.txtParentNo34 = New System.Windows.Forms.TextBox()
        Me.txtParentNo33 = New System.Windows.Forms.TextBox()
        Me.txtParentNo32 = New System.Windows.Forms.TextBox()
        Me.txtParentNo24 = New System.Windows.Forms.TextBox()
        Me.txtParentNo23 = New System.Windows.Forms.TextBox()
        Me.txtParentNo22 = New System.Windows.Forms.TextBox()
        Me.txtParentNo14 = New System.Windows.Forms.TextBox()
        Me.txtParentNo13 = New System.Windows.Forms.TextBox()
        Me.txtParentNo12 = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtPlanName4 = New System.Windows.Forms.TextBox()
        Me.txtPlanName3 = New System.Windows.Forms.TextBox()
        Me.txtPlanName2 = New System.Windows.Forms.TextBox()
        Me.txtPlanName1 = New System.Windows.Forms.TextBox()
        Me.txtParentNo41 = New System.Windows.Forms.TextBox()
        Me.txtParentNo31 = New System.Windows.Forms.TextBox()
        Me.txtParentNo21 = New System.Windows.Forms.TextBox()
        Me.txtParentNo11 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtLv44 = New System.Windows.Forms.TextBox()
        Me.txtLv43 = New System.Windows.Forms.TextBox()
        Me.txtLv42 = New System.Windows.Forms.TextBox()
        Me.txtLv41 = New System.Windows.Forms.TextBox()
        Me.txtLv34 = New System.Windows.Forms.TextBox()
        Me.txtLv33 = New System.Windows.Forms.TextBox()
        Me.txtLv32 = New System.Windows.Forms.TextBox()
        Me.txtLv31 = New System.Windows.Forms.TextBox()
        Me.txtLv24 = New System.Windows.Forms.TextBox()
        Me.txtLv23 = New System.Windows.Forms.TextBox()
        Me.txtLv22 = New System.Windows.Forms.TextBox()
        Me.txtLv21 = New System.Windows.Forms.TextBox()
        Me.txtLv14 = New System.Windows.Forms.TextBox()
        Me.txtLv13 = New System.Windows.Forms.TextBox()
        Me.txtLv12 = New System.Windows.Forms.TextBox()
        Me.txtLv11 = New System.Windows.Forms.TextBox()
        Me.nudStartRowNo1 = New System.Windows.Forms.NumericUpDown()
        Me.nudStartRowNo2 = New System.Windows.Forms.NumericUpDown()
        Me.nudStartRowNo3 = New System.Windows.Forms.NumericUpDown()
        Me.nudStartRowNo4 = New System.Windows.Forms.NumericUpDown()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.lblContractName = New System.Windows.Forms.Label()
        Me.lblCPNO = New System.Windows.Forms.Label()
        Me.lblContractNo = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnLogOut = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnReset = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnReturn = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnSave = New MUSE.UserControl.UCnt_Btn0001()
        Me.UCnt_Pal00011 = New MUSE.UserControl.UCnt_Pal0001()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Btn_DelLv1 = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_DelLv2 = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_DelLv3 = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_DelLv4 = New MUSE.UserControl.UCnt_Btn0001()
        Me.BtnImportXls = New MUSE.UserControl.UCnt_Btn0001()
        Me.BtnExportXls = New MUSE.UserControl.UCnt_Btn0001()
        Me.BtnOutFolder = New MUSE.UserControl.UCnt_Btn0001()
        CType(Me.nudStartRowNo1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudStartRowNo2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudStartRowNo3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudStartRowNo4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'tvPlan
        '
        Me.tvPlan.Location = New System.Drawing.Point(25, 303)
        Me.tvPlan.Name = "tvPlan"
        TreeNode1.Name = "ノード1"
        TreeNode1.Text = "ノード1"
        TreeNode2.Name = "ノード2"
        TreeNode2.Text = "ノード2"
        TreeNode3.Name = "ノード3"
        TreeNode3.Text = "ノード3"
        TreeNode4.Name = "ノード4"
        TreeNode4.Text = "ノード4"
        TreeNode5.Name = "ノード5"
        TreeNode5.Text = "ノード5"
        TreeNode6.Name = "ノード6"
        TreeNode6.Text = "ノード6"
        TreeNode7.Name = "ノード7"
        TreeNode7.Text = "ノード7"
        TreeNode8.Name = "ノード8"
        TreeNode8.Text = "ノード8"
        TreeNode9.Name = "ノード9"
        TreeNode9.Text = "ノード9"
        TreeNode10.Name = "ノード10"
        TreeNode10.Text = "ノード10"
        TreeNode11.Name = "ノード11"
        TreeNode11.Text = "ノード11"
        TreeNode12.Name = "ノード12"
        TreeNode12.Text = "ノード12"
        TreeNode13.Name = "ノード13"
        TreeNode13.Text = "ノード13"
        TreeNode14.Name = "ノード14"
        TreeNode14.Text = "ノード14"
        TreeNode15.Name = "ノード15"
        TreeNode15.Text = "ノード15"
        Me.tvPlan.Nodes.AddRange(New System.Windows.Forms.TreeNode() {TreeNode1, TreeNode2, TreeNode3, TreeNode4, TreeNode5, TreeNode6, TreeNode7, TreeNode8, TreeNode9, TreeNode10, TreeNode11, TreeNode12, TreeNode13, TreeNode14, TreeNode15})
        Me.tvPlan.Size = New System.Drawing.Size(692, 196)
        Me.tvPlan.TabIndex = 244
        Me.tvPlan.TabStop = False
        '
        'txtParentNo44
        '
        Me.txtParentNo44.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.txtParentNo44.Location = New System.Drawing.Point(642, 449)
        Me.txtParentNo44.Name = "txtParentNo44"
        Me.txtParentNo44.Size = New System.Drawing.Size(24, 19)
        Me.txtParentNo44.TabIndex = 257
        Me.txtParentNo44.TabStop = False
        Me.txtParentNo44.Visible = False
        '
        'txtParentNo43
        '
        Me.txtParentNo43.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.txtParentNo43.Location = New System.Drawing.Point(612, 449)
        Me.txtParentNo43.Name = "txtParentNo43"
        Me.txtParentNo43.Size = New System.Drawing.Size(24, 19)
        Me.txtParentNo43.TabIndex = 256
        Me.txtParentNo43.TabStop = False
        Me.txtParentNo43.Visible = False
        '
        'txtParentNo42
        '
        Me.txtParentNo42.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.txtParentNo42.Location = New System.Drawing.Point(582, 449)
        Me.txtParentNo42.Name = "txtParentNo42"
        Me.txtParentNo42.Size = New System.Drawing.Size(24, 19)
        Me.txtParentNo42.TabIndex = 255
        Me.txtParentNo42.TabStop = False
        Me.txtParentNo42.Visible = False
        '
        'txtParentNo34
        '
        Me.txtParentNo34.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.txtParentNo34.Location = New System.Drawing.Point(642, 424)
        Me.txtParentNo34.Name = "txtParentNo34"
        Me.txtParentNo34.Size = New System.Drawing.Size(24, 19)
        Me.txtParentNo34.TabIndex = 254
        Me.txtParentNo34.TabStop = False
        Me.txtParentNo34.Visible = False
        '
        'txtParentNo33
        '
        Me.txtParentNo33.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.txtParentNo33.Location = New System.Drawing.Point(612, 424)
        Me.txtParentNo33.Name = "txtParentNo33"
        Me.txtParentNo33.Size = New System.Drawing.Size(24, 19)
        Me.txtParentNo33.TabIndex = 253
        Me.txtParentNo33.TabStop = False
        Me.txtParentNo33.Visible = False
        '
        'txtParentNo32
        '
        Me.txtParentNo32.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.txtParentNo32.Location = New System.Drawing.Point(582, 424)
        Me.txtParentNo32.Name = "txtParentNo32"
        Me.txtParentNo32.Size = New System.Drawing.Size(24, 19)
        Me.txtParentNo32.TabIndex = 252
        Me.txtParentNo32.TabStop = False
        Me.txtParentNo32.Visible = False
        '
        'txtParentNo24
        '
        Me.txtParentNo24.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.txtParentNo24.Location = New System.Drawing.Point(642, 399)
        Me.txtParentNo24.Name = "txtParentNo24"
        Me.txtParentNo24.Size = New System.Drawing.Size(24, 19)
        Me.txtParentNo24.TabIndex = 251
        Me.txtParentNo24.TabStop = False
        Me.txtParentNo24.Visible = False
        '
        'txtParentNo23
        '
        Me.txtParentNo23.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.txtParentNo23.Location = New System.Drawing.Point(612, 399)
        Me.txtParentNo23.Name = "txtParentNo23"
        Me.txtParentNo23.Size = New System.Drawing.Size(24, 19)
        Me.txtParentNo23.TabIndex = 250
        Me.txtParentNo23.TabStop = False
        Me.txtParentNo23.Visible = False
        '
        'txtParentNo22
        '
        Me.txtParentNo22.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.txtParentNo22.Location = New System.Drawing.Point(582, 399)
        Me.txtParentNo22.Name = "txtParentNo22"
        Me.txtParentNo22.Size = New System.Drawing.Size(24, 19)
        Me.txtParentNo22.TabIndex = 249
        Me.txtParentNo22.TabStop = False
        Me.txtParentNo22.Visible = False
        '
        'txtParentNo14
        '
        Me.txtParentNo14.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.txtParentNo14.Location = New System.Drawing.Point(642, 374)
        Me.txtParentNo14.Name = "txtParentNo14"
        Me.txtParentNo14.Size = New System.Drawing.Size(24, 19)
        Me.txtParentNo14.TabIndex = 248
        Me.txtParentNo14.TabStop = False
        Me.txtParentNo14.Visible = False
        '
        'txtParentNo13
        '
        Me.txtParentNo13.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.txtParentNo13.Location = New System.Drawing.Point(612, 374)
        Me.txtParentNo13.Name = "txtParentNo13"
        Me.txtParentNo13.Size = New System.Drawing.Size(24, 19)
        Me.txtParentNo13.TabIndex = 247
        Me.txtParentNo13.TabStop = False
        Me.txtParentNo13.Visible = False
        '
        'txtParentNo12
        '
        Me.txtParentNo12.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.txtParentNo12.Location = New System.Drawing.Point(582, 374)
        Me.txtParentNo12.Name = "txtParentNo12"
        Me.txtParentNo12.Size = New System.Drawing.Size(24, 19)
        Me.txtParentNo12.TabIndex = 246
        Me.txtParentNo12.TabStop = False
        Me.txtParentNo12.Visible = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(25, 271)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(194, 12)
        Me.Label11.TabIndex = 243
        Me.Label11.Text = "該当するお客様の案件をツリー表示する"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(23, 232)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(38, 12)
        Me.Label3.TabIndex = 240
        Me.Label3.Text = "Level4"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(23, 207)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 12)
        Me.Label2.TabIndex = 239
        Me.Label2.Text = "Level3"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(23, 182)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 12)
        Me.Label1.TabIndex = 238
        Me.Label1.Text = "Level2"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(69, 138)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(53, 12)
        Me.Label8.TabIndex = 237
        Me.Label8.Text = "案件番号"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(196, 138)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(41, 12)
        Me.Label7.TabIndex = 236
        Me.Label7.Text = "案件名"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(550, 359)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(65, 12)
        Me.Label4.TabIndex = 235
        Me.Label4.Text = "親案件番号"
        Me.Label4.Visible = False
        '
        'txtPlanName4
        '
        Me.txtPlanName4.BackColor = System.Drawing.SystemColors.Window
        Me.txtPlanName4.Location = New System.Drawing.Point(198, 229)
        Me.txtPlanName4.Name = "txtPlanName4"
        Me.txtPlanName4.Size = New System.Drawing.Size(468, 19)
        Me.txtPlanName4.TabIndex = 11
        '
        'txtPlanName3
        '
        Me.txtPlanName3.BackColor = System.Drawing.SystemColors.Window
        Me.txtPlanName3.Location = New System.Drawing.Point(198, 204)
        Me.txtPlanName3.Name = "txtPlanName3"
        Me.txtPlanName3.Size = New System.Drawing.Size(468, 19)
        Me.txtPlanName3.TabIndex = 8
        '
        'txtPlanName2
        '
        Me.txtPlanName2.BackColor = System.Drawing.SystemColors.Window
        Me.txtPlanName2.Location = New System.Drawing.Point(198, 179)
        Me.txtPlanName2.Name = "txtPlanName2"
        Me.txtPlanName2.Size = New System.Drawing.Size(468, 19)
        Me.txtPlanName2.TabIndex = 5
        '
        'txtPlanName1
        '
        Me.txtPlanName1.BackColor = System.Drawing.SystemColors.Window
        Me.txtPlanName1.Location = New System.Drawing.Point(198, 154)
        Me.txtPlanName1.Name = "txtPlanName1"
        Me.txtPlanName1.Size = New System.Drawing.Size(468, 19)
        Me.txtPlanName1.TabIndex = 2
        '
        'txtParentNo41
        '
        Me.txtParentNo41.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.txtParentNo41.Location = New System.Drawing.Point(552, 449)
        Me.txtParentNo41.Name = "txtParentNo41"
        Me.txtParentNo41.Size = New System.Drawing.Size(24, 19)
        Me.txtParentNo41.TabIndex = 230
        Me.txtParentNo41.TabStop = False
        Me.txtParentNo41.Visible = False
        '
        'txtParentNo31
        '
        Me.txtParentNo31.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.txtParentNo31.Location = New System.Drawing.Point(552, 424)
        Me.txtParentNo31.Name = "txtParentNo31"
        Me.txtParentNo31.Size = New System.Drawing.Size(24, 19)
        Me.txtParentNo31.TabIndex = 229
        Me.txtParentNo31.TabStop = False
        Me.txtParentNo31.Visible = False
        '
        'txtParentNo21
        '
        Me.txtParentNo21.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.txtParentNo21.Location = New System.Drawing.Point(552, 399)
        Me.txtParentNo21.Name = "txtParentNo21"
        Me.txtParentNo21.Size = New System.Drawing.Size(24, 19)
        Me.txtParentNo21.TabIndex = 228
        Me.txtParentNo21.TabStop = False
        Me.txtParentNo21.Visible = False
        '
        'txtParentNo11
        '
        Me.txtParentNo11.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.txtParentNo11.Location = New System.Drawing.Point(552, 374)
        Me.txtParentNo11.Name = "txtParentNo11"
        Me.txtParentNo11.Size = New System.Drawing.Size(24, 19)
        Me.txtParentNo11.TabIndex = 227
        Me.txtParentNo11.TabStop = False
        Me.txtParentNo11.Visible = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(23, 157)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(38, 12)
        Me.Label5.TabIndex = 226
        Me.Label5.Text = "Level1"
        '
        'txtLv44
        '
        Me.txtLv44.BackColor = System.Drawing.SystemColors.Window
        Me.txtLv44.ImeMode = System.Windows.Forms.ImeMode.Alpha
        Me.txtLv44.Location = New System.Drawing.Point(158, 229)
        Me.txtLv44.MaxLength = 2
        Me.txtLv44.Name = "txtLv44"
        Me.txtLv44.Size = New System.Drawing.Size(24, 19)
        Me.txtLv44.TabIndex = 10
        '
        'txtLv43
        '
        Me.txtLv43.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.txtLv43.Location = New System.Drawing.Point(128, 229)
        Me.txtLv43.Name = "txtLv43"
        Me.txtLv43.ReadOnly = True
        Me.txtLv43.Size = New System.Drawing.Size(24, 19)
        Me.txtLv43.TabIndex = 222
        Me.txtLv43.TabStop = False
        '
        'txtLv42
        '
        Me.txtLv42.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.txtLv42.Location = New System.Drawing.Point(98, 229)
        Me.txtLv42.Name = "txtLv42"
        Me.txtLv42.ReadOnly = True
        Me.txtLv42.Size = New System.Drawing.Size(24, 19)
        Me.txtLv42.TabIndex = 221
        Me.txtLv42.TabStop = False
        '
        'txtLv41
        '
        Me.txtLv41.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.txtLv41.Location = New System.Drawing.Point(68, 229)
        Me.txtLv41.Name = "txtLv41"
        Me.txtLv41.ReadOnly = True
        Me.txtLv41.Size = New System.Drawing.Size(24, 19)
        Me.txtLv41.TabIndex = 220
        Me.txtLv41.TabStop = False
        '
        'txtLv34
        '
        Me.txtLv34.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.txtLv34.Location = New System.Drawing.Point(158, 204)
        Me.txtLv34.Name = "txtLv34"
        Me.txtLv34.ReadOnly = True
        Me.txtLv34.Size = New System.Drawing.Size(24, 19)
        Me.txtLv34.TabIndex = 219
        Me.txtLv34.TabStop = False
        '
        'txtLv33
        '
        Me.txtLv33.BackColor = System.Drawing.SystemColors.Window
        Me.txtLv33.ImeMode = System.Windows.Forms.ImeMode.Alpha
        Me.txtLv33.Location = New System.Drawing.Point(128, 204)
        Me.txtLv33.MaxLength = 2
        Me.txtLv33.Name = "txtLv33"
        Me.txtLv33.Size = New System.Drawing.Size(24, 19)
        Me.txtLv33.TabIndex = 7
        '
        'txtLv32
        '
        Me.txtLv32.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.txtLv32.Location = New System.Drawing.Point(98, 204)
        Me.txtLv32.Name = "txtLv32"
        Me.txtLv32.ReadOnly = True
        Me.txtLv32.Size = New System.Drawing.Size(24, 19)
        Me.txtLv32.TabIndex = 217
        Me.txtLv32.TabStop = False
        '
        'txtLv31
        '
        Me.txtLv31.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.txtLv31.Location = New System.Drawing.Point(68, 204)
        Me.txtLv31.Name = "txtLv31"
        Me.txtLv31.ReadOnly = True
        Me.txtLv31.Size = New System.Drawing.Size(24, 19)
        Me.txtLv31.TabIndex = 216
        Me.txtLv31.TabStop = False
        '
        'txtLv24
        '
        Me.txtLv24.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.txtLv24.Location = New System.Drawing.Point(158, 179)
        Me.txtLv24.Name = "txtLv24"
        Me.txtLv24.ReadOnly = True
        Me.txtLv24.Size = New System.Drawing.Size(24, 19)
        Me.txtLv24.TabIndex = 215
        Me.txtLv24.TabStop = False
        '
        'txtLv23
        '
        Me.txtLv23.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.txtLv23.Location = New System.Drawing.Point(128, 179)
        Me.txtLv23.Name = "txtLv23"
        Me.txtLv23.ReadOnly = True
        Me.txtLv23.Size = New System.Drawing.Size(24, 19)
        Me.txtLv23.TabIndex = 214
        Me.txtLv23.TabStop = False
        '
        'txtLv22
        '
        Me.txtLv22.BackColor = System.Drawing.SystemColors.Window
        Me.txtLv22.ImeMode = System.Windows.Forms.ImeMode.Alpha
        Me.txtLv22.Location = New System.Drawing.Point(98, 179)
        Me.txtLv22.MaxLength = 2
        Me.txtLv22.Name = "txtLv22"
        Me.txtLv22.Size = New System.Drawing.Size(24, 19)
        Me.txtLv22.TabIndex = 4
        '
        'txtLv21
        '
        Me.txtLv21.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.txtLv21.Location = New System.Drawing.Point(68, 179)
        Me.txtLv21.Name = "txtLv21"
        Me.txtLv21.ReadOnly = True
        Me.txtLv21.Size = New System.Drawing.Size(24, 19)
        Me.txtLv21.TabIndex = 212
        Me.txtLv21.TabStop = False
        '
        'txtLv14
        '
        Me.txtLv14.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.txtLv14.Location = New System.Drawing.Point(158, 154)
        Me.txtLv14.Name = "txtLv14"
        Me.txtLv14.ReadOnly = True
        Me.txtLv14.Size = New System.Drawing.Size(24, 19)
        Me.txtLv14.TabIndex = 211
        Me.txtLv14.TabStop = False
        '
        'txtLv13
        '
        Me.txtLv13.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.txtLv13.Location = New System.Drawing.Point(128, 154)
        Me.txtLv13.Name = "txtLv13"
        Me.txtLv13.ReadOnly = True
        Me.txtLv13.Size = New System.Drawing.Size(24, 19)
        Me.txtLv13.TabIndex = 210
        Me.txtLv13.TabStop = False
        '
        'txtLv12
        '
        Me.txtLv12.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.txtLv12.Location = New System.Drawing.Point(98, 154)
        Me.txtLv12.Name = "txtLv12"
        Me.txtLv12.ReadOnly = True
        Me.txtLv12.Size = New System.Drawing.Size(24, 19)
        Me.txtLv12.TabIndex = 209
        Me.txtLv12.TabStop = False
        '
        'txtLv11
        '
        Me.txtLv11.BackColor = System.Drawing.SystemColors.Window
        Me.txtLv11.ImeMode = System.Windows.Forms.ImeMode.Alpha
        Me.txtLv11.Location = New System.Drawing.Point(68, 154)
        Me.txtLv11.MaxLength = 2
        Me.txtLv11.Name = "txtLv11"
        Me.txtLv11.Size = New System.Drawing.Size(24, 19)
        Me.txtLv11.TabIndex = 1
        '
        'nudStartRowNo1
        '
        Me.nudStartRowNo1.Location = New System.Drawing.Point(591, 154)
        Me.nudStartRowNo1.Maximum = New Decimal(New Integer() {99999, 0, 0, 0})
        Me.nudStartRowNo1.Name = "nudStartRowNo1"
        Me.nudStartRowNo1.Size = New System.Drawing.Size(49, 19)
        Me.nudStartRowNo1.TabIndex = 3
        Me.nudStartRowNo1.Visible = False
        '
        'nudStartRowNo2
        '
        Me.nudStartRowNo2.Location = New System.Drawing.Point(591, 179)
        Me.nudStartRowNo2.Maximum = New Decimal(New Integer() {99999, 0, 0, 0})
        Me.nudStartRowNo2.Name = "nudStartRowNo2"
        Me.nudStartRowNo2.Size = New System.Drawing.Size(49, 19)
        Me.nudStartRowNo2.TabIndex = 6
        Me.nudStartRowNo2.Visible = False
        '
        'nudStartRowNo3
        '
        Me.nudStartRowNo3.Location = New System.Drawing.Point(591, 204)
        Me.nudStartRowNo3.Maximum = New Decimal(New Integer() {99999, 0, 0, 0})
        Me.nudStartRowNo3.Name = "nudStartRowNo3"
        Me.nudStartRowNo3.Size = New System.Drawing.Size(49, 19)
        Me.nudStartRowNo3.TabIndex = 9
        Me.nudStartRowNo3.Visible = False
        '
        'nudStartRowNo4
        '
        Me.nudStartRowNo4.Location = New System.Drawing.Point(591, 229)
        Me.nudStartRowNo4.Maximum = New Decimal(New Integer() {99999, 0, 0, 0})
        Me.nudStartRowNo4.Name = "nudStartRowNo4"
        Me.nudStartRowNo4.Size = New System.Drawing.Size(49, 19)
        Me.nudStartRowNo4.TabIndex = 12
        Me.nudStartRowNo4.Visible = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(589, 138)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(53, 12)
        Me.Label10.TabIndex = 259
        Me.Label10.Text = "開始行番"
        Me.Label10.Visible = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.lblContractName)
        Me.GroupBox1.Controls.Add(Me.lblCPNO)
        Me.GroupBox1.Controls.Add(Me.lblContractNo)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(25, 47)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(692, 83)
        Me.GroupBox1.TabIndex = 261
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "契約情報"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label12.Location = New System.Drawing.Point(10, 59)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(70, 12)
        Me.Label12.TabIndex = 53
        Me.Label12.Text = "契約順番名"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label13.Location = New System.Drawing.Point(10, 21)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(104, 12)
        Me.Label13.TabIndex = 51
        Me.Label13.Text = "お客様名（CPNO）"
        '
        'lblContractName
        '
        Me.lblContractName.AutoSize = True
        Me.lblContractName.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblContractName.Location = New System.Drawing.Point(133, 59)
        Me.lblContractName.Name = "lblContractName"
        Me.lblContractName.Size = New System.Drawing.Size(0, 12)
        Me.lblContractName.TabIndex = 54
        '
        'lblCPNO
        '
        Me.lblCPNO.AutoSize = True
        Me.lblCPNO.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblCPNO.Location = New System.Drawing.Point(133, 21)
        Me.lblCPNO.Name = "lblCPNO"
        Me.lblCPNO.Size = New System.Drawing.Size(0, 12)
        Me.lblCPNO.TabIndex = 52
        '
        'lblContractNo
        '
        Me.lblContractNo.AutoSize = True
        Me.lblContractNo.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblContractNo.Location = New System.Drawing.Point(133, 40)
        Me.lblContractNo.Name = "lblContractNo"
        Me.lblContractNo.Size = New System.Drawing.Size(0, 12)
        Me.lblContractNo.TabIndex = 54
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label14.Location = New System.Drawing.Point(10, 40)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(57, 12)
        Me.Label14.TabIndex = 53
        Me.Label14.Text = "契約順番"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Red
        Me.Label6.Location = New System.Drawing.Point(200, 251)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(328, 12)
        Me.Label6.TabIndex = 263
        Me.Label6.Text = "削除：※一度登録すると修正または削除することはできません。"
        Me.Label6.Visible = False
        '
        'btnLogOut
        '
        Me.btnLogOut.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnLogOut.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnLogOut.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogOut.ForeColor = System.Drawing.Color.White
        Me.btnLogOut.Location = New System.Drawing.Point(25, 514)
        Me.btnLogOut.Name = "btnLogOut"
        Me.btnLogOut.Size = New System.Drawing.Size(125, 44)
        Me.btnLogOut.TabIndex = 15
        Me.btnLogOut.Text = "ログアウト"
        Me.btnLogOut.UseVisualStyleBackColor = False
        '
        'btnReset
        '
        Me.btnReset.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnReset.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReset.ForeColor = System.Drawing.Color.White
        Me.btnReset.Location = New System.Drawing.Point(584, 255)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(133, 44)
        Me.btnReset.TabIndex = 13
        Me.btnReset.Text = "画面リセット"
        Me.btnReset.UseVisualStyleBackColor = False
        '
        'btnReturn
        '
        Me.btnReturn.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnReturn.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnReturn.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReturn.ForeColor = System.Drawing.Color.White
        Me.btnReturn.Location = New System.Drawing.Point(156, 514)
        Me.btnReturn.Name = "btnReturn"
        Me.btnReturn.Size = New System.Drawing.Size(125, 44)
        Me.btnReturn.TabIndex = 16
        Me.btnReturn.Text = "メニューへ"
        Me.btnReturn.UseVisualStyleBackColor = False
        '
        'btnSave
        '
        Me.btnSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSave.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnSave.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSave.ForeColor = System.Drawing.Color.White
        Me.btnSave.Location = New System.Drawing.Point(594, 514)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(125, 44)
        Me.btnSave.TabIndex = 14
        Me.btnSave.Text = "登録/更新"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'UCnt_Pal00011
        '
        Me.UCnt_Pal00011.BackColor = System.Drawing.Color.Teal
        Me.UCnt_Pal00011.BackColro2 = System.Drawing.Color.PaleTurquoise
        Me.UCnt_Pal00011.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UCnt_Pal00011.ForeColor = System.Drawing.Color.White
        Me.UCnt_Pal00011.Location = New System.Drawing.Point(1, 0)
        Me.UCnt_Pal00011.Name = "UCnt_Pal00011"
        Me.UCnt_Pal00011.Size = New System.Drawing.Size(741, 44)
        Me.UCnt_Pal00011.TabIndex = 206
        Me.UCnt_Pal00011.TitleText = "OIO BAMA Client  案件情報登録"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Blue
        Me.Label9.Location = New System.Drawing.Point(25, 286)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(115, 12)
        Me.Label9.TabIndex = 264
        Me.Label9.Text = "【案件番号_案件名】"
        '
        'Btn_DelLv1
        '
        Me.Btn_DelLv1.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_DelLv1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_DelLv1.ForeColor = System.Drawing.Color.White
        Me.Btn_DelLv1.Location = New System.Drawing.Point(666, 154)
        Me.Btn_DelLv1.Name = "Btn_DelLv1"
        Me.Btn_DelLv1.Size = New System.Drawing.Size(51, 19)
        Me.Btn_DelLv1.TabIndex = 3
        Me.Btn_DelLv1.Text = "削除"
        Me.Btn_DelLv1.UseVisualStyleBackColor = False
        '
        'Btn_DelLv2
        '
        Me.Btn_DelLv2.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_DelLv2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_DelLv2.ForeColor = System.Drawing.Color.White
        Me.Btn_DelLv2.Location = New System.Drawing.Point(666, 179)
        Me.Btn_DelLv2.Name = "Btn_DelLv2"
        Me.Btn_DelLv2.Size = New System.Drawing.Size(51, 19)
        Me.Btn_DelLv2.TabIndex = 6
        Me.Btn_DelLv2.Text = "削除"
        Me.Btn_DelLv2.UseVisualStyleBackColor = False
        '
        'Btn_DelLv3
        '
        Me.Btn_DelLv3.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_DelLv3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_DelLv3.ForeColor = System.Drawing.Color.White
        Me.Btn_DelLv3.Location = New System.Drawing.Point(666, 204)
        Me.Btn_DelLv3.Name = "Btn_DelLv3"
        Me.Btn_DelLv3.Size = New System.Drawing.Size(51, 19)
        Me.Btn_DelLv3.TabIndex = 9
        Me.Btn_DelLv3.Text = "削除"
        Me.Btn_DelLv3.UseVisualStyleBackColor = False
        '
        'Btn_DelLv4
        '
        Me.Btn_DelLv4.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_DelLv4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_DelLv4.ForeColor = System.Drawing.Color.White
        Me.Btn_DelLv4.Location = New System.Drawing.Point(666, 229)
        Me.Btn_DelLv4.Name = "Btn_DelLv4"
        Me.Btn_DelLv4.Size = New System.Drawing.Size(51, 19)
        Me.Btn_DelLv4.TabIndex = 12
        Me.Btn_DelLv4.Text = "削除"
        Me.Btn_DelLv4.UseVisualStyleBackColor = False
        '
        'BtnImportXls
        '
        Me.BtnImportXls.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.BtnImportXls.BackColor = System.Drawing.Color.RoyalBlue
        Me.BtnImportXls.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnImportXls.ForeColor = System.Drawing.Color.White
        Me.BtnImportXls.Location = New System.Drawing.Point(289, 514)
        Me.BtnImportXls.Name = "BtnImportXls"
        Me.BtnImportXls.Size = New System.Drawing.Size(94, 44)
        Me.BtnImportXls.TabIndex = 17
        Me.BtnImportXls.Text = "XLS取込"
        Me.BtnImportXls.UseVisualStyleBackColor = False
        '
        'BtnExportXls
        '
        Me.BtnExportXls.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.BtnExportXls.BackColor = System.Drawing.Color.RoyalBlue
        Me.BtnExportXls.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnExportXls.ForeColor = System.Drawing.Color.White
        Me.BtnExportXls.Location = New System.Drawing.Point(390, 514)
        Me.BtnExportXls.Name = "BtnExportXls"
        Me.BtnExportXls.Size = New System.Drawing.Size(94, 44)
        Me.BtnExportXls.TabIndex = 18
        Me.BtnExportXls.Text = "XLS出力"
        Me.BtnExportXls.UseVisualStyleBackColor = False
        '
        'BtnOutFolder
        '
        Me.BtnOutFolder.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.BtnOutFolder.BackColor = System.Drawing.Color.RoyalBlue
        Me.BtnOutFolder.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnOutFolder.ForeColor = System.Drawing.Color.White
        Me.BtnOutFolder.Location = New System.Drawing.Point(491, 514)
        Me.BtnOutFolder.Name = "BtnOutFolder"
        Me.BtnOutFolder.Size = New System.Drawing.Size(94, 44)
        Me.BtnOutFolder.TabIndex = 19
        Me.BtnOutFolder.Text = "フォルダ表示"
        Me.BtnOutFolder.UseVisualStyleBackColor = False
        '
        'Frm_NewPlan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(738, 588)
        Me.ControlBox = False
        Me.Controls.Add(Me.BtnOutFolder)
        Me.Controls.Add(Me.BtnExportXls)
        Me.Controls.Add(Me.BtnImportXls)
        Me.Controls.Add(Me.Btn_DelLv4)
        Me.Controls.Add(Me.Btn_DelLv3)
        Me.Controls.Add(Me.Btn_DelLv2)
        Me.Controls.Add(Me.Btn_DelLv1)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.txtPlanName4)
        Me.Controls.Add(Me.txtPlanName3)
        Me.Controls.Add(Me.txtPlanName2)
        Me.Controls.Add(Me.txtPlanName1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.btnLogOut)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.nudStartRowNo4)
        Me.Controls.Add(Me.nudStartRowNo3)
        Me.Controls.Add(Me.nudStartRowNo2)
        Me.Controls.Add(Me.nudStartRowNo1)
        Me.Controls.Add(Me.tvPlan)
        Me.Controls.Add(Me.txtParentNo44)
        Me.Controls.Add(Me.txtParentNo43)
        Me.Controls.Add(Me.txtParentNo42)
        Me.Controls.Add(Me.txtParentNo34)
        Me.Controls.Add(Me.txtParentNo33)
        Me.Controls.Add(Me.txtParentNo32)
        Me.Controls.Add(Me.txtParentNo24)
        Me.Controls.Add(Me.txtParentNo23)
        Me.Controls.Add(Me.txtParentNo22)
        Me.Controls.Add(Me.txtParentNo14)
        Me.Controls.Add(Me.txtParentNo13)
        Me.Controls.Add(Me.txtParentNo12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtParentNo41)
        Me.Controls.Add(Me.txtParentNo31)
        Me.Controls.Add(Me.txtParentNo21)
        Me.Controls.Add(Me.txtParentNo11)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.btnReturn)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.txtLv44)
        Me.Controls.Add(Me.txtLv43)
        Me.Controls.Add(Me.txtLv42)
        Me.Controls.Add(Me.txtLv41)
        Me.Controls.Add(Me.txtLv34)
        Me.Controls.Add(Me.txtLv33)
        Me.Controls.Add(Me.txtLv32)
        Me.Controls.Add(Me.txtLv31)
        Me.Controls.Add(Me.txtLv24)
        Me.Controls.Add(Me.txtLv23)
        Me.Controls.Add(Me.txtLv22)
        Me.Controls.Add(Me.txtLv21)
        Me.Controls.Add(Me.txtLv14)
        Me.Controls.Add(Me.txtLv13)
        Me.Controls.Add(Me.txtLv12)
        Me.Controls.Add(Me.txtLv11)
        Me.Controls.Add(Me.UCnt_Pal00011)
        Me.MaximizeBox = False
        Me.Name = "Frm_NewPlan"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "OIO BAMA Client"
        CType(Me.nudStartRowNo1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudStartRowNo2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudStartRowNo3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudStartRowNo4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents tvPlan As System.Windows.Forms.TreeView
    Friend WithEvents txtParentNo44 As System.Windows.Forms.TextBox
    Friend WithEvents txtParentNo43 As System.Windows.Forms.TextBox
    Friend WithEvents txtParentNo42 As System.Windows.Forms.TextBox
    Friend WithEvents txtParentNo34 As System.Windows.Forms.TextBox
    Friend WithEvents txtParentNo33 As System.Windows.Forms.TextBox
    Friend WithEvents txtParentNo32 As System.Windows.Forms.TextBox
    Friend WithEvents txtParentNo24 As System.Windows.Forms.TextBox
    Friend WithEvents txtParentNo23 As System.Windows.Forms.TextBox
    Friend WithEvents txtParentNo22 As System.Windows.Forms.TextBox
    Friend WithEvents txtParentNo14 As System.Windows.Forms.TextBox
    Friend WithEvents txtParentNo13 As System.Windows.Forms.TextBox
    Friend WithEvents txtParentNo12 As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtPlanName4 As System.Windows.Forms.TextBox
    Friend WithEvents txtPlanName3 As System.Windows.Forms.TextBox
    Friend WithEvents txtPlanName2 As System.Windows.Forms.TextBox
    Friend WithEvents txtPlanName1 As System.Windows.Forms.TextBox
    Friend WithEvents txtParentNo41 As System.Windows.Forms.TextBox
    Friend WithEvents txtParentNo31 As System.Windows.Forms.TextBox
    Friend WithEvents txtParentNo21 As System.Windows.Forms.TextBox
    Friend WithEvents txtParentNo11 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnReturn As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents btnSave As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents txtLv44 As System.Windows.Forms.TextBox
    Friend WithEvents txtLv43 As System.Windows.Forms.TextBox
    Friend WithEvents txtLv42 As System.Windows.Forms.TextBox
    Friend WithEvents txtLv41 As System.Windows.Forms.TextBox
    Friend WithEvents txtLv34 As System.Windows.Forms.TextBox
    Friend WithEvents txtLv33 As System.Windows.Forms.TextBox
    Friend WithEvents txtLv32 As System.Windows.Forms.TextBox
    Friend WithEvents txtLv31 As System.Windows.Forms.TextBox
    Friend WithEvents txtLv24 As System.Windows.Forms.TextBox
    Friend WithEvents txtLv23 As System.Windows.Forms.TextBox
    Friend WithEvents txtLv22 As System.Windows.Forms.TextBox
    Friend WithEvents txtLv21 As System.Windows.Forms.TextBox
    Friend WithEvents txtLv14 As System.Windows.Forms.TextBox
    Friend WithEvents txtLv13 As System.Windows.Forms.TextBox
    Friend WithEvents txtLv12 As System.Windows.Forms.TextBox
    Friend WithEvents txtLv11 As System.Windows.Forms.TextBox
    Friend WithEvents UCnt_Pal00011 As MUSE.UserControl.UCnt_Pal0001
    Friend WithEvents nudStartRowNo1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudStartRowNo2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudStartRowNo3 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudStartRowNo4 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents btnReset As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents lblContractName As System.Windows.Forms.Label
    Friend WithEvents lblCPNO As System.Windows.Forms.Label
    Friend WithEvents lblContractNo As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents btnLogOut As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Btn_DelLv1 As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_DelLv2 As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_DelLv3 As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_DelLv4 As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents BtnImportXls As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents BtnExportXls As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents BtnOutFolder As MUSE.UserControl.UCnt_Btn0001
End Class
