﻿Imports System.IO
Imports Microsoft.Office.Interop
Imports MUSE.Utility
Imports MUSE.Utility.OioBamaCommmon
Imports MUSE.Utility.SharedClass

Public Class ExcelNissay

#Region "Inner Class"
    Private Class PaymentTBL
        Inherits DataTable

        Public Sub New()
            Me.TableName = "PSExcelDataTable"
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT_SEQ, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM05, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.QTY, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.INST_DATE, Type.GetType("System.String"))
            Me.Columns.Add("DivideNo", Type.GetType("System.String"))
            Me.Columns.Add("DivideNo2", Type.GetType("System.String"))
        End Sub
    End Class
#End Region

#Region "Const"
    Private Const SHEET_NAME_SUMMARY As String = "サマリ"
    Private Const OUTPUT_DATE As String = "N2"
    Private Const CONTRACT_NO As String = "D4"
    Private Const CONTRACT_NAME As String = "D5"
    Private Const PAYMENT_NAME As String = "D10"
    Private Const PAYMENT_DATE As String = "J10"

    Private Const SHEET_NAME_PA As String = "PA別紙"
    Private Const EXCEL_TMP_ROW As Integer = 3
    Private Const EXCEL_BESSI_ROW As Integer = 4
    Private Const EXCEL_TUUCHI_ROW As Integer = 5
    Private Const EXCEL_DATA_START_ROW As Integer = 9
#End Region

#Region "Public"

    ''' <summary>
    ''' 機能：Nissay向け契約書別紙(PA)
    ''' </summary>
    ''' <param name="strPaymentFileName"></param>
    ''' <param name="strMsg"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function OutputPa(ByVal strPaymentFileName As String,
                             ByRef strMsg As String) As Boolean

        Dim xlApp As New Excel.Application
        Dim xlBooks As Excel.Workbooks = Nothing
        Dim blnRet As Boolean
        Dim PaymentData As New PaymentTBL
        Dim alDivideNo As New ArrayList     '契約通番を"."区切りにした最後の値の先頭4桁
        Dim alDivideNo2 As New ArrayList    '契約通番を"."区切りにした最初と２番目の値を"_"で繋げた値

        OutputPa = False

        Try
            xlApp.DisplayAlerts = False
            xlApp.EnableEvents = False
            xlApp.Visible = False
            xlBooks = xlApp.Workbooks

            '---------------------------------------------------
            'Paymentからデータ取得
            '---------------------------------------------------
            blnRet = GetPaymentData(xlBooks, strPaymentFileName, PaymentData, alDivideNo, alDivideNo2, strMsg)
            If blnRet = False Then
                Exit Function
            End If

            '---------------------------------------------------
            '件数チェック
            '---------------------------------------------------
            If PaymentData.Rows.Count = 0 Then
                strMsg = "該当データが存在しません。"
                Exit Function
            End If

            '---------------------------------------------------
            '契約書別紙（PA）出力
            '---------------------------------------------------
            blnRet = OutputExcelPa(xlBooks, PaymentData, alDivideNo, alDivideNo2, strMsg, strPaymentFileName)
            If blnRet = False Then
                Exit Function
            End If

            OutputPa = True

        Catch ex As Exception
            strMsg = ex.Message.ToString & "(OutputPa)"

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlBooks, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Function

#End Region

#Region "Private"
    ''' <summary>
    ''' 機能：Paymentからデータ取得
    ''' </summary>
    ''' <param name="xlBooks"></param>
    ''' <param name="strPaymentFileName"></param>
    ''' <param name="PaymentData"></param>
    ''' <param name="alDivideNo"></param>
    ''' <param name="strMsg"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetPaymentData(ByVal xlBooks As Excel.Workbooks,
                                    ByVal strPaymentFileName As String,
                                    ByRef PaymentData As PaymentTBL,
                                    ByRef alDivideNo As ArrayList,
                                    ByRef alDivideNo2 As ArrayList,
                                    ByRef strMsg As String) As Boolean

        Dim blnRet As Boolean
        Dim strRange As String
        Dim objData(,) As Object
        Dim intRow As Integer = ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW - 1
        Dim strContactNo As String
        Dim strDivideNo() As String
        Dim intCol As Integer

        Dim xlBook As Excel.Workbook = Nothing
        Dim xlSheets As Excel.Sheets = Nothing
        Dim xlSheet As Excel.Worksheet = Nothing

        GetPaymentData = False

        Try
            xlBook = xlBooks.Open(strPaymentFileName)
            xlSheets = xlBook.Worksheets
            xlSheet = xlSheets.Item(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)

            Do
                intRow = intRow + 1
                strRange = "A" & intRow.ToString & ":BJ" & intRow.ToString
                blnRet = ExcelWrite.GetCellValue(xlSheet, strRange, objData)
                If blnRet = False Then
                    Exit Function
                End If

                'EOF判定
                If ExcelWrite.changeDBNullToString(objData(1, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)) = "" Then
                    Exit Do
                End If

                '対象チェック
                blnRet = CheckTargetLine(objData)
                If blnRet = False Then
                    Continue Do
                End If

                Dim row As DataRow
                row = PaymentData.NewRow

                intCol = ExcelWrite.ExcelPaymentLineColumn.CONTRACT_SEQ
                strContactNo = ExcelWrite.changeDBNullToString(objData(1, intCol)).Trim
                row("CellNM" & intCol) = strContactNo
                intCol = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01
                row("CellNM" & intCol) = ExcelWrite.changeDBNullToString(objData(1, intCol)).Trim
                intCol = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03
                row("CellNM" & intCol) = ExcelWrite.changeDBNullToString(objData(1, intCol)).Trim
                intCol = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM05
                row("CellNM" & intCol) = ExcelWrite.changeDBNullToString(objData(1, intCol)).Trim
                intCol = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11
                row("CellNM" & intCol) = ExcelWrite.changeDBNullToString(objData(1, intCol)).Trim
                intCol = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12
                row("CellNM" & intCol) = ExcelWrite.changeDBNullToString(objData(1, intCol)).Trim
                intCol = ExcelWrite.ExcelPaymentLineColumn.QTY
                row("CellNM" & intCol) = ExcelWrite.changeDBNullToString(objData(1, intCol)).Trim
                intCol = ExcelWrite.ExcelPaymentLineColumn.INST_DATE
                row("CellNM" & intCol) = ExcelWrite.changeDBNullToString(objData(1, intCol)).Trim
                If strContactNo.Trim <> "" Then
                    strDivideNo = strContactNo.Split(".")
                    If strDivideNo.Length > 1 Then
                        row("DivideNo2") = strDivideNo(0) & "_" & strDivideNo(1)
                    Else
                        row("DivideNo2") = "不明"
                    End If
                    If strDivideNo(strDivideNo.Length - 1).Length >= 4 Then
                        row("DivideNo") = strDivideNo(strDivideNo.Length - 1).Substring(0, 4)
                    Else
                        row("DivideNo") = "不明"
                    End If
                Else
                    row("DivideNo") = "不明"
                    row("DivideNo2") = "不明"
                End If

                PaymentData.Rows.Add(row)

                If alDivideNo.Contains(row("DivideNo")) = False Then
                    alDivideNo.Add(row("DivideNo"))
                End If

                If alDivideNo2.Contains(row("DivideNo2")) = False Then
                    alDivideNo2.Add(row("DivideNo2"))
                End If
            Loop

            GetPaymentData = True

        Catch ex As Exception
            strMsg = ex.Message.ToString & "(GetPaymentData)"

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBook) = False Then
                xlBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Function

    ''' <summary>
    ''' 機能：対象チェック
    ''' </summary>
    ''' <param name="objData"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckTargetLine(ByVal objData(,) As Object) As Boolean

        Dim strWork As String

        CheckTargetLine = False

        Try
            strWork = ExcelWrite.changeDBNullToString(objData(1, ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG))
            If strWork = "C" Then
                Exit Function
            End If

            strWork = ExcelWrite.changeDBNullToString(objData(1, ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD))
            If strWork <> "11" Then
                Exit Function
            End If

            strWork = ExcelWrite.changeDBNullToZero(objData(1, ExcelWrite.ExcelPaymentLineColumn.QTY))
            If strWork <= 0 Then
                Exit Function
            End If

            CheckTargetLine = True

        Catch ex As Exception
            Throw ex

        End Try

    End Function

    ''' <summary>
    ''' 機能：契約書別紙（PA）出力
    ''' </summary>
    ''' <param name="xlBooks"></param>
    ''' <param name="PaymentData"></param>
    ''' <param name="alDivideNo"></param>
    ''' <param name="strMsg"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function OutputExcelPa(ByVal xlBooks As Excel.Workbooks,
                                   ByVal PaymentData As PaymentTBL,
                                   ByVal alDivideNo As ArrayList,
                                   ByVal alDivideNo2 As ArrayList,
                                   ByRef strMsg As String,
                                   ByVal PaymentFileName As String) As Boolean

        Dim xlBook As Excel.Workbook = Nothing
        Dim xlSheets As Excel.Sheets = Nothing
        Dim xlSheet As Excel.Worksheet = Nothing
        Dim xlRange As Excel.Range = Nothing
        Dim strSrcPath As String = FileManager.GetLocalFolderPath(CommonConstant.FOLDERNAME_TEMPLATE)
        Dim strSrcFileName As String = "日生用契約書別紙Template.xlsm"
        Dim strDestPath As String
        Dim strDestFileName As String
        Dim ofm As New OioFileManage
        Dim strDivideNo As String
        Dim strDivideNo2 As String
        Dim strSelect As String
        Dim strSort As String = "CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT_SEQ
        Dim objData(,) As Object
        Dim blnRet As Boolean
        Dim strRange As String
        Dim intOutputRow As Integer
        Dim strItem01 As String
        Dim strItem05 As String
        Dim strItem11 As String
        Dim strWork As String
        Dim strEndDate As String

        OutputExcelPa = False

        Try
            'Templateコピー元取得
            strSrcPath = FileManager.GetLocalFolderPath(CommonConstant.FOLDERNAME_TEMPLATE)
            '出力先フォルダ取得
            strDestPath = ofm.GetLocalOutputCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)

            Dim intRet As Integer

            intRet = MsgBox("PA別紙：通知書用のヘッダーで宜しいですか？", vbQuestion + MsgBoxStyle.YesNo, "")

            For Each strDivideNo In alDivideNo
                strSelect = "DivideNo='" & strDivideNo & "'"
                '---------------------------------------------------
                'Templateコピー
                '---------------------------------------------------
                strDestFileName = "契約書別紙情報_" &
                                  CommonVariable.CPNO & "_NO" &
                                  Format(CommonVariable.CONTRACTNO, "000") & "_" &
                                  strDivideNo & "_" &
                                  Now.ToString("yyyyMMdd_HHmm") & ".xlsm"
                File.Copy(strSrcPath & strSrcFileName, strDestPath & strDestFileName, True)

                'Excel Open
                xlBook = xlBooks.Open(strDestPath & strDestFileName)
                xlSheets = xlBook.Worksheets
                xlSheet = xlSheets.Item(SHEET_NAME_PA)

                ''ｼｰﾄのｺﾋﾟｰ&ﾘﾈｰﾑ
                Dim i As Integer = 0
                If alDivideNo2.Count > 1 Then
                    For Each strDivideNo2 In alDivideNo2
                        xlSheet = xlSheets.Item(SHEET_NAME_PA)
                        Call xlSheet.Copy(Before:=xlSheet)
                        xlSheet = xlSheets.Item(SHEET_NAME_PA & " (" & 2 & ")")
                        xlSheet.Name = strDivideNo2
                        i = i + 1
                    Next
                Else
                    xlSheet = xlSheets.Item(SHEET_NAME_PA)
                    Call xlSheet.Copy(Before:=xlSheet)
                    xlSheet = xlSheets.Item(SHEET_NAME_PA & " (" & 2 & ")")
                    xlSheet.Name = alDivideNo2(0)
                End If

                xlSheet = xlSheets.Item(SHEET_NAME_PA)
                xlSheet.Delete()

                For Each strDivideNo2 In alDivideNo2
                    strSelect = "DivideNo='" & strDivideNo & "'" & "AND "
                    strSelect = strSelect & "DivideNo2='" & strDivideNo2 & "'"

                    xlSheet = xlSheets.Item(strDivideNo2)

                    '---------------------------------------------------
                    'データ取得
                    '---------------------------------------------------
                    Dim rows() As DataRow
                    rows = PaymentData.Select(strSelect, strSort)

                    If rows.Length = 0 Then
                        xlSheet.Delete()
                    Else
                        '---------------------------------------------------
                        '罫線作成
                        '---------------------------------------------------
                        Const DIVISION_LINES As Integer = 5000
                        Dim intCnt As Integer
                        Dim intSho As Integer = rows.Length \ DIVISION_LINES
                        Dim intAmari As Integer = rows.Length Mod DIVISION_LINES

                        If intRet = vbYes Then
                            xlRange = xlSheet.Rows(EXCEL_BESSI_ROW)
                        Else
                            xlRange = xlSheet.Rows(EXCEL_TUUCHI_ROW)
                        End If
                        xlRange.Hidden = True

                        xlRange = xlSheet.Rows(EXCEL_TMP_ROW)
                        xlRange.Copy()
                        ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                        For intCnt = 1 To intSho
                            strRange = (EXCEL_DATA_START_ROW + (intCnt - 1) * DIVISION_LINES).ToString() & ":" & (EXCEL_DATA_START_ROW + intCnt * DIVISION_LINES - 1).ToString()
                            xlRange = xlSheet.Range(strRange)
                            xlRange.PasteSpecial()
                            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                        Next
                        If intAmari > 0 Then
                            strRange = (EXCEL_DATA_START_ROW + (intSho * DIVISION_LINES)).ToString() & ":" & (EXCEL_DATA_START_ROW + (intSho * DIVISION_LINES + intAmari) - 1).ToString()
                            xlRange = xlSheet.Range(strRange)
                            xlRange.PasteSpecial()
                            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                        End If
                        xlRange = xlSheet.Rows(EXCEL_TMP_ROW)
                        xlRange.Hidden = True
                        ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)

                        '---------------------------------------------------
                        'データ出力
                        '---------------------------------------------------
                        intOutputRow = EXCEL_DATA_START_ROW
                        For Each row As DataRow In rows
                            strRange = "B" & intOutputRow.ToString & ":L" & intOutputRow.ToString
                            blnRet = ExcelWrite.GetCellValue(xlSheet, strRange, objData)
                            If blnRet = False Then
                                Exit Function
                            End If

                            '通番（B列）
                            objData(1, 1) = row("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT_SEQ)
                            '非表示（C列）
                            objData(1, 2) = ""
                            '非表示（D列）
                            objData(1, 3) = ""
                            '項目１（E列）
                            strItem01 = row("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01)
                            objData(1, 4) = strItem01
                            '項目３（F列）
                            objData(1, 5) = row("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03) & vbCrLf
                            '数量（G列）
                            objData(1, 6) = row("CellNM" & ExcelWrite.ExcelPaymentLineColumn.QTY)
                            '使用可能予定日（H列）
                            strItem11 = row("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11)
                            objData(1, 7) = strItem11
                            '提供期間（I列）
                            objData(1, 8) = strItem11
                            '～（J列）
                            objData(1, 9) = "～"
                            '年/月/日（K列）
                            '※空白                      ：項目１の先頭１桁目が「D、E」以外
                            '※出荷日から12ヵ月後の末日  ：項目１の先頭１桁目が「D」
                            '※サービス期間終了日        ：項目１の先頭１桁目が「E」and  ｱﾆﾊﾞｰｻﾘｰDateとｻｰﾋﾞｽ期間開始日が違う
                            '※一年間                    ：項目１の先頭１桁目が「E」and  ｱﾆﾊﾞｰｻﾘｰDateとｻｰﾋﾞｽ期間開始日が同じ
                            Select Case strItem01.Substring(0, 1)
                                Case "D"
                                    strEndDate = "出荷日から" & vbCrLf & "12ヵ月後の末日"
                                Case "E"
                                    strEndDate = "一年間"
                                    strItem05 = row("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM05)
                                    If IsNumeric(strItem05) = True And IsDate(strItem11) = True Then
                                        If Integer.Parse(strItem05) <> Date.Parse(strItem11).Month Then
                                            strEndDate = row("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12)
                                        End If
                                    End If
                                Case Else
                                    strEndDate = ""
                            End Select
                            objData(1, 10) = strEndDate
                            '補足（L列）
                            objData(1, 11) = "*8"

                            xlRange = xlSheet.Range(strRange)
                            xlRange.Value = objData
                            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)

                            intOutputRow = intOutputRow + 1
                        Next

                        'データ貼付後に行の高さを合わせる
                        Dim xlOutCell As Excel.Range

                        xlOutCell = xlSheet.Rows(EXCEL_DATA_START_ROW & ":" & intOutputRow)
                        Call xlOutCell.AutoFit()

                    End If

                Next

                'サマリシート作成
                xlSheet = xlSheets.Item(SHEET_NAME_SUMMARY)

                xlRange = xlSheet.Range(OUTPUT_DATE)
                xlRange.Value = Now.ToString("yyyy/MM/dd")

                xlRange = xlSheet.Range(CONTRACT_NO)
                xlRange.Value = CommonVariable.CONTRACTNO.ToString.PadLeft(3, "0")

                xlRange = xlSheet.Range(CONTRACT_NAME)
                xlRange.Value = CommonVariable.CONTRACTNONAME

                xlRange = xlSheet.Range(PAYMENT_NAME)
                xlRange.Value = System.IO.Path.GetFileName(PaymentFileName)

                xlRange = xlSheet.Range(PAYMENT_DATE)
                xlRange.Value = System.IO.File.GetLastWriteTime(PaymentFileName).ToString("yyyy/MM/dd HH:mm:ss")

                '保存
                xlBook.Save()
                If IsNothing(xlBook) = False Then
                    xlBook.Close(False)
                End If
                ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)
            Next

            OutputExcelPa = True

        Catch ex As Exception
            strMsg = ex.Message.ToString & "(GetPaymentData)"

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBook) = False Then
                xlBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Function

#End Region

End Class
