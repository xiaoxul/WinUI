﻿Imports System.Text
Imports System.Data.OleDb
Imports System.IO
Imports Microsoft.Office.Interop
Imports MUSE.Utility
Imports MUSE.Utility.UserMessageBox
Imports MUSE.Utility.OioBamaCommmon
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.UserDataTable.Master
Imports MUSE.DataAccess.OleDb
Imports System.Runtime

Public Class Frm_ContractInfo

#Region "定数"
    Private Const samplePSFile As String = "PaymentLineSample.xlsm"
    Private Const sampleDetailFile As String = "PaymentLineDetailSample.xlsm"
    Private Const samplePath As String = "../Template\"
    Private Const EXCEL_START_MONTH As String = "01"

    'ｺﾝﾎﾞﾎﾞｯｸｽのTag情報　※仮契約/それ以外の判定に使用
    Private Const CmbCpnoTag_Contract As String = "Contract"
    Private Const CmbCpnoTag_TmpContract As String = "TmpContract"

    'Req.1612 別紙B自動作成 2017/12 Str
    Private Const PRCPNO As String = "PRCPNO"
    'Req.1612 別紙B自動作成 2017/12 End
#End Region

#Region "構造体"

    ''DGV ⇔ 価格承認依頼/契約締結日の移動用の情報
    ''補足：DGVのRow情報のTagにて格納。
    ''　　　DGVのSelect時、画面_価格承認依頼のセット等に使用。
    ''　　　GSAｻｰﾊﾞｰのレスポンスが低いため、MDBの再取得は極力避ける。
    Private Structure AddDGVRowInfo
        Dim priceRequestDate As String          ''価格承認依頼日
        Dim contractDate As String              ''契約締結済日
        Dim proposalDate As String              ''提案開始日
    End Structure


    '変更前設定値
    Private Structure BeforeValue
        Dim strCpNo As String                   'CPNO
        Dim strCustomerName As String           'お客様名
        Dim strDtpStartDate As String           '契約期間（開始）
        Dim strDtpEndDate As String             '契約期間（終了）
        Dim strTopacsCPNO As String             'Topacs用CPNO
        Dim strPaAniv As String                 'PAアニバーサリーDate(月)
        Dim strPaLevel As String                'PA Level
        Dim strSection As String                '部署名
        Dim strExcelStartYear As String         'EXCEL開始（年）
        Dim strExcelStartMonth As String        'EXCEL開始（月）
        Dim strContractNo As String             '契約順番
        Dim strContractName As String           '契約順番名
        Dim strPriceRequestDate As String       '価格承認依頼日
        Dim blnPriceRequestDate As Boolean      '価格承認依頼日（チェック）
        Dim strContractDate As String           '契約締結日
        Dim blnContractDate As Boolean          '契約締結日（チェック）
        Dim strDeploymentPeriod As String       'Payment展開期間        
    End Structure
#End Region

#Region "メンバ変数 "
    Private bvItem As BeforeValue               '変更前設定値
    Private isTmpContract As Boolean            ''仮契約情報かどうか?
    'Req.1612 別紙B自動作成 2017/12 Str
    Private isAttachB As Boolean                '別紙B出力の現在値
    'Req.1612 別紙B自動作成 2017/12 End
#End Region

#Region "フィールド"
    Private tbBase As DataTable
    Private tbDetail As DataTable
    Private tbBusho As DataTable
    Private isUpdate As Boolean
    Private isNewRegist As Boolean
    Private itemPALevel As Object = New Object() {"", "PAX", "BL", "C", "D", "E", "F", "G", "H", "I", "J", "ED"}
#End Region

#Region "列挙体"
    Private Enum enmCommonVariableIdx
        CPNO = 1
        CONTRACTNO
        CUSTOMERNAME
        CONTRACTNONAME
        PALEVEL
        ANNIVERSARY
        ContractStart
        ContractEnd
        PaymentStart
        PaymentPeriod
    End Enum
#End Region

#Region "イベント処理"

    ''' <summary>
    ''' 機　能：フォームロード時
    ''' 説　明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Frm_ContractInfo_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Me.cmbPAAniv.Items.AddRange(New Object() {"", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"})
        Me.cmbPALevel.Items.AddRange(itemPALevel)
        Me.nudContractNo.Value = 0

        ControlReflesh(True)
        AddCmbItemsCPNO()
        Me.btnRegistUpdate.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.btnRegistUpdate.Name)

        '画面の値をセットする
        Call SetDisplayValue()

        Me.Text = CommonVariable.OBAMATITLE
        If IsNothing(CommonVariable.CPNO) = False AndAlso CommonVariable.CPNO <> "" Then
            cmbCpnoName.Text = CommonVariable.CPNO & " " & CommonVariable.CUSTOMERNAME
        End If
        cmbCpnoName.Location = cmbCPNO.Location
        cmbCPNO.Visible = False

    End Sub

    ''' <summary>
    ''' 機　能：CPNOコンボボックスを選択したとき
    ''' 説　明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub cmbCPNO_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbCPNO.SelectedIndexChanged


        Try
            If Me.cmbCPNO.SelectedIndex = 0 Then
                ControlReflesh(True)
                Me.cmbCPNO.DropDownStyle = ComboBoxStyle.DropDown
                Me.cmbCPNO.Tag = Me.CmbCpnoTag_Contract             ''選択したCPNOが仮契約かの判定に使用
                Me.cmbCpnoName.DropDownStyle = ComboBoxStyle.DropDown
            Else
                ControlReflesh(False)
                Me.cmbCPNO.DropDownStyle = ComboBoxStyle.DropDownList
                Me.isUpdate = True
                Me.cmbCpnoName.DropDownStyle = ComboBoxStyle.DropDownList

                Dim drBase() As DataRow = tbBase.Select("CPNO = '" & Me.cmbCPNO.SelectedItem.ToString() & "'")
                Me.tbCustomerName.Text = drBase(0).Item("CUST_NAME").ToString()
                If drBase(0).Item("START_YEAR") IsNot DBNull.Value Or drBase(0).Item("START_MONTH") IsNot DBNull.Value Then
                    Dim startDate As Date = Date.ParseExact(drBase(0).Item("START_YEAR").ToString() + drBase(0).Item("START_MONTH").ToString().PadLeft(2, "0"),
                                     "yyyyMM", Nothing)

                    Me.dtpStart.Value = startDate
                End If

                If drBase(0).Item("END_YEAR") IsNot DBNull.Value Or drBase(0).Item("END_MONTH") IsNot DBNull.Value Then

                    Dim endDate As Date = Date.ParseExact(drBase(0).Item("END_YEAR").ToString() + drBase(0).Item("END_MONTH").ToString().PadLeft(2, "0"),
                                                     "yyyyMM", Nothing)
                    Me.dtpEnd.Value = endDate
                End If

                Me.tbTopacsCPNO.Text = ExcelWrite.changeDBNullToString(drBase(0).Item("TOPACS_CPNO"))

                If drBase(0).Item("PA_ANV_DATE") IsNot DBNull.Value AndAlso _
                   drBase(0).Item("PA_ANV_DATE") <> "" Then

                    Dim strDP As String() = {"", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K"}
                    Dim strAD As String() = {"", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C"}
                    Dim Str1 As String
                    Dim Int1 As Integer
                    Dim Int2 As Integer
                    Dim ii As Integer

                    '１文字目切り出し
                    Str1 = Mid(drBase(0).Item("PA_ANV_DATE").ToString(), 1, 1)
                    '１文字目をIndexに変換
                    Int1 = 0
                    For ii = 0 To 20
                        If Str1 = strDP(ii) Then
                            Int1 = ii
                        End If
                    Next
                    '変換したIndexを画面にセット
                    If Int1 = 0 Then
                        Me.nudDeploymentPeriod.Value = 20
                    Else
                        Me.nudDeploymentPeriod.Value = Int1
                    End If

                    '２文字目切り出し
                    Str1 = Mid(drBase(0).Item("PA_ANV_DATE").ToString(), 2, 1)
                    '２文字目をIndexに変換
                    Int2 = 0
                    For ii = 0 To 12
                        If Str1 = strAD(ii) Then
                            Int2 = ii
                        End If
                    Next
                    '変換したIndexを画面にセット
                    Me.cmbPAAniv.SelectedIndex = Int2
                Else
                    Me.nudDeploymentPeriod.Value = 20
                    Me.cmbPAAniv.SelectedIndex = 0
                End If

                Dim i As Integer = 0
                For Each obj As Object In itemPALevel
                    If drBase(0).Item("PA_LEVEL").ToString() = obj.ToString() Then
                        Me.cmbPALevel.SelectedIndex = i
                    End If
                    i += 1
                Next
                Me.nudExcelStartYear.Value = Integer.Parse(drBase(0).Item("EXCEL_START").ToString().Substring(0, 4))
                Me.nudExcelStartMonth.Value = Integer.Parse(drBase(0).Item("EXCEL_START").ToString().Substring(4, 2))

                ''統合処理方法 = JRIなら、統合/削除ﾎﾞﾀﾝ表示
                If drBase(0).Item("UNIFICATION_PATERN").ToString() = "01" Then
                    Me.cmbCPNO.Tag = Me.CmbCpnoTag_TmpContract             ''選択したCPNOが仮契約かの判定に使用
                    Me.Btn_DspFrm.Enabled = True
                    Me.Btn_DspFrm.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.Btn_DspFrm.Name)
                    Me.isTmpContract = True
                    '仮契約の初期化を表示
                    Me.ChkInitTmpCon.Visible = True
                Else
                    Me.cmbCPNO.Tag = Me.CmbCpnoTag_Contract                ''選択したCPNOが仮契約かの判定に使用
                    Me.Btn_DspFrm.Enabled = False
                    Me.isTmpContract = False
                    '仮契約の初期化を非表示
                    Me.ChkInitTmpCon.Visible = False
                End If

                If ExcelWrite.changeDBNullToString(drBase(0).Item("DISP_ASR_FLG")) = "0" Then
                    Me.chkAsrAll.Checked = True
                ElseIf ExcelWrite.changeDBNullToString(drBase(0).Item("DISP_ASR_FLG")) = "" Then
                    Me.chkAsrAll.Checked = False
                Else
                    Me.chkAsrAll.Checked = False
                End If

                If ExcelWrite.changeDBNullToString(drBase(0).Item("UNIFICATION_PATERN")) = "00" Or _
                   ExcelWrite.changeDBNullToString(drBase(0).Item("UNIFICATION_PATERN")) = "" Then
                    Me.chkDspFrm.Checked = False
                Else
                    Me.chkDspFrm.Checked = True
                End If

                'データグリッド表示
                Call ShowDGV()

                ''ステータスの初期値をセット
                If Me.DataGridView1.Rows.Count > 0 Then
                    Call AddCmbItemsState(Me.cmbCPNO.Tag, Me.DataGridView1.Rows(0).Cells(0).Value)
                    Me.CmbState.SelectedText = Me.DataGridView1.Rows(0).Cells(2).Value
                Else
                    Call AddCmbItemsState(Me.cmbCPNO.Tag)
                End If

                '画面の値をセットする
                Call SetDisplayValue()

                'Req.1612 別紙B自動作成 2017/12 Str
                If GetCode(cmbCPNO.Text) = True Then
                    ChkAttachB.Checked = True
                    isAttachB = True
                Else
                    ChkAttachB.Checked = False
                    isAttachB = False
                End If
                'Req.1612 別紙B自動作成 2017/12 End
            End If

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")

        End Try

    End Sub

    ''' <summary>
    ''' 機　能：契約順番の値変更ｲﾍﾞﾝﾄ
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub nudContractNo_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles nudContractNo.ValueChanged

        ''前のｺﾝﾎﾞﾎﾞｯｸｽの値を保持
        Dim BeforeValue As String
        BeforeValue = Me.CmbState.Text

        ''ｺﾝﾎﾞﾎﾞｯｸｽ初期化        
        Call AddCmbItemsState(Me.cmbCPNO.Tag, Me.nudContractNo.Value)

        ''          以下、ｺﾝﾎﾞﾎﾞｯｸｽの選択文字をｾｯﾄ
        ''--------------------------------------------------------
        ''例外①：JRI+仮契約順番のため、仮契約をセット
        If isTmpContract = True And nudContractNo.Value >= 800 Then
            Me.CmbState.SelectedText = "仮契約"
            Exit Sub
        End If

        ''例外②：仮契約の契約 ⇒　通常契約移動
        If BeforeValue = "仮契約" And _
           (nudContractNo.Value < 800 Or nudContractNo.Value > 990 Or isTmpContract = False) Then
            Me.CmbState.SelectedText = "作成中"
            Exit Sub
        End If

        ''上記以外：前の値を引き継ぐ
        Me.CmbState.Text = BeforeValue

        ''          以下、仮契約の初期化の有効/無効切替
        ''--------------------------------------------------------
        If Me.isTmpContract = True And _
           (nudContractNo.Value < 800 Or nudContractNo.Value > 990 Or isTmpContract = False) Then
            Me.ChkInitTmpCon.Enabled = False
        Else
            Me.ChkInitTmpCon.Enabled = True
        End If

    End Sub



    ''' <summary>
    ''' 機　能：契約統合/削除ボタン押下
    ''' 説　明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Btn_DspFrm_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_DspFrm.Click

        SetCommonVariable()
        Me.Visible = False
        Dim frmTmpContractUnification As New Frm_TmpContractUnification("Contract")
        Call frmTmpContractUnification.ShowDialog()

        ''JRI画面にて押下した終了ﾎﾞﾀﾝに応じて処理を行う。
        If frmTmpContractUnification.Rtn_ContractFrmBtn = True Then
            ''契約登録画面へ
            Me.Visible = True

        ElseIf frmTmpContractUnification.Rtn_LogOutBtn = True Then
            ''Login画面へ
            Me.Close()

        End If

    End Sub

    ''' <summary>
    ''' 機　能：画面リセット押下時
    ''' 説　明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnReflesh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReflesh.Click

        'リフレッシュ
        ControlReflesh(True)

        '画面の値をセットする
        Call SetDisplayValue()

    End Sub

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnGetNewData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetNewData.Click

        Dim ofm As New OioFileManage
        Dim blnRet As Boolean

        Try
            ''画面の契約順番を保持　-- selectChangeイベントが多数走っているため、変数に値を保持
            Dim constract As Integer
            constract = Me.nudContractNo.Value

            'データ表示処理
            Dim strCpNo As String = Me.cmbCPNO.Text
            ControlReflesh(False)
            AddCmbItemsCPNO()
            Me.cmbCPNO.SelectedItem = strCpNo

            '画面の値をセットする
            Call SetDisplayValue()

            'データグリッド表示
            Call ShowDGV()

            cmbCpnoName.SelectedIndex = cmbCPNO.SelectedIndex

            Dim gridExists As Boolean = False
            Dim Idx As Integer
            For Idx = 1 To Me.DataGridView1.Rows.Count
                If CInt(Me.DataGridView1.Rows(Idx - 1).Cells(0).Value) = constract Then
                    gridExists = True
                    Exit For
                End If
            Next

            MsgBox("最新データを取得しました。", vbInformation, Me.Text)

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "")

        End Try

    End Sub

    ''' <summary>
    ''' 機　能：ログアウトボタン押下時
    ''' 説　明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBack.Click

        Dim blnRet As Boolean

        '画面の変更前の値と現在の値を比較する(True:一致　False:不一致)
        blnRet = isDisplayValue()
        If blnRet = False Then
            If MessageBox.Show(FileReader.GetMessage("MSG_0071"), Me.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = DialogResult.No Then
                Exit Sub
            End If
        End If

        Me.Hide()

    End Sub


    ''' <summary>
    ''' 機　能：登録ボタン押下時
    ''' 説　明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnRegistUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRegistUpdate.Click

        Dim blnRet As Boolean

        Try

            ''CPNOの登録済ﾁｪｯｸ ※cmbCPNO.Textのセットで、画面のイベントが起動するためここにチェックロジック
            If ExistsCPNO() Then
                MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0055"), Me.Text)
                Exit Sub
            End If

            cmbCPNO.Text = cmbCpnoName.Text


            '----------------------------------------
            '入力チェック
            '----------------------------------------
            blnRet = CheckInputData()
            If blnRet = False Then
                Exit Sub
            End If

            '1729 str
            '----------------------------------------
            '特殊文字変換
            '----------------------------------------
            blnRet = UpdateVal()
            If blnRet = False Then
                Exit Sub
            End If
            '1729 end

            '----------------------------------------
            '登録処理
            '----------------------------------------
            Me.isNewRegist = True
            blnRet = RegistContract()
            If blnRet = False Then
                Exit Sub
            End If

            'Req.1612 別紙B自動作成 2017/12 Str
            '----------------------------------------
            'Codeテーブル更新(別紙B区分更新)
            '----------------------------------------
            'Req.1612 別紙B自動作成 2018/03 Str
            'Dim wCpno As String
            'wCpno = Strings.Left(cmbCPNO.Text, 6)

            'If ChkAttachB.Checked = True Then
            '    If isAttachB = False Then
            '        'CODEテーブル更新
            'Req.1612 別紙B自動作成 2018/03 End
            blnRet = UpdateCode(cmbCPNO.Text)
            'Req.1612 別紙B自動作成 2018/03 Str
            '        If blnRet = False Then
            '            Exit Sub
            '        End If
            '    End If
            'Else
            '    If isAttachB = True Then
            '        'CODEテーブル更新
            '        blnRet = DeleteCode(wCpno)
            '        If blnRet = False Then
            '            Exit Sub
            '        End If
            '    End If
            'End If
            'Req.1612 別紙B自動作成 2018/03 End
            'Req.1612 別紙B自動作成 2017/12 End

            '----------------------------------------
            '画面表示
            '----------------------------------------
            ''画面の契約順番を保持　-- selectChangeイベントが多数走っているため、変数に値を保持
            Dim constract As Integer
            constract = Me.nudContractNo.Value

            'データ表示処理
            Dim strCpNo As String = Me.cmbCPNO.Text
            ControlReflesh(False)
            AddCmbItemsCPNO()
            Me.cmbCPNO.SelectedItem = strCpNo

            '画面の値をセットする
            Call SetDisplayValue()

            'データグリッド表示
            Call ShowDGV()

            cmbCpnoName.SelectedIndex = cmbCPNO.SelectedIndex

            Dim gridExists As Boolean = False
            Dim Idx As Integer
            For Idx = 1 To Me.DataGridView1.Rows.Count
                If CInt(Me.DataGridView1.Rows(Idx - 1).Cells(0).Value) = constract Then
                    gridExists = True
                    Exit For
                End If
            Next
            ''登録失敗してなければ、SelectChangeｲﾍﾞﾝﾄで詳細情報を画面に表示させる。
            If gridExists = True Then
                Me.DataGridView1.CurrentCell = Me.DataGridView1.Rows(Idx - 1).Cells(0)
                Call ShowDetailDate(Idx - 1)
            Else
                Call ShowDetailDate(-1)
            End If

            '処理を移動
            '----------------------------------------
            'Payment作成処理
            '----------------------------------------
            Dim exitMsg As String
            If Not Me.isUpdate Or (Me.isUpdate And Me.isNewRegist) Then
                Dim msg As String
                Dim ofm As New OioFileManage
                If ofm.CopyGSATmpFile(OioFileManage.enmTmpFileType.Payment, msg) = False Then
                    Call MuseMessageBox.ShowError(msg, Me.Text)
                    Exit Sub
                End If
                exitMsg = CreateXlsFile(cmbCPNO.Text, Me.nudContractNo.Value, Me.isTmpContract)
            End If

            If Not Me.isUpdate Or (Me.isUpdate And Me.isNewRegist) Then
                MuseMessageBox.ShowInformation(exitMsg, Me.Text)
            Else
                MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0061"), Me.Text)
            End If


        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")

        End Try
    End Sub

    ''' <summary>
    ''' 機能：契約締結済み/廃案案件の表示追加対応
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub ChkDispContract_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChkDispContract.CheckedChanged

        ''DGVのﾘﾌﾚｯｼｭと契約詳細ﾃﾞｰﾀに紐づく画面項目を再表示する。
        Try

            If Me.isUpdate = True Then

                ''ﾃﾞｰﾀｸﾞﾘｯﾄﾞの再表示
                Call ShowDGV()

                ''契約詳細ﾃﾞｰﾀに紐づく画面項目を再表示
                If Me.DataGridView1.Rows.Count > 0 Then
                    Call ShowDetailDate(Me.DataGridView1.CurrentRow.Index)
                Else
                    Call ShowDetailDate(-1)
                End If

            End If

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")

        End Try

    End Sub

    ''' <summary>
    ''' 機　能：データグリッドセル選択時
    ''' 説　明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub DataGridView1_SelectionChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DataGridView1.SelectionChanged

        ''※補足：契約締結済み/廃案案件On/Off切替でまったく同じ処理が必要になったので、関数化する。
        If Me.DataGridView1.Rows.Count > 0 Then
            Call ShowDetailDate(Me.DataGridView1.CurrentRow.Index)
        Else
            Call ShowDetailDate(-1)
        End If

    End Sub

    ''' <summary>
    ''' 機　能：
    ''' 説　明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub cbContractDate_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbContractDate.CheckedChanged

        If Me.cbContractDate.Checked Then
            Me.dtpContractDate.Enabled = True
        Else
            Me.dtpContractDate.Enabled = False
        End If

    End Sub

    ''' <summary>
    ''' 機　能：
    ''' 説　明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub cbPriceRequestDate_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbPriceRequestDate.CheckedChanged

        If Me.cbPriceRequestDate.Checked Then
            Me.dtpPriceRequestDate.Enabled = True
        Else
            Me.dtpPriceRequestDate.Enabled = False
        End If

    End Sub

    ''' <summary>
    ''' 機　能：メニューボタンを押したとき
    ''' 説　明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btn_Menu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Menu.Click

        'ステータス判定
        If IsExitContractNo() Then
            MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0059"), Me.Text)
            Return
        End If

        If Not ExistContractNo() Then
            MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0062"), Me.Text)
            Return
        End If

        '新旧ファイル名チェック
        Dim blnRet As Boolean
        blnRet = CheckPsFileName()
        If blnRet = False Then
            Exit Sub
        End If

        ''仮契約の初期化 = On なら、確認メッセージ表示
        Dim isTmpClear As Boolean = False
        If IsTmpContractClear() = True Then
            If MsgBox(FileReader.GetMessage("MSG_0459"), MsgBoxStyle.Information + MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                isTmpClear = True
            End If
        End If

        Dim updateContractNo As String
        updateContractNo = nudContractNo.Value.ToString.PadLeft(3, "000")

        ''フォルダ作成
        Dim ofm As New OioFileManage
        Call ofm.CreateFrm_ContractInfoCPNOFolder(cmbCPNO.Text, CInt(updateContractNo), Me.isTmpContract)

        Dim exitMsg As String
        If isTmpClear = True Then

            ''BackUpフォルダに移動する。
            Call MoveTmpContractFileToBackUP(cmbCPNO.Text, nudContractNo.Value)

            ''空ファイルの作成  ※ﾒｯｾｰｼﾞは表示しない。
            exitMsg = CreateXlsFile(Me.cmbCPNO.Text, Me.nudContractNo.Value, Me.isTmpContract)

        Else

            '' Excelフォルダにファイルがなければ警告メッセージを表示する。
            If ChkExistsExcelFile(cmbCPNO.Text, nudContractNo.Value) = False Then
                If MessageBox.Show(FileReader.GetMessage("MSG_0385"), _
                                   Me.Text, _
                                   MessageBoxButtons.YesNo, _
                                   MessageBoxIcon.Warning) = DialogResult.No Then
                    Exit Sub
                End If
            End If

        End If

        Dim frm As New Frm_Menu()
        Me.Hide()

        '共通変数に値をセット
        SetCommonVariable()

        frm.ShowDialog()
        Me.Close()

    End Sub

    ''' <summary>
    ''' 機　能：仮契約の初期化対象かどうか判定
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function IsTmpContractClear() As Boolean

        ''初期化
        IsTmpContractClear = False

        ''「仮契約の初期化」のﾌﾟﾛﾊﾟﾃｨで判定
        If Me.ChkInitTmpCon.Visible = True And _
           Me.ChkInitTmpCon.Enabled = True And _
           Me.ChkInitTmpCon.Checked = True Then

            Return True
        Else
            Return False

        End If

    End Function


    ''' <summary>
    ''' 機　能：仮契約ﾌｧｲﾙをBackUpフォルダに移動する。
    ''' 説　明：※メニューへﾎﾞﾀﾝ押下時に使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub MoveTmpContractFileToBackUP(ByVal CPNO As String, _
                                            ByVal ContractNo As Integer)

        Try

            ''BackUpフォルダを作成
            Dim ofm As New OioFileManage
            Call ofm.CreateTmpConBackUpFolder(CPNO, ContractNo)

            ''BackUp対象のﾌｫﾙﾀﾞﾊﾟｽを取得
            Dim copyDir As OioFileManage.TmpContractBackUpPath
            copyDir = ofm.GetDetailTmpConCopyFolder(CPNO, ContractNo)

            ''BackUp出力先ﾌｫﾙﾀﾞﾊﾟｽを取得
            Dim pasteDir As OioFileManage.TmpContractBackUpPath
            pasteDir = ofm.GetDetailTmpConBackUpFolder(CPNO, ContractNo)

            ''対象フォルダをBackUpする。
            Call MoveTmpContractFile(copyDir, pasteDir)

        Catch ex As Exception
            Throw ex

        End Try

    End Sub


    ''' <summary>
    ''' 機　能：引数のﾊﾟｽを元に、仮契約ファイルのフォルダをBackUpフォルダに移す。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub MoveTmpContractFile(ByRef copyDir As OioFileManage.TmpContractBackUpPath, _
                                    ByRef pasteDir As OioFileManage.TmpContractBackUpPath)

        ''             以下、各ﾌｧｲﾙをBackUpの移動
        ''-----------------------------------------------------
        Try
            ''Excleフォルダ
            If copyDir.Excel <> "" Then
                Call FolderMove(copyDir.Excel, pasteDir.Excel)
            End If

            ''Csv1フォルダ
            If copyDir.Csv1 <> "" Then
                Call FolderMove(copyDir.Csv1, pasteDir.Csv1)
            End If

            ''Csv2フォルダ
            If copyDir.Csv2 <> "" Then
                Call FolderMove(copyDir.Csv2, pasteDir.Csv2)
            End If

            ''Configフォルダ
            If copyDir.Config <> "" Then
                Call FolderMove(copyDir.Config, pasteDir.Config)
            End If

            ''Outputフォルダ
            If copyDir.Output <> "" Then
                Call FolderMove(copyDir.Output, pasteDir.Output)
            End If

            ''CsvTmpフォルダ
            If copyDir.CsvTmp <> "" Then
                Call FolderMove(copyDir.CsvTmp, pasteDir.CsvTmp)
            End If
        Catch ex As Exception
            Throw ex

        End Try

    End Sub

    ''' <summary>
    ''' 機　能：フォルダ直下のﾌｧｲﾙ/ディレクトリを移動する。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub FolderMove(ByVal copyDir As String, _
                           ByVal pasteDir As String)

        Try

            ''フォルダ内のファイルの移動
            Dim copyFilePaths() As String
            copyFilePaths = System.IO.Directory.GetFiles(copyDir)
            For Each copyFilePath As String In copyFilePaths
                System.IO.File.Move(copyFilePath, _
                                    pasteDir & "\" & Path.GetFileName(copyFilePath))
            Next

            ''フォルダ内のフォルダの移動
            Dim copyDirPaths() As String
            Dim TmpDir() As String
            copyDirPaths = System.IO.Directory.GetDirectories(copyDir)
            For Each copyDirPath As String In copyDirPaths
                TmpDir = Split(copyDirPath, "\")
                System.IO.Directory.Move(copyDirPath, _
                                         pasteDir & "\" & TmpDir(UBound(TmpDir)))
            Next

        Catch ex As Exception
            Throw ex

        End Try

    End Sub

    ''' <summary>
    ''' 機　能：空ﾌｧｲﾙの作成ボタン処理
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub BtnCreateXls_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnCreateXls.Click

        Try
            ''契約詳細の存在ﾁｪｯｸ
            If Not ExistContractNo() Then
                MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0062"), Me.Text)
                Return
            End If

            Dim msg As String
            Dim ofm As New OioFileManage
            If ofm.CopyGSATmpFile(OioFileManage.enmTmpFileType.Payment, msg) = False Then
                Call MuseMessageBox.ShowError(msg, Me.Text)
                Exit Sub
            End If

            ''空ファイルの作成
            Dim exitMsg As String
            exitMsg = CreateXlsFile(Me.cmbCPNO.Text, Me.nudContractNo.Value, Me.isTmpContract, False)

            ''処理の完了ﾒｯｾｰｼﾞ
            Call MuseMessageBox.ShowInformation(exitMsg, Me.Text)

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")

        End Try

    End Sub

    ''' <summary>
    ''' 機　能：データグリッドのセルをダブルクリックしたとき
    ''' 説　明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub DataGridView1_CellDoubleClick_1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellDoubleClick

        If IsExitContractNo() Then
            MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0059"), Me.Text)
            Exit Sub
        End If

        Dim frm As New Frm_Menu()

        Me.Hide()

        ''MDBから、契約番号を取得
        Dim updateContractNo As String
        updateContractNo = nudContractNo.Value.ToString.PadLeft(3, "000")

        ''フォルダ作成
        Dim ofm As New OioFileManage
        Call ofm.CreateFrm_ContractInfoCPNOFolder(cmbCPNO.Text, CInt(updateContractNo), Me.isTmpContract)

        '共通変数に値をセット
        SetCommonVariable()

        Me.Hide()
        frm.ShowDialog()
        Me.Close()
    End Sub

    Private Sub cmbCpnoName_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbCpnoName.SelectedIndexChanged

        Me.cmbCPNO.SelectedIndex = Me.cmbCpnoName.SelectedIndex

    End Sub

    ''256バイト以上の入力制限
    Private Sub tbCustomerName_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tbCustomerName.KeyPress
        Dim chkText As String
        chkText = tbCustomerName.Text & e.KeyChar
        If e.KeyChar = ControlChars.Back Then
            Exit Sub
        End If
        If System.Text.Encoding.GetEncoding("utf-8").GetByteCount(chkText) > 256 Then
            e.Handled = True
        End If
    End Sub

    ''' <summary>
    ''' 機　能：空ﾌｧｲﾙの作成＆契約済MDB作成　ボタン処理
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub BtnCreateXlsData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnCreateXlsData.Click

        Dim frmWait As New Frm_WaitDialog
        Dim OUTERR As New OutputErrorList
        Dim blnRet As Boolean
        Dim alPsCreating As New ArrayList
        Dim alPsCreated As New ArrayList
        Dim alPsdCreating As New ArrayList
        Dim alPsdCreated As New ArrayList
        Dim alPsCreatingMdb As New ArrayList                        '作成中PaymentのMDB
        Dim alPsdCreatingMdb As New ArrayList                       '作成中詳細のMDB
        Dim strExcelYear As String
        Dim usedFilePath As ImportCsv.usedFilePath
        Dim importCount As ImportCsv.ImportCount                      ''取込成功件数
        Dim importErrCount As ImportCsv.ImportErrCount                ''取込失敗件数
        Dim strCreateTime As String = Now.ToString("yyyyMMdd_HHmmss")
        Dim dtStart As Date = Now
        Dim strMsg As String
        Dim ic As New ImportCsv
        Dim strErrMsg As String
        Dim strDownloadCsvPath As String                                'CSVﾀﾞｳﾝﾛｰﾄﾞﾊﾟｽ
        Dim ofm As New OioFileManage
        Dim intImportCd As Integer
        Dim blnImportMDB As Boolean

        Try
            ''空Paymentの作成 =================================================
            ''契約詳細の存在ﾁｪｯｸ
            If Not ExistContractNo() Then
                MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0062"), Me.Text)
                Return
            End If

            ''テンプレートファイル最新化
            Dim msg As String
            If ofm.CopyGSATmpFile(OioFileManage.enmTmpFileType.Payment, msg) = False Then
                Call MuseMessageBox.ShowError(msg, Me.Text)
                Exit Sub
            End If

            ''空ファイルの作成
            Dim exitMsg As String
            exitMsg = CreateXlsFile(Me.cmbCPNO.Text, Me.nudContractNo.Value, Me.isTmpContract, False)


            '共通変数に値をセット
            SetCommonVariable()

            ''契約済MDBの作成 =================================================
            OUTERR.CpNo = CommonVariable.CPNO
            OUTERR.ContractNo = CommonVariable.CONTRACTNO   '契約順番

            strMsg = "Import(契約済のみ)"
            blnImportMDB = True
            intImportCd = ImportCsv.CD_IMPORT_MDB

            OUTERR.OutImportErrorList("START", strMsg, , , , True)
            Call SetInitWaitDialog(frmWait, "")

            '==========================================
            'MasterMDB存在チェック
            '==========================================
            If ofm.CheckExistsMdb(OioFileManage.enmMdbType.Master, CommonVariable.MdbPW, strMsg) = False Then
                Call CloseWaitDialog(frmWait)
                OUTERR.OutImportErrorList("END", "Import")
                Call MuseMessageBox.ShowError(strMsg, Me.Text)
                Exit Sub
            End If

            '==========================================
            'Masterバージョンチェック
            '==========================================
            If ofm.CheckMdbVersion(CommonVariable.MdbPW,
                                   OioFileManage.enmMdbType.Master,
                                   strErrMsg,
                                   CommonVariable.CPNO) = False Then
                Call CloseWaitDialog(frmWait)
                OUTERR.OutImportErrorList("END", "Import")
                Call MuseMessageBox.ShowError(strErrMsg, Me.Text)
                Return
            End If

            '==========================================
            'サーバーからCSVデータ取得
            '==========================================
            frmWait.ProgressValue = 1
            Call SetMsgWaitDialog(frmWait, FileReader.GetMessage("MSG_0461"))
            Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0430"))
            ''Csv取得
            Dim filePath As ImportCsv.ServerCsvPath
            strDownloadCsvPath = ofm.GetLocalCsv1Folder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            blnRet = ic.GetServerCsv(blnImportMDB, "", "C", strDownloadCsvPath, filePath, strErrMsg)
            If blnRet = False Then
                Call CloseWaitDialog(frmWait)
                OUTERR.OutImportErrorList("END", "Import")

                MsgBox(strErrMsg, MsgBoxStyle.Critical, Me.Text)

                ''処理の完了ﾒｯｾｰｼﾞ
                Call MuseMessageBox.ShowInformation(exitMsg, Me.Text)
                Exit Sub
            End If

            Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0431"))

            '==========================================
            'データを配列に保存（Refresh、Validation以外）
            '==========================================
            frmWait.ProgressValue = 3
            Call SetMsgWaitDialog(frmWait, FileReader.GetMessage("MSG_0462"))
            Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0463"))
            blnRet = ic.GetCsvData(intImportCd,
                                   filePath,
                                   CommonVariable.PaymentPeriod,
                                   alPsCreating,
                                   alPsCreatingMdb,
                                   alPsCreated,
                                   alPsdCreating,
                                   alPsdCreatingMdb,
                                   alPsdCreated,
                                   importCount,
                                   importErrCount,
                                   OUTERR,
                                   True,
                                   frmWait)
            If blnRet = False Then
                Call CloseWaitDialog(frmWait)
                Call MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0392"), Me.Text)
                Exit Sub
            End If
            Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0464"))

            '==========================================
            'TempMDBに保存
            '==========================================
            frmWait.ProgressValue = 4

            strExcelYear = CommonVariable.PaymentStart.ToString("yyyy")

            SetMsgWaitDialog(frmWait, FileReader.GetMessage("MSG_0335"))
            Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0336"))
            '締結済みMDB保存
            blnRet = ic.ImportDb(alPsCreated,
                                 alPsdCreated,
                                 strExcelYear,
                                 importCount,
                                 OUTERR,
                                 True,
                                 False,
                                 frmWait)
            If blnRet = False Then
                Call CloseWaitDialog(frmWait)
                MsgBox(FileReader.GetMessage("MSG_0338"), vbCritical)
                Exit Sub
            End If
            Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0337"))

            '==========================================
            '終了処理
            '==========================================
            frmWait.ProgressValue = 7
            Call CloseWaitDialog(frmWait)
            OUTERR.OutImportErrorList("処理時間：" & (Now - dtStart).ToString, "Import")
            OUTERR.OutImportErrorList("END", "Import")

            '完了メッセージ
            Call CompleteImportMessage(sender.name, importCount, importErrCount, usedFilePath)

            ''処理の完了ﾒｯｾｰｼﾞ
            Call MuseMessageBox.ShowInformation(exitMsg, Me.Text)

        Catch ex As Exception
            Call CloseWaitDialog(frmWait)
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")

        End Try

    End Sub

#End Region

#Region "プライベートメソッド"
    ''' <summary>
    ''' 機　能：リフレッシュ
    ''' 説　明：
    ''' </summary>
    ''' <param name="isNewReg"></param>
    ''' <remarks></remarks>
    Private Sub ControlReflesh(ByVal isNewReg As Boolean)

        Dim wc As New WebDb.WebDbCommon
        Dim blnRet As Boolean
        Dim strMsg As String = ""
        Dim dt As New M_CONTRACT_BASETable

        Try
            Me.isUpdate = False

            '契約基本情報取得
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW
            blnRet = wc.GetContractBaseData(dt, strMsg)
            If blnRet = False Then
                MsgBox(strMsg, vbCritical, "ControlReflesh")
                Exit Sub
            End If
            'ソート
            tbBase = New M_CONTRACT_BASETable
            Dim rows() As DataRow
            rows = dt.Select(Nothing, "CPNO")
            For Each row As DataRow In rows
                tbBase.ImportRow(row)
            Next

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "ControlReflesh")

        End Try

        If isNewReg Then
            Me.cmbCPNO.BackColor = Color.Yellow
            Me.tbCustomerName.BackColor = Color.Yellow
            Me.cmbPAAniv.BackColor = Color.White
            Me.cmbPALevel.BackColor = Color.White
            Me.nudExcelStartYear.BackColor = Color.Yellow
            Me.nudExcelStartMonth.BackColor = Color.Yellow
            Me.cmbPAAniv.Enabled = True
            Me.nudExcelStartYear.Enabled = True
            Me.nudExcelStartMonth.Enabled = True
            Me.cmbCPNO.Text = String.Empty
            Me.tbCustomerName.Text = String.Empty
            Me.tbTopacsCPNO.Text = String.Empty
            Dim CurDate As DateTime = DateTime.Now
            Me.dtpStart.Value = CurDate.AddMonths(1)
            Me.dtpEnd.Value = CurDate.AddYears(3)
            Me.dtpPriceRequestDate.Value = Date.Now
            Me.dtpContractDate.Value = Date.Now
            Me.cmbPAAniv.SelectedIndex = 0
            Me.cmbPALevel.SelectedIndex = 0
            Me.nudExcelStartYear.Value = CDec(CurDate.AddMonths(1).Year)
            Me.nudExcelStartMonth.Value = Date.Now.Month
            Me.nudContractNo.Value = 0
            Me.DataGridView1.Columns.Clear()
            Me.tbContractNoName.Text = String.Empty
            Me.dtpPriceRequestDate.Enabled = False
            Me.dtpContractDate.Enabled = False
            Me.cbContractDate.Enabled = False
            Me.cbContractDate.Checked = False
            Me.dtpSuggestDay.Value = CDate(CurDate.AddMonths(1).ToString("yyyy/MM/01"))
            Me.cbPriceRequestDate.Enabled = False
            Me.cbPriceRequestDate.Checked = False
            Me.btn_Menu.Enabled = False
            Me.ChkDispContract.Checked = False
            Call AddCmbItemsState(Me.cmbCPNO.Tag)
            Me.CmbState.BackColor = Color.Yellow
            Me.isTmpContract = False
            Me.BtnCreateXls.Enabled = False
            Me.BtnCreateXlsData.Enabled = False
            Me.ChkInitTmpCon.Visible = False        ''仮契約の初期化   ※Visible/Enableで制御 
            Me.ChkInitTmpCon.Enabled = False
            Me.chkAsrAll.Checked = False
            Me.chkDspFrm.Checked = False
            Me.cmbCpnoName.BackColor = Color.Yellow
            Me.cmbCpnoName.Text = String.Empty
            Me.Btn_DspFrm.Enabled = False
            'Req.1612 別紙B自動作成 2017/12 Str
            ChkAttachB.Checked = False
            isAttachB = False
            'Req.1612 別紙B自動作成 2017/12 End
        Else
            Me.cmbCPNO.BackColor = Color.White
            Me.tbCustomerName.BackColor = Color.Yellow
            Me.cmbPAAniv.BackColor = Color.White
            Me.cmbPALevel.BackColor = Color.White
            Me.nudExcelStartYear.BackColor = Color.White
            Me.nudExcelStartMonth.BackColor = Color.White
            Me.cmbPAAniv.Enabled = True
            Me.nudExcelStartYear.Enabled = False
            Me.nudExcelStartMonth.Enabled = False
            Me.nudContractNo.Enabled = True
            Me.DataGridView1.Columns.Clear()
            Me.DataGridView1.ReadOnly = True
            Me.DataGridView1.AllowUserToAddRows = False
            Me.cbContractDate.Enabled = True
            Me.cbPriceRequestDate.Enabled = True
            Me.btn_Menu.Enabled = True
            Call AddCmbItemsState(Me.cmbCPNO.Tag)
            Me.CmbState.BackColor = Color.Yellow
            Me.BtnCreateXls.Enabled = True
            Me.BtnCreateXlsData.Enabled = True
            Me.cmbCpnoName.BackColor = Color.White
            tbDetail = New M_CONTRACT_DETAILTable
            blnRet = wc.GetContractDetailData(Me.cmbCPNO.Text, tbDetail, strMsg)
            If blnRet = False Then
                MsgBox(strMsg, vbCritical, "ControlReflesh")
                Exit Sub
            End If
        End If

    End Sub

    ''' <summary>
    ''' 機　能：データグリッド表示
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub ShowDGV()

        Dim wc As New WebDb.WebDbCommon
        Dim blnRet As Boolean
        Dim strMsg As String = ""
        Dim dt As New M_CONTRACT_DETAILTable
        Dim strWhere As String

        Try
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW
            blnRet = wc.GetContractDetailData(cmbCPNO.Text.Trim, dt, strMsg)
            If blnRet = False Then
                MsgBox(strMsg, vbCritical, "")
                Exit Sub
            End If
            '抽出&ソート
            Dim Table As New M_CONTRACT_DETAILTable
            Dim rows() As DataRow
            If ChkDispContract.Checked = True Then
                rows = dt.Select(Nothing, "CPNO")
            Else
                strWhere = "STATUS<>'1' AND STATUS<>'2'"
                rows = dt.Select(strWhere, "CPNO")
            End If
            For Each row As DataRow In rows
                Table.ImportRow(row)
            Next

            ''ステータスのｺｰﾄﾞ⇒値に変換する。
            Call ChngTBL_MContractState(True, Table)

            ''DGVの行にセットする補足情報(Tag)を取得
            Dim DGVRowInfo As ArrayList
            DGVRowInfo = GetAddDGVRowInfo(Table)

            'カラム設定
            DataGridView1.Columns.Clear()
            Dim textColumn As New DataGridViewTextBoxColumn()
            textColumn.SortMode = DataGridViewColumnSortMode.NotSortable
            textColumn.FillWeight = 20
            textColumn.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
            textColumn.DataPropertyName = "Column1"
            textColumn.Name = "Column1"
            textColumn.HeaderText = "契約順番"
            DataGridView1.Columns.Add(textColumn)

            textColumn = New DataGridViewTextBoxColumn()
            textColumn.SortMode = DataGridViewColumnSortMode.NotSortable
            textColumn.FillWeight = 65
            textColumn.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
            textColumn.DataPropertyName = "Column2"
            textColumn.Name = "Column2"
            textColumn.HeaderText = "契約順番名"
            DataGridView1.Columns.Add(textColumn)

            textColumn = New DataGridViewTextBoxColumn()
            textColumn.SortMode = DataGridViewColumnSortMode.NotSortable
            textColumn.FillWeight = 15
            textColumn.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
            textColumn.DataPropertyName = "Column3"
            textColumn.Name = "Column3"
            textColumn.HeaderText = "ステータス"
            DataGridView1.Columns.Add(textColumn)

            '行クリア
            DataGridView1.Rows.Clear()

            '行設定
            For intCnt As Integer = 0 To (Table.Rows.Count - 1)
                DataGridView1.Rows.Add(Table.Rows(intCnt).Item(M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_NO),
                                        Table.Rows(intCnt).Item(M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_NO_NAME),
                                        Table.Rows(intCnt).Item(M_CONTRACT_DETAILTable.COLUMN_NAME_STATUS))
            Next


            ''ビューの行に補足情報(Tag)セット
            Call SetAddDGVRowInfo(DGVRowInfo)
            If 0 < Me.DataGridView1.Rows.Count Then
                Me.DataGridView1.Rows(0).Selected = False
            End If

        Catch ex As Exception
            Throw ex
            MsgBox(ex.Message, MsgBoxStyle.Critical, "ShowDGV")

        End Try

    End Sub

    ''' 機　能：M_ContractDetailのステータス列を値⇔ｺｰﾄﾞに変換する。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub ChngTBL_MContractState(ByVal isValue As Boolean, _
                                            ByRef chngTable As DataTable)

        ''引数に応じて、ｺｰﾄﾞ⇔値に変換する。
        Dim tmpValue As DataRow
        If isValue = True Then

            ''ステータス列をｺｰﾄﾞ⇒値に変換する。
            For Each tmpValue In chngTable.Rows

                Select Case tmpValue.Item(M_CONTRACT_DETAILTable.COLUMN_NAME_STATUS)
                    Case "0"
                        tmpValue.Item(M_CONTRACT_DETAILTable.COLUMN_NAME_STATUS) = "作成中"
                    Case "1"
                        tmpValue.Item(M_CONTRACT_DETAILTable.COLUMN_NAME_STATUS) = "締結済"
                    Case "2"
                        tmpValue.Item(M_CONTRACT_DETAILTable.COLUMN_NAME_STATUS) = "廃案"
                    Case "3"
                        tmpValue.Item(M_CONTRACT_DETAILTable.COLUMN_NAME_STATUS) = "仮契約"
                End Select
            Next
        Else

            ''ステータス列を値⇒ｺｰﾄﾞに変換する。
            For Each tmpValue In chngTable.Rows

                Select Case tmpValue.Item(M_CONTRACT_DETAILTable.COLUMN_NAME_STATUS)
                    Case "作成中"
                        tmpValue.Item(M_CONTRACT_DETAILTable.COLUMN_NAME_STATUS) = "0"
                    Case "締結済"
                        tmpValue.Item(M_CONTRACT_DETAILTable.COLUMN_NAME_STATUS) = "1"
                    Case "廃案"
                        tmpValue.Item(M_CONTRACT_DETAILTable.COLUMN_NAME_STATUS) = "2"
                    Case "仮契約"
                        tmpValue.Item(M_CONTRACT_DETAILTable.COLUMN_NAME_STATUS) = "3"
                End Select
            Next
        End If

    End Sub

    ''' <summary>
    ''' 機　能：データグリッドにセットする補足情報(Tag)をArrayListへ格納する。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetAddDGVRowInfo(ByRef Table As DataTable) As ArrayList

        ''初期化
        Dim rtnValue As New ArrayList
        GetAddDGVRowInfo = rtnValue

        ''Tableから補足情報を抜き出して、ArrayListへ格納
        Dim tmpRow As DataRow
        Dim insItem As AddDGVRowInfo
        For Each tmpRow In Table.Rows
            If IsDBNull(tmpRow.Item(M_CONTRACT_DETAILTable.COLUMN_NAME_PRICE_REQUEST_DATE)) = False Then
                insItem.priceRequestDate = CStr(tmpRow.Item(M_CONTRACT_DETAILTable.COLUMN_NAME_PRICE_REQUEST_DATE))
            Else
                insItem.priceRequestDate = ""
            End If
            If IsDBNull(tmpRow.Item(M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_DATE)) = False Then
                insItem.contractDate = CStr(tmpRow.Item(M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_DATE))
            Else
                insItem.contractDate = ""
            End If

            If IsDate(tmpRow.Item(M_CONTRACT_DETAILTable.COLUMN_NAME_PROPOSAL_DATE)) Then
                insItem.proposalDate = tmpRow.Item(M_CONTRACT_DETAILTable.COLUMN_NAME_PROPOSAL_DATE)
            Else
                insItem.proposalDate = Now.AddMonths(1)
            End If

            Call rtnValue.Add(insItem)
        Next

        ''戻り値
        Return rtnValue

    End Function


    ''' <summary>
    ''' 機　能：データグリッドに補足情報(Tag)をｾｯﾄする。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetAddDGVRowInfo(ByRef DGVRowInfo As ArrayList)

        ''DGVにTag情報をｾｯﾄする
        Dim Idx As Integer
        For Idx = 0 To DGVRowInfo.Count - 1
            Me.DataGridView1.Rows(Idx).Tag = DGVRowInfo(Idx)
        Next

    End Sub

    ''' <summary>
    ''' 機　能：契約詳細情報に紐づく画面項目の値をセットする。
    ''' 説　明：※Viewの選択/契約締結済_廃案の表示のﾁｪｯｸﾎﾞｯｸｽ変更ｲﾍﾞﾝﾄで使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub ShowDetailDate(ByVal RowIndex As Integer)

        Try
            ''引数= -1なら、初期化して処理終了
            If RowIndex = -1 Then
                Call ClearDetailDate()
                Exit Sub
            End If

            ''契約順番セット
            If Me.DataGridView1(0, RowIndex).Value IsNot Nothing Then
                Me.nudContractNo.Value = Me.DataGridView1(0, RowIndex).Value
            End If

            ''契約順番名セット
            If Me.DataGridView1(1, RowIndex).Value IsNot Nothing Then
                Me.tbContractNoName.Text = Me.DataGridView1(1, RowIndex).Value.ToString()
            End If

            ''Tagに価格承認日/契約締結日がセットされているか確認　
            ''※補足：ShowDGVでDGV更新途中で呼ばれてしまうため、ｴﾗｰ回避が理由でロジック追加
            If IsNothing(Me.DataGridView1.Rows(RowIndex).Tag) = False Then

                ''価格承認日
                If Me.DataGridView1.Rows(RowIndex).Tag.priceRequestDate <> "" Then
                    Me.dtpPriceRequestDate.Value = Me.DataGridView1.Rows(RowIndex).Tag.priceRequestDate
                Else
                    Me.dtpPriceRequestDate.Value = Date.Now
                End If

                ''契約締結日
                If DirectCast(Me.DataGridView1.Rows(RowIndex).Tag, AddDGVRowInfo).contractDate <> Nothing Then
                    Me.dtpContractDate.Value = Me.DataGridView1.Rows(RowIndex).Tag.contractDate
                Else
                    Me.dtpContractDate.Value = Date.Now
                End If

                ''提案開始日
                If IsDate(DirectCast(Me.DataGridView1.Rows(RowIndex).Tag, AddDGVRowInfo).proposalDate) Then
                    Dim dtWork As Date = Me.DataGridView1.Rows(RowIndex).Tag.proposalDate
                    Me.dtpSuggestDay.Value = CDate(dtWork.ToString("yyyy/MM/01"))
                Else
                    Me.dtpContractDate.Value = Now.AddMonths(1)
                End If

            End If

            ''ステータスの初期値をセット
            If Me.DataGridView1.Rows.Count > 0 Then
                Call AddCmbItemsState(Me.cmbCPNO.Tag, Me.DataGridView1.Rows(RowIndex).Cells(0).Value)
                Me.CmbState.Text = Me.DataGridView1.Rows(RowIndex).Cells(2).Value
            Else
                Call AddCmbItemsState(Me.cmbCPNO.Tag)
            End If

            If Me.isTmpContract = True And _
               (Me.nudContractNo.Value >= 800 And Me.nudContractNo.Value <= 990) Then
                Me.ChkInitTmpCon.Enabled = True
            Else
                Me.ChkInitTmpCon.Enabled = False
            End If

        Catch ex As Exception
            Throw ex

        End Try

    End Sub

    ''' <summary>
    ''' 機　能：契約詳細情報に紐づく画面項目の値をクリアする。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub ClearDetailDate()
        Me.nudContractNo.Value = 0                  ''契約順番
        Me.tbContractNoName.Text = ""               ''契約順番名
        Me.dtpPriceRequestDate.Value = Date.Now     ''価格承認日
        Me.dtpContractDate.Value = Date.Now         ''契約締結日
        Call AddCmbItemsState(Me.cmbCPNO.Tag)       ''ステータスｺﾝﾎﾞﾎﾞｯｸｽ初期化
    End Sub

    ''' <summary>
    ''' 機　能：CPNOのアイテムに値を入れる
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub AddCmbItemsCPNO()

        Dim i As Integer

        Me.cmbCPNO.Items.Clear()
        Me.cmbCpnoName.Items.Clear()
        cmbCPNO.Items.Add(String.Empty)
        cmbCpnoName.Items.Add(String.Empty)
        For i = 0 To tbBase.Rows.Count - 1
            Me.cmbCPNO.Items.Add(tbBase.Rows(i)("CPNO"))
            Me.cmbCpnoName.Items.Add(tbBase.Rows(i)("CPNO") & " " & tbBase.Rows(i)("CUST_NAME"))
        Next

    End Sub

    ''' <summary>
    ''' 機　能：画面で指定したCpnoが仮契約/正契約に応じて、ステータスの値をセット
    ''' 説　明：※画面起動時/Cpno未セットの場合、正契約のステートをセット
    ''' </summary>
    ''' <remarks></remarks
    Private Sub AddCmbItemsState(ByVal Tag As String, _
                                 Optional ByVal ContractNo As String = "0")

        ''ｺﾝﾄﾛｰﾙ初期化
        Me.CmbState.Items.Clear()

        ''ｺﾝﾎﾞﾎﾞｯｸｽにセットする値を取得 
        Dim setArray() As Object
        Select Case Tag
            Case Nothing,
                 Me.CmbCpnoTag_Contract

                ReDim setArray(2)
                setArray(0) = "作成中"
                setArray(1) = "締結済"
                setArray(2) = "廃案"

            Case Me.CmbCpnoTag_TmpContract

                ''選択した契約順番が800以上の場合、仮契約のステータスを追加
                If CInt(ContractNo) >= 800 And _
                   CInt(ContractNo) <= 989 Then
                    ReDim setArray(0)
                    setArray(0) = "仮契約"
                Else
                    ReDim setArray(2)
                    setArray(0) = "作成中"
                    setArray(1) = "締結済"
                    setArray(2) = "廃案"
                End If

        End Select

        ''ｺﾝﾎﾞﾎﾞｯｸｽのセット
        Call Me.CmbState.Items.AddRange(setArray)
        Me.CmbState.SelectedIndex = 0

    End Sub


    ''' <summary>
    ''' 機　能：必須チェック
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function EssentialCheck(ByVal isUpdate As Boolean)

        Dim isValid As Boolean = True

        If Me.tbCustomerName.Text = String.Empty Or Me.tbCustomerName.Text = "" Then
            Me.tbCustomerName.BackColor = Color.Red
            isValid = False
        Else
            Me.tbCustomerName.BackColor = Color.Yellow
        End If

        If Me.nudContractNo.Text = String.Empty Then
            Me.nudContractNo.BackColor = Color.Red
            isValid = False
        Else
            Me.nudContractNo.BackColor = Color.Yellow
        End If
        If Not isUpdate Then
            If Me.cmbCPNO.Text = String.Empty Or Me.cmbCPNO.Text = "" Then
                Me.cmbCPNO.BackColor = Color.Red
                isValid = False
            Else
                Me.cmbCPNO.BackColor = Color.Yellow
            End If

            If Me.nudExcelStartYear.Text = String.Empty Then
                Me.nudExcelStartYear.BackColor = Color.Red
                isValid = False
            Else
                Me.nudExcelStartYear.BackColor = Color.Yellow
            End If

            If Me.nudExcelStartMonth.Text = String.Empty Then
                Me.nudExcelStartMonth.BackColor = Color.Red
                isValid = False
            Else
                Me.nudExcelStartMonth.BackColor = Color.Yellow
            End If

        End If

        Return isValid

    End Function

    ''' <summary>
    ''' 機　能：契約順番名のチェック
    ''' 説　明：※Windowsのファイル名に入力できない、禁止文字のチェック
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function NGCharCheck()

        ''初期化
        NGCharCheck = True

        ''禁止文字列の取得
        Dim NGWords() As Char
        NGWords = Path.GetInvalidFileNameChars

        ''禁止文字があればエラー				
        If Me.tbCustomerName.Text.IndexOfAny(NGWords) <> -1 Then
            Me.tbCustomerName.BackColor = Color.Red
            Return False
        End If

    End Function


    ''' <summary>
    ''' 機　能：日付逆転チェック
    ''' 説　明：
    ''' </summary>
    ''' <param name="isUpdate"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function DateCheck(ByVal isUpdate As Boolean)

        Dim isValid As Boolean = True

        ''Update時もチェック
        If Date.Compare(Me.dtpEnd.Value, Me.dtpStart.Value) < 0 Then
            isValid = False
        End If

        Return isValid

    End Function

    ''' <summary>
    ''' 機　能：Excel開始年と請求開始年の関連チェック
    ''' 説　明：
    ''' </summary>
    ''' <param name="isUpdate"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ExcelDateCheck(ByVal isUpdate As Boolean)

        Dim isValid As Boolean = True
        If Not isUpdate Then
            If Year(Me.dtpStart.Value) <> CInt(nudExcelStartYear.Value) Then
                isValid = False
            End If
        End If

        Return isValid

    End Function

    ''' <summary>
    ''' 機　能：入力形式チェック
    ''' 説　明：
    ''' </summary>
    ''' <param name="isUpdate"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ValidCheck(ByVal isUpdate As Boolean)

        Dim isValid As Boolean = True

        Dim intConvert As Integer
        If Not isUpdate Then
            If Not Integer.TryParse(Me.cmbCPNO.Text, intConvert) Then
                Me.cmbCPNO.BackColor = Color.Red
                isValid = False
            Else
                Me.cmbCPNO.BackColor = Color.Yellow
            End If
        End If

        Return isValid
    End Function

    ''' <summary>
    ''' 機　能：桁数チェック
    ''' 説　明：
    ''' </summary>
    ''' <param name="isUpdate"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function LengthCheck(ByVal isUpdate As Boolean)

        Dim isValid As Boolean = True

        If Not isUpdate Then
            If 6 < Me.cmbCPNO.Text.Length Then
                Me.cmbCPNO.BackColor = Color.Red
                isValid = False
            Else
                Me.cmbCPNO.BackColor = Color.Yellow
            End If
        End If

        Return isValid

    End Function

    ''' <summary>
    ''' 機　能：CPNO存在チェック
    ''' 説　明：
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ExistCPNO(ByVal isUpdate As Boolean)

        Dim isExist As Boolean = False

        If Not isUpdate Then
            Dim i As Integer
            For i = 0 To tbBase.Rows.Count - 1
                If cmbCPNO.Text = tbBase.Rows(i)("CPNO").ToString() Then
                    isExist = True
                    Exit For
                End If
            Next
        End If

        Return isExist

    End Function

    ''' <summary>
    ''' 機　能：CPNO全角チェック
    ''' 説　明：
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function DblByteCPNO(ByVal isUpdate As Boolean)

        Dim isDblByte As Boolean = False
        Dim sjisEnc As Encoding = Encoding.GetEncoding("Shift_JIS")

        If Not isUpdate Then
            Dim i As Integer
            If cmbCPNO.Text.Length <> sjisEnc.GetByteCount(cmbCPNO.Text) Then
                isDblByte = True
            End If
        End If

        Return isDblByte

    End Function

    ''' <summary>
    ''' 機　能：桁数チェック（既定の桁数入力されているかどうか）
    ''' 説　明：
    ''' </summary>
    ''' <param name="isUpdate"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function MaxLengthCheck(ByVal isUpdate As Boolean)

        Dim isValid As Boolean = True

        If Not isUpdate Then
            If 6 <> Me.cmbCPNO.Text.Length Or Me.cmbCPNO.Text = String.Empty Then
                Me.cmbCPNO.BackColor = Color.Red
                isValid = False
            Else
                Me.cmbCPNO.BackColor = Color.Yellow
            End If
        End If

        Return isValid

    End Function

    ''' <summary>
    ''' 機　能：契約順番存在チェック
    ''' 説　明：
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ExistContractNo()

        Dim isExist As Boolean = False
        Dim i As Integer

        For i = 0 To Me.DataGridView1.Rows.Count - 1
            If Me.nudContractNo.Value.ToString() = Me.DataGridView1(0, i).Value.ToString() Then
                isExist = True
                Exit For
            End If
        Next
        Return isExist

    End Function

    ''' <summary>
    ''' 機　能：画面遷移時に共通変数に値をセットする
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetCommonVariable()

        Try
            'DBの値セット　※CPNO選択/登録時の値
            CommonVariable.CPNO = GetStackCommonVariable(enmCommonVariableIdx.CPNO)
            CommonVariable.CONTRACTNO = GetStackCommonVariable(enmCommonVariableIdx.CONTRACTNO)
            CommonVariable.CUSTOMERNAME = GetStackCommonVariable(enmCommonVariableIdx.CUSTOMERNAME)
            CommonVariable.CONTRACTNONAME = GetStackCommonVariable(enmCommonVariableIdx.CONTRACTNONAME)
            CommonVariable.PALEVEL = GetStackCommonVariable(enmCommonVariableIdx.PALEVEL)
            CommonVariable.ANNIVERSARY = GetStackCommonVariable(enmCommonVariableIdx.ANNIVERSARY)
            CommonVariable.ContractStart = GetStackCommonVariable(enmCommonVariableIdx.ContractStart)
            CommonVariable.ContractEnd = GetStackCommonVariable(enmCommonVariableIdx.ContractEnd)
            CommonVariable.PaymentStart = GetStackCommonVariable(enmCommonVariableIdx.PaymentStart)
            CommonVariable.PaymentPeriod = GetStackCommonVariable(enmCommonVariableIdx.PaymentPeriod)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        End Try
    End Sub

    ''' <summary>
    ''' 機　能：PaymentSheet書込処理
    ''' 説　明：
    ''' </summary>
    ''' <param name="StrTargetFileName"></param>
    ''' <remarks></remarks>
    Private Sub ExcelEditPaymentSheet(ByVal StrTargetFileName As String, _
                                      ByVal isServerRegist As Boolean)

        Dim strFileExcel As String = ""
        Dim xlApp As Excel.Application
        Dim xlBook As Excel.Workbook
        Dim xlOBAMASheet As Excel.Worksheet
        Dim xlListSheet As Excel.Worksheet
        Dim xlRange As Excel.Range
        Dim xlDummySheet As Excel.Worksheet

        Try

            ''OBAMAシートのセット
            xlApp = New Excel.Application
            xlApp.EnableEvents = False
            xlBook = xlApp.Workbooks.Open(StrTargetFileName)
            xlApp.EnableEvents = True
            xlOBAMASheet = xlBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)
            xlDummySheet = xlBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_DUMMYSHEET)

            ''OBAMAシートの書込
            Dim excelSTRYear As String
            excelSTRYear = Me.nudExcelStartYear.Value.ToString
            xlRange = xlOBAMASheet.Cells(4, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1)
            xlRange.Value = excelSTRYear

            Call ExcelWrite.CreatePaymentPeriod(xlOBAMASheet,
                                                    ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1),
                                                    GetStackCommonVariable(enmCommonVariableIdx.PaymentPeriod))
            Call ExcelWrite.CreatePaymentPeriod(xlDummySheet,
                                                ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1),
                                                GetStackCommonVariable(enmCommonVariableIdx.PaymentPeriod))
            'WS1シート作成
            If isServerRegist = True Then
                'サーバーにPS更新情報を登録する
                ExcelWrite.KickVBASuffixUpAct(xlApp, xlBook, ExcelWrite.VBActNMList.契約情報登録, CommonVariable.USERID, CommonVariable.USERPW)
            Else
                'サーバーにPS更新情報を登録しない
                ExcelWrite.KickVBASuffixUpAct(xlApp, xlBook, ExcelWrite.VBActNMList.空ファイル作成, CommonVariable.USERID, CommonVariable.USERPW)
            End If

            ''プロパティにファイル名を記載 str
            'Dim obj As Object
            'Dim fso As Object

            'fso = CreateObject("Scripting.FileSystemObject")
            'obj = GetObject(xlBook.Path & "\" & xlBook.Name)

            'obj.BuiltinDocumentProperties("Category") = xlBook.Name
            'obj.save()

            'obj = Nothing
            'fso = Nothing

            Dim properties As Object
            properties = xlBook.BuiltinDocumentProperties
            properties.Item("Category").value = xlBook.Name
            xlBook.Save()

            properties = Nothing
            ''プロパティにファイル名を記載 end

            ''警告メッセージの非表示
            xlApp.DisplayAlerts = False
            xlApp.EnableEvents = False
            xlBook.Save()
            xlApp.EnableEvents = True

        Catch ex As Exception
            Throw ex

        Finally

            ''エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlListSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlOBAMASheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBook) = False Then
                xlBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Sub

    ''' <summary>
    ''' 機　能：画面の値をセットする
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetDisplayValue()

        With bvItem
            .strCpNo = cmbCPNO.Text.Trim
            .strCustomerName = tbCustomerName.Text.Trim
            .strTopacsCPNO = tbTopacsCPNO.Text.Trim
            .strDtpStartDate = dtpStart.Value.ToString("yyyy/MM/dd")
            .strDtpEndDate = dtpEnd.Value.ToString("yyyy/MM/dd")
            .strPaAniv = cmbPAAniv.Text.Trim
            .strPaLevel = cmbPALevel.Text.Trim
            .strExcelStartYear = nudExcelStartYear.Value.ToString
            .strExcelStartMonth = nudExcelStartMonth.Value.ToString
            .strContractNo = nudContractNo.Value.ToString
            .strContractName = tbContractNoName.Text.Trim
            .strPriceRequestDate = dtpPriceRequestDate.Checked
            .blnPriceRequestDate = cbPriceRequestDate.Checked
            .strContractDate = dtpContractDate.Value.ToString("yyyy/MM/dd")
            .blnContractDate = cbContractDate.Checked
            .strDeploymentPeriod = nudDeploymentPeriod.Value
        End With

    End Sub

    ''' <summary>
    ''' 機　能：画面の変更前の値と現在の値を比較する
    ''' 説　明：True:一致　False:不一致
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function isDisplayValue() As Boolean

        isDisplayValue = False

        With bvItem
            If .strCpNo = cmbCPNO.Text.Trim And _
                .strCustomerName = tbCustomerName.Text.Trim And _
                .strTopacsCPNO = tbTopacsCPNO.Text.Trim And _
                .strDtpStartDate = dtpStart.Value.ToString("yyyy/MM/dd") And _
                .strDtpEndDate = dtpEnd.Value.ToString("yyyy/MM/dd") And _
                .strPaAniv = cmbPAAniv.Text.Trim And _
                .strPaLevel = cmbPALevel.Text.Trim And _
                .strExcelStartYear = nudExcelStartYear.Value.ToString And _
                .strExcelStartMonth = nudExcelStartMonth.Value.ToString And _
                .strContractNo = nudContractNo.Value.ToString And _
                .strContractName = tbContractNoName.Text.Trim And _
                .strPriceRequestDate = dtpPriceRequestDate.Checked And _
                .blnPriceRequestDate = cbPriceRequestDate.Checked And _
                .strContractDate = dtpContractDate.Value.ToString("yyyy/MM/dd") And _
                .blnContractDate = cbContractDate.Checked And _
                .strDeploymentPeriod = nudDeploymentPeriod.Value Then
                isDisplayValue = True
            End If
        End With

    End Function

    ''' <summary>
    ''' 機　能：ｺﾝﾎﾞﾎﾞｯｸｽのステータスの値をコード値に変換する。
    ''' 説　明：※登録処理時に使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Function chngCmbStateValueToCode(ByRef ValueNM As String) As String

        ''初期化
        Dim rtnValue As String = ""
        chngCmbStateValueToCode = rtnValue

        ''名称⇒コードへ変換
        Select Case ValueNM
            Case "作成中"
                rtnValue = "0"
            Case "締結済"
                rtnValue = "1"
            Case "廃案"
                rtnValue = "2"
            Case "仮契約"
                rtnValue = "3"
        End Select

        ''戻り値
        Return rtnValue

    End Function


    ''' <summary>
    ''' 機　能：PS/Detailﾌｧｲﾙをﾃﾝﾌﾟﾚﾌｧｲﾙからｺﾋﾟｰ/ﾘﾈｰﾑで作成
    ''' 説　明：※登録/更新ボタン、空ファイル作成ﾎﾞﾀﾝで使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateXlsFile(ByVal Cpno As String, _
                                   ByVal ContractNo As Integer, _
                                   ByVal isTmpContract As Boolean, _
                                   Optional ByVal isServerRegist As Boolean = True) As String
        ''初期化
        Dim rtnMsg As String = ""
        CreateXlsFile = rtnMsg

        ''変数の宣言
        Dim ofm As New OioFileManage    ''ﾌｧｲﾙ操作の共通クラス
        Dim createTime As String        ''ファイルの作成日時
        Dim outDir As String            ''出力先フォルダ
        Dim outPSPath As String         ''PSﾊﾟｽ
        Dim outPSFile As String         ''PSファイル名        

        Try

            ''フォルダの作成
            ofm.CreateFrm_ContractInfoCPNOFolder(Cpno, ContractNo, isTmpContract)

            ''出力先ﾊﾟｽを取得
            createTime = Now.ToString("yyyyMMdd_HHmmss")
            outDir = ofm.CreateLocalCPNOFolder(Cpno, ContractNo)
            outPSFile = ofm.GetNewPaymentLineExcelFileNm(Cpno, ContractNo, createTime)
            outPSPath = outDir & "\" & outPSFile

            ''ﾃﾝﾌﾟﾚﾌｧｲﾙをコピー/リネーム
            System.Environment.CurrentDirectory = Application.StartupPath
            Call File.Copy(Me.samplePath + Me.samplePSFile, outPSPath, True)

            'PaymentSheet書込処理
            Call ExcelEditPaymentSheet(outPSPath, isServerRegist)

            ''完了ﾒｯｾｰｼﾞの作成
            rtnMsg = FileReader.GetMessage("MSG_0073") + vbCrLf + vbCrLf + _
                     FileReader.GetMessage("MSG_0074") + outDir + vbCrLf + _
                     FileReader.GetMessage("MSG_0075") + outPSFile

            Return rtnMsg

        Catch ex As Exception
            Throw ex

        End Try

    End Function


    ''' <summary>
    '''概  要：ExcelフォルダにPSファイルと詳細ファイルが存在するかどうか判定する。
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function ChkExistsExcelFile(ByVal CPNO As String, _
                                        ByVal ContractNo As Integer) As Boolean

        ''初期化
        ChkExistsExcelFile = True

        ''Payment/Detailファイル名を取得する。
        Dim ofm As New OioFileManage
        Dim PSPath As String
        PSPath = ofm.GetLocalCPNOFolder(CPNO, ContractNo) & _
                 ofm.GetPaymentLineExcelFileNm(CPNO, ContractNo)

        ''ファイルの存在ﾁｪｯｸ
        If File.Exists(PSPath) = False Then
            ChkExistsExcelFile = False
        End If

    End Function

    ''' <summary>
    ''' 機能：入力値チェック
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckInputData() As Boolean

        CheckInputData = False

        Try
            '入力チェック
            'CPNOの必須チェック
            If Trim(Me.cmbCPNO.Text) = "" Then
                Me.cmbCPNO.BackColor = Color.Red
                MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0052"), Me.Text)
                Exit Function
            End If

            'CPNOの桁数
            If Not MaxLengthCheck(Me.isUpdate) Then
                MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0272"), Me.Text)
                Exit Function
            End If

            ''必須項目チェック
            If Not EssentialCheck(Me.isUpdate) Then
                MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0052"), Me.Text)
                Exit Function
            End If

            ''お客様名のチェック禁止文字チェック
            If Not ExcelWrite.ChkNGCharInFileNM(Me.tbCustomerName.Text) Then
                Me.tbCustomerName.BackColor = Color.Red
                MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0327"), Me.Text)
                Exit Function
            End If
            ''ｻｰﾊﾞｰへの送信Bytesﾁｪｯｸ
            If Not ExcelWrite.ChkByteByEncode(Me.tbCustomerName.Text, "UTF-8", 256) Then
                Me.tbCustomerName.BackColor = Color.Red
                MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0412"), Me.Text)
                Exit Function
            End If

            ''日付逆転チェック
            If Not DateCheck(Me.isUpdate) Then
                MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0053"), Me.Text)
                Exit Function
            End If

            ''Excel開始年のチェック
            If Not ExcelDateCheck(Me.isUpdate) Then
                MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0266"), Me.Text)
                Exit Function
            End If

            If Not LengthCheck(Me.isUpdate) Then
                MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0054"), Me.Text)
                Exit Function
            End If

            If ExistCPNO(Me.isUpdate) Then
                MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0055"), Me.Text)
                Exit Function
            End If

            If DblByteCPNO(Me.isUpdate) Then
                MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0056"), Me.Text)
                Exit Function
            End If

            ''締結済/廃案非表示の場合、Updateしない。
            If Me.ChkDispContract.Checked = False Then
                Dim filter As New StringBuilder
                filter.Append(M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_NO)
                filter.Append(CommonConstant.SQL_STR_EQUAL)
                filter.Append(StringEdit.EncloseSingleQuotation(Me.nudContractNo.Value))
                filter.Append(CommonConstant.SQL_STR_AND)
                filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                filter.Append(M_CONTRACT_DETAILTable.COLUMN_NAME_STATUS)
                filter.Append(CommonConstant.SQL_STR_EQUAL)
                filter.Append(StringEdit.EncloseSingleQuotation("1"))
                filter.Append(CommonConstant.SQL_STR_OR)
                filter.Append(M_CONTRACT_DETAILTable.COLUMN_NAME_STATUS)
                filter.Append(CommonConstant.SQL_STR_EQUAL)
                filter.Append(StringEdit.EncloseSingleQuotation("2"))
                filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                If Not (tbDetail Is Nothing) Then
                    If tbDetail.Select(filter.ToString).Length <> 0 Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0057"), Me.Text)
                        Exit Function
                    End If
                End If
            End If

            CheckInputData = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "CheckInputData")

        End Try

    End Function

    '1729 str

    ''' <summary>
    ''' 機能：特殊文字の変換
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function UpdateVal() As Boolean

        UpdateVal = False

        Try


            ''お客様名の特殊文字変換
            Me.tbCustomerName.Text = Replace(Me.tbCustomerName.Text, ChrW(&H2212), "－")
            Me.tbCustomerName.Text = Replace(Me.tbCustomerName.Text, ChrW(&H2015), "－")
            Me.tbCustomerName.Text = Replace(Me.tbCustomerName.Text, ChrW(&H2014), "－")
            Me.tbCustomerName.Text = Replace(Me.tbCustomerName.Text, ChrW(&H301C), "～")

            ''契約順番名の特殊文字変換
            Me.tbContractNoName.Text = Replace(Me.tbContractNoName.Text, ChrW(&H2212), "－")
            Me.tbContractNoName.Text = Replace(Me.tbContractNoName.Text, ChrW(&H2015), "－")
            Me.tbContractNoName.Text = Replace(Me.tbContractNoName.Text, ChrW(&H2014), "－")
            Me.tbContractNoName.Text = Replace(Me.tbContractNoName.Text, ChrW(&H301C), "～")

            UpdateVal = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "UpdateVal")

        End Try

    End Function

    '1729 end

    ''' <summary>
    ''' 機能：登録処理
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function RegistContract() As Boolean

        Dim wc As New WebDb.WebDbCommon
        Dim blnRet As Boolean
        Dim strMsg As String = ""
        Dim dtBase As New M_CONTRACT_BASETable
        Dim dtDetail As New M_CONTRACT_DETAILTable
        Dim strCpno As String
        Dim strContractNo As String
        Dim dtBaseResponse As New M_CONTRACT_BASETable
        Dim dtDetailResponse As New M_CONTRACT_DETAILTable
        Dim blnPlanCreate As Boolean = False

        RegistContract = False

        Try
            '----------------------------------------
            '画面の値をDataTableにセット
            '----------------------------------------
            blnRet = SetDispValueToDataTable(dtBase, dtDetail)
            If blnRet = False Then
                Exit Function
            End If

            '----------------------------------------
            '認証設定
            '----------------------------------------
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW

            '----------------------------------------
            '契約基本情報登録処理
            '----------------------------------------
            '契約基本情報が登録されているかチェック
            strCpno = cmbCPNO.Text.Trim
            blnRet = wc.GetContractBaseData(strCpno, dtBaseResponse, strMsg)
            If blnRet = False Then
                MsgBox(strMsg, MsgBoxStyle.Critical, "RegistContract")
                Exit Function
            End If
            If dtBaseResponse.Rows.Count > 0 Then
                '0件以外の場合、更新処理
                dtBase.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_CONTRACT_PATERN) = ExcelWrite.changeDBNullToString(dtBaseResponse.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_CONTRACT_PATERN))
                blnRet = wc.UpdateContractBaseData(dtBase, strMsg)
            Else
                '0件の場合、新規処理
                blnRet = wc.InsertContractBaseData(dtBase, strMsg)
                blnPlanCreate = True
            End If
            If blnRet = False Then
                MsgBox(strMsg, MsgBoxStyle.Critical, "RegistContract")
                Exit Function
            End If
            If blnPlanCreate = True Then
                '案件情報に(未定義)を設定
                Dim dtPlan As New M_PLANTable
                blnRet = SetDispValueToDataTablePlan(dtPlan)
                If blnRet = False Then
                    Exit Function
                End If
                blnRet = wc.InsertPlanData(dtPlan, strMsg)
                If blnRet = False Then
                    MsgBox(strMsg, MsgBoxStyle.Critical, "RegistContract")
                    Exit Function
                End If
            End If

            '----------------------------------------
            '契約詳細情報登録処理
            '----------------------------------------
            '契約詳細情報が登録されているかチェック
            strContractNo = nudContractNo.Value.ToString()
            blnRet = wc.GetContractDetailData(strCpno, strContractNo, dtDetailResponse, strMsg)
            If blnRet = False Then
                MsgBox(strMsg, MsgBoxStyle.Critical, "RegistContract")
                Exit Function
            End If
            If dtDetailResponse.Rows.Count > 0 Then
                '0件以外の場合、更新処理
                Me.isNewRegist = False
                blnRet = wc.UpdateContractDetailData(dtDetail, strMsg)
            Else
                '0件の場合、新規処理
                blnRet = wc.InsertContractDetailData(dtDetail, strMsg)
            End If
            If blnRet = False Then
                MsgBox(strMsg, MsgBoxStyle.Critical, "RegistContract")
                Exit Function
            End If

            RegistContract = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "RegistContract")

        End Try

    End Function

    ''' <summary>
    ''' 機能：画面の値をDataTableにセット
    ''' </summary>
    ''' <param name="dtBase">契約基本情報データ</param>
    ''' <param name="dtDetail">契約詳細データ</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function SetDispValueToDataTable(ByRef dtBase As M_CONTRACT_BASETable, ByRef dtDetail As M_CONTRACT_DETAILTable) As Boolean

        Dim row As DataRow
        Dim strWork As String

        SetDispValueToDataTable = False

        Try
            '----------------------------------------
            '契約基本情報セット
            '----------------------------------------
            row = dtBase.NewRow
            row(M_CONTRACT_BASETable.COLUMN_NAME_CPNO) = cmbCPNO.Text.Trim
            row(M_CONTRACT_BASETable.COLUMN_NAME_CUST_NAME) = tbCustomerName.Text.Trim
            row(M_CONTRACT_BASETable.COLUMN_NAME_TOPACS_CPNO) = tbTopacsCPNO.Text.Trim
            row(M_CONTRACT_BASETable.COLUMN_NAME_START_YEAR) = dtpStart.Value.ToString("yyyy")
            row(M_CONTRACT_BASETable.COLUMN_NAME_START_MONTH) = dtpStart.Value.ToString("MM")
            row(M_CONTRACT_BASETable.COLUMN_NAME_END_YEAR) = dtpEnd.Value.ToString("yyyy")
            row(M_CONTRACT_BASETable.COLUMN_NAME_END_MONTH) = dtpEnd.Value.ToString("MM")

            Dim strDP As String() = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K"}
            Dim strPA As String() = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C"}

            If cmbPAAniv.Text = "" Then
                row(M_CONTRACT_BASETable.COLUMN_NAME_PA_ANV_DATE) = strDP(nudDeploymentPeriod.Value)
            Else
                row(M_CONTRACT_BASETable.COLUMN_NAME_PA_ANV_DATE) = strDP(nudDeploymentPeriod.Value) & _
                                                                    strPA(CInt(cmbPAAniv.Text))
            End If

            row(M_CONTRACT_BASETable.COLUMN_NAME_PA_LEVEL) = cmbPALevel.Text.Trim
            row(M_CONTRACT_BASETable.COLUMN_NAME_EXCEL_START) = nudExcelStartYear.Value.ToString() & EXCEL_START_MONTH
            '一括処理表示(0:表示　　1:非表示)
            If chkAsrAll.Checked = True Then
                strWork = "0"
            Else
                strWork = "1"
            End If
            row(M_CONTRACT_BASETable.COLUMN_NAME_DISP_ASR_FLG) = strWork
            '統合処理方法(00：無し、01：JRI)
            If chkDspFrm.Checked = True Then
                strWork = "01"
            Else
                strWork = "00"
            End If
            row(M_CONTRACT_BASETable.COLUMN_NAME_UNIFICATION_PATERN) = strWork
            dtBase.Rows.Add(row)

            '----------------------------------------
            '契約詳細情報セット
            '----------------------------------------
            row = dtDetail.NewRow
            row(M_CONTRACT_DETAILTable.COLUMN_NAME_CPNO) = cmbCPNO.Text.Trim
            row(M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_NO) = nudContractNo.Value.ToString()
            row(M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_NO_NAME) = tbContractNoName.Text.Trim
            row(M_CONTRACT_DETAILTable.COLUMN_NAME_STATUS) = chngCmbStateValueToCode(CmbState.Text)
            row(M_CONTRACT_DETAILTable.COLUMN_NAME_PROPOSAL_DATE) = dtpSuggestDay.Value.ToString("yyyy/MM/01")
            row(M_CONTRACT_DETAILTable.COLUMN_NAME_PA_LEVEL) = ExcelWrite.changeDBNullToString(cmbPALevel.SelectedItem)
            If cbPriceRequestDate.Checked = True Then
                row(M_CONTRACT_DETAILTable.COLUMN_NAME_PRICE_REQUEST_DATE) = dtpPriceRequestDate.Value.ToString
            End If
            If cbContractDate.Checked = True Then
                row(M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_DATE) = dtpContractDate.Value.ToString
            End If
            dtDetail.Rows.Add(row)

            SetDispValueToDataTable = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "SetDispValueToDataTable")

        End Try

    End Function

    ''' <summary>
    ''' 機能：新規案件情報テーブルに(未定)データを設定
    ''' </summary>
    ''' <param name="dtPlan">案件情報データ</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function SetDispValueToDataTablePlan(ByRef dtPlan As M_PLANTable) As Boolean

        Dim row As DataRow

        SetDispValueToDataTablePlan = False

        Try
            row = dtPlan.NewRow
            row(M_PLANTable.COLUMN_NAME_CPNO) = cmbCPNO.Text.Trim
            row(M_PLANTable.COLUMN_NAME_PLAN_NAME) = "(未定義)"
            row(M_PLANTable.COLUMN_NAME_LEVEL1) = "00"
            row(M_PLANTable.COLUMN_NAME_LEVEL2) = "00"
            row(M_PLANTable.COLUMN_NAME_LEVEL3) = "00"
            row(M_PLANTable.COLUMN_NAME_LEVEL4) = "00"
            row(M_PLANTable.COLUMN_NAME_PARENT_NO) = ""
            row(M_PLANTable.COLUMN_NAME_PRINT_F) = "0"
            row(M_PLANTable.COLUMN_NAME_SORT) = "0"
            row(M_PLANTable.COLUMN_NAME_DISP) = "0"
            row(M_PLANTable.COLUMN_NAME_ROW_NO_START) = "0"
            row(M_PLANTable.COLUMN_NAME_ROW_NO_MAX) = "0"
            dtPlan.Rows.Add(row)

            SetDispValueToDataTablePlan = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "SetDispValueToDataTablePlan")

        End Try

    End Function

    ''' <summary>
    ''' 機能：新旧ファイル名チェック
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckPsFileName() As Boolean

        Dim ofm As New OioFileManage
        Dim strCpno As String = cmbCPNO.Text.Trim
        Dim intContractNo As Integer = nudContractNo.Value
        Dim strNewFile As String
        Dim strOldFile As String
        Dim blnRet As Boolean
        Dim strPath As String

        CheckPsFileName = False

        Try
            'フォルダ存在チェック
            strPath = ofm.GetLocalCPNOFolder(strCpno, intContractNo)
            If Directory.Exists(strPath) = True Then
                '「CPNO_契約順番_Payment_YYYYMMDD_HHMMSS.xls」の形式でファイル名を検索
                strNewFile = strPath & ofm.GetPaymentLineExcelFileNm(strCpno, intContractNo)
                blnRet = File.Exists(strNewFile)
                If blnRet = False Then
                    'ファイルが存在しない場合、旧ファイル名で検索
                    '「PaymentLine999999CNO99999_YYYYMMDD_HHMMSS.xls」
                    strOldFile = ofm.GetLocalCPNOFolder(strCpno, intContractNo) & ofm.GetPaymentLineExcelOldFileNm(strCpno, intContractNo)
                    blnRet = File.Exists(strOldFile)
                    If blnRet = True Then
                        '旧ファイル名で存在する場合、コピーして新ファイル名にリネーム
                        strNewFile = strNewFile & ofm.GetNewPaymentLineExcelFileNm(strCpno, intContractNo, Now.ToString("yyyyMMdd_HHmmss"))
                        File.Copy(strOldFile, strNewFile)
                    End If
                End If
            End If

            CheckPsFileName = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "CheckPsFileName")
        End Try

    End Function

    Private Function IsExitContractNo() As Boolean

        ''初期値
        IsExitContractNo = True

        If DataGridView1.RowCount = 0 Then
            Exit Function
        End If

        If CmbState.Text <> "作成中" And CmbState.Text <> "仮契約" Then
            Exit Function
        End If

        IsExitContractNo = False

    End Function

    ''CPNOがTBLに登録済みかどうか判定
    Private Function ExistsCPNO() As Boolean

        ''初期値
        ExistsCPNO = False

        ''新規登録のみチェック
        If Me.isUpdate = True Then
            Exit Function
        End If

        ''CPNO登録済チェック
        Dim filter As New StringBuilder
        filter.Append(M_CONTRACT_BASETable.COLUMN_NAME_CPNO)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(Me.cmbCpnoName.Text))
        If tbBase.Select(filter.ToString).Length <> 0 Then
            ExistsCPNO = True
        End If

    End Function

    ''' <summary>
    ''' 機　能：CPNO選択時の値を取得する。
    ''' 説　明：※CommonVariableのFormatを返す。
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetStackCommonVariable(ByVal colIdx As enmCommonVariableIdx) As Object

        '呼出条件を満たしているかどうか？
        If Me.isUpdate = False Then
            Throw New Exception("CPNO未入力の場合、「GetStackCommonVariable」は呼び出せません。")
        End If

        'CommonVariableセット用にフォーマット変換
        Dim aryPayPeriod As String() = {"", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K"}
        Dim aryAnniversary As String() = {"", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C"}
        Dim row() As DataRow = tbBase.Select("CPNO = '" & Me.cmbCPNO.SelectedItem.ToString() & "'")
        Select Case colIdx
            Case enmCommonVariableIdx.CPNO
                Return Me.cmbCPNO.Text
            Case enmCommonVariableIdx.CUSTOMERNAME
                Return CStr(row(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_CUST_NAME))
            Case enmCommonVariableIdx.CONTRACTNO
                Return CInt(Me.DataGridView1(0, Me.DataGridView1.CurrentRow.Index).Value)
            Case enmCommonVariableIdx.CONTRACTNONAME
                Return CStr(Me.DataGridView1(1, Me.DataGridView1.CurrentRow.Index).Value)
            Case enmCommonVariableIdx.PALEVEL
                Return CStr(row(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_PA_LEVEL))
            Case enmCommonVariableIdx.ANNIVERSARY
                Return ChgAnniversary(Mid(row(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_PA_ANV_DATE), 2, 1))
            Case enmCommonVariableIdx.ContractStart
                Return Date.ParseExact(row(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_START_YEAR).ToString + row(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_START_MONTH).ToString().PadLeft(2, "0"), "yyyyMM", Nothing)
            Case enmCommonVariableIdx.ContractEnd
                Return Date.ParseExact(row(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_END_YEAR).ToString() + row(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_END_MONTH).ToString().PadLeft(2, "0"), "yyyyMM", Nothing)
            Case enmCommonVariableIdx.PaymentStart
                Return CDate(row(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_EXCEL_START).ToString().Substring(0, 4) & "/1/1")
            Case enmCommonVariableIdx.PaymentPeriod
                Return Array.IndexOf(aryPayPeriod, row(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_PA_ANV_DATE).SubString(0, 1))
            Case Else
                Throw New Exception("引数の値が不正です。「GetStackCommonVariable」は呼び出せません。")
        End Select
    End Function

    ''' <summary>
    ''' 機　能：DBのAnniversaryをClient画面用の値に変換する。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function ChgAnniversary(ByVal dbAnniversary As String) As String
        Select Case dbAnniversary
            Case ""
                Return ""
            Case "1"
                Return "1"
            Case "2"
                Return "2"
            Case "3"
                Return "3"
            Case "4"
                Return "4"
            Case "5"
                Return "5"
            Case "6"
                Return "6"
            Case "7"
                Return "7"
            Case "8"
                Return "8"
            Case "9"
                Return "9"
            Case "A"
                Return "10"
            Case "B"
                Return "11"
            Case "C"
                Return "12"
        End Select
    End Function

    ''' <summary>
    ''' 機能：インポート完了メッセージ表示
    ''' </summary>
    ''' <param name="strButtonName"></param>
    ''' <param name="importCount"></param>
    ''' <param name="importErrCount"></param>
    ''' <param name="usedFilePath"></param>
    ''' <remarks></remarks>
    Private Sub CompleteImportMessage(ByVal strButtonName As String,
                                      ByVal importCount As ImportCsv.ImportCount,
                                      ByVal importErrCount As ImportCsv.ImportErrCount,
                                      ByVal usedFilePath As ImportCsv.usedFilePath)

        Dim MsgStr As String
        Dim strMsgCd As String
        Dim intBoxStyle As Integer

        Try
            If (importErrCount.MDBCount = 0 And
                importErrCount.MDBDetailCount = 0) Then
                '---------------------------------------------------
                'MDB正常
                '---------------------------------------------------
                '締結済MDBの処理	
                If importCount.MDBCount <> -1 Then
                    MsgStr = MsgStr & "契約済みMDBPaymentデータ" & vbCrLf _
                                    & "  件数      :" & importCount.MDBCount.ToString("###,###,###,##0") & "件" & vbCrLf
                End If
                '締結済個別詳細の処理	
                If importCount.MDBDetailCount <> -1 Then
                    MsgStr = MsgStr & "契約済みMDB詳細データ" & vbCrLf _
                                    & "  件数      :" & importCount.MDBDetailCount.ToString("###,###,###,##0") & "件" & vbCrLf

                End If

                intBoxStyle = MsgBoxStyle.Information

            Else
                '---------------------------------------------------
                'エラーのファイルを表示
                '---------------------------------------------------
                MsgStr = MsgStr & "■以下のファイルに、取込みできないデータが存在します。" & vbCrLf
                MsgStr = MsgStr & "  ImportErrorLogﾌｧｲﾙを確認してください。" & vbCrLf & vbCrLf

                If importErrCount.MDBCount = -1 Then
                    MsgStr = MsgStr & "  契約締結済みMDBPaymentデータ" & vbCrLf
                End If

                If importErrCount.PSCount > 0 Then
                    MsgStr = MsgStr & "  Paymentファイル" & vbCrLf
                End If

                If importErrCount.MDBDetailCount = -1 Then
                    MsgStr = MsgStr & "  契約締結済みMDB詳細情報データ" & vbCrLf
                End If

                If importErrCount.DetailCount > 0 Then
                    MsgStr = MsgStr & "  個別詳細ファイル" & vbCrLf
                End If

                intBoxStyle = MsgBoxStyle.Critical
            End If

            'メッセージ表示
            MsgBox(MsgStr, intBoxStyle, Me.Text)

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "CompleteMessage")
        End Try

    End Sub

    ''' <summary>
    ''' 機　能：ファイルの処理開始/終了メッセージを表示
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub OutImpTitleErrLog(ByRef OutErr As OutputErrorList, _
                                  ByVal Msg As String)

        OutErr.OutImportErrorList("=========================================", "Import")
        OutErr.OutImportErrorList(Msg, "Import")
        OutErr.OutImportErrorList("=========================================", "Import")

    End Sub

    ''' <summary>
    ''' 機　能：処理中ﾀﾞｲｱﾙﾛｸﾞの初期設定
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetInitWaitDialog(ByRef waitDialog As Frm_WaitDialog, _
                                  ByVal startMsg As String)

        Const STR_CREATING_IN As String = "インポート中・・「Ctl+Cﾎﾞﾀﾝ」を押さないでください。"

        waitDialog.Text = STR_CREATING_IN
        waitDialog.lbl_Message.Text = startMsg
        waitDialog.Pic_Excel.Visible = True
        waitDialog.ProgressMin = 0
        waitDialog.ProgressMax = 7
        waitDialog.ProgressStep = 1
        waitDialog.ProgressValue = 0
        waitDialog.Show()
        waitDialog.Refresh()

    End Sub


    ''' <summary>
    ''' 機　能：処理中ﾀﾞｲｱﾙﾛｸﾞのメッセージ変更
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetMsgWaitDialog(ByRef waitDialog As Frm_WaitDialog, _
                                 ByVal setMsg As String)

        waitDialog.lbl_Message.Text = setMsg
        waitDialog.Show()
        waitDialog.Refresh()

    End Sub

    ''' <summary>
    ''' 機　能：処理中ﾀﾞｲｱﾙﾛｸﾞのClose
    ''' 説　明：※処理中の画面制御が増えたときのため(マウスポインタの砂時計等)、一応関数化する。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub CloseWaitDialog(ByRef waitDialog As Frm_WaitDialog)

        waitDialog.Close()

    End Sub

    'Req.1612 別紙B自動作成 2017/12 Str
    ''' <summary>
    ''' Codeテーブル取得
    ''' </summary>
    ''' <param name="CPNO">CPNO</param>
    ''' <remarks></remarks>
    Private Function GetCode(ByVal CPNO As String) As Boolean
        Dim mdc As New MasterMdbControl
        Dim dbCon As OleDbConnection
        Dim odc As New OleDbCode
        Dim dbTable As DataTable
        Dim ii As Integer
        'Req.1612 別紙B自動作成 2018/03 Str
        Dim wc As New WebDb.WebDbCommon
        Dim dt As New M_CONTRACT_BASETable
        Dim wRet As Boolean
        Dim wMsg As String
        'Req.1612 別紙B自動作成 2018/03 End

        GetCode = False

        Try
            'Req.1612 別紙B自動作成 2018/03 Str
            '認証設定
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW

            wRet = wc.GetContractBaseData(CPNO, dt, wMsg)
            If wRet = False Then
                Throw New Exception(wMsg)
                Exit Function
            End If

            If dt.Rows.Count > 0 Then
                If Mid(dt.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_CONTRACT_PATERN).ToString, 1, 1) = "1" Then
                    GetCode = True
                End If
            End If

            ''認証設定
            'dbCon = mdc.GetOleServerDBConnection(CommonVariable.MdbPW)

            'If CPNO = "" Then
            '    Exit Function
            'End If

            ''CODEテーブル取得
            'dbTable = odc.SelectDataTable(dbCon, PRCPNO)

            ''取得内容チェック
            'If dbTable.Rows.Count > 0 Then
            '    For ii = 0 To dbTable.Rows.Count - 1
            '        If dbTable.Rows(ii).Item("ItemValue") = CPNO Then
            '            '当該CPNOの登録あり
            '            GetCode = True
            '            Exit Function
            '        End If
            '    Next
            'End If
            'Req.1612 別紙B自動作成 2018/03 End

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "GetCode")

        Finally
            'Req.1612 別紙B自動作成 2018/03 Str
            'dbCon.Close()
            'Req.1612 別紙B自動作成 2018/03 End

        End Try

    End Function

    ''' <summary>
    ''' Codeテーブル更新
    ''' </summary>
    ''' <param name="CPNO">CPNO</param>
    ''' <remarks></remarks>
    Private Function UpdateCode(ByVal CPNO As String) As Boolean
        Dim mdc As New MasterMdbControl
        Dim dbCon As OleDbConnection
        Dim sdbCon As OleDbConnection
        Dim dbTrn As OleDbTransaction
        Dim sdbTrn As OleDbTransaction
        Dim odc As New OleDbCode
        Dim dbTable As DataTable
        Dim ii As Integer
        Dim MaxNo As Long = 1
        Dim wNo As Long = 1
        Dim wRet As Boolean
        Dim fFind As Boolean = False
        'Req.1612：別紙Bの自動分割 2018/03 Str
        Dim wc As New WebDb.WebDbCommon
        Dim wMsg As String
        Dim wStr As String
        Dim dt As New M_CONTRACT_BASETable
        'Req.1612：別紙Bの自動分割 2018/03 End

        UpdateCode = False

        Try
            'Req.1612：別紙Bの自動分割 2018/03 Str
            '認証設定
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW

            '検索
            wRet = wc.GetContractBaseData(CPNO, dt, wMsg)
            If wRet = False Then
                Throw New Exception(wMsg)
                Exit Function
            End If

            If dt.Rows.Count > 0 Then
                '現在の２桁目取得
                wStr = Mid(dt.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_CONTRACT_PATERN).ToString, 2, 1)
                If wStr = "" Then
                    wStr = "0"
                End If
                If ChkAttachB.Checked = True Then
                    dt.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_CONTRACT_PATERN) = "1" & wStr
                Else
                    dt.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_CONTRACT_PATERN) = "0" & wStr
                End If

                '更新
                wRet = wc.UpdateContractBaseData(dt, wMsg)
                If wRet = False Then
                    Throw New Exception(wMsg)
                    Exit Function
                End If
            End If

            ''認証設定
            'dbCon = mdc.GetOleDBConnection(CommonVariable.MdbPW)
            'sdbCon = mdc.GetOleServerDBConnection(CommonVariable.MdbPW)

            ''CODEテーブル取得
            'dbTable = odc.SelectDataTable(sdbCon, PRCPNO, CodeTable.COLUMN_NAME_ORDERNO)

            ''取得内容チェック
            'If dbTable.Rows.Count > 0 Then
            '    For ii = 1 To dbTable.Rows.Count
            '        If dbTable.Rows(ii - 1).Item("ItemValue") = CPNO Then
            '            '当該CPNOの登録あり
            '            UpdateCode = True
            '            isAttachB = True
            '            Exit Function
            '        End If

            '        If Val(dbTable.Rows(ii - 1).Item("ItemCode")) > MaxNo Then
            '            '最大番号取得
            '            MaxNo = Val(dbTable.Rows(ii - 1).Item("ItemCode"))
            '        End If

            '        'ループNoとOrderNo(順取り出し)が異なっている　→空き番号
            '        If Val(dbTable.Rows(ii - 1).Item("ItemCode")) <> ii Then
            '            '空き番号取得
            '            wNo = ii
            '            fFind = True
            '            Exit For
            '        End If
            '    Next

            '    If fFind = False Then
            '        '空き番号が無い場合は最大番号
            '        wNo = MaxNo + 1
            '    End If

            '    'CODEテーブルに追加
            '    wRet = odc.InsertData(dbCon, dbTrn, PRCPNO, wNo, wNo, CPNO)

            '    wRet = odc.InsertData(sdbCon, sdbTrn, PRCPNO, wNo, wNo, CPNO)

            'Else
            '    'CODEテーブルに新規追加
            '    wRet = odc.InsertData(dbCon, dbTrn, PRCPNO, "1", "1", CPNO)

            '    wRet = odc.InsertData(sdbCon, sdbTrn, PRCPNO, "1", "1", CPNO)
            'End If
            'Req.1612：別紙Bの自動分割 2018/03 End

            UpdateCode = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "UpdateCode")

        Finally
            'Req.1612：別紙Bの自動分割 2018/03 Str
            'dbCon.Close()
            'sdbCon.Close()
            'Req.1612：別紙Bの自動分割 2018/03 End

        End Try

    End Function

    'Req.1612：別紙Bの自動分割 2018/03 Str
    ' ''' <summary>
    ' ''' Codeテーブル削除
    ' ''' </summary>
    ' ''' <param name="CPNO">CPNO</param>
    ' ''' <remarks></remarks>
    'Private Function DeleteCode(ByVal CPNO As String) As Boolean
    '    Dim mdc As New MasterMdbControl
    '    Dim sdbCon As OleDbConnection
    '    Dim dbCon As OleDbConnection
    '    Dim dbTrn As OleDbTransaction
    '    Dim sdbTrn As OleDbTransaction
    '    Dim odc As New OleDbCode

    '    DeleteCode = False

    '    Try
    '        '認証設定
    '        dbCon = mdc.GetOleDBConnection(CommonVariable.MdbPW)
    '        sdbCon = mdc.GetOleServerDBConnection(CommonVariable.MdbPW)

    '        'CODEレコード削除
    '        odc.DeleteRecord(dbCon, _
    '                         dbTrn, _
    '                         PRCPNO, _
    '                         CPNO)
    '        odc.DeleteRecord(sdbCon, _
    '                         sdbTrn, _
    '                         PRCPNO, _
    '                         CPNO)

    '        DeleteCode = True

    '    Catch ex As Exception
    '        MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "DeleteCode")

    '    Finally
    '        dbCon.Close()
    '        sdbCon.Close()

    '    End Try

    'End Function
    'Req.1612：別紙Bの自動分割 2018/03 End
    'Req.1612 別紙B自動作成 2017/12 End

#End Region

End Class