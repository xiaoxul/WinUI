﻿Imports MUSE.Utility.UserMessageBox

Public Class Frm_IntraLogin

    Public ReturnEvent As String = ""

    Private Sub Frm_IntraLogin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Me.Text = CommonVariable.OBAMATITLE
        txtPassword.Text = ""

    End Sub

    Private Sub btnOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOk.Click

        Call MainOk()

    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click

        txtUserId.Text = ""
        txtPassword.Text = ""
        ReturnEvent = btnCancel.Text
        Me.Hide()

    End Sub

    Private Sub txtPassword_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtPassword.KeyDown

        If e.KeyCode = Keys.Enter Then
            Call MainOk()
        End If

    End Sub

    Private Sub MainOk()

        If txtUserId.Text.Trim = "" Then
            MuseMessageBox.ShowWarning(Utility.SharedClass.FileReader.GetMessage("MSG_0200"), Me.Text)
            Exit Sub
        End If

        If txtPassword.Text.Trim = "" Then
            MuseMessageBox.ShowWarning(Utility.SharedClass.FileReader.GetMessage("MSG_0201"), Me.Text)
            Exit Sub
        End If

        ReturnEvent = btnOk.Text
        Me.Hide()

    End Sub

End Class