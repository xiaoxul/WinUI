﻿Imports System.Text
Imports System.IO
Imports System.Reflection
Imports System.Data.OleDb
Imports MUSE.WinUI.CommonVariable
Imports MUSE.Utility
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.SharedStructure
Imports MUSE.Utility.UserDataSet
Imports MUSE.Utility.UserDataTable.Master
Imports MUSE.Utility.UserDataTable.Transaction
Imports MUSE.Utility.UserDataTable.Work
Imports MUSE.Utility.UserMessageBox
Imports MUSE.Utility.UserException
Imports MUSE.Utility.XmlClass.Parameter
Imports MUSE.Utility.XmlClass.SystemInfo
Imports MUSE.Controller
Imports Microsoft.Office.Interop
Imports MUSE.Utility.OioBamaCommmon

Public Class Frm_PSDetailDelete

#Region "定数"

    ''Excelファイルの項目位置
    ''個別PS
    Private Const Excel_PS_ROW_LOCK_FLAG As Integer = 2                                                 ''ロックFLG
    Private Const Excel_PS_ROW_VALID_FLAG As Integer = 3                                                ''有効/無効
    Private Const Excel_PS_ROW_LINE_NO As Integer = 4                                                   ''NO
    Private Const Excel_PS_ROW_PROJ_ID As Integer = 11                                                  ''案件番号
    Private Const Excel_PS_ROW_PROD_ITEM01 As Integer = 35                                              ''ﾊﾟﾀｰﾝ別入力項目_項目１
    Private Const Excel_PS_ROW_PROD_ITEM02 As Integer = 36                                              ''ﾊﾟﾀｰﾝ別入力項目_項目２
    Private Const Excel_PS_ROW_PROD_ITEM03 As Integer = 37                                              ''ﾊﾟﾀｰﾝ別入力項目_項目３
    Private Const Excel_PS_ROW_PROD_ITEM04 As Integer = 38                                              ''ﾊﾟﾀｰﾝ別入力項目_項目４
    Private Const Excel_PS_ROW_PROD_ITEM05 As Integer = 39                                              ''ﾊﾟﾀｰﾝ別入力項目_項目５
    Private Const Excel_PS_ROW_PROD_ITEM06 As Integer = 40                                              ''ﾊﾟﾀｰﾝ別入力項目_項目６
    Private Const Excel_PS_ROW_PROD_ITEM07 As Integer = 41                                              ''ﾊﾟﾀｰﾝ別入力項目_項目７
    Private Const Excel_PS_ROW_PROD_ITEM08 As Integer = 42                                              ''ﾊﾟﾀｰﾝ別入力項目_項目８
    Private Const Excel_PS_ROW_PROD_ITEM09 As Integer = 43                                              ''ﾊﾟﾀｰﾝ別入力項目_項目９
    Private Const Excel_PS_ROW_PROD_ITEM10 As Integer = 44                                              ''ﾊﾟﾀｰﾝ別入力項目_項目１０
    Private Const Excel_PS_ROW_FILENM As Integer = 5                                                    ''ファイル名
    Private Const Excel_PS_ROW_FILE_NAME_SUFFIX As Integer = 6                                          ''ファイル名サフィックス
    Private Const Excel_PS_ROW_FILE_NAME_SUFFIX_INTR As Integer = 7                                     ''ファイル内サフィックス
    Private Const Excel_PS_ROW_CONTRACT As Integer = 8                                                  ''契約順番

    ''個別詳細
    Private Const Excel_PSD_ROW_VALID_FLAG As Integer = 3                                               ''有効/無効
    Private Const Excel_PSD_ROW_WD_ANNT_DATE As Integer = 12                                            ''製品･ｻｰﾋﾞｽ廃止発表日
    Private Const Excel_PSD_ROW_FILE_NAME As Integer = 5                                                ''ﾌｧｲﾙ名
    Private Const Excel_PSD_ROW_FILE_NAME_SUFFIX As Integer = 6                                          ''ファイル名サフィックス
    Private Const Excel_PSD_ROW_FILE_NAME_SUFFIX_INTR As Integer = 7                                     ''ファイル内サフィックス
    Private Const Excel_PSD_ROW_CONTRACT As Integer = 4                                                  ''契約順番

    ''Excelファイルの項目名
    ''個別PS
    Private Const Excel_PS_COLUMNM_VALID_FLAG As String = "VALID_FLAG"                                    ''有効/無効
    Private Const Excel_PS_COLUMNM_LOCK_FLAG As String = "LOCK_FLAG"                                      ''ロックフラグ
    Private Const Excel_PS_COLUMNM_LINE_NO As String = "LINE_NO"                                          ''NO
    Private Const Excel_PS_COLUMNM_PROJ_ID As String = "PROJ_ID"                                          ''案件番号
    Private Const Excel_PS_COLUMNM_PROD_ITEM10 As String = "PROD_ITEM10"                                  ''ﾊﾟﾀｰﾝ別入力項目_項目１０
    Private Const Excel_PS_COLUMNM_FILE_NAME As String = "FILE_NAME"                                      ''ファイル名
    Private Const Excel_PS_COLUMNM_FILE_NAME_SUFFIX As String = "FILE_NAME_SUFFIX"                        ''ファイル名サフィックス
    Private Const Excel_PS_COLUMNM_FILE_NAME_SUFFIX_INTR As String = "FILE_NAME_SUFFIX_INTR"              ''ファイル内サフィックス
    Private Const Excel_PS_COLUMNM_CONTRACT As String = "CONTRACT"                                        ''契約番号

    ''個別詳細
    Private Const Excel_PSD_COLUMNM_VALID_FLAG As String = "VALID_FLAG"                                    ''有効/無効
    Private Const Excel_PSD_COLUMNM_WD_ANNT_DATE As String = "WD_ANNT_DATE"                                ''製品･ｻｰﾋﾞｽ廃止発表日
    Private Const Excel_PSD_COLUMNM_CONTRACT As String = "CONTRACT"                                        ''契約番号
    Private Const Excel_PSD_COLUMNM_FILE_NAME As String = "FILE_NAME"                                      ''ﾌｧｲﾙ名
    Private Const Excel_PSD_COLUMNM_FILE_NAME_SUFFIX As String = "FILE_NAME_SUFFIX"                        ''ファイル名サフィックス
    Private Const Excel_PSD_COLUMNM_FILE_NAME_SUFFIX_INTR As String = "FILE_NAME_SUFFIX_INTR"              ''ファイル内サフィックス

#End Region

#Region "メンバ変数"
    Private ExclePSTable As New DataTable       ''個別PS　Excel行データ格納
    Private ExcleDetailTable As New DataTable   ''個別詳細 Excel行データ格納
#End Region

#Region "コンストラクタ"

    Sub New()

        ' この呼び出しはデザイナーで必要です。
        InitializeComponent()

        ' InitializeComponent() 呼び出しの後で初期化を追加します。

        ''削除対象コントロールの設定
        Me.lsv_SelectDel.View = System.Windows.Forms.View.Details
        Me.lsv_SelectDel.AllowColumnReorder = False
        Me.lsv_SelectDel.CheckBoxes = True
        Me.lsv_SelectDel.FullRowSelect = True
        Me.lsv_SelectDel.GridLines = False

        ''データテーブルの項目定義
        ''個別PS
        Me.ExclePSTable.Columns.Add(Excel_PS_COLUMNM_VALID_FLAG, Type.GetType("System.String"))
        Me.ExclePSTable.Columns.Add(Excel_PS_COLUMNM_LOCK_FLAG, Type.GetType("System.String"))
        Me.ExclePSTable.Columns.Add(Excel_PS_COLUMNM_LINE_NO, Type.GetType("System.String"))
        Me.ExclePSTable.Columns.Add(Excel_PS_COLUMNM_PROJ_ID, Type.GetType("System.String"))
        Me.ExclePSTable.Columns.Add(Excel_PS_COLUMNM_FILE_NAME, Type.GetType("System.String"))
        Me.ExclePSTable.Columns.Add(Excel_PS_COLUMNM_PROD_ITEM10, Type.GetType("System.String"))
        Me.ExclePSTable.Columns.Add(Excel_PS_COLUMNM_FILE_NAME_SUFFIX, Type.GetType("System.String"))
        Me.ExclePSTable.Columns.Add(Excel_PS_COLUMNM_FILE_NAME_SUFFIX_INTR, Type.GetType("System.String"))
        Me.ExclePSTable.Columns.Add(Excel_PS_COLUMNM_CONTRACT, Type.GetType("System.String"))

        ''個別詳細
        Me.ExcleDetailTable.Columns.Add(Excel_PSD_COLUMNM_VALID_FLAG, Type.GetType("System.String"))
        Me.ExcleDetailTable.Columns.Add(Excel_PSD_COLUMNM_FILE_NAME, Type.GetType("System.String"))
        Me.ExcleDetailTable.Columns.Add(Excel_PSD_COLUMNM_WD_ANNT_DATE, Type.GetType("System.String"))
        Me.ExcleDetailTable.Columns.Add(Excel_PSD_COLUMNM_FILE_NAME_SUFFIX, Type.GetType("System.String"))
        Me.ExcleDetailTable.Columns.Add(Excel_PSD_COLUMNM_FILE_NAME_SUFFIX_INTR, Type.GetType("System.String"))
        Me.ExcleDetailTable.Columns.Add(Excel_PSD_COLUMNM_CONTRACT, Type.GetType("System.String"))

    End Sub

#End Region

#Region "イベントハンドラ"

    ''' <summary>
    ''' 概　要：画面のLoad
    ''' 説　明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Frm_PSDetailDelete_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim waitDialog As New Frm_WaitDialog        '処理中ダイアログ定義

        '処理中ダイアログ表示
        waitDialog.Text = "データの読込み中"
        waitDialog.lbl_Message.Text = "データの読込み中です。"
        waitDialog.Pic_Excel.Visible = False
        waitDialog.ProgressMin = 0
        waitDialog.ProgressMax = 10
        waitDialog.ProgressStep = 1
        waitDialog.ProgressValue = 0
        waitDialog.Show()
        waitDialog.Refresh()

        '実行環境＋Version
        Me.Text = CommonVariable.OBAMATITLE

        ''契約情報の表示
        Call DispContractInfo()

        ''削除対象データの表示
        Call DispDelPsControl()

        waitDialog.Close()

    End Sub


    ''' <summary>
    ''' 概　要：ログアウト
    ''' 説　明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnLogOut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogOut.Click
        Me.DialogResult = DialogResult.Cancel
        Me.Close()
    End Sub

    ''' <summary>
    ''' 概　要：メニューへ
    ''' 説　明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnReturn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReturn.Click
        Me.DialogResult = DialogResult.No
        Me.Close()
    End Sub

    ''' <summary>
    ''' 概　要：PaymentSheet/個別詳細データ削除
    ''' 説　明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnDelPSDetailData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelPSDetailData.Click
        Try
            If Me.lsv_SelectDel.CheckedItems.Count = 0 Then
                Call MsgBox(FileReader.GetMessage("MSG_0429"), MsgBoxStyle.Critical, Me.Text)
                Exit Sub
            End If
            If MuseMessageBox.ShowQuestion(FileReader.GetMessage("MSG_0270"), Me.Text) = DialogResult.OK Then

                If ExcelWrite.ChkPaymentErr(Me.Name, sender.Name, _
                                            CommonVariable.CPNO, CommonVariable.CONTRACTNO) = False Then
                    Exit Sub
                End If

                ''削除処理
                Dim createTime As String
                Call DelPsDetailData(createTime)

                ''カテゴリ更新用のマクロをキックする。
                Dim ofm As New OioFileManage
                Dim PSFilePath As String
                PSFilePath = PSFilePath & ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
                PSFilePath = PSFilePath & ofm.GetNewPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO, createTime)
                If ExcelWrite.KickVBASuffixUpAct(ExcelWrite.VBActNMList.構成情報取消, PSFilePath, CommonVariable.USERID, CommonVariable.USERPW) = False Then
                    Exit Sub
                End If

                Call MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0271"), Me.Text)

                ''チェックリストが選択されていた場合のみサフィックス更新
                If Me.lsv_SelectDel.CheckedItems.Count > 0 Then

                    ''インクリメントしたサフィックスを画面に反映
                    Call DispContractInfo()

                    ''削除対象コントロールの再表示
                    Call DispDelPsControl()

                End If

            End If

        Catch ex As Exception

            MsgBox(ex.Message, MsgBoxStyle.Critical, Me.Text)

        End Try

    End Sub
#End Region

#Region "プライベートメソッド"

    ''' <summary>
    ''' 概　要：画面のLoad時、契約情報を画面のラベルに表示する。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub DispContractInfo()

        'カレントディレクトリの設定
        System.Environment.CurrentDirectory = Application.StartupPath

        ''CPNOをセット
        Dim dt As DataTable
        dt = OleDbAcc.OleDbCpnoBpt.getCpno(CommonVariable.CPNO)
        If dt.Rows.Count = 0 Then
            MsgBox("存在しないCPNOが選択されました。", MsgBoxStyle.Critical, Me.Name)
            dt = Nothing
            Exit Sub
        Else
            Me.txtModifyNo.Text = CommonVariable.CONTRACTNO.ToString.PadLeft(3, "0c")
            Me.txtCpnoName.Text = dt.Rows(0).Item(0).ToString & "(" & dt.Rows(0).Item(1).ToString.PadLeft(6, "0c") & ")"
            Me.txtCustomerName.Text = dt.Rows(0).Item(0).ToString
        End If

        ''契約順番をセット
        txtContract.Text = CommonVariable.CONTRACTNO.ToString.PadLeft(3, "0c")

        dt = Nothing

    End Sub

    ''' <summary>
    ''' 概　要：削除対象データの表示処理
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub DispDelPsControl()

        Dim xlApp As Excel.Application = Nothing
        Dim xlBooks As Excel.Workbooks = Nothing
        Dim xlBook As Excel.Workbook = Nothing
        Dim xlSheets As Excel.Sheets = Nothing
        Dim xlSheet As Excel.Worksheet = Nothing
        Dim strPSFileName As String
        Dim ofm As New Utility.OioBamaCommmon.OioFileManage

        Try
            'Excleアプリの初期化
            xlApp = New Excel.Application
            xlApp.DisplayAlerts = False
            xlApp.EnableEvents = False

            strPSFileName = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            strPSFileName = strPSFileName & ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            xlBooks = xlApp.Workbooks
            xlBook = xlBooks.Open(strPSFileName)
            xlSheets = xlBook.Sheets

            ''個別PSExcel行情報を取得
            xlSheet = xlSheets.Item(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)
            Call GetPSExcelRows(xlSheet)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, True)

            ''個別詳細Excel行情報を取得
            xlSheet = xlSheets.Item(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)
            Call GetDetailExcelRows(xlSheet)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, True)

            ''個別PSExcel行情報から、N行のファイル名表示
            Call DispNLineData()

        Catch ex As Exception
            Call MsgBox(ex.Message, MsgBoxStyle.Critical, Me.Text)
        Finally
            xlApp.DisplayAlerts = True
            xlApp.EnableEvents = True

            ''オブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlSheet, True)
            ExcelObjRelease.ReleaseExcelObj(xlSheets, True)
            If Not (xlBook Is Nothing) Then
                xlBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, True)
            ExcelObjRelease.ReleaseExcelObj(xlBooks, True)
            If Not (xlApp Is Nothing) Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, True)

            GC.Collect()
        End Try
    End Sub

    ''' <summary>
    ''' 概　要：個別PS、個別詳細Excelのデータ削除
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub DelPsDetailData(ByRef createTime As String)
        Try
            ''作成日時をExcelファイル名に追加
            createTime = Now.ToString("yyyyMMdd_HHmmss")

            ''個別Psのデータ削除
            Call DelPsData(createTime)

            ''個別詳細Excelのデータ削除
            Call DelDetailData(createTime)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    ''' <summary>
    ''' 概　要：個別PSExcelシートのセルの情報を取得
    ''' 説　明：
    ''' </summary>
    ''' <param name="xlSheet"></param>
    ''' <remarks></remarks>
    Private Sub GetPSExcelRows(ByVal xlSheet As Excel.Worksheet)

        Dim xlRange As Excel.Range
        Dim ew As New ExcelWrite
        Dim intRowsMax As Integer
        Dim objData(,) As Object

        Try
            'メンバ変数のExcel PS情報初期化
            ExclePSTable.Rows.Clear()

            'Excelのオートフィルタを初期化
            Call ew.CrearAutoFilter(xlSheet)

            'Excel個別Psの情報をメンバ変数へセット
            xlRange = xlSheet.Rows
            intRowsMax = xlRange.Count - 1
            ExcelObjRelease.ReleaseExcelObj(xlRange, True)
            For i As Integer = ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW To intRowsMax
                '1行取得
                xlRange = xlSheet.Range("A" & i.ToString & ":AW" & i.ToString)
                objData = xlRange.Value
                ExcelObjRelease.ReleaseExcelObj(xlRange, True)

                'N行がNullの場合、EOF
                If ExcelWrite.changeDBNullToString(objData(1, Excel_PS_ROW_VALID_FLAG)) = "" Then
                    Exit For
                End If

                'メンバ変数へセット
                Dim row As DataRow = Me.ExclePSTable.NewRow
                row.Item(Excel_PS_COLUMNM_VALID_FLAG) = objData(1, Excel_PS_ROW_VALID_FLAG)
                row.Item(Excel_PS_COLUMNM_LOCK_FLAG) = ExcelWrite.changeDBNullToString(objData(1, Excel_PS_ROW_LOCK_FLAG))
                row.Item(Excel_PS_COLUMNM_LINE_NO) = objData(1, Excel_PS_ROW_LINE_NO)
                row.Item(Excel_PS_COLUMNM_PROJ_ID) = objData(1, Excel_PS_ROW_PROJ_ID)
                If row.Item(Excel_PS_COLUMNM_VALID_FLAG) = "N" Then
                    ''N行の場合、ファイル名を取得
                    row.Item(Excel_PS_COLUMNM_PROD_ITEM10) = objData(1, Excel_PS_ROW_FILENM)
                Else
                    ''N行以外の場合、項目１０を取得
                    row.Item(Excel_PS_COLUMNM_PROD_ITEM10) = GetItem10FileNm(objData(1, Excel_PS_ROW_PROD_ITEM10))
                End If
                row.Item(Excel_PS_COLUMNM_FILE_NAME) = objData(1, Excel_PS_ROW_FILENM)
                row.Item(Excel_PS_COLUMNM_FILE_NAME_SUFFIX) = objData(1, Excel_PS_ROW_FILE_NAME_SUFFIX)
                row.Item(Excel_PS_COLUMNM_FILE_NAME_SUFFIX_INTR) = objData(1, Excel_PS_ROW_FILE_NAME_SUFFIX_INTR)
                row.Item(Excel_PS_COLUMNM_CONTRACT) = objData(1, Excel_PS_ROW_CONTRACT)

                Me.ExclePSTable.Rows.Add(row)
            Next

        Catch ex As Exception
            Throw ex
        Finally
            'オブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlRange, True)

            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' 概　要：個別詳細Excelシートのセルの情報を取得
    ''' 説　明：
    ''' </summary>
    ''' <param name="xlSheet"></param>
    ''' <remarks></remarks>
    Private Sub GetDetailExcelRows(ByVal xlSheet As Excel.Worksheet)

        Dim xlRange As Excel.Range
        Dim intRowsMax As Integer
        Dim isEof As Boolean            'Eof条件の判定
        Dim objData(,) As Object

        Try
            'メンバ変数のExcel PS情報初期化
            ExcleDetailTable.Rows.Clear()

            'Excel個別詳細の情報をメンバ変数へセット
            xlRange = xlSheet.Rows
            intRowsMax = xlRange.Count - 1
            ExcelObjRelease.ReleaseExcelObj(xlRange, True)
            For i As Integer = ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW To intRowsMax
                '1行取得
                xlRange = xlSheet.Range("A" & i.ToString & ":L" & i.ToString)
                objData = xlRange.Value
                ExcelObjRelease.ReleaseExcelObj(xlRange, True)

                isEof = True
                '契約順番　<> 空白は　出力
                If ExcelWrite.changeDBNullToString(objData(1, Excel_PSD_ROW_CONTRACT)) <> "" Then
                    isEof = False
                End If
                'Eof条件の判定
                If isEof Then
                    Exit For
                End If

                'メンバ変数へセット
                Dim row As DataRow = Me.ExcleDetailTable.NewRow
                row.Item(Excel_PSD_COLUMNM_VALID_FLAG) = objData(1, Excel_PSD_ROW_VALID_FLAG)
                row.Item(Excel_PSD_COLUMNM_FILE_NAME) = objData(1, Excel_PSD_ROW_FILE_NAME)
                row.Item(Excel_PSD_COLUMNM_WD_ANNT_DATE) = objData(1, Excel_PSD_ROW_WD_ANNT_DATE)
                row.Item(Excel_PSD_COLUMNM_FILE_NAME_SUFFIX) = objData(1, Excel_PSD_ROW_FILE_NAME_SUFFIX)
                row.Item(Excel_PSD_COLUMNM_FILE_NAME_SUFFIX_INTR) = objData(1, Excel_PSD_ROW_FILE_NAME_SUFFIX_INTR)
                row.Item(Excel_PSD_COLUMNM_CONTRACT) = objData(1, Excel_PSD_ROW_CONTRACT)

                Me.ExcleDetailTable.Rows.Add(row)
            Next

        Catch ex As Exception
            Throw ex

        Finally
            ''オブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlRange, True)
            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' 概　要：削除対象データコントロールの表示処理
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub DispNLineData()

        ''初期化
        Me.lsv_SelectDel.Items.Clear()

        ''----------------------------------
        ''Excel 個別PS情報の抽出
        ''----------------------------------
        ''ファイル名 <> ""以外を出力
        Dim filter As New StringBuilder
        filter.Append(Excel_PS_COLUMNM_PROD_ITEM10)
        filter.Append(" <> ")
        filter.Append(StringEdit.EncloseSingleQuotation(""))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(Excel_PS_COLUMNM_VALID_FLAG)
        filter.Append(CommonConstant.SQL_STR_NOT)
        filter.Append(CommonConstant.SQL_STR_IN)
        filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        filter.Append(StringEdit.EncloseSingleQuotation("N"))
        filter.Append(CommonConstant.STR_COMMA)
        filter.Append(StringEdit.EncloseSingleQuotation("C"))
        filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

        ''作成中　＆　作業中の契約順番のみ対象
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(Excel_PS_COLUMNM_LOCK_FLAG)
        filter.Append(" = ")
        filter.Append(StringEdit.EncloseSingleQuotation(""))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(Excel_PS_COLUMNM_CONTRACT)
        filter.Append(" = ")
        filter.Append(StringEdit.EncloseSingleQuotation(CommonVariable.CONTRACTNO))

        ''ファイル名 でソート　
        ''※重複データの判定のために使用
        Dim sort As New StringBuilder
        sort.Append(Excel_PS_COLUMNM_PROD_ITEM10)

        Dim sortRows() As DataRow
        sortRows = Me.ExclePSTable.Select(filter.ToString, sort.ToString)

        ''削除対象コントロールに、ファイル名を表示
        Dim preFileNm As String = ""                    ''前のレコードのファイル名
        Dim item10 As String = ""                       ''処理中レコードのファイル名
        Dim listItems As New ListViewItem
        For i As Integer = 0 To sortRows.Length - 1
            item10 = sortRows(i).Item(Excel_PS_COLUMNM_PROD_ITEM10)

            ''重複しないファイル名のみコントロールに出力
            If preFileNm <> item10 Then
                preFileNm = item10

                ''画面に表示する際、拡張子を外す。
                Dim item As New ListViewItem(Path.GetFileNameWithoutExtension(item10), 0)
                item.Checked = False

                ''構成取込ボタンの処理　※N行無し
                If sortRows(i).Item(Excel_PS_COLUMNM_PROD_ITEM10).ToString.IndexOf("構成取込") <> -1 Then
                    item.SubItems.Add(sortRows(i).Item(Excel_PS_COLUMNM_LINE_NO))
                    item.SubItems.Add(sortRows(i).Item(Excel_PS_COLUMNM_PROJ_ID))
                    Me.lsv_SelectDel.Items.Add(item)
                    Continue For
                End If

                ''NoはN行のデータを選択
                ''N行のNOを取得
                Dim filterN As New StringBuilder
                filterN.Remove(0, filterN.Length())
                filterN.Append(Excel_PS_COLUMNM_PROD_ITEM10)
                filterN.Append(" Like ")
                filterN.Append(StringEdit.EncloseSingleQuotation(item.Text & "%"))
                filterN.Append(CommonConstant.SQL_STR_AND)
                filterN.Append(Excel_PS_COLUMNM_VALID_FLAG)
                filterN.Append(CommonConstant.SQL_STR_EQUAL)
                filterN.Append(StringEdit.EncloseSingleQuotation("N"))

                ''作成中　＆　作業中の契約順番のみ対象
                filterN.Append(CommonConstant.SQL_STR_AND)
                filterN.Append(Excel_PS_COLUMNM_LOCK_FLAG)
                filterN.Append(" = ")
                filterN.Append(StringEdit.EncloseSingleQuotation(""))
                filterN.Append(CommonConstant.SQL_STR_AND)
                filterN.Append(Excel_PS_COLUMNM_CONTRACT)
                filterN.Append(" = ")
                filterN.Append(StringEdit.EncloseSingleQuotation(CommonVariable.CONTRACTNO))

                Dim Rows() As DataRow
                Rows = Me.ExclePSTable.Select(filterN.ToString)
                If Rows.Length > 0 Then
                    item.SubItems.Add(Rows(0).Item(Excel_PS_COLUMNM_LINE_NO))
                    item.SubItems.Add(sortRows(i).Item(Excel_PS_COLUMNM_PROJ_ID))
                    Me.lsv_SelectDel.Items.Add(item)
                End If
            End If
        Next
    End Sub

    ''' <summary>
    ''' 概　要：Item10　の　-000を除外した文字列を返す
    '''         Item10　の　PS_を除外した文字列を返す
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetItem10FileNm(ByVal value As Object) As String
        ''初期化
        GetItem10FileNm = ""

        If IsNothing(value) = True Then
            Exit Function
        End If

        If CStr(value).Length < 7 Then
            Exit Function
        End If

        ''PS_ と　-000を除外
        Dim rtnData As String
        rtnData = value.ToString
        rtnData = rtnData.Substring(3, rtnData.Length - 7)

        Return rtnData

    End Function

    ''' <summary>
    ''' 概　要：個別PS Excelのデータ削除
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub DelPsData(ByVal createTime As String)

        Dim app As New Excel.Application
        Dim WWbook As Excel.Workbook
        Dim WWsheet As Excel.Worksheet
        Dim Wran As Excel.Range
        Dim delFileNmArray As New ArrayList

        Dim excelWrite As New ExcelWrite

        ''Excelアプリの初期化
        app.DisplayAlerts = False
        app.EnableEvents = False

        ''削除対象コントロールから、ファイル名を取得
        Dim chekdValue As System.Windows.Forms.ListView.CheckedListViewItemCollection
        chekdValue = Me.lsv_SelectDel.CheckedItems
        For i As Integer = 0 To chekdValue.Count - 1
            delFileNmArray.Add(chekdValue(i).Text)
        Next

        Try
            ''個別PSExcelのファイル名の取得
            Dim bookPath As String = ""
            Dim fileManage As New Utility.OioBamaCommmon.OioFileManage

            ''Excelオブジェクトセット
            bookPath = fileManage.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            bookPath = bookPath & fileManage.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            WWbook = app.Workbooks.Open(bookPath)
            WWsheet = WWbook.Worksheets(excelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)

            ''Excelのオートフィルタを初期化
            Call ExcelWrite.CrearAutoFilter(WWsheet)

            ''個別PS Excelデータより削除対象の行を検索
            For i As Integer = Me.ExclePSTable.Rows.Count - 1 To 0 Step -1
                With Me.ExclePSTable
                    ''削除対象のセルか判定
                    If isDelPsRow(.Rows(i), delFileNmArray) Then

                        If .Rows(i).Item(Excel_PS_COLUMNM_VALID_FLAG) = "N" Then
                            ''N行の場合、項目1-10を初期化
                            Wran = WWsheet.Cells(i + 6, Excel_PS_ROW_PROD_ITEM01)
                            Wran.Value = ""
                            Wran = WWsheet.Cells(i + 6, Excel_PS_ROW_PROD_ITEM02)
                            Wran.Value = ""
                            Wran = WWsheet.Cells(i + 6, Excel_PS_ROW_PROD_ITEM03)
                            Wran.Value = ""
                            Wran = WWsheet.Cells(i + 6, Excel_PS_ROW_PROD_ITEM04)
                            Wran.Value = ""
                            Wran = WWsheet.Cells(i + 6, Excel_PS_ROW_PROD_ITEM05)
                            Wran.Value = ""
                            Wran = WWsheet.Cells(i + 6, Excel_PS_ROW_PROD_ITEM06)
                            Wran.Value = ""
                            Wran = WWsheet.Cells(i + 6, Excel_PS_ROW_PROD_ITEM07)
                            Wran.Value = ""
                            Wran = WWsheet.Cells(i + 6, Excel_PS_ROW_PROD_ITEM08)
                            Wran.Value = ""
                            Wran = WWsheet.Cells(i + 6, Excel_PS_ROW_PROD_ITEM09)
                            Wran.Value = ""
                        ElseIf .Rows(i).Item(Excel_PS_COLUMNM_VALID_FLAG) = "C" Then
                            ''コメント行は削除しない。
                        Else
                            ''行削除
                            Wran = WWsheet.Range(i + 6 & ":" & i + 6)
                            Wran.Delete(Excel.XlDirection.xlUp)
                        End If
                    End If
                End With
            Next

            WWbook.SaveAs(Filename:=(fileManage.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO) & fileManage.GetNewPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO, createTime)),
                          FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

        Catch ex As Exception
            Throw ex

        Finally
            app.DisplayAlerts = True
            app.EnableEvents = True

            ''オブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(Wran, True)
            ExcelObjRelease.ReleaseExcelObj(WWsheet, True)
            If Not (WWbook Is Nothing) Then
                WWbook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(WWbook, True)
            If Not (app Is Nothing) Then
                app.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(app, True)

            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' 概　要：個別詳細 Excelのデータ削除
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub DelDetailData(ByVal createTime As String)

        Dim app As New Excel.Application
        Dim WWbook As Excel.Workbook
        Dim WWsheet As Excel.Worksheet
        Dim Wran As Excel.Range
        Dim delFileNmArray As New ArrayList

        ''Excelアプリの初期化
        app.DisplayAlerts = False
        app.EnableEvents = False

        ''削除対象コントロールから、ファイル名を取得
        Dim chekdValue As System.Windows.Forms.ListView.CheckedListViewItemCollection
        chekdValue = Me.lsv_SelectDel.CheckedItems
        For i As Integer = 0 To chekdValue.Count - 1
            delFileNmArray.Add(chekdValue(i).Text)
        Next

        Try
            ''個別PSExcelのファイル名の取得
            Dim bookPath As String = ""
            Dim fileManage As New Utility.OioBamaCommmon.OioFileManage

            ''Excelオブジェクトセット
            bookPath = fileManage.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            bookPath = bookPath & fileManage.GetNewPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO, createTime)
            WWbook = app.Workbooks.Open(bookPath)
            WWsheet = WWbook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)

            ''個別PS Excelデータより削除対象の行を検索
            For i As Integer = Me.ExcleDetailTable.Rows.Count - 1 To 0 Step -1
                With Me.ExcleDetailTable
                    ''削除対象のセルか判定
                    If isDelPsDRow(.Rows(i), delFileNmArray) Then
                        ''行削除
                        Wran = WWsheet.Range(i + ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW & ":" & i + ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW)
                        Wran.Delete(Excel.XlDirection.xlUp)
                    End If
                End With
            Next

            'プロパティにファイル名を記載 str
            Dim properties As Object
            properties = WWbook.BuiltinDocumentProperties
            properties.Item("Category").value = WWbook.Name
            WWbook.Save()
            ''プロパティにファイル名を記載 end

            WWbook.SaveAs(Filename:=(fileManage.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO) & fileManage.GetNewPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO, createTime)),
                          FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

        Catch ex As Exception
            Throw ex
        Finally
            app.DisplayAlerts = True
            app.EnableEvents = True

            ''オブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(Wran, True)
            ExcelObjRelease.ReleaseExcelObj(WWsheet, True)
            If Not (WWbook Is Nothing) Then
                WWbook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(WWbook, True)
            If Not (app Is Nothing) Then
                app.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(app, True)

            GC.Collect()

        End Try

    End Sub


    ''' <summary>
    ''' 概　要：削除対象の個別PSセルか判定
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function isDelPsRow(ByVal row As DataRow, _
                                ByVal delFileNmArray As ArrayList) As Boolean

        isDelPsRow = False

        ''拡張子抜きのファイル名で、削除対象コントロールの名称を検索
        Dim rtnCd As Integer
        rtnCd = delFileNmArray.IndexOf(Path.GetFileNameWithoutExtension(ExcelWrite.changeDBNullToString(row(Excel_PS_COLUMNM_PROD_ITEM10))))

        ''==========================================================
        ''契約順番が一致でかつ、作成中のデータのみ削除
        ''==========================================================
        ''契約順番がNull
        If ExcelWrite.changeDBNullToString(row.Item(Excel_PS_COLUMNM_CONTRACT)) = "" Then
            rtnCd = -1
        Else
            ''契約順番がNull以外で値が違う
            If CInt(ExcelWrite.changeDBNullToString(row.Item(Excel_PS_COLUMNM_CONTRACT))) <> CommonVariable.CONTRACTNO Then
                rtnCd = -1
            End If
        End If

        ''作成中以外NG
        If ExcelWrite.changeDBNullToString(row.Item(Excel_PS_COLUMNM_LOCK_FLAG)) <> "" Then
            rtnCd = -1
        End If

        If rtnCd <> -1 Then
            isDelPsRow = True
        End If

    End Function

    ''' <summary>
    ''' 概　要：削除対象の個別詳細セルか判定
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function isDelPsDRow(ByVal row As DataRow, _
                                 ByVal delFileNmArray As ArrayList) As Boolean

        isDelPsDRow = False

        ''個別詳細に紐づくPS情報取得
        Dim rows() As DataRow
        Dim filter As New StringBuilder
        filter.Append(Excel_PS_COLUMNM_FILE_NAME)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(row.Item(Excel_PSD_COLUMNM_FILE_NAME)))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(Excel_PS_COLUMNM_FILE_NAME_SUFFIX)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(row.Item(Excel_PSD_COLUMNM_FILE_NAME_SUFFIX)))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(Excel_PS_COLUMNM_FILE_NAME_SUFFIX_INTR)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(row.Item(Excel_PSD_COLUMNM_FILE_NAME_SUFFIX_INTR)))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(Excel_PS_COLUMNM_CONTRACT)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(row.Item(Excel_PSD_COLUMNM_CONTRACT)))

        ''画面の契約順番と一致 &　作業中のデータのみ 
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(Excel_PS_COLUMNM_CONTRACT)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(CommonVariable.CONTRACTNO))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(Excel_PS_COLUMNM_LOCK_FLAG)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(""))

        rows = Me.ExclePSTable.Select(filter.ToString)

        ''PS情報が、画面で選択した値に紐づくかどうか
        If rows.Length > 0 Then
            Dim rtn As Integer = 0
            rtn = delFileNmArray.IndexOf(Path.GetFileNameWithoutExtension(ExcelWrite.changeDBNullToString(rows(0).Item(Excel_PS_COLUMNM_PROD_ITEM10))))
            If rtn <> -1 Then
                isDelPsDRow = True
            End If
        End If

    End Function

#End Region

End Class


