﻿'Imports Shell32
Imports System.IO
Imports System.Text
Imports System.Data.OleDb
Imports Microsoft.Office.Interop
Imports MUSE.Utility
Imports MUSE.Utility.OioBamaCommmon
Imports MUSE.Utility.UserMessageBox
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.XmlClass.SheetFoumulate
Imports MUSE.Utility.UserDataTable.Master
Imports MUSE.Controller

Public Class ExcelVersionUp

#Region "構造体"
    '各バージョン情報
    Private Structure OldVersion
        Public VerUp As Boolean                     '最新バージョンに対してバージョンアップを行うか　○：行う　×：行わない
        Public Ver As String                        'バージョン
        Public Method As String                     'バージョンアップ方法　1：全て変更　2：表題、マクロ変更（データのコピーだけで済ませれるもの）
        Public Comment As String                    'コメント
    End Structure
    'バージョン情報
    Private Structure ExcelVersion
        Public Name As String                       'シート名
        Public NewVer As String                     '最新バージョン
        Public OldVer() As OldVersion               '各バージョン情報
    End Structure

    'EXCEL設定値
    Private Structure ExcelSetting
        Public OldVer As Double                     '旧バージョン
        Public OldExcelFileName As String           '旧EXCELファイル名
        Public OldRowStart As Integer               '旧データ開始行
        Public OldSheetName As String               '旧シート名
        Public OldValueRange As String              '旧値範囲
        Public OldColMax As Integer                 '旧最大カラム数
        Public NewVer As Double                     '新バージョン
        Public NewExcelFileName As String           '新EXCELファイル名
        Public NewRowStart As Integer               '新データ開始行
        Public NewSheetName As String               '新シート名
        Public NewValueRange As String              '新値範囲
        Public NewColMax As Integer                 '新最大カラム数
    End Structure

    Private Structure SRow
        Public SRow As Integer                      'S行の位置
        Public BRowStart As Integer                 'S行に付随するBoxの開始位置
        Public BRowEnd As Integer                   'S行に付随するBoxの終了位置
    End Structure

    'S行の情報を格納
    Private Structure SLineInfo
        Public ContractNo As Object                 '契約順番
        Public FileNM As Object                     'ファイル名
        Public FileNMSuffix As Object               'ファイル名Suffix
        Public FileIntrSuffix As Object             'ファイル内Suffix
        Public Attach As Boolean                    'リンク貼付済かどうか？
        Public ExcelRow As Long                     'Excelの行位置
        Public BoxIndex As Long                     '詳細のBox行の位置
        Public BoxCount As Long                     'S行のBox/Feature数
    End Structure

    Private Structure MappingCellPs
        Public NewPos As Integer
        Public OldPos As Integer
    End Structure

    Private Structure MappingCellDetail
        Public NewPos As Integer
        Public OldPos As Integer
    End Structure

    '体裁変換用
    Private Structure FormatChange
        Public Pos As Integer                       'セル位置
        Public Title As String                      '項目名
        Public PhysicalName As String               '物理名
        Public ChangeOldNew As Integer              '変換順番　0：VERUP前　   1：VERUP後
        Public ChangeCd As Integer                  '変換区分　0：変換しない　1：変換する
        Public FormatType As Integer                '型　      0：文字列　    1：数値
    End Structure
#End Region

#Region "CONST"
    Private Const IDX_PS As Integer = 1
    Private Const IDX_DETAIL As Integer = 2
    Private Const CD_METHOD_ALL As Integer = 1
    Private Const CD_METHOD_MACRO As Integer = 2
    Private Const SHEET_OLD_PS As String = "OBAMA-PS"
    Private Const SHEET_OLD_DETAIL As String = "PaymentLineDetail"

    'Ver.旧
    Private Const ROW_START_PS_OLD As Integer = ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW
    Private Const ROW_START_DETAIL_OLD As Integer = ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW
    Private Const ROW_TOTAL_PS_OLD As String = "2:2"
    Private Const ROW_TOTAL_DETAIL_OLD As String = "2:2"
    Private Const ROW_SAMPLE_DETAIL_OLD As String = "3:3"
    Private Const RANGE_VALUE_PS_OLD As String = "A@:MS@"
    Private Const RANGE_VALUE_DETAIL_OLD As String = "A@:AD@"
    Private Const COL_MAX_PS_OLD As Integer = 357
    Private Const COL_MAX_DETAIL_OLD As Integer = 30
    'Ver.最新
    Private Const ROW_START_PS_NEW As Integer = ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW
    Private Const ROW_START_DETAIL_NEW As Integer = ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW
    Private Const ROW_TOTAL_PS_NEW As String = "2:2"
    Private Const ROW_TOTAL_DETAIL_NEW As String = "2:2"
    Private Const ROW_SAMPLE_DETAIL_NEW As String = "3:3"
    Private Const RANGE_VALUE_PS_NEW As String = "A@:MS@"
    Private Const RANGE_VALUE_DETAIL_NEW As String = "A@:AD@"
    Private Const COL_MAX_PS_NEW As Integer = 357
    Private Const COL_MAX_DETAIL_NEW As Integer = 30

    Private Const CD_FORMAT_OLD As Integer = 0
    Private Const CD_FORMAT_NEW As Integer = 1
#End Region

#Region "Public"
#Region "編集ボタンからのバージョンアップ"
    ''' <summary>
    ''' 機　能：EXCELのバージョンアップ
    ''' </summary>
    ''' <param name="frmWait"></param>
    ''' <param name="strExcelFileName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function CheckExcelVersion(ByRef frmWait As Frm_WaitDialog, ByRef strExcelFileName As String) As Boolean

        Dim strCpnoPath As String = ""
        Dim strPsVer As String = ""
        Dim strDetailVer As String = ""
        Dim strTempPath As String
        Dim strTempPsVer As String
        Dim ofm As New OioFileManage
        Dim blnVerUpPs As Boolean = False           'True:VerUp有　False:VerUp無
        Dim blnRet As Boolean
        Dim strAddFileName As String
        Dim strMsg As String
        Dim ExcelVerInfo As ExcelVersion
        Dim intCnt As Integer
        Dim strComment As String = ""
        Dim strMethod As String = "                 'バージョンアップ方法"
        Dim intRet As Integer
        Dim strProcMsg As String = ""
        Dim strEndMsg As String = ""
        Dim ExcelSettingInfo(2) As ExcelSetting

        CheckExcelVersion = False

        Try
            '===========================================
            'ダイアログ設定
            '===========================================
            With frmWait
                .Text = "バージョンチェック"
                .Pic_Excel.Visible = True
                .lbl_Message.Text = "バージョンチェック中です。"
                .ProgressMin = 0
                .ProgressMax = 100
                .ProgressValue = 0
                .Show()
                .Update()
            End With

            '===========================================
            'バージョン取得
            '===========================================
            strCpnoPath = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            '該当CPNOのPaymentsheetのバージョン
            ExcelSettingInfo(IDX_PS).OldExcelFileName = ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            'ファイル存在チェック
            blnRet = File.Exists(strCpnoPath & ExcelSettingInfo(IDX_PS).OldExcelFileName)
            If blnRet = False Then
                Call MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0326") & "Paymentsheet", "")
                Exit Function
            End If
            'PaymentsheetがOPEN中かチェック
            blnRet = ofm.ChkOpenedExcelFile(strCpnoPath & ExcelSettingInfo(IDX_PS).OldExcelFileName)
            If blnRet = False Then
                Call MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0325") & vbCrLf & vbCrLf _
                                              & "ファイル名：" & ExcelSettingInfo(IDX_PS).OldExcelFileName, "")
                Exit Function
            End If
            ''Ver情報の取得元を変更
            Dim msg As String
            If ofm.GetXlsFileVer(strCpnoPath & ExcelSettingInfo(IDX_PS).OldExcelFileName, strPsVer, msg) = False Then
                Call MuseMessageBox.ShowError(msg, "")
                Exit Function
            End If

            'PaymentLineのバージョンをチェック
            ExcelSettingInfo(IDX_PS).OldVer = Double.Parse(strPsVer)

            'Templateのバージョン
            strTempPath = ofm.GetLocalTemplateFolder
            If ofm.GetXlsFileVer(strTempPath & CommonConstant.FILENAME_XLS_PAYMENTSAMPLE, strTempPsVer, msg) = False Then
                Call MuseMessageBox.ShowError(msg & "(Template)", "Excel VersionUp")
                Exit Function
            End If

            'Templateからバージョンを取得出来なかった場合
            If strTempPsVer = "" Then
                Call MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0362"), "Excel VersionUp")
                Exit Function
            End If

            'EXCELバージョン情報ファイル（ExcelVersionInfo.xml）からデータを取得
            blnRet = GetExcelVersion(ExcelVerInfo)
            If blnRet = False Then
                Call MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0363"), "Excel VersionUp")
                Exit Function
            End If

            frmWait.ProgressValue = 10
            frmWait.Update()

            '===========================================    
            'EXCELバージョン情報ファイルとTemplateとPaymentsheetのバージョン比較
            '===========================================
            strMsg = ""
            'EXCELバージョン情報ファイルとTemplateのバージョンをチェック
            If ExcelVerInfo.NewVer <> strTempPsVer Then
                '不一致の場合、エラー表示し処理を中断する
                Call MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0358"), "Excel VersionUp")
                Exit Function
            End If

            'PaymentsheetとEXCELバージョン情報ファイルを比較
            If strPsVer <> strTempPsVer Then
                For intCnt = 1 To (ExcelVerInfo.OldVer.Length - 1)
                    If strPsVer = ExcelVerInfo.OldVer(intCnt).Ver Then
                        If ExcelVerInfo.OldVer(intCnt).VerUp = True Then
                            blnVerUpPs = True
                            strMethod = ExcelVerInfo.OldVer(intCnt).Method
                            strComment = strComment & vbCrLf & "Paymentsheetの変更履歴" & vbCrLf
                            strComment = strComment & "（ﾌｧｲﾙﾊﾞｰｼﾞｮﾝ　" & strPsVer & " → " & strTempPsVer & "）" & vbCrLf
                            Continue For
                        Else
                            'バージョンアップ：×の場合は処理を中断する
                            strMsg = FileReader.GetMessage("MSG_0360") & vbCrLf & vbCrLf
                            strMsg = strMsg & "中断理由（" & strPsVer & " → " & strTempPsVer & "）" & vbCrLf
                            strMsg = strMsg & "　" & ExcelVerInfo.OldVer(intCnt + 1).Comment
                            Call MuseMessageBox.ShowError(strMsg, "Excel VersionUp")
                            Exit Function
                        End If
                    End If
                    If blnVerUpPs = True Then
                        strComment = strComment & "　" & ExcelVerInfo.OldVer(intCnt).Ver & "　" & ExcelVerInfo.OldVer(intCnt).Comment & vbCrLf
                    End If
                Next
                If strComment = "" Then
                    Call MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0409"), "Excel VersionUp")
                    Exit Function
                Else
                    strProcMsg = FileReader.GetMessage("MSG_0488")
                    strEndMsg = FileReader.GetMessage("MSG_0359") & vbCrLf & strComment
                End If
            Else
                'PSﾌｧｲﾙとDB2の保有年数の確認
                intRet = ExcelWrite.chkPayPeriod(strMsg,
                                                 ExcelWrite.enmChkPayPeriodCallMethod.payEdit,
                                                 strCpnoPath & ExcelSettingInfo(IDX_PS).OldExcelFileName,
                                                 CommonVariable.PaymentStart,
                                                 CommonVariable.PaymentPeriod)
                Select Case intRet
                    Case ExcelWrite.enmChkPayPeriodRtnCd.ChkOK
                        CheckExcelVersion = True
                        Exit Function
                    Case ExcelWrite.enmChkPayPeriodRtnCd.ChkWarningAdd
                        strMethod = CD_METHOD_MACRO
                        blnVerUpPs = True
                        strProcMsg = FileReader.GetMessage("MSG_0489")
                        strEndMsg = FileReader.GetMessage("MSG_0490")
                    Case ExcelWrite.enmChkPayPeriodRtnCd.ChkWarningDel
                        MuseMessageBox.ShowWarning(FileReader.GetMessage("MSG_0487"), "Excel VersionUp")
                        strMethod = CD_METHOD_MACRO
                        blnVerUpPs = True
                        strProcMsg = FileReader.GetMessage("MSG_0489")
                        strEndMsg = FileReader.GetMessage("MSG_0490")
                    Case ExcelWrite.enmChkPayPeriodRtnCd.ChkNG,
                         ExcelWrite.enmChkPayPeriodRtnCd.ChkException
                        MuseMessageBox.ShowError(strMsg, "Excel VersionUp")
                        Exit Function
                End Select
            End If

            frmWait.ProgressValue = 20
            frmWait.Update()

            '===========================================
            'PaymentsheetとPaymentsheetDetailのバージョンアップ
            '===========================================
            If strMethod = CD_METHOD_ALL Then
                With ExcelSettingInfo(IDX_PS)
                    .OldSheetName = ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET
                    .OldRowStart = ROW_START_PS_OLD
                    .OldValueRange = RANGE_VALUE_PS_OLD
                    .OldColMax = COL_MAX_PS_OLD
                End With
                With ExcelSettingInfo(IDX_PS)
                    .NewSheetName = ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET
                    .NewRowStart = ROW_START_PS_NEW
                    .NewValueRange = RANGE_VALUE_PS_NEW
                    .NewColMax = COL_MAX_PS_NEW
                End With

                With ExcelSettingInfo(IDX_DETAIL)
                    .OldExcelFileName = ExcelSettingInfo(IDX_PS).OldExcelFileName
                    .OldSheetName = ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET
                    .OldRowStart = ROW_START_DETAIL_OLD
                    .OldValueRange = RANGE_VALUE_DETAIL_OLD
                    .OldColMax = COL_MAX_DETAIL_OLD
                End With
                With ExcelSettingInfo(IDX_DETAIL)
                    .NewSheetName = ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET
                    .NewRowStart = ROW_START_DETAIL_NEW
                    .NewValueRange = RANGE_VALUE_DETAIL_NEW
                    .NewColMax = COL_MAX_DETAIL_NEW
                End With
            Else
                With ExcelSettingInfo(IDX_PS)
                    .OldSheetName = ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET
                    .OldRowStart = ROW_START_PS_NEW
                    .OldValueRange = RANGE_VALUE_PS_NEW
                    .OldColMax = COL_MAX_PS_NEW
                End With
                With ExcelSettingInfo(IDX_PS)
                    .NewSheetName = ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET
                    .NewRowStart = ROW_START_PS_NEW
                    .NewValueRange = RANGE_VALUE_PS_NEW
                    .NewColMax = COL_MAX_PS_NEW
                End With

                With ExcelSettingInfo(IDX_DETAIL)
                    .OldExcelFileName = ExcelSettingInfo(IDX_PS).OldExcelFileName
                    .OldSheetName = ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET
                    .OldRowStart = ROW_START_DETAIL_NEW
                    .OldValueRange = RANGE_VALUE_DETAIL_NEW
                    .OldColMax = COL_MAX_DETAIL_NEW
                End With
                With ExcelSettingInfo(IDX_DETAIL)
                    .NewSheetName = ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET
                    .NewRowStart = ROW_START_DETAIL_NEW
                    .NewValueRange = RANGE_VALUE_DETAIL_NEW
                    .NewColMax = COL_MAX_DETAIL_NEW
                End With
            End If

            'ファイル名設定
            strAddFileName = ofm.GetNewPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Now.ToString("yyyyMMdd_HHmmss"))
            ExcelSettingInfo(IDX_PS).NewExcelFileName = strAddFileName
            ExcelSettingInfo(IDX_DETAIL).NewExcelFileName = ExcelSettingInfo(IDX_PS).NewExcelFileName

            'Paymentsheet
            If blnVerUpPs = True Then
                frmWait.lbl_Message.Text = strProcMsg
                frmWait.Update()

                'Temlateからファイルをコピーする
                strExcelFileName = strCpnoPath & ExcelSettingInfo(IDX_PS).NewExcelFileName
                FileCopy(strTempPath & CommonConstant.FILENAME_XLS_PAYMENTSAMPLE, strExcelFileName)

                blnRet = VersionUpExcel(strCpnoPath, ExcelSettingInfo, strMethod, CommonVariable.PaymentStart.ToString("yyyy"), frmWait)
                If blnRet = False Then
                    Exit Function
                End If

                frmWait.ProgressValue = 95
                frmWait.Update()
            End If

            Call MuseMessageBox.ShowInformation(strEndMsg, "Excel VersionUp")

            CheckExcelVersion = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "CheckExcelVersion")
            File.Delete(strCpnoPath & ExcelSettingInfo(IDX_PS).NewExcelFileName)

        Finally
            frmWait.ProgressValue = 100

        End Try

    End Function
#End Region

#Region "一括でのバージョンアップ"
    ''' <summary>
    ''' 一括でのバージョンアップ
    ''' </summary>
    ''' <param name="strPaymentFileName"></param>
    ''' <param name="strOutputPath"></param>
    ''' <param name="intPsCnt"></param>
    ''' <param name="intDetailCnt"></param>
    ''' <param name="strMsg"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function OutputVerUpExcelToCsv(ByVal strPaymentFileName As String,
                                          ByVal strOutputPath As String,
                                          ByRef intPsCnt As Integer,
                                          ByRef intDetailCnt As Integer,
                                          ByRef strMsg As String) As Integer

        ''初期化
        Dim WriteCsvCnt As Integer = -1
        Dim dtNow As DateTime = Now
        Dim strCreateTime As String
        Dim strOutputFileNameVPLine As String
        Dim strOutputFileNameTPprice As String
        Dim strOutputFileNameDetail As String
        Dim strWork As String
        Dim intRowCount As Integer
        Dim CsvFileName As New StringBuilder

        ''Excelオブジェクト
        Dim xlApp As Excel.Application = Nothing
        Dim xlBooks As Excel.Workbooks = Nothing
        Dim xlBook As Excel.Workbook = Nothing
        Dim xlSheets As Excel.Sheets = Nothing
        Dim xlSheet As Excel.Worksheet = Nothing

        Try
            ''ファイル名取得
            strCreateTime = dtNow.ToString("yyyyMMdd_HHmmss")
            strWork = Path.GetFileName(strPaymentFileName)
            strOutputFileNameVPLine = strWork.Substring(0, 6) & "_999_V_PLINE_" & strCreateTime & ".csv"
            strOutputFileNameTPprice = strWork.Substring(0, 6) & "_999_T_PPRICE_" & strCreateTime & ".csv"
            strOutputFileNameDetail = strWork.Substring(0, 6) & "_999_T_PLINE_DETAIL_" & strCreateTime & ".csv"

            ''エクセル用のオブジェクト初期設定
            xlApp = New Excel.Application
            xlApp.EnableEvents = False
            xlBooks = xlApp.Workbooks
            xlBook = xlBooks.Open(strPaymentFileName, ReadOnly:=True)
            xlApp.EnableEvents = True
            xlSheets = xlBook.Worksheets

            'PaymentCSV変換（移行データロード専用）
            xlSheet = xlSheets.Item(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)
            intPsCnt = OutputVerUpExcelToCsvPs(strOutputPath & "\" & strOutputFileNameVPLine,
                                               strOutputPath & "\" & strOutputFileNameTPprice,
                                               xlSheet,
                                               dtNow,
                                               strMsg)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            '詳細CSV変換（移行データロード専用）
            xlSheet = xlSheets.Item(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)
            intDetailCnt = OutputVerUpExcelToCsvDetail(strOutputPath & "\" & strOutputFileNameDetail, xlSheet, dtNow, strMsg)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

        Catch ex As Exception
            strMsg = ex.Message.ToString & "(OutputVerUpExcelToCsv)"

        Finally
            'エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBook) = False Then
                xlBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlBooks, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

        End Try

        ''処理件数を返す。
        Return intRowCount

    End Function
#End Region

#End Region

#Region "Private"
#Region "編集"
    ''' <summary>
    ''' 機能：Paymentの変換処理
    ''' </summary>
    ''' <param name="strCpnoPath"></param>
    ''' <param name="ExcelSettingInfo"></param>
    ''' <param name="strMethod"></param>
    ''' <param name="strExcelStart"></param>
    ''' <param name="frmWait"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function VersionUpExcel(ByVal strCpnoPath As String,
                                    ByVal ExcelSettingInfo() As ExcelSetting,
                                    ByVal strMethod As String,
                                    ByVal strExcelStart As String,
                                    ByRef frmWait As Frm_WaitDialog) As Boolean

        Dim blnRet As Boolean
        Dim arPsData As New ArrayList
        Dim arPsdData As New ArrayList
        Dim strCsvPaht As String = ""
        Dim strCreateDate As String
        Dim ofm As New OioFileManage
        Dim intOldPaymentPeriod As Integer = CommonVariable.PaymentPeriod     '変換元Payment展開期間

        Dim xlApp As Excel.Application = Nothing
        Dim xlBooks As Excel.Workbooks = Nothing
        Dim xlBook As Excel.Workbook = Nothing
        Dim xlSheets As Excel.Sheets = Nothing
        Dim xlSheet As Excel.Worksheet = Nothing

        VersionUpExcel = False

        Try
            '-----------------------------------------------
            'ExcelObject初期化
            '-----------------------------------------------
            xlApp = New Excel.Application
            xlBooks = xlApp.Workbooks

            '-----------------------------------------------
            'データ取得
            '-----------------------------------------------
            xlApp.EnableEvents = False
            xlBook = xlBooks.Open(strCpnoPath & ExcelSettingInfo(IDX_PS).OldExcelFileName, 0)
            xlApp.EnableEvents = True
            xlSheets = xlBook.Worksheets

            'WS1(保有年数取得)
            If strMethod = CD_METHOD_MACRO Then
                xlSheet = xlSheets.Item(ExcelWrite.EXCEL_PAYMENTLINEDATE_WS1)
                Dim objValue(,) As Object
                blnRet = GetCellValue(xlSheet, "H7:I7", objValue)
                If (objValue(1, 2) - objValue(1, 1)) > 0 Then
                    intOldPaymentPeriod = objValue(1, 2) - objValue(1, 1) + 1
                End If
                ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            End If

            'Payment
            xlSheet = xlSheets.Item(ExcelSettingInfo(IDX_PS).OldSheetName)
            blnRet = VersionUpPs(xlSheet, arPsData, ExcelSettingInfo(IDX_PS), intOldPaymentPeriod, strMethod)
            If blnRet = False Then
                Exit Function
            End If
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            frmWait.ProgressValue = 40
            frmWait.Update()

            '詳細
            xlSheet = xlSheets.Item(ExcelSettingInfo(IDX_DETAIL).OldSheetName)
            blnRet = VersionUpDetail(xlSheet, arPsdData, ExcelSettingInfo(IDX_DETAIL), strMethod)
            If blnRet = False Then
                Exit Function
            End If
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)
            xlBook.Close()
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)

            frmWait.ProgressValue = 60
            frmWait.Update()

            '-----------------------------------------------
            'Excel出力
            '-----------------------------------------------
            xlApp.EnableEvents = False
            xlBook = xlBooks.Open(strCpnoPath & ExcelSettingInfo(IDX_PS).NewExcelFileName, 0)
            xlApp.EnableEvents = True
            xlSheets = xlBook.Worksheets

            strCsvPaht = Path.GetFullPath("../log/")
            strCreateDate = Now.ToString("_yyyyMMdd_HHmmss")

            'Payment
            xlSheet = xlSheets.Item(ExcelSettingInfo(IDX_PS).NewSheetName)
            blnRet = OutputExcelPs(arPsData, strExcelStart, strCsvPaht, strCreateDate, xlSheet)
            If blnRet = False Then
                Exit Function
            End If
            'Payment展開期間分列削除
            'Paymentｼｰﾄ
            ExcelWrite.CreatePaymentPeriod(xlSheet,
                                             ExcelWrite.ChgExcelRowNumberToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1),
                                             CommonVariable.PaymentPeriod)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            'Dummyｼｰﾄ
            xlSheet = xlSheets.Item(ExcelWrite.EXCEL_PAYMENTLINEDATE_DUMMYSHEET)
            ExcelWrite.CreatePaymentPeriod(xlSheet,
                                             ExcelWrite.ChgExcelRowNumberToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1),
                                             CommonVariable.PaymentPeriod)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            frmWait.ProgressValue = 78
            frmWait.Update()

            '詳細
            xlSheet = xlSheets.Item(ExcelSettingInfo(IDX_DETAIL).NewSheetName)
            blnRet = OutputExcelPsd(arPsdData, strCsvPaht, strCreateDate, xlSheet)
            If blnRet = False Then
                Exit Function
            End If
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            ExcelWrite.KickVBASuffixUpAct(xlApp, xlBook, ExcelWrite.VBActNMList.Verup, CommonVariable.USERID, CommonVariable.USERPW)

            ''プロパティにファイル名を記載 str
            'Dim obj As Object
            'Dim fso As Object

            'fso = CreateObject("Scripting.FileSystemObject")
            'obj = GetObject(xlBook.Path & "\" & xlBook.Name)

            'obj.BuiltinDocumentProperties("Category") = xlBook.Name
            'obj.save()

            'obj = Nothing
            'fso = Nothing

            Dim properties As Object
            properties = xlBook.BuiltinDocumentProperties
            properties.Item("Category").value = xlBook.Name
            xlBook.Save()

            properties = Nothing
            ''プロパティにファイル名を記載 end

            VersionUpExcel = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "VersionUpExcel")

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBook) = False Then
                xlBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlBooks, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            'ﾜｰｸﾌｧｲﾙ削除
            Call ofm.DeleteWorkFile(strCsvPaht)

        End Try

    End Function

    ''' <summary>
    ''' 機　能：Paymentｼｰﾄ変換処理
    ''' </summary>
    ''' <param name="xlSheet"></param>
    ''' <param name="arPsData"></param>
    ''' <param name="ExcelSettingInfo"></param>
    ''' <param name="intOldPaymentPeriod"></param>
    ''' <param name="strMethod"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function VersionUpPs(ByRef xlSheet As Excel.Worksheet,
                                 ByRef arPsData As ArrayList,
                                 ByVal ExcelSettingInfo As ExcelSetting,
                                 ByVal intOldPaymentPeriod As Integer,
                                 ByVal strMethod As String) As Boolean

        Dim strRange As String
        Dim intRow As Integer
        Dim objLineFomula(,) As Object
        Dim objLineValue(,) As Object
        Dim objFomulaNew(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12) As Object
        Dim intCnt As Integer
        Dim xmlPaymentLineFomulateInfo As PaymentLineFomulateInfo
        Dim blnRet As Boolean

        VersionUpPs = False

        Try
            '-----------------------------------------------
            'xmlから新計算式を取得
            '-----------------------------------------------
            xmlPaymentLineFomulateInfo = ExcelWrite.GetPaymentExcelFomulate
            '計算式を配列代入
            Call SetPsFomulaObject(xmlPaymentLineFomulateInfo, objFomulaNew)

            '-----------------------------------------------
            'Paymentのデータ取得(変換元)
            '-----------------------------------------------
            intRow = ExcelSettingInfo.OldRowStart
            Do
                '１行取得（変換元の値）
                strRange = ExcelSettingInfo.OldValueRange.Replace("@", intRow.ToString)
                blnRet = GetCellValue(xlSheet, strRange, objLineValue)
                '１行取得（変換元の式）
                strRange = ExcelSettingInfo.OldValueRange.Replace("@", intRow.ToString)
                blnRet = GetCellFormula(xlSheet, strRange, objLineFomula)

                'ExcelのEOFの判定
                If ExcelWrite.changeDBNullToString(objLineValue(1, ExcelWrite.OldExcelPsColumn.LINE_NO)) = "" Then
                    Exit Do
                End If

                Dim objData(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12 - 1) As Object
                Dim objFomulaOld(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12) As Object
                If strMethod = CD_METHOD_ALL Then
                    '位置変更
                    Call ChangePsItem(objLineValue, objLineFomula, objData, objFomulaOld)
                Else
                    For intCnt = ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG To ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12
                        objData(intCnt - 1) = objLineValue(1, intCnt)
                        objFomulaOld(intCnt) = objLineFomula(1, intCnt)
                    Next
                End If

                '-----------------------------------------------
                '式セット
                '-----------------------------------------------
                For intCnt = ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG To ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12
                    If (intCnt >= ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1 And intCnt <= ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20) Or
                        (intCnt >= ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1 And intCnt <= ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12) Then
                        If (intCnt >= (CommonVariable.PaymentPeriod + ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1) And
                            intCnt <= ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20) Or
                           (intCnt >= (intOldPaymentPeriod * 12 + ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1) And
                            intCnt <= ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12) Then
                            'Payment展開期間外の場合、初期値をセット
                            objData(intCnt - 1) = "0"
                        Else
                            If objData(ExcelWrite.ExcelPaymentLineColumn.PAY_FLAG - 1) = ExcelWrite.Payflg_Irregular Then
                                '変則の場合、そのままの値をセット
                                objData(intCnt - 1) = ExcelWrite.changeDBNullToString(objData(intCnt - 1))
                            Else
                                If (IsNothing(objFomulaOld(intCnt)) = False AndAlso objFomulaOld(intCnt).ToString.IndexOf("=") <> -1) And
                                    (IsNothing(objFomulaNew(intCnt)) = False AndAlso objFomulaNew(intCnt).ToString.IndexOf("=") <> -1) Then
                                    '変換元、変換先の両方が式の場合、変換先の式に置き換える
                                    objData(intCnt - 1) = objFomulaNew(intCnt).ToString.Replace("@", intRow.ToString)
                                Else
                                    '変換元、変換先の片方が式の場合、変換元の値をセット
                                    objData(intCnt - 1) = ExcelWrite.changeDBNullToString(objData(intCnt - 1))
                                End If
                            End If
                        End If

                    Else
                        '年額、月額展開以外の場合
                        If (IsNothing(objFomulaOld(intCnt)) = False AndAlso objFomulaOld(intCnt).ToString.IndexOf("=") <> -1) And
                            (IsNothing(objFomulaNew(intCnt)) = False AndAlso objFomulaNew(intCnt).ToString.IndexOf("=") <> -1) Then
                            '変換元、変換先の両方が式の場合、変換先の式に置き換える
                            objData(intCnt - 1) = objFomulaNew(intCnt).ToString.Replace("@", intRow.ToString)
                        Else
                            '変換元、変換先の片方が式の場合、変換元の値をセット
                            objData(intCnt - 1) = changeDataToString(objData(intCnt - 1))
                        End If
                    End If
                Next

                arPsData.Add(objData)

                intRow = intRow + 1
            Loop

            VersionUpPs = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "VersionUpPs")

        End Try

    End Function

    ''' <summary>
    ''' 機　能：詳細ｼｰﾄ変換処理
    ''' </summary>
    ''' <param name="ExcelSettingInfo">EXCEL設定情報</param>
    ''' <param name="strMethod"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function VersionUpDetail(ByRef xlSheet As Excel.Worksheet,
                                     ByRef arPsdData As ArrayList,
                                     ByVal ExcelSettingInfo As ExcelSetting,
                                     ByVal strMethod As String) As Boolean



        Dim strRange As String
        Dim intRow As Integer
        Dim objLineValue(,) As Object
        Dim objLineFomula(,) As Object
        Dim objFomulaNew(ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE) As Object
        Dim intCnt As Integer

        Dim blnRet As Boolean

        VersionUpDetail = False

        Try
            '-----------------------------------------------
            '詳細のデータ取得(変換元)
            '-----------------------------------------------
            intRow = ExcelSettingInfo.OldRowStart
            Do
                '１行取得（変換元の値）
                strRange = ExcelSettingInfo.OldValueRange.Replace("@", intRow.ToString)
                blnRet = GetCellValue(xlSheet, strRange, objLineValue)
                '１行取得（変換元の式）
                strRange = ExcelSettingInfo.OldValueRange.Replace("@", intRow.ToString)
                blnRet = GetCellFormula(xlSheet, strRange, objLineFomula)

                'ExcelのEOFの判定
                If ExcelWrite.changeDBNullToString(objLineValue(1, ExcelWrite.ExcelPaymentLineDetailColumn.SEQ)) = "" Then
                    Exit Do
                End If

                Dim objDataNew(ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE - 1) As Object
                For intCnt = ExcelWrite.ExcelPaymentLineDetailColumn.UPDATE_FLAG To ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE
                    If ExcelWrite.changeDBNullToString(objLineFomula(1, intCnt)).IndexOf("=") <> -1 Then
                        objDataNew(intCnt - 1) = ExcelWrite.changeDBNullToString(objLineFomula(1, intCnt))
                    Else
                        objDataNew(intCnt - 1) = changeDataToString(objLineValue(1, intCnt))
                    End If
                Next

                arPsdData.Add(objDataNew)

                intRow = intRow + 1
            Loop

            VersionUpDetail = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "VersionUpDetail")

        End Try

    End Function

    ''' <summary>
    ''' 機能：Paymentｼｰﾄにﾃﾞｰﾀを出力する
    ''' </summary>
    ''' <param name="arPsData"></param>
    ''' <param name="strExcelYear"></param>
    ''' <param name="strCsvPaht"></param>
    ''' <param name="strCreateDate"></param>
    ''' <param name="xlSheet"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function OutputExcelPs(ByVal arPsData As ArrayList,
                                   ByVal strExcelYear As String,
                                   ByVal strCsvPaht As String,
                                   ByVal strCreateDate As String,
                                   ByRef xlSheet As Excel.Worksheet) As Boolean

        Dim xlCell As Excel.Range = Nothing
        Dim xlEntireRow As Excel.Range = Nothing
        Dim xlRange As Excel.Range = Nothing

        Dim intSho As Integer
        Dim intAmari As Integer
        Dim intCnt As Integer
        Dim intOuntputCnt As Integer
        Dim strRange As String
        Dim strCsvFileName As String
        Dim oe As New OutputExcel
        Dim intDataType(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12 - 1) As Integer

        OutputExcelPs = False

        Try
            '-------------------------------------------------
            '開始年出力
            '-------------------------------------------------
            xlRange = xlSheet.Cells(4, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1)
            xlRange.Value = strExcelYear
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)

            intOuntputCnt = arPsData.Count
            If intOuntputCnt > 0 Then
                '-------------------------------------------------
                '罫線
                '-------------------------------------------------
                xlCell = xlSheet.Range(ROW_TOTAL_PS_NEW)
                xlEntireRow = xlCell.EntireRow
                xlEntireRow.Hidden = False
                ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)
                xlCell.Copy()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

                Const COPY_TEMPLATE_ROW As Integer = 5000

                intSho = intOuntputCnt \ COPY_TEMPLATE_ROW
                intAmari = intOuntputCnt Mod COPY_TEMPLATE_ROW

                For intCnt = 1 To intSho
                    strRange = (ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW).ToString() + (intCnt - 1) * COPY_TEMPLATE_ROW & ":" & (ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + intCnt * COPY_TEMPLATE_ROW - 1).ToString()
                    xlRange = xlSheet.Range(strRange)
                    xlRange.PasteSpecial()
                    ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                Next
                If intAmari > 0 Then
                    strRange = (ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW).ToString() + (intCnt - 1) * COPY_TEMPLATE_ROW & ":" & (ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + (intCnt - 1) * COPY_TEMPLATE_ROW + intAmari - 1).ToString()
                    xlRange = xlSheet.Range(strRange)
                    xlRange.PasteSpecial()
                    ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                End If

                xlCell = xlSheet.Range(ROW_TOTAL_PS_NEW)
                xlEntireRow = xlCell.EntireRow
                xlEntireRow.Hidden = True
                ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

                '-------------------------------------------------
                'データ出力
                '-------------------------------------------------
                '中間ファイル作成
                strCsvFileName = strCsvPaht & "WorkCsv_Ps" & strCreateDate & ".csv"
                Call oe.arDataToCsv(arPsData, strCsvFileName)
                'ﾃｷｽﾄﾌｧｲﾙをExcelﾌｧｲﾙに読み込ませる
                Call ExcelWrite.SetExcelDataTypePayment(intDataType)
                Call ExcelWrite.LoadCsvToExcel(strCsvFileName, 1, "Payment", "A6", xlSheet, intDataType)
            End If

            OutputExcelPs = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "OutputExcelPs")

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)

        End Try

    End Function

    ''' <summary>
    ''' 機能：詳細ｼｰﾄにﾃﾞｰﾀを出力する
    ''' </summary>
    ''' <param name="arPsdData"></param>
    ''' <param name="strCsvPaht"></param>
    ''' <param name="strCreateDate"></param>
    ''' <param name="xlSheet"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function OutputExcelPsd(ByVal arPsdData As ArrayList,
                                    ByVal strCsvPaht As String,
                                    ByVal strCreateDate As String,
                                    ByRef xlSheet As Excel.Worksheet) As Boolean

        Dim intSho As Integer
        Dim intAmari As Integer
        Dim intCnt As Integer
        Dim intOuntputCnt As Integer
        Dim strCsvFileName As String
        Dim oe As New OutputExcel
        Dim strRange As String
        Dim intDataType(ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE - 1) As Integer

        Dim xlRange As Excel.Range = Nothing
        Dim xlCell As Excel.Range = Nothing
        Dim xlEntireRow As Excel.Range = Nothing

        OutputExcelPsd = False

        Try
            If arPsdData.Count > 0 Then
                '-------------------------------------------------
                '罫線作成
                '-------------------------------------------------
                'Template行表示
                xlCell = xlSheet.Range(ROW_SAMPLE_DETAIL_NEW)
                xlEntireRow = xlCell.EntireRow
                xlEntireRow.Hidden = False
                ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)
                xlCell.Copy()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

                Const COPY_TEMPLATE_ROW As Integer = 1000

                intOuntputCnt = arPsdData.Count
                intSho = intOuntputCnt \ COPY_TEMPLATE_ROW
                intAmari = intOuntputCnt Mod COPY_TEMPLATE_ROW

                For intCnt = 1 To intSho
                    strRange = (ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW).ToString() + (intCnt - 1) * COPY_TEMPLATE_ROW & ":" & (ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW + intCnt * COPY_TEMPLATE_ROW - 1).ToString()
                    xlRange = xlSheet.Range(strRange)
                    xlRange.PasteSpecial()
                    ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                Next
                If intAmari > 0 Then
                    strRange = (ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW).ToString() + (intCnt - 1) * COPY_TEMPLATE_ROW & ":" & (ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW + (intCnt - 1) * COPY_TEMPLATE_ROW + intAmari - 1).ToString()
                    xlRange = xlSheet.Range(strRange)
                    xlRange.PasteSpecial()
                    ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                End If

                xlCell = xlSheet.Range(ROW_SAMPLE_DETAIL_NEW)
                xlEntireRow = xlCell.EntireRow
                xlEntireRow.Hidden = True
                ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

                '-------------------------------------------------
                'データ出力
                '-------------------------------------------------
                '中間ファイル作成
                strCsvFileName = strCsvPaht & "WorkCsv_Psd" & strCreateDate & ".csv"
                Call oe.arDataToCsv(arPsdData, strCsvFileName)
                'ﾃｷｽﾄﾌｧｲﾙをExcelﾌｧｲﾙに読み込ませる
                Call ExcelWrite.SetExcelDataTypeDetail(intDataType)
                Call ExcelWrite.LoadCsvToExcel(strCsvFileName, 1, "詳細", "A7", xlSheet, intDataType)
            End If

            OutputExcelPsd = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "OutputExcelPsd")

        Finally
            'エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            'ガベージコレクトの起動
            GC.Collect()

        End Try

    End Function

    ''' <summary>
    ''' 機能：Paymentの計算式を配列にセット
    ''' </summary>
    ''' <param name="pfi"></param>
    ''' <param name="objFomula"></param>
    ''' <remarks></remarks>
    Private Sub SetPsFomulaObject(ByVal pfi As PaymentLineFomulateInfo,
                                  ByRef objFomula() As Object)

        Try
            '更新FLG	
            If pfi.UPDATE_FLAG <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG) = pfi.UPDATE_FLAG
            End If

            'ﾛｯｸFLG	
            If pfi.LOCK_FLAG <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG) = pfi.LOCK_FLAG
            End If

            '有効/無効	
            If pfi.VALID_FLAG <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG) = pfi.VALID_FLAG
            End If

            'NO	
            If pfi.LINE_NO <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.LINE_NO) = pfi.LINE_NO
            End If

            'ﾌｧｲﾙ名	
            If pfi.FILE_NAME <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.FILE_NAME) = pfi.FILE_NAME
            End If

            'ﾌｧｲﾙ名Suffix	
            If pfi.FILE_NAME_SUFFIX <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX) = pfi.FILE_NAME_SUFFIX
            End If

            'ﾌｧｲﾙ内Suffix	
            If pfi.FILE_NAME_SUFFIX_INTR <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR) = pfi.FILE_NAME_SUFFIX_INTR
            End If

            '契約順番	
            If pfi.CONTRACT <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.CONTRACT) = pfi.CONTRACT
            End If

            'COST_開示依頼	
            If pfi.ST_COST <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.ST_COST) = pfi.ST_COST
            End If

            '価格承認_申請依頼	
            If pfi.ST_APPROVAL <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.ST_APPROVAL) = pfi.ST_APPROVAL
            End If

            '案件番号	
            If pfi.PROJ_ID <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PROJ_ID) = pfi.PROJ_ID
            End If

            '契約通番	
            If pfi.CONTRACT_SEQ <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.CONTRACT_SEQ) = pfi.CONTRACT_SEQ
            End If

            '新規/既存	
            If pfi.NEW_EXIST <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.NEW_EXIST) = pfi.NEW_EXIST
            End If

            'お客様集計ｶﾃｺﾞﾘ	
            If pfi.CUST_CATEGORY <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.CUST_CATEGORY) = pfi.CUST_CATEGORY
            End If

            '業務ﾒﾓ情報	
            If pfi.LETTER_PLAN_DATE <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.LETTER_PLAN_DATE) = pfi.LETTER_PLAN_DATE
            End If

            '実行通知書_受領日	
            If pfi.LETTER_ACCEPT_DATE <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.LETTER_ACCEPT_DATE) = pfi.LETTER_ACCEPT_DATE
            End If

            '発注完了日	
            If pfi.ORDER_DATE <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.ORDER_DATE) = pfi.ORDER_DATE
            End If

            '実行通知書番号	
            If pfi.LETTER_ID <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.LETTER_ID) = pfi.LETTER_ID
            End If

            '請求品目ｺｰﾄﾞ
            If pfi.ORDERCODE <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.ORDERCODE) = pfi.ORDERCODE
            End If

            'Brand Category_BU	
            If pfi.BU <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.BU) = pfi.BU
            End If

            'Brand Category_Brand	
            If pfi.BRAND <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.BRAND) = pfi.BRAND
            End If

            'Brand Category_ｻﾏﾘｰ用ｶﾃｺﾞﾘ	
            If pfi.SUM_CATEGORY <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.SUM_CATEGORY) = pfi.SUM_CATEGORY
            End If

            'Brand Category_SubBrand	
            If pfi.BRAND_SUB <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.BRAND_SUB) = pfi.BRAND_SUB
            End If

            'Brand Category_Option1	
            If pfi.OP1 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.OP1) = pfi.OP1
            End If

            'Brand Category_Option2	
            If pfi.OP2 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.OP2) = pfi.OP2
            End If

            'Brand Category_Size	
            If pfi.BRAND_SIZE <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.BRAND_SIZE) = pfi.BRAND_SIZE
            End If

            'Brand Category_SBO制限	
            If pfi.NON_SBO <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.NON_SBO) = pfi.NON_SBO
            End If

            'Brand Category_追記事項
            If pfi.POSTSCRIPT <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.POSTSCRIPT) = pfi.POSTSCRIPT
            End If

            'Brand承認_TOPACS CPNO	
            If pfi.TOPACS_CPNO <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.TOPACS_CPNO) = pfi.TOPACS_CPNO
            End If

            'Brand承認_起票番号	
            If pfi.BRAND_AP_FORM <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_FORM) = pfi.BRAND_AP_FORM
            End If

            'Brand承認_申請番号	
            If pfi.BRAND_AP_REQ <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_REQ) = pfi.BRAND_AP_REQ
            End If

            'Brand承認_承認番号	
            If pfi.BRAND_AP_CONF <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_CONF) = pfi.BRAND_AP_CONF
            End If

            '入力項目ﾊﾟﾀｰﾝ SEQ	
            If pfi.PATTERN_CD <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD) = pfi.PATTERN_CD
            End If

            '入力項目ﾊﾟﾀｰﾝ	
            If pfi.PATTERN <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PATTERN) = pfi.PATTERN
            End If

            'ﾊﾟﾀｰﾝ別入力項目_項目１	
            If pfi.PROD_ITEM01 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01) = pfi.PROD_ITEM01
            End If

            'ﾊﾟﾀｰﾝ別入力項目_項目２	
            If pfi.PROD_ITEM02 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02) = pfi.PROD_ITEM02
            End If

            'ﾊﾟﾀｰﾝ別入力項目_項目３	
            If pfi.PROD_ITEM03 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03) = pfi.PROD_ITEM03
            End If

            'ﾊﾟﾀｰﾝ別入力項目_項目４	
            If pfi.PROD_ITEM04 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM04) = pfi.PROD_ITEM04
            End If

            'ﾊﾟﾀｰﾝ別入力項目_項目５	
            If pfi.PROD_ITEM05 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM05) = pfi.PROD_ITEM05
            End If

            'ﾊﾟﾀｰﾝ別入力項目_項目６	
            If pfi.PROD_ITEM06 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM06) = pfi.PROD_ITEM06
            End If

            'ﾊﾟﾀｰﾝ別入力項目_項目７	
            If pfi.PROD_ITEM07 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM07) = pfi.PROD_ITEM07
            End If

            'ﾊﾟﾀｰﾝ別入力項目_項目８	
            If pfi.PROD_ITEM08 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM08) = pfi.PROD_ITEM08
            End If

            'ﾊﾟﾀｰﾝ別入力項目_項目９	
            If pfi.PROD_ITEM09 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM09) = pfi.PROD_ITEM09
            End If

            'ﾊﾟﾀｰﾝ別入力項目_項目１０	
            If pfi.PROD_ITEM10 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10) = pfi.PROD_ITEM10
            End If

            'ﾊﾟﾀｰﾝ別入力項目11
            If pfi.PROD_ITEM11 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11) = pfi.PROD_ITEM11
            End If

            'ﾊﾟﾀｰﾝ別入力項目12
            If pfi.PROD_ITEM12 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12) = pfi.PROD_ITEM12
            End If

            'ﾊﾟﾀｰﾝ別入力項目13
            If pfi.PROD_ITEM13 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM13) = pfi.PROD_ITEM13
            End If

            'ﾊﾟﾀｰﾝ別入力項目14
            If pfi.PROD_ITEM14 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM14) = pfi.PROD_ITEM14
            End If

            'ﾊﾟﾀｰﾝ別入力項目15
            If pfi.PROD_ITEM15 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM15) = pfi.PROD_ITEM15
            End If

            'ﾊﾟﾀｰﾝ別入力項目16
            If pfi.PROD_ITEM16 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM16) = pfi.PROD_ITEM16
            End If

            'ﾊﾟﾀｰﾝ別入力項目17
            If pfi.PROD_ITEM17 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM17) = pfi.PROD_ITEM17
            End If

            'ﾊﾟﾀｰﾝ別入力項目18
            If pfi.PROD_ITEM18 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM18) = pfi.PROD_ITEM18
            End If

            'ﾊﾟﾀｰﾝ別入力項目19
            If pfi.PROD_ITEM19 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM19) = pfi.PROD_ITEM19
            End If

            'ﾊﾟﾀｰﾝ別入力項目20
            If pfi.PROD_ITEM20 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM20) = pfi.PROD_ITEM20
            End If

            'ﾊﾟﾀｰﾝ別入力項目22
            If pfi.PROD_ITEM22 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM22) = pfi.PROD_ITEM22
            End If

            'ﾊﾟﾀｰﾝ別入力項目23
            If pfi.PROD_ITEM23 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM23) = pfi.PROD_ITEM23
            End If

            'ﾊﾟﾀｰﾝ別入力項目24
            If pfi.PROD_ITEM24 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM24) = pfi.PROD_ITEM24
            End If

            '製品･ｻｰﾋﾞｽ廃止発表日	
            If pfi.WD_ANNT_DATE <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.WD_ANNT_DATE) = pfi.WD_ANNT_DATE
            End If

            '製品･ｻｰﾋﾞｽ廃止予定	
            If pfi.WD_DATE <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.WD_DATE) = pfi.WD_DATE
            End If

            '価格改定予定日	
            If pfi.PRICE_CHG_DATE <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_CHG_DATE) = pfi.PRICE_CHG_DATE
            End If

            '数量	
            If pfi.QTY <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.QTY) = pfi.QTY
            End If

            '導入_年月
            If pfi.INST_DATE <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.INST_DATE) = pfi.INST_DATE
            End If

            '元本計算・開始_年月
            If pfi.PAY_START_DATE <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE) = pfi.PAY_START_DATE
            End If

            '元本計算・終了_年月
            If pfi.PAY_END_DATE <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE) = pfi.PAY_END_DATE
            End If

            'Payment展開
            If pfi.PAY_FLAG <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PAY_FLAG) = pfi.PAY_FLAG
            End If

            '定額BID
            If pfi.BID_FLAG <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.BID_FLAG) = pfi.BID_FLAG
            End If

            '請求期間	
            If pfi.PAY_MONTHS <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PAY_MONTHS) = pfi.PAY_MONTHS
            End If

            'Validation 
            If pfi.PAY_VALIDATION <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PAY_VALIDATION) = pfi.PAY_VALIDATION
            End If

            '支払方法	
            If pfi.PAY_METHOD <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD) = pfi.PAY_METHOD
            End If

            'IGF_対象	
            If pfi.IGF_APPLIED <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.IGF_APPLIED) = pfi.IGF_APPLIED
            End If

            'IGF契約番号	
            If pfi.IGF_CONT_NO <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_NO) = pfi.IGF_CONT_NO
            End If

            'IGF契約形態
            If pfi.IGF_CONT_FORM <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_FORM) = pfi.IGF_CONT_FORM
            End If

            'IGF物件管理
            If pfi.IGF_CONT_MANAGMENT <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_MANAGMENT) = pfi.IGF_CONT_MANAGMENT
            End If

            'IGF_IOC料率	
            If pfi.IGF_RATE_IOC <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.IGF_RATE_IOC) = pfi.IGF_RATE_IOC
            End If

            'Listprice(単価)_提案時	
            If pfi.LIST_PRICE_PROPOSAL <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL) = pfi.LIST_PRICE_PROPOSAL
            End If

            'Listprice(単価)_ﾘﾌﾚｯｼｭ後	
            If pfi.LIST_PRICE_REFLESH <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH) = pfi.LIST_PRICE_REFLESH
            End If

            'Listprice(合計)_提案時	
            If pfi.LIST_PRICE_TOTAL_PROPOSAL <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_PROPOSAL) = pfi.LIST_PRICE_TOTAL_PROPOSAL
            End If

            'Listprice(合計)_ﾘﾌﾚｯｼｭ後	
            If pfi.LIST_PRICE_TOTAL_REFLESH <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH) = pfi.LIST_PRICE_TOTAL_REFLESH
            End If

            'IOC D%	
            If pfi.DP_IOC <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.DP_IOC) = pfi.DP_IOC
            End If

            'Offering Price_単価Validation前
            If pfi.PRICE_UNIT_IOC <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC) = pfi.PRICE_UNIT_IOC
            End If

            'Offering Price 単価Validation後
            If pfi.PRICE_UNIT_IOC_VAL <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC_VAL) = pfi.PRICE_UNIT_IOC_VAL
            End If

            'Offering Price_小計	
            If pfi.PRICE_QTY_IOC <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC) = pfi.PRICE_QTY_IOC
            End If

            'COST %	
            If pfi.COST_RATE <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.COST_RATE) = pfi.COST_RATE
            End If

            'COST_単価	
            If pfi.COST <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.COST) = pfi.COST
            End If

            'COST_合計	
            If pfi.COST_TOTAL <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.COST_TOTAL) = pfi.COST_TOTAL
            End If

            'COST_入力日	
            If pfi.COST_INPUT_DATE <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.COST_INPUT_DATE) = pfi.COST_INPUT_DATE
            End If

            '展開金額
            If pfi.PRICE_TO_SPLIT <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_TO_SPLIT) = pfi.PRICE_TO_SPLIT
            End If

            'Listprice_期間合計	
            If pfi.LIST_PRICE_TOTAL_IOC <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_IOC) = pfi.LIST_PRICE_TOTAL_IOC
            End If

            'D%適用後_期間合計	
            If pfi.PRICE_TOTAL_IOC <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_TOTAL_IOC) = pfi.PRICE_TOTAL_IOC
            End If

            'COST_期間合計	
            If pfi.COST_TOTAL_IOC <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.COST_TOTAL_IOC) = pfi.COST_TOTAL_IOC
            End If

            'IGF適用後 期間合計
            If pfi.PRICE_IGF_TOTAL <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_TOTAL_IGF) = pfi.PRICE_IGF_TOTAL
            End If

            '契約期間内
            If pfi.PRICE_CONT_TOTAL <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.CONTRACT_IN) = pfi.PRICE_CONT_TOTAL
            End If

            '契約期間外
            If pfi.PRICE_OO_CONT_TOTAL <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.CONTRACT_OUT) = pfi.PRICE_OO_CONT_TOTAL
            End If

            'IGF金利(差額)
            If pfi.IGF_DIF_INTEREST <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_DEFF_IGF) = pfi.IGF_DIF_INTEREST
            End If

            '年度情報1	
            If pfi.PRICE_YEAR1 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1) = pfi.PRICE_YEAR1
            End If

            '年度情報2	
            If pfi.PRICE_YEAR2 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2) = pfi.PRICE_YEAR2
            End If

            '年度情報3	
            If pfi.PRICE_YEAR3 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3) = pfi.PRICE_YEAR3
            End If

            '年度情報4	
            If pfi.PRICE_YEAR4 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4) = pfi.PRICE_YEAR4
            End If

            '年度情報5	
            If pfi.PRICE_YEAR5 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5) = pfi.PRICE_YEAR5
            End If

            '年度情報6	
            If pfi.PRICE_YEAR6 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6) = pfi.PRICE_YEAR6
            End If

            '年度情報7	
            If pfi.PRICE_YEAR7 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7) = pfi.PRICE_YEAR7
            End If

            '年度情報8	
            If pfi.PRICE_YEAR8 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8) = pfi.PRICE_YEAR8
            End If

            '年度情報9	
            If pfi.PRICE_YEAR9 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9) = pfi.PRICE_YEAR9
            End If

            '年度情報10	
            If pfi.PRICE_YEAR10 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10) = pfi.PRICE_YEAR10
            End If

            '年度情報11	
            If pfi.PRICE_YEAR11 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11) = pfi.PRICE_YEAR11
            End If

            '年度情報12	
            If pfi.PRICE_YEAR12 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12) = pfi.PRICE_YEAR12
            End If

            '年度情報13	
            If pfi.PRICE_YEAR13 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13) = pfi.PRICE_YEAR13
            End If

            '年度情報14	
            If pfi.PRICE_YEAR14 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14) = pfi.PRICE_YEAR14
            End If

            '年度情報15	
            If pfi.PRICE_YEAR15 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15) = pfi.PRICE_YEAR15
            End If

            '年度情報16	
            If pfi.PRICE_YEAR16 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16) = pfi.PRICE_YEAR16
            End If

            '年度情報17	
            If pfi.PRICE_YEAR17 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17) = pfi.PRICE_YEAR17
            End If

            '年度情報18	
            If pfi.PRICE_YEAR18 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18) = pfi.PRICE_YEAR18
            End If

            '年度情報19	
            If pfi.PRICE_YEAR19 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19) = pfi.PRICE_YEAR19
            End If

            '年度情報20	
            If pfi.PRICE_YEAR20 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20) = pfi.PRICE_YEAR20
            End If

            '過去の契約金額合計
            If pfi.PAST_PRICE_TOTAL <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL) = pfi.PAST_PRICE_TOTAL
            End If

            'IGF金利以外、年度情報に式をセット
            '年度1_月度情報1	
            If pfi.PRICE_YEAR1_MONTH1 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1) = pfi.PRICE_YEAR1_MONTH1
            End If

            '年度1_月度情報2	
            If pfi.PRICE_YEAR1_MONTH2 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH2) = pfi.PRICE_YEAR1_MONTH2
            End If

            '年度1_月度情報3	
            If pfi.PRICE_YEAR1_MONTH3 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH3) = pfi.PRICE_YEAR1_MONTH3
            End If

            '年度1_月度情報4	
            If pfi.PRICE_YEAR1_MONTH4 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH4) = pfi.PRICE_YEAR1_MONTH4
            End If

            '年度1_月度情報5	
            If pfi.PRICE_YEAR1_MONTH5 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH5) = pfi.PRICE_YEAR1_MONTH5
            End If

            '年度1_月度情報6	
            If pfi.PRICE_YEAR1_MONTH6 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH6) = pfi.PRICE_YEAR1_MONTH6
            End If

            '年度1_月度情報7	
            If pfi.PRICE_YEAR1_MONTH7 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH7) = pfi.PRICE_YEAR1_MONTH7
            End If

            '年度1_月度情報8	
            If pfi.PRICE_YEAR1_MONTH8 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH8) = pfi.PRICE_YEAR1_MONTH8
            End If

            '年度1_月度情報9	
            If pfi.PRICE_YEAR1_MONTH9 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH9) = pfi.PRICE_YEAR1_MONTH9
            End If

            '年度1_月度情報10	
            If pfi.PRICE_YEAR1_MONTH10 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH10) = pfi.PRICE_YEAR1_MONTH10
            End If

            '年度1_月度情報11	
            If pfi.PRICE_YEAR1_MONTH11 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH11) = pfi.PRICE_YEAR1_MONTH11
            End If

            '年度1_月度情報12	
            If pfi.PRICE_YEAR1_MONTH12 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH12) = pfi.PRICE_YEAR1_MONTH12
            End If

            '年度2_月度情報1	
            If pfi.PRICE_YEAR2_MONTH1 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH1) = pfi.PRICE_YEAR2_MONTH1
            End If

            '年度2_月度情報2	
            If pfi.PRICE_YEAR2_MONTH2 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH2) = pfi.PRICE_YEAR2_MONTH2
            End If

            '年度2_月度情報3	
            If pfi.PRICE_YEAR2_MONTH3 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH3) = pfi.PRICE_YEAR2_MONTH3
            End If

            '年度2_月度情報4	
            If pfi.PRICE_YEAR2_MONTH4 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH4) = pfi.PRICE_YEAR2_MONTH4
            End If

            '年度2_月度情報5	
            If pfi.PRICE_YEAR2_MONTH5 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH5) = pfi.PRICE_YEAR2_MONTH5
            End If

            '年度2_月度情報6	
            If pfi.PRICE_YEAR2_MONTH6 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH6) = pfi.PRICE_YEAR2_MONTH6
            End If

            '年度2_月度情報7	
            If pfi.PRICE_YEAR2_MONTH7 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH7) = pfi.PRICE_YEAR2_MONTH7
            End If

            '年度2_月度情報8	
            If pfi.PRICE_YEAR2_MONTH8 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH8) = pfi.PRICE_YEAR2_MONTH8
            End If

            '年度2_月度情報9	
            If pfi.PRICE_YEAR2_MONTH9 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH9) = pfi.PRICE_YEAR2_MONTH9
            End If

            '年度2_月度情報10	
            If pfi.PRICE_YEAR2_MONTH10 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH10) = pfi.PRICE_YEAR2_MONTH10
            End If

            '年度2_月度情報11	
            If pfi.PRICE_YEAR2_MONTH11 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH11) = pfi.PRICE_YEAR2_MONTH11
            End If

            '年度2_月度情報12	
            If pfi.PRICE_YEAR2_MONTH12 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH12) = pfi.PRICE_YEAR2_MONTH12
            End If

            '年度3_月度情報1	
            If pfi.PRICE_YEAR3_MONTH1 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH1) = pfi.PRICE_YEAR3_MONTH1
            End If

            '年度3_月度情報2	
            If pfi.PRICE_YEAR3_MONTH2 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH2) = pfi.PRICE_YEAR3_MONTH2
            End If

            '年度3_月度情報3	
            If pfi.PRICE_YEAR3_MONTH3 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH3) = pfi.PRICE_YEAR3_MONTH3
            End If

            '年度3_月度情報4	
            If pfi.PRICE_YEAR3_MONTH4 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH4) = pfi.PRICE_YEAR3_MONTH4
            End If

            '年度3_月度情報5	
            If pfi.PRICE_YEAR3_MONTH5 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH5) = pfi.PRICE_YEAR3_MONTH5
            End If

            '年度3_月度情報6	
            If pfi.PRICE_YEAR3_MONTH6 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH6) = pfi.PRICE_YEAR3_MONTH6
            End If

            '年度3_月度情報7	
            If pfi.PRICE_YEAR3_MONTH7 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH7) = pfi.PRICE_YEAR3_MONTH7
            End If

            '年度3_月度情報8	
            If pfi.PRICE_YEAR3_MONTH8 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH8) = pfi.PRICE_YEAR3_MONTH8
            End If

            '年度3_月度情報9	
            If pfi.PRICE_YEAR3_MONTH9 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH9) = pfi.PRICE_YEAR3_MONTH9
            End If

            '年度3_月度情報10	
            If pfi.PRICE_YEAR3_MONTH10 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH10) = pfi.PRICE_YEAR3_MONTH10
            End If

            '年度3_月度情報11	
            If pfi.PRICE_YEAR3_MONTH11 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH11) = pfi.PRICE_YEAR3_MONTH11
            End If

            '年度3_月度情報12	
            If pfi.PRICE_YEAR3_MONTH12 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH12) = pfi.PRICE_YEAR3_MONTH12
            End If

            '年度4_月度情報1	
            If pfi.PRICE_YEAR4_MONTH1 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH1) = pfi.PRICE_YEAR4_MONTH1
            End If

            '年度4_月度情報2	
            If pfi.PRICE_YEAR4_MONTH2 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH2) = pfi.PRICE_YEAR4_MONTH2
            End If

            '年度4_月度情報3	
            If pfi.PRICE_YEAR4_MONTH3 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH3) = pfi.PRICE_YEAR4_MONTH3
            End If

            '年度4_月度情報4	
            If pfi.PRICE_YEAR4_MONTH4 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH4) = pfi.PRICE_YEAR4_MONTH4
            End If

            '年度4_月度情報5	
            If pfi.PRICE_YEAR4_MONTH5 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH5) = pfi.PRICE_YEAR4_MONTH5
            End If

            '年度4_月度情報6	
            If pfi.PRICE_YEAR4_MONTH6 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH6) = pfi.PRICE_YEAR4_MONTH6
            End If

            '年度4_月度情報7	
            If pfi.PRICE_YEAR4_MONTH7 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH7) = pfi.PRICE_YEAR4_MONTH7
            End If

            '年度4_月度情報8	
            If pfi.PRICE_YEAR4_MONTH8 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH8) = pfi.PRICE_YEAR4_MONTH8
            End If

            '年度4_月度情報9	
            If pfi.PRICE_YEAR4_MONTH9 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH9) = pfi.PRICE_YEAR4_MONTH9
            End If

            '年度4_月度情報10	
            If pfi.PRICE_YEAR4_MONTH10 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH10) = pfi.PRICE_YEAR4_MONTH10
            End If

            '年度4_月度情報11	
            If pfi.PRICE_YEAR4_MONTH11 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH11) = pfi.PRICE_YEAR4_MONTH11
            End If

            '年度4_月度情報12	
            If pfi.PRICE_YEAR4_MONTH12 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH12) = pfi.PRICE_YEAR4_MONTH12
            End If

            '年度5_月度情報1	
            If pfi.PRICE_YEAR5_MONTH1 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH1) = pfi.PRICE_YEAR5_MONTH1
            End If

            '年度5_月度情報2	
            If pfi.PRICE_YEAR5_MONTH2 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH2) = pfi.PRICE_YEAR5_MONTH2
            End If

            '年度5_月度情報3	
            If pfi.PRICE_YEAR5_MONTH3 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH3) = pfi.PRICE_YEAR5_MONTH3
            End If

            '年度5_月度情報4	
            If pfi.PRICE_YEAR5_MONTH4 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH4) = pfi.PRICE_YEAR5_MONTH4
            End If

            '年度5_月度情報5	
            If pfi.PRICE_YEAR5_MONTH5 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH5) = pfi.PRICE_YEAR5_MONTH5
            End If

            '年度5_月度情報6	
            If pfi.PRICE_YEAR5_MONTH6 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH6) = pfi.PRICE_YEAR5_MONTH6
            End If

            '年度5_月度情報7	
            If pfi.PRICE_YEAR5_MONTH7 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH7) = pfi.PRICE_YEAR5_MONTH7
            End If

            '年度5_月度情報8	
            If pfi.PRICE_YEAR5_MONTH8 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH8) = pfi.PRICE_YEAR5_MONTH8
            End If

            '年度5_月度情報9	
            If pfi.PRICE_YEAR5_MONTH9 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH9) = pfi.PRICE_YEAR5_MONTH9
            End If

            '年度5_月度情報10	
            If pfi.PRICE_YEAR5_MONTH10 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH10) = pfi.PRICE_YEAR5_MONTH10
            End If

            '年度5_月度情報11	
            If pfi.PRICE_YEAR5_MONTH11 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH11) = pfi.PRICE_YEAR5_MONTH11
            End If

            '年度5_月度情報12	
            If pfi.PRICE_YEAR5_MONTH12 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH12) = pfi.PRICE_YEAR5_MONTH12
            End If

            '年度6_月度情報1	
            If pfi.PRICE_YEAR6_MONTH1 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH1) = pfi.PRICE_YEAR6_MONTH1
            End If

            '年度6_月度情報2	
            If pfi.PRICE_YEAR6_MONTH2 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH2) = pfi.PRICE_YEAR6_MONTH2
            End If

            '年度6_月度情報3	
            If pfi.PRICE_YEAR6_MONTH3 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH3) = pfi.PRICE_YEAR6_MONTH3
            End If

            '年度6_月度情報4	
            If pfi.PRICE_YEAR6_MONTH4 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH4) = pfi.PRICE_YEAR6_MONTH4
            End If

            '年度6_月度情報5	
            If pfi.PRICE_YEAR6_MONTH5 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH5) = pfi.PRICE_YEAR6_MONTH5
            End If

            '年度6_月度情報6	
            If pfi.PRICE_YEAR6_MONTH6 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH6) = pfi.PRICE_YEAR6_MONTH6
            End If

            '年度6_月度情報7	
            If pfi.PRICE_YEAR6_MONTH7 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH7) = pfi.PRICE_YEAR6_MONTH7
            End If

            '年度6_月度情報8	
            If pfi.PRICE_YEAR6_MONTH8 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH8) = pfi.PRICE_YEAR6_MONTH8
            End If

            '年度6_月度情報9	
            If pfi.PRICE_YEAR6_MONTH9 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH9) = pfi.PRICE_YEAR6_MONTH9
            End If

            '年度6_月度情報10	
            If pfi.PRICE_YEAR6_MONTH10 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH10) = pfi.PRICE_YEAR6_MONTH10
            End If

            '年度6_月度情報11	
            If pfi.PRICE_YEAR6_MONTH11 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH11) = pfi.PRICE_YEAR6_MONTH11
            End If

            '年度6_月度情報12	
            If pfi.PRICE_YEAR6_MONTH12 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH12) = pfi.PRICE_YEAR6_MONTH12
            End If

            '年度7_月度情報1	
            If pfi.PRICE_YEAR7_MONTH1 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH1) = pfi.PRICE_YEAR7_MONTH1
            End If

            '年度7_月度情報2	
            If pfi.PRICE_YEAR7_MONTH2 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH2) = pfi.PRICE_YEAR7_MONTH2
            End If

            '年度7_月度情報3	
            If pfi.PRICE_YEAR7_MONTH3 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH3) = pfi.PRICE_YEAR7_MONTH3
            End If

            '年度7_月度情報4	
            If pfi.PRICE_YEAR7_MONTH4 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH4) = pfi.PRICE_YEAR7_MONTH4
            End If

            '年度7_月度情報5	
            If pfi.PRICE_YEAR7_MONTH5 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH5) = pfi.PRICE_YEAR7_MONTH5
            End If

            '年度7_月度情報6	
            If pfi.PRICE_YEAR7_MONTH6 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH6) = pfi.PRICE_YEAR7_MONTH6
            End If

            '年度7_月度情報7	
            If pfi.PRICE_YEAR7_MONTH7 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH7) = pfi.PRICE_YEAR7_MONTH7
            End If

            '年度7_月度情報8	
            If pfi.PRICE_YEAR7_MONTH8 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH8) = pfi.PRICE_YEAR7_MONTH8
            End If

            '年度7_月度情報9	
            If pfi.PRICE_YEAR7_MONTH9 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH9) = pfi.PRICE_YEAR7_MONTH9
            End If

            '年度7_月度情報10	
            If pfi.PRICE_YEAR7_MONTH10 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH10) = pfi.PRICE_YEAR7_MONTH10
            End If

            '年度7_月度情報11	
            If pfi.PRICE_YEAR7_MONTH11 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH11) = pfi.PRICE_YEAR7_MONTH11
            End If

            '年度7_月度情報12	
            If pfi.PRICE_YEAR7_MONTH12 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH12) = pfi.PRICE_YEAR7_MONTH12
            End If

            '年度8_月度情報1	
            If pfi.PRICE_YEAR8_MONTH1 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH1) = pfi.PRICE_YEAR8_MONTH1
            End If

            '年度8_月度情報2	
            If pfi.PRICE_YEAR8_MONTH2 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH2) = pfi.PRICE_YEAR8_MONTH2
            End If

            '年度8_月度情報3	
            If pfi.PRICE_YEAR8_MONTH3 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH3) = pfi.PRICE_YEAR8_MONTH3
            End If

            '年度8_月度情報4	
            If pfi.PRICE_YEAR8_MONTH4 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH4) = pfi.PRICE_YEAR8_MONTH4
            End If

            '年度8_月度情報5	
            If pfi.PRICE_YEAR8_MONTH5 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH5) = pfi.PRICE_YEAR8_MONTH5
            End If

            '年度8_月度情報6	
            If pfi.PRICE_YEAR8_MONTH6 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH6) = pfi.PRICE_YEAR8_MONTH6
            End If

            '年度8_月度情報7	
            If pfi.PRICE_YEAR8_MONTH7 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH7) = pfi.PRICE_YEAR8_MONTH7
            End If

            '年度8_月度情報8	
            If pfi.PRICE_YEAR8_MONTH8 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH8) = pfi.PRICE_YEAR8_MONTH8
            End If

            '年度8_月度情報9	
            If pfi.PRICE_YEAR8_MONTH9 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH9) = pfi.PRICE_YEAR8_MONTH9
            End If

            '年度8_月度情報10	
            If pfi.PRICE_YEAR8_MONTH10 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH10) = pfi.PRICE_YEAR8_MONTH10
            End If

            '年度8_月度情報11	
            If pfi.PRICE_YEAR8_MONTH11 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH11) = pfi.PRICE_YEAR8_MONTH11
            End If

            '年度8_月度情報12	
            If pfi.PRICE_YEAR8_MONTH12 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH12) = pfi.PRICE_YEAR8_MONTH12
            End If

            '年度9_月度情報1	
            If pfi.PRICE_YEAR9_MONTH1 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH1) = pfi.PRICE_YEAR9_MONTH1
            End If

            '年度9_月度情報2	
            If pfi.PRICE_YEAR9_MONTH2 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH2) = pfi.PRICE_YEAR9_MONTH2
            End If

            '年度9_月度情報3	
            If pfi.PRICE_YEAR9_MONTH3 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH3) = pfi.PRICE_YEAR9_MONTH3
            End If

            '年度9_月度情報4	
            If pfi.PRICE_YEAR9_MONTH4 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH4) = pfi.PRICE_YEAR9_MONTH4
            End If

            '年度9_月度情報5	
            If pfi.PRICE_YEAR9_MONTH5 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH5) = pfi.PRICE_YEAR9_MONTH5
            End If

            '年度9_月度情報6	
            If pfi.PRICE_YEAR9_MONTH6 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH6) = pfi.PRICE_YEAR9_MONTH6
            End If

            '年度9_月度情報7	
            If pfi.PRICE_YEAR9_MONTH7 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH7) = pfi.PRICE_YEAR9_MONTH7
            End If

            '年度9_月度情報8	
            If pfi.PRICE_YEAR9_MONTH8 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH8) = pfi.PRICE_YEAR9_MONTH8
            End If

            '年度9_月度情報9	
            If pfi.PRICE_YEAR9_MONTH9 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH9) = pfi.PRICE_YEAR9_MONTH9
            End If

            '年度9_月度情報10	
            If pfi.PRICE_YEAR9_MONTH10 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH10) = pfi.PRICE_YEAR9_MONTH10
            End If

            '年度9_月度情報11	
            If pfi.PRICE_YEAR9_MONTH11 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH11) = pfi.PRICE_YEAR9_MONTH11
            End If

            '年度9_月度情報12	
            If pfi.PRICE_YEAR9_MONTH12 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH12) = pfi.PRICE_YEAR9_MONTH12
            End If

            '年度10_月度情報1	
            If pfi.PRICE_YEAR10_MONTH1 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH1) = pfi.PRICE_YEAR10_MONTH1
            End If

            '年度10_月度情報2	
            If pfi.PRICE_YEAR10_MONTH2 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH2) = pfi.PRICE_YEAR10_MONTH2
            End If

            '年度10_月度情報3	
            If pfi.PRICE_YEAR10_MONTH3 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH3) = pfi.PRICE_YEAR10_MONTH3
            End If

            '年度10_月度情報4	
            If pfi.PRICE_YEAR10_MONTH4 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH4) = pfi.PRICE_YEAR10_MONTH4
            End If

            '年度10_月度情報5	
            If pfi.PRICE_YEAR10_MONTH5 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH5) = pfi.PRICE_YEAR10_MONTH5
            End If

            '年度10_月度情報6	
            If pfi.PRICE_YEAR10_MONTH6 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH6) = pfi.PRICE_YEAR10_MONTH6
            End If

            '年度10_月度情報7	
            If pfi.PRICE_YEAR10_MONTH7 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH7) = pfi.PRICE_YEAR10_MONTH7
            End If

            '年度10_月度情報8	
            If pfi.PRICE_YEAR10_MONTH8 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH8) = pfi.PRICE_YEAR10_MONTH8
            End If

            '年度10_月度情報9	
            If pfi.PRICE_YEAR10_MONTH9 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH9) = pfi.PRICE_YEAR10_MONTH9
            End If

            '年度10_月度情報10	
            If pfi.PRICE_YEAR10_MONTH10 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH10) = pfi.PRICE_YEAR10_MONTH10
            End If

            '年度10_月度情報11	
            If pfi.PRICE_YEAR10_MONTH11 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH11) = pfi.PRICE_YEAR10_MONTH11
            End If

            '年度10_月度情報12	
            If pfi.PRICE_YEAR10_MONTH12 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH12) = pfi.PRICE_YEAR10_MONTH12
            End If

            '年度11_月度情報1	
            If pfi.PRICE_YEAR11_MONTH1 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH1) = pfi.PRICE_YEAR11_MONTH1
            End If

            '年度11_月度情報2	
            If pfi.PRICE_YEAR11_MONTH2 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH2) = pfi.PRICE_YEAR11_MONTH2
            End If

            '年度11_月度情報3	
            If pfi.PRICE_YEAR11_MONTH3 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH3) = pfi.PRICE_YEAR11_MONTH3
            End If

            '年度11_月度情報4	
            If pfi.PRICE_YEAR11_MONTH4 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH4) = pfi.PRICE_YEAR11_MONTH4
            End If

            '年度11_月度情報5	
            If pfi.PRICE_YEAR11_MONTH5 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH5) = pfi.PRICE_YEAR11_MONTH5
            End If

            '年度11_月度情報6	
            If pfi.PRICE_YEAR11_MONTH6 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH6) = pfi.PRICE_YEAR11_MONTH6
            End If

            '年度11_月度情報7	
            If pfi.PRICE_YEAR11_MONTH7 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH7) = pfi.PRICE_YEAR11_MONTH7
            End If

            '年度11_月度情報8	
            If pfi.PRICE_YEAR11_MONTH8 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH8) = pfi.PRICE_YEAR11_MONTH8
            End If

            '年度11_月度情報9	
            If pfi.PRICE_YEAR11_MONTH9 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH9) = pfi.PRICE_YEAR11_MONTH9
            End If

            '年度11_月度情報10	
            If pfi.PRICE_YEAR11_MONTH10 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH10) = pfi.PRICE_YEAR11_MONTH10
            End If

            '年度11_月度情報11	
            If pfi.PRICE_YEAR11_MONTH11 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH11) = pfi.PRICE_YEAR11_MONTH11
            End If

            '年度11_月度情報12	
            If pfi.PRICE_YEAR11_MONTH12 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH12) = pfi.PRICE_YEAR11_MONTH12
            End If

            '年度12_月度情報1	
            If pfi.PRICE_YEAR12_MONTH1 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH1) = pfi.PRICE_YEAR12_MONTH1
            End If

            '年度12_月度情報2	
            If pfi.PRICE_YEAR12_MONTH2 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH2) = pfi.PRICE_YEAR12_MONTH2
            End If

            '年度12_月度情報3	
            If pfi.PRICE_YEAR12_MONTH3 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH3) = pfi.PRICE_YEAR12_MONTH3
            End If

            '年度12_月度情報4	
            If pfi.PRICE_YEAR12_MONTH4 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH4) = pfi.PRICE_YEAR12_MONTH4
            End If

            '年度12_月度情報5	
            If pfi.PRICE_YEAR12_MONTH5 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH5) = pfi.PRICE_YEAR12_MONTH5
            End If

            '年度12_月度情報6	
            If pfi.PRICE_YEAR12_MONTH6 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH6) = pfi.PRICE_YEAR12_MONTH6
            End If

            '年度12_月度情報7	
            If pfi.PRICE_YEAR12_MONTH7 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH7) = pfi.PRICE_YEAR12_MONTH7
            End If

            '年度12_月度情報8	
            If pfi.PRICE_YEAR12_MONTH8 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH8) = pfi.PRICE_YEAR12_MONTH8
            End If

            '年度12_月度情報9	
            If pfi.PRICE_YEAR12_MONTH9 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH9) = pfi.PRICE_YEAR12_MONTH9
            End If

            '年度12_月度情報10	
            If pfi.PRICE_YEAR12_MONTH10 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH10) = pfi.PRICE_YEAR12_MONTH10
            End If

            '年度12_月度情報11	
            If pfi.PRICE_YEAR12_MONTH11 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH11) = pfi.PRICE_YEAR12_MONTH11
            End If

            '年度12_月度情報12	
            If pfi.PRICE_YEAR12_MONTH12 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH12) = pfi.PRICE_YEAR12_MONTH12
            End If

            '年度13_月度情報1 
            If pfi.PRICE_YEAR13_MONTH1 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH1) = pfi.PRICE_YEAR13_MONTH1
            End If

            '年度13_月度情報2 
            If pfi.PRICE_YEAR13_MONTH2 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH2) = pfi.PRICE_YEAR13_MONTH2
            End If

            '年度13_月度情報3 
            If pfi.PRICE_YEAR13_MONTH3 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH3) = pfi.PRICE_YEAR13_MONTH3
            End If

            '年度13_月度情報4 
            If pfi.PRICE_YEAR13_MONTH4 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH4) = pfi.PRICE_YEAR13_MONTH4
            End If

            '年度13_月度情報5 
            If pfi.PRICE_YEAR13_MONTH5 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH5) = pfi.PRICE_YEAR13_MONTH5
            End If

            '年度13_月度情報6 
            If pfi.PRICE_YEAR13_MONTH6 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH6) = pfi.PRICE_YEAR13_MONTH6
            End If

            '年度13_月度情報7 
            If pfi.PRICE_YEAR13_MONTH7 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH7) = pfi.PRICE_YEAR13_MONTH7
            End If

            '年度13_月度情報8 
            If pfi.PRICE_YEAR13_MONTH8 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH8) = pfi.PRICE_YEAR13_MONTH8
            End If

            '年度13_月度情報9 
            If pfi.PRICE_YEAR13_MONTH9 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH9) = pfi.PRICE_YEAR13_MONTH9
            End If

            '年度13_月度情報10 
            If pfi.PRICE_YEAR13_MONTH10 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH10) = pfi.PRICE_YEAR13_MONTH10
            End If

            '年度13_月度情報11 
            If pfi.PRICE_YEAR13_MONTH11 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH11) = pfi.PRICE_YEAR13_MONTH11
            End If

            '年度13_月度情報12 
            If pfi.PRICE_YEAR13_MONTH12 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH12) = pfi.PRICE_YEAR13_MONTH12
            End If

            '年度14_月度情報1 
            If pfi.PRICE_YEAR14_MONTH1 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH1) = pfi.PRICE_YEAR14_MONTH1
            End If

            '年度14_月度情報2 
            If pfi.PRICE_YEAR14_MONTH2 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH2) = pfi.PRICE_YEAR14_MONTH2
            End If

            '年度14_月度情報3 
            If pfi.PRICE_YEAR14_MONTH3 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH3) = pfi.PRICE_YEAR14_MONTH3
            End If

            '年度14_月度情報4 
            If pfi.PRICE_YEAR14_MONTH4 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH4) = pfi.PRICE_YEAR14_MONTH4
            End If

            '年度14_月度情報5 
            If pfi.PRICE_YEAR14_MONTH5 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH5) = pfi.PRICE_YEAR14_MONTH5
            End If

            '年度14_月度情報6 
            If pfi.PRICE_YEAR14_MONTH6 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH6) = pfi.PRICE_YEAR14_MONTH6
            End If

            '年度14_月度情報7 
            If pfi.PRICE_YEAR14_MONTH7 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH7) = pfi.PRICE_YEAR14_MONTH7
            End If

            '年度14_月度情報8 
            If pfi.PRICE_YEAR14_MONTH8 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH8) = pfi.PRICE_YEAR14_MONTH8
            End If

            '年度14_月度情報9 
            If pfi.PRICE_YEAR14_MONTH9 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH9) = pfi.PRICE_YEAR14_MONTH9
            End If

            '年度14_月度情報10 
            If pfi.PRICE_YEAR14_MONTH10 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH10) = pfi.PRICE_YEAR14_MONTH10
            End If

            '年度14_月度情報11 
            If pfi.PRICE_YEAR14_MONTH11 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH11) = pfi.PRICE_YEAR14_MONTH11
            End If

            '年度14_月度情報12 
            If pfi.PRICE_YEAR14_MONTH12 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH12) = pfi.PRICE_YEAR14_MONTH12
            End If

            '年度15_月度情報1 
            If pfi.PRICE_YEAR15_MONTH1 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH1) = pfi.PRICE_YEAR15_MONTH1
            End If

            '年度15_月度情報2 
            If pfi.PRICE_YEAR15_MONTH2 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH2) = pfi.PRICE_YEAR15_MONTH2
            End If

            '年度15_月度情報3 
            If pfi.PRICE_YEAR15_MONTH3 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH3) = pfi.PRICE_YEAR15_MONTH3
            End If

            '年度15_月度情報4 
            If pfi.PRICE_YEAR15_MONTH4 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH4) = pfi.PRICE_YEAR15_MONTH4
            End If

            '年度15_月度情報5 
            If pfi.PRICE_YEAR15_MONTH5 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH5) = pfi.PRICE_YEAR15_MONTH5
            End If

            '年度15_月度情報6 
            If pfi.PRICE_YEAR15_MONTH6 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH6) = pfi.PRICE_YEAR15_MONTH6
            End If

            '年度15_月度情報7 
            If pfi.PRICE_YEAR15_MONTH7 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH7) = pfi.PRICE_YEAR15_MONTH7
            End If

            '年度15_月度情報8 
            If pfi.PRICE_YEAR15_MONTH8 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH8) = pfi.PRICE_YEAR15_MONTH8
            End If

            '年度15_月度情報9 
            If pfi.PRICE_YEAR15_MONTH9 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH9) = pfi.PRICE_YEAR15_MONTH9
            End If

            '年度15_月度情報10 
            If pfi.PRICE_YEAR15_MONTH10 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH10) = pfi.PRICE_YEAR15_MONTH10
            End If

            '年度15_月度情報11 
            If pfi.PRICE_YEAR15_MONTH11 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH11) = pfi.PRICE_YEAR15_MONTH11
            End If

            '年度15_月度情報12 
            If pfi.PRICE_YEAR15_MONTH12 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH12) = pfi.PRICE_YEAR15_MONTH12
            End If

            '年度16_月度情報1 
            If pfi.PRICE_YEAR16_MONTH1 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH1) = pfi.PRICE_YEAR16_MONTH1
            End If

            '年度16_月度情報2 
            If pfi.PRICE_YEAR16_MONTH2 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH2) = pfi.PRICE_YEAR16_MONTH2
            End If

            '年度16_月度情報3 
            If pfi.PRICE_YEAR16_MONTH3 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH3) = pfi.PRICE_YEAR16_MONTH3
            End If

            '年度16_月度情報4 
            If pfi.PRICE_YEAR16_MONTH4 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH4) = pfi.PRICE_YEAR16_MONTH4
            End If

            '年度16_月度情報5 
            If pfi.PRICE_YEAR16_MONTH5 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH5) = pfi.PRICE_YEAR16_MONTH5
            End If

            '年度16_月度情報6 
            If pfi.PRICE_YEAR16_MONTH6 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH6) = pfi.PRICE_YEAR16_MONTH6
            End If

            '年度16_月度情報7 
            If pfi.PRICE_YEAR16_MONTH7 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH7) = pfi.PRICE_YEAR16_MONTH7
            End If

            '年度16_月度情報8 
            If pfi.PRICE_YEAR16_MONTH8 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH8) = pfi.PRICE_YEAR16_MONTH8
            End If

            '年度16_月度情報9 
            If pfi.PRICE_YEAR16_MONTH9 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH9) = pfi.PRICE_YEAR16_MONTH9
            End If

            '年度16_月度情報10 
            If pfi.PRICE_YEAR16_MONTH10 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH10) = pfi.PRICE_YEAR16_MONTH10
            End If

            '年度16_月度情報11 
            If pfi.PRICE_YEAR16_MONTH11 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH11) = pfi.PRICE_YEAR16_MONTH11
            End If

            '年度16_月度情報12 
            If pfi.PRICE_YEAR16_MONTH12 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH12) = pfi.PRICE_YEAR16_MONTH12
            End If

            '年度17_月度情報1 
            If pfi.PRICE_YEAR17_MONTH1 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH1) = pfi.PRICE_YEAR17_MONTH1
            End If

            '年度17_月度情報2 
            If pfi.PRICE_YEAR17_MONTH2 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH2) = pfi.PRICE_YEAR17_MONTH2
            End If

            '年度17_月度情報3 
            If pfi.PRICE_YEAR17_MONTH3 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH3) = pfi.PRICE_YEAR17_MONTH3
            End If

            '年度17_月度情報4 
            If pfi.PRICE_YEAR17_MONTH4 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH4) = pfi.PRICE_YEAR17_MONTH4
            End If

            '年度17_月度情報5 
            If pfi.PRICE_YEAR17_MONTH5 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH5) = pfi.PRICE_YEAR17_MONTH5
            End If

            '年度17_月度情報6 
            If pfi.PRICE_YEAR17_MONTH6 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH6) = pfi.PRICE_YEAR17_MONTH6
            End If

            '年度17_月度情報7 
            If pfi.PRICE_YEAR17_MONTH7 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH7) = pfi.PRICE_YEAR17_MONTH7
            End If

            '年度17_月度情報8 
            If pfi.PRICE_YEAR17_MONTH8 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH8) = pfi.PRICE_YEAR17_MONTH8
            End If

            '年度17_月度情報9 
            If pfi.PRICE_YEAR17_MONTH9 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH9) = pfi.PRICE_YEAR17_MONTH9
            End If

            '年度17_月度情報10 
            If pfi.PRICE_YEAR17_MONTH10 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH10) = pfi.PRICE_YEAR17_MONTH10
            End If

            '年度17_月度情報11 
            If pfi.PRICE_YEAR17_MONTH11 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH11) = pfi.PRICE_YEAR17_MONTH11
            End If

            '年度17_月度情報12 
            If pfi.PRICE_YEAR17_MONTH12 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH12) = pfi.PRICE_YEAR17_MONTH12
            End If

            '年度18_月度情報1 
            If pfi.PRICE_YEAR18_MONTH1 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH1) = pfi.PRICE_YEAR18_MONTH1
            End If

            '年度18_月度情報2 
            If pfi.PRICE_YEAR18_MONTH2 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH2) = pfi.PRICE_YEAR18_MONTH2
            End If

            '年度18_月度情報3 
            If pfi.PRICE_YEAR18_MONTH3 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH3) = pfi.PRICE_YEAR18_MONTH3
            End If

            '年度18_月度情報4 
            If pfi.PRICE_YEAR18_MONTH4 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH4) = pfi.PRICE_YEAR18_MONTH4
            End If

            '年度18_月度情報5 
            If pfi.PRICE_YEAR18_MONTH5 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH5) = pfi.PRICE_YEAR18_MONTH5
            End If

            '年度18_月度情報6 
            If pfi.PRICE_YEAR18_MONTH6 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH6) = pfi.PRICE_YEAR18_MONTH6
            End If

            '年度18_月度情報7 
            If pfi.PRICE_YEAR18_MONTH7 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH7) = pfi.PRICE_YEAR18_MONTH7
            End If

            '年度18_月度情報8 
            If pfi.PRICE_YEAR18_MONTH8 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH8) = pfi.PRICE_YEAR18_MONTH8
            End If

            '年度18_月度情報9 
            If pfi.PRICE_YEAR18_MONTH9 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH9) = pfi.PRICE_YEAR18_MONTH9
            End If

            '年度18_月度情報10 
            If pfi.PRICE_YEAR18_MONTH10 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH10) = pfi.PRICE_YEAR18_MONTH10
            End If

            '年度18_月度情報11 
            If pfi.PRICE_YEAR18_MONTH11 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH11) = pfi.PRICE_YEAR18_MONTH11
            End If

            '年度18_月度情報12 
            If pfi.PRICE_YEAR18_MONTH12 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH12) = pfi.PRICE_YEAR18_MONTH12
            End If

            '年度19_月度情報1 
            If pfi.PRICE_YEAR19_MONTH1 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH1) = pfi.PRICE_YEAR19_MONTH1
            End If

            '年度19_月度情報2 
            If pfi.PRICE_YEAR19_MONTH2 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH2) = pfi.PRICE_YEAR19_MONTH2
            End If

            '年度19_月度情報3 
            If pfi.PRICE_YEAR19_MONTH3 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH3) = pfi.PRICE_YEAR19_MONTH3
            End If

            '年度19_月度情報4 
            If pfi.PRICE_YEAR19_MONTH4 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH4) = pfi.PRICE_YEAR19_MONTH4
            End If

            '年度19_月度情報5 
            If pfi.PRICE_YEAR19_MONTH5 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH5) = pfi.PRICE_YEAR19_MONTH5
            End If

            '年度19_月度情報6 
            If pfi.PRICE_YEAR19_MONTH6 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH6) = pfi.PRICE_YEAR19_MONTH6
            End If

            '年度19_月度情報7 
            If pfi.PRICE_YEAR19_MONTH7 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH7) = pfi.PRICE_YEAR19_MONTH7
            End If

            '年度19_月度情報8 
            If pfi.PRICE_YEAR19_MONTH8 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH8) = pfi.PRICE_YEAR19_MONTH8
            End If

            '年度19_月度情報9 
            If pfi.PRICE_YEAR19_MONTH9 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH9) = pfi.PRICE_YEAR19_MONTH9
            End If

            '年度19_月度情報10 
            If pfi.PRICE_YEAR19_MONTH10 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH10) = pfi.PRICE_YEAR19_MONTH10
            End If

            '年度19_月度情報11 
            If pfi.PRICE_YEAR19_MONTH11 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH11) = pfi.PRICE_YEAR19_MONTH11
            End If

            '年度19_月度情報12 
            If pfi.PRICE_YEAR19_MONTH12 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH12) = pfi.PRICE_YEAR19_MONTH12
            End If

            '年度20_月度情報1 
            If pfi.PRICE_YEAR20_MONTH1 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH1) = pfi.PRICE_YEAR20_MONTH1
            End If

            '年度20_月度情報2 
            If pfi.PRICE_YEAR20_MONTH2 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH2) = pfi.PRICE_YEAR20_MONTH2
            End If

            '年度20_月度情報3 
            If pfi.PRICE_YEAR20_MONTH3 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH3) = pfi.PRICE_YEAR20_MONTH3
            End If

            '年度20_月度情報4 
            If pfi.PRICE_YEAR20_MONTH4 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH4) = pfi.PRICE_YEAR20_MONTH4
            End If

            '年度20_月度情報5 
            If pfi.PRICE_YEAR20_MONTH5 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH5) = pfi.PRICE_YEAR20_MONTH5
            End If

            '年度20_月度情報6 
            If pfi.PRICE_YEAR20_MONTH6 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH6) = pfi.PRICE_YEAR20_MONTH6
            End If

            '年度20_月度情報7 
            If pfi.PRICE_YEAR20_MONTH7 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH7) = pfi.PRICE_YEAR20_MONTH7
            End If

            '年度20_月度情報8 
            If pfi.PRICE_YEAR20_MONTH8 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH8) = pfi.PRICE_YEAR20_MONTH8
            End If

            '年度20_月度情報9 
            If pfi.PRICE_YEAR20_MONTH9 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH9) = pfi.PRICE_YEAR20_MONTH9
            End If

            '年度20_月度情報10 
            If pfi.PRICE_YEAR20_MONTH10 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH10) = pfi.PRICE_YEAR20_MONTH10
            End If

            '年度20_月度情報11 
            If pfi.PRICE_YEAR20_MONTH11 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH11) = pfi.PRICE_YEAR20_MONTH11
            End If

            '年度20_月度情報12 
            If pfi.PRICE_YEAR20_MONTH12 <> "" Then
                objFomula(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12) = pfi.PRICE_YEAR20_MONTH12
            End If

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' 機能：位置変換
    ''' </summary>
    ''' <param name="objCellOld"></param>
    ''' <param name="objLineFomula"></param>
    ''' <param name="objCellNew"></param>
    ''' <remarks></remarks>
    Private Sub ChangePsItem(ByVal objCellOld(,) As Object,
                             ByVal objLineFomula(,) As Object,
                             ByRef objCellNew() As Object,
                             ByRef objFomulaOld() As Object)

        Dim intCnt As Integer

        Try
            '作業指示ファイル - 項目２０
            For intCnt = ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG To ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM20
                objCellNew(intCnt - 1) = objCellOld(1, intCnt)
                objFomulaOld(intCnt) = objLineFomula(1, intCnt)
            Next
            '項目２２ - Offering Price_Validation前
            For intCnt = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM22 To ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC
                objCellNew(intCnt - 1) = objCellOld(1, intCnt + 1)
                objFomulaOld(intCnt) = objLineFomula(1, intCnt + 1)
            Next
            'Offering Price_Validation後
            objCellNew(ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC_VAL - 1) = objCellOld(1, ExcelWrite.OldExcelPsColumn.PROD_ITEM21)
            objFomulaOld(ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC_VAL) = objLineFomula(1, ExcelWrite.OldExcelPsColumn.PROD_ITEM21)
            'Offering Price_小計 - 年度20_月度情報12
            For intCnt = ExcelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC To ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12
                objCellNew(intCnt - 1) = objCellOld(1, intCnt)
                objFomulaOld(intCnt) = objLineFomula(1, intCnt)
            Next

        Catch ex As Exception
            Throw ex

        End Try

    End Sub

    ''' <summary>
    ''' 機　能：セルデータ取得
    ''' 説　明：
    ''' </summary>
    ''' <param name="xlSheet"></param>
    ''' <param name="strRange"></param>
    ''' <param name="ExcelData"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetCellValue(ByRef xlSheet As Excel.Worksheet, ByVal strRange As String, ByRef ExcelData(,) As Object) As Boolean

        Dim xlCell As Excel.Range = Nothing

        GetCellValue = False

        Try
            xlCell = xlSheet.Range(strRange)
            ExcelData = xlCell.Value

            GetCellValue = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "GetCellValue")

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Function

    ''' <summary>
    ''' 機　能：セル式取得
    ''' </summary>
    ''' <param name="xlSheet"></param>
    ''' <param name="strRange"></param>
    ''' <param name="ExcelFormula"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetCellFormula(ByVal xlSheet As Excel.Worksheet, ByVal strRange As String, ByRef ExcelFormula(,) As Object) As Boolean

        Dim xlCell As Excel.Range = Nothing

        GetCellFormula = False

        Try
            xlCell = xlSheet.Range(strRange)
            ExcelFormula = xlCell.Formula

            GetCellFormula = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "GetCellFormula")

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Function

    ''' <summary>
    ''' 機　能：EXCELバージョン情報取得
    ''' 説　明：EXCELバージョン情報(xml)から取得する
    ''' </summary>
    ''' <param name="ExcelVerInfo"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetExcelVersion(ByRef ExcelVerInfo As ExcelVersion) As Boolean

        Dim intOldIndex As Integer = 0
        Dim strLocalName As String
        Dim strFile As String = FileManager.GetLocalFolderPath(CommonConstant.FOLDERNAME_XML) & "ExcelVersionInfo.xml"
        Dim reader As System.Xml.XmlReader = System.Xml.XmlReader.Create(strFile)

        GetExcelVersion = False

        Try
            While reader.Read
                'タグ名判定
                If reader.NodeType = Xml.XmlNodeType.Element Then
                    strLocalName = reader.LocalName
                    Select Case strLocalName
                        Case "Version"
                            intOldIndex = 0
                        Case "Old"
                            intOldIndex = intOldIndex + 1
                            ReDim Preserve ExcelVerInfo.OldVer(intOldIndex)
                    End Select
                End If

                '値取得
                If reader.NodeType = Xml.XmlNodeType.Text Then
                    Select Case strLocalName
                        Case "Sheet"
                            ExcelVerInfo.Name = ExcelWrite.changeDBNullToString(reader.Value)
                        Case "NewVer"
                            ExcelVerInfo.NewVer = ExcelWrite.changeDBNullToString(reader.Value)
                        Case "VerUp"
                            If ExcelWrite.changeDBNullToString(reader.Value) = "○" Then
                                ExcelVerInfo.OldVer(intOldIndex).VerUp = True
                            Else
                                ExcelVerInfo.OldVer(intOldIndex).VerUp = False
                            End If
                        Case "OldVer"
                            ExcelVerInfo.OldVer(intOldIndex).Ver = ExcelWrite.changeDBNullToString(reader.Value)
                        Case "Method"
                            ExcelVerInfo.OldVer(intOldIndex).Method = ExcelWrite.changeDBNullToString(reader.Value)
                        Case "Comment"
                            ExcelVerInfo.OldVer(intOldIndex).Comment = ExcelWrite.changeDBNullToString(reader.Value)
                    End Select
                End If
            End While

            'リーダーを閉じる
            reader.Close()

            GetExcelVersion = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "GetExcelVersion")

        End Try

    End Function

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="Value"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function changeDataToString(ByVal Value As Object) As Object

        Dim strWork As String
        Dim strWork2 As String      '小数点以下「E-」までの文字数
        Dim intPos As Integer
        Dim intPos2 As Integer      '小数点
        Dim strFormat As String
        Dim intMax As Integer

        If IsDBNull(Value) Or IsNothing(Value) Then
            Return ""
        Else
            If TypeName(Value) = "Double" Then
                '小数点１０桁以上の場合、そのまま文字列にすると指数表示されるため以下の処理を行う
                '　元の値：-0.0000000000000051219012497439
                '　そのままToStringiした値：-5.1219012497439E-15
                '　「E-」から後ろの値を取得、小数点桁数とする①
                '　「E-」からまえに「.」がある場合、「.」から「E-」まで間の文字数を取得し小数点桁数とする②
                '　①と②の合計を小数点桁数とし、Fromat文を作成
                strWork = Value.ToString
                intPos = strWork.IndexOf("E-")
                If intPos = -1 Then
                    Return Value.ToString
                Else
                    strWork2 = strWork.Substring(0, intPos)
                    intMax = Integer.Parse(strWork.Substring(intPos + 2))
                    intPos2 = strWork2.IndexOf(".")
                    If intPos2 >= 0 Then
                        strWork2 = strWork2.Substring(intPos2 + 1)
                        intMax = intMax + strWork2.Length
                    End If
                    strFormat = "0."
                    For intCnt As Integer = 1 To intMax
                        strFormat = strFormat & "0"
                    Next
                    Return Format(Value, strFormat)
                End If
            Else
                Return Value.ToString
            End If
        End If

    End Function

#End Region

#Region "一括"
    ''' <summary>
    ''' 機能：PaymentCSV変換（移行データロード専用）
    ''' </summary>
    ''' <param name="strOutputFileNameVPLine"></param>
    ''' <param name="strOutputFileNameTPprice"></param>
    ''' <param name="xlSheet"></param>
    ''' <param name="dtNow"></param>
    ''' <param name="strMsg"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function OutputVerUpExcelToCsvPs(ByVal strOutputFileNameVPLine As String,
                                             ByVal strOutputFileNameTPprice As String,
                                             ByVal xlSheet As Excel.Worksheet,
                                             ByVal dtNow As DateTime,
                                             ByRef strMsg As String) As Integer

        Dim sw1 As StreamWriter = Nothing
        Dim sw2 As StreamWriter = Nothing
        Dim ew As New ExcelWrite
        Dim oc As New OutputCsv
        Dim blnRet As Boolean
        Dim strRange As String
        Dim intLine As Integer
        Dim objCellLine(,) As Object
        Dim strOutputLine As String
        Dim intOutputCnt As Integer = 0
        Dim dtClientValue As DataTable
        Dim intCnt As Integer
        Dim intYearCnt As Integer
        Dim intMonthCnt As Integer
        Dim intPaymentStart As Integer
        Dim intColMonth As Integer

        OutputVerUpExcelToCsvPs = -1

        Try
            sw1 = New StreamWriter(strOutputFileNameVPLine, False, Encoding.GetEncoding("shift-jis"))
            sw2 = New StreamWriter(strOutputFileNameTPprice, False, Encoding.GetEncoding("shift-jis"))

            'Excelのオートフィルタを初期化
            Call ew.CrearAutoFilter(xlSheet)
            'Export用：変換データテーブル
            dtClientValue = oc.GetClientValueTable()
            'Chis項目と、修正前の項目との対応表をセットする。
            Call oc.SetChangePaymentLineColumn()

            intLine = ROW_START_PS_NEW
            Do
                Try
                    '----------------------------------------
                    'V_PLINE
                    '----------------------------------------
                    'Excel1行分の情報を取得
                    strRange = RANGE_VALUE_PS_NEW.Replace("@", intLine.ToString)
                    blnRet = GetCellValue(xlSheet, strRange, objCellLine)

                    'ExcelのEOFの判定
                    If (IsNothing(objCellLine(1, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)) OrElse CStr(objCellLine(1, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)) = "") _
                        AndAlso (IsNothing(objCellLine(1, ExcelWrite.ExcelPaymentLineColumn.FILE_NAME)) OrElse CStr(objCellLine(1, ExcelWrite.ExcelPaymentLineColumn.FILE_NAME)) = "") _
                        AndAlso (IsNothing(objCellLine(1, ExcelWrite.ExcelPaymentLineColumn.CONTRACT)) OrElse CStr(objCellLine(1, ExcelWrite.ExcelPaymentLineColumn.CONTRACT)) = "") _
                        AndAlso (IsNothing(objCellLine(1, ExcelWrite.ExcelPaymentLineColumn.PROJ_ID)) OrElse CStr(objCellLine(1, ExcelWrite.ExcelPaymentLineColumn.PROJ_ID)) = "") Then
                        Exit Do
                    End If

                    'CPNO
                    strOutputLine = """" & CommonVariable.CPNO & ""","

                    'CSV1行分のデータを書込
                    strOutputLine = strOutputLine & oc.GetPaymentLine(objCellLine, dtClientValue, True)

                    'Validation Status
                    strOutputLine = strOutputLine & """Y"""

                    'PL,PP
                    For intCnt = 1 To 2
                        'CreateTimeStamp
                        strOutputLine = strOutputLine & "," & dtNow.ToString("yyyy-MM-dd HH:mm:ss")
                        'UpdateTimeStamp
                        strOutputLine = strOutputLine & "," & dtNow.ToString("yyyy-MM-dd HH:mm:ss")
                        'CreateUser
                        strOutputLine = strOutputLine & ",BATCH"
                        'UpdateUser
                        strOutputLine = strOutputLine & ",BATCH"
                    Next
                    '出力
                    sw1.WriteLine(strOutputLine)

                    '----------------------------------------
                    'T_PPRICE
                    '----------------------------------------
                    intPaymentStart = Integer.Parse(CommonVariable.PaymentStart.ToString("yyyy"))
                    For intYearCnt = 1 To 20
                        'CPNO
                        strOutputLine = """" & CommonVariable.CPNO & ""","

                        'LINE_NO
                        strOutputLine = strOutputLine & objCellLine(1, ExcelWrite.ExcelPaymentLineColumn.LINE_NO) & ","

                        'DEL_FLAG
                        strOutputLine = strOutputLine & """"","

                        '年
                        strOutputLine = strOutputLine & """" & (intYearCnt + intPaymentStart - 1).ToString & ""","

                        '年額
                        strOutputLine = strOutputLine & objCellLine(1, (intYearCnt + ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1 - 1)) & ","

                        '月額
                        For intMonthCnt = 1 To 12
                            intColMonth = (intMonthCnt - 1 + ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1 + (intYearCnt - 1) * 12)
                            strOutputLine = strOutputLine & ExcelWrite.changeDBNullToZero(objCellLine(1, intColMonth)) & ","
                        Next

                        'CreateTimeStamp
                        strOutputLine = strOutputLine & dtNow.ToString("yyyy-MM-dd HH:mm:ss")
                        'UpdateTimeStamp
                        strOutputLine = strOutputLine & "," & dtNow.ToString("yyyy-MM-dd HH:mm:ss")
                        'CreateUser
                        strOutputLine = strOutputLine & ",BATCH"
                        'UpdateUser
                        strOutputLine = strOutputLine & ",BATCH"
                        '出力
                        sw2.WriteLine(strOutputLine)
                    Next

                    intLine = intLine + 1
                    intOutputCnt = intOutputCnt + 1

                Catch ex As Exception
                    strMsg = ex.Message.ToString & "(OutputVerUpExcelToCsvPs(Loop))"
                End Try
            Loop

            OutputVerUpExcelToCsvPs = intOutputCnt

        Catch ex As Exception
            strMsg = ex.Message.ToString & "(OutputVerUpExcelToCsvPs)"

        Finally
            If IsNothing(sw2) = False Then
                sw2.Close()
            End If
            If IsNothing(sw1) = False Then
                sw1.Close()
            End If

            GC.Collect()
        End Try

    End Function

    ''' <summary>
    ''' 機能：詳細CSV変換（移行データロード専用）
    ''' </summary>
    ''' <param name="strOutputFileName"></param>
    ''' <param name="xlSheet"></param>
    ''' <param name="dtNow"></param>
    ''' <param name="strMsg"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function OutputVerUpExcelToCsvDetail(ByVal strOutputFileName As String, ByVal xlSheet As Excel.Worksheet, ByVal dtNow As DateTime, ByRef strMsg As String) As Integer

        Dim sw As StreamWriter = Nothing
        Dim ew As New ExcelWrite
        Dim oc As New OutputCsv
        Dim blnRet As Boolean
        Dim strRange As String
        Dim intLine As Integer
        Dim objCellLine(1, 188) As Object
        Dim strOutputLine As String
        Dim intOutputCnt As Integer = 0

        OutputVerUpExcelToCsvDetail = -1

        Try
            sw = New StreamWriter(strOutputFileName, False, Encoding.GetEncoding("shift-jis"))

            ''Excelのオートフィルタを初期化
            Call ew.CrearAutoFilter(xlSheet)

            intLine = ROW_START_DETAIL_NEW
            Do
                Try
                    strRange = RANGE_VALUE_DETAIL_NEW.Replace("@", intLine.ToString)
                    blnRet = GetCellValue(xlSheet, strRange, objCellLine)

                    If (IsNothing(objCellLine(1, 4)) OrElse CStr(objCellLine(1, 4)) = "") _
                        AndAlso (IsNothing(objCellLine(1, 5)) OrElse CStr(objCellLine(1, 5)) = "") _
                        AndAlso (IsNothing(objCellLine(1, 10)) OrElse CStr(objCellLine(1, 10)) = "") Then
                        Exit Do
                    End If

                    '個別詳細出力
                    strOutputLine = oc.GetVerupDetail(objCellLine, dtNow)

                    sw.WriteLine(strOutputLine)

                    intLine = intLine + 1
                    intOutputCnt = intOutputCnt + 1

                Catch ex As Exception
                    strMsg = ex.Message.ToString & "(OutputVerUpExcelToCsvDetail)(Loop)"
                End Try
            Loop

            OutputVerUpExcelToCsvDetail = intOutputCnt

        Catch ex As Exception
            strMsg = ex.Message.ToString & "(OutputVerUpExcelToCsvDetail)"

        Finally
            If IsNothing(sw) = False Then
                sw.Close()
            End If

            GC.Collect()
        End Try

    End Function
#End Region

#End Region

End Class
