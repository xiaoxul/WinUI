﻿Imports System.IO
Imports System.Text
Imports System.Data.OleDb
Imports MUSE.Utility
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.OioBamaCommmon
Imports MUSE.Utility.UserMessageBox
Imports MUSE.Utility.UserDataTable.Master
Imports Microsoft.Office.Interop
Imports MUSE.WinUI.OioBamaCommmon
Imports MUSE.DataAccess.OleDb

Public Class Frm_DataOutput

#Region "定数"

    ''入力のダイアルログ画面
    Private Const INPUTDIALOG_FILTER_XLS As String = "ﾍﾟｲﾒﾝﾄｼｰﾄ ﾌｧｲﾙ (*.xlsm)|*.xlsm"

    'PaymentLine データ開始行
    Private Const EXCEL_PAYMENTLINEDATE_OUTROW As Integer = 6
    Private Const EXCEL_PAYMENTLINEDETAIL_OUTROW As Integer = 7
    Private Const EXCEL_SUMMARY_ROW As Integer = 10

    ''各帳票処理名
    Private Const OUTPUT_TYOUHYOUNAME_KAKAKUSYOUNINN As String = "KAKAKUSYOUNINN"
    Private Const OUTPUT_TYOUHYOUNAME_PAYMENTCOC As String = "PAYMENTCOC"
    Private Const OUTPUT_TYOUHYOUNAME_SEUKYU As String = "SEIKYU"
    Private Const OUTPUT_TYOUHYOUNAME_PROJECTIOC As String = "PROJECTIOC"
    Private Const OUTPUT_TYOUHYOUNAME_EXTENSION As String = "EXTENSION"

    ''出力ファイル名の判別に使用
    ''価格承認サマリー
    Private Const EXCELTYPE_IOCS As String = "個別PS(IOC)月次展開集計"
    Private Const EXCELTYPE_PSCOC_S As String = "個別PS(COC)月次展開集計"
    Private Const EXCELTYPE_PSCOCIOC_S As String = "個別PS(COC/IOC)差分月次展開"
    ''管理台帳
    Private Const EXCELTYPE_ACCOUNTCOC_C As String = "管理台帳 統合PS(COC)月次展開集計"
    Private Const EXCELTYPE_ACCOUNTBAU_C As String = "管理台帳 統合PS(BAU)月次展開集計"
    Private Const EXCELTYPE_ACCOUNTBAUCOC_C As String = "管理台帳 統合PS(BAU/COC)差分"
    ''IGF集計
    Private Const EXCELTYPE_IGFSummary As String = "IGF集計ファイル"
    Private Const EXCELTYPE_IGFSummaryimport As String = "IGF集計ファイル importファイル"

    ''請求
    Private Const EXCELTYPE_SEIKYU As String = "請求品目管理資料"

    ''処理中ダイアログ表示用
    Private Const STR_CREATING As String = "作成中・・・"
    Private Const STR_MESSAGE_CREATE_FILE As String = "ファイルを作成中です。"
    Private Const STR_MESSAGE_CHKVER_PAYMENT As String = "Paymentのバージョンチェック中です。"
    Private Const STR_MESSAGE_CHKVER_MDB As String = "MDBバージョンチェック中です。"
    Private Const STR_MESSAGE_UDT_ERROR As String = "Errorシート更新中です。"
    Private Const STR_MESSAGE_DOWNLOAD As String = "データダウンロード中です。"

    ''テーブルの項目
    Private Const ColumnNM_ContractNo As String = "ColumnNM_ContractNo"
    Private Const ColumnNM_FileNM As String = "ColumnNM_FileNM"
    Private Const ColumnNM_FileNMSuffix As String = "ColumnNM_FileNMSuffix"
    Private Const ColumnNM_FileIntraSuffix As String = "ColumnNM_FileIntraSuffix"

    ''WS1のサマリカテゴリTBLの作成に使用する。
    Private Const ColumnNM_KeyNo As String = "KeyNo"
    Private Const ColumnNM_Bu As String = "Bu"
    Private Const ColumnNM_Brand As String = "Brand"
    Private Const ColumnNM_SummaryCategory As String = "SummaryCategory"
    Private Const ColumnNM_SortKey As String = "SortKey"

    ''統合PS出力ｺﾝﾎﾞﾎﾞｯｸｽの値
    Private Const CmbValue_SumPayment_NotOutPut As String = "出力しない"
    Private Const CmbValue_SumPayment_OutPutIOC As String = "同一ﾌｧｲﾙに出力"
    Private Const CmbValue_SumPayment_OutPutOth As String = "別ﾌｧｲﾙに出力"

    'シート名を一括管理
    Private Const SHEET_NAME_WS1 As String = ExcelWrite.EXCEL_PAYMENTLINEDATE_WS1
    Private Const SHEET_NAME_PAYMENT As String = ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET
    Private Const SHEET_NAME_DETAIL As String = ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET
    Private Const SHEET_NAME_SUMMARY As String = ExcelWrite.EXCEL_PAYMENTLINEDATE_SUMMARY
    Private Const SHEET_NAME_LIST As String = ExcelWrite.EXCEL_PAYMENTLINEDATE_LISTSHEET
    Private Const SHEET_NAME_PRICE_SUMMARY As String = "価格承認サマリー"
    Private Const SHEET_NAME_IOC_SUMMARY As String = "OBAMA-PS_IOC集計"
    Private Const SHEET_NAME_COC_SUMMARY As String = "OBAMA-PS_COC集計"
    Private Const SHEET_NAME_COCIOC_SUMMARY As String = "OBAMA-PS_COCIOC差分"
    Private Const SHEET_NAME_BAU_SUMMARY As String = "OBAMA-PS_BAU集計"
    Private Const SHEET_NAME_BAUCOC_SUMMARY As String = "OBAMA-PS_BAUCOC差分"
    Private Const SHEET_NAME_IOC_P_SUMMARY As String = "OBAMA-PS_案件別IOC"

    Private Const SHEET_NAME_IGF_SUMMARY As String = "IGF集計ｼｰﾄ"
    Private Const SHEET_NAME_REFERENCE As String = "参考シート"
    Private Const SHEET_NAME_JOIN_PAYMENT As String = "統合Payment"

    Private Const SHEET_NAME_Ext1 As String = "出力結果"
    Private Const SHEET_NAME_Ext2 As String = "明細シート"

    'Req:1569 シリアル重複チェックリスト str
    Private Const SHEET_NAME_SerialChk As String = "出力結果"
    'Req:1569 シリアル重複チェックリスト end


    Private Const IDX_CHK_BOX1 As Integer = 0
    Private Const IDX_CHK_BOX2 As Integer = 1
    Private Const IDX_CHK_BOX3 As Integer = 2

    ''契約履歴リストのExcel定数
    Private Const TmpDelListFileNM As String = "削除ﾃﾞｰﾀﾁｪｯｸﾘｽﾄ.xlsm"
    Private Const TmpConListFileNM As String = "契約履歴チェックリスト.xlsm"
    Private Const ConList_ChkSheetNM As String = "変更履歴情報"
    Private Const ConList_TmpRow As Integer = 2         ''ﾃﾝﾌﾟﾚ行
    Private Const ConList_OutRow As Integer = 6         ''出力開始位置
    Private Const CopyRowCount As Integer = 1000        ''ﾃﾝﾌﾟﾚ行コピー数

    ''契約履歴リストの項目
    Private Const ChkList_ColumnNM_ID As String = "ID"                        ''ID
    Private Const ChkList_ColumnNM_Item10No As String = "Item10No"            ''Item10No
    Private Const ChkList_ColumnNM_BaseNo As String = "BaseNo"                ''BaseNo
    Private Const ChkList_ColumnNM_RefNo As String = "RefNo"                  ''関連NO
    Private Const ChkList_ColumnNM_CheckItem As String = "CheckItem"          ''確認結果
    Private Const ChkList_ColumnNM_FileKB As String = "FileKB"                ''取得元ファイル　　「MDB/Excel」

    ''確認項目の値
    Private Const ConList_ChkItem_RefNothing As String = "関連ﾃﾞｰﾀ無し"
    Private Const ConList_ChkItem_FlgChk As String = "FLG確認"
    Private Const ConList_ChkItem_ExistsPS As String = "Payment有り"
    Private Const ConList_ChkItem_NothingPS As String = "Payment無し"
    Private Const ConList_ChkItem_DowbleDel As String = "二重削除"

    ''項目10の値
    Private Const ProdItem10_Value_CopyNo As String = "ｺﾋﾟｰ元NO = "
    Private Const ProdItem10_Value_DelNo As String = "削除元NO = "

    Private Const FileKB_Value_MDB As String = "MDB"
    Private Const FileKB_Value_EXCEL As String = "EXCEL"

    Private Const EXCEL_MAX_ROWS As Long = 1048576      'Excelの最大行
    Private Const EXCEL_MAX_COLS As Long = 16384        'Excelの最大列

    Private Const EXT_ADDYEAR As Integer = 5            '延長年数初期値

    Private Const ExtPlusRow As Integer = 2             'Paymentと延長候補リストとの差分行
    Private Const ExtPlusCol As Integer = 11            'Paymentと延長候補リストとの差分列

    Private Const EXCEL_EXTENSIONLIST_OUTROW As Integer = 8    '延長候補リスト明細：データ開始行
    Private Const ColYearStart As Integer = 108         '候補リスト：年額開始列
    Private Const ColYearEnd As Integer = 127           '候補リスト：年額終了列
    Private Const ColMonthStart As Integer = 129        '候補リスト：月額開始列

    Private Const ExtensionTemplate As String = "延長候補リスト.xlsx"

    'Req:1569 シリアル重複チェックリスト str
    Private Const SerialCheckTemplate As String = "シリアル重複チェックリスト.xlsm"
    Private Const SerPlusCol As Integer = 6             'Paymentとシリアル重複チェックリストとの差分列

    Private Const SerialCheckLIST_OUTROW As Integer = 7 'シリアル重複チェックリスト明細：データ開始行
    'Req.1690 シリアル重複チェックリスト変更 2018/12 Str
    'Private Const SerColYearStart As Integer = 103      'シリアル重複チェックリスト：年額開始列
    'Private Const SerColYearEnd As Integer = 122        'シリアル重複チェック候補リスト：年額終了列
    'Private Const SerColMonthStart As Integer = 124     'シリアル重複チェックリスト：月額開始列
    Private Const SerColYearStart As Integer = 104      'シリアル重複チェックリスト：年額開始列
    Private Const SerColYearEnd As Integer = 123        'シリアル重複チェック候補リスト：年額終了列
    Private Const SerColMonthStart As Integer = 125     'シリアル重複チェックリスト：月額開始列
    'Req.1690 シリアル重複チェックリスト変更 2018/12 End
    'Req:1569 シリアル重複チェックリスト end

#End Region

#Region "列挙体"
    Private Enum DelListColumn
        CheckItem = 1                       ''確認結果
        BaseNo                              ''BaseNo
        RefNo                               ''関連No
        LOCK_FLAG                           ''Status
        VALID_FLAG                          ''有効/無効
        LINE_NO                             ''NO
        FILE_NAME                           ''ﾌｧｲﾙ名
        FILE_NAME_SUFFIX                    ''ﾌｧｲﾙ名Suffix
        FILE_NAME_SUFFIX_INTR               ''ﾌｧｲﾙ内Suffix
        CONTRACT                            ''契約順番
        ST_COST                             ''COST_開示依頼
        ST_APPROVAL                         ''価格承認_申請依頼
        PROJ_ID                             ''案件番号
        CONTRACT_SEQ                        ''契約通番
        NEW_EXIST                           ''新規/既存
        CUST_CATEGORY                       ''お客様集計ｶﾃｺﾞﾘ
        LETTER_PLAN_DATE                    ''実行通知書_発行予定日
        LETTER_ACCEPT_DATE                  ''実行通知書_受領日
        ORDER_DATE                          ''発注完了日
        LETTER_ID                           ''実行通知書番号
        ORDERCODE                           ''請求コード
        BU                                  ''Brand Category_BU
        BRAND                               ''Brand Category_Brand
        SUM_CATEGORY                        ''Brand Category_ｻﾏﾘｰ用ｶﾃｺﾞﾘ
        BRAND_SUB                           ''Brand Category_SubBrand
        OP1                                 ''Brand Category_Option1
        OP2                                 ''Brand Category_Option2
        BRAND_SIZE                          ''Brand Category_Size
        NON_SBO                             ''Brand Category_SBO制限
        POSTSCRIPT                          ''Brand Category_追記事項
        TOPACS_CPNO                         ''Brand承認_TOPACS CPNO
        BRAND_AP_FORM                       ''Brand承認_起票番号
        BRAND_AP_REQ                        ''Brand承認_申請番号
        BRAND_AP_CONF                       ''Brand承認_承認番号
        PATTERN_CD                          ''入力項目ﾊﾟﾀｰﾝ SEQ
        PATTERN                             ''入力項目ﾊﾟﾀｰﾝ
        PROD_ITEM01                         ''ﾊﾟﾀｰﾝ別入力項目_項目１
        PROD_ITEM02                         ''ﾊﾟﾀｰﾝ別入力項目_項目２
        PROD_ITEM03                         ''ﾊﾟﾀｰﾝ別入力項目_項目３
        PROD_ITEM04                         ''ﾊﾟﾀｰﾝ別入力項目_項目４
        PROD_ITEM05                         ''ﾊﾟﾀｰﾝ別入力項目_項目５
        PROD_ITEM06                         ''ﾊﾟﾀｰﾝ別入力項目_項目６
        PROD_ITEM07                         ''ﾊﾟﾀｰﾝ別入力項目_項目７
        PROD_ITEM08                         ''ﾊﾟﾀｰﾝ別入力項目_項目８
        PROD_ITEM09                         ''ﾊﾟﾀｰﾝ別入力項目_項目９
        PROD_ITEM10                         ''ﾊﾟﾀｰﾝ別入力項目_項目１０
        PROD_ITEM11                         ''ﾊﾟﾀｰﾝ別入力項目_項目１１
        PROD_ITEM12                         ''ﾊﾟﾀｰﾝ別入力項目_項目１２
        PROD_ITEM13                         ''ﾊﾟﾀｰﾝ別入力項目_項目１３
        PROD_ITEM14                         ''ﾊﾟﾀｰﾝ別入力項目_項目１４
        PROD_ITEM15                         ''ﾊﾟﾀｰﾝ別入力項目_項目１５
        PROD_ITEM16                         ''ﾊﾟﾀｰﾝ別入力項目_項目１６
        PROD_ITEM17                         ''ﾊﾟﾀｰﾝ別入力項目_項目１７
        PROD_ITEM18                         ''ﾊﾟﾀｰﾝ別入力項目_項目１８
        PROD_ITEM19                         ''ﾊﾟﾀｰﾝ別入力項目_項目１９
        PROD_ITEM20                         ''ﾊﾟﾀｰﾝ別入力項目_項目２０
        PROD_ITEM22                         ''ﾊﾟﾀｰﾝ別入力項目_項目２２
        PROD_ITEM23                         ''ﾊﾟﾀｰﾝ別入力項目_項目２３
        PROD_ITEM24                         ''ﾊﾟﾀｰﾝ別入力項目_項目２４
        WD_ANNT_DATE                        ''製品･ｻｰﾋﾞｽ廃止発表日
        WD_DATE                             ''製品･ｻｰﾋﾞｽ廃止予定
        PRICE_CHG_DATE                      ''価格改定予定日
        QTY                                 ''数量
        INST_DATE                           ''導入年月
        PAY_START_DATE                      ''元本計算・開始年月
        PAY_END_DATE                        ''元本計算・終了年月
        IGF_START_DATE                      ''IGF計算・開始年月
        IGF_END_DATE                        ''IGF計算・終了年月
        PAY_FLAG                            ''Payment・展開
        BID_FLAG                            ''定額BID
        PAY_MONTHS                          ''請求期間
        PAY_VALIDATION                      ''Validation
        PAY_METHOD                          ''支払方法
        IGF_APPLIED                         ''IGF_対象
        IGF_CONT_NO                         ''IGF契約番号
        IGF_CONT_FORM                       ''IGF契約形態
        IGF_CONT_MANAGMENT                  ''IGF契約物件管理
        IGF_RATE_IOC                        ''IGF_IOC料率
        LIST_PRICE_PROPOSAL                 ''Listprice(単価)_提案時
        LIST_PRICE_REFLESH                  ''Listprice(単価)_ﾘﾌﾚｯｼｭ後
        LIST_PRICE_TOTAL_PROPOSAL           ''Listprice(合計)_提案時	
        LIST_PRICE_TOTAL_REFLESH            ''Listprice(合計)_ﾘﾌﾚｯｼｭ後	
        DP_IOC                              ''IOC D%
        PRICE_UNIT_IOC                      ''IOC単価
        PRICE_UNIT_IOC_VAL                  ''Offering Price 単価Validation後
        PRICE_QTY_IOC                       ''IOC合計
        COST_RATE                           ''COST %
        COST                                ''COST_単価
        COST_TOTAL                          ''COST_合計
        COST_INPUT_DATE                     ''COST_入力日
        PRICE_TO_SPLIT                      ''展開金額
        LIST_PRICE_TOTAL_IOC                ''Listprice_期間合計
        PRICE_TOTAL_IOC                     ''D%適用後_期間合計
        COST_TOTAL_IOC                      ''COST_期間合計
        PRICE_TOTAL_IGF                     ''IGF適用後 期間合計
        CONTRACT_IN                         ''契約期間内
        CONTRACT_OUT                        ''契約期間外
        PRICE_DEFF_IGF                      ''IGF金利(差額)
        PRICE_YEAR1                         ''年度情報1
        PRICE_YEAR2                         ''年度情報2
        PRICE_YEAR3                         ''年度情報3
        PRICE_YEAR4                         ''年度情報4
        PRICE_YEAR5                         ''年度情報5
        PRICE_YEAR6                         ''年度情報6
        PRICE_YEAR7                         ''年度情報7
        PRICE_YEAR8                         ''年度情報8
        PRICE_YEAR9                         ''年度情報9
        PRICE_YEAR10                        ''年度情報10
        PRICE_YEAR11                        ''年度情報11
        PRICE_YEAR12                        ''年度情報12
        PRICE_YEAR13                        ''年度情報13
        PRICE_YEAR14                        ''年度情報14
        PRICE_YEAR15                        ''年度情報15
        PRICE_YEAR16                        ''年度情報16
        PRICE_YEAR17                        ''年度情報17
        PRICE_YEAR18                        ''年度情報18
        PRICE_YEAR19                        ''年度情報19
        PRICE_YEAR20                        ''年度情報20
        PAST_PRICE_TOTAL                    ''過去の契約金額合計
        PRICE_YEAR1_MONTH1                  ''年度1_月度情報1
        PRICE_YEAR1_MONTH2                  ''年度1_月度情報2
        PRICE_YEAR1_MONTH3                  ''年度1_月度情報3
        PRICE_YEAR1_MONTH4                  ''年度1_月度情報4
        PRICE_YEAR1_MONTH5                  ''年度1_月度情報5
        PRICE_YEAR1_MONTH6                  ''年度1_月度情報6
        PRICE_YEAR1_MONTH7                  ''年度1_月度情報7
        PRICE_YEAR1_MONTH8                  ''年度1_月度情報8
        PRICE_YEAR1_MONTH9                  ''年度1_月度情報9
        PRICE_YEAR1_MONTH10                 ''年度1_月度情報10
        PRICE_YEAR1_MONTH11                 ''年度1_月度情報11
        PRICE_YEAR1_MONTH12                 ''年度1_月度情報12
        PRICE_YEAR2_MONTH1                  ''年度2_月度情報1
        PRICE_YEAR2_MONTH2                  ''年度2_月度情報2
        PRICE_YEAR2_MONTH3                  ''年度2_月度情報3
        PRICE_YEAR2_MONTH4                  ''年度2_月度情報4
        PRICE_YEAR2_MONTH5                  ''年度2_月度情報5
        PRICE_YEAR2_MONTH6                  ''年度2_月度情報6
        PRICE_YEAR2_MONTH7                  ''年度2_月度情報7
        PRICE_YEAR2_MONTH8                  ''年度2_月度情報8
        PRICE_YEAR2_MONTH9                  ''年度2_月度情報9
        PRICE_YEAR2_MONTH10                 ''年度2_月度情報10
        PRICE_YEAR2_MONTH11                 ''年度2_月度情報11
        PRICE_YEAR2_MONTH12                 ''年度2_月度情報12
        PRICE_YEAR3_MONTH1                  ''年度3_月度情報1
        PRICE_YEAR3_MONTH2                  ''年度3_月度情報2
        PRICE_YEAR3_MONTH3                  ''年度3_月度情報3
        PRICE_YEAR3_MONTH4                  ''年度3_月度情報4
        PRICE_YEAR3_MONTH5                  ''年度3_月度情報5
        PRICE_YEAR3_MONTH6                  ''年度3_月度情報6
        PRICE_YEAR3_MONTH7                  ''年度3_月度情報7
        PRICE_YEAR3_MONTH8                  ''年度3_月度情報8
        PRICE_YEAR3_MONTH9                  ''年度3_月度情報9
        PRICE_YEAR3_MONTH10                 ''年度3_月度情報10
        PRICE_YEAR3_MONTH11                 ''年度3_月度情報11
        PRICE_YEAR3_MONTH12                 ''年度3_月度情報12
        PRICE_YEAR4_MONTH1                  ''年度4_月度情報1
        PRICE_YEAR4_MONTH2                  ''年度4_月度情報2
        PRICE_YEAR4_MONTH3                  ''年度4_月度情報3
        PRICE_YEAR4_MONTH4                  ''年度4_月度情報4
        PRICE_YEAR4_MONTH5                  ''年度4_月度情報5
        PRICE_YEAR4_MONTH6                  ''年度4_月度情報6
        PRICE_YEAR4_MONTH7                  ''年度4_月度情報7
        PRICE_YEAR4_MONTH8                  ''年度4_月度情報8
        PRICE_YEAR4_MONTH9                  ''年度4_月度情報9
        PRICE_YEAR4_MONTH10                 ''年度4_月度情報10
        PRICE_YEAR4_MONTH11                 ''年度4_月度情報11
        PRICE_YEAR4_MONTH12                 ''年度4_月度情報12
        PRICE_YEAR5_MONTH1                  ''年度5_月度情報1
        PRICE_YEAR5_MONTH2                  ''年度5_月度情報2
        PRICE_YEAR5_MONTH3                  ''年度5_月度情報3
        PRICE_YEAR5_MONTH4                  ''年度5_月度情報4
        PRICE_YEAR5_MONTH5                  ''年度5_月度情報5
        PRICE_YEAR5_MONTH6                  ''年度5_月度情報6
        PRICE_YEAR5_MONTH7                  ''年度5_月度情報7
        PRICE_YEAR5_MONTH8                  ''年度5_月度情報8
        PRICE_YEAR5_MONTH9                  ''年度5_月度情報9
        PRICE_YEAR5_MONTH10                 ''年度5_月度情報10
        PRICE_YEAR5_MONTH11                 ''年度5_月度情報11
        PRICE_YEAR5_MONTH12                 ''年度5_月度情報12
        PRICE_YEAR6_MONTH1                  ''年度6_月度情報1
        PRICE_YEAR6_MONTH2                  ''年度6_月度情報2
        PRICE_YEAR6_MONTH3                  ''年度6_月度情報3
        PRICE_YEAR6_MONTH4                  ''年度6_月度情報4
        PRICE_YEAR6_MONTH5                  ''年度6_月度情報5
        PRICE_YEAR6_MONTH6                  ''年度6_月度情報6
        PRICE_YEAR6_MONTH7                  ''年度6_月度情報7
        PRICE_YEAR6_MONTH8                  ''年度6_月度情報8
        PRICE_YEAR6_MONTH9                  ''年度6_月度情報9
        PRICE_YEAR6_MONTH10                 ''年度6_月度情報10
        PRICE_YEAR6_MONTH11                 ''年度6_月度情報11
        PRICE_YEAR6_MONTH12                 ''年度6_月度情報12
        PRICE_YEAR7_MONTH1                  ''年度7_月度情報1
        PRICE_YEAR7_MONTH2                  ''年度7_月度情報2
        PRICE_YEAR7_MONTH3                  ''年度7_月度情報3
        PRICE_YEAR7_MONTH4                  ''年度7_月度情報4
        PRICE_YEAR7_MONTH5                  ''年度7_月度情報5
        PRICE_YEAR7_MONTH6                  ''年度7_月度情報6
        PRICE_YEAR7_MONTH7                  ''年度7_月度情報7
        PRICE_YEAR7_MONTH8                  ''年度7_月度情報8
        PRICE_YEAR7_MONTH9                  ''年度7_月度情報9
        PRICE_YEAR7_MONTH10                 ''年度7_月度情報10
        PRICE_YEAR7_MONTH11                 ''年度7_月度情報11
        PRICE_YEAR7_MONTH12                 ''年度7_月度情報12
        PRICE_YEAR8_MONTH1                  ''年度8_月度情報1
        PRICE_YEAR8_MONTH2                  ''年度8_月度情報2
        PRICE_YEAR8_MONTH3                  ''年度8_月度情報3
        PRICE_YEAR8_MONTH4                  ''年度8_月度情報4
        PRICE_YEAR8_MONTH5                  ''年度8_月度情報5
        PRICE_YEAR8_MONTH6                  ''年度8_月度情報6
        PRICE_YEAR8_MONTH7                  ''年度8_月度情報7
        PRICE_YEAR8_MONTH8                  ''年度8_月度情報8
        PRICE_YEAR8_MONTH9                  ''年度8_月度情報9
        PRICE_YEAR8_MONTH10                 ''年度8_月度情報10
        PRICE_YEAR8_MONTH11                 ''年度8_月度情報11
        PRICE_YEAR8_MONTH12                 ''年度8_月度情報12
        PRICE_YEAR9_MONTH1                  ''年度9_月度情報1
        PRICE_YEAR9_MONTH2                  ''年度9_月度情報2
        PRICE_YEAR9_MONTH3                  ''年度9_月度情報3
        PRICE_YEAR9_MONTH4                  ''年度9_月度情報4
        PRICE_YEAR9_MONTH5                  ''年度9_月度情報5
        PRICE_YEAR9_MONTH6                  ''年度9_月度情報6
        PRICE_YEAR9_MONTH7                  ''年度9_月度情報7
        PRICE_YEAR9_MONTH8                  ''年度9_月度情報8
        PRICE_YEAR9_MONTH9                  ''年度9_月度情報9
        PRICE_YEAR9_MONTH10                 ''年度9_月度情報10
        PRICE_YEAR9_MONTH11                 ''年度9_月度情報11
        PRICE_YEAR9_MONTH12                 ''年度9_月度情報12
        PRICE_YEAR10_MONTH1                 ''年度10_月度情報1
        PRICE_YEAR10_MONTH2                 ''年度10_月度情報2
        PRICE_YEAR10_MONTH3                 ''年度10_月度情報3
        PRICE_YEAR10_MONTH4                 ''年度10_月度情報4
        PRICE_YEAR10_MONTH5                 ''年度10_月度情報5
        PRICE_YEAR10_MONTH6                 ''年度10_月度情報6
        PRICE_YEAR10_MONTH7                 ''年度10_月度情報7
        PRICE_YEAR10_MONTH8                 ''年度10_月度情報8
        PRICE_YEAR10_MONTH9                 ''年度10_月度情報9
        PRICE_YEAR10_MONTH10                ''年度10_月度情報10
        PRICE_YEAR10_MONTH11                ''年度10_月度情報11
        PRICE_YEAR10_MONTH12                ''年度10_月度情報12
        PRICE_YEAR11_MONTH1                 ''年度11_月度情報1
        PRICE_YEAR11_MONTH2                 ''年度11_月度情報2
        PRICE_YEAR11_MONTH3                 ''年度11_月度情報3
        PRICE_YEAR11_MONTH4                 ''年度11_月度情報4
        PRICE_YEAR11_MONTH5                 ''年度11_月度情報5
        PRICE_YEAR11_MONTH6                 ''年度11_月度情報6
        PRICE_YEAR11_MONTH7                 ''年度11_月度情報7
        PRICE_YEAR11_MONTH8                 ''年度11_月度情報8
        PRICE_YEAR11_MONTH9                 ''年度11_月度情報9
        PRICE_YEAR11_MONTH10                ''年度11_月度情報10
        PRICE_YEAR11_MONTH11                ''年度11_月度情報11
        PRICE_YEAR11_MONTH12                ''年度11_月度情報12
        PRICE_YEAR12_MONTH1                 ''年度12_月度情報1
        PRICE_YEAR12_MONTH2                 ''年度12_月度情報2
        PRICE_YEAR12_MONTH3                 ''年度12_月度情報3
        PRICE_YEAR12_MONTH4                 ''年度12_月度情報4
        PRICE_YEAR12_MONTH5                 ''年度12_月度情報5
        PRICE_YEAR12_MONTH6                 ''年度12_月度情報6
        PRICE_YEAR12_MONTH7                 ''年度12_月度情報7
        PRICE_YEAR12_MONTH8                 ''年度12_月度情報8
        PRICE_YEAR12_MONTH9                 ''年度12_月度情報9
        PRICE_YEAR12_MONTH10                ''年度12_月度情報10
        PRICE_YEAR12_MONTH11                ''年度12_月度情報11
        PRICE_YEAR12_MONTH12                ''年度12_月度情報12
        PRICE_YEAR13_MONTH1                 ''年度13_月度情報1
        PRICE_YEAR13_MONTH2                 ''年度13_月度情報2
        PRICE_YEAR13_MONTH3                 ''年度13_月度情報3
        PRICE_YEAR13_MONTH4                 ''年度13_月度情報4
        PRICE_YEAR13_MONTH5                 ''年度13_月度情報5
        PRICE_YEAR13_MONTH6                 ''年度13_月度情報6
        PRICE_YEAR13_MONTH7                 ''年度13_月度情報7
        PRICE_YEAR13_MONTH8                 ''年度13_月度情報8
        PRICE_YEAR13_MONTH9                 ''年度13_月度情報9
        PRICE_YEAR13_MONTH10                ''年度13_月度情報10
        PRICE_YEAR13_MONTH11                ''年度13_月度情報11
        PRICE_YEAR13_MONTH12                ''年度13_月度情報12
        PRICE_YEAR14_MONTH1                 ''年度14_月度情報1
        PRICE_YEAR14_MONTH2                 ''年度14_月度情報2
        PRICE_YEAR14_MONTH3                 ''年度14_月度情報3
        PRICE_YEAR14_MONTH4                 ''年度14_月度情報4
        PRICE_YEAR14_MONTH5                 ''年度14_月度情報5
        PRICE_YEAR14_MONTH6                 ''年度14_月度情報6
        PRICE_YEAR14_MONTH7                 ''年度14_月度情報7
        PRICE_YEAR14_MONTH8                 ''年度14_月度情報8
        PRICE_YEAR14_MONTH9                 ''年度14_月度情報9
        PRICE_YEAR14_MONTH10                ''年度14_月度情報10
        PRICE_YEAR14_MONTH11                ''年度14_月度情報11
        PRICE_YEAR14_MONTH12                ''年度14_月度情報12
        PRICE_YEAR15_MONTH1                 ''年度15_月度情報1
        PRICE_YEAR15_MONTH2                 ''年度15_月度情報2
        PRICE_YEAR15_MONTH3                 ''年度15_月度情報3
        PRICE_YEAR15_MONTH4                 ''年度15_月度情報4
        PRICE_YEAR15_MONTH5                 ''年度15_月度情報5
        PRICE_YEAR15_MONTH6                 ''年度15_月度情報6
        PRICE_YEAR15_MONTH7                 ''年度15_月度情報7
        PRICE_YEAR15_MONTH8                 ''年度15_月度情報8
        PRICE_YEAR15_MONTH9                 ''年度15_月度情報9
        PRICE_YEAR15_MONTH10                ''年度15_月度情報10
        PRICE_YEAR15_MONTH11                ''年度15_月度情報11
        PRICE_YEAR15_MONTH12                ''年度15_月度情報12
        PRICE_YEAR16_MONTH1                 ''年度16_月度情報1
        PRICE_YEAR16_MONTH2                 ''年度16_月度情報2
        PRICE_YEAR16_MONTH3                 ''年度16_月度情報3
        PRICE_YEAR16_MONTH4                 ''年度16_月度情報4
        PRICE_YEAR16_MONTH5                 ''年度16_月度情報5
        PRICE_YEAR16_MONTH6                 ''年度16_月度情報6
        PRICE_YEAR16_MONTH7                 ''年度16_月度情報7
        PRICE_YEAR16_MONTH8                 ''年度16_月度情報8
        PRICE_YEAR16_MONTH9                 ''年度16_月度情報9
        PRICE_YEAR16_MONTH10                ''年度16_月度情報10
        PRICE_YEAR16_MONTH11                ''年度16_月度情報11
        PRICE_YEAR16_MONTH12                ''年度16_月度情報12
        PRICE_YEAR17_MONTH1                 ''年度17_月度情報1
        PRICE_YEAR17_MONTH2                 ''年度17_月度情報2
        PRICE_YEAR17_MONTH3                 ''年度17_月度情報3
        PRICE_YEAR17_MONTH4                 ''年度17_月度情報4
        PRICE_YEAR17_MONTH5                 ''年度17_月度情報5
        PRICE_YEAR17_MONTH6                 ''年度17_月度情報6
        PRICE_YEAR17_MONTH7                 ''年度17_月度情報7
        PRICE_YEAR17_MONTH8                 ''年度17_月度情報8
        PRICE_YEAR17_MONTH9                 ''年度17_月度情報9
        PRICE_YEAR17_MONTH10                ''年度17_月度情報10
        PRICE_YEAR17_MONTH11                ''年度17_月度情報11
        PRICE_YEAR17_MONTH12                ''年度17_月度情報12
        PRICE_YEAR18_MONTH1                 ''年度18_月度情報1
        PRICE_YEAR18_MONTH2                 ''年度18_月度情報2
        PRICE_YEAR18_MONTH3                 ''年度18_月度情報3
        PRICE_YEAR18_MONTH4                 ''年度18_月度情報4
        PRICE_YEAR18_MONTH5                 ''年度18_月度情報5
        PRICE_YEAR18_MONTH6                 ''年度18_月度情報6
        PRICE_YEAR18_MONTH7                 ''年度18_月度情報7
        PRICE_YEAR18_MONTH8                 ''年度18_月度情報8
        PRICE_YEAR18_MONTH9                 ''年度18_月度情報9
        PRICE_YEAR18_MONTH10                ''年度18_月度情報10
        PRICE_YEAR18_MONTH11                ''年度18_月度情報11
        PRICE_YEAR18_MONTH12                ''年度18_月度情報12
        PRICE_YEAR19_MONTH1                 ''年度19_月度情報1
        PRICE_YEAR19_MONTH2                 ''年度19_月度情報2
        PRICE_YEAR19_MONTH3                 ''年度19_月度情報3
        PRICE_YEAR19_MONTH4                 ''年度19_月度情報4
        PRICE_YEAR19_MONTH5                 ''年度19_月度情報5
        PRICE_YEAR19_MONTH6                 ''年度19_月度情報6
        PRICE_YEAR19_MONTH7                 ''年度19_月度情報7
        PRICE_YEAR19_MONTH8                 ''年度19_月度情報8
        PRICE_YEAR19_MONTH9                 ''年度19_月度情報9
        PRICE_YEAR19_MONTH10                ''年度19_月度情報10
        PRICE_YEAR19_MONTH11                ''年度19_月度情報11
        PRICE_YEAR19_MONTH12                ''年度19_月度情報12
        PRICE_YEAR20_MONTH1                 ''年度20_月度情報1
        PRICE_YEAR20_MONTH2                 ''年度20_月度情報2
        PRICE_YEAR20_MONTH3                 ''年度20_月度情報3
        PRICE_YEAR20_MONTH4                 ''年度20_月度情報4
        PRICE_YEAR20_MONTH5                 ''年度20_月度情報5
        PRICE_YEAR20_MONTH6                 ''年度20_月度情報6
        PRICE_YEAR20_MONTH7                 ''年度20_月度情報7
        PRICE_YEAR20_MONTH8                 ''年度20_月度情報8
        PRICE_YEAR20_MONTH9                 ''年度20_月度情報9
        PRICE_YEAR20_MONTH10                ''年度20_月度情報10
        PRICE_YEAR20_MONTH11                ''年度20_月度情報11
        PRICE_YEAR20_MONTH12                ''年度20_月度情報12
    End Enum

    Private Enum ConListColumn
        CheckItem = 1                       ''確認結果
        BaseNo                              ''BaseNo
        RefNo                               ''関連No
        VALID_FLAG                          ''有効/無効
        LINE_NO                             ''NO
        FILE_NAME                           ''ﾌｧｲﾙ名
        FILE_NAME_SUFFIX                    ''ﾌｧｲﾙ名Suffix
        FILE_NAME_SUFFIX_INTR               ''ﾌｧｲﾙ内Suffix
        CONTRACT                            ''契約順番
        ST_COST                             ''COST_開示依頼
        ST_APPROVAL                         ''価格承認_申請依頼
        PROJ_ID                             ''案件番号
        CONTRACT_SEQ                        ''契約通番
        NEW_EXIST                           ''新規/既存
        CUST_CATEGORY                       ''お客様集計ｶﾃｺﾞﾘ
        LETTER_PLAN_DATE                    ''実行通知書_発行予定日
        LETTER_ACCEPT_DATE                  ''実行通知書_受領日
        ORDER_DATE                          ''発注完了日
        LETTER_ID                           ''実行通知書番号
        ORDERCODE                           ''請求コード
        BU                                  ''Brand Category_BU
        BRAND                               ''Brand Category_Brand
        SUM_CATEGORY                        ''Brand Category_ｻﾏﾘｰ用ｶﾃｺﾞﾘ
        BRAND_SUB                           ''Brand Category_SubBrand
        OP1                                 ''Brand Category_Option1
        OP2                                 ''Brand Category_Option2
        BRAND_SIZE                          ''Brand Category_Size
        NON_SBO                             ''Brand Category_SBO制限
        POSTSCRIPT                          ''Brand Category_追記事項
        TOPACS_CPNO                         ''Brand承認_TOPACS CPNO
        BRAND_AP_FORM                       ''Brand承認_起票番号
        BRAND_AP_REQ                        ''Brand承認_申請番号
        BRAND_AP_CONF                       ''Brand承認_承認番号
        PATTERN_CD                          ''入力項目ﾊﾟﾀｰﾝ SEQ
        PATTERN                             ''入力項目ﾊﾟﾀｰﾝ
        PROD_ITEM01                         ''ﾊﾟﾀｰﾝ別入力項目_項目１
        PROD_ITEM02                         ''ﾊﾟﾀｰﾝ別入力項目_項目２
        PROD_ITEM03                         ''ﾊﾟﾀｰﾝ別入力項目_項目３
        PROD_ITEM04                         ''ﾊﾟﾀｰﾝ別入力項目_項目４
        PROD_ITEM05                         ''ﾊﾟﾀｰﾝ別入力項目_項目５
        PROD_ITEM06                         ''ﾊﾟﾀｰﾝ別入力項目_項目６
        PROD_ITEM07                         ''ﾊﾟﾀｰﾝ別入力項目_項目７
        PROD_ITEM08                         ''ﾊﾟﾀｰﾝ別入力項目_項目８
        PROD_ITEM09                         ''ﾊﾟﾀｰﾝ別入力項目_項目９
        PROD_ITEM10                         ''ﾊﾟﾀｰﾝ別入力項目_項目１０
        PROD_ITEM11                         ''ﾊﾟﾀｰﾝ別入力項目_項目１１
        PROD_ITEM12                         ''ﾊﾟﾀｰﾝ別入力項目_項目１２
        PROD_ITEM13                         ''ﾊﾟﾀｰﾝ別入力項目_項目１３
        PROD_ITEM14                         ''ﾊﾟﾀｰﾝ別入力項目_項目１４
        PROD_ITEM15                         ''ﾊﾟﾀｰﾝ別入力項目_項目１５
        PROD_ITEM16                         ''ﾊﾟﾀｰﾝ別入力項目_項目１６
        PROD_ITEM17                         ''ﾊﾟﾀｰﾝ別入力項目_項目１７
        PROD_ITEM18                         ''ﾊﾟﾀｰﾝ別入力項目_項目１８
        PROD_ITEM19                         ''ﾊﾟﾀｰﾝ別入力項目_項目１９
        PROD_ITEM20                         ''ﾊﾟﾀｰﾝ別入力項目_項目２０
        PROD_ITEM22                         ''ﾊﾟﾀｰﾝ別入力項目_項目２２
        PROD_ITEM23                         ''ﾊﾟﾀｰﾝ別入力項目_項目２３
        PROD_ITEM24                         ''ﾊﾟﾀｰﾝ別入力項目_項目２４
        WD_ANNT_DATE                        ''製品･ｻｰﾋﾞｽ廃止発表日
        WD_DATE                             ''製品･ｻｰﾋﾞｽ廃止予定
        PRICE_CHG_DATE                      ''価格改定予定日
        QTY                                 ''数量
        INST_DATE                           ''導入年月
        PAY_START_DATE                      ''元本計算・開始年月
        PAY_END_DATE                        ''元本計算・終了年月
        IGF_START_DATE                      ''IGF計算・開始年月
        IGF_END_DATE                        ''IGF計算・終了年月
        PAY_FLAG                            ''Payment・展開
        BID_FLAG                            ''定額BID
        PAY_MONTHS                          ''請求期間
        PAY_VALIDATION                      ''Validation
        PAY_METHOD                          ''支払方法
        IGF_APPLIED                         ''IGF_対象
        IGF_CONT_NO                         ''IGF契約番号
        IGF_CONT_FORM                       ''IGF契約形態
        IGF_CONT_MANAGMENT                  ''IGF契約物件管理
        IGF_RATE_IOC                        ''IGF_IOC料率
        LIST_PRICE_PROPOSAL                 ''Listprice(単価)_提案時
        LIST_PRICE_REFLESH                  ''Listprice(単価)_ﾘﾌﾚｯｼｭ後
        LIST_PRICE_TOTAL_PROPOSAL           ''Listprice(合計)_提案時	
        LIST_PRICE_TOTAL_REFLESH            ''Listprice(合計)_ﾘﾌﾚｯｼｭ後	
        DP_IOC                              ''IOC D%
        PRICE_UNIT_IOC                      ''IOC単価
        PRICE_UNIT_IOC_VAL                  ''Offering Price 単価Validation後
        PRICE_QTY_IOC                       ''IOC合計
        COST_RATE                           ''COST %
        COST                                ''COST_単価
        COST_TOTAL                          ''COST_合計
        COST_INPUT_DATE                     ''COST_入力日
        PRICE_TO_SPLIT                      ''展開金額
        LIST_PRICE_TOTAL_IOC                ''Listprice_期間合計
        PRICE_TOTAL_IOC                     ''D%適用後_期間合計
        COST_TOTAL_IOC                      ''COST_期間合計
        PRICE_TOTAL_IGF                     ''IGF適用後 期間合計
        CONTRACT_IN                         ''契約期間内
        CONTRACT_OUT                        ''契約期間外
        PRICE_DEFF_IGF                      ''IGF金利(差額)
        PRICE_YEAR1                         ''年度情報1
        PRICE_YEAR2                         ''年度情報2
        PRICE_YEAR3                         ''年度情報3
        PRICE_YEAR4                         ''年度情報4
        PRICE_YEAR5                         ''年度情報5
        PRICE_YEAR6                         ''年度情報6
        PRICE_YEAR7                         ''年度情報7
        PRICE_YEAR8                         ''年度情報8
        PRICE_YEAR9                         ''年度情報9
        PRICE_YEAR10                        ''年度情報10
        PRICE_YEAR11                        ''年度情報11
        PRICE_YEAR12                        ''年度情報12
        PRICE_YEAR13                        ''年度情報13
        PRICE_YEAR14                        ''年度情報14
        PRICE_YEAR15                        ''年度情報15
        PRICE_YEAR16                        ''年度情報16
        PRICE_YEAR17                        ''年度情報17
        PRICE_YEAR18                        ''年度情報18
        PRICE_YEAR19                        ''年度情報19
        PRICE_YEAR20                        ''年度情報20
        PAST_PRICE_TOTAL                    ''過去の契約金額合計
        PRICE_YEAR1_MONTH1                  ''年度1_月度情報1
        PRICE_YEAR1_MONTH2                  ''年度1_月度情報2
        PRICE_YEAR1_MONTH3                  ''年度1_月度情報3
        PRICE_YEAR1_MONTH4                  ''年度1_月度情報4
        PRICE_YEAR1_MONTH5                  ''年度1_月度情報5
        PRICE_YEAR1_MONTH6                  ''年度1_月度情報6
        PRICE_YEAR1_MONTH7                  ''年度1_月度情報7
        PRICE_YEAR1_MONTH8                  ''年度1_月度情報8
        PRICE_YEAR1_MONTH9                  ''年度1_月度情報9
        PRICE_YEAR1_MONTH10                 ''年度1_月度情報10
        PRICE_YEAR1_MONTH11                 ''年度1_月度情報11
        PRICE_YEAR1_MONTH12                 ''年度1_月度情報12
        PRICE_YEAR2_MONTH1                  ''年度2_月度情報1
        PRICE_YEAR2_MONTH2                  ''年度2_月度情報2
        PRICE_YEAR2_MONTH3                  ''年度2_月度情報3
        PRICE_YEAR2_MONTH4                  ''年度2_月度情報4
        PRICE_YEAR2_MONTH5                  ''年度2_月度情報5
        PRICE_YEAR2_MONTH6                  ''年度2_月度情報6
        PRICE_YEAR2_MONTH7                  ''年度2_月度情報7
        PRICE_YEAR2_MONTH8                  ''年度2_月度情報8
        PRICE_YEAR2_MONTH9                  ''年度2_月度情報9
        PRICE_YEAR2_MONTH10                 ''年度2_月度情報10
        PRICE_YEAR2_MONTH11                 ''年度2_月度情報11
        PRICE_YEAR2_MONTH12                 ''年度2_月度情報12
        PRICE_YEAR3_MONTH1                  ''年度3_月度情報1
        PRICE_YEAR3_MONTH2                  ''年度3_月度情報2
        PRICE_YEAR3_MONTH3                  ''年度3_月度情報3
        PRICE_YEAR3_MONTH4                  ''年度3_月度情報4
        PRICE_YEAR3_MONTH5                  ''年度3_月度情報5
        PRICE_YEAR3_MONTH6                  ''年度3_月度情報6
        PRICE_YEAR3_MONTH7                  ''年度3_月度情報7
        PRICE_YEAR3_MONTH8                  ''年度3_月度情報8
        PRICE_YEAR3_MONTH9                  ''年度3_月度情報9
        PRICE_YEAR3_MONTH10                 ''年度3_月度情報10
        PRICE_YEAR3_MONTH11                 ''年度3_月度情報11
        PRICE_YEAR3_MONTH12                 ''年度3_月度情報12
        PRICE_YEAR4_MONTH1                  ''年度4_月度情報1
        PRICE_YEAR4_MONTH2                  ''年度4_月度情報2
        PRICE_YEAR4_MONTH3                  ''年度4_月度情報3
        PRICE_YEAR4_MONTH4                  ''年度4_月度情報4
        PRICE_YEAR4_MONTH5                  ''年度4_月度情報5
        PRICE_YEAR4_MONTH6                  ''年度4_月度情報6
        PRICE_YEAR4_MONTH7                  ''年度4_月度情報7
        PRICE_YEAR4_MONTH8                  ''年度4_月度情報8
        PRICE_YEAR4_MONTH9                  ''年度4_月度情報9
        PRICE_YEAR4_MONTH10                 ''年度4_月度情報10
        PRICE_YEAR4_MONTH11                 ''年度4_月度情報11
        PRICE_YEAR4_MONTH12                 ''年度4_月度情報12
        PRICE_YEAR5_MONTH1                  ''年度5_月度情報1
        PRICE_YEAR5_MONTH2                  ''年度5_月度情報2
        PRICE_YEAR5_MONTH3                  ''年度5_月度情報3
        PRICE_YEAR5_MONTH4                  ''年度5_月度情報4
        PRICE_YEAR5_MONTH5                  ''年度5_月度情報5
        PRICE_YEAR5_MONTH6                  ''年度5_月度情報6
        PRICE_YEAR5_MONTH7                  ''年度5_月度情報7
        PRICE_YEAR5_MONTH8                  ''年度5_月度情報8
        PRICE_YEAR5_MONTH9                  ''年度5_月度情報9
        PRICE_YEAR5_MONTH10                 ''年度5_月度情報10
        PRICE_YEAR5_MONTH11                 ''年度5_月度情報11
        PRICE_YEAR5_MONTH12                 ''年度5_月度情報12
        PRICE_YEAR6_MONTH1                  ''年度6_月度情報1
        PRICE_YEAR6_MONTH2                  ''年度6_月度情報2
        PRICE_YEAR6_MONTH3                  ''年度6_月度情報3
        PRICE_YEAR6_MONTH4                  ''年度6_月度情報4
        PRICE_YEAR6_MONTH5                  ''年度6_月度情報5
        PRICE_YEAR6_MONTH6                  ''年度6_月度情報6
        PRICE_YEAR6_MONTH7                  ''年度6_月度情報7
        PRICE_YEAR6_MONTH8                  ''年度6_月度情報8
        PRICE_YEAR6_MONTH9                  ''年度6_月度情報9
        PRICE_YEAR6_MONTH10                 ''年度6_月度情報10
        PRICE_YEAR6_MONTH11                 ''年度6_月度情報11
        PRICE_YEAR6_MONTH12                 ''年度6_月度情報12
        PRICE_YEAR7_MONTH1                  ''年度7_月度情報1
        PRICE_YEAR7_MONTH2                  ''年度7_月度情報2
        PRICE_YEAR7_MONTH3                  ''年度7_月度情報3
        PRICE_YEAR7_MONTH4                  ''年度7_月度情報4
        PRICE_YEAR7_MONTH5                  ''年度7_月度情報5
        PRICE_YEAR7_MONTH6                  ''年度7_月度情報6
        PRICE_YEAR7_MONTH7                  ''年度7_月度情報7
        PRICE_YEAR7_MONTH8                  ''年度7_月度情報8
        PRICE_YEAR7_MONTH9                  ''年度7_月度情報9
        PRICE_YEAR7_MONTH10                 ''年度7_月度情報10
        PRICE_YEAR7_MONTH11                 ''年度7_月度情報11
        PRICE_YEAR7_MONTH12                 ''年度7_月度情報12
        PRICE_YEAR8_MONTH1                  ''年度8_月度情報1
        PRICE_YEAR8_MONTH2                  ''年度8_月度情報2
        PRICE_YEAR8_MONTH3                  ''年度8_月度情報3
        PRICE_YEAR8_MONTH4                  ''年度8_月度情報4
        PRICE_YEAR8_MONTH5                  ''年度8_月度情報5
        PRICE_YEAR8_MONTH6                  ''年度8_月度情報6
        PRICE_YEAR8_MONTH7                  ''年度8_月度情報7
        PRICE_YEAR8_MONTH8                  ''年度8_月度情報8
        PRICE_YEAR8_MONTH9                  ''年度8_月度情報9
        PRICE_YEAR8_MONTH10                 ''年度8_月度情報10
        PRICE_YEAR8_MONTH11                 ''年度8_月度情報11
        PRICE_YEAR8_MONTH12                 ''年度8_月度情報12
        PRICE_YEAR9_MONTH1                  ''年度9_月度情報1
        PRICE_YEAR9_MONTH2                  ''年度9_月度情報2
        PRICE_YEAR9_MONTH3                  ''年度9_月度情報3
        PRICE_YEAR9_MONTH4                  ''年度9_月度情報4
        PRICE_YEAR9_MONTH5                  ''年度9_月度情報5
        PRICE_YEAR9_MONTH6                  ''年度9_月度情報6
        PRICE_YEAR9_MONTH7                  ''年度9_月度情報7
        PRICE_YEAR9_MONTH8                  ''年度9_月度情報8
        PRICE_YEAR9_MONTH9                  ''年度9_月度情報9
        PRICE_YEAR9_MONTH10                 ''年度9_月度情報10
        PRICE_YEAR9_MONTH11                 ''年度9_月度情報11
        PRICE_YEAR9_MONTH12                 ''年度9_月度情報12
        PRICE_YEAR10_MONTH1                 ''年度10_月度情報1
        PRICE_YEAR10_MONTH2                 ''年度10_月度情報2
        PRICE_YEAR10_MONTH3                 ''年度10_月度情報3
        PRICE_YEAR10_MONTH4                 ''年度10_月度情報4
        PRICE_YEAR10_MONTH5                 ''年度10_月度情報5
        PRICE_YEAR10_MONTH6                 ''年度10_月度情報6
        PRICE_YEAR10_MONTH7                 ''年度10_月度情報7
        PRICE_YEAR10_MONTH8                 ''年度10_月度情報8
        PRICE_YEAR10_MONTH9                 ''年度10_月度情報9
        PRICE_YEAR10_MONTH10                ''年度10_月度情報10
        PRICE_YEAR10_MONTH11                ''年度10_月度情報11
        PRICE_YEAR10_MONTH12                ''年度10_月度情報12
        PRICE_YEAR11_MONTH1                 ''年度11_月度情報1
        PRICE_YEAR11_MONTH2                 ''年度11_月度情報2
        PRICE_YEAR11_MONTH3                 ''年度11_月度情報3
        PRICE_YEAR11_MONTH4                 ''年度11_月度情報4
        PRICE_YEAR11_MONTH5                 ''年度11_月度情報5
        PRICE_YEAR11_MONTH6                 ''年度11_月度情報6
        PRICE_YEAR11_MONTH7                 ''年度11_月度情報7
        PRICE_YEAR11_MONTH8                 ''年度11_月度情報8
        PRICE_YEAR11_MONTH9                 ''年度11_月度情報9
        PRICE_YEAR11_MONTH10                ''年度11_月度情報10
        PRICE_YEAR11_MONTH11                ''年度11_月度情報11
        PRICE_YEAR11_MONTH12                ''年度11_月度情報12
        PRICE_YEAR12_MONTH1                 ''年度12_月度情報1
        PRICE_YEAR12_MONTH2                 ''年度12_月度情報2
        PRICE_YEAR12_MONTH3                 ''年度12_月度情報3
        PRICE_YEAR12_MONTH4                 ''年度12_月度情報4
        PRICE_YEAR12_MONTH5                 ''年度12_月度情報5
        PRICE_YEAR12_MONTH6                 ''年度12_月度情報6
        PRICE_YEAR12_MONTH7                 ''年度12_月度情報7
        PRICE_YEAR12_MONTH8                 ''年度12_月度情報8
        PRICE_YEAR12_MONTH9                 ''年度12_月度情報9
        PRICE_YEAR12_MONTH10                ''年度12_月度情報10
        PRICE_YEAR12_MONTH11                ''年度12_月度情報11
        PRICE_YEAR12_MONTH12                ''年度12_月度情報12
        PRICE_YEAR13_MONTH1                 ''年度13_月度情報1
        PRICE_YEAR13_MONTH2                 ''年度13_月度情報2
        PRICE_YEAR13_MONTH3                 ''年度13_月度情報3
        PRICE_YEAR13_MONTH4                 ''年度13_月度情報4
        PRICE_YEAR13_MONTH5                 ''年度13_月度情報5
        PRICE_YEAR13_MONTH6                 ''年度13_月度情報6
        PRICE_YEAR13_MONTH7                 ''年度13_月度情報7
        PRICE_YEAR13_MONTH8                 ''年度13_月度情報8
        PRICE_YEAR13_MONTH9                 ''年度13_月度情報9
        PRICE_YEAR13_MONTH10                ''年度13_月度情報10
        PRICE_YEAR13_MONTH11                ''年度13_月度情報11
        PRICE_YEAR13_MONTH12                ''年度13_月度情報12
        PRICE_YEAR14_MONTH1                 ''年度14_月度情報1
        PRICE_YEAR14_MONTH2                 ''年度14_月度情報2
        PRICE_YEAR14_MONTH3                 ''年度14_月度情報3
        PRICE_YEAR14_MONTH4                 ''年度14_月度情報4
        PRICE_YEAR14_MONTH5                 ''年度14_月度情報5
        PRICE_YEAR14_MONTH6                 ''年度14_月度情報6
        PRICE_YEAR14_MONTH7                 ''年度14_月度情報7
        PRICE_YEAR14_MONTH8                 ''年度14_月度情報8
        PRICE_YEAR14_MONTH9                 ''年度14_月度情報9
        PRICE_YEAR14_MONTH10                ''年度14_月度情報10
        PRICE_YEAR14_MONTH11                ''年度14_月度情報11
        PRICE_YEAR14_MONTH12                ''年度14_月度情報12
        PRICE_YEAR15_MONTH1                 ''年度15_月度情報1
        PRICE_YEAR15_MONTH2                 ''年度15_月度情報2
        PRICE_YEAR15_MONTH3                 ''年度15_月度情報3
        PRICE_YEAR15_MONTH4                 ''年度15_月度情報4
        PRICE_YEAR15_MONTH5                 ''年度15_月度情報5
        PRICE_YEAR15_MONTH6                 ''年度15_月度情報6
        PRICE_YEAR15_MONTH7                 ''年度15_月度情報7
        PRICE_YEAR15_MONTH8                 ''年度15_月度情報8
        PRICE_YEAR15_MONTH9                 ''年度15_月度情報9
        PRICE_YEAR15_MONTH10                ''年度15_月度情報10
        PRICE_YEAR15_MONTH11                ''年度15_月度情報11
        PRICE_YEAR15_MONTH12                ''年度15_月度情報12
        PRICE_YEAR16_MONTH1                 ''年度16_月度情報1
        PRICE_YEAR16_MONTH2                 ''年度16_月度情報2
        PRICE_YEAR16_MONTH3                 ''年度16_月度情報3
        PRICE_YEAR16_MONTH4                 ''年度16_月度情報4
        PRICE_YEAR16_MONTH5                 ''年度16_月度情報5
        PRICE_YEAR16_MONTH6                 ''年度16_月度情報6
        PRICE_YEAR16_MONTH7                 ''年度16_月度情報7
        PRICE_YEAR16_MONTH8                 ''年度16_月度情報8
        PRICE_YEAR16_MONTH9                 ''年度16_月度情報9
        PRICE_YEAR16_MONTH10                ''年度16_月度情報10
        PRICE_YEAR16_MONTH11                ''年度16_月度情報11
        PRICE_YEAR16_MONTH12                ''年度16_月度情報12
        PRICE_YEAR17_MONTH1                 ''年度17_月度情報1
        PRICE_YEAR17_MONTH2                 ''年度17_月度情報2
        PRICE_YEAR17_MONTH3                 ''年度17_月度情報3
        PRICE_YEAR17_MONTH4                 ''年度17_月度情報4
        PRICE_YEAR17_MONTH5                 ''年度17_月度情報5
        PRICE_YEAR17_MONTH6                 ''年度17_月度情報6
        PRICE_YEAR17_MONTH7                 ''年度17_月度情報7
        PRICE_YEAR17_MONTH8                 ''年度17_月度情報8
        PRICE_YEAR17_MONTH9                 ''年度17_月度情報9
        PRICE_YEAR17_MONTH10                ''年度17_月度情報10
        PRICE_YEAR17_MONTH11                ''年度17_月度情報11
        PRICE_YEAR17_MONTH12                ''年度17_月度情報12
        PRICE_YEAR18_MONTH1                 ''年度18_月度情報1
        PRICE_YEAR18_MONTH2                 ''年度18_月度情報2
        PRICE_YEAR18_MONTH3                 ''年度18_月度情報3
        PRICE_YEAR18_MONTH4                 ''年度18_月度情報4
        PRICE_YEAR18_MONTH5                 ''年度18_月度情報5
        PRICE_YEAR18_MONTH6                 ''年度18_月度情報6
        PRICE_YEAR18_MONTH7                 ''年度18_月度情報7
        PRICE_YEAR18_MONTH8                 ''年度18_月度情報8
        PRICE_YEAR18_MONTH9                 ''年度18_月度情報9
        PRICE_YEAR18_MONTH10                ''年度18_月度情報10
        PRICE_YEAR18_MONTH11                ''年度18_月度情報11
        PRICE_YEAR18_MONTH12                ''年度18_月度情報12
        PRICE_YEAR19_MONTH1                 ''年度19_月度情報1
        PRICE_YEAR19_MONTH2                 ''年度19_月度情報2
        PRICE_YEAR19_MONTH3                 ''年度19_月度情報3
        PRICE_YEAR19_MONTH4                 ''年度19_月度情報4
        PRICE_YEAR19_MONTH5                 ''年度19_月度情報5
        PRICE_YEAR19_MONTH6                 ''年度19_月度情報6
        PRICE_YEAR19_MONTH7                 ''年度19_月度情報7
        PRICE_YEAR19_MONTH8                 ''年度19_月度情報8
        PRICE_YEAR19_MONTH9                 ''年度19_月度情報9
        PRICE_YEAR19_MONTH10                ''年度19_月度情報10
        PRICE_YEAR19_MONTH11                ''年度19_月度情報11
        PRICE_YEAR19_MONTH12                ''年度19_月度情報12
        PRICE_YEAR20_MONTH1                 ''年度20_月度情報1
        PRICE_YEAR20_MONTH2                 ''年度20_月度情報2
        PRICE_YEAR20_MONTH3                 ''年度20_月度情報3
        PRICE_YEAR20_MONTH4                 ''年度20_月度情報4
        PRICE_YEAR20_MONTH5                 ''年度20_月度情報5
        PRICE_YEAR20_MONTH6                 ''年度20_月度情報6
        PRICE_YEAR20_MONTH7                 ''年度20_月度情報7
        PRICE_YEAR20_MONTH8                 ''年度20_月度情報8
        PRICE_YEAR20_MONTH9                 ''年度20_月度情報9
        PRICE_YEAR20_MONTH10                ''年度20_月度情報10
        PRICE_YEAR20_MONTH11                ''年度20_月度情報11
        PRICE_YEAR20_MONTH12                ''年度20_月度情報12
    End Enum
#End Region

#Region "構造体"
    ''マクロの引数
    Private Structure MacroArgu
        Dim createTime As String         ''作成日時
        Dim strFilePath As String        ''ファイル名
        Dim outRowInFile As Integer      ''1ファイルに出力するデータ量
        Dim outFile As String            ''出力資料の種類
    End Structure

    Private Structure ExtCount
        Dim Total As Long
        Dim Target As Long
        Dim Confirm As Long
        Dim NonTarget As Long
    End Structure
#End Region

#Region "インナークラス"
    Private Class PaymentDetailKeyData
        Inherits DataTable

        Sub New()
            Me.Columns.Add(ColumnNM_ContractNo, Type.GetType("System.String"))
            Me.Columns.Add(ColumnNM_FileNM, Type.GetType("System.String"))
            Me.Columns.Add(ColumnNM_FileNMSuffix, Type.GetType("System.String"))
            Me.Columns.Add(ColumnNM_FileIntraSuffix, Type.GetType("System.String"))
        End Sub

    End Class

    ''WS1のサマリカテゴリ情報の取得に使用
    Private Class SummaryTBLData
        Inherits DataTable

        Sub New()
            Me.Columns.Add(ColumnNM_KeyNo, Type.GetType("System.String"))
            Me.Columns.Add(ColumnNM_Bu, Type.GetType("System.String"))
            Me.Columns.Add(ColumnNM_Brand, Type.GetType("System.String"))
            Me.Columns.Add(ColumnNM_SummaryCategory, Type.GetType("System.String"))
            Me.Columns.Add(ColumnNM_SortKey, Type.GetType("System.String"))
        End Sub

    End Class

    Private Class PSExcelDataTable
        Inherits DataTable

        Public Sub New()

            Me.TableName = "PSExcelDataTable"

            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.ST_COST, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.ST_APPROVAL, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROJ_ID, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT_SEQ, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.NEW_EXIST, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CUST_CATEGORY, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LETTER_PLAN_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LETTER_ACCEPT_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.ORDER_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LETTER_ID, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.ORDERCODE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BU, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.SUM_CATEGORY, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND_SUB, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.OP1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.OP2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND_SIZE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.NON_SBO, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.POSTSCRIPT, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.TOPACS_CPNO, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_FORM, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_REQ, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_CONF, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM04, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM05, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM06, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM07, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM08, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM09, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM13, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM14, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM15, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM16, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM17, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM18, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM19, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM20, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM22, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM23, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM24, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.WD_ANNT_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.WD_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_CHG_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.QTY, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.INST_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_START_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_END_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BID_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_MONTHS, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_VALIDATION, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_APPLIED, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_NO, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_FORM, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_MANAGMENT, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_RATE_IOC, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_PROPOSAL, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.DP_IOC, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC_VAL, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.COST_RATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.COST, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.COST_TOTAL, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.COST_INPUT_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_TO_SPLIT, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_IOC, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_TOTAL_IOC, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.COST_TOTAL_IOC, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_TOTAL_IGF, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT_IN, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT_OUT, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_DEFF_IGF, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12, Type.GetType("System.String"))

            '行情報
            Me.Columns.Add("ExcelRow", Type.GetType("System.String"))
            Me.Columns.Add("DataKBN", Type.GetType("System.String"))
            Me.Columns.Add("RowSTATUS", Type.GetType("System.String"))
            Me.Columns.Add("DataKBN2", Type.GetType("System.String"))
            Me.Columns.Add("ErrReason", Type.GetType("System.String"))
            Me.Columns.Add("ENDDATE", Type.GetType("System.String"))
            Me.Columns.Add("EOSDATE", Type.GetType("System.String"))
            Me.Columns.Add("PsKBN", Type.GetType("System.String"))
            Me.Columns.Add("DeleteNO", Type.GetType("System.String"))
            Me.Columns.Add("TDateSTART", Type.GetType("System.String"))
            Me.Columns.Add("TDateEND", Type.GetType("System.String"))
            Me.Columns.Add("MDateSTART", Type.GetType("System.String"))
            Me.Columns.Add("MDateEND", Type.GetType("System.String"))

            ''ソート順
            Me.Columns.Add("SortAsc01", Type.GetType("System.String"))
            Me.Columns.Add("SortAsc02", Type.GetType("System.String"))
            Me.Columns.Add("SortAsc03", Type.GetType("System.String"))
            Me.Columns.Add("SortAsc04", Type.GetType("System.String"))
            Me.Columns.Add("SortAsc05", Type.GetType("System.String"))
            Me.Columns.Add("SortAsc06", Type.GetType("System.String"))
            Me.Columns.Add("SortAsc07", Type.GetType("System.String"))  '予備：拡張用
            Me.Columns.Add("SortDsc01", Type.GetType("System.Int64"))
            Me.Columns.Add("SortDsc02", Type.GetType("System.Int64"))
            Me.Columns.Add("SortDsc03", Type.GetType("System.Int64"))   '予備：拡張用

        End Sub

    End Class

    Private Class ITEM10DataTable
        Inherits DataTable

        Public Sub New()
            Me.TableName = "ITEM10DataTable"

            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10, Type.GetType("System.String"))
        End Sub
    End Class

#End Region

#Region "メンバ変数"
    Private INPUTDIALOG_DEFULT_PATH As String = FileManager.GetLocalFolderPath("Excel")
    Private SAMPELEXCEL_DEFULT_PATH As String = FileManager.GetLocalFolderPath("Template") & "PaymentLineSample_SumPS.xlsm"
    Private MASTERMDB_DEFULT_PATH As String = FileManager.GetLocalFolderPath("Mdb")
    Private FileContractno As String = ""

    Private OUTPUT_DEFAULTFOLDER As String
    Private OUTPUT_LOGFOLDER As String
    Private OUTPUT_TEMPLATEFOLDER As String

    '画面入力情報
    Private wExtYear As String
    Private wExtMonth As String
    Private wDelDataOutput As Boolean
    '集計情報
    Private OioEndDate As String
    Private ExtPSTotal As Long
    Private ExtPDTotal As Long
    Private ExtAASHW As ExtCount
    Private ExtHWMA As ExtCount
    Private ExtPA As ExtCount
    Private ExtOther As ExtCount
    Private ExtIgfLease As ExtCount
    Private ExtIgfExLease As ExtCount
    Private ExtNonTarget As ExtCount
    Private wSwmaYear As String
    Private OioEndYear As String
    Private OioEndMonth As String
    Private Item10Table As New ITEM10DataTable
    Private SwmaTBL As SwmaTable
    Private SpaTBL As ServicePac_ALLTable

    'Req:1569 シリアル重複チェックリスト str
    Private Schk_PS_Cnt As Long
    Private Schk_DB_Cnt As Long
    Private Schk_W_Cnt As Long
    'Req:1569 シリアル重複チェックリスト end

    'Req.1612 別紙B自動作成 2017/12 Str
    Private wCPNO As String
    'Req.1612 別紙B自動作成 2017/12 End

#End Region

#Region "コンストラクタ"
    Sub New()

            ' この呼び出しはデザイナーで必要です。
            InitializeComponent()

            ''画面項目のセット
            Me.txb_DispCpno.Text = CommonVariable.CPNO
            Me.txb_DispCustNm.Text = CommonVariable.CUSTOMERNAME
            Me.txb_Contact_No_Name.Text = CommonVariable.CONTRACTNONAME
            Me.txb_DispKeiyakuZyunban.Text = CommonVariable.CONTRACTNO.ToString.PadLeft(3, "0")

            '固定パスを相対パスへ
            Dim ofm As New OioFileManage
            OUTPUT_DEFAULTFOLDER = ofm.GetLocalOutputCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            OUTPUT_DEFAULTFOLDER = OUTPUT_DEFAULTFOLDER.Substring(0, OUTPUT_DEFAULTFOLDER.Length - 1)
            OUTPUT_LOGFOLDER = FileManager.GetLocalFolderPath(CommonConstant.FOLDERNAME_LOG)
            OUTPUT_LOGFOLDER = OUTPUT_LOGFOLDER.Substring(0, OUTPUT_LOGFOLDER.Length - 1)
            OUTPUT_TEMPLATEFOLDER = FileManager.GetLocalFolderPath(CommonConstant.FOLDERNAME_TEMPLATE)
            OUTPUT_TEMPLATEFOLDER = OUTPUT_TEMPLATEFOLDER.Substring(0, OUTPUT_TEMPLATEFOLDER.Length - 1)
        End Sub

#End Region

#Region "イベントハンドラ"

    ''' <summary>
    ''' 機能：画面の読み込み処理
    ''' 説明：画面の読み込み処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Frm_DataOutput_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        '実行環境＋Version
        Me.Text = CommonVariable.OBAMATITLE

        ''更新前の契約順番を取得
        FileContractno = CommonVariable.CONTRACTNO

        ''統合Payment分割件数の表示
        '1722 str
        'Dim maxLinno As Integer
        'maxLinno = GetMaxSheetLine()
        'Me.txb_ChangePage.Text = Format(maxLinno, "###,###,###,##0")
        '1722 end

        ''PS/詳細ファイルパスの初期設定
        Call DispPSTextBox()

        Try
            ''契約済みﾃﾞｰﾀ件数表示
            Dim ofm As New OioFileManage
            Dim Cpno As String
            Cpno = ofm.GetCpnoForPaymentXls(txb_InputFile.Text)
            'Req.1612 別紙B自動作成 2017/12 Str
            wCPNO = Cpno
            'Req.1612 別紙B自動作成 2017/12 End

            Dim MaxMdbCount As Integer
            MaxMdbCount = GetMaxMdbCount(Cpno)
            lbl_Contract.Text = MaxMdbCount.ToString("###,###,###,##0")
            '1722 str
            Me.txb_ChangePage.Text = MaxMdbCount.ToString("###,###,###,##0")
            '1722 end
        Catch ex As Exception
            lbl_Contract.Text = 0
        End Try

        '画面の読み込み時はIOCﾌｧｲﾙの指定が無いため、請求品目管理資料作成ﾎﾞﾀﾝ以外は非表示とする
        If Me.txb_InputFile.Text = "" Then
            Me.Cmb_SumPaymentSheet.Enabled = False
            Me.Btn_OutKakakuSyouninNonLock.Enabled = False
            Me.Btn_OutKakakuSyounin.Enabled = False
            Me.Btn_OutCOCPS.Enabled = False
            Me.Btn_OutProjctIOC.Enabled = False
            Me.Btn_OutSeikyu.Enabled = False
            Me.Btn_OutConList.Enabled = False
            Me.Btn_DelCheckList.Enabled = False
            Me.Btn_Extension.Enabled = False
        Else
            Me.Cmb_SumPaymentSheet.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.Cmb_SumPaymentSheet.Name)
            Me.Btn_OutKakakuSyouninNonLock.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.Btn_OutKakakuSyouninNonLock.Name)
            Me.Btn_OutKakakuSyounin.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.Btn_OutKakakuSyounin.Name)
            Me.Btn_OutCOCPS.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.Btn_OutCOCPS.Name)
            Me.Btn_OutProjctIOC.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.Btn_OutProjctIOC.Name)
            Me.Btn_OutSeikyu.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.Btn_OutSeikyu.Name)
            Me.Btn_OutConList.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.Btn_OutConList.Name)
            Me.Btn_DelCheckList.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.Btn_DelCheckList.Name)
            Me.Btn_Extension.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.Btn_Extension.Name)
        End If

        Call Me.Init_Cmb_SumPaymentSheet()

    End Sub


    ''' <summary>
    ''' 機能：ファイルの参照ボタンの処理
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Btn_InputFileDisp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_InputFileDisp.Click
        Dim dialog As OpenFileDialog = New OpenFileDialog
        Dim InitialDirectory As New OioFileManage
        dialog.Filter = INPUTDIALOG_FILTER_XLS

        'フォルダの初期位置
        Dim FolderPath As String = InitialDirectory.GetLocalCPNOFolder(Me.txb_DispCpno.Text.Trim, CInt(FileContractno))
        ''フォルダが存在しない
        If Directory.Exists(FolderPath) = False Then
            MuseMessageBox.ShowWarning(FileReader.GetMessage("MSG_0208"), Me.Text)
            FolderPath = FileManager.GetLocalFolderPath(CommonConstant.FOLDERNAME_EXCEL)
        End If

        dialog.InitialDirectory = FolderPath
        If dialog.ShowDialog() = DialogResult.OK Then
            Dim fileName As String = dialog.FileName

            ''Open済みの個別PSファイルの存在チェック
            Dim ofm As New OioFileManage
            If ofm.ChkOpenedExcelFile(fileName) = False Then
                Call MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0324") & vbCrLf & vbCrLf _
                                              & "ファイル名：" & Path.GetFileName(fileName), Me.Text)
                Exit Sub
            End If

            Me.txb_InputFile.Text = fileName

            ''契約済みデータ件数表示
            If Trim(txb_InputFile.Text) <> "" Then
                Try
                    '権限によってオブジェクト可否
                    Me.Cmb_SumPaymentSheet.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.Cmb_SumPaymentSheet.Name)
                    Me.Btn_OutKakakuSyouninNonLock.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.Btn_OutKakakuSyouninNonLock.Name)
                    Me.Btn_OutKakakuSyounin.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.Btn_OutKakakuSyounin.Name)
                    Me.Btn_OutCOCPS.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.Btn_OutCOCPS.Name)
                    Me.Btn_OutProjctIOC.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.Btn_OutProjctIOC.Name)
                    Me.Btn_OutSeikyu.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.Btn_OutSeikyu.Name)
                    Me.Btn_OutConList.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.Btn_OutConList.Name)
                    Me.Btn_DelCheckList.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.Btn_DelCheckList.Name)

                    ''契約済みﾃﾞｰﾀ件数表示
                    Dim Cpno As String
                    Cpno = ofm.GetCpnoForPaymentXls(txb_InputFile.Text)

                    Dim MaxMdbCount As Integer
                    MaxMdbCount = GetMaxMdbCount(Cpno)
                    lbl_Contract.Text = MaxMdbCount.ToString("###,###,###,##0")

                Catch ex As Exception
                    lbl_Contract.Text = 0
                End Try

            Else

            End If

        End If

    End Sub

    ''' <summary>
    ''' 機能：ﾌｫﾙﾀﾞ表示ボタンの共通処理
    ''' 説明：※ﾌｫﾙﾀﾞ表示ボタン1～6は全て同じﾌｫﾙﾀﾞを参照する。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub DispExplorer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DispExplorer1.Click
        ''Explorer表示
        Dim ofm As New OioFileManage
        If ofm.DispExplorer(CommonConstant.FOLDERNAME_OUTPUT, CommonVariable.CPNO, CommonVariable.CONTRACTNO) = False Then
            MsgBox(FileReader.GetMessage("MSG_0208"), MsgBoxStyle.Exclamation, "")
        End If

    End Sub


    ''' <summary>
    ''' 機　能：統合Payment分割件数の書式変換
    ''' 説　明：※入力後、[,]をフォーマットとして入力する。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub txb_ChangePage_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txb_ChangePage.Leave


        ''値が数字ならフォーマットを整える。
        Dim value As String
        value = Me.txb_ChangePage.Text.Replace(",", "")
        If IsNumeric(value) Then
            sender.text = Format(CInt(value), "###,###,###,###,##0")
        End If

    End Sub

    ''' <summary>
    ''' 機能：作成ボタンの共通処理
    ''' 説明：作成ボタンの共通処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    'Req:1569 シリアル重複チェックリスト str
    'Private Sub Btn_OutputBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _
    '                                                                                            Btn_OutKakakuSyounin.Click, _
    '                                                                                            Btn_OutCOCPS.Click, _
    '                                                                                            Btn_OutSeikyu.Click, _
    '                                                                                            Btn_OutProjctIOC.Click, _
    '                                                                                            Btn_OutConList.Click, _
    '                                                                                            Btn_DelCheckList.Click, _
    '                                                                                            Btn_OutKakakuSyouninNonLock.Click, _
    '                                                                                            Btn_Extension.Click
    Private Sub Btn_OutputBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _
                                                                                                Btn_OutKakakuSyounin.Click, _
                                                                                                Btn_OutCOCPS.Click, _
                                                                                                Btn_OutSeikyu.Click, _
                                                                                                Btn_OutProjctIOC.Click, _
                                                                                                Btn_OutConList.Click, _
                                                                                                Btn_DelCheckList.Click, _
                                                                                                Btn_OutKakakuSyouninNonLock.Click, _
                                                                                                Btn_Extension.Click, _
                                                                                                Btn_SerialCheckList.Click
        'Req:1569 シリアル重複チェックリスト end

        Dim dtStart As DateTime = DateTime.Now
        Dim dtEnd As DateTime

        '処理中ダイアログ定義
        Dim waitDialog As New Frm_WaitDialog

        ''画面の入力値チェック
        If ChkFrmInputDate(sender.name) = False Then
            Return
        End If

        If sender.name = "Btn_Extension" Then
            '==============================
            '◇延長期間指定画面表示◇
            '==============================
            Dim el As New Frm_ExtensionList

            el.StartYear = CommonVariable.ContractStart.ToString("yyyy")
            el.StartMonth = CommonVariable.ContractStart.ToString("MM")
            el.EndYear = CommonVariable.ContractEnd.ToString("yyyy")
            el.EndMonth = CommonVariable.ContractEnd.ToString("MM")

            el.ExtYear = CommonVariable.ContractEnd.AddYears(5).ToString("yyyy")
            el.ExtMonth = CommonVariable.ContractEnd.AddYears(5).ToString("MM")
            el.DelDataOutput = False
            el.isOK = False

            '画面表示
            el.ShowDialog()

            'キャンセル
            If el.isOK = False Then
                Exit Sub
            End If

            wExtYear = el.ExtYear
            wExtMonth = el.ExtMonth
            wDelDataOutput = el.DelDataOutput

            OioEndYear = el.EndYear
            OioEndMonth = el.EndMonth

            el.Close()
        End If

        Try
            Me.Cursor = Cursors.WaitCursor
            Me.Enabled = False
            '処理中ダイアログ表示
            waitDialog.Text = STR_CREATING
            waitDialog.lbl_Message.Text = ""
            waitDialog.Pic_Excel.Visible = True
            waitDialog.ProgressMin = 0
            waitDialog.ProgressMax = 10
            waitDialog.ProgressStep = 1
            waitDialog.ProgressValue = 0
            waitDialog.Show()
            waitDialog.Refresh()

            ''Version管理機能強化 
            Dim msg As String
            Dim ofm As New OioFileManage
            Select Case sender.name
                Case "Btn_OutKakakuSyounin", _
                     "Btn_OutKakakuSyouninNonLock"

                    waitDialog.lbl_Message.Text = STR_MESSAGE_CHKVER_PAYMENT
                    waitDialog.PerformStep()
                    waitDialog.Refresh()

                    ''PaymentのVer確認
                    If ofm.ChkFileVer(Me.txb_InputFile.Text, msg) = False Then
                        Call MuseMessageBox.ShowError(msg, Me.Text)
                        Return
                    End If
                    ''templateﾌｧｲﾙ最新にする
                    If sender.name = "Btn_Extension" Then
                    End If
                    If ofm.CopyGSATmpFile(OioFileManage.enmTmpFileType.PaymentSum, msg) = False Then
                        Call MuseMessageBox.ShowError(msg, Me.Text)
                        Return
                    End If
            End Select

            'MasterMDB存在チェック
            If sender.name = "Btn_OutKakakuSyounin" Or
                sender.name = "Btn_OutKakakuSyouninNonLock" Or
                sender.name = "Btn_OutSeikyu" Then
                Dim strRetMsg As String
                If ofm.CheckExistsMdb(OioFileManage.enmMdbType.Master, CommonVariable.MdbPW, strRetMsg) = False Then
                    Call MuseMessageBox.ShowError(strRetMsg, Me.Text)
                    Exit Sub
                End If
            End If

            '処理が価格承認サマリー、請求品目の場合、マスターバージョンチェックのチェックを行う
            If sender.name = "Btn_OutKakakuSyounin" Or
                sender.name = "Btn_OutKakakuSyouninNonLock" Or
                sender.name = "Btn_OutSeikyu" Then
                waitDialog.lbl_Message.Text = STR_MESSAGE_CHKVER_MDB
                waitDialog.PerformStep()
                waitDialog.Refresh()
                If ofm.CheckMdbVersion(CommonVariable.MdbPW,
                                       OioFileManage.enmMdbType.Master,
                                       msg,
                                       CommonVariable.CPNO) = False Then
                    Call MuseMessageBox.ShowError(msg, Me.Text)
                    Return
                End If
            End If

            ''Errorシートの更新
            Select Case sender.name
                Case "Btn_OutKakakuSyounin",
                     "Btn_OutCOCPS",
                     "Btn_OutProjctIOC",
                     "Btn_OutKakakuSyouninNonLock"
                    waitDialog.lbl_Message.Text = STR_MESSAGE_UDT_ERROR
                    waitDialog.PerformStep()
                    waitDialog.Refresh()

                    ''Errorシートのﾘﾌﾚｯｼｭ
                    Dim strRetMsg As String = ""
                    If ExcelWrite.KickVBASuffixUpAct(ExcelWrite.VBActNMList.Chk_集計管理台帳, Me.txb_InputFile.Text, CommonVariable.USERID, CommonVariable.USERPW, True, strRetMsg) = False Then
                        Exit Sub
                    End If
                    Select Case strRetMsg
                        Case "Client未導入"
                            If MsgBox(FileReader.GetMessage("MSG_0424"), MsgBoxStyle.Information + MsgBoxStyle.YesNo) = MsgBoxResult.No Then
                                Exit Sub
                            End If
                        Case "ｻｰﾊﾞｰ接続無し"
                            If MsgBox(FileReader.GetMessage("MSG_0425"), MsgBoxStyle.Information + MsgBoxStyle.YesNo) = MsgBoxResult.No Then
                                Exit Sub
                            End If
                        Case "ｴﾗｰ1"
                            If sender.name = "Btn_OutKakakuSyounin" Then
                                MsgBox(FileReader.GetMessage("MSG_0426"), MsgBoxStyle.Exclamation)
                                Exit Sub
                            Else
                                If MsgBox(FileReader.GetMessage("MSG_0427"), MsgBoxStyle.Information + MsgBoxStyle.YesNo) = MsgBoxResult.No Then
                                    Exit Sub
                                End If
                            End If
                        Case "ｴﾗｰ2"
                            If MsgBox(FileReader.GetMessage("MSG_0427"), MsgBoxStyle.Information + MsgBoxStyle.YesNo) = MsgBoxResult.No Then
                                Exit Sub
                            End If

                            'Req.1550 案件番号チェック 2017/03 Str
                        Case "ｴﾗｰ3"
                            Select Case sender.name
                                Case "Btn_OutKakakuSyounin",
                                     "Btn_OutKakakuSyouninNonLock"
                                    MsgBox(FileReader.GetMessage("MSG_0551"), MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly)
                                    Exit Sub
                            End Select
                            'Req.1550 案件番号チェック 2017/03 End
                    End Select
            End Select

            'サーバーから契約済データを取得しTempDBに保存する
            waitDialog.lbl_Message.Text = STR_MESSAGE_DOWNLOAD
            waitDialog.PerformStep()
            waitDialog.Refresh()
            Dim blnRet As Boolean
            Dim strErrMsg As String = ""
            blnRet = GetNewTempDb(sender.name.ToString, strErrMsg)
            If blnRet = False Or strErrMsg <> "" Then
                If strErrMsg = FileReader.GetMessage("MSG_0470") Then
                    'Req:1569 シリアル重複チェックリスト str
                    'If sender.name = "Btn_OutCOCPS" Or
                    '    sender.name = "Btn_OutSeikyu" Or
                    '    sender.name = "Btn_OutConList" Or
                    '    sender.name = "Btn_DelCheckList" Or _
                    '    sender.name = "Btn_Extension" Then

                    If sender.name = "Btn_OutCOCPS" Or
                        sender.name = "Btn_OutSeikyu" Or
                        sender.name = "Btn_OutConList" Or
                        sender.name = "Btn_DelCheckList" Or _
                        sender.name = "Btn_Extension" Or _
                        sender.name = "Btn_SerialCheckList" Then
                        'Req:1569 シリアル重複チェックリスト end
                        Throw New Exception(strErrMsg)
                        Exit Sub
                    End If
                Else
                    If strErrMsg <> "" Then
                        Throw New Exception(strErrMsg)
                    Else
                        Throw New Exception(FileReader.GetMessage("MSG_0392"))
                    End If
                    Exit Sub
                End If
            End If

            If ofm.CheckExistsMdb(OioFileManage.enmMdbType.TempMdb, CommonVariable.MdbPW, strErrMsg, CommonVariable.CPNO) = False Then
                Call MuseMessageBox.ShowError(strErrMsg, Me.Text)
                Exit Sub
            End If

            'TempMDBのバージョンチェック
            If ofm.CheckMdbVersion(CommonVariable.MdbPW,
                                   OioFileManage.enmMdbType.TempMdb,
                                   msg,
                                   CommonVariable.CPNO) = False Then
                Call MuseMessageBox.ShowError(msg, Me.Text)
                Return
            End If

            waitDialog.lbl_Message.Text = STR_MESSAGE_CREATE_FILE
            waitDialog.PerformStep()
            waitDialog.Refresh()

            ''フォルダの作成
            Dim FileManage As New OioFileManage
            FileManage.CreateLocalOutputCpNoFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)

            Dim strMsg As String = String.Empty
            Select Case sender.name
                Case "Btn_OutKakakuSyouninNonLock"
                    strMsg = BaseOutExcel(OUTPUT_TYOUHYOUNAME_KAKAKUSYOUNINN, OUTPUT_DEFAULTFOLDER & "\", waitDialog, False)
                Case "Btn_OutKakakuSyounin"
                    strMsg = BaseOutExcel(OUTPUT_TYOUHYOUNAME_KAKAKUSYOUNINN, OUTPUT_DEFAULTFOLDER & "\", waitDialog, True)
                Case "Btn_OutCOCPS"
                    strMsg = BaseOutExcel(OUTPUT_TYOUHYOUNAME_PAYMENTCOC, OUTPUT_DEFAULTFOLDER & "\", waitDialog, False)
                Case "Btn_OutSeikyu"
                    strMsg = BaseOutExcel(OUTPUT_TYOUHYOUNAME_SEUKYU, OUTPUT_DEFAULTFOLDER & "\", waitDialog, False)
                Case "Btn_OutProjctIOC"
                    strMsg = BaseOutExcel(OUTPUT_TYOUHYOUNAME_PROJECTIOC, OUTPUT_DEFAULTFOLDER & "\", waitDialog, False)
                Case "Btn_OutConList"
                    strMsg = ConListExcelOutput(OUTPUT_DEFAULTFOLDER & "\", waitDialog)
                Case "Btn_DelCheckList"
                    strMsg = DelDateCheckList(OUTPUT_DEFAULTFOLDER & "\", waitDialog)
                Case "Btn_Extension"
                    strMsg = ExtensionListOutput(OUTPUT_DEFAULTFOLDER & "\", waitDialog)
                    'Req:1569 シリアル重複チェックリスト str
                Case "Btn_SerialCheckList"
                    strMsg = SerialCheckListOutput(OUTPUT_DEFAULTFOLDER & "\", waitDialog)
                    'Req:1569 シリアル重複チェックリスト end
                Case Else
                    Exit Sub
            End Select

                ''画面の値を元に戻す
                waitDialog.Close()
                Me.Enabled = True
                Me.Cursor = Cursors.Default

                dtEnd = DateTime.Now

                ''完了メッセージの表示
                Select Case strMsg
                    Case String.Empty
                        ''1つもファイルが作成できない場合
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0319") & strMsg, Me.Text)
                    Case "NoCheck"
                        '集計対象ファイルが選択されていない場合（ｴﾗｰﾒｯｾｰｼﾞを出力しない）
                        Exit Sub
                    Case Else
                        Debug.Print("処理時間　" & (dtEnd - dtStart).ToString)
                        ''1つ以上、ﾌｧｲﾙが作成された場合
                        MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0213") & vbCrLf & strMsg, Me.Text)
                End Select

        Catch ex As Exception

            ''管理台帳作成中に以下のエラーが出たらエラーを表示
            ''①マクロ有りのテンプレファイルのｺﾋﾟｰ等、
            ''②その他、O-BAMAシートのｺﾋﾟｰ等の処理エラー
            Select Case ex.Message
                Case FileReader.GetMessage("MSG_0414")
                    MsgBox(ex.Message, MsgBoxStyle.Information, Me.Text)

                    ''完了メッセージ
                Case FileReader.GetMessage("MSG_0450")
                    MsgBox(ex.Message, MsgBoxStyle.Information, Me.Text)
                Case Else
                    MsgBox(ex.Message, MsgBoxStyle.Critical, Me.Text)
            End Select
            Me.Activate()

        Finally
            ''画面の値を元に戻す
            waitDialog.Close()
            Me.Enabled = True
            Me.Cursor = Cursors.Default
        End Try

    End Sub

    ''' <summary>
    ''' 機能：戻るボタンの処理
    ''' 説明：戻るボタンの処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Btn_Rtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Rtn.Click
        Dim frm As New Frm_Menu()

        Me.Hide()

        frm.ShowDialog()
        Me.Close()
    End Sub

    ''' <summary>
    ''' 機能：ログアウトボタンの処理
    ''' 説明：ログアウトボタンの処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnLogOut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogOut.Click
        Me.Close()
    End Sub

#End Region

#Region "プライベートメソッド"

    ''' <summary>
    ''' 機能：作成ボタンの処理（共通処理）
    ''' 説明：作成ボタンの処理（共通処理）
    ''' </summary>
    ''' <param name="OutFile"></param>
    ''' <param name="OutFilePath"></param>
    ''' <param name="waitDialog"></param>
    ''' <param name="blnSheetLock"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function BaseOutExcel(ByVal OutFile As String, _
                                  ByVal OutFilePath As String, _
                                  ByVal waitDialog As Frm_WaitDialog, _
                                  ByVal blnSheetLock As Boolean) As String

        Dim strCreateFileName(0 To 2) As String         '配列1:ChekBox1  配列2:ChekBox2  配列3:ChekBox3　処理が１の場合、配列1にセット
        Dim blnChk(0 To 2) As Boolean                   '配列1:ChekBox1  配列2:ChekBox2  配列3:ChekBox3　処理が１の場合、配列1にセット
        Dim strWork As String
        Dim blnRet As Boolean = False
        Dim blnCheck As Boolean
        Dim strErrMsg As String = ""

        ''例外処理の概要
        ''①Templeteのコピー、O-BAMASheetのTemplateﾌｧｲﾙへのｺﾋﾟｰ等が失敗した場合、呼び出し元へ例外をThrowする。
        ''②以下のタスク中にエラーが発生した場合、例外をThrowせずに処理を実行する。
        ''  ・マクロの実行時
        ''　・Cost削除データ作成時にエラーが発生した場合
        Try

            ''マクロ実行用の引数を設定（集計資料作成種類）
            Dim msg As String = String.Empty
            Dim chkcre1 As Boolean = False
            Dim chkcre2 As Boolean = False
            Dim chkcre3 As Boolean = False
            Call SetChkBoxInfo(OutFile, chkcre1, chkcre2, chkcre3)

            'Logフォルダがなければ作成
            If Not Directory.Exists(OUTPUT_LOGFOLDER) Then
                Directory.CreateDirectory(OUTPUT_LOGFOLDER)
            End If

            'LogフォルダにPSのコピーを作成
            Dim PSFilePathInLogFolder As String = OUTPUT_LOGFOLDER _
                                                  & "\OutputLog_" _
                                                  & Path.GetFileName(Me.txb_InputFile.Text)
            System.IO.File.Copy(Me.txb_InputFile.Text, PSFilePathInLogFolder, True)

            'TemplateをLogフォルダにコピーする。
            Dim templateFileInLog As String = OUTPUT_LOGFOLDER & "\PaymentLineSample_Sum.xlsm"
            Dim templateFileInTemplate As String = OUTPUT_TEMPLATEFOLDER & "\PaymentLineSample_Sum.xlsm"
            System.IO.File.Copy(templateFileInTemplate, templateFileInLog, True)

            waitDialog.PerformStep()

            'ファイルの作成日時
            Dim createTime As String
            createTime = Now.ToString("_yyyyMMdd_HHmmss")

            'Cost削除の個別詳細ファイル
            Dim strFileNameCopyDetail As String
            Dim strFileNameDetail As String

            ''VBAマクロに渡す引数
            Dim macroInfo As MacroArgu
            macroInfo = SetMacroParam(createTime, templateFileInLog, OutFile)

            ''押下した、作成ボタンに応じて処理を変更
            'Dim msg As String = String.Empty
            Dim result As String = String.Empty
            Dim isDetail As Boolean = False
            Select Case OutFile
                Case OUTPUT_TYOUHYOUNAME_KAKAKUSYOUNINN
                    '===================================================
                    '価格承認サマリー
                    '===================================================
                    Dim strJoinPsFileName As String = ""                        '統合Paymentファイル名（フルパス）
                    Dim strNormalMsg As String = ""                             '通常ファイル完了メッセージ
                    Dim strJoinPsMsg As String = ""                             '統合Payment完了メッセージ
                    Dim strDelCostMsg As String = ""                            'COST削除ファイル完了メッセージ

                    ''マクロ実行
                    Call SheetCopy(templateFileInLog, Me.txb_InputFile.Text)
                    ExecExcelMacro("LPASIOCCOC", macroInfo, chkcre1, chkcre2, chkcre3, blnSheetLock, result, CommonVariable.USERID, CommonVariable.USERPW)
                    If result = "NG" Then
                        Exit Function
                    End If

                    waitDialog.PerformStep()

                    ''出力ファイル名の取得
                    strWork = CreateOutputFileName(OUTPUT_DEFAULTFOLDER, createTime, "_@")
                    If blnSheetLock = True Then
                        strCreateFileName(IDX_CHK_BOX1) = strWork.Replace("@", "Summary(Lock済)")
                    Else
                        strCreateFileName(IDX_CHK_BOX1) = strWork.Replace("@", "Summary")
                    End If
                    strCreateFileName(IDX_CHK_BOX2) = strWork.Replace("@", "COC_S")
                    strCreateFileName(IDX_CHK_BOX3) = strWork.Replace("@", "COCIOC_S")
                    '通常ファイル存在チェック
                    If chkcre1 = True Then
                        If File.Exists(strCreateFileName(IDX_CHK_BOX1)) = True Then
                            strNormalMsg = strNormalMsg & vbCrLf & " 個別PS(IOC)月次展開集計、価格承認サマリー"
                        Else
                            BaseOutExcel = "NoCheck"
                            Exit Function
                        End If
                    End If

                    'Req.1612 別紙B自動作成 2017/12 Str
                    macroInfo = SetMacroParam(createTime, strCreateFileName(IDX_CHK_BOX1), OutFile)

                    If GetCode(wCPNO) = True Then
                        ExecExcelMacro("AttachBCall", macroInfo, chkcre1, chkcre2, chkcre3, blnSheetLock, result, CommonVariable.USERID, CommonVariable.USERPW)
                        If result = "NG" Then
                            Exit Function
                        End If
                    End If
                    'Req.1612 別紙B自動作成 2017/12 End


                    If chkcre1 = True Then
                        '統合Paymentシートを作成
                        Call CreateSumPaymentSheet(Me.Cmb_SumPaymentSheet.Text,
                                                   Me.txb_InputFile.Text,
                                                   strCreateFileName(IDX_CHK_BOX1),
                                                   createTime,
                                                   strJoinPsFileName,
                                                   blnSheetLock)

                        '別ファイルで統合Paymentシートを出力した場合
                        If Cmb_SumPaymentSheet.Text = CmbValue_SumPayment_OutPutOth Then
                            If File.Exists(strJoinPsFileName) = True Then
                                strJoinPsMsg = vbCrLf & " 統合Payment"
                            End If
                        End If
                    End If

                    '' マクロ以外のファイルの作成
                    '’個別PS(IOC)月次展開集計（コスト列の削除）
                    If Me.ChkCostDel.Checked = True Then
                        blnChk(IDX_CHK_BOX1) = chkcre1
                        blnChk(IDX_CHK_BOX2) = chkcre2
                        blnChk(IDX_CHK_BOX3) = chkcre3
                        blnRet = CreateDeleteCostFile(strCreateFileName, OutFile, blnChk, blnSheetLock, strJoinPsFileName)
                        If blnRet = True Then
                            strDelCostMsg = vbCrLf & vbCrLf & "【COST削除】" & strNormalMsg
                            If strJoinPsFileName <> "" Then
                                strDelCostMsg = strDelCostMsg & vbCrLf & " 統合Payment"
                            End If
                        Else
                            Exit Function
                        End If
                    End If
                    msg = strNormalMsg & strJoinPsMsg & strDelCostMsg

                Case OUTPUT_TYOUHYOUNAME_PAYMENTCOC
                    '===================================================
                    '統合Payment(IOC/COC)
                    '===================================================
                    ''ファイル名の設定
                    Dim isDelCostSUMIOC As Boolean = False
                    Dim isSUMCOCIOC As Boolean = False
                    Dim strFileNameSUMIOC As String
                    Dim strFileNameDelCostSUMIOC As String

                    ''作成中のデータを契約締結済MDBへセット
                    Dim ofm As New OioFileManage
                    Dim psPath As String = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, _
                                                                    CommonVariable.CONTRACTNO)
                    psPath = psPath & ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, _
                                                                    CommonVariable.CONTRACTNO)
                    Dim categoryList As SummaryTBLData
                    Dim oioList As ArrayList
                    Dim excelStrYear As String
                    Call GetPaymentData(psPath, categoryList, oioList, excelStrYear)
                    Call CreateDataKeepMDB(CommonVariable.CPNO, categoryList, oioList, excelStrYear)

                    ''マクロ実行
                    ''※総合資料は、処理完了メッセージをマクロ内で取得する。
                    Dim fileCount As Integer
                    ExecExcelMacro("IPSSCOCIOC", macroInfo, chkcre1, chkcre2, chkcre3, blnSheetLock, result)
                    If result = "NoCheck" Then
                        msg = result
                    Else
                        msg = msg & result.Substring(3, result.Length - 3)
                    End If

                    ''出力ファイル数を取得
                    If Trim(result) <> "NoCheck" And _
                       Trim(result) <> "" Then
                        If result.IndexOf("ﾌｧｲﾙ数：") = -1 Then
                            fileCount = 1
                        Else
                            fileCount = CInt(result.Substring(result.IndexOf("ﾌｧｲﾙ数：") + "ﾌｧｲﾙ数：".Length, _
                                             result.Length - (result.IndexOf("ﾌｧｲﾙ数：") + "ﾌｧｲﾙ数：".Length)))
                        End If
                    End If

                    waitDialog.PerformStep()

                    '''統合PaymentSheet　【COST削除】IOC月次展開集計（コスト列の削除）
                    ' ※マクロの修正はリスクが高いため、VB.netで個別PS(IOC)月次展開集計をコピーし、コスト情報を削除する。
                    If Me.ChkCostDel.Checked = True Then
                        blnCheck = True
                        For i As Integer = 1 To fileCount
                            blnChk(IDX_CHK_BOX1) = chkcre1
                            blnChk(IDX_CHK_BOX2) = chkcre2
                            blnChk(IDX_CHK_BOX3) = chkcre3
                            strWork = CreateOutputFileName(OUTPUT_DEFAULTFOLDER, createTime, "_@", i, fileCount)
                            strCreateFileName(IDX_CHK_BOX1) = strWork.Replace("@", "統合Payment_Brand別集計(IOC)")
                            strCreateFileName(IDX_CHK_BOX2) = strWork.Replace("@", "COC")
                            strCreateFileName(IDX_CHK_BOX3) = strWork.Replace("@", "COCIOC")
                            blnRet = CreateDeleteCostFile(strCreateFileName, OutFile, blnChk, blnSheetLock)
                            If blnRet = False Then
                                blnCheck = False
                                Exit For
                            End If
                        Next
                        If blnCheck = True Then
                            msg = msg & vbCrLf & vbCrLf & "【COST削除】" & result.Substring(3, result.Length - 3)
                        End If
                    End If

                Case OUTPUT_TYOUHYOUNAME_SEUKYU
                    '===================================================
                    '請求品目
                    '※出力された請求品目ファイルはCOSTを削除した状態で出力されるため、新たにCOST削除ファイルを作成しない
                    '===================================================
                    Dim isSeikyu As Boolean = False
                    Dim strFileNameSeikyu As String
                    Dim isCostDelSeikyu As Boolean = False
                    Dim strCostDelFileNameSeikyu As String

                    ''管理台帳出力用MDBの作成
                    Call CreateTmpKeepMDB(Me.txb_InputFile.Text)

                    ''マクロ実行
                    ExecExcelMacro("LPASREQUEST", macroInfo, chkcre1, chkcre2, chkcre3, blnSheetLock, result, CommonVariable.USERID, CommonVariable.USERPW)

                    waitDialog.PerformStep()
                    msg = result

                Case OUTPUT_TYOUHYOUNAME_PROJECTIOC
                    '===================================================
                    '案件別IOC
                    '===================================================

                    Dim isProjectIoc As Boolean = False
                    Dim fileNameProjectIoc As String

                    ''マクロ実行
                    Call ExecExcelMacro("IPSSIOCPLAN", macroInfo, chkcre1, chkcre2, chkcre3, blnSheetLock, result)

                    waitDialog.PerformStep()
                    fileNameProjectIoc = CreateOutputFileName(OUTPUT_DEFAULTFOLDER, createTime, "_案件番号別集計")

                    If File.Exists(fileNameProjectIoc) = True Then
                        msg = msg & vbCrLf & "案件別IOC資料"
                    End If

                    'COST削除別ファイル
                    If Me.ChkCostDel.Checked = True Then
                        blnChk(IDX_CHK_BOX1) = True
                        blnChk(IDX_CHK_BOX2) = False
                        blnChk(IDX_CHK_BOX3) = False
                        strCreateFileName(IDX_CHK_BOX1) = fileNameProjectIoc
                        strCreateFileName(IDX_CHK_BOX2) = ""
                        strCreateFileName(IDX_CHK_BOX3) = ""
                        blnRet = CreateDeleteCostFile(strCreateFileName, OutFile, blnChk, blnSheetLock)
                        If blnRet = True Then
                            msg = msg & vbCrLf & vbCrLf & "【COST削除】" & vbCrLf & "案件別IOC資料"
                        End If
                    End If
            End Select
            Return msg

        Catch ex As Exception
            Throw ex

        End Try

    End Function

    ''' <summary>
    ''' マクロ実行
    ''' </summary>
    ''' <param name="strMacro"></param>
    ''' <param name="macroInfo"></param>
    ''' <param name="chkcre1"></param>
    ''' <param name="chkcre2"></param>
    ''' <param name="chkcre3"></param>
    ''' <param name="blnLock">シートロック　有：True　無：False</param>
    ''' <param name="Result"></param>
    ''' <remarks></remarks>
    Private Sub ExecExcelMacro(ByVal strMacro As String, _
                               ByVal macroInfo As MacroArgu, _
                               Optional ByVal chkcre1 As Boolean = False, _
                               Optional ByVal chkcre2 As Boolean = False, _
                               Optional ByVal chkcre3 As Boolean = False, _
                               Optional ByVal blnLock As Boolean = False, _
                               Optional ByRef Result As String = "", _
                               Optional ByVal strUserID As String = "", _
                               Optional ByVal strUserPW As String = "")

        Dim xlApp As New Excel.Application
        Dim xlBooks As Excel.Workbooks = Nothing
        Dim xlBook As Excel.Workbook = Nothing

        Try

            'Excelオブジェクトの設定
            xlApp.Visible = False
            xlApp.EnableEvents = False
            xlBooks = xlApp.Workbooks
            xlApp.AskToUpdateLinks = False      ''自動更新リンクの警告メッセージを無効化する。
            xlBook = xlBooks.Open(macroInfo.strFilePath)
            xlApp.EnableEvents = True

            'マクロの実行
            xlApp.DisplayAlerts = False
            Select Case macroInfo.outFile
                Case OUTPUT_TYOUHYOUNAME_PAYMENTCOC
                    Result = DirectCast(xlApp.Run("'" + xlBook.Name + "'!" + strMacro, _
                                                  macroInfo.createTime, _
                                                  Path.GetFileName(Me.txb_InputFile.Text), _
                                                  macroInfo.outRowInFile,
                                                  chkcre1, _
                                                  chkcre2, _
                                                  chkcre3, _
                                                  CommonVariable.PaymentPW), String)

                Case OUTPUT_TYOUHYOUNAME_SEUKYU

                    Result = DirectCast(xlApp.Run("'" + xlBook.Name + "'!" + strMacro, _
                                                  macroInfo.createTime, _
                                                  Path.GetFileName(Me.txb_InputFile.Text), _
                                                  macroInfo.outRowInFile,
                                                  chkcre1, _
                                                  chkcre2, _
                                                  chkcre3, _
                                                  strUserID, _
                                                  strUserPW, _
                                                  CommonVariable.PaymentPW), String)

                Case OUTPUT_TYOUHYOUNAME_KAKAKUSYOUNINN
                    Result = DirectCast(xlApp.Run("'" + xlBook.Name + "'!" + strMacro, _
                                                  macroInfo.createTime, _
                                                  Path.GetFileName(Me.txb_InputFile.Text), _
                                                  ChkValOut.Checked, _
                                                  chkcre1, _
                                                  chkcre2, _
                                                  chkcre3, _
                                                  blnLock, _
                                                  strUserID, _
                                                  strUserPW, _
                                                  CommonVariable.PaymentPW, _
                                                  CommonVariable.SummaryPW), String)

                Case Else
                    Result = DirectCast(xlApp.Run("'" + xlBook.Name + "'!" + strMacro, _
                                                  macroInfo.createTime, _
                                                  Path.GetFileName(Me.txb_InputFile.Text), _
                                                  ChkValOut.Checked, _
                                                  chkcre1, _
                                                  chkcre2, _
                                                  chkcre3, _
                                                  CommonVariable.PaymentPW), String)
            End Select

        Catch ex As Exception
        Finally
            '後処理
            If IsNothing(xlBook) = False Then
                xlBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlBooks, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.DisplayAlerts = True
            xlApp.AskToUpdateLinks = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Sub

    ''' <summary>
    ''' 概　要：価格承認サマリーシートのコスト列を削除
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub DelCostRowPriceSummarySheet(ByRef sheet As Excel.Worksheet, ByVal blnSheetLock As Boolean)

        Dim Eof As Integer
        Dim xlRange As Excel.Range
        Dim xlBorder As Excel.Border

        Try
            ''PW保管場所変更
            If blnSheetLock = True Then
                sheet.Unprotect(CommonVariable.SummaryPW)
            End If
            xlRange = sheet.Columns("O:T")
            xlRange.Delete(Shift:=Excel.XlDeleteShiftDirection.xlShiftToLeft)

            ''Revenue集計行の縦罫線を引く
            Dim BuNullCount As Integer = 0
            Dim i As Integer = EXCEL_PAYMENTLINEDATE_OUTROW
            Do
                ''レスポンス修正
                ''※全行読込みだとレスポンスが極端に悪化するので、BU列が10行連続でNullの場合、EOFと判定する。
                xlRange = sheet.Range("D" & i)
                If xlRange.Value <> "" Then

                    BuNullCount = 0

                    ''BU列の左縦罫線の有無で、集計行を判定
                    xlBorder = xlRange.Borders(Excel.XlBordersIndex.xlEdgeLeft)
                    If xlBorder.LineStyle = Excel.XlLineStyle.xlContinuous And
                       xlBorder.Weight = Excel.XlBorderWeight.xlMedium Then

                        xlRange = sheet.Range("N" & i)
                        xlBorder = xlRange.Borders(Excel.XlBordersIndex.xlEdgeRight)
                        xlBorder.LineStyle = Excel.XlLineStyle.xlContinuous
                        xlBorder.ColorIndex = Excel.Constants.xlAutomatic
                        xlBorder.Weight = Excel.XlBorderWeight.xlMedium

                    End If
                Else
                    BuNullCount = BuNullCount + 1
                End If

                If BuNullCount >= 10 Then
                    Exit Do
                End If
                i = i + 1
            Loop
            ''PW保管場所変更
            If blnSheetLock = True Then
                Call ProtectSheet(sheet, CommonVariable.SummaryPW)
            End If
        Catch ex As Exception
            Throw ex

        Finally
            ''オブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlBorder, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' 機能：管理台帳出力用テーブル作成
    ''' 説明：
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Sub CreateTmpKeepMDB(ByVal PSxlsPath As String)

        Try

            ''管理台帳出力用テーブル作成
            Dim CopymdbPath As String
            Dim PastemdbPath As String
            Dim ofm As New OioFileManage
            Dim Cpno As String
            Cpno = ofm.GetCpnoForPaymentXls(PSxlsPath)
            CopymdbPath = ofm.GetDataKeepMDBPath(Cpno)
            PastemdbPath = ofm.GetDataKeepTmpMDBPath(Cpno)
            Call File.Copy(CopymdbPath, PastemdbPath, True)

        Catch ex As Exception
            Throw ex

        End Try

    End Sub

    ''' <summary>
    ''' 機　能：Oio-Sheet１シートに出力できるMAX件数を取得
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetMaxSheetLine() As Integer

        ''初期化
        GetMaxSheetLine = 0

        Try
            ''Xmlから、規定値を取得
            Dim ofm As New OioFileManage
            Dim OioSettingInfo() As SettingList
            OioSettingInfo = ofm.GetOioSettingInfo()
            OioSettingInfo = ofm.GetfrmOioSettingInfo("Frm_DataOutput", OioSettingInfo)
            For Each item As SettingList In OioSettingInfo
                If item.ParamNM = "OutputMaxSheetLine" Then
                    Return CLng(item.ParamValue)
                End If
            Next

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)

        End Try

    End Function

    ''' <summary>
    ''' 機　能：契約締結済みMDBからMAX件数を取得する。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetMaxMdbCount(ByVal Cpno As String) As Integer

        ''初期化
        GetMaxMdbCount = 0

        Try
            Dim con As OleDbConnection
            Dim mmc As New MasterMdbControl
            con = mmc.GetOleTmpDBConnection(Cpno, CommonVariable.MdbPW)

            Dim dr As OleDbDataReader
            Dim cmd As New OleDbCommand()
            Dim sqlCountRec As New StringBuilder
            sqlCountRec.Append(CommonConstant.SQL_STR_SELECT)
            sqlCountRec.Append(CommonConstant.SQL_STR_COUNT)
            sqlCountRec.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            sqlCountRec.Append("ID")
            sqlCountRec.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
            sqlCountRec.Append(CommonConstant.SQL_STR_FROM)
            sqlCountRec.Append("PaymentTBL1")
            cmd.Connection = con
            cmd.CommandText = sqlCountRec.ToString

            Dim MaxCount As Integer
            dr = cmd.ExecuteReader()
            If dr.Read() = True Then
                MaxCount = dr.Item(0)
            End If
            dr.Close()
            con.Close()

            Return MaxCount

        Catch ex As Exception
            Throw ex

        End Try

    End Function

    ''' <summary>
    ''' 概　要：マクロに渡す引数をセットする。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function SetMacroParam(ByVal createTime As String,
                                   ByVal strFilePath As String,
                                   ByVal outFile As String) As MacroArgu

        ''初期化
        SetMacroParam.createTime = ""
        SetMacroParam.strFilePath = ""

        ''値のセット
        Dim rtnValue As MacroArgu
        rtnValue.createTime = createTime
        rtnValue.strFilePath = strFilePath
        If IsNumeric(Me.txb_ChangePage.Text) = True Then
            rtnValue.outRowInFile = CInt(Me.txb_ChangePage.Text)
        Else
            rtnValue.outRowInFile = 0
        End If
        rtnValue.outFile = outFile

        Return rtnValue

    End Function

    ''' <summary>
    ''' 概　要：作成中のデータをArrayListに追加する。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetPaymentData(ByVal PSPath As String,
                               ByRef categoryList As SummaryTBLData,
                               ByRef oioList As ArrayList,
                               ByRef excelStrYear As String)

        Const Row_Category As Integer = 1
        Const row_Lockflg As Integer = 2
        Const Row_LineNo As Integer = 4
        Const CategoryArea As String = "B@:E@"
        Const PaymentArea As String = "A@:MS@"
        Const Area_ExcelStrYear As String = "H7"
        Const Area_SummarySort As String = "B@"

        Dim rtnCatArray As New SummaryTBLData
        Dim rtnOioArray As New ArrayList

        Dim xlApp As New Excel.Application
        Dim xlBook As Excel.Workbook
        Dim xlWS1Sheet As Excel.Worksheet
        Dim xlSummarySheet As Excel.Worksheet
        Dim xlListSheet As Excel.Worksheet
        Dim xlOioSheet As Excel.Worksheet
        Dim xlCell As Excel.Range
        Dim xlBooks As Excel.Workbooks = Nothing

        Try
            xlApp.EnableEvents = False
            xlApp.DisplayAlerts = False
            xlBooks = xlApp.Workbooks
            xlBook = xlBooks.Open(PSPath)
            xlWS1Sheet = xlBook.Worksheets(SHEET_NAME_WS1)
            xlSummarySheet = xlBook.Worksheets(SHEET_NAME_SUMMARY)
            xlOioSheet = xlBook.Worksheets(SHEET_NAME_PAYMENT)

            ''価格承認ｻﾏﾘｰｷｰ取得
            Dim i As Integer
            Dim intSpaceCnt As Integer = 0
            i = EXCEL_SUMMARY_ROW
            Do
                If intSpaceCnt > 1 Then
                    Exit Do
                End If

                xlCell = xlSummarySheet.Range(CategoryArea.Replace("@", i))
                Dim obj(1, 4) As Object
                obj = xlCell.Value
                ExcelObjRelease.ReleaseExcelObj(xlCell, True)

                If ExcelWrite.changeDBNullToString(obj(1, 1)) = "" Then
                    intSpaceCnt = intSpaceCnt + 1
                Else
                    Dim insRow As DataRow
                    insRow = rtnCatArray.NewRow
                    insRow.Item(ColumnNM_KeyNo) = ""
                    insRow.Item(ColumnNM_Bu) = ExcelWrite.changeDBNullToString(obj(1, 2))
                    insRow.Item(ColumnNM_Brand) = ExcelWrite.changeDBNullToString(obj(1, 3))
                    insRow.Item(ColumnNM_SummaryCategory) = ExcelWrite.changeDBNullToString(obj(1, 4))
                    insRow.Item(ColumnNM_SortKey) = ExcelWrite.GetBrandSortKey(obj)
                    rtnCatArray.Rows.Add(insRow)
                    intSpaceCnt = 0
                End If
                i = i + 1
            Loop

            ''OIOシート情報取得
            Dim j As Integer = EXCEL_PAYMENTLINEDATE_OUTROW
            Do
                xlCell = xlOioSheet.Cells(j, Row_LineNo)
                If ExcelWrite.changeDBNullToString(xlCell.Value) = "" Then
                    Exit Do
                End If
                ExcelObjRelease.ReleaseExcelObj(xlCell, True)

                '締結済みデータは対象外
                xlCell = xlOioSheet.Cells(j, row_Lockflg)
                If ExcelWrite.changeDBNullToString(xlCell.Value) <> "C" Then
                    ExcelObjRelease.ReleaseExcelObj(xlCell, True)
                    xlCell = xlOioSheet.Range(PaymentArea.Replace("@", j))
                    rtnOioArray.Add(xlCell.Value)
                End If
                ExcelObjRelease.ReleaseExcelObj(xlCell, True)
                j = j + 1
            Loop

            ''WS1シートから契約開始年月取得
            xlCell = xlWS1Sheet.Range(Area_ExcelStrYear)
            excelStrYear = ExcelWrite.changeDBNullToString(xlCell.Value)

            categoryList = rtnCatArray
            oioList = rtnOioArray

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, True)
            ExcelObjRelease.ReleaseExcelObj(xlWS1Sheet, True)
            ExcelObjRelease.ReleaseExcelObj(xlOioSheet, True)
            ExcelObjRelease.ReleaseExcelObj(xlListSheet, True)
            If IsNothing(xlBook) = False Then
                xlBook.Close()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, True)
            ExcelObjRelease.ReleaseExcelObj(xlBooks, True)
            xlApp.Quit()
            ExcelObjRelease.ReleaseExcelObj(xlApp, True)

            GC.Collect()
        End Try

    End Sub

    '--------------------------------------------------------
    '概    要  ：作成中のデータをMDBへ保管する。
    '説    明  ：
    '--------------------------------------------------------
    Private Sub CreateDataKeepMDB(ByVal cpNo As String, _
                                  ByRef categoryList As SummaryTBLData, _
                                  ByRef oioList As ArrayList, _
                                  ByVal excelStrYear As String)

        Dim con As New ADODB.Connection()
        Dim rsIn1 As New ADODB.Recordset
        Dim rsIn2 As New ADODB.Recordset
        Dim rsIn3 As New ADODB.Recordset
        Dim rsIn4 As New ADODB.Recordset
        Dim rsSel As New ADODB.Recordset
        Try
            ''テンプレートMDBのｺﾋﾟｰ
            Dim ofm As New OioFileManage
            Dim copyMDBPath As String
            Dim outMDBPath As String
            copyMDBPath = ofm.GetDataKeepMDBPath(cpNo)
            ''契約締結済MDBがない場合、テンプレMDBを使用する。
            If File.Exists(copyMDBPath) = False Then
                copyMDBPath = ofm.GetLocalDataKeepMDBFolder & CommonConstant.FILENAME_MDB_TEMPMDB
            End If
            outMDBPath = ofm.GetDataWorkMDBPath(cpNo)
            System.IO.File.Copy(copyMDBPath, outMDBPath, True)

            ''接続の作成		
            Dim mmc As New MasterMdbControl
            con = mmc.GetAdoWorkTmpDBConnection(CommonVariable.CPNO, CommonVariable.MdbPW)

            ''===========================================
            ''CurPaymentTBL1の更新
            ''===========================================
            Dim Sql As New StringBuilder
            Dim i As Integer

            ''レコードセット作成
            Sql.Length = 0
            Sql.Append(CommonConstant.SQL_STR_SELECT)
            Sql.Append(CommonConstant.SQL_STR_ASTERISK)
            Sql.Append(CommonConstant.SQL_STR_FROM)
            Sql.Append("CurPaymentTBL1")
            Call rsIn1.Open(Sql.ToString, con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)

            i = 0
            For Each tmpObj1 As Object In oioList

                i += 1
                rsIn1.AddNew()

                ''レコードのセット
                Call SetTBL1Record(i, rsIn1, tmpObj1)

                rsIn1.Update()
            Next
            Call rsIn1.Close()

            ''===========================================
            ''CurPaymentTBL2の更新
            ''===========================================
            ''レコードセット作成
            Sql.Length = 0
            Sql.Append(CommonConstant.SQL_STR_SELECT)
            Sql.Append(CommonConstant.SQL_STR_ASTERISK)
            Sql.Append(CommonConstant.SQL_STR_FROM)
            Sql.Append("CurPaymentTBL2")
            Call rsIn2.Open(Sql.ToString, con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)

            i = 0
            For Each tmpObj3(,) As Object In oioList

                i += 1
                rsIn2.AddNew()

                ''レコードのセット
                Call SetTBL2Record(i, rsIn2, tmpObj3)

                rsIn2.Update()
            Next
            Call rsIn2.Close()

            ''===========================================
            ''CurPaymentTBL3の更新
            ''===========================================
            ''レコードセット作成
            Sql.Length = 0
            Sql.Append(CommonConstant.SQL_STR_SELECT)
            Sql.Append(CommonConstant.SQL_STR_ASTERISK)
            Sql.Append(CommonConstant.SQL_STR_FROM)
            Sql.Append("CurPaymentTBL3")
            Call rsIn3.Open(Sql.ToString, con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)

            i = 0
            For Each tmpObj2(,) As Object In oioList

                i += 1

                ''レコードのセット + 更新
                Call SetTBL3Record(i, rsIn3, tmpObj2, excelStrYear)

            Next
            Call rsIn3.Close()

            ''===========================================
            ''SummaryCategory
            ''===========================================
            ''契約締結済MDBとPayment.xlsの契約締結済情報をマージしてSortする。
            Const TBL1ColumnNM_BU As String = "BU"
            Const TBL1ColumnNM_BRAND As String = "BRAND"
            Const TBL1ColumnNM_SUM_CATEGORY As String = "SUM_CATEGORY"

            Sql.Length = 0
            Sql.Append(CommonConstant.SQL_STR_SELECT)
            Sql.Append(TBL1ColumnNM_BU)
            Sql.Append(CommonConstant.STR_COMMA)
            Sql.Append(TBL1ColumnNM_BRAND)
            Sql.Append(CommonConstant.STR_COMMA)
            Sql.Append(TBL1ColumnNM_SUM_CATEGORY)
            Sql.Append(CommonConstant.SQL_STR_FROM)
            Sql.Append("PaymentTBL1")
            Sql.Append(CommonConstant.SQL_STR_GROUP_BY)
            Sql.Append(TBL1ColumnNM_BU)
            Sql.Append(CommonConstant.STR_COMMA)
            Sql.Append(TBL1ColumnNM_BRAND)
            Sql.Append(CommonConstant.STR_COMMA)
            Sql.Append(TBL1ColumnNM_SUM_CATEGORY)

            ''締結済データのマージ
            Dim insRow As DataRow
            Dim obj(1, 4) As Object
            Call rsSel.Open(Sql.ToString, con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)
            While rsSel.EOF = False

                insRow = categoryList.NewRow
                insRow.Item(ColumnNM_Bu) = ExcelWrite.changeDBNullToString(rsSel.Fields(TBL1ColumnNM_BU).Value)
                insRow.Item(ColumnNM_Brand) = ExcelWrite.changeDBNullToString(rsSel.Fields(TBL1ColumnNM_BRAND).Value)
                insRow.Item(ColumnNM_SummaryCategory) = ExcelWrite.changeDBNullToString(rsSel.Fields(TBL1ColumnNM_SUM_CATEGORY).Value)
                ''SortKey情報
                obj(1, 2) = ExcelWrite.changeDBNullToString(rsSel.Fields(TBL1ColumnNM_BU).Value)
                obj(1, 3) = ExcelWrite.changeDBNullToString(rsSel.Fields(TBL1ColumnNM_BRAND).Value)
                insRow.Item(ColumnNM_SortKey) = ExcelWrite.GetBrandSortKey(obj)

                categoryList.Rows.Add(insRow)

                rsSel.MoveNext()

            End While
            Call rsSel.Close()

            ''Sort/重複の削除
            Dim sortKey As New StringBuilder
            Dim tmpView As New DataView(categoryList)
            Dim outTable As DataTable
            sortKey.Append(ColumnNM_SortKey)
            sortKey.Append(CommonConstant.STR_COMMA)
            sortKey.Append(ColumnNM_Brand)
            sortKey.Append(CommonConstant.STR_COMMA)
            sortKey.Append(ColumnNM_SummaryCategory)
            sortKey.Append(" ASC ")
            tmpView.Sort = sortKey.ToString
            outTable = tmpView.ToTable("SummaryTBLData", True, New String() {"Bu", "Brand", "SummaryCategory", "SortKey"})

            ''レコードセット作成
            Sql.Length = 0
            Sql.Append(CommonConstant.SQL_STR_SELECT)
            Sql.Append(CommonConstant.SQL_STR_ASTERISK)
            Sql.Append(CommonConstant.SQL_STR_FROM)
            Sql.Append("FrmDataOutPut_IOCCOC_Category")
            Call rsIn4.Open(Sql.ToString, con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)

            i = 0
            For Each row As DataRow In outTable.Rows
                i += 1
                ''レコードのセット + 更新
                rsIn4.AddNew()
                Call SetTBL4Record(i, rsIn4, row)
                rsIn4.Update()
            Next
            Call rsIn4.Close()

        Catch ex As Exception
            Throw ex

        Finally
            ''レコードのクローズ
            If rsIn1.State <> ADODB.ObjectStateEnum.adStateClosed Then
                rsIn1.Close()
            End If
            If rsIn2.State <> ADODB.ObjectStateEnum.adStateClosed Then
                rsIn2.Close()
            End If
            If rsIn3.State <> ADODB.ObjectStateEnum.adStateClosed Then
                rsIn3.Close()
            End If
            If rsIn4.State <> ADODB.ObjectStateEnum.adStateClosed Then
                rsIn4.Close()
            End If
            If rsSel.State <> ADODB.ObjectStateEnum.adStateClosed Then
                rsSel.Close()
            End If

            ''Connectionのクローズ
            If con.State <> ADODB.ObjectStateEnum.adStateClosed Then
                con.Close()
            End If
        End Try

    End Sub

    ''' <summary>
    ''' 機　能：PaymentTBL1のレコードセットに値をセットする。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetTBL1Record(ByVal i As Integer,
                              ByRef rsIn As ADODB.Recordset,
                              ByRef obj(,) As Object)

        rsIn.Fields("ID").Value = i.ToString.PadLeft(5, "0")
        rsIn.Fields("UPDATE_FLAG").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG))                                       ''更新FLG
        rsIn.Fields("LOCK_FLAG").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG))                                           ''ﾛｯｸFLG
        rsIn.Fields("VALID_FLAG").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG))                                         ''有効/無効
        rsIn.Fields("LINE_NO").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.LINE_NO))                                               ''NO
        rsIn.Fields("FILE_NAME").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.FILE_NAME))                                           ''ﾌｧｲﾙ名
        rsIn.Fields("FILE_NAME_SUFFIX").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX))                             ''ﾌｧｲﾙ名Suffix
        rsIn.Fields("FILE_NAME_SUFFIX_INTR").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR))                   ''ﾌｧｲﾙ内Suffix
        rsIn.Fields("CONTRACT").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.CONTRACT))                                             ''契約順番
        rsIn.Fields("ST_COST").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.ST_COST))                                               ''COST_開示依頼
        rsIn.Fields("ST_APPROVAL").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.ST_APPROVAL))                                       ''価格承認_申請依頼
        rsIn.Fields("PROJ_ID").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PROJ_ID))                                               ''案件番号
        rsIn.Fields("CONTRACT_SEQ").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.CONTRACT_SEQ))                                     ''契約通番
        rsIn.Fields("NEW_EXIST").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.NEW_EXIST))                                           ''新規/既存
        rsIn.Fields("CUST_CATEGORY").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.CUST_CATEGORY))                                   ''お客様集計ｶﾃｺﾞﾘ
        rsIn.Fields("LETTER_PLAN_DATE").Value = ChgFormatYYYYMMDD(obj(1, ExcelWrite.ExcelPaymentLineColumn.LETTER_PLAN_DATE))                                           ''実行通知書_発行予定日
        rsIn.Fields("LETTER_ACCEPT_DATE").Value = ChgFormatYYYYMMDD(obj(1, ExcelWrite.ExcelPaymentLineColumn.LETTER_ACCEPT_DATE))                                       ''実行通知書_受領日
        rsIn.Fields("ORDER_DATE").Value = ChgFormatYYYYMMDD(obj(1, ExcelWrite.ExcelPaymentLineColumn.ORDER_DATE))                                                       ''発注完了日
        rsIn.Fields("LETTER_ID").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.LETTER_ID))                                           ''実行通知書番号
        rsIn.Fields("BILLING_CD").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.ORDERCODE))                                          ''請求コード
        rsIn.Fields("BU").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.BU))                                                         ''Brand Category_BU
        rsIn.Fields("BRAND").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.BRAND))                                                   ''Brand Category_Brand
        rsIn.Fields("SUM_CATEGORY").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.SUM_CATEGORY))                                     ''Brand Category_ｻﾏﾘｰ用ｶﾃｺﾞﾘ
        rsIn.Fields("BRAND_SUB").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.BRAND_SUB))                                           ''Brand Category_SubBrand
        rsIn.Fields("T_OP1").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.OP1))                                                     ''Brand Category_Option1
        rsIn.Fields("T_OP2").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.OP2))                                                     ''Brand Category_Option2
        rsIn.Fields("T_SIZE").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.BRAND_SIZE))                                             ''Brand Category_Size
        rsIn.Fields("NON_SBO").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.NON_SBO))                                               ''Brand Category_SBO制限
        rsIn.Fields("ADDITION_ITEM").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.POSTSCRIPT))                                      ''Brand Category_追記事項
        rsIn.Fields("TOPACS_CPNO").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.TOPACS_CPNO))                                       ''Brand承認_TOPACS CPNO
        rsIn.Fields("BRAND_AP_FORM").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_FORM))                                   ''Brand承認_起票番号
        rsIn.Fields("BRAND_AP_REQ").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_REQ))                                     ''Brand承認_申請番号
        rsIn.Fields("BRAND_AP_CONF").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_CONF))                                   ''Brand承認_承認番号
        rsIn.Fields("PATTERN_CD").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD))                                         ''入力項目ﾊﾟﾀｰﾝ SEQ
        rsIn.Fields("PATTERN").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PATTERN))                                               ''入力項目ﾊﾟﾀｰﾝ
        rsIn.Fields("PROD_ITEM01").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01))                                       ''ﾊﾟﾀｰﾝ別入力項目_項目１
        rsIn.Fields("PROD_ITEM02").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02))                                       ''ﾊﾟﾀｰﾝ別入力項目_項目２
        rsIn.Fields("PROD_ITEM03").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03))                                       ''ﾊﾟﾀｰﾝ別入力項目_項目３
        rsIn.Fields("PROD_ITEM04").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM04))                                       ''ﾊﾟﾀｰﾝ別入力項目_項目４
        rsIn.Fields("PROD_ITEM05").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM05))                                       ''ﾊﾟﾀｰﾝ別入力項目_項目５
        rsIn.Fields("PROD_ITEM06").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM06))                                       ''ﾊﾟﾀｰﾝ別入力項目_項目６
        rsIn.Fields("PROD_ITEM07").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM07))                                       ''ﾊﾟﾀｰﾝ別入力項目_項目７
        rsIn.Fields("PROD_ITEM08").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM08))                                       ''ﾊﾟﾀｰﾝ別入力項目_項目８
        rsIn.Fields("PROD_ITEM09").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM09))                                       ''ﾊﾟﾀｰﾝ別入力項目_項目９
        rsIn.Fields("PROD_ITEM10").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10))                                       ''ﾊﾟﾀｰﾝ別入力項目_項目１０
        rsIn.Fields("PROD_ITEM11").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11))                                       ''ﾊﾟﾀｰﾝ別入力項目_項目１１
        rsIn.Fields("PROD_ITEM12").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12))                                       ''ﾊﾟﾀｰﾝ別入力項目_項目１２
        rsIn.Fields("PROD_ITEM13").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM13))                                       ''ﾊﾟﾀｰﾝ別入力項目_項目１３
        rsIn.Fields("PROD_ITEM14").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM14))                                       ''ﾊﾟﾀｰﾝ別入力項目_項目１４
        rsIn.Fields("PROD_ITEM15").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM15))                                       ''ﾊﾟﾀｰﾝ別入力項目_項目１５
        rsIn.Fields("PROD_ITEM16").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM16))                                       ''ﾊﾟﾀｰﾝ別入力項目_項目１６
        rsIn.Fields("PROD_ITEM17").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM17))                                       ''ﾊﾟﾀｰﾝ別入力項目_項目１７
        rsIn.Fields("PROD_ITEM18").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM18))                                       ''ﾊﾟﾀｰﾝ別入力項目_項目１８
        rsIn.Fields("PROD_ITEM19").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM19))                                       ''ﾊﾟﾀｰﾝ別入力項目_項目１９
        rsIn.Fields("PROD_ITEM20").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM20))                                       ''ﾊﾟﾀｰﾝ別入力項目_項目２０
        rsIn.Fields("PROD_ITEM22").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM22))                                       ''ﾊﾟﾀｰﾝ別入力項目_項目２２
        rsIn.Fields("PROD_ITEM23").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM23))                                       ''ﾊﾟﾀｰﾝ別入力項目_項目２３
        rsIn.Fields("PROD_ITEM24").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM24))                                       ''ﾊﾟﾀｰﾝ別入力項目_項目２４

    End Sub


    ''' <summary>
    ''' 機　能：PaymentTBL2のレコードセットに値をセットする。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetTBL2Record(ByVal i As Integer,
                              ByRef rsIn As ADODB.Recordset,
                              ByRef obj(,) As Object)

        rsIn.Fields("ID").Value = i.ToString.PadLeft(5, "0")                                                                                                           ''ID
        rsIn.Fields("WD_ANNT_DATE").Value = ChgFormatYYYYMMDD(obj(1, ExcelWrite.ExcelPaymentLineColumn.WD_ANNT_DATE))                                                   ''製品･ｻｰﾋﾞｽ廃止発表日
        rsIn.Fields("WD_DATE").Value = ChgFormatYYYYMMDD(obj(1, ExcelWrite.ExcelPaymentLineColumn.WD_DATE))                                                             ''製品･ｻｰﾋﾞｽ廃止予定
        rsIn.Fields("PRICE_CHG_DATE").Value = ChgFormatYYYYMMDD(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_CHG_DATE))                                               ''価格改定予定日	
        rsIn.Fields("QTY").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.QTY))                                                       ''数量
        rsIn.Fields("INST_DATE").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.INST_DATE))                                           ''導入_年月
        rsIn.Fields("PAY_START_DATE").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE))                                 ''請求開始_年月	
        rsIn.Fields("PAY_END_DATE").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE))                                     ''請求終了_年月
        rsIn.Fields("IGF_START_DATE").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.IGF_START_DATE))                                 ''IGF計算開始_年月	
        rsIn.Fields("IGF_END_DATE").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.IGF_END_DATE))                                     ''IGF計算開始_年月
        rsIn.Fields("PAY_FLAG").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PAY_FLAG))                                             ''Payment_展開
        rsIn.Fields("BID_FLAG").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.BID_FLAG))                                             ''定額_BID
        rsIn.Fields("PAY_MONTHS").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PAY_MONTHS))                                         ''請求期間
        rsIn.Fields("VALID_CTRL").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PAY_VALIDATION))                                     ''Validation
        rsIn.Fields("PAY_METHOD").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD))                                         ''支払方法
        rsIn.Fields("IGF_APPLIED").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.IGF_APPLIED))                                       ''IGF_対象
        rsIn.Fields("IGF_CONT_NO").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_NO))                                       ''IGF契約番号
        rsIn.Fields("IGF_CONT_TYPE").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_FORM))                                   ''IGF契約形態	
        rsIn.Fields("IGF_PROPERTY").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_MANAGMENT))                               ''IGF契約物件管理		
        rsIn.Fields("IGF_RATE_IOC").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.IGF_RATE_IOC))                                     ''IGF_IOC料率
        rsIn.Fields("LIST_PRICE_PROPOSAL").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL))                       ''Listprice(単価)_提案時				
        rsIn.Fields("LIST_PRICE").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH))                                 ''Listprice(単価)_ﾘﾌﾚｯｼｭ後	
        rsIn.Fields("LIST_PRICE_TOTAL_PROPOSAL").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_PROPOSAL))           ''Listprice(合計)_提案時								
        rsIn.Fields("LIST_PRICE_TOTAL").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH))                     ''Listprice(合計)_ﾘﾌﾚｯｼｭ後					
        rsIn.Fields("DP_IOC").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.DP_IOC))                                                 ''IOC D%
        rsIn.Fields("PRICE_UNIT_IOC").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC))                                 ''IOC単価	
        rsIn.Fields("PRICE_UNIT_IOC_VAL").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC_VAL))                         ''Offering Price 単価Validation後
        rsIn.Fields("PRICE_QTY_IOC").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC))                                   ''IOC合計	
        rsIn.Fields("COST_RATE").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.COST_RATE))                                           ''COST %
        rsIn.Fields("COST").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.COST))                                                     ''COST_単価
        rsIn.Fields("COST_TOTAL").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.COST_TOTAL))                                         ''COST_合計
        rsIn.Fields("COST_INPUT_DATE").Value = ChgFormatYYYYMMDD(obj(1, ExcelWrite.ExcelPaymentLineColumn.COST_INPUT_DATE))                                             ''COST_入力日		
        rsIn.Fields("PRICE_TO_SPLIT").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_TO_SPLIT))                                 ''展開金額	
        rsIn.Fields("LIST_PRICE_TOTAL_IOC").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_IOC))                     ''Listprice_期間合計				
        rsIn.Fields("PRICE_TOTAL_IOC").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_TOTAL_IOC))                               ''D%適用後_期間合計		
        rsIn.Fields("COST_TOTAL_IOC").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.COST_TOTAL_IOC))                                 ''COST_期間合計	
        rsIn.Fields("PRICE_IGF_TOTAL").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_TOTAL_IGF))                               ''IGF適用後 期間合計		
        rsIn.Fields("PRICE_CONT_TOTAL").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.CONTRACT_IN))                                  ''契約期間内	
        rsIn.Fields("PRICE_OO_CONT_TOTAL").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.CONTRACT_OUT))                              ''契約期間外		
        rsIn.Fields("IGF_DIF_INTEREST").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_DEFF_IGF))                               ''IGF金利(差額)		
        rsIn.Fields("PAST_PRICE_TOTAL").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL))                             ''過去の契約金額合計

    End Sub

    ''' <summary>
    ''' 機　能：PaymentTBL3のレコードセットに値をセットする。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetTBL3Record(ByVal i As Integer,
                              ByRef rsIn As ADODB.Recordset,
                              ByRef obj(,) As Object,
                              ByVal excelStrYear As String)

        Dim iocYear As Integer = -1

        ''1年目
        rsIn.AddNew()
        iocYear += 1
        rsIn.Fields("ID").Value = i.ToString.PadLeft(5, "0")
        rsIn.Fields("IOC_YEAER").Value = iocYear + CInt(excelStrYear)
        rsIn.Fields("IOC_YYYY").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1))
        rsIn.Fields("IOC_01").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1))
        rsIn.Fields("IOC_02").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH2))
        rsIn.Fields("IOC_03").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH3))
        rsIn.Fields("IOC_04").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH4))
        rsIn.Fields("IOC_05").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH5))
        rsIn.Fields("IOC_06").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH6))
        rsIn.Fields("IOC_07").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH7))
        rsIn.Fields("IOC_08").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH8))
        rsIn.Fields("IOC_09").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH9))
        rsIn.Fields("IOC_10").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH10))
        rsIn.Fields("IOC_11").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH11))
        rsIn.Fields("IOC_12").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH12))
        rsIn.Update()

        ''2年目
        rsIn.AddNew()
        iocYear += 1
        rsIn.Fields("ID").Value = i.ToString.PadLeft(5, "0")
        rsIn.Fields("IOC_YEAER").Value = iocYear + CInt(excelStrYear)
        rsIn.Fields("IOC_YYYY").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2))
        rsIn.Fields("IOC_01").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH1))
        rsIn.Fields("IOC_02").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH2))
        rsIn.Fields("IOC_03").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH3))
        rsIn.Fields("IOC_04").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH4))
        rsIn.Fields("IOC_05").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH5))
        rsIn.Fields("IOC_06").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH6))
        rsIn.Fields("IOC_07").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH7))
        rsIn.Fields("IOC_08").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH8))
        rsIn.Fields("IOC_09").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH9))
        rsIn.Fields("IOC_10").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH10))
        rsIn.Fields("IOC_11").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH11))
        rsIn.Fields("IOC_12").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH12))

        ''3年目
        rsIn.AddNew()
        iocYear += 1
        rsIn.Fields("ID").Value = i.ToString.PadLeft(5, "0")
        rsIn.Fields("IOC_YEAER").Value = iocYear + CInt(excelStrYear)
        rsIn.Fields("IOC_YYYY").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3))
        rsIn.Fields("IOC_01").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH1))
        rsIn.Fields("IOC_02").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH2))
        rsIn.Fields("IOC_03").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH3))
        rsIn.Fields("IOC_04").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH4))
        rsIn.Fields("IOC_05").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH5))
        rsIn.Fields("IOC_06").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH6))
        rsIn.Fields("IOC_07").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH7))
        rsIn.Fields("IOC_08").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH8))
        rsIn.Fields("IOC_09").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH9))
        rsIn.Fields("IOC_10").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH10))
        rsIn.Fields("IOC_11").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH11))
        rsIn.Fields("IOC_12").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH12))
        rsIn.Update()

        ''4年目
        rsIn.AddNew()
        iocYear += 1
        rsIn.Fields("ID").Value = i.ToString.PadLeft(5, "0")
        rsIn.Fields("IOC_YEAER").Value = iocYear + CInt(excelStrYear)
        rsIn.Fields("IOC_YYYY").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4))
        rsIn.Fields("IOC_01").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH1))
        rsIn.Fields("IOC_02").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH2))
        rsIn.Fields("IOC_03").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH3))
        rsIn.Fields("IOC_04").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH4))
        rsIn.Fields("IOC_05").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH5))
        rsIn.Fields("IOC_06").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH6))
        rsIn.Fields("IOC_07").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH7))
        rsIn.Fields("IOC_08").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH8))
        rsIn.Fields("IOC_09").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH9))
        rsIn.Fields("IOC_10").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH10))
        rsIn.Fields("IOC_11").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH11))
        rsIn.Fields("IOC_12").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH12))
        rsIn.Update()

        ''5年目
        rsIn.AddNew()
        iocYear += 1
        rsIn.Fields("ID").Value = i.ToString.PadLeft(5, "0")
        rsIn.Fields("IOC_YEAER").Value = iocYear + CInt(excelStrYear)
        rsIn.Fields("IOC_YYYY").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5))
        rsIn.Fields("IOC_01").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH1))
        rsIn.Fields("IOC_02").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH2))
        rsIn.Fields("IOC_03").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH3))
        rsIn.Fields("IOC_04").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH4))
        rsIn.Fields("IOC_05").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH5))
        rsIn.Fields("IOC_06").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH6))
        rsIn.Fields("IOC_07").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH7))
        rsIn.Fields("IOC_08").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH8))
        rsIn.Fields("IOC_09").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH9))
        rsIn.Fields("IOC_10").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH10))
        rsIn.Fields("IOC_11").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH11))
        rsIn.Fields("IOC_12").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH12))
        rsIn.Update()

        ''6年目
        rsIn.AddNew()
        iocYear += 1
        rsIn.Fields("ID").Value = i.ToString.PadLeft(5, "0")
        rsIn.Fields("IOC_YEAER").Value = iocYear + CInt(excelStrYear)
        rsIn.Fields("IOC_YYYY").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6))
        rsIn.Fields("IOC_01").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH1))
        rsIn.Fields("IOC_02").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH2))
        rsIn.Fields("IOC_03").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH3))
        rsIn.Fields("IOC_04").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH4))
        rsIn.Fields("IOC_05").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH5))
        rsIn.Fields("IOC_06").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH6))
        rsIn.Fields("IOC_07").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH7))
        rsIn.Fields("IOC_08").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH8))
        rsIn.Fields("IOC_09").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH9))
        rsIn.Fields("IOC_10").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH10))
        rsIn.Fields("IOC_11").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH11))
        rsIn.Fields("IOC_12").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH12))
        rsIn.Update()

        ''7年目
        rsIn.AddNew()
        iocYear += 1
        rsIn.Fields("ID").Value = i.ToString.PadLeft(5, "0")
        rsIn.Fields("IOC_YEAER").Value = iocYear + CInt(excelStrYear)
        rsIn.Fields("IOC_YYYY").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7))
        rsIn.Fields("IOC_01").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH1))
        rsIn.Fields("IOC_02").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH2))
        rsIn.Fields("IOC_03").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH3))
        rsIn.Fields("IOC_04").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH4))
        rsIn.Fields("IOC_05").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH5))
        rsIn.Fields("IOC_06").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH6))
        rsIn.Fields("IOC_07").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH7))
        rsIn.Fields("IOC_08").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH8))
        rsIn.Fields("IOC_09").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH9))
        rsIn.Fields("IOC_10").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH10))
        rsIn.Fields("IOC_11").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH11))
        rsIn.Fields("IOC_12").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH12))
        rsIn.Update()

        ''8年目
        rsIn.AddNew()
        iocYear += 1
        rsIn.Fields("ID").Value = i.ToString.PadLeft(5, "0")
        rsIn.Fields("IOC_YEAER").Value = iocYear + CInt(excelStrYear)
        rsIn.Fields("IOC_YYYY").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8))
        rsIn.Fields("IOC_01").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH1))
        rsIn.Fields("IOC_02").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH2))
        rsIn.Fields("IOC_03").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH3))
        rsIn.Fields("IOC_04").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH4))
        rsIn.Fields("IOC_05").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH5))
        rsIn.Fields("IOC_06").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH6))
        rsIn.Fields("IOC_07").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH7))
        rsIn.Fields("IOC_08").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH8))
        rsIn.Fields("IOC_09").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH9))
        rsIn.Fields("IOC_10").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH10))
        rsIn.Fields("IOC_11").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH11))
        rsIn.Fields("IOC_12").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH12))
        rsIn.Update()

        ''9年目
        rsIn.AddNew()
        iocYear += 1
        rsIn.Fields("ID").Value = i.ToString.PadLeft(5, "0")
        rsIn.Fields("IOC_YEAER").Value = iocYear + CInt(excelStrYear)
        rsIn.Fields("IOC_YYYY").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9))
        rsIn.Fields("IOC_01").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH1))
        rsIn.Fields("IOC_02").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH2))
        rsIn.Fields("IOC_03").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH3))
        rsIn.Fields("IOC_04").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH4))
        rsIn.Fields("IOC_05").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH5))
        rsIn.Fields("IOC_06").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH6))
        rsIn.Fields("IOC_07").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH7))
        rsIn.Fields("IOC_08").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH8))
        rsIn.Fields("IOC_09").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH9))
        rsIn.Fields("IOC_10").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH10))
        rsIn.Fields("IOC_11").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH11))
        rsIn.Fields("IOC_12").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH12))
        rsIn.Update()

        ''10年目
        rsIn.AddNew()
        iocYear += 1
        rsIn.Fields("ID").Value = i.ToString.PadLeft(5, "0")
        rsIn.Fields("IOC_YEAER").Value = iocYear + CInt(excelStrYear)
        rsIn.Fields("IOC_YYYY").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10))
        rsIn.Fields("IOC_01").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH1))
        rsIn.Fields("IOC_02").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH2))
        rsIn.Fields("IOC_03").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH3))
        rsIn.Fields("IOC_04").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH4))
        rsIn.Fields("IOC_05").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH5))
        rsIn.Fields("IOC_06").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH6))
        rsIn.Fields("IOC_07").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH7))
        rsIn.Fields("IOC_08").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH8))
        rsIn.Fields("IOC_09").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH9))
        rsIn.Fields("IOC_10").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH10))
        rsIn.Fields("IOC_11").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH11))
        rsIn.Fields("IOC_12").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH12))
        rsIn.Update()

        ''11年目
        rsIn.AddNew()
        iocYear += 1
        rsIn.Fields("ID").Value = i.ToString.PadLeft(5, "0")
        rsIn.Fields("IOC_YEAER").Value = iocYear + CInt(excelStrYear)
        rsIn.Fields("IOC_YYYY").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11))
        rsIn.Fields("IOC_01").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH1))
        rsIn.Fields("IOC_02").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH2))
        rsIn.Fields("IOC_03").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH3))
        rsIn.Fields("IOC_04").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH4))
        rsIn.Fields("IOC_05").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH5))
        rsIn.Fields("IOC_06").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH6))
        rsIn.Fields("IOC_07").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH7))
        rsIn.Fields("IOC_08").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH8))
        rsIn.Fields("IOC_09").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH9))
        rsIn.Fields("IOC_10").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH10))
        rsIn.Fields("IOC_11").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH11))
        rsIn.Fields("IOC_12").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH12))
        rsIn.Update()

        ''12年目
        rsIn.AddNew()
        iocYear += 1
        rsIn.Fields("ID").Value = i.ToString.PadLeft(5, "0")
        rsIn.Fields("IOC_YEAER").Value = iocYear + CInt(excelStrYear)
        rsIn.Fields("IOC_YYYY").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12))
        rsIn.Fields("IOC_01").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH1))
        rsIn.Fields("IOC_02").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH2))
        rsIn.Fields("IOC_03").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH3))
        rsIn.Fields("IOC_04").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH4))
        rsIn.Fields("IOC_05").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH5))
        rsIn.Fields("IOC_06").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH6))
        rsIn.Fields("IOC_07").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH7))
        rsIn.Fields("IOC_08").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH8))
        rsIn.Fields("IOC_09").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH9))
        rsIn.Fields("IOC_10").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH10))
        rsIn.Fields("IOC_11").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH11))
        rsIn.Fields("IOC_12").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH12))
        rsIn.Update()

        ''13年目
        rsIn.AddNew()
        iocYear += 1
        rsIn.Fields("ID").Value = i.ToString.PadLeft(5, "0")
        rsIn.Fields("IOC_YEAER").Value = iocYear + CInt(excelStrYear)
        rsIn.Fields("IOC_YYYY").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13))
        rsIn.Fields("IOC_01").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH1))
        rsIn.Fields("IOC_02").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH2))
        rsIn.Fields("IOC_03").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH3))
        rsIn.Fields("IOC_04").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH4))
        rsIn.Fields("IOC_05").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH5))
        rsIn.Fields("IOC_06").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH6))
        rsIn.Fields("IOC_07").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH7))
        rsIn.Fields("IOC_08").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH8))
        rsIn.Fields("IOC_09").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH9))
        rsIn.Fields("IOC_10").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH10))
        rsIn.Fields("IOC_11").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH11))
        rsIn.Fields("IOC_12").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH12))
        rsIn.Update()

        ''14年目
        rsIn.AddNew()
        iocYear += 1
        rsIn.Fields("ID").Value = i.ToString.PadLeft(5, "0")
        rsIn.Fields("IOC_YEAER").Value = iocYear + CInt(excelStrYear)
        rsIn.Fields("IOC_YYYY").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14))
        rsIn.Fields("IOC_01").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH1))
        rsIn.Fields("IOC_02").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH2))
        rsIn.Fields("IOC_03").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH3))
        rsIn.Fields("IOC_04").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH4))
        rsIn.Fields("IOC_05").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH5))
        rsIn.Fields("IOC_06").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH6))
        rsIn.Fields("IOC_07").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH7))
        rsIn.Fields("IOC_08").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH8))
        rsIn.Fields("IOC_09").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH9))
        rsIn.Fields("IOC_10").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH10))
        rsIn.Fields("IOC_11").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH11))
        rsIn.Fields("IOC_12").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH12))
        rsIn.Update()

        ''15年目
        rsIn.AddNew()
        iocYear += 1
        rsIn.Fields("ID").Value = i.ToString.PadLeft(5, "0")
        rsIn.Fields("IOC_YEAER").Value = iocYear + CInt(excelStrYear)
        rsIn.Fields("IOC_YYYY").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15))
        rsIn.Fields("IOC_01").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH1))
        rsIn.Fields("IOC_02").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH2))
        rsIn.Fields("IOC_03").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH3))
        rsIn.Fields("IOC_04").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH4))
        rsIn.Fields("IOC_05").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH5))
        rsIn.Fields("IOC_06").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH6))
        rsIn.Fields("IOC_07").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH7))
        rsIn.Fields("IOC_08").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH8))
        rsIn.Fields("IOC_09").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH9))
        rsIn.Fields("IOC_10").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH10))
        rsIn.Fields("IOC_11").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH11))
        rsIn.Fields("IOC_12").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH12))
        rsIn.Update()

        ''16年目
        rsIn.AddNew()
        iocYear += 1
        rsIn.Fields("ID").Value = i.ToString.PadLeft(5, "0")
        rsIn.Fields("IOC_YEAER").Value = iocYear + CInt(excelStrYear)
        rsIn.Fields("IOC_YYYY").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16))
        rsIn.Fields("IOC_01").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH1))
        rsIn.Fields("IOC_02").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH2))
        rsIn.Fields("IOC_03").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH3))
        rsIn.Fields("IOC_04").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH4))
        rsIn.Fields("IOC_05").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH5))
        rsIn.Fields("IOC_06").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH6))
        rsIn.Fields("IOC_07").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH7))
        rsIn.Fields("IOC_08").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH8))
        rsIn.Fields("IOC_09").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH9))
        rsIn.Fields("IOC_10").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH10))
        rsIn.Fields("IOC_11").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH11))
        rsIn.Fields("IOC_12").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH12))
        rsIn.Update()

        ''17年目
        rsIn.AddNew()
        iocYear += 1
        rsIn.Fields("ID").Value = i.ToString.PadLeft(5, "0")
        rsIn.Fields("IOC_YEAER").Value = iocYear + CInt(excelStrYear)
        rsIn.Fields("IOC_YYYY").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17))
        rsIn.Fields("IOC_01").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH1))
        rsIn.Fields("IOC_02").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH2))
        rsIn.Fields("IOC_03").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH3))
        rsIn.Fields("IOC_04").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH4))
        rsIn.Fields("IOC_05").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH5))
        rsIn.Fields("IOC_06").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH6))
        rsIn.Fields("IOC_07").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH7))
        rsIn.Fields("IOC_08").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH8))
        rsIn.Fields("IOC_09").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH9))
        rsIn.Fields("IOC_10").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH10))
        rsIn.Fields("IOC_11").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH11))
        rsIn.Fields("IOC_12").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH12))
        rsIn.Update()

        ''18年目
        rsIn.AddNew()
        iocYear += 1
        rsIn.Fields("ID").Value = i.ToString.PadLeft(5, "0")
        rsIn.Fields("IOC_YEAER").Value = iocYear + CInt(excelStrYear)
        rsIn.Fields("IOC_YYYY").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18))
        rsIn.Fields("IOC_01").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH1))
        rsIn.Fields("IOC_02").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH2))
        rsIn.Fields("IOC_03").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH3))
        rsIn.Fields("IOC_04").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH4))
        rsIn.Fields("IOC_05").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH5))
        rsIn.Fields("IOC_06").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH6))
        rsIn.Fields("IOC_07").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH7))
        rsIn.Fields("IOC_08").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH8))
        rsIn.Fields("IOC_09").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH9))
        rsIn.Fields("IOC_10").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH10))
        rsIn.Fields("IOC_11").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH11))
        rsIn.Fields("IOC_12").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH12))
        rsIn.Update()

        ''19年目
        rsIn.AddNew()
        iocYear += 1
        rsIn.Fields("ID").Value = i.ToString.PadLeft(5, "0")
        rsIn.Fields("IOC_YEAER").Value = iocYear + CInt(excelStrYear)
        rsIn.Fields("IOC_YYYY").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19))
        rsIn.Fields("IOC_01").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH1))
        rsIn.Fields("IOC_02").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH2))
        rsIn.Fields("IOC_03").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH3))
        rsIn.Fields("IOC_04").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH4))
        rsIn.Fields("IOC_05").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH5))
        rsIn.Fields("IOC_06").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH6))
        rsIn.Fields("IOC_07").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH7))
        rsIn.Fields("IOC_08").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH8))
        rsIn.Fields("IOC_09").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH9))
        rsIn.Fields("IOC_10").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH10))
        rsIn.Fields("IOC_11").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH11))
        rsIn.Fields("IOC_12").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH12))
        rsIn.Update()

        ''20年目
        rsIn.AddNew()
        iocYear += 1
        rsIn.Fields("ID").Value = i.ToString.PadLeft(5, "0")
        rsIn.Fields("IOC_YEAER").Value = iocYear + CInt(excelStrYear)
        rsIn.Fields("IOC_YYYY").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20))
        rsIn.Fields("IOC_01").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH1))
        rsIn.Fields("IOC_02").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH2))
        rsIn.Fields("IOC_03").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH3))
        rsIn.Fields("IOC_04").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH4))
        rsIn.Fields("IOC_05").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH5))
        rsIn.Fields("IOC_06").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH6))
        rsIn.Fields("IOC_07").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH7))
        rsIn.Fields("IOC_08").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH8))
        rsIn.Fields("IOC_09").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH9))
        rsIn.Fields("IOC_10").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH10))
        rsIn.Fields("IOC_11").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH11))
        rsIn.Fields("IOC_12").Value = ExcelWrite.changeDBNullToString(obj(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12))
        rsIn.Update()

    End Sub

    ''' <summary>
    ''' 機　能：WS1Categoryテーブルのレコードセットに値をセットする。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetTBL4Record(ByVal i As Integer,
                              ByRef rsIn As ADODB.Recordset,
                              ByRef row As DataRow)

        Const Row_SORTNO As Integer = 1
        Const Row_BU As Integer = 2
        Const Row_BRAND As Integer = 3
        Const Row_SUMMARYCATEGORY As Integer = 4

        rsIn.Fields("SORTNO").Value = ExcelWrite.changeDBNullToString(i).PadLeft(4, "0")
        rsIn.Fields("BU").Value = ExcelWrite.changeDBNullToString(row.Item(ColumnNM_Bu))
        rsIn.Fields("BRAND").Value = ExcelWrite.changeDBNullToString(row.Item(ColumnNM_Brand))
        rsIn.Fields("SUM_CATEGORY").Value = ExcelWrite.changeDBNullToString(row.Item(ColumnNM_SummaryCategory))

    End Sub

    ''' <summary>
    ''' 機　能：日付項目をyyyy/MM/dd 00:00:00 ⇒　yyyy/MM/ddへ変更
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function ChgFormatYYYYMMDD(ByVal Value As Object) As String

        ''初期化
        Dim tmpValue As String
        tmpValue = ExcelWrite.changeDBNullToString(Value)
        ChgFormatYYYYMMDD = tmpValue

        If IsDate(tmpValue) = True Then

            ChgFormatYYYYMMDD = String.Format(CDate(Value), "yyyy/MM/dd")

        End If

    End Function


    ''' <summary>
    ''' 機能：作成前の画面の入力値チェック
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function ChkFrmInputDate(ByVal btnName As String) As Boolean

        ''初期化
        ChkFrmInputDate = False

        ''
        ''全てのボタン共通処理
        ''
        If Not File.Exists(Me.txb_InputFile.Text) Then
            MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0081"), Me.Text)
            Exit Function
        End If

        ''
        ''ボタン毎のチェック処理
        ''
        Dim chgCount As String
        Select Case btnName
            Case "Btn_OutSeikyu"
                '統合Payment分割件数のチェック
                chgCount = Me.txb_ChangePage.Text.Replace(",", "")
                If IsNumeric(chgCount) = False Then
                    MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0328"), Me.Text)
                    Exit Function

                Else
                    If CInt(chgCount) < 2000 Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0328"), Me.Text)
                        Exit Function
                    End If

                End If

            Case "Btn_OutCOCPS"

                '統合Payment分割件数のチェック
                chgCount = Me.txb_ChangePage.Text.Replace(",", "")
                If IsNumeric(chgCount) = False Then
                    MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0328"), Me.Text)
                    Exit Function

                Else
                    If CInt(chgCount) < 2000 Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0328"), Me.Text)
                        Exit Function
                    End If

                End If

            Case "Btn_OutConList"
            Case "Btn_OutKakakuSyounin",
                 "Btn_OutKakakuSyouninNonLock",
                 "Btn_OutProjctIOC"

                Dim ofm As New OioFileManage
                If ofm.ChkOpenedExcelFile(Me.txb_InputFile.Text) = False Then
                    Call MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0417"), Me.Text)
                    Exit Function
                End If
        End Select

        Return True

    End Function

    ''' <summary>
    ''' 機能：画面のﾁｪｯｸﾎﾞｯｸｽの情報を変数にセットする。
    ''' 説明：※PaymentSampleSumのマクロの引数に使用する。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetChkBoxInfo(ByVal OutFile As String, _
                              ByRef chkcre1 As Boolean, _
                              ByRef chkcre2 As Boolean, _
                              ByRef chkcre3 As Boolean)

        ''初期化
        chkcre1 = False
        chkcre2 = False
        chkcre3 = False

        ''画面のチェックボックスの値を変数にセットする。
        Select Case OutFile
            Case OUTPUT_TYOUHYOUNAME_KAKAKUSYOUNINN
                chkcre1 = True
                chkcre2 = False
                chkcre3 = False

            Case OUTPUT_TYOUHYOUNAME_PAYMENTCOC
                chkcre1 = True
            Case Else
                chkcre1 = True
                chkcre2 = True
                chkcre3 = True
        End Select

        ''※全て未チェックはエラーメッセージ表示　⇒　全てチェック済みとする。
        If (chkcre1 = False) And _
           (chkcre2 = False) And _
           (chkcre3 = False) Then

            chkcre1 = True
            chkcre2 = True
            chkcre3 = True
        End If

    End Sub

    ''' <summary>
    ''' 機　能：ｺﾝﾎﾞﾎﾞｯｸｽの初期値を設定
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Init_Cmb_SumPaymentSheet()

        ''ﾘｽﾄの値をｾｯﾄ
        Dim addItemList(2) As Object
        addItemList(0) = Me.CmbValue_SumPayment_NotOutPut
        addItemList(1) = Me.CmbValue_SumPayment_OutPutIOC
        addItemList(2) = Me.CmbValue_SumPayment_OutPutOth
        Me.Cmb_SumPaymentSheet.Items.AddRange(addItemList)

        ''「出力しない」を選択
        Me.Cmb_SumPaymentSheet.SelectedIndex = 0

    End Sub

    ''' <summary>
    ''' 機能：価格承認サマリ作成時、統合Paymentシートを作成する。
    ''' 説明：※統合Paymentシート = (Paymentﾌｧｲﾙの値 + 契約締結済みMDBの値)
    ''' </summary>
    ''' <param name="cmbValue"></param>
    ''' <param name="PaymentFilePath"></param>
    ''' <param name="IocFilePath"></param>
    ''' <param name="createTime"></param>
    ''' <param name="outFilePath"></param>
    ''' <param name="blnSheetLock"></param>
    ''' <remarks></remarks>
    Private Sub CreateSumPaymentSheet(ByVal cmbValue As String, _
                                      ByVal PaymentFilePath As String, _
                                      ByVal IocFilePath As String, _
                                      ByVal createTime As String, _
                                      ByRef outFilePath As String, _
                                      ByVal blnSheetLock As Boolean)

        Try

            ''「出力しない」なら、処理終了
            If cmbValue = Me.CmbValue_SumPayment_NotOutPut Then
                Exit Sub
            End If

            ''PaymentとMdbの値を保持        
            Dim OutMergeDateList(,) As Object
            Dim OutDataList_1(,) As Object
            Dim OutDataList_2(,) As Object

            ''Payment.Xlsから情報を取得
            Dim excelStrYear As String
            Dim payperiod As String
            Call GetPaymentDateInArray(PaymentFilePath, OutDataList_1, excelStrYear, payperiod)

            ''Mdbから情報を取得
            Call GetMDBDateInArray(OutDataList_2)

            ''PaymentのﾃﾞｰﾀとMDBの値をマージ
            Call GetMergeDate(OutMergeDateList, OutDataList_1, OutDataList_2)

            ''取得したﾃﾞｰﾀをﾌｧｲﾙに出力する。
            Call CopySumPaymentSheet(cmbValue, IocFilePath, createTime, OutMergeDateList, excelStrYear, PaymentFilePath, outFilePath, blnSheetLock, payperiod)

        Catch ex As Exception
            ''例外の処理は行わない。

        End Try

    End Sub


    ''' <summary>
    ''' 機能：PaymentSheet.Xlsの値を配列へ格納する。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetPaymentDateInArray(ByVal PSFilePath As String, _
                                      ByRef OutDataList_1(,) As Object, _
                                      ByRef excelStrYear As String, _
                                      ByRef PayPeriod As String)


        ''初期化
        OutDataList_1 = Nothing

        ''Excel変数宣言    
        Dim xlsApp As New Excel.Application
        Dim xlsPaymentBook As Excel.Workbook
        Dim xlsOBAMASheet As Excel.Worksheet
        Dim xlsCell As Excel.Range
        Dim xlsChkCell As Excel.Range

        Try
            ''App初期化
            xlsApp.EnableEvents = False
            xlsApp.DisplayAlerts = False
            xlsApp.ScreenUpdating = False

            ''BookOpen
            xlsPaymentBook = xlsApp.Workbooks.Open(PSFilePath)
            xlsApp.Calculation = Excel.XlCalculation.xlCalculationManual

            ''Sheetｾｯﾄ
            xlsOBAMASheet = xlsPaymentBook.Worksheets(SHEET_NAME_PAYMENT)


            ''                  以下、Eof行の判定
            ''-----------------------------------------------
            Dim EofLine As Integer          ''Eof行の位置
            xlsCell = xlsOBAMASheet.Cells(EXCEL_PAYMENTLINEDATE_OUTROW, _
                                          ExcelWrite.ExcelPaymentLineColumn.LINE_NO)

            ''最初のセルに値がなければ処理終了
            If IsNumeric(xlsCell.Value) = False Then
                Exit Sub
            End If

            ''Linnoの列セルをFind関数で検索   ※空白を検索し、あればEofとする。
            Dim chkArea As String       ''Linnoの検索範囲
            chkArea = ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.LINE_NO) & EXCEL_PAYMENTLINEDATE_OUTROW & ":" & _
                      ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.LINE_NO) & ExcelWrite.GetLastRow(xlsOBAMASheet, ExcelWrite.ExcelPaymentLineColumn.LINE_NO) + 1
            xlsCell = xlsOBAMASheet.Range(chkArea)
            xlsChkCell = xlsCell.Find(What:="", _
                                      LookAt:=Excel.XlLookAt.xlWhole)
            If IsNothing(xlsChkCell) = True Then
                Exit Sub
            Else
                EofLine = xlsChkCell.Row - 1
            End If
            ExcelObjRelease.ReleaseExcelObj(xlsChkCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlsCell, ExcelObjRelease.OBJECT_NOTHING)


            ''       　以下、Paymentﾌｧｲﾙの情報をｽﾄｱ
            ''-----------------------------------------------        
            ''ﾃﾞｰﾀをまとめて配列へ取得
            xlsCell = xlsOBAMASheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG) & EXCEL_PAYMENTLINEDATE_OUTROW & ":" & _
                                          ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12) & EofLine)
            OutDataList_1 = xlsCell.FormulaR1C1
            ExcelObjRelease.ReleaseExcelObj(xlsCell, ExcelObjRelease.OBJECT_NOTHING)

            For i As Integer = 1 To UBound(OutDataList_1, 1)
                If OutDataList_1(i, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH).ToString.IndexOf("=詳細!") <> -1 Then
                    xlsCell = xlsOBAMASheet.Cells(EXCEL_PAYMENTLINEDATE_OUTROW + i - 1, _
                                                  ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH)
                    OutDataList_1(i, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH) = xlsCell.Value
                    ExcelObjRelease.ReleaseExcelObj(xlsCell, ExcelObjRelease.OBJECT_NOTHING)
                End If
            Next

            ''          以下、Excelの開始年を取得
            ''-----------------------------------------------        
            xlsCell = xlsOBAMASheet.Range("DN4")
            excelStrYear = xlsCell.Value

            Dim dummyCpno, rtnMsg As String
            Dim dummyYear As Integer
            rtnMsg = ExcelWrite.GetWS1PayPeriod(PSFilePath, dummyCpno, dummyYear, PayPeriod)
            If rtnMsg <> "" Then
                Throw New Exception(rtnMsg)
            End If

        Catch ex As Exception
            ''ﾒｯｾｰｼﾞの処理はしない。

        Finally
            xlsApp.ScreenUpdating = True
            xlsApp.Calculation = Excel.XlCalculation.xlCalculationAutomatic
            ExcelObjRelease.ReleaseExcelObj(xlsChkCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlsCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlsOBAMASheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlsPaymentBook) = False Then
                Call xlsPaymentBook.Close()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlsPaymentBook, ExcelObjRelease.OBJECT_NOTHING)
            xlsApp.EnableEvents = True
            xlsApp.DisplayAlerts = True

            If IsNothing(xlsApp) = False Then
                Call xlsApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlsApp, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' 機能：MDBを配列へ格納する。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetMDBDateInArray(ByRef OutDataList_2(,) As Object)

        ''初期化
        OutDataList_2 = Nothing

        ''MDBからﾃﾞｰﾀを取得        
        Dim Con As OleDbConnection
        Dim mmc As New MasterMdbControl
        Try

            ''接続取得
            Con = mmc.GetOleTmpDBConnection(CommonVariable.CPNO, CommonVariable.MdbPW)

            ''Sql取得
            Dim sql_Tbl1 As String = GetSql_PaymentTable1()
            Dim sql_Tbl2 As String = GetSql_PaymentTable2()
            Dim sql_Tbl3 As String = GetSql_PaymentTable3()

            ''ﾃﾞｰﾀ取得
            Dim Table1_Date As New DataTable
            Dim Table2_Date As New DataTable
            Dim Table3_Date As New DataTable
            Dim da_Tbl1 As New OleDbDataAdapter(sql_Tbl1, Con)
            Dim da_Tbl2 As New OleDbDataAdapter(sql_Tbl2, Con)
            Dim da_Tbl3 As New OleDbDataAdapter(sql_Tbl3, Con)
            Call da_Tbl1.Fill(Table1_Date)
            Call da_Tbl2.Fill(Table2_Date)
            Call da_Tbl3.Fill(Table3_Date)

            ''ﾃﾞｰﾀがなければ処理終了
            If Table1_Date.Rows.Count = 0 Then
                Exit Sub
            End If

            ''配列サイズ確定
            If Table1_Date.Rows.Count <> 0 Then
                ReDim Preserve OutDataList_2(Table1_Date.Rows.Count, ExcelWrite.MdbPaymentLineColumn.PRICE_YEAR20_MONTH12)
            End If

            ''ﾃﾞｰﾀを配列用に加工
            Dim Idx As Integer                  ''MDBのｶﾚﾝﾄ位置：年額/月額以外
            Dim IdxD As Integer                 ''MDBのｶﾚﾝﾄ位置：年額/月額
            Dim ArrayIdx As Integer             ''配列のIdx：年額/月額以外
            Dim ArrayIdxD As Integer            ''配列のIdx：年額/月額
            For Idx = 0 To Table1_Date.Rows.Count - 1

                ''配列のIdx初期化
                ArrayIdx = 0

                ''PaymentTBL1取得
                For i As Integer = 1 To Table1_Date.Columns.Count - 1
                    ArrayIdx = ArrayIdx + 1
                    OutDataList_2(Idx + 1, ArrayIdx) = Table1_Date.Rows(Idx).Item(i)
                Next

                ''PaymentTBL2取得
                For j As Integer = 1 To Table2_Date.Columns.Count - 2
                    ArrayIdx = ArrayIdx + 1
                    OutDataList_2(Idx + 1, ArrayIdx) = Table2_Date.Rows(Idx).Item(j)
                Next

                ''PaymentTBL3取得 ※20年分の値をセット
                IdxD = (Idx * 20) - 1

                '年額セット
                IdxD = IdxD + 1
                For IdxD = IdxD To IdxD + 19
                    ArrayIdx = ArrayIdx + 1
                    OutDataList_2(Idx + 1, ArrayIdx) = Table3_Date.Rows(IdxD).Item("IOC_YYYY")
                Next

                '過去の契約金額合計をセット(Mdbの40カラム目を統合Paymentの117カラム目にセット)
                ArrayIdx = ArrayIdx + 1
                OutDataList_2(Idx + 1, ArrayIdx) = Table2_Date.Rows(Idx).Item(Table2_Date.Columns.Count - 1)

                '月額セット
                ''PaymentTBL3取得 ※20年分の値をセット
                IdxD = (Idx * 20) - 1

                IdxD = IdxD + 1
                For IdxD = IdxD To IdxD + 19
                    For l As Integer = 1 To 12
                        ArrayIdx = ArrayIdx + 1

                        Select Case l
                            Case 1
                                OutDataList_2(Idx + 1, ArrayIdx) = Table3_Date.Rows(IdxD).Item("IOC_01")
                            Case 2
                                OutDataList_2(Idx + 1, ArrayIdx) = Table3_Date.Rows(IdxD).Item("IOC_02")
                            Case 3
                                OutDataList_2(Idx + 1, ArrayIdx) = Table3_Date.Rows(IdxD).Item("IOC_03")
                            Case 4
                                OutDataList_2(Idx + 1, ArrayIdx) = Table3_Date.Rows(IdxD).Item("IOC_04")
                            Case 5
                                OutDataList_2(Idx + 1, ArrayIdx) = Table3_Date.Rows(IdxD).Item("IOC_05")
                            Case 6
                                OutDataList_2(Idx + 1, ArrayIdx) = Table3_Date.Rows(IdxD).Item("IOC_06")
                            Case 7
                                OutDataList_2(Idx + 1, ArrayIdx) = Table3_Date.Rows(IdxD).Item("IOC_07")
                            Case 8
                                OutDataList_2(Idx + 1, ArrayIdx) = Table3_Date.Rows(IdxD).Item("IOC_08")
                            Case 9
                                OutDataList_2(Idx + 1, ArrayIdx) = Table3_Date.Rows(IdxD).Item("IOC_09")
                            Case 10
                                OutDataList_2(Idx + 1, ArrayIdx) = Table3_Date.Rows(IdxD).Item("IOC_10")
                            Case 11
                                OutDataList_2(Idx + 1, ArrayIdx) = Table3_Date.Rows(IdxD).Item("IOC_11")
                            Case 12
                                OutDataList_2(Idx + 1, ArrayIdx) = Table3_Date.Rows(IdxD).Item("IOC_12")
                        End Select
                    Next
                Next

            Next
            Con.Close()

        Catch ex As Exception
            ''ｴﾗｰの処理はなし
        End Try

    End Sub


    ''' <summary>
    ''' 概 要：PaymentTable1の取得SQL
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_PaymentTable1() As String

        ''戻り値
        Dim rtnValue As New StringBuilder

        ''Select句
        rtnValue.Append(CommonConstant.SQL_STR_SELECT)
        rtnValue.Append(CommonConstant.SQL_STR_ASTERISK)

        ''From句
        rtnValue.Append(CommonConstant.SQL_STR_FROM)
        rtnValue.Append(" PaymentTBL1 ")

        ''Order By句
        rtnValue.Append(CommonConstant.SQL_STR_ORDER_BY)
        rtnValue.Append(" ID ")

        Return rtnValue.ToString

    End Function


    ''' <summary>
    ''' 概 要：PaymentTable2の取得SQL
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_PaymentTable2() As String

        ''戻り値
        Dim rtnValue As New StringBuilder

        ''Select句
        rtnValue.Append(CommonConstant.SQL_STR_SELECT)
        rtnValue.Append(CommonConstant.SQL_STR_ASTERISK)

        ''From句
        rtnValue.Append(CommonConstant.SQL_STR_FROM)
        rtnValue.Append(" PaymentTBL2 ")

        ''Order By句
        rtnValue.Append(CommonConstant.SQL_STR_ORDER_BY)
        rtnValue.Append(" ID ")

        Return rtnValue.ToString

    End Function


    ''' <summary>
    ''' 概 要：PaymentTable3の取得SQL
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_PaymentTable3() As String

        ''戻り値
        Dim rtnValue As New StringBuilder

        ''Select句
        rtnValue.Append(CommonConstant.SQL_STR_SELECT)
        rtnValue.Append(CommonConstant.SQL_STR_ASTERISK)

        ''From句
        rtnValue.Append(CommonConstant.SQL_STR_FROM)
        rtnValue.Append(" PaymentTBL3 ")

        ''Order By句
        rtnValue.Append(CommonConstant.SQL_STR_ORDER_BY)
        rtnValue.Append(" ID, IOC_YEAER")

        Return rtnValue.ToString

    End Function


    ''' <summary>
    ''' 概 要：Payment.Xlsの配列ﾃﾞｰﾀとMDBの配列ﾃﾞｰﾀを統合する。
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetMergeDate(ByRef OutMergeDateList(,) As Object,
                             ByRef OutDataList_1(,) As Object, _
                             ByRef OutDataList_2(,) As Object)

        ''初期化
        OutMergeDateList = Nothing

        ''Payment.Xlsの値をﾏｰｼﾞ        ※配列メモ：2次元配列は動的に配列拡張できない。
        Dim MergeList As New ArrayList
        If IsNothing(OutDataList_1) = False Then
            For Idx As Integer = 1 To UBound(OutDataList_1, 1)

                ''「作成中」、「価格承認済み」以外対象外
                If OutDataList_1(Idx, ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG) = "" Or _
                   OutDataList_1(Idx, ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG) = "P" Then

                    Call MergeList.Add(GetMargeValue(OutDataList_1, Idx))

                End If
            Next
        End If

        ''Mdbの値をﾏｰｼﾞ
        If IsNothing(OutDataList_2) = False Then
            For Idx As Integer = 1 To UBound(OutDataList_2, 1)
                Call MergeList.Add(GetMargeValue(OutDataList_2, Idx))
            Next
        End If

        ''値をｾｯﾄ     ※ArrayListの値を配列へ入れ替える。
        If MergeList.Count <> 0 Then
            ReDim OutMergeDateList(MergeList.Count - 1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12 - 1)
            For i As Integer = 0 To MergeList.Count - 1
                For j As Integer = 0 To ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12 - 1
                    OutMergeDateList(i, j) = MergeList(i)(j + 1)
                Next
            Next
        End If

    End Sub


    ''' <summary>
    ''' 概 要：1行分のﾃﾞｰﾀをﾏｰｼﾞ
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetMargeValue(ByRef OutDataList(,) As Object, _
                                   ByVal Idx As Integer) As Object

        ''値のｾｯﾄ
        Dim rtnOutMergeDateList(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12) As Object
        For IdxD As Integer = 1 To UBound(OutDataList, 2)
            rtnOutMergeDateList(IdxD) = OutDataList(Idx, IdxD)
        Next
        Return rtnOutMergeDateList

    End Function


    ''' <summary>
    ''' 概 要：配列ﾃﾞｰﾀを元に統合Paymentｼｰﾄを作成する。
    ''' 説 明：
    ''' </summary>
    ''' <param name="cmbValue"></param>
    ''' <param name="IocFilePath"></param>
    ''' <param name="createTime"></param>
    ''' <param name="OutMergeDateList"></param>
    ''' <param name="excelStrYear"></param>
    ''' <param name="PaymentFilePath"></param>
    ''' <param name="outFilePath"></param>
    ''' <param name="blnLock"></param>
    ''' <remarks></remarks>
    'START 変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
    Private Sub CopySumPaymentSheet(ByVal cmbValue As String, _
                                    ByVal IocFilePath As String, _
                                    ByVal createTime As String, _
                                    ByRef OutMergeDateList(,) As Object, _
                                    ByRef excelStrYear As String, _
                                    ByVal PaymentFilePath As String, _
                                    ByRef outFilePath As String, _
                                    ByVal blnSheetLock As Boolean, _
                                    ByVal PayPeriod As String)

        '共通
        Dim xlApp As New Excel.Application
        Dim xlBooks As Excel.Workbooks
        'コピー元
        Dim xlBookSrc As Excel.Workbook
        Dim xlSheetsSrc As Excel.Sheets
        Dim xlSheetSrc As Excel.Worksheet
        Dim xlCellSrc As Excel.Range
        'コピー先
        Dim xlBookDest As Excel.Workbook
        Dim xlSheetsDest As Excel.Sheets
        Dim xlSheetDest As Excel.Worksheet
        Dim xlCellDest As Excel.Range
        'ワーク用
        Dim xlSheet As Excel.Worksheet
        Dim xlCells As Excel.Range
        Dim xlRows As Excel.Range
        Dim xlRangeSort As Excel.Range
        Dim xlNames As Excel.Names
        Dim xlName As Excel.Name

        Dim ofm As New OioFileManage

        Try
            xlApp.EnableEvents = False
            xlApp.DisplayAlerts = False
            xlBooks = xlApp.Workbooks

            '=======================================================
            'Templateﾌｧｲﾙから、「OBAMA-PS」ｼｰﾄをｺﾋﾟｰ
            '=======================================================
            xlBookSrc = xlBooks.Open(FileManager.GetLocalFolderPath(CommonConstant.FOLDERNAME_TEMPLATE) & CommonConstant.FILENAME_XLS_PAYMENTSAMPLE)
            xlSheetsSrc = xlBookSrc.Worksheets
            xlSheetSrc = xlSheetsSrc.Item(SHEET_NAME_PAYMENT)

            'ｺﾝﾎﾞﾎﾞｯｸｽの値に応じて、出力先のシートを変更する。
            Select Case cmbValue
                Case Me.CmbValue_SumPayment_OutPutIOC
                    '同一ファイルにコピー

                    ''ｼｰﾄｺﾋﾟｰ
                    xlBookDest = xlBooks.Open(IocFilePath)
                    xlSheetsDest = xlBookDest.Worksheets
                    xlSheetDest = xlSheetsDest.Item(xlSheetsDest.Count)
                    xlSheetSrc.Copy(After:=xlSheetDest)
                    ExcelObjRelease.ReleaseExcelObj(xlSheetDest, ExcelObjRelease.OBJECT_NOTHING)

                    ''ｼｰﾄ名変更
                    xlSheetDest = xlSheetsDest.Item(SHEET_NAME_PAYMENT)
                    xlSheetDest.Name = SHEET_NAME_JOIN_PAYMENT

                Case Me.CmbValue_SumPayment_OutPutOth
                    '別ファイルに出力

                    ''ｼｰﾄｺﾋﾟｰ
                    xlBookDest = xlBooks.Add
                    xlSheetsDest = xlBookDest.Worksheets
                    xlSheetDest = xlSheetsDest.Item(xlSheetsDest.Count)
                    xlSheetSrc.Copy(After:=xlSheetDest)
                    ExcelObjRelease.ReleaseExcelObj(xlSheetDest, ExcelObjRelease.OBJECT_NOTHING)

                    ''ｼｰﾄ名変更
                    xlSheetDest = xlSheetsDest.Item(xlSheetsDest.Count)
                    xlSheetDest.Name = SHEET_NAME_JOIN_PAYMENT

                    ''不要なｼｰﾄがあれば削除      ※最後のｼｰﾄが統合ｼｰﾄなので、それ以外は不要
                    For idx As Integer = xlSheetsDest.Count - 1 To 1 Step -1
                        xlSheetDest = xlSheetsDest.Item(idx)
                        xlSheetDest.Delete()
                        ExcelObjRelease.ReleaseExcelObj(xlSheetDest, ExcelObjRelease.OBJECT_NOTHING)
                    Next
                    xlSheetDest = xlSheetsDest.Item(xlSheetsDest.Count)
            End Select
            'コピー元解放
            ExcelObjRelease.ReleaseExcelObj(xlSheetSrc, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheetsSrc, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBookSrc) = False Then
                xlBookSrc.Close()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBookSrc, ExcelObjRelease.OBJECT_NOTHING)

            xlApp.Calculation = Excel.XlCalculation.xlCalculationManual

            '=======================================================
            'ﾃﾝﾌﾟﾚｰﾄ行コピペ
            '=======================================================
            Const CopyCount As Integer = 1000           ''一度のｺﾋﾟｰ行数
            Dim outCount As Integer                     ''出力行数
            Dim pasteCount As Integer                   ''貼付回数
            Dim strCopyIdx As Integer                   ''ｺﾋﾟｰ範囲：開始位置
            Dim endCopyIdx As Integer                   ''ｺﾋﾟｰ範囲：終了位置

            ''貼付回数を取得する。
            outCount = UBound(OutMergeDateList, 1) + 1
            If outCount = 0 Then
                Exit Sub
            End If
            pasteCount = Math.Truncate((outCount - 1) / CopyCount) + 1
            xlRows = xlSheetDest.Rows
            xlCellDest = DirectCast(xlRows.Item(ExcelWrite.EXCEL_PAYMENTLINE_TMPROW), Excel.Range)
            xlCellDest.Hidden = False
            xlCellDest.Copy()
            ExcelObjRelease.ReleaseExcelObj(xlCellDest, ExcelObjRelease.OBJECT_NOTHING)
            For PastIdx As Integer = 1 To pasteCount

                ''開始/終了位置を取得
                strCopyIdx = (PastIdx - 1) * CopyCount + EXCEL_PAYMENTLINEDATE_OUTROW
                If outCount >= (PastIdx * CopyCount) Then
                    endCopyIdx = (PastIdx * CopyCount) + EXCEL_PAYMENTLINEDATE_OUTROW - 1
                Else
                    endCopyIdx = strCopyIdx + (outCount Mod CopyCount) - 1
                End If

                ''コピペ実行
                xlCellDest = DirectCast(xlRows.Item(strCopyIdx.ToString & ":" & endCopyIdx.ToString), Excel.Range)
                xlCellDest.PasteSpecial()
                ExcelObjRelease.ReleaseExcelObj(xlCellDest, ExcelObjRelease.OBJECT_NOTHING)

            Next
            'Template行非表示
            xlCellDest = DirectCast(xlRows.Item(ExcelWrite.EXCEL_PAYMENTLINE_TMPROW), Excel.Range)
            xlCellDest.Hidden = True
            ExcelObjRelease.ReleaseExcelObj(xlCellDest, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlRows, ExcelObjRelease.OBJECT_NOTHING)

            '=======================================================
            '項目の書式セット
            '=======================================================
            xlCellDest = xlSheetDest.Cells
            For idx As Integer = 0 To UBound(OutMergeDateList, 1)
                ''HWMAのパターンの場合のみ、項目9に掛率のExcel式が入力されるため、Cellの書式を変更する。
                If ExcelWrite.changeDBNullToString(OutMergeDateList(idx, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM09 - 1)).IndexOf("=") <> -1 Then
                    xlCells = DirectCast(xlCellDest.Item(EXCEL_PAYMENTLINEDATE_OUTROW + idx, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM09), Excel.Range)
                    xlCells.NumberFormatLocal = "G/標準"
                    ExcelObjRelease.ReleaseExcelObj(xlCells, ExcelObjRelease.OBJECT_NOTHING)
                End If
            Next
            ExcelObjRelease.ReleaseExcelObj(xlCellDest, ExcelObjRelease.OBJECT_NOTHING)

            '=======================================================
            '値のセット
            '=======================================================
            'データ量によって「メモリ不足です。」が発生するため、1000件づつ貼り付け
            Dim setArea As String           ''値の貼付範囲
            For PastIdx As Integer = 1 To pasteCount

                ''開始/終了位置を取得
                strCopyIdx = (PastIdx - 1) * CopyCount + EXCEL_PAYMENTLINEDATE_OUTROW
                If outCount >= (PastIdx * CopyCount) Then
                    endCopyIdx = (PastIdx * CopyCount) + EXCEL_PAYMENTLINEDATE_OUTROW - 1
                Else
                    endCopyIdx = strCopyIdx + (outCount Mod CopyCount) - 1
                End If
                setArea = ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG) & strCopyIdx & _
                          ":" & _
                          ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12) & endCopyIdx

                ''出力用データ貼り付け  ※1000件分
                Dim OutCellValue(endCopyIdx - strCopyIdx, UBound(OutMergeDateList, 2)) As Object
                For Idx As Integer = strCopyIdx To endCopyIdx
                    For IdxD As Integer = 0 To UBound(OutMergeDateList, 2)
                        OutCellValue(Idx - strCopyIdx, IdxD) = OutMergeDateList(Idx - EXCEL_PAYMENTLINEDATE_OUTROW, IdxD)
                    Next
                Next
                xlCellDest = xlSheetDest.Range(setArea)
                xlCellDest.FormulaR1C1 = OutCellValue
                ExcelObjRelease.ReleaseExcelObj(xlCellDest, ExcelObjRelease.OBJECT_NOTHING)
            Next

            '=======================================================
            'Linno順にSort
            '=======================================================
            If endCopyIdx <> EXCEL_PAYMENTLINEDATE_OUTROW Then
                Dim sortArea As String           ''Sort範囲
                sortArea = ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG) & EXCEL_PAYMENTLINEDATE_OUTROW & _
                           ":" & _
                           ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12) & endCopyIdx
                xlRangeSort = xlSheetDest.Range(sortArea)
                xlCells = xlSheetDest.Cells
                xlCellDest = DirectCast(xlCells.Item(EXCEL_PAYMENTLINEDATE_OUTROW, ExcelWrite.ExcelPaymentLineColumn.LINE_NO), Excel.Range)
                Call xlRangeSort.Sort(Key1:=xlCellDest, _
                                      Order1:=Excel.XlSortOrder.xlAscending, _
                                      Orientation:=Excel.XlSortOrientation.xlSortColumns)
                ExcelObjRelease.ReleaseExcelObj(xlRangeSort, ExcelObjRelease.OBJECT_NOTHING)
                ExcelObjRelease.ReleaseExcelObj(xlCellDest, ExcelObjRelease.OBJECT_NOTHING)
                ExcelObjRelease.ReleaseExcelObj(xlCells, ExcelObjRelease.OBJECT_NOTHING)
            End If

            '=======================================================
            '契約期間を固定値で貼付
            '=======================================================
            ''Excel開始年をセット
            xlCellDest = xlSheetDest.Range("DN4")
            xlCellDest.Value = excelStrYear
            ExcelObjRelease.ReleaseExcelObj(xlCellDest, ExcelObjRelease.OBJECT_NOTHING)

            ''契約期間の固定化
            xlBookSrc = xlBooks.Open(PaymentFilePath)
            xlSheetsSrc = xlBookSrc.Worksheets
            xlSheetSrc = xlSheetsSrc.Item(SHEET_NAME_PAYMENT)
            Dim contractArea As String
            contractArea = ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1) & "3" & _
                           ":" & _
                           ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12) & "3"
            xlCellSrc = xlSheetSrc.Range(contractArea)
            xlCellSrc.Copy()
            ExcelObjRelease.ReleaseExcelObj(xlCellSrc, ExcelObjRelease.OBJECT_NOTHING)
            xlCellDest = xlSheetDest.Range(contractArea)
            xlCellDest.PasteSpecial(Paste:=Excel.XlPasteType.xlPasteValues)
            ExcelObjRelease.ReleaseExcelObj(xlCellDest, ExcelObjRelease.OBJECT_NOTHING)

            ''Bookを複数開いてBookのSaveｲﾍﾞﾝﾄを発行すると極端にレスポンスが落ちる。ING)
            ExcelObjRelease.ReleaseExcelObj(xlSheetSrc, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheetsSrc, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBookSrc) = False Then
                xlBookSrc.Close()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBookSrc, ExcelObjRelease.OBJECT_NOTHING)

            '=======================================================
            '名前の定義削除
            '=======================================================
            xlNames = xlBookDest.Names
            For intCnt As Integer = xlNames.Count To 1 Step -1
                xlName = xlNames.Item(intCnt)
                If xlName.Name.IndexOf("_FilterDatabase") = -1 Then
                    xlName.Delete()
                End If
                ExcelObjRelease.ReleaseExcelObj(xlName, ExcelObjRelease.OBJECT_NOTHING)
            Next
            ExcelObjRelease.ReleaseExcelObj(xlNames, ExcelObjRelease.OBJECT_NOTHING)

            '=======================================================
            'オートフィルタの再設定
            '=======================================================
            ''OBAMA-PS/Detailシートの再フィルタ 
            For Each xlSheet In xlSheetsDest
                If xlSheet.Name = SHEET_NAME_JOIN_PAYMENT Then
                    xlSheet.AutoFilterMode = False
                    xlSheet.Activate()
                    xlCells = xlSheet.Range("A5:MS5")
                    xlCells.AutoFilter(Field:=1)
                    ExcelObjRelease.ReleaseExcelObj(xlCells, ExcelObjRelease.OBJECT_NOTHING)
                End If
                If xlSheet.Name = SHEET_NAME_DETAIL Then
                    xlSheet.Unprotect(CommonVariable.SummaryPW)
                    xlSheet.AutoFilterMode = False
                    xlSheet.Activate()
                    xlCells = xlSheet.Range("A6:AG6")
                    xlCells.AutoFilter(Field:=1)
                    If blnSheetLock = True Then
                        Call ProtectSheet(xlSheet, CommonVariable.SummaryPW)
                    End If
                    ExcelObjRelease.ReleaseExcelObj(xlCells, ExcelObjRelease.OBJECT_NOTHING)
                End If
                ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
                GC.Collect()
            Next

            '=======================================================
            'Payment保有年数以外の月額情報を削除し、不要な年度情報を非表示にする
            '=======================================================
            If PayPeriod <> 20 Then
                Call SumPaymentDeleteColum(xlSheetDest, PayPeriod)
            End If

            '=======================================================
            'シート保護
            '=======================================================
            If blnSheetLock = True Then
                xlSheetDest = xlSheetsDest.Item(SHEET_NAME_JOIN_PAYMENT)
                If cmbValue = CmbValue_SumPayment_OutPutIOC Then
                    Call ProtectSheet(xlSheetDest, CommonVariable.SummaryPW)
                Else
                    Call ProtectSheet(xlSheetDest, CommonVariable.PaymentPW)
                End If
                ExcelObjRelease.ReleaseExcelObj(xlSheetDest, ExcelObjRelease.OBJECT_NOTHING)
                ExcelObjRelease.ReleaseExcelObj(xlSheetsDest, ExcelObjRelease.OBJECT_NOTHING)
                GC.Collect()
            End If

            '=======================================================
            'Book保存
            '=======================================================
            xlApp.Calculation = Excel.XlCalculation.xlCalculationAutomatic

            Select Case cmbValue
                Case Me.CmbValue_SumPayment_OutPutIOC
                    Call xlBookDest.Save()

                Case Me.CmbValue_SumPayment_OutPutOth
                    outFilePath = ofm.GetLocalOutputCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO) & _
                                  ofm.GetSumPaymentExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO, createTime, blnSheetLock)
                    outFilePath = outFilePath.Replace("__", "_")
                    Call xlBookDest.SaveAs(Filename:=outFilePath, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

            End Select

        Catch ex As Exception
            Throw ex

        Finally
            '=======================================================
            'Excelｵﾌﾞｼﾞｪｸﾄ解放
            '=======================================================
            'ワーク用
            ExcelObjRelease.ReleaseExcelObj(xlName, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCells, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlRows, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlRangeSort, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            'コピー元
            ExcelObjRelease.ReleaseExcelObj(xlCellSrc, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheetSrc, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheetsSrc, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBookSrc) = False Then
                xlBookSrc.Close()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBookSrc, ExcelObjRelease.OBJECT_NOTHING)
            'コピー先
            ExcelObjRelease.ReleaseExcelObj(xlCellDest, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheetDest, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheetsDest, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBookDest) = False Then
                xlBookDest.Close()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBookDest, ExcelObjRelease.OBJECT_NOTHING)
            '共通
            ExcelObjRelease.ReleaseExcelObj(xlBooks, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Sub

    ''' <summary>
    ''' 機能：Payment保有年数以外の月額情報を削除し、不要な年度情報を非表示にする
    ''' </summary>
    ''' <param name="xlOutSheet"></param>
    ''' <param name="strPaymentPeriod"></param>
    ''' <remarks></remarks>
    Private Sub SumPaymentDeleteColum(ByRef xlOutSheet As Excel.Worksheet, ByVal strPaymentPeriod As String)

        Dim xlCells As Excel.Range
        Dim xlRange As Excel.Range
        Dim strRange As String

        Try
            '「【IBM Confidential】」をコピー
            'xlOutSheet.Range("MS1").Copy(xlOutSheet.Range("DY1"))
            xlRange = xlOutSheet.Range("MS1")
            xlRange.Copy()
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            strRange = ExcelWrite.ChgExcelRowNumberToChar(Integer.Parse(strPaymentPeriod) * 12 + ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL)
            xlRange = xlOutSheet.Range(strRange & "1")
            xlRange.PasteSpecial()
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)

            '月額の不要分を削除
            'xlRange = xlOutSheet.Columns("DZ:MS")
            strRange = ExcelWrite.ChgExcelRowNumberToChar(Integer.Parse(strPaymentPeriod) * 12 + ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL + 1)
            xlRange = xlOutSheet.Columns(strRange & ":MS")
            xlRange.Delete(Shift:=Excel.XlDeleteShiftDirection.xlShiftToLeft)
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)

            '年額の不要分を非表示
            'xlRange = xlOutSheet.Columns("CT:DL")
            strRange = ExcelWrite.ChgExcelRowNumberToChar(Integer.Parse(strPaymentPeriod) * 12 + ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1 + 1)
            xlCells = xlOutSheet.Cells
            xlRange = xlCells.Item(strRange & ":DL")
            xlRange.Hidden = True
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCells, ExcelObjRelease.OBJECT_NOTHING)

        Catch ex As Exception
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCells, ExcelObjRelease.OBJECT_NOTHING)

        End Try

    End Sub
    'Private Sub CopySumPaymentSheet(ByVal cmbValue As String, _
    '                                ByVal IocFilePath As String, _
    '                                ByVal createTime As String, _
    '                                ByRef OutMergeDateList(,) As Object, _
    '                                ByRef excelStrYear As String, _
    '                                ByVal PaymentFilePath As String, _
    '                                ByRef outFilePath As String, _
    '                                ByVal blnSheetLock As Boolean, _
    '                                ByVal PayPeriod As String)

    '    Dim OutSheetNM As String = SHEET_NAME_JOIN_PAYMENT

    '    ''Excel変数の宣言
    '    Dim xlApp As New Excel.Application
    '    Dim xlCopyBook As Excel.Workbook            ''ｺﾋﾟｰ対象：PaymentLineSample.xls
    '    Dim xlPSBook As Excel.Workbook              ''ｺﾋﾟｰ対象：PSﾌｧｲﾙ
    '    Dim xlOBAMASheet As Excel.Worksheet         ''ｺﾋﾟｰ対象：OIOシート
    '    Dim xlCopySheet As Excel.Worksheet          ''ｺﾋﾟｰ対象：OBAMA-PSシート
    '    Dim xlPasteSheet As Excel.Worksheet
    '    Dim xlfilerSheet As Excel.Worksheet         ''filter対象：OBAMA-PSシート
    '    Dim xlOutBook As Excel.Workbook
    '    Dim xlOutSheet As Excel.Worksheet
    '    Dim xlCell As Excel.Range
    '    Dim xlCopyCell As Excel.Range
    '    Dim xlName As Excel.Name
    '    Dim xlBooks As Excel.Workbooks = Nothing

    '    Try

    '        ''                   以下、統合PaymentSheetを作成
    '        ''------------------------------------------------------------------

    '        ''App設定
    '        xlApp.EnableEvents = False
    '        xlApp.DisplayAlerts = False
    '        xlBooks = xlApp.Workbooks

    '        ''Templateﾌｧｲﾙから、「OBAMA-PS」ｼｰﾄをｺﾋﾟｰ
    '        Dim ofm As New OioFileManage
    '        xlCopyBook = xlBooks.Open(FileManager.GetLocalFolderPath(CommonConstant.FOLDERNAME_TEMPLATE) & "PaymentLineSample.xlsm")
    '        xlCopySheet = xlCopyBook.Worksheets(SHEET_NAME_PAYMENT)


    '        ''ｺﾝﾎﾞﾎﾞｯｸｽの値に応じて、出力先のシートを変更する。
    '        Select Case cmbValue
    '            Case Me.CmbValue_SumPayment_OutPutIOC

    '                ''ｼｰﾄｺﾋﾟｰ
    '                xlOutBook = xlApp.Workbooks.Open(IocFilePath)
    '                xlPasteSheet = xlOutBook.Worksheets(xlOutBook.Worksheets.Count)
    '                Call xlCopySheet.Copy(After:=xlPasteSheet)

    '                ''ｼｰﾄ名変更
    '                xlOutSheet = xlOutBook.Worksheets(SHEET_NAME_PAYMENT)
    '                xlOutSheet.Name = OutSheetNM

    '            Case Me.CmbValue_SumPayment_OutPutOth

    '                ''ｼｰﾄｺﾋﾟｰ
    '                xlOutBook = xlBooks.Add
    '                xlPasteSheet = xlOutBook.Worksheets(xlOutBook.Worksheets.Count)
    '                Call xlCopySheet.Copy(After:=xlPasteSheet)

    '                ''ｼｰﾄ名変更
    '                xlOutSheet = xlOutBook.Worksheets(xlOutBook.Worksheets.Count)
    '                xlOutSheet.Name = OutSheetNM

    '                ''不要なｼｰﾄがあれば削除      ※最後のｼｰﾄが統合ｼｰﾄなので、それ以外は不要
    '                For idx As Integer = xlOutBook.Worksheets.Count - 1 To 1 Step -1
    '                    xlPasteSheet = xlOutBook.Worksheets(idx)
    '                    Call xlPasteSheet.Delete()
    '                    ExcelObjRelease.ReleaseExcelObj(xlPasteSheet, ExcelObjRelease.OBJECT_NOTHING)
    '                Next

    '        End Select

    '        ''Book関係APP設定
    '        xlApp.Calculation = Excel.XlCalculation.xlCalculationManual


    '        ''                   以下、ﾃﾝﾌﾟﾚｰﾄ行コピペ
    '        ''------------------------------------------------------------------
    '        ''ﾃﾝﾌﾟﾚｰﾄ行をｺﾋﾟﾍﾟする。
    '        Const CopyCount As Integer = 1000           ''一度のｺﾋﾟｰ行数
    '        Dim outCount As Integer                     ''出力行数
    '        Dim pasteCount As Integer                   ''貼付回数
    '        Dim strCopyIdx As Integer                   ''ｺﾋﾟｰ範囲：開始位置
    '        Dim endCopyIdx As Integer                   ''ｺﾋﾟｰ範囲：終了位置

    '        ''貼付回数を取得する。
    '        outCount = UBound(OutMergeDateList, 1) + 1
    '        If outCount = 0 Then
    '            Exit Sub
    '        End If
    '        pasteCount = Math.Truncate((outCount - 1) / CopyCount) + 1
    '        xlCopyCell = xlOutSheet.Rows(2)
    '        xlCopyCell.Hidden = False
    '        For PastIdx As Integer = 1 To pasteCount

    '            ''開始/終了位置を取得
    '            strCopyIdx = (PastIdx - 1) * CopyCount + EXCEL_PAYMENTLINEDATE_OUTROW
    '            If outCount >= (PastIdx * CopyCount) Then
    '                endCopyIdx = (PastIdx * CopyCount) + EXCEL_PAYMENTLINEDATE_OUTROW - 1
    '            Else
    '                endCopyIdx = strCopyIdx + (outCount Mod CopyCount) - 1
    '            End If

    '            ''コピペ実行
    '            xlCell = xlOutSheet.Rows(strCopyIdx & ":" & endCopyIdx)
    '            Call xlCopyCell.Copy()
    '            Call xlCell.PasteSpecial()
    '            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

    '        Next
    '        xlCopyCell.Hidden = True
    '        ExcelObjRelease.ReleaseExcelObj(xlCopyCell, ExcelObjRelease.OBJECT_NOTHING)


    '        ''                      以下、項目の書式セット
    '        ''------------------------------------------------------------------
    '        For idx As Integer = 0 To UBound(OutMergeDateList, 1)
    '            ''HWMAのパターンの場合のみ、項目9に掛率のExcel式が入力されるため、Cellの書式を変更する。
    '            If ExcelWrite.changeDBNullToString(OutMergeDateList(idx, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM09 - 1)).IndexOf("=") <> -1 Then
    '                xlCell = xlOutSheet.Cells(EXCEL_PAYMENTLINEDATE_OUTROW + idx, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM09)
    '                xlCell.NumberFormatLocal = "G/標準"
    '                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
    '            End If
    '        Next

    '        ''                      以下、値のセット
    '        ''------------------------------------------------------------------
    '        'データ量によって「メモリ不足です。」が発生するため、1000件づつ貼り付け
    '        Dim setArea As String           ''値の貼付範囲
    '        For PastIdx As Integer = 1 To pasteCount

    '            ''開始/終了位置を取得
    '            strCopyIdx = (PastIdx - 1) * CopyCount + EXCEL_PAYMENTLINEDATE_OUTROW
    '            If outCount >= (PastIdx * CopyCount) Then
    '                endCopyIdx = (PastIdx * CopyCount) + EXCEL_PAYMENTLINEDATE_OUTROW - 1
    '            Else
    '                endCopyIdx = strCopyIdx + (outCount Mod CopyCount) - 1
    '            End If
    '            setArea = ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG) & strCopyIdx & _
    '                      ":" & _
    '                      ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12) & endCopyIdx

    '            ''出力用データ貼り付け  ※1000件分
    '            Dim OutCellValue(endCopyIdx - strCopyIdx, UBound(OutMergeDateList, 2)) As Object
    '            For Idx As Integer = strCopyIdx To endCopyIdx
    '                For IdxD As Integer = 0 To UBound(OutMergeDateList, 2)
    '                    OutCellValue(Idx - strCopyIdx, IdxD) = OutMergeDateList(Idx - EXCEL_PAYMENTLINEDATE_OUTROW, IdxD)
    '                Next
    '            Next
    '            xlCell = xlOutSheet.Range(setArea)
    '            xlCell.FormulaR1C1 = OutCellValue
    '            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
    '        Next


    '        ''                      以下、Linno順にSort
    '        ''------------------------------------------------------------------
    '        If endCopyIdx <> EXCEL_PAYMENTLINEDATE_OUTROW Then
    '            Dim sortArea As String           ''Sort範囲
    '            sortArea = ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG) & EXCEL_PAYMENTLINEDATE_OUTROW & _
    '                       ":" & _
    '                       ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12) & endCopyIdx
    '            xlCell = xlOutSheet.Range(sortArea)
    '            xlCopyCell = xlOutSheet.Cells(EXCEL_PAYMENTLINEDATE_OUTROW, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)
    '            Call xlCell.Sort(Key1:=xlCopyCell, _
    '                             Order1:=Excel.XlSortOrder.xlAscending, _
    '                             Orientation:=Excel.XlSortOrientation.xlSortColumns)
    '            ExcelObjRelease.ReleaseExcelObj(xlCopyCell, ExcelObjRelease.OBJECT_NOTHING)
    '            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
    '        End If

    '        ''                      以下、契約期間を固定値で貼付
    '        ''------------------------------------------------------------------
    '        ''Excel開始年をセット
    '        xlCell = xlOutSheet.Range("DN4")
    '        xlCell.Value = excelStrYear
    '        ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

    '        ''契約期間の固定化
    '        xlPSBook = xlBooks.Open(PaymentFilePath)
    '        xlOBAMASheet = xlPSBook.Worksheets(SHEET_NAME_PAYMENT)
    '        Dim contractArea As String
    '        contractArea = ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1) & "3" & _
    '                       ":" & _
    '                       ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12) & "3"
    '        xlCopyCell = xlOBAMASheet.Range(contractArea)
    '        Call xlCopyCell.Copy()
    '        xlCell = xlOutSheet.Range(contractArea)
    '        Call xlCell.PasteSpecial(Paste:=Excel.XlPasteType.xlPasteValues)
    '        ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

    '        ''Bookを複数開いてBookのSaveｲﾍﾞﾝﾄを発行すると極端にレスポンスが落ちる。
    '        ExcelObjRelease.ReleaseExcelObj(xlCopyCell, ExcelObjRelease.OBJECT_NOTHING)
    '        ExcelObjRelease.ReleaseExcelObj(xlOBAMASheet, ExcelObjRelease.OBJECT_NOTHING)
    '        If IsNothing(xlPSBook) = False Then
    '            xlPSBook.Close()
    '        End If
    '        ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)

    '        ''                      以下、名前の定義削除
    '        ''------------------------------------------------------------------
    '        For Each xlName In xlOutBook.Names
    '            If xlName.Name.IndexOf("_FilterDatabase") = -1 Then
    '                Call xlName.Delete()
    '            End If
    '        Next

    '        ''                      以下、オートフィルタの再設定
    '        ''------------------------------------------------------------------
    '        ''テスト----------------------------------------------------
    '        ''OBAMA-PS/Detailシートの再フィルタ 
    '        For i As Integer = 1 To xlOutBook.Worksheets.Count
    '            xlfilerSheet = xlOutBook.Worksheets(i)
    '            If xlfilerSheet.Name = SHEET_NAME_JOIN_PAYMENT Then
    '                xlfilerSheet.AutoFilterMode = False
    '                Call xlfilerSheet.Activate()
    '                xlCell = xlfilerSheet.Range("A5:MS5")
    '                xlCell.AutoFilter(Field:=1)
    '            End If
    '            If xlfilerSheet.Name = SHEET_NAME_DETAIL Then
    '                xlfilerSheet.Unprotect(CommonVariable.SummaryPW)

    '                xlfilerSheet.AutoFilterMode = False
    '                Call xlfilerSheet.Activate()
    '                xlCell = xlfilerSheet.Range("A6:AG6")
    '                xlCell.AutoFilter(Field:=1)
    '                If blnSheetLock = True Then
    '                    Call ProtectSheet(xlfilerSheet, CommonVariable.SummaryPW)
    '                End If
    '                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
    '                ExcelObjRelease.ReleaseExcelObj(xlfilerSheet, ExcelObjRelease.OBJECT_NOTHING)
    '                GC.Collect()
    '            End If
    '        Next
    '        ''テスト----------------------------------------------------

    '        'Payment保有年数以外の月額情報を削除し、不要な年度情報を非表示にする
    '        Dim xlPSRange As Excel.Range
    '        Dim entryRange As Excel.Range
    '        Dim enColumns As Excel.Range

    '        Select Case PayPeriod
    '            Case 1
    '                xlOutSheet.Range("MS1").Copy(xlOutSheet.Range("DY1"))
    '                xlPSRange = xlOutSheet.Columns("DZ:MS")
    '                xlPSRange.Delete(Shift:=Excel.XlDeleteShiftDirection.xlShiftToLeft)
    '                entryRange = xlOutSheet.Columns("CT:DL")
    '                entryRange.Hidden = True
    '            Case 2
    '                xlOutSheet.Range("MS1").Copy(xlOutSheet.Range("EK1"))
    '                xlPSRange = xlOutSheet.Columns("EL:MS")
    '                xlPSRange.Delete(Shift:=Excel.XlDeleteShiftDirection.xlShiftToLeft)
    '                entryRange = xlOutSheet.Columns("CU:DL")
    '                entryRange.Hidden = True
    '            Case 3
    '                xlOutSheet.Range("MS1").Copy(xlOutSheet.Range("EW1"))
    '                xlPSRange = xlOutSheet.Columns("EX:MS")
    '                xlPSRange.Delete(Shift:=Excel.XlDeleteShiftDirection.xlShiftToLeft)
    '                entryRange = xlOutSheet.Columns("CV:DL")
    '                entryRange.Hidden = True
    '            Case 4
    '                xlOutSheet.Range("MS1").Copy(xlOutSheet.Range("FI1"))
    '                xlPSRange = xlOutSheet.Columns("FJ:MS")
    '                xlPSRange.Delete(Shift:=Excel.XlDeleteShiftDirection.xlShiftToLeft)
    '                entryRange = xlOutSheet.Columns("CW:DL")
    '                entryRange.Hidden = True
    '            Case 5
    '                xlOutSheet.Range("MS1").Copy(xlOutSheet.Range("FU1"))
    '                xlPSRange = xlOutSheet.Columns("FV:MS")
    '                xlPSRange.Delete(Shift:=Excel.XlDeleteShiftDirection.xlShiftToLeft)
    '                entryRange = xlOutSheet.Columns("CX:DL")
    '                entryRange.Hidden = True
    '            Case 6
    '                xlOutSheet.Range("MS1").Copy(xlOutSheet.Range("GG1"))
    '                xlPSRange = xlOutSheet.Columns("GH:MS")
    '                xlPSRange.Delete(Shift:=Excel.XlDeleteShiftDirection.xlShiftToLeft)
    '                entryRange = xlOutSheet.Columns("CY:DL")
    '                entryRange.Hidden = True
    '            Case 7
    '                xlOutSheet.Range("MS1").Copy(xlOutSheet.Range("GS1"))
    '                xlPSRange = xlOutSheet.Columns("GT:MS")
    '                xlPSRange.Delete(Shift:=Excel.XlDeleteShiftDirection.xlShiftToLeft)
    '                entryRange = xlOutSheet.Columns("CZ:DL")
    '                entryRange.Hidden = True
    '            Case 8
    '                xlOutSheet.Range("MS1").Copy(xlOutSheet.Range("HE1"))
    '                xlPSRange = xlOutSheet.Columns("HF:MS")
    '                xlPSRange.Delete(Shift:=Excel.XlDeleteShiftDirection.xlShiftToLeft)
    '                entryRange = xlOutSheet.Columns("DA:DL")
    '                entryRange.Hidden = True
    '            Case 9
    '                xlOutSheet.Range("MS1").Copy(xlOutSheet.Range("HQ1"))
    '                xlPSRange = xlOutSheet.Columns("HR:MS")
    '                xlPSRange.Delete(Shift:=Excel.XlDeleteShiftDirection.xlShiftToLeft)
    '                entryRange = xlOutSheet.Columns("DB:DL")
    '                entryRange.Hidden = True
    '            Case 10
    '                xlOutSheet.Range("MS1").Copy(xlOutSheet.Range("IC1"))
    '                xlPSRange = xlOutSheet.Columns("ID:MS")
    '                xlPSRange.Delete(Shift:=Excel.XlDeleteShiftDirection.xlShiftToLeft)
    '                entryRange = xlOutSheet.Columns("DC:DL")
    '                entryRange.Hidden = True
    '            Case 11
    '                xlOutSheet.Range("MS1").Copy(xlOutSheet.Range("IO1"))
    '                xlPSRange = xlOutSheet.Columns("IP:MS")
    '                xlPSRange.Delete(Shift:=Excel.XlDeleteShiftDirection.xlShiftToLeft)
    '                entryRange = xlOutSheet.Columns("DD:DL")
    '                entryRange.Hidden = True
    '            Case 12
    '                xlOutSheet.Range("MS1").Copy(xlOutSheet.Range("JA1"))
    '                xlPSRange = xlOutSheet.Columns("JB:MS")
    '                xlPSRange.Delete(Shift:=Excel.XlDeleteShiftDirection.xlShiftToLeft)
    '                entryRange = xlOutSheet.Columns("DE:DL")
    '                entryRange.Hidden = True
    '            Case 13
    '                xlOutSheet.Range("MS1").Copy(xlOutSheet.Range("JM1"))
    '                xlPSRange = xlOutSheet.Columns("JN:MS")
    '                xlPSRange.Delete(Shift:=Excel.XlDeleteShiftDirection.xlShiftToLeft)
    '                entryRange = xlOutSheet.Columns("DF:DL")
    '                entryRange.Hidden = True
    '            Case 14
    '                xlOutSheet.Range("MS1").Copy(xlOutSheet.Range("JY1"))
    '                xlPSRange = xlOutSheet.Columns("JZ:MS")
    '                xlPSRange.Delete(Shift:=Excel.XlDeleteShiftDirection.xlShiftToLeft)
    '                entryRange = xlOutSheet.Columns("DG:DL")
    '                entryRange.Hidden = True
    '            Case 15
    '                xlOutSheet.Range("MS1").Copy(xlOutSheet.Range("KK1"))
    '                xlPSRange = xlOutSheet.Columns("KL:MS")
    '                xlPSRange.Delete(Shift:=Excel.XlDeleteShiftDirection.xlShiftToLeft)
    '                entryRange = xlOutSheet.Columns("DH:DL")
    '                entryRange.Hidden = True
    '            Case 16
    '                xlOutSheet.Range("MS1").Copy(xlOutSheet.Range("KW1"))
    '                xlPSRange = xlOutSheet.Columns("KX:MS")
    '                xlPSRange.Delete(Shift:=Excel.XlDeleteShiftDirection.xlShiftToLeft)
    '                entryRange = xlOutSheet.Columns("DI:DL")
    '                entryRange.Hidden = True
    '            Case 17
    '                xlOutSheet.Range("MS1").Copy(xlOutSheet.Range("LI1"))
    '                xlPSRange = xlOutSheet.Columns("LJ:MS")
    '                xlPSRange.Delete(Shift:=Excel.XlDeleteShiftDirection.xlShiftToLeft)
    '                entryRange = xlOutSheet.Columns("DJ:DL")
    '                entryRange.Hidden = True
    '            Case 18
    '                xlOutSheet.Range("MS1").Copy(xlOutSheet.Range("LU1"))
    '                xlPSRange = xlOutSheet.Columns("LV:MS")
    '                xlPSRange.Delete(Shift:=Excel.XlDeleteShiftDirection.xlShiftToLeft)
    '                entryRange = xlOutSheet.Columns("DK:DL")
    '                entryRange.Hidden = True
    '            Case 19
    '                xlOutSheet.Range("MS1").Copy(xlOutSheet.Range("MG1"))
    '                xlPSRange = xlOutSheet.Columns("MH:MS")
    '                xlPSRange.Delete(Shift:=Excel.XlDeleteShiftDirection.xlShiftToLeft)
    '                entryRange = xlOutSheet.Columns("DL:DL")
    '                entryRange.Hidden = True
    '        End Select

    '        ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
    '        ExcelObjRelease.ReleaseExcelObj(xlfilerSheet, ExcelObjRelease.OBJECT_NOTHING)
    '        GC.Collect()

    '        'シート保護
    '        If blnSheetLock = True Then
    '            xlOutSheet = xlOutBook.Worksheets(OutSheetNM)
    '            If cmbValue = CmbValue_SumPayment_OutPutIOC Then
    '                Call ProtectSheet(xlOutSheet, CommonVariable.SummaryPW)
    '            Else
    '                Call ProtectSheet(xlOutSheet, CommonVariable.PaymentPW)
    '            End If
    '        End If
    '        ExcelObjRelease.ReleaseExcelObj(xlOutSheet, ExcelObjRelease.OBJECT_NOTHING)
    '        GC.Collect()

    '        ''                      以下、Book保存
    '        ''------------------------------------------------------------------
    '        ''App設定
    '        'START 変更管理#3?（ExcelのEventEnable対応)　2017/01 sugo
    '        'xlApp.EnableEvents = True
    '        'xlApp.ScreenUpdating = True
    '        'END   変更管理#3?（ExcelのEventEnable対応)　2017/01 sugo
    '        xlApp.Calculation = Excel.XlCalculation.xlCalculationAutomatic

    '        outFilePath = ""
    '        Select Case cmbValue
    '            Case Me.CmbValue_SumPayment_OutPutIOC
    '                Call xlOutBook.Save()

    '            Case Me.CmbValue_SumPayment_OutPutOth
    '                outFilePath = ofm.GetLocalOutputCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO) & _
    '                              ofm.GetSumPaymentExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO, createTime, blnSheetLock)
    '                outFilePath = outFilePath.Replace("__", "_")
    '                Call xlOutBook.SaveAs(Filename:=outFilePath, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

    '        End Select

    '    Catch ex As Exception
    '    Finally
    '        'START 変更管理#3?（ExcelのEventEnable対応)　2017/01 sugo
    '        'xlApp.EnableEvents = True
    '        'xlApp.DisplayAlerts = False
    '        'END   変更管理#3?（ExcelのEventEnable対応)　2017/01 sugo
    '        xlApp.ScreenUpdating = True
    '        xlApp.Calculation = Excel.XlCalculation.xlCalculationAutomatic
    '        ExcelObjRelease.ReleaseExcelObj(xlName, ExcelObjRelease.OBJECT_NOTHING)
    '        ExcelObjRelease.ReleaseExcelObj(xlCopyCell, ExcelObjRelease.OBJECT_NOTHING)
    '        ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
    '        ExcelObjRelease.ReleaseExcelObj(xlOutSheet, ExcelObjRelease.OBJECT_NOTHING)
    '        ExcelObjRelease.ReleaseExcelObj(xlPasteSheet, ExcelObjRelease.OBJECT_NOTHING)
    '        ExcelObjRelease.ReleaseExcelObj(xlCopySheet, ExcelObjRelease.OBJECT_NOTHING)
    '        ExcelObjRelease.ReleaseExcelObj(xlOBAMASheet, ExcelObjRelease.OBJECT_NOTHING)
    '        ExcelObjRelease.ReleaseExcelObj(xlfilerSheet, ExcelObjRelease.OBJECT_NOTHING)
    '        'START 変更管理#3?（ExcelのEventEnable対応)　2017/01 sugo
    '        'xlApp.DisplayAlerts = False
    '        'END   変更管理#3?（ExcelのEventEnable対応)　2017/01 sugo
    '        If IsNothing(xlOutBook) = False Then
    '            xlOutBook.Close()
    '        End If
    '        ExcelObjRelease.ReleaseExcelObj(xlOutBook, ExcelObjRelease.OBJECT_NOTHING)
    '        'START 変更管理#3?（ExcelのEventEnable対応)　2017/01 sugo
    '        'xlApp.DisplayAlerts = False
    '        'END   変更管理#3?（ExcelのEventEnable対応)　2017/01 sugo
    '        If IsNothing(xlCopyBook) = False Then
    '            xlCopyBook.Close()
    '        End If
    '        ExcelObjRelease.ReleaseExcelObj(xlCopyBook, ExcelObjRelease.OBJECT_NOTHING)
    '        'START 変更管理#3?（ExcelのEventEnable対応)　2017/01 sugo
    '        'xlApp.DisplayAlerts = False
    '        'END   変更管理#3?（ExcelのEventEnable対応)　2017/01 sugo
    '        If IsNothing(xlPSBook) = False Then
    '            xlPSBook.Close()
    '        End If
    '        ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
    '        ExcelObjRelease.ReleaseExcelObj(xlBooks, ExcelObjRelease.OBJECT_NOTHING)
    '        'START 変更管理#3?（ExcelのEventEnable対応)　2017/01 sugo
    '        xlApp.EnableEvents = True
    '        'END   変更管理#3?（ExcelのEventEnable対応)　2017/01 sugo
    '        xlApp.DisplayAlerts = True
    '        If IsNothing(xlApp) = False Then
    '            xlApp.Quit()
    '        End If
    '        ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

    '        GC.Collect()

    '    End Try

    'End Sub
    'END   変更管理#3?（Excel.exeの解放対応)　2017/01 sugo

    ''' <summary>
    ''' 機能：コスト削除ファイル作成
    ''' </summary>
    ''' <param name="strSrcFileName">コピー元ファイル名（フルパス）</param>
    ''' <param name="strOutFile">出力区分</param>
    ''' <param name="blnChk">チェックボックス区分</param>
    ''' <param name="strJoinPayment">統合Paymentのファイル名</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CreateDeleteCostFile(ByVal strSrcFileName() As String, _
                                          ByVal strOutFile As String, _
                                          ByVal blnChk() As Boolean, _
                                          ByVal blnSheetLock As Boolean, _
                                          Optional ByVal strJoinPayment As String = "") As Boolean

        Dim intCnt As Integer
        Dim strDelFileName As String
        Dim xlApp As New Excel.Application
        Dim xlBooks As Excel.Workbooks = Nothing
        Dim xlBook As Excel.Workbook
        Dim xlSheets As Excel.Sheets = Nothing
        Dim xlSheet As Excel.Worksheet = Nothing
        Dim arrRange As New ArrayList

        CreateDeleteCostFile = False

        Try
            ''Excelアプリケーションの設定
            xlApp.DisplayAlerts = False
            xlApp.EnableEvents = False
            xlApp.AskToUpdateLinks = False          ''自動更新リンクの警告メッセージを無効化する。

            For intCnt = 0 To 2
                If blnChk(intCnt) = True Then
                    '元となるファイルをコピーする
                    strDelFileName = Path.GetDirectoryName(strSrcFileName(intCnt)) & "\【COST削除】_" & Path.GetFileName(strSrcFileName(intCnt))
                    File.Copy(strSrcFileName(intCnt), strDelFileName)

                    ''BookOpen
                    xlBooks = xlApp.Workbooks
                    xlBook = xlBooks.Open(strDelFileName)
                    xlSheets = xlBook.Worksheets

                    arrRange.Clear()
                    Select Case strOutFile
                        Case OUTPUT_TYOUHYOUNAME_KAKAKUSYOUNINN
                            If blnChk(intCnt) = True Then
                                ''価格承認サマリーシートの処理（罫線も引き直す）
                                arrRange.Add(SHEET_NAME_DETAIL & "," & EXCEL_PAYMENTLINEDATE_OUTROW.ToString & ",W@1:Z@2")
                                arrRange.Add(SHEET_NAME_SUMMARY & "," & EXCEL_SUMMARY_ROW.ToString & ",J@1:J@2")
                                arrRange.Add(SHEET_NAME_JOIN_PAYMENT & "," & EXCEL_PAYMENTLINEDATE_OUTROW.ToString & ",CG@1:CJ@2,CN@1:CN@2")
                                If intCnt = IDX_CHK_BOX1 Then
                                    xlSheet = xlSheets.Item(SHEET_NAME_PRICE_SUMMARY)
                                    Call DelCostRowPriceSummarySheet(xlSheet, blnSheetLock)
                                    ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

                                    'コスト削除
                                    'シート名,開始行,削除範囲１,削除範囲２,・・・
                                    arrRange.Add(SHEET_NAME_IOC_SUMMARY & "," & EXCEL_PAYMENTLINEDATE_OUTROW.ToString & ",CD@1:CG@2,CK@1:CK@2")
                                    Call DeleteCostData(xlSheets, arrRange, CommonVariable.SummaryPW, blnSheetLock)

                                    '別ファイルで出力された統合PaymentのCOST削除
                                    If strJoinPayment <> "" Then
                                        strDelFileName = Path.GetDirectoryName(strJoinPayment) & "\【COST削除】_" & Path.GetFileName(strJoinPayment)
                                        File.Copy(strJoinPayment, strDelFileName)
                                        Dim xlJoinPsBook As Excel.Workbook
                                        Dim xlJoinPsSheets As Excel.Sheets = Nothing
                                        xlJoinPsBook = xlBooks.Open(strDelFileName)
                                        xlJoinPsSheets = xlJoinPsBook.Worksheets
                                        arrRange.Clear()
                                        arrRange.Add(SHEET_NAME_JOIN_PAYMENT & "," & EXCEL_PAYMENTLINEDATE_OUTROW.ToString & ",CG@1:CJ@2,CN@1:CN@2")
                                        Call DeleteCostData(xlJoinPsSheets, arrRange, CommonVariable.PaymentPW, blnSheetLock)
                                        xlJoinPsBook.Save()
                                        ExcelObjRelease.ReleaseExcelObj(xlJoinPsSheets, ExcelObjRelease.OBJECT_NOTHING)
                                        If IsNothing(xlJoinPsBook) = False Then
                                            xlJoinPsBook.Close(False)
                                        End If
                                        ExcelObjRelease.ReleaseExcelObj(xlJoinPsBook, ExcelObjRelease.OBJECT_NOTHING)
                                    End If
                                End If
                            End If

                        Case OUTPUT_TYOUHYOUNAME_PAYMENTCOC
                            arrRange.Add(SHEET_NAME_DETAIL & "," & EXCEL_PAYMENTLINEDATE_OUTROW.ToString & ",W@1:Z@2")
                            arrRange.Add(SHEET_NAME_SUMMARY & "," & EXCEL_SUMMARY_ROW.ToString & ",J@1:J@2")
                            arrRange.Add("STG," & EXCEL_PAYMENTLINEDATE_OUTROW.ToString & ",CD@1:CG@2,CK@1:CK@2")
                            arrRange.Add("SWG," & EXCEL_PAYMENTLINEDATE_OUTROW.ToString & ",CD@1:CG@2,CK@1:CK@2")
                            arrRange.Add("GTS," & EXCEL_PAYMENTLINEDATE_OUTROW.ToString & ",CD@1:CG@2,CK@1:CK@2")
                            arrRange.Add("GBS," & EXCEL_PAYMENTLINEDATE_OUTROW.ToString & ",CD@1:CG@2,CK@1:CK@2")
                            arrRange.Add("IGF," & EXCEL_PAYMENTLINEDATE_OUTROW.ToString & ",CD@1:CG@2,CK@1:CK@2")
                            arrRange.Add("VLS," & EXCEL_PAYMENTLINEDATE_OUTROW.ToString & ",CD@1:CG@2,CK@1:CK@2")
                            arrRange.Add("Other," & EXCEL_PAYMENTLINEDATE_OUTROW.ToString & ",CD@1:CG@2,CK@1:CK@2")
                            arrRange.Add("請求統合," & EXCEL_PAYMENTLINEDATE_OUTROW.ToString & ",CD@1:CG@2,CK@1:CK@2")
                            '統合PaymentSheet　IOC月次展開集計
                            If intCnt = IDX_CHK_BOX1 Then
                                arrRange.Add(SHEET_NAME_IOC_SUMMARY & "," & EXCEL_PAYMENTLINEDATE_OUTROW.ToString & ",CD@1:CG@2,CK@1:CK@2")
                                Call DeleteCostData(xlSheets, arrRange, CommonVariable.PaymentPW, blnSheetLock)
                            End If
                            '統合PaymentSheet　COC月次展開集計
                            If intCnt = IDX_CHK_BOX2 Then
                                arrRange.Add(SHEET_NAME_COC_SUMMARY & "," & EXCEL_PAYMENTLINEDATE_OUTROW.ToString & ",CD@1:CG@2,CL@1:CL@2")
                                Call DeleteCostData(xlSheets, arrRange, CommonVariable.PaymentPW, blnSheetLock)
                            End If
                            '統合PaymentSheet　COC/IOC差分作成
                            If intCnt = IDX_CHK_BOX3 Then
                                arrRange.Add(SHEET_NAME_COCIOC_SUMMARY & "," & EXCEL_PAYMENTLINEDATE_OUTROW.ToString & ",CD@1:CG@2,CL@1:CL@2")
                                Call DeleteCostData(xlSheets, arrRange, CommonVariable.PaymentPW, blnSheetLock)
                            End If
                        Case OUTPUT_TYOUHYOUNAME_SEUKYU
                            arrRange.Add(SHEET_NAME_DETAIL & "," & EXCEL_PAYMENTLINEDATE_OUTROW.ToString & ",W@1:Z@2")
                            arrRange.Add(SHEET_NAME_SUMMARY & "," & EXCEL_SUMMARY_ROW.ToString & ",J@1:J@2")
                            Call DeleteCostData(xlSheets, arrRange, CommonVariable.PaymentPW, blnSheetLock)
                        Case OUTPUT_TYOUHYOUNAME_PROJECTIOC
                            arrRange.Add(SHEET_NAME_IOC_P_SUMMARY & "," & EXCEL_PAYMENTLINEDATE_OUTROW.ToString & ",CD@1:CG@2,CK@1:CK@2")
                            arrRange.Add("L01案件," & EXCEL_PAYMENTLINEDATE_OUTROW.ToString & ",CD@1:CG@2,CK@1:CK@2")
                            arrRange.Add("L02案件," & EXCEL_PAYMENTLINEDATE_OUTROW.ToString & ",CD@1:CG@2,CK@1:CK@2")
                            arrRange.Add("L03案件," & EXCEL_PAYMENTLINEDATE_OUTROW.ToString & ",CD@1:CG@2,CK@1:CK@2")
                            arrRange.Add("L04案件," & EXCEL_PAYMENTLINEDATE_OUTROW.ToString & ",CD@1:CG@2,CK@1:CK@2")
                            Call DeleteCostData(xlSheets, arrRange, CommonVariable.PaymentPW, blnSheetLock)
                    End Select

                    ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)
                    xlBook.Save()
                    If IsNothing(xlBook) = False Then
                        xlBook.Close(False)
                    End If
                    ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)
                    ExcelObjRelease.ReleaseExcelObj(xlBooks, ExcelObjRelease.OBJECT_NOTHING)
                End If
            Next

            CreateDeleteCostFile = True

        Catch ex As Exception
            Throw ex

        Finally
            ''Excelアプリケーションの設定を戻す
            xlApp.DisplayAlerts = True
            xlApp.EnableEvents = True

            ''オブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBook) = False Then
                xlBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlBooks, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Function

    Private Sub DeleteCostData(ByVal xlSheets As Excel.Sheets, ByVal arrItem As ArrayList, ByVal excelPW As String, ByVal blnSheetLock As Boolean)

        Dim xlSheet As Excel.Worksheet = Nothing
        Dim xlRange As Excel.Range = Nothing
        Dim strWork As String
        Dim intSheetCnt As Integer
        Dim intRangeCnt As Integer
        Dim strRange() As String
        Dim blnRet As Boolean
        Dim xlUsedCell As Excel.Range

        Try
            For intSheetCnt = 0 To (arrItem.Count - 1)
                strRange = arrItem(intSheetCnt).Split(",")
                For intRangeCnt = 2 To (strRange.Length - 1)
                    blnRet = isSheet(xlSheets, strRange(0))
                    If blnRet = True Then
                        xlSheet = xlSheets.Item(strRange(0))
                        strWork = strRange(intRangeCnt).Replace("@1", strRange(1))
                        xlUsedCell = xlSheet.UsedRange
                        strWork = strWork.Replace("@2", Split(xlUsedCell.Address, "$")(4))
                        ExcelObjRelease.ReleaseExcelObj(xlUsedCell, ExcelObjRelease.OBJECT_NOTHING)
                        xlSheet.Unprotect(excelPW)
                        xlRange = xlSheet.Range(strWork)
                        xlRange.Value = ""
                        ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                        If blnSheetLock = True Then
                            Call ProtectSheet(xlSheet, excelPW)
                        End If
                    End If
                Next
                ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            Next

        Catch ex As Exception
            Throw ex

        Finally
            ''オブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlUsedCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub

    Private Function isSheet(ByVal xlSheets As Excel.Sheets, ByVal strSheetName As String) As Boolean

        Dim xlSheet As Excel.Worksheet = Nothing

        isSheet = False

        Try
            For Each xlSheet In xlSheets
                If xlSheet.Name = strSheetName Then
                    isSheet = True
                End If
            Next

        Catch ex As Exception
            Throw ex

        Finally
            ''オブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try

    End Function

    Private Function CreateOutputFileName(ByVal strOutputPath As String,
                                          ByVal strCreateTime As String,
                                          ByVal strAddName As String,
                                          Optional ByVal intDiv As Integer = 1,
                                          Optional ByVal intMaxDiv As Integer = 1) As String
        Dim strDivision As String = ""

        CreateOutputFileName = ""

        Try
            '分割用文言
            If intMaxDiv <> 1 Then
                strDivision = "_" & intDiv.ToString & "_" & intMaxDiv.ToString
            End If

            CreateOutputFileName = strOutputPath & "\" & _
                                    CommonVariable.CPNO & _
                                    "_" & _
                                    CommonVariable.CONTRACTNO.ToString.PadLeft(3, "0"c) & _
                                    strAddName & _
                                    strDivision & _
                                    strCreateTime & _
                                    ".xlsm"

        Catch ex As Exception
            Throw ex

        End Try

    End Function

    Private Sub DispPSTextBox()

        Dim ofm As New OioFileManage
        Dim PSPath As String
        PSPath = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, _
                                        CommonVariable.CONTRACTNO) & _
                  ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, _
                                                CommonVariable.CONTRACTNO)
        ''ファイルが存在する場合のみ表示
        If File.Exists(PSPath) = True Then
            Me.txb_InputFile.Text = PSPath
        Else
            Me.txb_InputFile.Text = ""
        End If
    End Sub


    ''' <summary>
    ''' 機能：契約履歴ﾌｧｲﾙ出力Main
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function ConListExcelOutput(ByVal outFolder As String, _
                                        ByRef WaitDialog As Frm_WaitDialog) As String

        ''初期化
        ConListExcelOutput = ""
        Try
            '--------------------------------------------------
            'データをMDBにセット
            '--------------------------------------------------
            Call SetMdbOutConList()

            '--------------------------------------------------
            '出力対象ﾃﾞｰﾀ取得
            '--------------------------------------------------
            Dim ConListPt1Pt2 As New DataTable
            Dim ConListPT3Year1 As New DataTable
            Dim ConListPT3Year2 As New DataTable
            Dim ConListPT3Month1 As New DataTable
            Dim ConListPT3Month2 As New DataTable
            Call GetOutConListDate(ConListPt1Pt2,
                                   ConListPT3Year1,
                                   ConListPT3Year2,
                                   ConListPT3Month1,
                                   ConListPT3Month2)

            ''0件は出力しない。
            If ConListPt1Pt2.Rows.Count = 0 Then
                Throw New Exception(FileReader.GetMessage("MSG_0414"))
            End If

            ''関連No更新
            Call UpdConListTblRefNo(ConListPt1Pt2)

            ''BaseNo更新
            Call UpdConListTblBaseNo(ConListPt1Pt2)

            ''確認項目更新
            Call UpdConListTblChkItem(ConListPt1Pt2, ConListPT3Month1, ConListPT3Month2)

            ''契約履歴ﾁｪｯｸﾘｽﾄ出力
            Call OutConListExcelFile(outFolder,
                                     ConListPt1Pt2,
                                     ConListPT3Year1,
                                     ConListPT3Year2,
                                     ConListPT3Month1,
                                     ConListPT3Month2)

            ''戻り値
            Return "契約履歴ﾁｪｯｸﾘｽﾄ"

        Catch ex As Exception
            Throw ex

        End Try

    End Function


    ''' <summary>
    ''' 機能：契約履歴ﾌｧｲﾙ出力用TBLの定義を作成
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateConListTBL() As DataTable

        Dim rtnTBL As New DataTable
        CreateConListTBL = rtnTBL

        For idx As Integer = ExcelWrite.MdbPaymentLineColumn.UPDATE_FLAG To _
                             ExcelWrite.MdbPaymentLineColumn.PRICE_YEAR12_MONTH12
            rtnTBL.Columns.Add("CellNM" & idx, Type.GetType("System.String"))
        Next

        ''PSに存在しない項目を追加
        rtnTBL.Columns.Add(ChkList_ColumnNM_ID, Type.GetType("System.String"))
        rtnTBL.Columns.Add(ChkList_ColumnNM_Item10No, Type.GetType("System.String"))
        rtnTBL.Columns.Add(ChkList_ColumnNM_BaseNo, Type.GetType("System.String"))
        rtnTBL.Columns.Add(ChkList_ColumnNM_RefNo, Type.GetType("System.String"))
        rtnTBL.Columns.Add(ChkList_ColumnNM_CheckItem, Type.GetType("System.String"))
        rtnTBL.Columns.Add(ChkList_ColumnNM_FileKB, Type.GetType("System.String"))

        rtnTBL.Columns(ChkList_ColumnNM_ID).DefaultValue = ""
        rtnTBL.Columns(ChkList_ColumnNM_Item10No).DefaultValue = ""
        rtnTBL.Columns(ChkList_ColumnNM_BaseNo).DefaultValue = ""
        rtnTBL.Columns(ChkList_ColumnNM_RefNo).DefaultValue = ""
        rtnTBL.Columns(ChkList_ColumnNM_CheckItem).DefaultValue = ""

        Return rtnTBL

    End Function

    ''' <summary>
    ''' 機能：契約履歴ﾌｧｲﾙ出力用TBLの関連Noを更新
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub UpdConListTblRefNo(ByRef rtnTBL As DataTable)

        Dim updRow As DataRow
        Dim refNo As String
        Dim item10 As String
        Dim item10No As String
        For Each updRow In rtnTBL.Rows
            Application.DoEvents()              ''応答なし対応
            ''削除元 = xxxの場合、xxxx/それ以外はLineNoをセット
            item10 = ExcelWrite.changeDBNullToString(updRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10))
            item10No = ExcelWrite.changeDBNullToString(updRow.Item(ChkList_ColumnNM_Item10No))
            If item10.IndexOf(ProdItem10_Value_DelNo) <> -1 And _
               item10No <> "" Then
                refNo = updRow.Item(ChkList_ColumnNM_Item10No)
            Else
                refNo = ExcelWrite.changeDBNullToString(updRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO)).PadLeft(10, "0")
            End If
            updRow.Item(ChkList_ColumnNM_RefNo) = refNo
        Next

    End Sub


    ''' <summary>
    ''' 機能：契約履歴ﾌｧｲﾙ出力用TBLのBaseNoを更新
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub UpdConListTblBaseNo(ByRef rtnTBL As DataTable)

        Dim isBaseRow As Boolean
        Dim lineNo As String
        Dim item10No As String
        Dim row As DataRow
        Dim baseRow As DataRow
        Dim allRows() As DataRow

        allRows = rtnTBL.Select("")
        For i As Integer = 0 To allRows.Length - 1
            Application.DoEvents()              ''応答なし対応
            isBaseRow = False
            row = allRows(i)
            item10No = ExcelWrite.changeDBNullToString(row.Item(ChkList_ColumnNM_Item10No)).Trim
            lineNo = ExcelWrite.changeDBNullToString(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO))

            ''親のレコードが存在するか判定 ※Copy元xxxx/削除元yyyyの値
            If item10No = "" Then
                isBaseRow = False
            Else
                If ExistsCopyDelRow(rtnTBL, baseRow, item10No) = True AndAlso _
                   ChkConListTBLLoopRefNo(rtnTBL, baseRow, lineNo) = False Then
                    isBaseRow = True
                Else
                    isBaseRow = False
                End If
            End If

            ''親ﾚｺｰﾄﾞが存在すれば、親ﾚｺｰﾄﾞの値で更新する。
            If isBaseRow = True Then
                If baseRow.Item(ChkList_ColumnNM_BaseNo) <> "" Then
                    row.Item(ChkList_ColumnNM_BaseNo) = baseRow.Item(ChkList_ColumnNM_BaseNo)
                Else
                    row.Item(ChkList_ColumnNM_BaseNo) = baseRow.Item("CellNM" & ConListColumn.LINE_NO - 1)
                End If
            Else
                row.Item(ChkList_ColumnNM_BaseNo) = lineNo
            End If
            Call UpdConListTBLOtherBaseNo(rtnTBL, lineNo, row.Item(ChkList_ColumnNM_BaseNo))
        Next

    End Sub


    ''' <summary>
    ''' 機能：削除元No/Copy元Noの参照元ﾚｺｰﾄﾞの判定
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function ExistsCopyDelRow(ByRef rtnTBL As DataTable, _
                                      ByRef baseRow As DataRow, _
                                      ByVal item10No As String) As Boolean

        ''初期化
        ExistsCopyDelRow = False

        ''Copy/削除元 = xxxxのレコードを検索
        Dim rows() As DataRow
        Dim Sql As New StringBuilder
        Sql.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO)
        Sql.Append(CommonConstant.SQL_STR_EQUAL)
        Sql.Append(StringEdit.EncloseSingleQuotation(item10No))

        rows = rtnTBL.Select(Sql.ToString)
        If rows.Length > 0 Then
            baseRow = rows(0)
            Return True
        Else
            Return False
        End If

    End Function


    ''' <summary>
    ''' 機能：削除元No/Copy元Noの無限ループを判定
    ''' 説明：※Copy元 10 ⇒20 ⇒30⇒10 を判定
    ''' </summary>
    ''' <remarks></remarks>
    Private Function ChkConListTBLLoopRefNo(ByRef rtnTBL As DataTable, _
                                            ByRef baseRow As DataRow, _
                                            ByVal item10No As String) As Boolean
        ''初期化
        ChkConListTBLLoopRefNo = False

        ''Base番号取得
        Dim baseNo As String
        If ExcelWrite.changeDBNullToString(baseRow.Item(ChkList_ColumnNM_Item10No)) <> "" Then
            baseNo = ExcelWrite.changeDBNullToString(baseRow.Item(ChkList_ColumnNM_Item10No))
        Else
            Return False
        End If

        Dim Sql As New StringBuilder
        Sql.Append(ChkList_ColumnNM_BaseNo)
        Sql.Append(CommonConstant.SQL_STR_EQUAL)
        Sql.Append(StringEdit.EncloseSingleQuotation(baseNo))
        Sql.Append(CommonConstant.SQL_STR_AND)
        Sql.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO)
        Sql.Append(CommonConstant.SQL_STR_EQUAL)
        Sql.Append(StringEdit.EncloseSingleQuotation(item10No))

        If rtnTBL.Select(Sql.ToString).Length = 0 Then
            Return False
        Else
            Return True
        End If

    End Function


    ''' <summary>
    ''' 機能：BaseNoを更新する
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub UpdConListTBLOtherBaseNo(ByRef rtnTBL As DataTable, _
                                         ByVal lineNo As String, _
                                         ByVal baseNo As String)
        Dim Sql As New StringBuilder
        Sql.Append(ChkList_ColumnNM_BaseNo)
        Sql.Append(CommonConstant.SQL_STR_EQUAL)
        Sql.Append(StringEdit.EncloseSingleQuotation(lineNo))
        For Each updRow As DataRow In rtnTBL.Select(Sql.ToString)
            updRow.Item(ChkList_ColumnNM_BaseNo) = baseNo
        Next

    End Sub



    ''' <summary>
    ''' 機能：契約履歴のExcelFileを作成する。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub OutConListExcelFile(ByVal outFolder As String,
                                    ByRef dtTbl1Tbl2 As DataTable,
                                    ByRef dtTbl3Year1 As DataTable,
                                    ByRef dtTbl3Year2 As DataTable,
                                    ByRef dtTbl3Month1 As DataTable,
                                    ByRef dtTbl3Month2 As DataTable)

        Application.DoEvents()              ''応答なし対応
        Dim xlApp As New Excel.Application
        Dim xlConListBook As Excel.Workbook
        Dim xlListSheet As Excel.Worksheet
        Dim xlCell As Excel.Range
        Try
            ''ﾌｧｲﾙの作成
            Dim ofm As New OioFileManage
            Dim tmpPath As String
            Dim outPath As String
            tmpPath = ofm.GetLocalTemplateFolder & _
                      TmpConListFileNM
            outPath = outFolder & GetConListFileNM()
            Call File.Copy(tmpPath, outPath)

            ''Appの初期化
            xlApp.EnableEvents = False
            xlApp.DisplayAlerts = False

            ''ﾌｧｲﾙのOpen/Sheetセット
            xlConListBook = xlApp.Workbooks.Open(outPath)
            xlListSheet = xlConListBook.Worksheets(ConList_ChkSheetNM)

            ''ﾃﾝﾌﾟﾚ行のCopy&Paste
            Application.DoEvents()              ''応答なし対応
            Call CopyConListTmpRow(xlListSheet, dtTbl1Tbl2.Rows.Count)

            ''Excel出力用の配列作成
            Dim outArray(,) As Object
            Application.DoEvents()              ''応答なし対応
            outArray = GetConListWriteArray(xlListSheet,
                                            dtTbl1Tbl2,
                                            dtTbl3Year1,
                                            dtTbl3Year2,
                                            dtTbl3Month1,
                                            dtTbl3Month2)

            ''WS1ｼｰﾄの更新
            Dim crWs1 As New CreateWS1
            Dim blet As Boolean
            Call crWs1.WS1の作成(xlConListBook, CommonVariable.PaymentPeriod, CommonVariable.PaymentPW)

            ''変更履歴情報ｼｰﾄ更新
            Application.DoEvents()              ''応答なし対応
            Dim copyArea As String
            copyArea = "A@Str:MT@End".Replace("@Str", ConList_OutRow) _
                                     .Replace("@End", ConList_OutRow + dtTbl1Tbl2.Rows.Count - 1)
            xlCell = xlListSheet.Range(copyArea)
            xlCell.FormulaR1C1 = outArray

            '年額月額展開可変設定
            Call ExcelWrite.CreatePaymentPeriod(xlListSheet,
                                                ExcelWrite.chgExcelColumnIdxToChar(ConListColumn.PRICE_YEAR1_MONTH1),
                                                CommonVariable.PaymentPeriod)
            'A1にカーソル
            xlListSheet.Activate()
            xlCell = xlListSheet.Range("A1")
            xlCell.Select()
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlListSheet, ExcelObjRelease.OBJECT_NOTHING)

            ''BookのSave
            Call xlConListBook.Save()
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlListSheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlConListBook) = False Then
                Call xlConListBook.Close()
            End If

            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            ExcelObjRelease.ReleaseExcelObj(xlConListBook, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlApp) = False Then
                Call xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try
    End Sub


    ''' <summary>
    ''' 機能：契約履歴のファイル名を取得
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetConListFileNM()

        ''定数
        Const BaseFileNM As String = "@CPNO(@CPNAME)_変更履歴リスト_@yyyyMMdd_HHmmss.xlsm"

        ''初期化
        Dim rtnValue As String
        rtnValue = ""
        GetConListFileNM = rtnValue

        ''ファイル名取得
        rtnValue = BaseFileNM.Replace("@CPNO", CommonVariable.CPNO) _
                             .Replace("@CPNAME", CommonVariable.CUSTOMERNAME) _
                             .Replace("@yyyyMMdd_HHmmss", Now.ToString("yyyyMMdd_HHmmss"))

        Return rtnValue

    End Function

    ''' <summary>
    ''' 機能：削除ﾃﾞｰﾀﾁｪｯｸﾘｽﾄのファイル名を取得
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetDelListFileNM()

        ''定数
        Const BaseFileNM As String = "@CPNO_@契約順番_削除ﾃﾞｰﾀﾁｪｯｸﾘｽﾄ_@yyyyMMdd_HHmmss.xlsm"

        ''初期化
        Dim rtnValue As String
        rtnValue = ""
        GetDelListFileNM = rtnValue

        ''ファイル名取得
        rtnValue = BaseFileNM.Replace("@CPNO", CommonVariable.CPNO) _
                             .Replace("@契約順番", CommonVariable.CONTRACTNO.ToString.PadLeft(3, "0")) _
                             .Replace("@yyyyMMdd_HHmmss", Now.ToString("yyyyMMdd_HHmmss"))

        Return rtnValue

    End Function

    ''' <summary>
    ''' 機能：ﾃﾝﾌﾟﾚ行をコピペする
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub CopyConListTmpRow(ByRef xlListSheet As Excel.Worksheet, _
                                  ByVal rowCount As Integer)

        Dim copyCell As Excel.Range
        Dim pasteCell As Excel.Range
        Dim idxStr As Integer                ''Copy開始位置
        Dim idxEnd As Integer              ''Copy終了位置
        Dim copyArea As String               ''Copy範囲
        Dim copyCount As Integer            ''Copy回数
        Try

            ''Copy回数取得
            If CopyRowCount >= rowCount Then
                copyCount = 1
            Else
                copyCount = Math.Truncate((rowCount - 1) / CopyRowCount) + 1
            End If

            ''回数分コピー & Paste
            copyCell = xlListSheet.Rows(ConList_TmpRow)
            copyCell.Hidden = False
            Call copyCell.Copy()
            For i As Integer = 1 To copyCount
                idxStr = ConList_OutRow + (CopyRowCount * (i - 1))
                If i = copyCount Then
                    idxEnd = idxStr + (rowCount Mod CopyRowCount) - 1
                Else
                    idxEnd = idxStr + CopyRowCount - 1
                End If
                copyArea = "@Str:@End".Replace("@Str", idxStr) _
                                      .Replace("@End", idxEnd)
                pasteCell = xlListSheet.Rows(copyArea)
                Call pasteCell.PasteSpecial()
            Next
            copyCell.Hidden = True

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(copyCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(pasteCell, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' 機能：削除妥当性チェックリストの配列値を取得
    ''' 説明：※値をセット
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetDelListWriteArray(ByRef xlListSheet As Excel.Worksheet, _
                                          ByRef dtTbl1Tbl2 As DataTable,
                                          ByRef dtTbl3Year1 As DataTable,
                                          ByRef dtTbl3Year2 As DataTable,
                                          ByRef dtTbl3Month1 As DataTable,
                                          ByRef dtTbl3Month2 As DataTable) As Object(,)

        ''初期化
        GetDelListWriteArray = Nothing

        Dim i As Integer
        Dim xlCell As Excel.Range
        Dim rtnValue(,) As Object
        Dim formulaArray(,) As Object
        Dim filter As New StringBuilder

        Try
            '---------------------------------------------------------------------
            'Tmple行のExcel式を取得
            '---------------------------------------------------------------------
            xlCell = xlListSheet.Range(xlListSheet.Cells(ConList_TmpRow, DelListColumn.CheckItem), _
                                       xlListSheet.Cells(ConList_TmpRow, DelListColumn.PRICE_YEAR20_MONTH12))
            formulaArray = xlCell.FormulaR1C1

            '---------------------------------------------------------------------
            '出力用配列作成
            '---------------------------------------------------------------------

            i = -1
            filter.Remove(0, filter.Length())
            filter.Append("Trim(" & ChkList_ColumnNM_CheckItem & ")")
            filter.Append(CommonConstant.SQL_STR_NOT_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(""))
            ReDim rtnValue(dtTbl1Tbl2.Select(filter.ToString, "BaseNo, RefNo").Length, DelListColumn.PRICE_YEAR20_MONTH12 - 1)
            For Each row As DataRow In dtTbl1Tbl2.Select(filter.ToString, "BaseNo, RefNo")
                'カウンタ
                i = i + 1

                '1行分の値（ヘッダ）
                Call SetDelListArrayHead(rtnValue, i, row)

                '1行分の値（dtTbl1Tbl2）
                Call SetDelListArrayValue(rtnValue,
                                          i,
                                          row,
                                          ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG,
                                          ExcelWrite.ExcelPaymentLineColumn.PRICE_DEFF_IGF)

                '関連ﾃｰﾌﾞﾙのﾌｨﾙﾀｰ作成
                Dim sbRelTbl As New StringBuilder
                sbRelTbl.Remove(0, sbRelTbl.Length())
                sbRelTbl.Append("ID")
                sbRelTbl.Append(CommonConstant.SQL_STR_EQUAL)
                sbRelTbl.Append(StringEdit.EncloseSingleQuotation(row.Item("ID").ToString))

                '1行分の値（dtTbl3Year1）
                Call SetDelListArrayValue(rtnValue,
                                          i,
                                          dtTbl3Year1.Select(sbRelTbl.ToString)(0),
                                          ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1,
                                          ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10)

                '1行分の値（dtTbl3Year2）
                Call SetDelListArrayValue(rtnValue,
                                          i,
                                          dtTbl3Year2.Select(sbRelTbl.ToString)(0),
                                          ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11,
                                          ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL)

                '1行分の値（dtTbl3Month1）
                Call SetDelListArrayValue(rtnValue,
                                          i,
                                          dtTbl3Month1.Select(sbRelTbl.ToString)(0),
                                          ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1,
                                          ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH12)

                '1行分の値（dtTbl3Month2）
                Call SetDelListArrayValue(rtnValue,
                                          i,
                                          dtTbl3Month2.Select(sbRelTbl.ToString)(0),
                                          ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH1,
                                          ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12)

                '1行分の式
                Call SetDelListArrayFormula(rtnValue, i, formulaArray)
            Next

            Return rtnValue

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try
    End Function

    ''' <summary>
    ''' 機能：削除妥当性チェックリスト1行分の配列値を取得
    ''' 説明：※値をセット
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetDelListArrayHead(ByRef rtnValue(,) As Object, _
                                    ByVal i As Integer, _
                                    ByRef row As DataRow)

        ''確認結果/BaseNo/関連No
        Select Case row.Item(ChkList_ColumnNM_CheckItem)
            Case ConList_ChkItem_RefNothing
                rtnValue(i, DelListColumn.CheckItem - 1) = "削除元ﾃﾞｰﾀがありません"
            Case ConList_ChkItem_FlgChk
                rtnValue(i, DelListColumn.CheckItem - 1) = "削除元ﾃﾞｰﾀとPayment種別のFLGが異なります"
            Case ConList_ChkItem_DowbleDel
                '変更管理#43 削除妥当性チェックファイルのコメント変更 Str
                rtnValue(i, DelListColumn.CheckItem - 1) = "【部分削除】削除元データに対し、削除行が重複して作成されているので、削除期間に重複がないか、履歴を確認して下さい"
                'rtnValue(i, DelListColumn.CheckItem - 1) = "削除元ﾃﾞｰﾀが過去に部分削除されているので、履歴を確認して下さい"
                '変更管理#43 削除妥当性チェックファイルのコメント変更 End
            Case ConList_ChkItem_ExistsPS
                rtnValue(i, DelListColumn.CheckItem - 1) = "Payment種別=" & """" & "D" & """" & "で相殺されていないPayment月が存在します"
        End Select
        rtnValue(i, DelListColumn.BaseNo - 1) = row.Item(ChkList_ColumnNM_BaseNo)
        rtnValue(i, DelListColumn.RefNo - 1) = row.Item(ChkList_ColumnNM_RefNo)

    End Sub

    Private Sub SetDelListArrayValue(ByRef rtnValue(,) As Object, _
                                     ByVal i As Integer, _
                                     ByRef row As DataRow,
                                     ByVal intColStart As Integer,
                                     ByVal intColEnd As Integer)

        '確認結果/BaseNo/関連No以外はLoopで取得
        For idx As Integer = intColStart To intColEnd
            rtnValue(i, idx + 1) = row.Item("CellNM" & idx)
        Next

    End Sub

    ''' <summary>
    ''' 機能：削除妥当性チェックリスト1行分の配列値を取得
    ''' 説明：※ﾃﾝﾌﾟﾚ行の式をセット
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetDelListArrayFormula(ByRef rtnValue(,) As Object, _
                                       ByVal i As Integer, _
                                       ByRef formulaArray(,) As Object)

        For Idx As Integer = 1 To UBound(formulaArray, 2)
            If formulaArray(1, Idx).IndexOf("=") <> -1 Then
                rtnValue(i, Idx - 1) = formulaArray(1, Idx)
            End If
        Next
    End Sub

    ''' <summary>
    ''' 機能：契約経歴リストの配列値を取得
    ''' 説明：※値をセット
    ''' </summary>
    ''' <param name="xlListSheet"></param>
    ''' <param name="dtTbl1Tbl2"></param>
    ''' <param name="dtTbl3Year1"></param>
    ''' <param name="dtTbl3Year2"></param>
    ''' <param name="dtTbl3Month1"></param>
    ''' <param name="dtTbl3Month2"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetConListWriteArray(ByRef xlListSheet As Excel.Worksheet, _
                                          ByRef dtTbl1Tbl2 As DataTable,
                                          ByRef dtTbl3Year1 As DataTable,
                                          ByRef dtTbl3Year2 As DataTable,
                                          ByRef dtTbl3Month1 As DataTable,
                                          ByRef dtTbl3Month2 As DataTable) As Object(,)

        ''初期化
        GetConListWriteArray = Nothing
        Dim i As Integer
        Dim xlCell As Excel.Range
        Dim rtnValue(,) As Object
        Dim formulaArray(,) As Object
        ReDim rtnValue(dtTbl1Tbl2.Rows.Count - 1, ConListColumn.PRICE_YEAR20_MONTH12 - 1)
        Try
            ''Tmple行のExcel式を取得
            xlCell = xlListSheet.Range(xlListSheet.Cells(ConList_TmpRow, ConListColumn.CheckItem), _
                                       xlListSheet.Cells(ConList_TmpRow, ConListColumn.PRICE_YEAR20_MONTH12))
            formulaArray = xlCell.FormulaR1C1

            ''出力用配列作成
            i = -1
            For Each row As DataRow In dtTbl1Tbl2.Select("", "BaseNo, RefNo")
                ''カウンタ
                i = i + 1

                '1行分の値（ヘッダ）
                Call SetConListArrayHead(rtnValue, i, row)

                '1行分の値（dtTbl1Tbl2）
                Call SetConListArrayValue(rtnValue,
                                          i,
                                          row,
                                          ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG,
                                          ExcelWrite.ExcelPaymentLineColumn.PRICE_DEFF_IGF)

                '関連ﾃｰﾌﾞﾙのﾌｨﾙﾀｰ作成
                Dim sbRelTbl As New StringBuilder
                sbRelTbl.Remove(0, sbRelTbl.Length())
                sbRelTbl.Append("ID")
                sbRelTbl.Append(CommonConstant.SQL_STR_EQUAL)
                sbRelTbl.Append(StringEdit.EncloseSingleQuotation(row.Item("ID").ToString))

                '1行分の値（dtTbl3Year1）
                Call SetConListArrayValue(rtnValue,
                                          i,
                                          dtTbl3Year1.Select(sbRelTbl.ToString)(0),
                                          ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1,
                                          ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10)

                '1行分の値（dtTbl3Year2）
                Call SetConListArrayValue(rtnValue,
                                          i,
                                          dtTbl3Year2.Select(sbRelTbl.ToString)(0),
                                          ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11,
                                          ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL)

                '1行分の値（dtTbl3Month1）
                Call SetConListArrayValue(rtnValue,
                                          i,
                                          dtTbl3Month1.Select(sbRelTbl.ToString)(0),
                                          ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1,
                                          ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH12)

                '1行分の値（dtTbl3Month2）
                Call SetConListArrayValue(rtnValue,
                                          i,
                                          dtTbl3Month2.Select(sbRelTbl.ToString)(0),
                                          ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH1,
                                          ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12)

                '1行分の式
                Call SetConListArrayFormula(rtnValue, i, formulaArray)
            Next
            Return rtnValue

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try
    End Function

    ''' <summary>
    ''' 機能：契約経歴リスト1行分の配列値を取得
    ''' 説明：※値をセット
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetConListArrayHead(ByRef rtnValue(,) As Object, _
                                    ByVal i As Integer, _
                                    ByRef row As DataRow)

        ''確認結果/BaseNo/関連No
        rtnValue(i, ConListColumn.CheckItem - 1) = row.Item(ChkList_ColumnNM_CheckItem)
        rtnValue(i, ConListColumn.BaseNo - 1) = row.Item(ChkList_ColumnNM_BaseNo)
        rtnValue(i, ConListColumn.RefNo - 1) = row.Item(ChkList_ColumnNM_RefNo)

    End Sub

    ''' <summary>
    ''' 機能：契約経歴リスト1行分の配列値を取得
    ''' 説明：※値（Paymetn）をセット
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetConListArrayValue(ByRef rtnValue(,) As Object,
                                     ByVal i As Integer,
                                     ByRef row As DataRow,
                                     ByVal intColStart As Integer,
                                     ByVal intColEnd As Integer)

        ''確認結果/BaseNo/関連No以外はLoopで取得
        For idx As Integer = intColStart To intColEnd
            rtnValue(i, idx) = row.Item("CellNM" & idx)
        Next

    End Sub

    ''' <summary>
    ''' 機能：契約経歴リスト1行分の配列値を取得
    ''' 説明：※ﾃﾝﾌﾟﾚ行の式をセット
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetConListArrayFormula(ByRef rtnValue(,) As Object, _
                                       ByVal i As Integer, _
                                       ByRef formulaArray(,) As Object)

        For Idx As Integer = 1 To UBound(formulaArray, 2)
            If formulaArray(1, Idx).IndexOf("=") <> -1 Then
                rtnValue(i, Idx - 1) = formulaArray(1, Idx)
            End If
        Next
    End Sub

    ''' <summary>
    ''' 機能：確認項目を更新する。
    ''' 説明：※各確認項目をチェックする関数を呼び出す。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub UpdConListTblChkItem(ByRef dtTbl1Tbl2 As DataTable,
                                     ByRef dtTbl3Month1 As DataTable,
                                     ByRef dtTbl3Month2 As DataTable)


        ''各条件に当てはまる値をセット        
        ''関連なし    
        Application.DoEvents()              ''応答なし対応
        Call ConListTblChkItemRefNothing(dtTbl1Tbl2)

        ''FLG確認
        Application.DoEvents()              ''応答なし対応
        Call ConListTblChkItemFlgChk(dtTbl1Tbl2)

        ''Payment有り/無し　※有効/無効Flg = D
        Application.DoEvents()              ''応答なし対応
        Call ConListTblChkItemDFlgMonthlyPrice(dtTbl1Tbl2, dtTbl3Month1, dtTbl3Month2)

        ''Payment有り/無し　※有効/無効Flg <> D
        Application.DoEvents()              ''応答なし対応
        Call ConListTblChkItemOthMonthlyPrice(dtTbl1Tbl2, dtTbl3Month1, dtTbl3Month2)

    End Sub

    ''' <summary>
    ''' 機能：確認項目を更新する。
    ''' 説明：※「関連ﾃﾞｰﾀ無し」
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub ConListTblChkItemRefNothing(ByRef rtnTBL As DataTable)

        Dim row As DataRow
        Dim searchRow() As DataRow
        Dim Sql As New StringBuilder
        For Each row In rtnTBL.Rows

            Sql.Length = 0
            Sql.Append(ChkList_ColumnNM_BaseNo)
            Sql.Append(CommonConstant.SQL_STR_EQUAL)
            Sql.Append(StringEdit.EncloseSingleQuotation(row.Item(ChkList_ColumnNM_BaseNo)))
            searchRow = rtnTBL.Select(Sql.ToString)

            ''1件のみの場合、関連なしの文言
            If searchRow.Length = 1 Then
                row.Item(ChkList_ColumnNM_CheckItem) = ConList_ChkItem_RefNothing
            End If
        Next
    End Sub


    ''' <summary>
    ''' 機能：確認項目を更新する。
    ''' 説明：※「FLG確認」
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub ConListTblChkItemFlgChk(ByRef rtnTBL As DataTable)


        Dim tmpTBL1 As DataTable
        tmpTBL1 = rtnTBL.Copy

        Dim Sql As New StringBuilder
        Sql.Length = 0
        Sql.Append(ChkList_ColumnNM_CheckItem)
        Sql.Append(CommonConstant.SQL_STR_EQUAL)
        Sql.Append(StringEdit.EncloseSingleQuotation(""))

        Dim validFlag As String
        Dim row As DataRow
        Dim chkRow As DataRow
        Dim isFlgNG As Boolean
        For Each row In tmpTBL1.Select(Sql.ToString)

            Sql.Length = 0
            Sql.Append(ChkList_ColumnNM_RefNo)
            Sql.Append(CommonConstant.SQL_STR_EQUAL)
            Sql.Append(StringEdit.EncloseSingleQuotation(ExcelWrite.changeDBNullToString(row.Item(ChkList_ColumnNM_RefNo))))

            validFlag = ExcelWrite.changeDBNullToString(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG))
            isFlgNG = False
            For Each chkRow In tmpTBL1.Select(Sql.ToString)
                If validFlag <> ExcelWrite.changeDBNullToString(chkRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG)) Then
                    isFlgNG = True
                    Exit For
                End If
            Next

            If isFlgNG = True Then
                ConListTblChkItemUpdBase(row.Item(ChkList_ColumnNM_BaseNo), ConList_ChkItem_FlgChk, rtnTBL)
            End If
        Next

    End Sub

    ''' <summary>
    ''' 機能：確認項目を更新する。
    ''' 説明：※有効/無効Flg = D：「Payment有り/無し」
    ''' </summary>
    ''' <param name="dtTbl1Tbl2"></param>
    ''' <param name="dtTbl3Month1"></param>
    ''' <param name="dtTbl3Month2"></param>
    ''' <remarks></remarks>
    Private Sub ConListTblChkItemDFlgMonthlyPrice(ByRef dtTbl1Tbl2 As DataTable,
                                                  ByRef dtTbl3Month1 As DataTable,
                                                  ByRef dtTbl3Month2 As DataTable)


        Dim tmpTBL1 As DataTable
        Dim tmpTBL2 As DataTable
        tmpTBL1 = dtTbl1Tbl2.Copy
        tmpTBL2 = dtTbl1Tbl2.Copy

        Dim Sql As New StringBuilder
        Sql.Length = 0
        Sql.Append(ChkList_ColumnNM_CheckItem)
        Sql.Append(CommonConstant.SQL_STR_EQUAL)
        Sql.Append(StringEdit.EncloseSingleQuotation(""))
        Sql.Append(CommonConstant.SQL_STR_AND)
        Sql.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG)
        Sql.Append(CommonConstant.SQL_STR_EQUAL)
        Sql.Append(StringEdit.EncloseSingleQuotation("D"))

        ''月額の合計金額をﾁｪｯｸ
        Dim isSumMatch As Boolean
        Dim row As DataRow
        Dim searchRow As DataRow
        Dim chkSumValue() As Long
        For Each row In tmpTBL1.Select(Sql.ToString)

            Sql.Length = 0
            Sql.Append(ChkList_ColumnNM_BaseNo)
            Sql.Append(CommonConstant.SQL_STR_EQUAL)
            Sql.Append(StringEdit.EncloseSingleQuotation(row.Item(ChkList_ColumnNM_BaseNo)))
            Sql.Append(CommonConstant.SQL_STR_AND)
            Sql.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG)
            Sql.Append(CommonConstant.SQL_STR_EQUAL)
            Sql.Append(StringEdit.EncloseSingleQuotation("D"))

            ''ﾃﾞｰﾀが1行なら、チェックしない。
            If tmpTBL2.Select(Sql.ToString).Length = 1 Then
                Call ConListTblChkItemUpdBase(row.Item(ChkList_ColumnNM_BaseNo), ConList_ChkItem_NothingPS, dtTbl1Tbl2)
                Continue For
            End If

            ReDim chkSumValue(ExcelWrite.MdbPaymentLineColumn.PRICE_YEAR20_MONTH12 - ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1)
            For Each searchRow In tmpTBL2.Select(Sql.ToString)

                Dim sbMonthFil1 As New StringBuilder
                sbMonthFil1.Remove(0, sbMonthFil1.Length)
                sbMonthFil1.Append("ID")
                sbMonthFil1.Append(CommonConstant.SQL_STR_EQUAL)
                sbMonthFil1.Append(StringEdit.EncloseSingleQuotation(searchRow.Item("ID")))

                '1年目～10年目
                Dim rowMonth1 As DataRow = dtTbl3Month1.Select(sbMonthFil1.ToString)(0)
                For i As Integer = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1 To _
                                   ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH12
                    If IsNumeric(rowMonth1.Item("CellNM" & i)) = True Then
                        chkSumValue(i - ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1) = chkSumValue(i - ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1) + CLng(rowMonth1.Item("CellNM" & i))
                    End If
                Next
                '11年目～20年目
                Dim rowMonth2 As DataRow = dtTbl3Month2.Select(sbMonthFil1.ToString)(0)
                For i As Integer = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH1 To _
                                   ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12
                    If IsNumeric(rowMonth2.Item("CellNM" & i)) = True Then
                        chkSumValue(i - ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH1) = chkSumValue(i - ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH1) + CLng(rowMonth2.Item("CellNM" & i))
                    End If
                Next
            Next

            ''月額のうち、1ヶ月でも集計結果が異なるﾃﾞｰﾀがあれば、「Payment有り」
            isSumMatch = True
            For Each chkSum As Long In chkSumValue
                If chkSum <> 0 Then
                    isSumMatch = False
                    Exit For
                End If
            Next

            ''Payment有り/無し
            If isSumMatch = True Then
                Call ConListTblChkItemUpdBase(row.Item(ChkList_ColumnNM_BaseNo), ConList_ChkItem_NothingPS, dtTbl1Tbl2)
            Else
                Call ConListTblChkItemUpdBase(row.Item(ChkList_ColumnNM_BaseNo), ConList_ChkItem_ExistsPS, dtTbl1Tbl2)
            End If
        Next

    End Sub

    ''' <summary>
    ''' 機能：確認項目を更新する。
    ''' 説明：※有効/無効Flg <> D：「Payment有り/無し」
    ''' </summary>
    ''' <param name="dtTbl1Tbl2"></param>
    ''' <param name="dtTbl3Month1"></param>
    ''' <param name="dtTbl3Month2"></param>
    ''' <remarks></remarks>
    Private Sub ConListTblChkItemOthMonthlyPrice(ByRef dtTbl1Tbl2 As DataTable,
                                                 ByRef dtTbl3Month1 As DataTable,
                                                 ByRef dtTbl3Month2 As DataTable)

        Dim tmpTBL1 As DataTable
        Dim tmpTBL2 As DataTable
        tmpTBL1 = dtTbl1Tbl2.Copy
        tmpTBL2 = dtTbl1Tbl2.Copy

        Dim Sql As New StringBuilder
        Sql.Length = 0
        Sql.Append(ChkList_ColumnNM_CheckItem)
        Sql.Append(CommonConstant.SQL_STR_EQUAL)
        Sql.Append(StringEdit.EncloseSingleQuotation(""))

        ''月額の合計金額をﾁｪｯｸ
        Dim isSumMatch As Boolean
        Dim row As DataRow
        Dim searchRow As DataRow
        Dim chkSumValue() As Long
        For Each row In tmpTBL1.Select(Sql.ToString)

            Sql.Length = 0
            Sql.Append(ChkList_ColumnNM_RefNo)
            Sql.Append(CommonConstant.SQL_STR_EQUAL)
            Sql.Append(StringEdit.EncloseSingleQuotation(row.Item(ChkList_ColumnNM_RefNo)))
            Sql.Append(CommonConstant.SQL_STR_AND)
            Sql.Append("CellNM" & ConListColumn.VALID_FLAG)
            Sql.Append(CommonConstant.SQL_STR_NOT_EQUAL)
            Sql.Append(StringEdit.EncloseSingleQuotation("D"))

            ''ﾃﾞｰﾀが1行なら、チェックしない。
            If tmpTBL2.Select(Sql.ToString).Length = 1 Then
                Call ConListTblChkItemUpdBase(row.Item(ChkList_ColumnNM_BaseNo), ConList_ChkItem_NothingPS, dtTbl1Tbl2)
                Continue For
            End If

            ''金額チェック
            ReDim chkSumValue(ExcelWrite.MdbPaymentLineColumn.PRICE_YEAR20_MONTH2 - ExcelWrite.MdbPaymentLineColumn.PRICE_YEAR1_MONTH1)
            For Each searchRow In tmpTBL2.Select(Sql.ToString)

                Dim sbMonthFil1 As New StringBuilder
                sbMonthFil1.Remove(0, sbMonthFil1.Length)
                sbMonthFil1.Append("ID")
                sbMonthFil1.Append(CommonConstant.SQL_STR_EQUAL)
                sbMonthFil1.Append(StringEdit.EncloseSingleQuotation(searchRow.Item("ID")))

                '1年目～10年目
                Dim rowMonth1 As DataRow = dtTbl3Month1.Select(sbMonthFil1.ToString)(0)
                For i As Integer = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1 To _
                                       ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH12
                    If IsNumeric(rowMonth1.Item("CellNM" & i)) = True Then
                        chkSumValue(i - ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1) = chkSumValue(i - ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1) + CLng(rowMonth1.Item("CellNM" & i))
                    End If
                Next
                '11年目～20年目
                Dim rowMonth2 As DataRow = dtTbl3Month2.Select(sbMonthFil1.ToString)(0)
                For i As Integer = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH1 To _
                                       ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12
                    If IsNumeric(rowMonth2.Item("CellNM" & i)) = True Then
                        chkSumValue(i - ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH1) = chkSumValue(i - ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH1) + CLng(rowMonth2.Item("CellNM" & i))
                    End If
                Next
            Next

            ''月額のうち、1ヶ月でも集計結果が異なるﾃﾞｰﾀがあれば、「Payment有り」
            isSumMatch = True
            For Each chkSum As Long In chkSumValue
                If chkSum <> 0 Then
                    isSumMatch = False
                    Exit For
                End If
            Next

            ''Payment有り/無し
            If isSumMatch = True Then
                Call ConListTblChkItemUpdBase(row.Item(ChkList_ColumnNM_BaseNo), ConList_ChkItem_NothingPS, dtTbl1Tbl2)
            Else
                Call ConListTblChkItemUpdBase(row.Item(ChkList_ColumnNM_BaseNo), ConList_ChkItem_ExistsPS, dtTbl1Tbl2)
            End If
        Next
    End Sub

    ''' <summary>
    '''概  要：BaseNoが一致する確認項目をすべて更新
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub ConListTblChkItemUpdBase(ByVal baseNo As String, _
                                         ByVal updValue As String, _
                                         ByRef rtnTBL As DataTable)
        ''BaseNo一致を全て更新
        Dim Sql As New StringBuilder
        Sql.Append(ChkList_ColumnNM_BaseNo)
        Sql.Append(CommonConstant.SQL_STR_EQUAL)
        Sql.Append(StringEdit.EncloseSingleQuotation(baseNo))
        For Each updRow As DataRow In rtnTBL.Select(Sql.ToString)
            ''Payment有りは上書しない。
            If updRow.Item(ChkList_ColumnNM_CheckItem) <> ConList_ChkItem_ExistsPS Then
                updRow.Item(ChkList_ColumnNM_CheckItem) = updValue
            End If
        Next

    End Sub


    ''' <summary>
    ''' 機能：項目10のCopy元/削除元のNoを取得する。
    ''' 説明：※Order By用に10桁0埋め
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetItem10No(ByVal Item10 As String) As String

        ''初期化
        GetItem10No = ""

        ''OKな文言をセット
        Dim OKList As New ArrayList
        OKList.Add("*一部削除")
        OKList.Add("* 一部削除")

        ''Copy元No/削除元Noの削除
        Dim rtnNo As String
        Dim chkValue As String
        rtnNo = Item10
        chkValue = Item10
        If chkValue.IndexOf(ProdItem10_Value_DelNo) <> -1 Then
            chkValue = chkValue.Replace(ProdItem10_Value_DelNo, "").Trim
        ElseIf chkValue.IndexOf(ProdItem10_Value_CopyNo) <> -1 Then
            chkValue = chkValue.Replace(ProdItem10_Value_CopyNo, "").Trim
        Else
            Exit Function
        End If
        Dim intPos As Integer
        intPos = chkValue.IndexOf("_")
        If intPos <> -1 Then
            chkValue = chkValue.Substring(0, intPos)
        End If
        rtnNo = chkValue

        ''先頭1文字が文字の場合、NG
        If chkNumeric(chkValue.Substring(0, 1)) = False Then
            Exit Function
        End If

        ''OK文言
        For Each OKWord As String In OKList
            If chkValue.IndexOf(OKWord) <> -1 Then
                chkValue = chkValue.Replace(OKWord, "").Trim
                rtnNo = chkValue
            End If
        Next

        ''文字のチェック
        If chkNumeric(chkValue) = False Then
            Exit Function
        End If

        ''戻り値
        Return rtnNo.PadLeft(10, "0")

    End Function


    ''' <summary>
    ''' 機能：文字列の存在ﾁｪｯｸ
    ''' 説明：※IsNumericだと指数表現等を数値と判定するため、On Code
    ''' </summary>
    ''' <remarks></remarks>
    Private Function chkNumeric(ByVal value As String) As Boolean

        ''初期化
        chkNumeric = True
        Dim chkChar As String
        For i As Integer = 1 To value.Length
            chkChar = value.Substring(i - 1, 1)
            Select Case chkChar
                Case "0", _
                     "1", _
                     "2", _
                     "3", _
                     "4", _
                     "5", _
                     "6", _
                     "7", _
                     "8", _
                     "9"
                Case Else
                    chkNumeric = False
                    Exit Function
            End Select
        Next
    End Function

    ''' <summary>
    ''' 機能：削除データﾁｪｯｸﾘｽﾄ出力
    ''' </summary>
    ''' <param name="outFolder"></param>
    ''' <param name="WaitDialog"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function DelDateCheckList(ByVal outFolder As String, _
                                      ByRef WaitDialog As Frm_WaitDialog) As String


        DelDateCheckList = ""

        Try
            '--------------------------------------------------
            '処理前ﾁｪｯｸ
            '--------------------------------------------------
            Dim msg As String
            If ChkDelDateCheckListBtn(msg) = False Then
                Throw New Exception(msg)
            End If

            '--------------------------------------------------
            'データをMDBにセット
            '--------------------------------------------------
            Call SetMdbCheckDelete()

            '--------------------------------------------------
            '出力対象ﾃﾞｰﾀ取得
            '--------------------------------------------------
            Dim ConListPt1Pt2 As New DataTable
            Dim ConListPT3Year1 As New DataTable
            Dim ConListPT3Year2 As New DataTable
            Dim ConListPT3Month1 As New DataTable
            Dim ConListPT3Month2 As New DataTable

            Call GetDelDateCheckListDate(ConListPt1Pt2,
                                         ConListPT3Year1,
                                         ConListPT3Year2,
                                         ConListPT3Month1,
                                         ConListPT3Month2)

            If ConListPt1Pt2.Rows.Count > 0 Then
                '--------------------------------------------------
                'データチェック
                '--------------------------------------------------
                'BaseNo取得
                Dim baseNoList As ArrayList
                baseNoList = GetBaseNoList(ConListPt1Pt2)

                'BaseNO更新
                Call UpdConListTblBaseNo(baseNoList, ConListPt1Pt2)

                '確認項目
                Call UpdConListTblChkItem(baseNoList,
                                          ConListPt1Pt2,
                                          ConListPT3Month1,
                                          ConListPT3Month2)

            End If

            '--------------------------------------------------
            '削除妥当性ﾁｪｯｸﾘｽﾄ出力
            '--------------------------------------------------
            Call OutDelListExcelFile(outFolder,
                                     ConListPt1Pt2,
                                     ConListPT3Year1,
                                     ConListPT3Year2,
                                     ConListPT3Month1,
                                     ConListPT3Month2)

            ''戻り値
            Return "削除データ妥当性チェックリスト"

        Catch ex As Exception
            Throw ex
        End Try

    End Function

    ''' <summary>
    ''' 機能：サーバーから契約済データを取得しTempDBに保存する
    ''' </summary>
    ''' <param name="strButtonName">ボタン名</param>
    ''' <param name="strErrMsg">エラーメッセージ</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetNewTempDb(ByVal strButtonName As String, ByRef strErrMsg As String) As Boolean

        Dim ic As New ImportCsv
        Dim blnRet As Boolean
        Dim strCsvPsPath As String
        Dim filePath As ImportCsv.ServerCsvPath
        Dim importCount As ImportCsv.ImportCount
        Dim importErrCount As ImportCsv.ImportErrCount
        Dim OUTERR As New OutputErrorList
        Dim ofm As New OioFileManage
        Dim intRet As Integer

        GetNewTempDb = False

        Try
            'TempMDBが無い場合、空のTempMDBを作成する
            Dim strFile As String
            strFile = ofm.GetDataKeepMDBPath(CommonVariable.CPNO)
            If File.Exists(strFile) = False Then
                Dim strSrcFile As String
                strSrcFile = ofm.GetLocalTempMDBPath
                File.Copy(strSrcFile, strFile)
            End If

            '==============================================
            'メッセージ
            '==============================================
            strErrMsg = ""
            If strButtonName <> "Btn_DelCheckList" Then
                intRet = MsgBox(FileReader.GetMessage("MSG_0432"), vbQuestion + MsgBoxStyle.YesNo, "")
                If intRet = vbNo Then
                    '契約締結済MDBの存在チェック
                    Dim mdbPath As String
                    mdbPath = ofm.GetLocalDataKeepMDBFolder & ofm.GetCpnoForPaymentXls(Me.txb_InputFile.Text) & ".accdb"
                    If File.Exists(mdbPath) = False Then
                        strErrMsg = FileReader.GetMessage("MSG_0523")
                    End If
                    GetNewTempDb = True
                    Exit Function
                End If
            End If

            '==============================================
            'MasterMdb存在チェック
            '==============================================
            If ofm.CheckExistsMdb(OioFileManage.enmMdbType.Master, CommonVariable.MdbPW, strErrMsg) = False Then
                Exit Function
            End If

            '==============================================
            'インポート処理
            '==============================================
            OUTERR.CpNo = CommonVariable.CPNO
            OUTERR.ContractNo = CommonVariable.CONTRACTNO
            OUTERR.OutImportErrorList("START", "Import(集計及び台帳作成)", , , , True)
            'CSVﾀﾞｳﾝﾛｰﾄﾞﾊﾟｽ
            strCsvPsPath = ofm.GetLocalCsv1Folder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)

            blnRet = ic.SetServerCsvToTemMdb(ic.CD_IMPORT_MDB,
                                             "",
                                             "",
                                              CommonVariable.PaymentStart.ToString("yyyy"),
                                              strCsvPsPath,
                                              CommonVariable.PaymentPeriod,
                                              filePath,
                                              importCount,
                                              importErrCount,
                                              strErrMsg,
                                              OUTERR,
                                              False,
                                              False)
            OUTERR.OutImportErrorList("END", "Import")

            If blnRet = False Then
                Exit Function
            End If

            blnRet = ofm.CheckMdbCount(CommonVariable.MdbPW,
                                       CommonVariable.CPNO,
                                       True,
                                       False,
                                       importCount.MDBCount,
                                       importCount.MDBDetailCount,
                                       importCount.CreatingMdbCount,
                                       importCount.CreatingMdbDetailCount)
            If blnRet = False Then
                Exit Function
            End If

            If importCount.MDBCount = 0 Then
                strErrMsg = FileReader.GetMessage("MSG_0470")
            End If

            GetNewTempDb = True

        Catch ex As Exception
            strErrMsg = ex.Message.ToString
        End Try

    End Function

    ''' <summary>
    ''' 機能：削除データチェックリストの処理前チェック
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function ChkDelDateCheckListBtn(ByRef Msg As String) As Boolean

        ''初期化
        ChkDelDateCheckListBtn = False

        ''Payment/MDBファイル存在ﾁｪｯｸ
        Dim psPath As String
        Dim tmpMdbPath As String
        Dim ofm As New OioFileManage
        psPath = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO) & _
                 ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
        tmpMdbPath = ofm.GetDataKeepMDBPath(CommonVariable.CPNO)
        If File.Exists(psPath) = False Then
            Msg = FileReader.GetMessage("MSG_0326")
            Exit Function
        End If
        If File.Exists(tmpMdbPath) = False Then
            Msg = FileReader.GetMessage("MSG_0428")
            Exit Function
        End If

        ChkDelDateCheckListBtn = True

    End Function

    ''' <summary>
    ''' 機能：チェックリスト取得
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Sub GetDelDateCheckListDate(ByRef dtTbl1Tbl2 As DataTable,
                                        ByRef dtTbl3Year1 As DataTable,
                                        ByRef dtTbl3Year2 As DataTable,
                                        ByRef dtTbl3Month1 As DataTable,
                                        ByRef dtTbl3Month2 As DataTable)

        Dim mmc As New MasterMdbControl
        Dim con As OleDbConnection
        Dim cmd As OleDbCommand
        Dim adpt As OleDbDataAdapter
        Dim intCnt As Integer
        Dim strYear As String

        Try
            Application.DoEvents()              ''応答なし対応

            'MDBのConnection
            con = mmc.GetOleTmpDBConnection(CommonVariable.CPNO, CommonVariable.MdbPW)
            cmd = New OleDbCommand
            cmd.Connection = con

            '------------------------------------------------
            'PaymentTBL1,PaymentTBL2（過去の合計金額以外）
            '------------------------------------------------
            'クエリでデータ取得
            cmd.CommandText = "DelData_Valid_PT1PT2"
            cmd.CommandType = CommandType.StoredProcedure
            adpt = New OleDbDataAdapter(cmd)
            adpt.Fill(dtTbl1Tbl2)

            'カラム追加＋初期化
            Dim dcItem10No As New DataColumn(ChkList_ColumnNM_Item10No, Type.GetType("System.String"))
            dcItem10No.DefaultValue = ""
            dtTbl1Tbl2.Columns.Add(dcItem10No)
            Dim dcBaseNo As New DataColumn(ChkList_ColumnNM_BaseNo, Type.GetType("System.String"))
            dcBaseNo.DefaultValue = ""
            dtTbl1Tbl2.Columns.Add(dcBaseNo)
            Dim dcRefNo As New DataColumn(ChkList_ColumnNM_RefNo, Type.GetType("System.String"))
            dcRefNo.DefaultValue = ""
            dtTbl1Tbl2.Columns.Add(dcRefNo)
            Dim dcCheckItem As New DataColumn(ChkList_ColumnNM_CheckItem, Type.GetType("System.String"))
            dcCheckItem.DefaultValue = ""
            dtTbl1Tbl2.Columns.Add(dcCheckItem)

            'Item10No加工
            Call UpdateItem10No(dtTbl1Tbl2)

            '------------------------------------------------
            'PaymentTBL3（年額展開（1年目から10年目））
            '------------------------------------------------
            'クエリでデータ取得
            cmd.CommandText = "DelData_Valid_PT3_YEAR1"
            cmd.CommandType = CommandType.StoredProcedure
            strYear = CommonVariable.PaymentStart.ToString("yyyy")
            cmd.Parameters.Add("@1", strYear)
            adpt = New OleDbDataAdapter(cmd)
            adpt.Fill(dtTbl3Year1)

            '------------------------------------------------
            'PaymentTBL3（年額展開（11年目から20年目））、PaymentTBL2の過去の合計金額
            '------------------------------------------------
            'クエリでデータ取得
            cmd.CommandText = "DelData_Valid_PT3_YEAR2"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@1", strYear)
            adpt = New OleDbDataAdapter(cmd)
            adpt.Fill(dtTbl3Year2)

            '------------------------------------------------
            'PaymentTBL3（月額展開（1年目から10年目））
            '------------------------------------------------
            'クエリでデータ取得
            cmd.CommandText = "DelData_Valid_PT3_MONTH1"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@1", strYear)
            adpt = New OleDbDataAdapter(cmd)
            adpt.Fill(dtTbl3Month1)

            '------------------------------------------------
            'PaymentTBL3（月額展開（11年目から20年目））
            '------------------------------------------------
            'クエリでデータ取得
            cmd.CommandText = "DelData_Valid_PT3_MONTH2"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@1", strYear)
            adpt = New OleDbDataAdapter(cmd)
            adpt.Fill(dtTbl3Month2)

        Catch ex As Exception
            Debug.Print(ex.Message.ToString & "(GetDelDateCheckListDate)")
            Throw ex
        Finally
            cmd.Dispose()

        End Try

    End Sub

    ''' <summary>
    ''' 機能：Item10No加工
    ''' </summary>
    ''' <param name="dt"></param>
    ''' <remarks></remarks>
    Private Sub UpdateItem10No(ByRef dt As DataTable)

        Dim sbFilter As New StringBuilder
        Dim strWork As String

        Try
            '項目10の「削除元 =」「ｺﾋﾟｰ元 =」を検索
            sbFilter.Remove(0, sbFilter.Length())
            sbFilter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10)
            sbFilter.Append(CommonConstant.SQL_STR_LIKE)
            sbFilter.Append(StringEdit.EncloseSingleQuotation(ProdItem10_Value_DelNo & CommonConstant.SQL_STR_PERCENT))
            sbFilter.Append(CommonConstant.SQL_STR_OR)
            sbFilter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10)
            sbFilter.Append(CommonConstant.SQL_STR_LIKE)
            sbFilter.Append(StringEdit.EncloseSingleQuotation(ProdItem10_Value_CopyNo & CommonConstant.SQL_STR_PERCENT))

            'Item10Noを更新
            For Each row As DataRow In dt.Select(sbFilter.ToString)
                strWork = GetItem10No(ExcelWrite.changeDBNullToString(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10)))
                row.Item(ChkList_ColumnNM_Item10No) = strWork
                Debug.Print("NO:" & ExcelWrite.changeDBNullToString(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO)) &
                            "  項目10:" & ExcelWrite.changeDBNullToString(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10)) &
                            "  Item10No:" & strWork)
            Next

        Catch ex As Exception
            Debug.Print(ex.Message.ToString & "(GetDelDateCheckListDate3)")
            Throw ex
        End Try

    End Sub

    Private Function GetBaseNoList(ByRef ConListTable As DataTable) As ArrayList

        ''初期化
        Dim rtnArray As New ArrayList
        GetBaseNoList = rtnArray

        ''Excelで"削除元No"文言検索
        Dim baseNo As String
        Dim nowRow As DataRow
        Dim chkLoop As New ArrayList            ''無限ﾙｰﾌﾟ防止--LineNo履歴
        Dim filter As New StringBuilder
        filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10)
        filter.Append(CommonConstant.SQL_STR_LIKE)
        filter.Append(StringEdit.EncloseSingleQuotation(ProdItem10_Value_DelNo & CommonConstant.SQL_STR_PERCENT))
        ''Excel出力しているデータのみ対象にする。
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(ChkList_ColumnNM_FileKB)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(FileKB_Value_EXCEL))
        For Each tmpRow As DataRow In ConListTable.Select(filter.ToString)

            ''親レコードなくなるまで無限ループ
            nowRow = tmpRow
            Call chkLoop.Clear()
            While True
                Call chkLoop.Add(nowRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO))
                If searchBaseRow(nowRow, ConListTable, chkLoop) = False Then
                    baseNo = ExcelWrite.changeDBNullToString(nowRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO))
                    Exit While
                End If
            End While

            ''BaseNo追加
            If rtnArray.IndexOf(baseNo) = -1 Then
                Call rtnArray.Add(baseNo)
            End If
        Next

        ''戻り値
        GetBaseNoList = rtnArray

    End Function

    Private Function searchBaseRow(ByRef nowRow As DataRow, _
                                   ByRef ConListTable As DataTable, _
                                   ByRef chkLoop As ArrayList) As Boolean

        ''初期値
        searchBaseRow = False


        ''削除元/コピー元No取得
        Dim searchKey As String
        searchKey = nowRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10)
        '文字列に削除元NO or ｺﾋﾟｰ元NOが最初から始まらない場合、処理を抜ける
        If searchKey.IndexOf(ProdItem10_Value_CopyNo) <> 0 And
           searchKey.IndexOf(ProdItem10_Value_DelNo) <> 0 Then
            Exit Function
        End If
        searchKey = searchKey.Replace(ProdItem10_Value_CopyNo, "").Replace(ProdItem10_Value_DelNo, "")
        Dim intPos As Integer
        intPos = searchKey.IndexOf("_")
        If intPos <> -1 Then
            searchKey = searchKey.Substring(0, intPos).PadLeft(10, "0")
        Else
            searchKey = searchKey.PadLeft(10, "0")
        End If

        ''削除/コピー元の行取得
        Dim rows() As DataRow
        Dim filter As New StringBuilder
        filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(searchKey))
        rows = ConListTable.Select(filter.ToString)
        If rows.Length <> 0 AndAlso _
           chkLoop.IndexOf(rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO)) = -1 Then
            nowRow = rows(0)
            searchBaseRow = True
        Else
            searchBaseRow = False
        End If

    End Function

    Private Sub UpdConListTblBaseNo(ByRef baseNoList As ArrayList, _
                                    ByRef ConListTable As DataTable)

        Dim searchKey As String
        Dim chkLoop As New ArrayList
        Dim filter As New StringBuilder
        For Each baseNo As String In baseNoList

            ''baseNoListの行を更新
            filter.Remove(0, filter.Length())
            filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(baseNo))
            For Each updRow As DataRow In ConListTable.Select(filter.ToString)
                updRow.Item(ChkList_ColumnNM_BaseNo) = baseNo
            Next

            ''削除元/コピー元のBaseNo更新
            searchKey = baseNo
            Call chkLoop.Clear()
            Call UpdTblBaseNo(baseNo, ConListTable, searchKey, chkLoop)

        Next

    End Sub

    Private Sub UpdTblBaseNo(ByVal baseNo As String, _
                             ByRef ConListTable As DataTable, _
                             ByRef searchKey As String, _
                             ByRef chkLoop As ArrayList)

        ''削除元/コピー元を取得
        Dim rows() As DataRow
        Dim filter As New StringBuilder
        Dim tmpSearchKey As String
        tmpSearchKey = searchKey
        filter.Append(ChkList_ColumnNM_Item10No)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(tmpSearchKey))
        rows = ConListTable.Select(filter.ToString)
        If rows.Length = 0 Then
            Exit Sub
        End If

        ''BaseNoの更新
        For idx As Integer = 0 To UBound(rows)

            ''無限ﾙｰﾌﾟ防止
            tmpSearchKey = rows(idx).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO)
            If chkLoop.IndexOf(tmpSearchKey) <> -1 Then
                Continue For
            Else
                Call chkLoop.Add(tmpSearchKey)
            End If

            ''BaseNo更新
            rows(idx).Item(ChkList_ColumnNM_BaseNo) = baseNo

            ''再帰処理
            Call UpdTblBaseNo(baseNo, ConListTable, tmpSearchKey, chkLoop)

        Next

    End Sub

    ''' <summary>
    ''' 機能：確認項目
    ''' </summary>
    ''' <param name="baseNoList"></param>
    ''' <param name="dtTbl1Tbl2"></param>
    ''' <param name="dtTbl3Month1"></param>
    ''' <param name="dtTbl3Month2"></param>
    ''' <remarks></remarks>
    Private Sub UpdConListTblChkItem(ByRef baseNoList As ArrayList,
                                     ByRef dtTbl1Tbl2 As DataTable,
                                     ByRef dtTbl3Month1 As DataTable,
                                     ByRef dtTbl3Month2 As DataTable)

        ''関連なし
        Call ConListTblChkItemRefNothing(baseNoList, dtTbl1Tbl2)

        ''2重削除
        Call ConListTblChkItemDowbleDel(baseNoList, dtTbl1Tbl2)

        ''Flg確認
        Call ConListTblChkItemFlgChk(baseNoList, dtTbl1Tbl2)

        ''月額確認
        Call ConListTblChkItemDFlgMonthlyPrice(baseNoList, dtTbl1Tbl2, dtTbl3Month1, dtTbl3Month2)

    End Sub

    ''' <summary>
    ''' 機能：関連なしﾁｪｯｸ
    ''' </summary>
    ''' <param name="baseNoList"></param>
    ''' <param name="rtnTBL"></param>
    ''' <remarks></remarks>
    Private Sub ConListTblChkItemRefNothing(ByRef baseNoList As ArrayList, _
                                            ByRef rtnTBL As DataTable)

        For Each baseNo As String In baseNoList
            Dim fil As New StringBuilder
            Dim rows() As DataRow
            fil.Remove(0, fil.Length)
            fil.Append(ChkList_ColumnNM_BaseNo)
            fil.Append(CommonConstant.SQL_STR_EQUAL)
            fil.Append(StringEdit.EncloseSingleQuotation(baseNo))
            rows = rtnTBL.Select(fil.ToString)
            If rows.Length = 1 Then
                rows(0).Item(ChkList_ColumnNM_CheckItem) = ConList_ChkItem_RefNothing
            End If
        Next

    End Sub

    ''' <summary>
    ''' 機能：2重削除ﾁｪｯｸ
    ''' </summary>
    ''' <param name="baseNoList"></param>
    ''' <param name="rtnTBL"></param>
    ''' <remarks></remarks>
    Private Sub ConListTblChkItemDowbleDel(ByRef baseNoList As ArrayList, _
                                           ByRef rtnTBL As DataTable)

        For Each baseNo As String In baseNoList

            ''エラーが存在しないBaseNoのみUpdate
            Dim fil As New StringBuilder
            fil.Remove(0, fil.Length)
            fil.Append(ChkList_ColumnNM_BaseNo)
            fil.Append(CommonConstant.SQL_STR_EQUAL)
            fil.Append(StringEdit.EncloseSingleQuotation(baseNo))
            fil.Append(CommonConstant.SQL_STR_AND)
            fil.Append(ChkList_ColumnNM_CheckItem)
            fil.Append(CommonConstant.SQL_STR_NOT_EQUAL)
            fil.Append(StringEdit.EncloseSingleQuotation(""))
            If rtnTBL.Select(fil.ToString).Length <> 0 Then
                Continue For
            End If

            ''削除元No重複ﾁｪｯｸ
            Dim isExists As Boolean = False
            Dim chkArray As New ArrayList
            fil.Remove(0, fil.Length)
            fil.Append(ChkList_ColumnNM_BaseNo)
            fil.Append(CommonConstant.SQL_STR_EQUAL)
            fil.Append(StringEdit.EncloseSingleQuotation(baseNo))
            fil.Append(CommonConstant.SQL_STR_AND)
            fil.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10)
            fil.Append(CommonConstant.SQL_STR_LIKE)
            fil.Append(StringEdit.EncloseSingleQuotation(ProdItem10_Value_DelNo & CommonConstant.SQL_STR_PERCENT))
            fil.Append(CommonConstant.SQL_STR_AND)
            fil.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG)
            fil.Append(CommonConstant.SQL_STR_EQUAL)
            fil.Append(StringEdit.EncloseSingleQuotation(""))

            Call chkArray.Clear()
            For Each row As DataRow In rtnTBL.Select(fil.ToString)

                Dim intpos As Integer
                Dim chkvalue As String

                chkvalue = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10)
                intpos = chkvalue.IndexOf("_")
                If intpos <> -1 Then
                    chkvalue = chkvalue.Substring(0, intpos)
                End If
                Call chkArray.Add(chkvalue)

            Next


            'Excelに削除元NO = と書かれたデータが無ければ対象外
            If chkArray.Count = 0 Then
                Continue For
            End If

            Dim i As Integer

            For i = 0 To chkArray.Count - 1

                fil.Remove(0, fil.Length)
                fil.Append(ChkList_ColumnNM_BaseNo)
                fil.Append(CommonConstant.SQL_STR_EQUAL)
                fil.Append(StringEdit.EncloseSingleQuotation(baseNo))
                fil.Append(CommonConstant.SQL_STR_AND)
                fil.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10)
                fil.Append(CommonConstant.SQL_STR_LIKE)
                fil.Append(StringEdit.EncloseSingleQuotation(chkArray(i) & CommonConstant.SQL_STR_PERCENT))

                If rtnTBL.Select(fil.ToString).Length > 1 Then
                    isExists = True
                End If
            Next i

            ''重複していた場合、2重削除とする。
            If isExists = True Then
                fil.Remove(0, fil.Length)
                fil.Append(ChkList_ColumnNM_BaseNo)
                fil.Append(CommonConstant.SQL_STR_EQUAL)
                fil.Append(StringEdit.EncloseSingleQuotation(baseNo))
                For Each row As DataRow In rtnTBL.Select(fil.ToString)
                    row.Item(ChkList_ColumnNM_CheckItem) = ConList_ChkItem_DowbleDel
                Next
            End If

        Next

    End Sub

    ''' <summary>
    ''' 機能：Flg確認ﾁｪｯｸ
    ''' </summary>
    ''' <param name="baseNoList"></param>
    ''' <param name="rtnTBL"></param>
    ''' <remarks></remarks>
    Private Sub ConListTblChkItemFlgChk(ByRef baseNoList As ArrayList, _
                                        ByRef rtnTBL As DataTable)

        For Each baseNo As String In baseNoList

            ''エラーが存在しないBaseNoのみUpdate
            Dim fil As New StringBuilder
            fil.Remove(0, fil.Length)
            fil.Append(ChkList_ColumnNM_BaseNo)
            fil.Append(CommonConstant.SQL_STR_EQUAL)
            fil.Append(StringEdit.EncloseSingleQuotation(baseNo))
            fil.Append(CommonConstant.SQL_STR_AND)
            fil.Append(ChkList_ColumnNM_CheckItem)
            fil.Append(CommonConstant.SQL_STR_NOT_EQUAL)
            fil.Append(StringEdit.EncloseSingleQuotation(""))
            If rtnTBL.Select(fil.ToString).Length <> 0 Then
                Continue For
            End If

            Dim row1_validFlag As String
            Dim row2_validFlag As String
            fil.Remove(0, fil.Length)
            fil.Append(ChkList_ColumnNM_BaseNo)
            fil.Append(CommonConstant.SQL_STR_EQUAL)
            fil.Append(StringEdit.EncloseSingleQuotation(baseNo))
            fil.Append(CommonConstant.SQL_STR_AND)
            fil.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10)
            fil.Append(CommonConstant.SQL_STR_LIKE)
            fil.Append(StringEdit.EncloseSingleQuotation(ProdItem10_Value_DelNo & CommonConstant.SQL_STR_PERCENT))
            For Each row1 As DataRow In rtnTBL.Select(fil.ToString)

                fil.Remove(0, fil.Length)
                fil.Append(ChkList_ColumnNM_BaseNo)
                fil.Append(CommonConstant.SQL_STR_EQUAL)
                fil.Append(StringEdit.EncloseSingleQuotation(baseNo))
                fil.Append(CommonConstant.SQL_STR_AND)
                fil.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO)
                fil.Append(CommonConstant.SQL_STR_EQUAL)
                fil.Append(StringEdit.EncloseSingleQuotation(row1.Item(ChkList_ColumnNM_Item10No)))
                For Each row2 As DataRow In rtnTBL.Select(fil.ToString)
                    If row1.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG) <> row2.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG) Then
                        row1.Item(ChkList_ColumnNM_CheckItem) = ConList_ChkItem_FlgChk
                        row2.Item(ChkList_ColumnNM_CheckItem) = ConList_ChkItem_FlgChk
                    End If
                Next
            Next
        Next
    End Sub

    ''' <summary>
    ''' 機能：月額確認ﾁｪｯｸ
    ''' </summary>
    ''' <param name="baseNoList"></param>
    ''' <param name="dtTbl1Tbl2"></param>
    ''' <param name="dtTbl3Month1"></param>
    ''' <param name="dtTbl3Month2"></param>
    ''' <remarks></remarks>
    Private Sub ConListTblChkItemDFlgMonthlyPrice(ByRef baseNoList As ArrayList,
                                                  ByRef dtTbl1Tbl2 As DataTable,
                                                  ByRef dtTbl3Month1 As DataTable,
                                                  ByRef dtTbl3Month2 As DataTable)

        Dim chkPrice1 As Double
        Dim chkPrice2 As Double
        For Each baseNo As String In baseNoList

            ''エラーが存在しないBaseNoのみUpdate
            Dim fil As New StringBuilder
            fil.Remove(0, fil.Length)
            fil.Append(ChkList_ColumnNM_BaseNo)
            fil.Append(CommonConstant.SQL_STR_EQUAL)
            fil.Append(StringEdit.EncloseSingleQuotation(baseNo))
            fil.Append(CommonConstant.SQL_STR_AND)
            fil.Append(ChkList_ColumnNM_CheckItem)
            fil.Append(CommonConstant.SQL_STR_NOT_EQUAL)
            fil.Append(StringEdit.EncloseSingleQuotation(""))
            If dtTbl1Tbl2.Select(fil.ToString).Length <> 0 Then
                Continue For
            End If

            ''削除元との紐付けを取得
            fil.Remove(0, fil.Length)
            fil.Append(ChkList_ColumnNM_BaseNo)
            fil.Append(CommonConstant.SQL_STR_EQUAL)
            fil.Append(StringEdit.EncloseSingleQuotation(baseNo))
            fil.Append(CommonConstant.SQL_STR_AND)
            fil.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10)
            fil.Append(CommonConstant.SQL_STR_LIKE)
            fil.Append(StringEdit.EncloseSingleQuotation(ProdItem10_Value_DelNo & CommonConstant.SQL_STR_PERCENT))
            For Each row1 As DataRow In dtTbl1Tbl2.Select(fil.ToString)

                Dim sbMonthFil1 As New StringBuilder
                sbMonthFil1.Remove(0, sbMonthFil1.Length)
                sbMonthFil1.Append("ID")
                sbMonthFil1.Append(CommonConstant.SQL_STR_EQUAL)
                sbMonthFil1.Append(StringEdit.EncloseSingleQuotation(row1.Item("ID")))

                fil.Remove(0, fil.Length)
                fil.Append(ChkList_ColumnNM_BaseNo)
                fil.Append(CommonConstant.SQL_STR_EQUAL)
                fil.Append(StringEdit.EncloseSingleQuotation(baseNo))
                fil.Append(CommonConstant.SQL_STR_AND)
                fil.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO)
                fil.Append(CommonConstant.SQL_STR_EQUAL)
                fil.Append(StringEdit.EncloseSingleQuotation(row1.Item(ChkList_ColumnNM_Item10No)))
                For Each row2 As DataRow In dtTbl1Tbl2.Select(fil.ToString)


                    If row1.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG) = row2.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG) And _
                       row1.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG) = "D" Then

                        Dim sbMonthFil2 As New StringBuilder
                        sbMonthFil2.Remove(0, sbMonthFil2.Length)
                        sbMonthFil2.Append("ID")
                        sbMonthFil2.Append(CommonConstant.SQL_STR_EQUAL)
                        sbMonthFil2.Append(StringEdit.EncloseSingleQuotation(row2.Item("ID")))

                        '1年目から10年目
                        Dim isPrice As Boolean = True
                        Dim rowMonth1 As DataRow = dtTbl3Month1.Select(sbMonthFil1.ToString)(0)
                        Dim rowMonth2 As DataRow = dtTbl3Month1.Select(sbMonthFil2.ToString)(0)
                        For idx As Integer = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1 To _
                                             ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH12


                            If IsNumeric(rowMonth1.Item("CellNM" & idx)) Then
                                chkPrice1 = CDbl(rowMonth1.Item("CellNM" & idx))
                                '削除妥当性チェックリスト不備修正 str
                            Else
                                chkPrice1 = 0
                                '削除妥当性チェックリスト不備修正 end
                            End If
                            If IsNumeric(rowMonth2.Item("CellNM" & idx)) Then
                                chkPrice2 = CDbl(rowMonth2.Item("CellNM" & idx))
                                '削除妥当性チェックリスト不備修正 str
                            Else
                                chkPrice2 = 0
                                '削除妥当性チェックリスト不備修正 end
                            End If

                            If (chkPrice1 + chkPrice2) <> 0 Then
                                row1.Item(ChkList_ColumnNM_CheckItem) = ConList_ChkItem_ExistsPS
                                row2.Item(ChkList_ColumnNM_CheckItem) = ConList_ChkItem_ExistsPS
                                isPrice = False
                                Exit For
                            End If
                        Next

                        '11年目から20年目
                        If isPrice = True Then
                            rowMonth1 = dtTbl3Month2.Select(sbMonthFil1.ToString)(0)
                            rowMonth2 = dtTbl3Month2.Select(sbMonthFil2.ToString)(0)
                            For idx As Integer = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH1 To _
                                                 ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12

                                If IsNumeric(rowMonth1.Item("CellNM" & idx)) Then
                                    chkPrice1 = CDbl(rowMonth1.Item("CellNM" & idx))
                                    '削除妥当性チェックリスト不備修正 str
                                Else
                                    chkPrice1 = 0
                                    '削除妥当性チェックリスト不備修正 end
                                End If
                                If IsNumeric(rowMonth2.Item("CellNM" & idx)) Then
                                    chkPrice2 = CDbl(rowMonth2.Item("CellNM" & idx))
                                    '削除妥当性チェックリスト不備修正 str
                                Else
                                    chkPrice2 = 0
                                    '削除妥当性チェックリスト不備修正 end
                                End If

                                If (chkPrice1 + chkPrice2) <> 0 Then
                                    row1.Item(ChkList_ColumnNM_CheckItem) = ConList_ChkItem_ExistsPS
                                    row2.Item(ChkList_ColumnNM_CheckItem) = ConList_ChkItem_ExistsPS
                                    Exit For
                                End If
                            Next
                        End If
                    End If
                Next
            Next
        Next

    End Sub

    ''' <summary>
    ''' 機能：削除妥当性ﾁｪｯｸのExcelFileを作成する。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub OutDelListExcelFile(ByVal outFolder As String,
                                    ByRef dtTbl1Tbl2 As DataTable,
                                    ByRef dtTbl3Year1 As DataTable,
                                    ByRef dtTbl3Year2 As DataTable,
                                    ByRef dtTbl3Month1 As DataTable,
                                    ByRef dtTbl3Month2 As DataTable)

        Application.DoEvents()              ''応答なし対応
        Dim xlApp As New Excel.Application
        Dim xlConListBook As Excel.Workbook
        Dim xlListSheet As Excel.Worksheet
        Dim xlCell As Excel.Range
        Try
            ''ﾌｧｲﾙの作成
            Dim ofm As New OioFileManage
            Dim tmpPath As String
            Dim outPath As String
            tmpPath = ofm.GetLocalTemplateFolder & _
                      TmpDelListFileNM
            outPath = outFolder & GetDelListFileNM()
            Call File.Copy(tmpPath, outPath)

            ''Appの初期化
            xlApp.EnableEvents = False
            xlApp.DisplayAlerts = False

            ''ﾌｧｲﾙのOpen/Sheetセット
            xlConListBook = xlApp.Workbooks.Open(outPath)
            xlListSheet = xlConListBook.Worksheets(ConList_ChkSheetNM)

            ''WS1ｼｰﾄの更新
            Dim crWs1 As New CreateWS1
            Dim blet As Boolean
            Call crWs1.WS1の作成(xlConListBook, CommonVariable.PaymentPeriod, CommonVariable.PaymentPW)

            Dim filter As New StringBuilder
            filter.Append("Trim(" & ChkList_ColumnNM_CheckItem & ")")
            filter.Append(CommonConstant.SQL_STR_NOT_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(""))
            Application.DoEvents()              ''応答なし対応
            '出力結果がある場合
            If dtTbl1Tbl2.Select(filter.ToString).Length > 0 Then
                ''ﾃﾝﾌﾟﾚ行のCopy&Paste
                Call CopyConListTmpRow(xlListSheet, dtTbl1Tbl2.Select(filter.ToString).Length)

                ''Excel出力用の配列作成
                Dim outArray(,) As Object
                Application.DoEvents()              ''応答なし対応
                outArray = GetDelListWriteArray(xlListSheet,
                                                dtTbl1Tbl2,
                                                dtTbl3Year1,
                                                dtTbl3Year2,
                                                dtTbl3Month1,
                                                dtTbl3Month2)

                ''変更履歴情報ｼｰﾄ更新
                Application.DoEvents()              ''応答なし対応
                Dim copyArea As String
                copyArea = "A@Str:MU@End".Replace("@Str", ConList_OutRow) _
                                         .Replace("@End", ConList_OutRow + dtTbl1Tbl2.Select(filter.ToString).Length - 1)
                xlCell = xlListSheet.Range(copyArea)
                xlCell.FormulaR1C1 = outArray
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            End If
            '年額月額展開可変設定
            Call ExcelWrite.CreatePaymentPeriod(xlListSheet,
                                                ExcelWrite.chgExcelColumnIdxToChar(DelListColumn.PRICE_YEAR1_MONTH1),
                                                CommonVariable.PaymentPeriod)

            Dim intLastRow As Integer
            intLastRow = ExcelWrite.GetLastRow(xlListSheet, 1)
            If intLastRow < 6 Then
                intLastRow = 5
            End If
            xlCell = xlListSheet.Cells(intLastRow + 1, 1)
            xlCell.Value = "End of Data"

            'A1にカーソル
            xlListSheet.Activate()
            xlCell = xlListSheet.Range("A1")
            xlCell.Select()
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlListSheet, ExcelObjRelease.OBJECT_NOTHING)

            ''BookのSave
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            Call xlConListBook.Save()

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlListSheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlConListBook) = False Then
                Call xlConListBook.Close()
            End If

            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            ExcelObjRelease.ReleaseExcelObj(xlConListBook, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlApp) = False Then
                Call xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try
    End Sub

    Private Sub ProtectSheet(ByRef xlSheet As Excel.Worksheet, _
                             ByVal excelPW As String)

        Dim xlCellUsed As Excel.Range = Nothing
        Dim xlRange As Excel.Range = Nothing
        Dim strCol As String
        Dim strRow As String
        Dim intEndCol As Integer
        Dim intEndRow As Integer
        Dim strRange As String

        Try
            'LOCK範囲取得
            xlCellUsed = xlSheet.UsedRange
            strCol = xlCellUsed.Column
            strRow = xlCellUsed.Row
            intEndCol = xlCellUsed.Columns.Count + xlCellUsed.Column - 1
            intEndRow = xlCellUsed.Rows.Count + xlCellUsed.Row - 1
            ExcelObjRelease.ReleaseExcelObj(xlCellUsed, ExcelObjRelease.OBJECT_NOTHING)

            'LOCK制御
            strRange = ExcelWrite.R1ToA1(strRow, strCol) & ":" & ExcelWrite.R1ToA1(intEndRow, intEndCol)
            xlRange = xlSheet.Range(strRange)
            xlRange.Locked = True

            'シートロック
            xlSheet.Protect(Password:=excelPW, _
                          DrawingObjects:=True, _
                          Contents:=True, _
                          Scenarios:=True, _
                          UserInterfaceOnly:=True, _
                          AllowFormattingCells:=True, _
                          AllowFormattingColumns:=True, _
                          AllowFormattingRows:=True, _
                          AllowInsertingColumns:=False, _
                          AllowInsertingRows:=False, _
                          AllowInsertingHyperlinks:=False, _
                          AllowDeletingColumns:=False, _
                          AllowDeletingRows:=False, _
                          AllowSorting:=False, _
                          AllowFiltering:=True, _
                          AllowUsingPivotTables:=False)

        Catch ex As Exception
            Throw ex
        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCellUsed, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try

    End Sub

    ''' <summary>
    ''' 機能：データをMDBにセット
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetMdbCheckDelete()

        Dim con As New ADODB.Connection
        Dim strCon As String
        Dim strMdbPath As String
        Dim mmc As New MasterMdbControl

        Try
            '接続の作成
            con = mmc.GetAdoTmpDBConnection(CommonVariable.CPNO, CommonVariable.MdbPW)

            'PaymentTBL1,PaymentTBL2,PaymentTBL3をコピー
            Call CopyMdbPaymentData(con)

            'Payment(Excel)をMDBにセット
            Call SetPaymentExcelToMdb(con)

        Catch ex As Exception
            Debug.Print(ex.Message.ToString & "(SetMdbCheckDelete)")
            If ex.Message.ToString.IndexOf("Could not find file") <> -1 Then
                Throw New Exception(FileReader.GetMessage("MSG_0529"))
            Else
                Throw ex
            End If
        Finally
            If con.State <> ADODB.ObjectStateEnum.adStateClosed Then
                con.Close()
            End If
        End Try

    End Sub

    ''' <summary>
    ''' 機能：Payment(Excel)をMDBにセット
    ''' </summary>
    ''' <param name="con"></param>
    ''' <remarks></remarks>
    Private Sub CopyMdbPaymentData(ByVal con As ADODB.Connection)

        Dim cmd As New ADODB.Command

        Try
            cmd.ActiveConnection = con

            'CheckPaymentTBL1～3削除
            cmd.CommandText = "delete from CheckPaymentTBL1"
            cmd.Execute()
            cmd.CommandText = "delete from CheckPaymentTBL2"
            cmd.Execute()
            cmd.CommandText = "delete from CheckPaymentTBL3"
            cmd.Execute()

            'PaymentTBL1
            cmd.CommandText = "insert into CheckPaymentTBL1 select * from PaymentTBL1"
            cmd.Execute()
            'PaymentTBL2
            cmd.CommandText = "insert into CheckPaymentTBL2 select * from PaymentTBL2"
            cmd.Execute()
            'PaymentTBL3
            cmd.CommandText = "insert into CheckPaymentTBL3 select * from PaymentTBL3"
            cmd.Execute()

        Catch ex As Exception
            Debug.Print(ex.Message.ToString & "(CopyMdbPaymentData)")
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' 機能：Payment(Excel)をMDBにセット
    ''' </summary>
    ''' <param name="con"></param>
    ''' <remarks></remarks>
    Private Sub SetPaymentExcelToMdb(ByVal con As ADODB.Connection)

        Dim rsCount As New ADODB.Recordset
        Dim rsTbl1 As New ADODB.Recordset
        Dim rsTbl2 As New ADODB.Recordset
        Dim rsTbl3 As New ADODB.Recordset
        Dim strSQL As String
        Dim intIdCnt As Integer
        Dim strStartYear As String
        Dim xlApp As New Excel.Application
        Dim xlBook As Excel.Workbook
        Dim xlSheet As Excel.Worksheet
        Dim xlRange As Excel.Range

        Try
            'IDの最大値取得
            strSQL = "select max(id) from CheckPaymentTBL1"
            rsCount.Open(strSQL, con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)
            If IsDBNull(rsCount.Fields(0).Value) = False Then
                intIdCnt = Integer.Parse(rsCount.Fields(0).Value)
            End If
            rsCount.Close()

            strSQL = "select * from CheckPaymentTBL1"
            rsTbl1.Open(strSQL, con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)
            strSQL = "select * from CheckPaymentTBL2"
            rsTbl2.Open(strSQL, con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)
            strSQL = "select * from CheckPaymentTBL3"
            rsTbl3.Open(strSQL, con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)

            xlApp.EnableEvents = False
            xlApp.DisplayAlerts = False
            xlApp.ScreenUpdating = False
            xlBook = xlApp.Workbooks.Open(txb_InputFile.Text)
            xlSheet = xlBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)

            '開始年取得
            xlRange = xlSheet.Cells(4, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1)
            strStartYear = xlRange.Value
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)

            'Payment情報をTBLにセット
            Dim idx As Long
            Dim lineValue(,) As Object
            For idx = EXCEL_PAYMENTLINEDATE_OUTROW To xlSheet.Rows.Count
                '-----------------------------------------
                'Paymenet(Excel)からデータ取得
                '-----------------------------------------
                '1行取得
                xlRange = xlSheet.Range(ExcelWrite.EXCEL_PAYMENT_LINE_RANGE.Replace("@", idx))
                lineValue = xlRange.Value
                ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)

                'Eof確認
                If ExcelWrite.changeDBNullToString(lineValue(1, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)) = "" Then
                    Exit For
                End If

                '対象外
                If ExcelWrite.changeDBNullToString(lineValue(1, ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG)) = "C" Or _
                   ExcelWrite.changeDBNullToString(lineValue(1, ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG)) = "C" Or _
                   ExcelWrite.changeDBNullToString(lineValue(1, ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG)) = "N" Or _
                   ExcelWrite.changeDBNullToString(lineValue(1, ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD)) = "29" Or _
                   ExcelWrite.changeDBNullToString(lineValue(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10)).IndexOf(ProdItem10_Value_DelNo) = -1 Then
                    Continue For
                End If

                '-----------------------------------------
                'データセット
                '-----------------------------------------
                intIdCnt = intIdCnt + 1
                'PaymentTBL1
                rsTbl1.AddNew()
                Call SetTBL1Record(intIdCnt, rsTbl1, lineValue)
                rsTbl1.Fields(ChkList_ColumnNM_FileKB).Value = FileKB_Value_EXCEL
                rsTbl1.Update()
                'PaymentTBL2
                rsTbl2.AddNew()
                Call SetTBL2Record(intIdCnt, rsTbl2, lineValue)
                rsTbl2.Update()
                'PaymentTBL3
                Call SetTBL3Record(intIdCnt, rsTbl3, lineValue, strStartYear)
            Next
            Call rsTbl3.Close()
            Call rsTbl2.Close()
            Call rsTbl1.Close()


        Catch ex As Exception
            Debug.Print(ex.Message.ToString & "(SetPaymentExcelToMdb)")
            Throw ex
        Finally
            'Excel関連解放
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBook) = False Then
                xlBook.Close()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)

            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            xlApp.ScreenUpdating = True

            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            'MDB関連解放
            If rsCount.State <> ADODB.ObjectStateEnum.adStateClosed Then
                rsCount.Close()
            End If
            If rsTbl1.State <> ADODB.ObjectStateEnum.adStateClosed Then
                rsTbl1.Close()
            End If
            If rsTbl2.State <> ADODB.ObjectStateEnum.adStateClosed Then
                rsTbl2.Close()
            End If
            If rsTbl3.State <> ADODB.ObjectStateEnum.adStateClosed Then
                rsTbl3.Close()
            End If

            GC.Collect()
        End Try

    End Sub

    ''' <summary>
    ''' 機能：データをMDBにセット
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetMdbOutConList()

        Dim con As New ADODB.Connection
        Dim strCon As String
        Dim strMdbPath As String
        Dim mmc As New MasterMdbControl

        Try
            '接続の作成
            con = mmc.GetAdoTmpDBConnection(CommonVariable.CPNO, CommonVariable.MdbPW)

            'PaymentTBL1,PaymentTBL2,PaymentTBL3をコピー
            Call CopyMdbforOutConList(con)

        Catch ex As Exception
            Debug.Print(ex.Message.ToString & "(SetMdbOutConList)")
            Throw ex
        Finally
            If con.State <> ADODB.ObjectStateEnum.adStateClosed Then
                con.Close()
            End If
        End Try

    End Sub

    ''' <summary>
    ''' 機能：対象データを作業用テーブルへコピー
    ''' </summary>
    ''' <param name="con"></param>
    ''' <remarks></remarks>
    Private Sub CopyMdbforOutConList(ByVal con As ADODB.Connection)

        Dim cmd As New ADODB.Command
        Dim sSQL As New StringBuilder

        Try
            'MDBのConnection
            cmd.ActiveConnection = con

            'CheckPaymentTBL1削除
            cmd.CommandText = "delete from CheckPaymentTBL1"
            cmd.Execute()

            'CheckPaymentTBL2削除
            cmd.CommandText = "delete from CheckPaymentTBL2"
            cmd.Execute()

            'CheckPaymentTBL3削除
            cmd.CommandText = "delete from CheckPaymentTBL3"
            cmd.Execute()

            'PaymentTBL1
            sSQL = GetInsertSQL()
            cmd.CommandText = sSQL.ToString
            cmd.Execute()

            'PaymentTBL2
            cmd.CommandText = "insert into CheckPaymentTBL2 select * from PaymentTBL2"
            cmd.Execute()

            'PaymentTBL3
            cmd.CommandText = "insert into CheckPaymentTBL3 select * from PaymentTBL3"
            cmd.Execute()

        Catch ex As Exception
            Debug.Print(ex.Message.ToString & "(CopyMdbforOutConList)")
            Throw ex
        Finally
        End Try

    End Sub

    ''' <summary>
    ''' 機能：契約履歴チェックリスト用データをワークテーブルへコピーするSQLを生成
    ''' </summary>
    ''' <param name="con"></param>
    ''' <remarks></remarks>
    Private Function GetInsertSQL() As StringBuilder

        Dim sSQL As New StringBuilder

        sSQL.Append("INSERT INTO CheckPaymentTBL1")
        sSQL.Append(" SELECT TBL.*")
        sSQL.Append(" FROM (SELECT")
        sSQL.Append(" ID")
        sSQL.Append(" ,UPDATE_FLAG")
        sSQL.Append(" ,LOCK_FLAG")
        sSQL.Append(" ,VALID_FLAG")
        sSQL.Append(" ,LINE_NO")
        sSQL.Append(" ,FILE_NAME")
        sSQL.Append(" ,FILE_NAME_SUFFIX")
        sSQL.Append(" ,FILE_NAME_SUFFIX_INTR")
        sSQL.Append(" ,CONTRACT")
        sSQL.Append(" ,ST_COST")
        sSQL.Append(" ,ST_APPROVAL")
        sSQL.Append(" ,PROJ_ID")
        sSQL.Append(" ,CONTRACT_SEQ")
        sSQL.Append(" ,NEW_EXIST")
        sSQL.Append(" ,CUST_CATEGORY")
        sSQL.Append(" ,LETTER_PLAN_DATE")
        sSQL.Append(" ,LETTER_ACCEPT_DATE")
        sSQL.Append(" ,ORDER_DATE")
        sSQL.Append(" ,LETTER_ID")
        sSQL.Append(" ,BILLING_CD")
        sSQL.Append(" ,BU")
        sSQL.Append(" ,BRAND")
        sSQL.Append(" ,SUM_CATEGORY")
        sSQL.Append(" ,BRAND_SUB")
        sSQL.Append(" ,T_OP1")
        sSQL.Append(" ,T_OP2")
        sSQL.Append(" ,T_SIZE")
        sSQL.Append(" ,NON_SBO")
        sSQL.Append(" ,ADDITION_ITEM")
        sSQL.Append(" ,TOPACS_CPNO")
        sSQL.Append(" ,BRAND_AP_FORM")
        sSQL.Append(" ,BRAND_AP_REQ")
        sSQL.Append(" ,BRAND_AP_CONF")
        sSQL.Append(" ,PATTERN_CD")
        sSQL.Append(" ,PATTERN")
        sSQL.Append(" ,PROD_ITEM01")
        sSQL.Append(" ,PROD_ITEM02")
        sSQL.Append(" ,PROD_ITEM03")
        sSQL.Append(" ,PROD_ITEM04")
        sSQL.Append(" ,PROD_ITEM05")
        sSQL.Append(" ,PROD_ITEM06")
        sSQL.Append(" ,PROD_ITEM07")
        sSQL.Append(" ,PROD_ITEM08")
        sSQL.Append(" ,PROD_ITEM09")
        sSQL.Append(" ,PROD_ITEM10")
        sSQL.Append(" ,PROD_ITEM11")
        sSQL.Append(" ,PROD_ITEM12")
        sSQL.Append(" ,PROD_ITEM13")
        sSQL.Append(" ,PROD_ITEM14")
        sSQL.Append(" ,PROD_ITEM15")
        sSQL.Append(" ,PROD_ITEM16")
        sSQL.Append(" ,PROD_ITEM17")
        sSQL.Append(" ,PROD_ITEM18")
        sSQL.Append(" ,PROD_ITEM19")
        sSQL.Append(" ,PROD_ITEM20")
        sSQL.Append(" ,PROD_ITEM22")
        sSQL.Append(" ,PROD_ITEM23")
        sSQL.Append(" ,PROD_ITEM24")
        sSQL.Append(" FROM")
        sSQL.Append("     PaymentTBL1")
        sSQL.Append(" WHERE ")
        sSQL.Append("     NOT(")
        sSQL.Append("         VALID_FLAG IN ('C', 'N')")
        sSQL.Append("         Or")
        sSQL.Append("         PATTERN_CD = '29'")
        sSQL.Append("     )")
        sSQL.Append("     AND")
        sSQL.Append("     (")
        sSQL.Append("         VALID_FLAG IN ('B', 'D')")
        sSQL.Append("         OR")
        sSQL.Append("         (")
        sSQL.Append("             PROD_ITEM10 Like '削除元NO = %'")
        sSQL.Append("             Or")
        sSQL.Append("             PROD_ITEM10 Like 'ｺﾋﾟｰ元NO = %'")
        sSQL.Append("         )")
        sSQL.Append("     )")
        sSQL.Append(" UNION")
        sSQL.Append(" SELECT")
        sSQL.Append(" TBL1.ID")
        sSQL.Append(" ,TBL1.UPDATE_FLAG")
        sSQL.Append(" ,TBL1.LOCK_FLAG")
        sSQL.Append(" ,TBL1.VALID_FLAG")
        sSQL.Append(" ,TBL1.LINE_NO")
        sSQL.Append(" ,TBL1.FILE_NAME")
        sSQL.Append(" ,TBL1.FILE_NAME_SUFFIX")
        sSQL.Append(" ,TBL1.FILE_NAME_SUFFIX_INTR")
        sSQL.Append(" ,TBL1.CONTRACT")
        sSQL.Append(" ,TBL1.ST_COST")
        sSQL.Append(" ,TBL1.ST_APPROVAL")
        sSQL.Append(" ,TBL1.PROJ_ID")
        sSQL.Append(" ,TBL1.CONTRACT_SEQ")
        sSQL.Append(" ,TBL1.NEW_EXIST")
        sSQL.Append(" ,TBL1.CUST_CATEGORY")
        sSQL.Append(" ,TBL1.LETTER_PLAN_DATE")
        sSQL.Append(" ,TBL1.LETTER_ACCEPT_DATE")
        sSQL.Append(" ,TBL1.ORDER_DATE")
        sSQL.Append(" ,TBL1.LETTER_ID")
        sSQL.Append(" ,TBL1.BILLING_CD")
        sSQL.Append(" ,TBL1.BU")
        sSQL.Append(" ,TBL1.BRAND")
        sSQL.Append(" ,TBL1.SUM_CATEGORY")
        sSQL.Append(" ,TBL1.BRAND_SUB")
        sSQL.Append(" ,TBL1.T_OP1")
        sSQL.Append(" ,TBL1.T_OP2")
        sSQL.Append(" ,TBL1.T_SIZE")
        sSQL.Append(" ,TBL1.NON_SBO")
        sSQL.Append(" ,TBL1.ADDITION_ITEM")
        sSQL.Append(" ,TBL1.TOPACS_CPNO")
        sSQL.Append(" ,TBL1.BRAND_AP_FORM")
        sSQL.Append(" ,TBL1.BRAND_AP_REQ")
        sSQL.Append(" ,TBL1.BRAND_AP_CONF")
        sSQL.Append(" ,TBL1.PATTERN_CD")
        sSQL.Append(" ,TBL1.PATTERN")
        sSQL.Append(" ,TBL1.PROD_ITEM01")
        sSQL.Append(" ,TBL1.PROD_ITEM02")
        sSQL.Append(" ,TBL1.PROD_ITEM03")
        sSQL.Append(" ,TBL1.PROD_ITEM04")
        sSQL.Append(" ,TBL1.PROD_ITEM05")
        sSQL.Append(" ,TBL1.PROD_ITEM06")
        sSQL.Append(" ,TBL1.PROD_ITEM07")
        sSQL.Append(" ,TBL1.PROD_ITEM08")
        sSQL.Append(" ,TBL1.PROD_ITEM09")
        sSQL.Append(" ,TBL1.PROD_ITEM10")
        sSQL.Append(" ,TBL1.PROD_ITEM11")
        sSQL.Append(" ,TBL1.PROD_ITEM12")
        sSQL.Append(" ,TBL1.PROD_ITEM13")
        sSQL.Append(" ,TBL1.PROD_ITEM14")
        sSQL.Append(" ,TBL1.PROD_ITEM15")
        sSQL.Append(" ,TBL1.PROD_ITEM16")
        sSQL.Append(" ,TBL1.PROD_ITEM17")
        sSQL.Append(" ,TBL1.PROD_ITEM18")
        sSQL.Append(" ,TBL1.PROD_ITEM19")
        sSQL.Append(" ,TBL1.PROD_ITEM20")
        sSQL.Append(" ,TBL1.PROD_ITEM22")
        sSQL.Append(" ,TBL1.PROD_ITEM23")
        sSQL.Append(" ,TBL1.PROD_ITEM24")
        sSQL.Append(" FROM")
        sSQL.Append("     PaymentTBL1 TBL1")
        sSQL.Append("     inner join (")
        sSQL.Append("      SELECT")
        sSQL.Append("          iif(instr(PROD_ITEM10, '削除元NO =') > 0, mid(PROD_ITEM10, 9, 8), iif(instr(PROD_ITEM10, 'ｺﾋﾟｰ元NO = ') > 0, mid(PROD_ITEM10, 11, 8), '@@@@@@@@')) as sub_line")
        sSQL.Append("      FROM")
        sSQL.Append("          PaymentTBL1")
        sSQL.Append("      WHERE ")
        sSQL.Append("          NOT(")
        sSQL.Append("              VALID_FLAG IN ('C', 'N')")
        sSQL.Append("              Or")
        sSQL.Append("              PATTERN_CD = '29'")
        sSQL.Append("          )")
        sSQL.Append("          AND")
        sSQL.Append("          (")
        sSQL.Append("              VALID_FLAG IN ('B', 'D')")
        sSQL.Append("              Or")
        sSQL.Append("              (")
        sSQL.Append("                  PROD_ITEM10 Like '削除元NO = %'")
        sSQL.Append("                  Or")
        sSQL.Append("                  PROD_ITEM10 Like 'ｺﾋﾟｰ元NO = %'")
        sSQL.Append("              )")
        sSQL.Append("          )")
        sSQL.Append("     ) TBL")
        sSQL.Append("     ON TBL1.LINE_NO = TBL.SUB_LINE")
        sSQL.Append(" WHERE ")
        sSQL.Append("     NOT(")
        sSQL.Append("         TBL1.VALID_FLAG IN ('C', 'N')")
        sSQL.Append("         Or")
        sSQL.Append("         TBL1.PATTERN_CD = '29'")
        sSQL.Append("     )")
        sSQL.Append("     AND")
        sSQL.Append("     NOT (")
        sSQL.Append("         TBL1.PROD_ITEM10 Like '削除元NO = %'")
        sSQL.Append("         Or")
        sSQL.Append("         TBL1.PROD_ITEM10 Like 'ｺﾋﾟｰ元NO = %'")
        sSQL.Append("         OR")
        sSQL.Append("         TBL1.VALID_FLAG IN ('B', 'D')")
        sSQL.Append("     )")
        sSQL.Append(" )  AS TBL;")

        Return sSQL

    End Function

    ''' <summary>
    ''' 機能：契約履歴チェックリスト取得
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Sub GetOutConListDate(ByRef dtTbl1Tbl2 As DataTable,
                                  ByRef dtTbl3Year1 As DataTable,
                                  ByRef dtTbl3Year2 As DataTable,
                                  ByRef dtTbl3Month1 As DataTable,
                                  ByRef dtTbl3Month2 As DataTable)

        Dim mmc As New MasterMdbControl
        Dim con As OleDbConnection
        Dim strYear As String
        Dim cmd As OleDbCommand
        Dim adpt As OleDbDataAdapter
        Dim intCnt As Integer

        Try
            Application.DoEvents()              ''応答なし対応

            'MDBのConnection
            con = mmc.GetOleTmpDBConnection(CommonVariable.CPNO, CommonVariable.MdbPW)
            cmd = New OleDbCommand
            cmd.Connection = con

            '------------------------------------------------
            'PaymentTBL1,PaymentTBL2（過去の合計金額以外）
            '------------------------------------------------
            'クエリでデータ取得
            cmd.CommandText = "ContractHistory_PT1PT2"
            cmd.CommandType = CommandType.StoredProcedure
            adpt = New OleDbDataAdapter(cmd)
            adpt.Fill(dtTbl1Tbl2)

            'カラム追加＋初期化
            Dim dcItem10No As New DataColumn(ChkList_ColumnNM_Item10No, Type.GetType("System.String"))
            dcItem10No.DefaultValue = ""
            dtTbl1Tbl2.Columns.Add(dcItem10No)
            Dim dcBaseNo As New DataColumn(ChkList_ColumnNM_BaseNo, Type.GetType("System.String"))
            dcBaseNo.DefaultValue = ""
            dtTbl1Tbl2.Columns.Add(dcBaseNo)
            Dim dcRefNo As New DataColumn(ChkList_ColumnNM_RefNo, Type.GetType("System.String"))
            dcRefNo.DefaultValue = ""
            dtTbl1Tbl2.Columns.Add(dcRefNo)
            Dim dcCheckItem As New DataColumn(ChkList_ColumnNM_CheckItem, Type.GetType("System.String"))
            dcCheckItem.DefaultValue = ""
            dtTbl1Tbl2.Columns.Add(dcCheckItem)

            'Item10No加工
            Call UpdateItem10No(dtTbl1Tbl2)

            '------------------------------------------------
            'PaymentTBL3（年額展開（1年目から10年目））
            '------------------------------------------------
            'クエリでデータ取得
            cmd.CommandText = "ContractHistory_PT3_YEAR1"
            cmd.CommandType = CommandType.StoredProcedure
            strYear = CommonVariable.PaymentStart.ToString("yyyy")
            cmd.Parameters.Add("@1", strYear)
            adpt = New OleDbDataAdapter(cmd)
            adpt.Fill(dtTbl3Year1)

            '------------------------------------------------
            'PaymentTBL3（年額展開（11年目から20年目））、PaymentTBL2の過去の合計金額
            '------------------------------------------------
            'クエリでデータ取得
            cmd.CommandText = "ContractHistory_PT3_YEAR2"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@1", strYear)
            adpt = New OleDbDataAdapter(cmd)
            adpt.Fill(dtTbl3Year2)

            '------------------------------------------------
            'PaymentTBL3（月額展開（1年目から10年目））
            '------------------------------------------------
            'クエリでデータ取得
            cmd.CommandText = "ContractHistory_PT3_MONTH1"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@1", strYear)
            adpt = New OleDbDataAdapter(cmd)
            adpt.Fill(dtTbl3Month1)

            '------------------------------------------------
            'PaymentTBL3（月額展開（11年目から20年目））
            '------------------------------------------------
            'クエリでデータ取得
            cmd.CommandText = "ContractHistory_PT3_MONTH2"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@1", strYear)
            adpt = New OleDbDataAdapter(cmd)
            adpt.Fill(dtTbl3Month2)

        Catch ex As Exception
            Debug.Print(ex.Message.ToString & "(GetOutConListDate)")
            Throw ex
        Finally
            cmd.Dispose()

        End Try

    End Sub

    Private Sub SheetCopy(ByVal sumPaht As String, ByVal psPath As String)

        Const COPYRANGE_SUMMARY_ALL As String = "A1:MV@End"
        Const COPYRANGE_PAYMENT_ALL As String = "A1:MS@End"
        Const COPYRANGE_PAYMENT_TITLE As String = "A3:MV3"
        Const COPYRANGE_PAYMENT_LISTPRICE As String = "BU1:BU@End"
        Const COPYRANGE_DETAILE_ALL As String = "A1:IV@End"

        Dim xlApp As New Excel.Application
        Dim xlPsBook As Excel.Workbook
        Dim xlSumBook As Excel.Workbook
        Dim xlCopySheet As Excel.Worksheet
        Dim xlSheet As Excel.Worksheet
        Dim xlCell As Excel.Range
        Dim xlCopyCell As Excel.Range
        Dim xlUsedCell As Excel.Range
        Dim xlShape As Excel.Shape
        Try
            'BookOpen
            xlApp.Visible = False
            xlApp.EnableEvents = False
            xlApp.AskToUpdateLinks = False
            xlApp.DisplayAlerts = False
            xlPsBook = xlApp.Workbooks.Open(psPath)
            xlSumBook = xlApp.Workbooks.Open(sumPaht)
            '                       ｼｰﾄｺﾋﾟｰ
            '-------------------------------------------------------
            'WS1
            xlCopySheet = xlPsBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_WS1)
            xlSheet = xlSumBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)
            xlCopySheet.Copy(Before:=xlSheet)
            'Summary
            xlCopySheet = xlPsBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_SUMMARY)
            xlSheet = xlSumBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_SUMMARY)
            xlUsedCell = xlCopySheet.UsedRange
            xlCopyCell = xlCopySheet.Range(COPYRANGE_SUMMARY_ALL.Replace("@End", Split(xlUsedCell.Address, "$")(4)))
            xlCell = xlSheet.Range(xlCopyCell.Address)
            xlCopyCell.Copy()
            xlCell.PasteSpecial(Paste:=Excel.XlPasteType.xlPasteAll)
            'Payment
            xlCopySheet = xlPsBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)    '全SてAのIセZル?
            xlSheet = xlSumBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)
            xlUsedCell = xlCopySheet.UsedRange
            xlCopyCell = xlCopySheet.Range(COPYRANGE_PAYMENT_ALL.Replace("@End", Split(xlUsedCell.Address, "$")(4)))
            xlCell = xlSheet.Range(xlCopyCell.Address)
            xlCopyCell.Copy()
            xlCell.PasteSpecial(Paste:=Excel.XlPasteType.xlPasteFormulas)
            xlCell.PasteSpecial(Paste:=Excel.XlPasteType.xlPasteFormats)
            xlCopyCell = xlCopySheet.Range(COPYRANGE_PAYMENT_TITLE)                                 'タイトル
            xlCell = xlSheet.Range(COPYRANGE_PAYMENT_TITLE)
            xlCopyCell.Copy()
            xlCell.PasteSpecial(Paste:=Excel.XlPasteType.xlPasteValues)
            xlCell = xlSheet.Range(COPYRANGE_PAYMENT_LISTPRICE.Replace("@End", Split(xlUsedCell.Address, "$")(4)))                                 'ListPrice
            xlCopyCell = xlCopySheet.Range(xlCell.Address)
            xlCell.Copy()
            xlCopyCell.PasteSpecial(Paste:=Excel.XlPasteType.xlPasteValues)
            '詳U細×
            xlCopySheet = xlPsBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)
            xlSheet = xlSumBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)
            xlUsedCell = xlCopySheet.UsedRange
            xlCopyCell = xlCopySheet.Range(COPYRANGE_DETAILE_ALL.Replace("@End", Split(xlUsedCell.Address, "$")(4)))
            xlCell = xlSheet.Range(xlCopyCell.Address)
            xlCopyCell.Copy()
            xlCell.PasteSpecial(Paste:=Excel.XlPasteType.xlPasteValues)
            xlCell.PasteSpecial(Paste:=Excel.XlPasteType.xlPasteFormats)

            'ｼｪｲﾌﾟ削除
            xlSheet = xlSumBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_WS1)
            For Each xlShape In xlSheet.Shapes
                xlShape.Delete()
            Next
            xlSheet = xlSumBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_SUMMARY)
            For Each xlShape In xlSheet.Shapes
                xlShape.Delete()
            Next
            Call xlSumBook.Save()
        Catch ex As Exception
            Throw ex
        Finally
            ExcelObjRelease.ReleaseExcelObj(xlShape, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlUsedCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCopyCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCopySheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlSumBook) = False Then
                xlSumBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlSumBook, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlPsBook) = False Then
                xlPsBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlPsBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.Visible = True
            xlApp.EnableEvents = True
            xlApp.AskToUpdateLinks = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            GC.Collect()
        End Try
    End Sub

    'Req:1569 シリアル重複チェックリスト str
    ''' <summary>
    ''' 概 要：シリアル重複チェックリスト作成処理メイン
    ''' 説 明：
    ''' </summary>
    ''' <param name="OutFilePath">シリアル重複チェックリストファイル出力先パス</param>
    ''' <param name="waitDialog">処理中ダイアログオブジェクト</param>
    ''' <remarks></remarks>
    Private Function SerialCheckListOutput(ByVal OutFilePath As String, _
                                           ByVal waitDialog As Frm_WaitDialog) As String
        '===================================================
        'シリアル重複チェックリスト
        '===================================================
        Dim strSerialCheckFileName As String = ""
        Dim wRet As Boolean

        'ファイルの作成日時
        Dim createTime As String
        createTime = Now.ToString("_yyyyMMdd_HHmmss")

        'シリアル重複チェックリストファイル名編集
        strSerialCheckFileName = OutFilePath & CommonVariable.CPNO & "_ｼﾘｱﾙ重複ﾁｪｯｸﾘｽﾄ" & "_" & createTime & ".xlsm"

        'Templateをコピーする。
        System.IO.File.Copy(OUTPUT_TEMPLATEFOLDER & "\" & SerialCheckTemplate, strSerialCheckFileName, True)

        ''シリアル重複チェックリストを作成する。
        wRet = MakeSerialCheckList(strSerialCheckFileName, _
                                   waitDialog)

        If wRet = True Then
            SerialCheckListOutput = strSerialCheckFileName
        Else
            SerialCheckListOutput = ""
        End If

    End Function


    ''' <summary>
    ''' 概 要：シリアル重複チェックリストを作成する。
    ''' 説 明：
    ''' </summary>
    ''' <param name="ExtensionFilePath">シリアル重複チェックリストファイルフルパス(出力)</param>
    ''' <param name="waitDialog">処理中ダイアログオブジェクト</param>
    ''' <remarks></remarks>
    Private Function MakeSerialCheckList(ByVal SerialCheckFilePath As String, _
                                         ByVal waitDialog As Frm_WaitDialog) As Boolean

        ''Excel変数の宣言
        Dim xlApp As New Excel.Application
        Dim xlBooks As Excel.Workbooks
        Dim xlSerBook As Excel.Workbook
        Dim xlPSBook As Excel.Workbook
        Dim xlSerSheets As Excel.Sheets
        Dim xlPSSheets As Excel.Sheets
        Dim xlSerSheet As Excel.Worksheet
        Dim xlCell As Excel.Range
        Dim xlName As Excel.Name
        Dim xlNames As Excel.Names

        Dim wRet As Boolean
        Dim wStr As String
        Dim wDate As Date

        Dim con As New OleDbConnection
        Dim strErrMsg As String
        Dim arDelId As New ArrayList

        Dim PSDataTable As PSExcelDataTable
        Dim PSDataTable2 As New PSExcelDataTable

        Try
            MakeSerialCheckList = False

            ''App設定
            xlApp.EnableEvents = False
            xlApp.DisplayAlerts = False

            Schk_PS_Cnt = 0
            Schk_DB_Cnt = 0
            Schk_W_Cnt = 0

            '''' 処理：TempMDB Open
            Dim mmc As New MasterMdbControl
            con = mmc.GetOleTmpDBConnection(CommonVariable.CPNO, CommonVariable.MdbPW)

            '--------------------------------------------------
            '契約済みMDBから削除済みデータを検索(DelFlg=1が削除済みデータ)
            '--------------------------------------------------
            wRet = GetDuplicateId(con, arDelId, strErrMsg)
            If wRet = False Then
                Exit Function
            End If

            '--------------------------------------------------
            '契約済み、作成中のPaymentデータをMDBにセット(対象条件で絞込み)
            '--------------------------------------------------
            Call SetMdbCheckSerial(arDelId)

            If Schk_PS_Cnt = 0 Then
                Throw New Exception(FileReader.GetMessage("MSG_0563"))
                Exit Function
            End If

            If Schk_DB_Cnt = 0 Then
                Throw New Exception(FileReader.GetMessage("MSG_0564"))
                Exit Function
            End If

            'Req.1690 シリアル重複チェックリスト変更 2018/12 Str
            '--------------------------------------------------
            'MDBにサービス名称付与
            '--------------------------------------------------
            Call MakeSvcName()
            'Req.1690 シリアル重複チェックリスト変更 2018/12 End

            '--------------------------------------------------
            '作成中と契約済PaymentのMTDL+SERIAL重複データチェック
            '--------------------------------------------------
            Call CheckMTDLSerial()

            If Schk_W_Cnt = 0 Then
                Throw New Exception(FileReader.GetMessage("MSG_0564"))
                Exit Function
            End If

            ''------------------------------------------------------------------
            ''      各情報取得
            ''------------------------------------------------------------------
            'TBL1 - 3のデータをデータテーブルに集約   
            PSDataTable = GetSerialCheckPSDataTable()

            If IsNothing(PSDataTable) Then
                '該当データ無し
                MuseMessageBox.ShowWarning(FileReader.GetMessage("MSG_0282"), Me.Text)
                Exit Function
            End If

            ''------------------------------------------------------------------
            ''      シート取得
            ''------------------------------------------------------------------
            'シリアル重複チェックリスト取得
            xlBooks = xlApp.Workbooks
            xlSerBook = xlBooks.Open(SerialCheckFilePath)
            xlSerSheets = xlSerBook.Worksheets
            xlSerSheet = xlSerSheets.Item(SHEET_NAME_SerialChk)

            '※ここでウェイトを入れないと無応答になる場合あり
            Application.DoEvents()
            waitDialog.PerformStep()

            ''各行情報を判定・編集する
            'PSDataTable = EditSerialCheckRowInfo(PSDataTable)
            'waitDialog.PerformStep()

            '------------------------------------------------------------------
            '      データテーブルソート
            '------------------------------------------------------------------
            'ソート処理
            Dim tempView As DataView = New DataView(PSDataTable)
            Dim tempTable As DataTable
            tempView.Sort = "SortAsc01 ASC , " & _
                            "SortAsc02 ASC ," & _
                            "SortAsc03 ASC ," & _
                            "SortAsc04 ASC ," & _
                            "SortAsc05 ASC ," & _
                            "SortAsc06 ASC ," & _
                            "SortAsc07 ASC ," & _
                            "SortDsc01 DESC ," & _
                            "SortDsc02 DESC ," & _
                            "SortDsc03 DESC "

            'ソート後の値をテーブルに格納する。
            tempTable = tempView.ToTable()

            '使用済テーブルを開放する
            PSDataTable = Nothing
            waitDialog.PerformStep()
            Application.DoEvents()

            '------------------------------------------------------------------
            '      データ出力
            '------------------------------------------------------------------
            'シリアル重複チェックリストにデータをセットする
            Call MakeSerialCheckListData(tempTable, xlSerSheet)

            waitDialog.PerformStep()

            Application.DoEvents()

            ''------------------------------------------------------------------
            ''      Book保存
            ''------------------------------------------------------------------
            '各シート先頭に位置付け
            xlSerSheet.Activate()
            xlCell = xlSerSheet.Cells(1, 1)
            xlApp.Goto(xlCell)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            waitDialog.PerformStep()

            'セーブ
            xlSerBook.Save()

            MakeSerialCheckList = True

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, Me.Text)
        Finally
            ExcelObjRelease.ReleaseExcelObj(xlName, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlNames, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSerSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSerSheets, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPSSheets, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.DisplayAlerts = False
            If IsNothing(xlPSBook) = False Then
                xlPSBook.Close()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.DisplayAlerts = False
            If IsNothing(xlSerBook) = False Then
                xlSerBook.Close()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlSerBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlBooks, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            '            GC.Collect()

        End Try

    End Function

    ''' <summary>
    ''' 機能：PaymentデータをMDBにセット(シリアル重複チェック用)
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetMdbCheckSerial(ByRef arDelFlg As ArrayList)

        Dim con As New ADODB.Connection
        Dim strCon As String
        Dim strMdbPath As String
        Dim mmc As New MasterMdbControl

        Try
            '接続の作成
            con = mmc.GetAdoTmpDBConnection(CommonVariable.CPNO, CommonVariable.MdbPW)

            'PaymentTBL1,PaymentTBL2,PaymentTBL3をコピー
            Call CopyMdbPaymentDataS(con, arDelFlg)

            'Payment(Excel)をMDBにセット
            Call SetPaymentExcelToMdbS(con)

        Catch ex As Exception
            Debug.Print(ex.Message.ToString & "(SetMdbCheckSerial)")
            If ex.Message.ToString.IndexOf("Could not find file") <> -1 Then
                Throw New Exception(FileReader.GetMessage("MSG_0529"))
            Else
                Throw ex
            End If
        Finally
            If con.State <> ADODB.ObjectStateEnum.adStateClosed Then
                con.Close()
            End If
        End Try

    End Sub

    ''' <summary>
    ''' 機能：PaymentをMDBにセット(シリアル重複チェック用)
    ''' </summary>
    ''' <param name="con"></param>
    ''' <remarks></remarks>
    Private Sub CopyMdbPaymentDataS(ByVal con As ADODB.Connection, ByRef arDelFlg As ArrayList)

        Dim cmd As New ADODB.Command
        Dim strSQL As String
        Dim strID As String
        Dim Idx As Long
        Dim Idx2 As Long
        Dim rsTbl1 As New ADODB.Recordset
        Dim DelFlg As Boolean

        Try
            cmd.ActiveConnection = con

            'SerialCheckPaymentTBL1～3削除
            cmd.CommandText = "delete from SerialCheckPaymentTBL1"
            cmd.Execute()
            cmd.CommandText = "delete from SerialCheckPaymentTBL2"
            cmd.Execute()
            cmd.CommandText = "delete from SerialCheckPaymentTBL3"
            cmd.Execute()

            'PaymentTBL1から対象のIDを取得
            strSQL = ""
            strSQL = strSQL & "SELECT ID, PROD_ITEM01, PROD_ITEM02 " & vbCrLf
            strSQL = strSQL & "FROM PaymentTBL1 " & vbCrLf
            strSQL = strSQL & "WHERE LOCK_FLAG='C' " & vbCrLf
            strSQL = strSQL & "AND (PATTERN_CD='15' " & vbCrLf
            strSQL = strSQL & " OR  PATTERN_CD='16' " & vbCrLf
            strSQL = strSQL & " OR  PATTERN_CD='17' " & vbCrLf
            strSQL = strSQL & " OR  PATTERN_CD='20' " & vbCrLf
            strSQL = strSQL & " OR  PATTERN_CD='21' " & vbCrLf
            strSQL = strSQL & " OR  PATTERN_CD='34' " & vbCrLf
            strSQL = strSQL & " OR  PATTERN_CD='43' " & vbCrLf
            strSQL = strSQL & " OR  PATTERN_CD='44') " & vbCrLf
            strSQL = strSQL & " AND PROD_ITEM01<>'' " & vbCrLf
            strSQL = strSQL & " AND PROD_ITEM02<>'' " & vbCrLf
            rsTbl1.Open(strSQL, con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)

            Idx = 0
            'SQL用の対象IDリストを作成
            Do Until rsTbl1.EOF = True

                DelFlg = False
                For Idx2 = 0 To arDelFlg.Count - 1
                    If rsTbl1.Fields("ID").Value = arDelFlg(Idx2) Then
                        DelFlg = True
                        Exit For
                    End If

                    If InStr(rsTbl1.Fields("PROD_ITEM02").Value, "@") > 0 Then
                        DelFlg = True
                        Exit For
                    End If

                Next Idx2
                If DelFlg = False Then
                    If strID = "" Then
                        strID = "'" & rsTbl1.Fields("ID").Value & "'"
                    Else
                        strID = strID & ",'" & rsTbl1.Fields("ID").Value & "'"
                    End If
                    Schk_DB_Cnt = Schk_DB_Cnt + 1
                End If
                rsTbl1.MoveNext()
            Loop

            Call rsTbl1.Close()

            If strID <> Nothing Then

                'PaymentTBL1
                cmd.CommandText = "insert into SerialCheckPaymentTBL1 select * from PaymentTBL1 where ID in (" & strID & ")"
                cmd.Execute()
                'PaymentTBL2
                cmd.CommandText = "insert into SerialCheckPaymentTBL2 select * from PaymentTBL2 where ID in (" & strID & ")"
                cmd.Execute()
                'PaymentTBL3
                cmd.CommandText = "insert into SerialCheckPaymentTBL3 select * from PaymentTBL3 where ID in (" & strID & ")"
                cmd.Execute()
            End If

        Catch ex As Exception
            Debug.Print(ex.Message.ToString & "(CopyMdbPaymentDataS)")
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' 機能：Payment(Excel)をMDBにセット(シリアル重複チェック用)
    ''' </summary>
    ''' <param name="con"></param>
    ''' <remarks></remarks>
    Private Sub SetPaymentExcelToMdbS(ByVal con As ADODB.Connection)

        Dim rsCount As New ADODB.Recordset
        Dim rsTbl1 As New ADODB.Recordset
        Dim rsTbl2 As New ADODB.Recordset
        Dim rsTbl3 As New ADODB.Recordset
        Dim strSQL As String
        Dim intIdCnt As Integer
        Dim strStartYear As String
        Dim xlApp As New Excel.Application
        Dim xlBook As Excel.Workbook
        Dim xlSheet As Excel.Worksheet
        Dim xlRange As Excel.Range

        Try
            'IDの最大値取得
            strSQL = "select max(id) from SerialCheckPaymentTBL1"
            rsCount.Open(strSQL, con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)
            If IsDBNull(rsCount.Fields(0).Value) = False Then
                intIdCnt = Integer.Parse(rsCount.Fields(0).Value)
            End If
            rsCount.Close()

            strSQL = "select * from SerialCheckPaymentTBL1"
            rsTbl1.Open(strSQL, con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)
            strSQL = "select * from SerialCheckPaymentTBL2"
            rsTbl2.Open(strSQL, con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)
            strSQL = "select * from SerialCheckPaymentTBL3"
            rsTbl3.Open(strSQL, con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)

            xlApp.EnableEvents = False
            xlApp.DisplayAlerts = False
            xlApp.ScreenUpdating = False
            xlBook = xlApp.Workbooks.Open(txb_InputFile.Text)
            xlSheet = xlBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)

            '開始年取得
            xlRange = xlSheet.Cells(4, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1)
            strStartYear = xlRange.Value
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)

            'Payment情報をTBLにセット
            Dim idx As Long
            Dim lineValue(,) As Object
            For idx = EXCEL_PAYMENTLINEDATE_OUTROW To xlSheet.Rows.Count
                '-----------------------------------------
                'Paymenet(Excel)からデータ取得
                '-----------------------------------------
                '1行取得
                xlRange = xlSheet.Range(ExcelWrite.EXCEL_PAYMENT_LINE_RANGE.Replace("@", idx))
                lineValue = xlRange.Value
                ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)

                'Eof確認
                If ExcelWrite.changeDBNullToString(lineValue(1, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)) = "" Then
                    Exit For
                End If

                '対象外
                If ExcelWrite.changeDBNullToString(lineValue(1, ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG)) = "C" Or _
                   ExcelWrite.changeDBNullToString(lineValue(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01)) = "" Or _
                   ExcelWrite.changeDBNullToString(lineValue(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02)) = "" Or _
                   ExcelWrite.changeDBNullToString(lineValue(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02)).IndexOf("@") > 1 Then
                    Continue For
                End If

                If ExcelWrite.changeDBNullToString(lineValue(1, ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD)) <> "15" And _
                   ExcelWrite.changeDBNullToString(lineValue(1, ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD)) <> "16" And _
                   ExcelWrite.changeDBNullToString(lineValue(1, ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD)) <> "17" And _
                   ExcelWrite.changeDBNullToString(lineValue(1, ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD)) <> "20" And _
                   ExcelWrite.changeDBNullToString(lineValue(1, ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD)) <> "21" And _
                   ExcelWrite.changeDBNullToString(lineValue(1, ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD)) <> "34" And _
                   ExcelWrite.changeDBNullToString(lineValue(1, ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD)) <> "43" And _
                   ExcelWrite.changeDBNullToString(lineValue(1, ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD)) <> "44" Then
                    Continue For
                End If

                '-----------------------------------------
                'データセット
                '-----------------------------------------
                intIdCnt = intIdCnt + 1
                Schk_PS_Cnt = Schk_PS_Cnt + 1

                'PaymentTBL1
                rsTbl1.AddNew()
                Call SetTBL1Record(intIdCnt, rsTbl1, lineValue)
                rsTbl1.Fields(ChkList_ColumnNM_FileKB).Value = FileKB_Value_EXCEL
                rsTbl1.Update()
                'PaymentTBL2
                rsTbl2.AddNew()
                Call SetTBL2Record(intIdCnt, rsTbl2, lineValue)
                rsTbl2.Update()
                'PaymentTBL3
                Call SetTBL3Record(intIdCnt, rsTbl3, lineValue, strStartYear)
            Next
            Call rsTbl3.Close()
            Call rsTbl2.Close()
            Call rsTbl1.Close()


        Catch ex As Exception
            Debug.Print(ex.Message.ToString & "(SetPaymentExcelToMdbS)")
            Throw ex
        Finally
            'Excel関連解放
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBook) = False Then
                xlBook.Close()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)

            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            xlApp.ScreenUpdating = True

            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            'MDB関連解放
            If rsCount.State <> ADODB.ObjectStateEnum.adStateClosed Then
                rsCount.Close()
            End If
            If rsTbl1.State <> ADODB.ObjectStateEnum.adStateClosed Then
                rsTbl1.Close()
            End If
            If rsTbl2.State <> ADODB.ObjectStateEnum.adStateClosed Then
                rsTbl2.Close()
            End If
            If rsTbl3.State <> ADODB.ObjectStateEnum.adStateClosed Then
                rsTbl3.Close()
            End If

            GC.Collect()
        End Try

    End Sub

    ''' <summary>
    ''' 削除済みIDを取得(シリアル重複ﾁｪｯｸﾘｽﾄ用)
    ''' </summary>
    ''' <param name="con">MDBのコネクション</param>
    ''' <param name="arDelFlg">削除済みID</param>
    ''' <param name="strErrMsg">エラーメッセージ</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetDuplicateId(ByVal con As OleDbConnection,
                                    ByRef arDelFlg As ArrayList,
                                    ByRef strErrMsg As String) As Boolean

        Dim strSQL As String
        Dim strSQLUpdate As String
        Dim cmd As New OleDbCommand
        Dim cmdUpdate As New OleDbCommand
        Dim dr As OleDbDataReader
        Dim drSelect As OleDbDataReader
        Dim strItem10No As String
        Dim strParentNo As String
        Dim strNowParentNo As String
        Dim strMyNo As String
        Dim arWhereIn As ArrayList
        Dim blnRet As Boolean

        GetDuplicateId = False

        Try
            cmd.Connection = con

            '''' 処理：DuplicateIdﾃｰﾌﾞﾙのﾃﾞｰﾀ削除
            strSQL = "DELETE FROM DuplicateId"
            cmd.CommandText = strSQL
            cmd.ExecuteNonQuery()

            '''' 処理：DuplicateIdﾃｰﾌﾞﾙにPaymentTBL1から必要なデータをInsert
            strSQL = ""
            strSQL = strSQL & "INSERT INTO DuplicateId (ID, VALID_FLAG, LINE_NO, PROD_ITEM10) " & vbCrLf
            strSQL = strSQL & "SELECT ID, VALID_FLAG, FORMAT(LINE_NO,'0000000000'), PROD_ITEM10 " & vbCrLf
            strSQL = strSQL & "FROM PaymentTBL1 " & vbCrLf
            strSQL = strSQL & "WHERE LOCK_FLAG='C' " & vbCrLf
            strSQL = strSQL & "AND (PATTERN_CD='15' " & vbCrLf
            strSQL = strSQL & " OR  PATTERN_CD='16' " & vbCrLf
            strSQL = strSQL & " OR  PATTERN_CD='17' " & vbCrLf
            strSQL = strSQL & " OR  PATTERN_CD='20' " & vbCrLf
            strSQL = strSQL & " OR  PATTERN_CD='21' " & vbCrLf
            strSQL = strSQL & " OR  PATTERN_CD='34' " & vbCrLf
            strSQL = strSQL & " OR  PATTERN_CD='43' " & vbCrLf
            strSQL = strSQL & " OR  PATTERN_CD='44') " & vbCrLf
            strSQL = strSQL & "AND VALID_FLAG='D' " & vbCrLf
            Debug.Print(strSQL)
            cmd.CommandText = strSQL
            cmd.ExecuteNonQuery()

            '''' 繰返し_開始	：項目１０にコピー元NO/削除元NOがあるもとに対して繰り返す
            cmdUpdate.Connection = con
            strSQL = ""
            strSQL = strSQL & "SELECT " & vbCrLf
            strSQL = strSQL & "ID, " & vbCrLf
            strSQL = strSQL & "PROD_ITEM10 " & vbCrLf
            strSQL = strSQL & "FROM DuplicateId " & vbCrLf
            strSQL = strSQL & "WHERE PROD_ITEM10 LIKE '" & ProdItem10_Value_CopyNo & "%' " & vbCrLf
            strSQL = strSQL & "or PROD_ITEM10 LIKE '" & ProdItem10_Value_DelNo & "%' " & vbCrLf
            cmd.CommandText = strSQL
            dr = cmd.ExecuteReader
            While dr.Read = True
                '''' 　条件：項目１０に削除元NO/コピー元NOがあるか判定
                '''' 　ケース：有る場合、削除元コピー元NOにNOで更新
                strItem10No = GetDbData(dr, "PROD_ITEM10")
                strItem10No = GetItem10No(strItem10No)
                If strItem10No <> "" Then
                    strSQLUpdate = ""
                    strSQLUpdate = strSQLUpdate & "UPDATE " & vbCrLf
                    strSQLUpdate = strSQLUpdate & "DuplicateId " & vbCrLf
                    strSQLUpdate = strSQLUpdate & "SET Item10NO = '" & strItem10No & "' " & vbCrLf
                    strSQLUpdate = strSQLUpdate & "WHERE ID='" & GetDbData(dr, "ID") & "' " & vbCrLf
                    cmdUpdate.CommandText = strSQLUpdate
                    cmdUpdate.ExecuteNonQuery()
                End If
            End While
            dr.Close()
            '''' 繰返し_終了	：

            '''' 繰返し_開始	：削除元コピー元にNOがあるものに対して繰り返す
            strSQL = ""
            strSQL = strSQL & "SELECT * FROM DuplicateId " & vbCrLf
            strSQL = strSQL & "WHERE Item10NO IS NOT NULL " & vbCrLf
            strSQL = strSQL & "ORDER BY ID"
            cmd.CommandText = strSQL
            dr = cmd.ExecuteReader
            While dr.Read = True
                strItem10No = GetDbData(dr, "Item10NO")

                '''' 処理：自分レコードの削除元コピー元NOから削除元コピー元NOと親NOが空白のNOを検索
                ''''       一致レコードがある場合、一致したレコードの親NOに自分レコードの削除元コピー元NOで更新
                strSQLUpdate = ""
                strSQLUpdate = strSQLUpdate & "UPDATE DuplicateId" & vbCrLf
                strSQLUpdate = strSQLUpdate & "SET ParentNO='" & strItem10No & "' " & vbCrLf
                strSQLUpdate = strSQLUpdate & "WHERE LINE_NO='" & strItem10No & "' " & vbCrLf
                strSQLUpdate = strSQLUpdate & "AND Item10NO IS NULL " & vbCrLf
                strSQLUpdate = strSQLUpdate & "AND ParentNO IS NULL " & vbCrLf
                cmdUpdate.CommandText = strSQLUpdate
                cmdUpdate.ExecuteNonQuery()

                '''' 処理：自分レコードの親NOが空白の場合、自分レコードの親NOを自分レコードの削除元コピー元で更新
                ''''       ※親NOが更新されている可能性があるため新たに親NOを取得する
                strParentNo = GetParentNo(con, GetDbData(dr, "ID"))
                If strParentNo = "" Then
                    strSQLUpdate = ""
                    strSQLUpdate = strSQLUpdate & "UPDATE DuplicateId " & vbCrLf
                    strSQLUpdate = strSQLUpdate & "SET ParentNO='" & strItem10No & "' " & vbCrLf
                    strSQLUpdate = strSQLUpdate & "WHERE ID='" & GetDbData(dr, "ID") & "' " & vbCrLf
                    cmdUpdate.CommandText = strSQLUpdate
                    cmdUpdate.ExecuteNonQuery()
                    strParentNo = strItem10No
                End If

                '''' 処理：自分レコードのNOを元に削除元コピー元を検索
                ''''       一致レコードの親NOに自分レコードの親NOで更新
                strMyNo = GetDbData(dr, "LINE_NO")
                strSQLUpdate = ""
                strSQLUpdate = strSQLUpdate & "UPDATE DuplicateId " & vbCrLf
                strSQLUpdate = strSQLUpdate & "SET ParentNO='" & strParentNo & "' " & vbCrLf
                strSQLUpdate = strSQLUpdate & "WHERE Item10NO='" & strMyNo & "' " & vbCrLf
                cmdUpdate.CommandText = strSQLUpdate
                cmdUpdate.ExecuteNonQuery()
            End While
            dr.Close()
            '''' 繰返し_終了	：

            '親NOが同じIDを取得
            '''' 繰返し_開始	：Statusが「D」且つ親NOがあるデータを繰り返す
            strSQL = ""
            strSQL = strSQL & "SELECT " & vbCrLf
            strSQL = strSQL & "ID, ParentNo " & vbCrLf
            strSQL = strSQL & "FROM DuplicateId " & vbCrLf
            strSQL = strSQL & "WHERE ParentNo IS NOT NULL " & vbCrLf
            strSQL = strSQL & "AND VALID_FLAG='D' " & vbCrLf
            strSQL = strSQL & "ORDER BY ParentNo, ID " & vbCrLf
            Debug.Print(strSQL)
            cmd.CommandText = strSQL
            dr = cmd.ExecuteReader
            strParentNo = ""
            arWhereIn = New ArrayList
            While dr.Read = True
                '''' 　処理：親NOを取得
                strNowParentNo = GetDbData(dr, "ParentNo")
                '''' 　条件：親NOと前親NOが異なるか判定
                '''' 　ケース：異なる場合、以下の処理を行う
                If strParentNo <> strNowParentNo Then
                    '''' 　　処理：月額金額打ち消しあいデータ削除FLG更新処理(UpdateDelFlg())
                    blnRet = UpdateDelFlg(con, arWhereIn)
                    If blnRet = False Then
                        Exit Function
                    End If
                    arWhereIn = New ArrayList
                End If
                strParentNo = strNowParentNo
                arWhereIn.Add(GetDbData(dr, "ID"))
            End While
            dr.Close()
            '''' 繰返し_終了	：

            '''' 処理：月額金額打ち消しあいデータ削除FLG更新処理(UpdateDelFlg())
            blnRet = UpdateDelFlg(con, arWhereIn)
            If blnRet = False Then
                Exit Function
            End If

            '''' 処理：削除済みIDを取得
            strSQL = "SELECT ID FROM DuplicateId WHERE DelFlg='1'"
            cmd.CommandText = strSQL
            dr = cmd.ExecuteReader
            While dr.Read = True
                arDelFlg.Add(GetDbData(dr, "ID"))
            End While
            dr.Close()

            GetDuplicateId = True

        Catch ex As Exception
            strErrMsg = ex.Message.ToString & "(GetDuplicateId)"
        Finally

        End Try

    End Function

    ''' <summary>
    ''' ＤＢの値取得
    ''' </summary>
    ''' <param name="drData">DataReader</param>
    ''' <param name="strFieldName">フィールド名</param>
    ''' <returns></returns>
    ''' <remarks>値がNull値の場合、空文字に変換</remarks>
    Private Function GetDbData(ByVal drData As OleDbDataReader, ByVal strFieldName As String) As String

        GetDbData = ""

        Try
            '''' 条件：
            '''' ケース：Null値の場合、空文字を返す
            '''' ケース：Null値以外の場合、そのままの値を返す
            If IsDBNull(drData.Item(strFieldName)) = True Then
                GetDbData = ""
            Else
                GetDbData = drData.Item(strFieldName)
            End If

        Catch ex As Exception
            Throw ex
        End Try

    End Function

    ''' <summary>
    ''' 親NO取得
    ''' </summary>
    ''' <param name="con">MDBのコネクション</param>
    ''' <param name="strId">ID</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetParentNo(ByVal con As OleDbConnection, ByVal strId As String) As String

        Dim cmd As New OleDbCommand
        Dim dr As OleDbDataReader

        GetParentNo = ""

        Try
            '''' 処理：該当IDでDuplicateIdﾃｰﾌﾞﾙの親NOを取得
            cmd.Connection = con
            cmd.CommandText = "SELECT ParentNo FROM DuplicateId WHERE ID='" & strId & "'"
            dr = cmd.ExecuteReader

            While dr.Read = True
                GetParentNo = GetDbData(dr, "ParentNo")
                Exit While
            End While
            dr.Close()

        Catch ex As Exception
            Throw ex
        End Try
    End Function

    ''' <summary>
    ''' 月額金額打ち消しあいデータ削除FLG更新
    ''' </summary>
    ''' <param name="con"></param>
    ''' <param name="arWhereIn"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function UpdateDelFlg(ByVal con As OleDbConnection,
                                  ByVal arWhereIn As ArrayList) As Boolean

        Dim blnZero As Boolean
        Dim strWhereIn As String
        Dim strSQL As String
        Dim strSQLUpdate As String
        Dim cmd As New OleDbCommand
        Dim cmdUpdate As New OleDbCommand
        Dim dr As OleDbDataReader

        UpdateDelFlg = False

        Try
            '''' 条件：該当するIDがあるか判定
            '''' ケース：IDがある場合、以下の処理を行う
            If arWhereIn.Count > 0 Then
                '''' 　処理：IDに該当する年毎に各月額を合計し、それらを１つにした値を取得する
                '''' 　条件：年毎の合計が全て０か判定
                '''' 　ケース：合計が０の場合、該当するIDでDuplicateIdﾃｰﾌﾞﾙの削除FLGを１で更新する
                strWhereIn = ""
                For intCnt As Integer = 0 To arWhereIn.Count - 1
                    strWhereIn = strWhereIn & "'" & arWhereIn(intCnt) & "',"
                Next
                strWhereIn = strWhereIn.Substring(0, strWhereIn.Length - 1)
                strSQL = ""
                strSQL = strSQL & "SELECT " & vbCrLf
                strSQL = strSQL & "IOC_YEAER, " & vbCrLf
                strSQL = strSQL & "sum(IOC_01) + " & vbCrLf
                strSQL = strSQL & "sum(IOC_02) + " & vbCrLf
                strSQL = strSQL & "sum(IOC_03) + " & vbCrLf
                strSQL = strSQL & "sum(IOC_04) + " & vbCrLf
                strSQL = strSQL & "sum(IOC_05) + " & vbCrLf
                strSQL = strSQL & "sum(IOC_06) + " & vbCrLf
                strSQL = strSQL & "sum(IOC_07) + " & vbCrLf
                strSQL = strSQL & "sum(IOC_08) + " & vbCrLf
                strSQL = strSQL & "sum(IOC_09) + " & vbCrLf
                strSQL = strSQL & "sum(IOC_10) + " & vbCrLf
                strSQL = strSQL & "sum(IOC_11) + " & vbCrLf
                strSQL = strSQL & "sum(IOC_12) AS SumTotal " & vbCrLf
                strSQL = strSQL & "FROM (" & vbCrLf
                strSQL = strSQL & "    SELECT " & vbCrLf
                strSQL = strSQL & "    IOC_YEAER, " & vbCrLf
                strSQL = strSQL & "    IOC_01, " & vbCrLf
                strSQL = strSQL & "    IOC_02, " & vbCrLf
                strSQL = strSQL & "    IOC_03, " & vbCrLf
                strSQL = strSQL & "    IOC_04, " & vbCrLf
                strSQL = strSQL & "    IOC_05, " & vbCrLf
                strSQL = strSQL & "    IOC_06, " & vbCrLf
                strSQL = strSQL & "    IOC_07, " & vbCrLf
                strSQL = strSQL & "    IOC_08, " & vbCrLf
                strSQL = strSQL & "    IOC_09, " & vbCrLf
                strSQL = strSQL & "    IOC_10, " & vbCrLf
                strSQL = strSQL & "    IOC_11, " & vbCrLf
                strSQL = strSQL & "    IOC_12 " & vbCrLf
                strSQL = strSQL & "    FROM PaymentTBL3 " & vbCrLf
                strSQL = strSQL & "    WHERE ID IN (" & strWhereIn & ") " & vbCrLf
                strSQL = strSQL & ")" & vbCrLf
                strSQL = strSQL & "GROUP BY IOC_YEAER " & vbCrLf
                strSQL = strSQL & "ORDER BY IOC_YEAER " & vbCrLf
                Debug.Print(strSQL)
                cmd.Connection = con
                cmd.CommandText = strSQL
                dr = cmd.ExecuteReader
                blnZero = True
                While dr.Read = True
                    If Long.Parse(GetDbData(dr, "SumTotal")) > 0 Then
                        blnZero = False
                        Exit While
                    End If
                End While
                If blnZero = True Then
                    strSQLUpdate = ""
                    strSQLUpdate = strSQLUpdate & "UPDATE DuplicateId " & vbCrLf
                    strSQLUpdate = strSQLUpdate & "SET DelFlg='1' " & vbCrLf
                    strSQLUpdate = strSQLUpdate & "WHERE ID IN (" & strWhereIn & ")" & vbCrLf
                    Debug.Print(strSQLUpdate)
                    cmdUpdate.Connection = con
                    cmdUpdate.CommandText = strSQLUpdate
                    cmdUpdate.ExecuteNonQuery()
                End If
                dr.Close()
            End If

            UpdateDelFlg = True

        Catch ex As Exception
            Throw ex
        End Try

    End Function

    ''' <summary>
    ''' 機能：作成中と契約済みのMTDL+SERIAL+サービス名 重複チェック
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub CheckMTDLSerial()

        Dim strSQL As String
        Dim rsTbl1 As New ADODB.Recordset
        Dim con As New ADODB.Connection
        Dim strCon As String
        Dim strMdbPath As String
        Dim mmc As New MasterMdbControl

        Dim Sav_MTDL As String
        Dim Sav_SERIAL As String
        'Req.1690 シリアル重複チェックリスト変更 2018/12 Str
        Dim Sav_SvcNM As String

        Dim SVCNM() As String
        'Req.1690 シリアル重複チェックリスト変更 2018/12 End
        Dim MTDL() As String
        Dim SERIAL() As String
        Dim PSCNT() As Long
        Dim DBCNT() As Long
        Dim idx As Long
        Dim idx2 As Long

        Dim strID As String
        Dim cmd As New ADODB.Command

        Try
            '接続の作成
            con = mmc.GetAdoTmpDBConnection(CommonVariable.CPNO, CommonVariable.MdbPW)
            cmd.ActiveConnection = con

            '候補をMTDL+SERIAL順に並べて全件読込
            strSQL = ""
            strSQL = strSQL & "SELECT * " & vbCrLf
            strSQL = strSQL & "FROM SerialCheckPaymentTBL1 " & vbCrLf
            'Req.1690 シリアル重複チェックリスト変更 2018/12 Str
            'strSQL = strSQL & "ORDER BY PROD_ITEM01, PROD_ITEM02 ASC " & vbCrLf
            strSQL = strSQL & "ORDER BY PROD_ITEM01, PROD_ITEM02 ASC ,SERVICE_NAME" & vbCrLf
            'Req.1690 シリアル重複チェックリスト変更 2018/12 End

            rsTbl1.Open(strSQL, con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)

            Sav_MTDL = ""
            Sav_SERIAL = ""
            'Req.1690 シリアル重複チェックリスト変更 2018/12 Str
            Sav_SvcNM = ""
            ReDim SVCNM(0)
            'Req.1690 シリアル重複チェックリスト変更 2018/12 End
            ReDim MTDL(0)
            ReDim SERIAL(0)
            ReDim PSCNT(0)
            ReDim DBCNT(0)
            idx = 0

            'MTDL+SERIALの重複チェック結果を配列に保存
            Do Until rsTbl1.EOF = True
                '1件目は必ず保存
                'Req.1690 シリアル重複チェックリスト変更 2018/12 Str
                'If Sav_MTDL = "" And _
                '   Sav_SERIAL = "" Then
                If Sav_MTDL = "" And _
                   Sav_SERIAL = "" And _
                   Sav_SvcNM = "" Then
                    'Req.1690 シリアル重複チェックリスト変更 2018/12 End
                    MTDL(0) = rsTbl1.Fields("PROD_ITEM01").Value
                    SERIAL(0) = rsTbl1.Fields("PROD_ITEM02").Value
                    'Req.1690 シリアル重複チェックリスト変更 2018/12 Str
                    SVCNM(0) = rsTbl1.Fields("SERVICE_NAME").Value
                    'Req.1690 シリアル重複チェックリスト変更 2018/12 End
                    If rsTbl1.Fields("LOCK_FLAG").Value = "C" Then
                        PSCNT(0) = 0
                        DBCNT(0) = 1
                    Else
                        PSCNT(0) = 1
                        DBCNT(0) = 0
                    End If
                Else
                    '2件目以降はMTDL+SERIALが同じなら件数に+1
                    'Req.1690 シリアル重複チェックリスト変更 2018/12 Str
                    'If Sav_MTDL = rsTbl1.Fields("PROD_ITEM01").Value And _
                    '   Sav_SERIAL = rsTbl1.Fields("PROD_ITEM02").Value Then
                    If Sav_MTDL = rsTbl1.Fields("PROD_ITEM01").Value And _
                       Sav_SERIAL = rsTbl1.Fields("PROD_ITEM02").Value And _
                       Sav_SvcNM = rsTbl1.Fields("SERVICE_NAME").Value Then
                        'Req.1690 シリアル重複チェックリスト変更 2018/12 End
                        If rsTbl1.Fields("LOCK_FLAG").Value = "C" Then
                            DBCNT(idx) = DBCNT(idx) + 1
                        Else
                            PSCNT(idx) = PSCNT(idx) + 1
                        End If
                    Else
                        idx = idx + 1
                        ReDim Preserve MTDL(idx)
                        ReDim Preserve SERIAL(idx)
                        ReDim Preserve PSCNT(idx)
                        ReDim Preserve DBCNT(idx)
                        'Req.1690 シリアル重複チェックリスト変更 2018/12 Str
                        ReDim Preserve SVCNM(idx)
                        'Req.1690 シリアル重複チェックリスト変更 2018/12 End

                        MTDL(idx) = rsTbl1.Fields("PROD_ITEM01").Value
                        SERIAL(idx) = rsTbl1.Fields("PROD_ITEM02").Value
                        'Req.1690 シリアル重複チェックリスト変更 2018/12 Str
                        SVCNM(idx) = rsTbl1.Fields("SERVICE_NAME").Value
                        'Req.1690 シリアル重複チェックリスト変更 2018/12 End
                        If rsTbl1.Fields("LOCK_FLAG").Value = "C" Then
                            PSCNT(idx) = 0
                            DBCNT(idx) = 1
                        Else
                            PSCNT(idx) = 1
                            DBCNT(idx) = 0
                        End If
                    End If
                End If
                Sav_MTDL = rsTbl1.Fields("PROD_ITEM01").Value
                Sav_SERIAL = rsTbl1.Fields("PROD_ITEM02").Value
                'Req.1690 シリアル重複チェックリスト変更 2018/12 Str
                Sav_SvcNM = rsTbl1.Fields("SERVICE_NAME").Value
                'Req.1690 シリアル重複チェックリスト変更 2018/12 End
                rsTbl1.MoveNext()
            Loop

            '最初に戻り、作成中、契約済みの両方に存在するデータにFLGをセット
            rsTbl1.MoveFirst()
            Do Until rsTbl1.EOF = True
                For idx2 = 0 To idx
                    'If rsTbl1.Fields("PROD_ITEM01").Value = MTDL(idx2) And _
                    '   rsTbl1.Fields("PROD_ITEM02").Value = SERIAL(idx2) Then
                    'Req.1690 シリアル重複チェックリスト変更 2018/12 Str
                    If rsTbl1.Fields("PROD_ITEM01").Value = MTDL(idx2) And _
                       rsTbl1.Fields("PROD_ITEM02").Value = SERIAL(idx2) And _
                       rsTbl1.Fields("SERVICE_NAME").Value = SVCNM(idx2) Then
                        'Req.1690 シリアル重複チェックリスト変更 2018/12 end
                        If DBCNT(idx2) > 0 And _
                           PSCNT(idx2) > 0 Then
                            rsTbl1.Fields("OutFlg").Value = "Y"
                            rsTbl1.Update()
                            Schk_W_Cnt = Schk_W_Cnt + 1

                            If strID = "" Then
                                strID = "'" & rsTbl1.Fields("ID").Value & "'"
                            Else
                                strID = strID & ",'" & rsTbl1.Fields("ID").Value & "'"
                            End If

                        End If
                        Exit For
                    End If
                Next idx2
                rsTbl1.MoveNext()
            Loop

            Call rsTbl1.Close()

            If strID <> "" Then

                cmd.CommandText = "Update SerialCheckPaymentTBL2 SET OutFlg = 'Y' where ID in (" & strID & ")"
                cmd.Execute()

                cmd.CommandText = "Update SerialCheckPaymentTBL3 SET OutFlg = 'Y' where ID in (" & strID & ")"
                cmd.Execute()

            End If

        Catch ex As Exception
            Debug.Print(ex.Message.ToString & "(CheckMTDLSerial)")
            If ex.Message.ToString.IndexOf("Could not find file") <> -1 Then
                Throw New Exception(FileReader.GetMessage("MSG_0529"))
            Else
                Throw ex
            End If
        Finally
            If con.State <> ADODB.ObjectStateEnum.adStateClosed Then
                con.Close()
            End If
        End Try

    End Sub

    ''' <summary>
    ''' 概 要：シリアル重複チェック用データテーブルを作成する。
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSerialCheckPSDataTable() As PSExcelDataTable

        Dim rtnTable As New PSExcelDataTable
        Dim row As DataRow
        Dim row2 As DataRow

        'Mdbの値を保持
        Dim MdbDataList(,) As Object
        Dim i As Integer

        Try
            'MDBから情報を取得
            Call GetSerialMDBDateInArray(MdbDataList)

            If IsNothing(MdbDataList) Then
                GetSerialCheckPSDataTable = Nothing
                Exit Function
            End If

            For i = 1 To MdbDataList.GetLength(0) - 1
                row = rtnTable.NewRow
                row2 = Item10Table.NewRow

                '１行のデータを配列に取得
                For j As Integer = ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG To ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12
                    row("CellNM" & j) = MdbDataList(i, j)
                Next

                If Trim(MdbDataList(i, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10)) <> "" Then
                    row2("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10) = MdbDataList(i, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10)
                End If

                ''行情報初期設定
                row("ExcelRow") = i.ToString
                row("DataKBN") = ""
                row("RowSTATUS") = ""
                row("DataKBN2") = ""
                row("ErrReason") = ""
                row("ENDDATE") = ""
                row("EOSDATE") = ""
                row("PsKBN") = ""
                row("DeleteNO") = ""
                row("TDateSTART") = ""
                row("TDateEND") = ""
                row("MDateSTART") = ""
                row("MDateEND") = ""

                row("SortAsc01") = MdbDataList(i, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01)
                row("SortAsc02") = MdbDataList(i, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02)
                If MdbDataList(i, ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG) = "C" Then
                    row("SortAsc03") = "0"
                Else
                    row("SortAsc03") = "1"
                End If

                If MdbDataList(i, ExcelWrite.ExcelPaymentLineColumn.QTY) >= 0 Then
                    row("SortAsc04") = "0"
                Else
                    row("SortAsc04") = "1"
                End If

                row("SortAsc05") = MdbDataList(i, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11)
                row("SortAsc06") = Format(CLng(MdbDataList(i, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)), "00000000")
                row("SortAsc07") = ""
                row("SortDsc01") = 0
                row("SortDsc02") = 0
                row("SortDsc03") = 0

                '１行追加
                rtnTable.Rows.Add(row)
                Item10Table.Rows.Add(row2)
            Next

            Return rtnTable

        Catch ex As Exception
            Throw ex
        Finally
        End Try
    End Function

    ''' <summary>
    ''' 概 要：シリアルチェックに使用する情報を付与する。
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function EditSerialCheckRowInfo(ByVal PSDataTable As PSExcelDataTable) As PSExcelDataTable

        ''戻り値
        Dim rtnTable As New PSExcelDataTable
        Dim LINENO As String

        Try
            Dim wStartDate1 As String
            Dim wStartDate2 As String
            Dim wEndDate1 As String
            Dim wEndDate2 As String
            Dim wDeleteNo As String
            Dim wDate1 As Date
            Dim wDate2 As Date
            Dim wDate3 As Date
            Dim wStrDate1 As String
            Dim wStrDate2 As String
            Dim wStrDate3 As String
            Dim wStr1 As String
            Dim wInt1 As Integer
            Dim mDateEnd As Date

            Dim wDate As Date
            Dim Date1 As DateTime
            Dim Date2 As DateTime
            Dim Date3 As DateTime
            Dim Date4 As DateTime
            Dim Cnt As Integer = 0

            '通常行処理 ===========================================================================
            For Each row As DataRow In PSDataTable.Rows
                wDate = Now
                Cnt = Cnt + 1

                '共通情報取得 =====================================================================

                '開始日付取得(月末日として取得)
                wStartDate1 = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11)
                row.Item("TDateSTART") = wStartDate1
                If Not IsDate(wStartDate1) Then
                    wStartDate1 = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE)
                    If Not IsDate(wStartDate1) Then
                        wStartDate1 = "不明"
                    End If
                End If

                '終了日付取得(月末日として取得)
                wEndDate1 = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12)
                row.Item("TDateEND") = wEndDate1
                If Not IsDate(wEndDate1) Then
                    wEndDate1 = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE)
                    If Not IsDate(wEndDate1) Then
                        wEndDate1 = "不明"
                    End If
                End If

                LINENO = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO)

                rtnTable.ImportRow(row)

                Application.DoEvents()
            Next

            Return rtnTable

        Catch ex As Exception
            ''Throw ex
            MsgBox("エラーが発生しました。 LINE_NO=[" & LINENO & "]")
        End Try
    End Function

    ''' <summary>
    ''' 概 要：シリアル重複チェックリストを作成する。
    ''' 説 明：
    ''' </summary>
    ''' <param name="PSDataTable">Paymentデータテーブル</param>
    ''' <param name="xlExtsheet">シリアル重複チェックリスト(シート)</param>
    ''' <remarks></remarks>
    Private Sub MakeSerialCheckListData(ByVal PSDataTable As DataTable, _
                                        ByVal xlExtsheet As Excel.Worksheet)

        Dim ew As New ExcelWrite

        ''Excel変数の宣言
        Dim xlApp As New Excel.Application

        'RANGE
        Dim xlPasteCell As Excel.Range
        Dim xlCopyCell As Excel.Range
        'BORDER
        Dim xlBorder As Excel.Border

        Dim MyArray(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12 + SerPlusCol) As Object

        Dim ii As Long
        Dim LL As Long

        Const CopyCount As Integer = 1000           ''一度のｺﾋﾟｰ行数
        Dim pasteCount As Integer                   ''貼付回数
        Dim strCopyIdx As Integer                   ''ｺﾋﾟｰ範囲：開始位置
        Dim endCopyIdx As Integer                   ''ｺﾋﾟｰ範囲：終了位置
        Dim wCount As Integer = 0

        Try


            'ヘッダー部分編集(必要な値をセットすれば後は計算式で表示が変わる)
            xlExtsheet.Cells(1, SerColMonthStart) = CommonVariable.ContractStart
            xlExtsheet.Cells(2, SerColMonthStart) = CommonVariable.ContractEnd
            xlExtsheet.Cells(5, SerColMonthStart) = Year(CommonVariable.PaymentStart)

            wCount = PSDataTable.Rows.Count

            'テンプレート行コピー
            pasteCount = Math.Truncate((wCount - 1) / CopyCount) + 1
            xlCopyCell = xlExtsheet.Rows(3)
            xlCopyCell.Hidden = False

            For PasteIdx As Integer = 1 To pasteCount

                ''開始/終了位置を取得
                strCopyIdx = (PasteIdx - 1) * CopyCount + SerialCheckLIST_OUTROW
                If wCount >= (PasteIdx * CopyCount) Then
                    endCopyIdx = (PasteIdx * CopyCount) + SerialCheckLIST_OUTROW - 1
                Else
                    endCopyIdx = strCopyIdx + (wCount Mod CopyCount) - 1
                End If

                ''コピペ実行
                xlPasteCell = xlExtsheet.Rows(strCopyIdx & ":" & endCopyIdx)
                Call xlCopyCell.Copy()
                Call xlPasteCell.PasteSpecial()
            Next
            xlCopyCell.Hidden = True

            ''------------------------------------------------------------------
            ''      データ行コピー
            ''------------------------------------------------------------------
            'データ部登録
            ii = SerialCheckLIST_OUTROW

            For Each row As DataRow In PSDataTable.Select()

                'データテーブルの値を配列にセット

                'MTDL
                MyArray(0, 0) = row.Item("CellNM35")

                'SERIAL
                MyArray(0, 1) = row.Item("CellNM36")

                'サービス種類
                Select Case row.Item("CellNM33")
                    Case "15", "16", "17"
                        MyArray(0, 2) = "HWMA"
                    Case "20"
                        MyArray(0, 2) = "MVMS"
                    Case "21"
                        MyArray(0, 2) = "CISCO保守"
                    Case "34"
                        MyArray(0, 2) = "システムサービス"
                    Case "43"
                        MyArray(0, 2) = "ベーシックセレクション(M09)"
                    Case "44"
                        MyArray(0, 2) = "ベーシックセレクション(" & Mid(row.Item("CellNM38"), 2, 3) & ")"
                End Select

                'STATUS
                If row.Item("CellNM2") = "C" Then
                    MyArray(0, 3) = "契約済"
                Else
                    MyArray(0, 3) = "作成中"
                End If

                '削除/追加
                If row.Item("CellNM61") > 0 Then
                    MyArray(0, 4) = "追加"
                Else
                    MyArray(0, 4) = "削除"
                End If

                'パターン名称
                MyArray(0, 5) = row.Item("CellNM34")

                'NO
                MyArray(0, 6) = row.Item("CellNM4")

                'サービス期間(開始)
                MyArray(0, 7) = row.Item("CellNM45")

                'サービス期間(終了)
                MyArray(0, 8) = row.Item("CellNM46")

                'Payment種別
                MyArray(0, 9) = row.Item("CellNM3")

                'Payment部データ(ファイル名以降)
                For LL = ExcelWrite.ExcelPaymentLineColumn.FILE_NAME To ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12
                    MyArray(0, LL + SerPlusCol - 1) = row.Item("CellNM" & LL)
                Next

                ''データ貼り込み
                'Req.1690 シリアル重複チェックリスト変更 2018/12 Str
                'xlPasteCell = xlExtsheet.Range(ew.ChgExcelRowNumberToChar(ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG) & ii & ":" & _
                '                               ew.ChgExcelRowNumberToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12 + SerPlusCol) & ii)
                xlPasteCell = xlExtsheet.Range(ew.ChgExcelRowNumberToChar(ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG + 1) & ii & ":" & _
                                               ew.ChgExcelRowNumberToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12 + SerPlusCol + 1) & ii)
                'Req.1690 シリアル重複チェックリスト変更 2018/12 End
                xlPasteCell.Value = MyArray

                ExcelObjRelease.ReleaseExcelObj(xlCopyCell, ExcelObjRelease.OBJECT_NOTHING)
                ExcelObjRelease.ReleaseExcelObj(xlPasteCell, ExcelObjRelease.OBJECT_NOTHING)

                ii = ii + 1
            Next

            ''------------------------------------------------------------------
            ''      範囲外データ非表示・削除
            ''------------------------------------------------------------------
            '年額非表示
            For ii = SerColYearStart To SerColYearEnd
                If ii - SerColYearStart = CommonVariable.PaymentPeriod Then
                    xlCopyCell = xlExtsheet.Columns(ew.ChgExcelRowNumberToChar(ii) & ":" & ew.ChgExcelRowNumberToChar(SerColYearEnd))
                    xlCopyCell.Hidden = True
                    Exit For
                End If
            Next

            '月額非表示部分を削除する
            For ii = 20 To 1 Step -1
                If ii > CommonVariable.PaymentPeriod Then
                    'IBM Confidentialを前年位置に移動する
                    xlCopyCell = xlExtsheet.Cells(4, SerColMonthStart + ii * 12 - 1)
                    xlPasteCell = xlExtsheet.Cells(4, SerColMonthStart + ii * 12 - 13)
                    Call xlCopyCell.Copy()
                    Call xlPasteCell.PasteSpecial()

                    '列の削除
                    xlCopyCell = xlExtsheet.Columns(ew.ChgExcelRowNumberToChar(SerColMonthStart + ii * 12 - 12) & ":" & _
                                                    ew.ChgExcelRowNumberToChar(SerColMonthStart + ii * 12 - 1))
                    xlCopyCell.Delete()

                    '罫線の引き直し
                    xlCopyCell = xlExtsheet.Cells(5, SerColMonthStart + ii * 12 - 13)
                    xlBorder = xlCopyCell.Borders(Excel.XlBordersIndex.xlEdgeRight)
                    xlBorder.LineStyle = Excel.XlLineStyle.xlContinuous
                End If
            Next

        Catch ex As Exception
            MsgBox(ex)
        Finally
            ExcelObjRelease.ReleaseExcelObj(xlBorder, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCopyCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPasteCell, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' 機能：MDBを配列へ格納する。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetSerialMDBDateInArray(ByRef OutDataList_2(,) As Object)

        ''初期化
        OutDataList_2 = Nothing

        ''MDBからﾃﾞｰﾀを取得        
        Dim Con As OleDbConnection
        Dim mmc As New MasterMdbControl
        Try

            ''接続取得
            Con = mmc.GetOleTmpDBConnection(CommonVariable.CPNO, CommonVariable.MdbPW)

            ''Sql取得
            Dim sql_Tbl1 As String = GetSql_SerialCheckPaymentTable1()
            Dim sql_Tbl2 As String = GetSql_SerialCheckPaymentTable2()
            Dim sql_Tbl3 As String = GetSql_SerialCheckPaymentTable3()

            ''ﾃﾞｰﾀ取得
            Dim Table1_Date As New DataTable
            Dim Table2_Date As New DataTable
            Dim Table3_Date As New DataTable
            Dim da_Tbl1 As New OleDbDataAdapter(sql_Tbl1, Con)
            Dim da_Tbl2 As New OleDbDataAdapter(sql_Tbl2, Con)
            Dim da_Tbl3 As New OleDbDataAdapter(sql_Tbl3, Con)
            Call da_Tbl1.Fill(Table1_Date)
            Call da_Tbl2.Fill(Table2_Date)
            Call da_Tbl3.Fill(Table3_Date)

            ''ﾃﾞｰﾀがなければ処理終了
            If Table1_Date.Rows.Count = 0 Then
                Exit Sub
            End If

            ''配列サイズ確定
            If Table1_Date.Rows.Count <> 0 Then
                ReDim Preserve OutDataList_2(Table1_Date.Rows.Count, ExcelWrite.MdbPaymentLineColumn.PRICE_YEAR20_MONTH12)
            End If

            ''ﾃﾞｰﾀを配列用に加工
            Dim Idx As Integer                  ''MDBのｶﾚﾝﾄ位置：年額/月額以外
            Dim IdxD As Integer                 ''MDBのｶﾚﾝﾄ位置：年額/月額
            Dim ArrayIdx As Integer             ''配列のIdx：年額/月額以外
            Dim ArrayIdxD As Integer            ''配列のIdx：年額/月額
            For Idx = 0 To Table1_Date.Rows.Count - 1

                ''配列のIdx初期化
                ArrayIdx = 0

                ''PaymentTBL1取得
                'Req.1690 シリアル重複チェックリスト変更 2018/12 Str
                'For i As Integer = 1 To Table1_Date.Columns.Count - 3
                For i As Integer = 1 To Table1_Date.Columns.Count - 4
                    'Req.1690 シリアル重複チェックリスト変更 2018/12 End
                    ArrayIdx = ArrayIdx + 1
                    OutDataList_2(Idx + 1, ArrayIdx) = Table1_Date.Rows(Idx).Item(i)
                Next

                ''PaymentTBL2取得
                For j As Integer = 1 To Table2_Date.Columns.Count - 3
                    ArrayIdx = ArrayIdx + 1
                    OutDataList_2(Idx + 1, ArrayIdx) = Table2_Date.Rows(Idx).Item(j)
                Next

                ''PaymentTBL3取得 ※20年分の値をセット
                IdxD = (Idx * 20) - 1

                '年額セット
                IdxD = IdxD + 1
                For IdxD = IdxD To IdxD + 19
                    ArrayIdx = ArrayIdx + 1
                    OutDataList_2(Idx + 1, ArrayIdx) = Table3_Date.Rows(IdxD).Item("IOC_YYYY")
                Next

                '過去の契約金額合計をセット(Mdbの40カラム目を統合Paymentの117カラム目にセット)
                ArrayIdx = ArrayIdx + 1
                OutDataList_2(Idx + 1, ArrayIdx) = Table2_Date.Rows(Idx).Item(Table2_Date.Columns.Count - 2)

                '月額セット
                ''PaymentTBL3取得 ※20年分の値をセット
                IdxD = (Idx * 20) - 1

                IdxD = IdxD + 1
                For IdxD = IdxD To IdxD + 19
                    For l As Integer = 1 To 12
                        ArrayIdx = ArrayIdx + 1

                        Select Case l
                            Case 1
                                OutDataList_2(Idx + 1, ArrayIdx) = Table3_Date.Rows(IdxD).Item("IOC_01")
                            Case 2
                                OutDataList_2(Idx + 1, ArrayIdx) = Table3_Date.Rows(IdxD).Item("IOC_02")
                            Case 3
                                OutDataList_2(Idx + 1, ArrayIdx) = Table3_Date.Rows(IdxD).Item("IOC_03")
                            Case 4
                                OutDataList_2(Idx + 1, ArrayIdx) = Table3_Date.Rows(IdxD).Item("IOC_04")
                            Case 5
                                OutDataList_2(Idx + 1, ArrayIdx) = Table3_Date.Rows(IdxD).Item("IOC_05")
                            Case 6
                                OutDataList_2(Idx + 1, ArrayIdx) = Table3_Date.Rows(IdxD).Item("IOC_06")
                            Case 7
                                OutDataList_2(Idx + 1, ArrayIdx) = Table3_Date.Rows(IdxD).Item("IOC_07")
                            Case 8
                                OutDataList_2(Idx + 1, ArrayIdx) = Table3_Date.Rows(IdxD).Item("IOC_08")
                            Case 9
                                OutDataList_2(Idx + 1, ArrayIdx) = Table3_Date.Rows(IdxD).Item("IOC_09")
                            Case 10
                                OutDataList_2(Idx + 1, ArrayIdx) = Table3_Date.Rows(IdxD).Item("IOC_10")
                            Case 11
                                OutDataList_2(Idx + 1, ArrayIdx) = Table3_Date.Rows(IdxD).Item("IOC_11")
                            Case 12
                                OutDataList_2(Idx + 1, ArrayIdx) = Table3_Date.Rows(IdxD).Item("IOC_12")
                        End Select
                    Next
                Next

            Next
            Con.Close()

        Catch ex As Exception
            ''ｴﾗｰの処理はなし
        End Try

    End Sub


    ''' <summary>
    ''' 概 要：SerialCheckPaymentTable1の取得SQL
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_SerialCheckPaymentTable1() As String

        ''戻り値
        Dim rtnValue As New StringBuilder

        ''Select句
        rtnValue.Append(CommonConstant.SQL_STR_SELECT)
        rtnValue.Append(CommonConstant.SQL_STR_ASTERISK)

        ''From句
        rtnValue.Append(CommonConstant.SQL_STR_FROM)
        rtnValue.Append(" SerialCheckPaymentTBL1 ")

        ''Where句
        rtnValue.Append(CommonConstant.SQL_STR_WHERE)
        rtnValue.Append(" OutFlg = 'Y' ")

        ''Order By句
        rtnValue.Append(CommonConstant.SQL_STR_ORDER_BY)
        rtnValue.Append(" ID ")

        Return rtnValue.ToString

    End Function


    ''' <summary>
    ''' 概 要：SerialCheckPaymentTable2の取得SQL
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_SerialCheckPaymentTable2() As String

        ''戻り値
        Dim rtnValue As New StringBuilder

        ''Select句
        rtnValue.Append(CommonConstant.SQL_STR_SELECT)
        rtnValue.Append(CommonConstant.SQL_STR_ASTERISK)

        ''From句
        rtnValue.Append(CommonConstant.SQL_STR_FROM)
        rtnValue.Append(" SerialCheckPaymentTBL2 ")

        ''Where句
        rtnValue.Append(CommonConstant.SQL_STR_WHERE)
        rtnValue.Append(" OutFlg = 'Y' ")

        ''Order By句
        rtnValue.Append(CommonConstant.SQL_STR_ORDER_BY)
        rtnValue.Append(" ID ")

        Return rtnValue.ToString

    End Function


    ''' <summary>
    ''' 概 要：SerialCheckPaymentTable3の取得SQL
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_SerialCheckPaymentTable3() As String

        ''戻り値
        Dim rtnValue As New StringBuilder

        ''Select句
        rtnValue.Append(CommonConstant.SQL_STR_SELECT)
        rtnValue.Append(CommonConstant.SQL_STR_ASTERISK)

        ''From句
        rtnValue.Append(CommonConstant.SQL_STR_FROM)
        rtnValue.Append(" SerialCheckPaymentTBL3 ")

        ''Where句
        rtnValue.Append(CommonConstant.SQL_STR_WHERE)
        rtnValue.Append(" OutFlg = 'Y' ")

        ''Order By句
        rtnValue.Append(CommonConstant.SQL_STR_ORDER_BY)
        rtnValue.Append(" ID, IOC_YEAER")

        Return rtnValue.ToString

    End Function


    'Req:1569 シリアル重複チェックリスト end


    ''' <summary>
    ''' 概 要：延長候補リスト作成処理メイン
    ''' 説 明：
    ''' </summary>
    ''' <param name="OutFilePath">延長候補リストファイル出力先パス</param>
    ''' <param name="waitDialog">処理中ダイアログオブジェクト</param>
    ''' <remarks></remarks>
    Private Function ExtensionListOutput(ByVal OutFilePath As String, _
                                         ByVal waitDialog As Frm_WaitDialog) As String
        '===================================================
        '延長契約候補リスト
        '===================================================
        Dim strExtensionFileName As String = ""
        Dim wRet As Boolean

        'ファイルの作成日時
        Dim createTime As String
        createTime = Now.ToString("_yyyyMMdd_HHmmss")

        '延長候補リストファイル名編集
        strExtensionFileName = OutFilePath & "延長契約対象データ_" & CommonVariable.CPNO & "_" & createTime & ".xlsx"
        'Templateをコピーする。
        System.IO.File.Copy(OUTPUT_TEMPLATEFOLDER & "\" & ExtensionTemplate, strExtensionFileName, True)

        ''延長候補リストを作成する。
        wRet = MakeExtensionList(strExtensionFileName, _
                                 waitDialog)

        If wRet = True Then
            ExtensionListOutput = strExtensionFileName
        Else
            ExtensionListOutput = ""
        End If

    End Function

    ''' <summary>
    ''' 概 要：延長候補リストを作成する。
    ''' 説 明：
    ''' </summary>
    ''' <param name="ExtensionFilePath">延長候補リストファイルフルパス(出力)</param>
    ''' <param name="waitDialog">処理中ダイアログオブジェクト</param>
    ''' <remarks></remarks>
    Private Function MakeExtensionList(ByVal ExtensionFilePath As String, _
                                       ByVal waitDialog As Frm_WaitDialog) As Boolean
        Dim wc As New WebDb.WebDbCommon
        Dim con As OleDbConnection
        Dim mmc As New MasterMdbControl
        Dim swma As New OleDbSwma
        Dim spa As New OleDbServicePac_ALL

        ''Excel変数の宣言
        Dim xlApp As New Excel.Application
        'START 変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
        'BOOKS
        Dim xlBooks As Excel.Workbooks
        'END   変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
        'BOOK
        Dim xlExtBook As Excel.Workbook
        Dim xlPSBook As Excel.Workbook
        'START 変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
        'SHEETS
        Dim xlExtSheets As Excel.Sheets
        Dim xlPSSheets As Excel.Sheets
        'END   変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
        'SHEET
        Dim xlPDSheet As Excel.Worksheet
        Dim xlExtSheet As Excel.Worksheet
        Dim xlExtOutSheet As Excel.Worksheet
        'RANGE
        Dim xlCell As Excel.Range
        Dim xlName As Excel.Name
        'START 変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
        Dim xlNames As Excel.Names
        'END   変更管理#3?（Excel.exeの解放対応)　2017/01 sugo

        Dim dtContractBase As New M_CONTRACT_BASETable

        Dim wRet As Boolean
        Dim wStr As String
        Dim wDate As Date

        Dim PSDataTable As PSExcelDataTable
        Dim PSDataTable2 As New PSExcelDataTable

        Try
            MakeExtensionList = False

            ''App設定
            xlApp.EnableEvents = False
            xlApp.DisplayAlerts = False

            '計数項目初期化
            ExtPSTotal = 0
            ExtPDTotal = 0

            ExtAASHW.Total = 0
            ExtAASHW.Target = 0
            ExtAASHW.Confirm = 0
            ExtAASHW.NonTarget = 0
            ExtHWMA.Total = 0
            ExtHWMA.Target = 0
            ExtHWMA.Confirm = 0
            ExtHWMA.NonTarget = 0
            ExtPA.Total = 0
            ExtPA.Target = 0
            ExtPA.Confirm = 0
            ExtPA.NonTarget = 0
            ExtIgfLease.Total = 0
            ExtIgfLease.Target = 0
            ExtIgfLease.Confirm = 0
            ExtIgfLease.NonTarget = 0
            ExtIgfExLease.Total = 0
            ExtIgfExLease.Target = 0
            ExtIgfExLease.Confirm = 0
            ExtIgfExLease.NonTarget = 0
            ExtOther.Total = 0
            ExtOther.Target = 0
            ExtOther.Confirm = 0
            ExtOther.NonTarget = 0
            ExtNonTarget.Total = 0
            ExtNonTarget.Target = 0
            ExtNonTarget.Confirm = 0
            ExtNonTarget.NonTarget = 0

            '----------------------------------------
            'OIO基本契約期間終了日を取得する
            '----------------------------------------
            '契約基本情報取得
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW
            wRet = wc.GetContractBaseData(CommonVariable.CPNO, dtContractBase, wStr)
            If wRet = False Then
                MsgBox(wStr, MsgBoxStyle.Critical, "ExtensionList")
                Exit Function
            End If
            If dtContractBase.Rows.Count > 0 Then
                '日付文字列(月末日)にして取得
                wDate = CDate(ExcelWrite.changeDBNullToString(dtContractBase.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_END_YEAR)) & "/" & _
                              ExcelWrite.changeDBNullToString(dtContractBase.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_END_MONTH)) & "/01")
                OioEndDate = wDate.AddMonths(1).AddDays(-1).ToString("yyyy/MM/dd")
            End If

            '画面入力値を日付文字列(月末日)にして取得
            wDate = CDate(OioEndYear & "/" & _
                          OioEndMonth & "/01")
            OioEndDate = wDate.AddMonths(1).AddDays(-1).ToString("yyyy/MM/dd")

            ''------------------------------------------------------------------
            ''      シート取得
            ''------------------------------------------------------------------
            '延長候補リスト取得
            'START 変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
            xlBooks = xlApp.Workbooks
            xlExtBook = xlBooks.Open(ExtensionFilePath)
            xlExtSheets = xlExtBook.Worksheets
            xlExtSheet = xlExtSheets.Item(SHEET_NAME_Ext2)
            xlExtOutSheet = xlExtSheets.Item(SHEET_NAME_Ext1)
            'xlExtBook = xlApp.Workbooks.Open(ExtensionFilePath)
            'xlExtSheet = xlExtBook.Worksheets(SHEET_NAME_Ext2)
            'xlExtOutSheet = xlExtBook.Worksheets(SHEET_NAME_Ext1)
            'END   変更管理#3?（Excel.exeの解放対応)　2017/01 sugo

            '詳細テンプレートコピー
            'START 変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
            xlPSBook = xlBooks.Open(FileManager.GetLocalFolderPath(CommonConstant.FOLDERNAME_TEMPLATE) & "PaymentLineSample.xlsm")
            xlPSSheets = xlPSBook.Worksheets
            xlPDSheet = xlPSSheets.Item(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)
            Call xlPDSheet.Copy(After:=xlExtSheet)
            ExcelObjRelease.ReleaseExcelObj(xlPDSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPSSheets, ExcelObjRelease.OBJECT_NOTHING)
            xlPSBook.Close(False)
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            'xlPSBook = xlApp.Workbooks.Open(FileManager.GetLocalFolderPath(CommonConstant.FOLDERNAME_TEMPLATE) & "PaymentLineSample.xlsm")
            'xlPDSheet = xlPSBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)
            'Call xlPDSheet.Copy(After:=xlExtSheet)
            'END   変更管理#3?（Excel.exeの解放対応)　2017/01 sugo

            'コピーした詳細シートを変数に取得
            'START 変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
            xlPDSheet = xlExtSheets.Item(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)
            'xlPDSheet = xlExtBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)
            'END   変更管理#3?（Excel.exeの解放対応)　2017/01 sugo

            ''------------------------------------------------------------------
            ''      各情報取得
            ''------------------------------------------------------------------
            '締結済MDBのデータをデータテーブルに取得   
            PSDataTable = GetPSDataTable()

            If IsNothing(PSDataTable) Then
                '該当データ無し
                MuseMessageBox.ShowWarning(FileReader.GetMessage("MSG_0282"), Me.Text)
                Exit Function
            End If

            'マスタMDBをデータテーブルに取得
            con = mmc.GetOleDBConnection(CommonVariable.MdbPW)
            'SWMA
            SwmaTBL = swma.SelectDataTable(con)
            'ServicePac_ALL
            SpaTBL = spa.SelectDataTable(con)

            '※ここでウェイトを入れないと無応答になる場合あり
            Application.DoEvents()

            waitDialog.PerformStep()

            '詳細シートを作成
            PaymentDetailEdit(xlPDSheet)
            ExtPSTotal = PSDataTable.Rows.Count

            waitDialog.PerformStep()

            '各行情報を判定・編集する
            PSDataTable = EditRowInfo(PSDataTable)

            '使用済テーブルを開放する
            SwmaTBL = Nothing
            SpaTBL = Nothing

            waitDialog.PerformStep()

            ''------------------------------------------------------------------
            ''      データテーブルソート
            ''------------------------------------------------------------------
            'ソート処理
            Dim tempView As DataView = New DataView(PSDataTable)
            Dim tempTable As DataTable
            tempView.Sort = "SortAsc01 ASC , " & _
                            "SortAsc02 ASC ," & _
                            "SortAsc03 ASC ," & _
                            "SortAsc04 ASC ," & _
                            "SortAsc05 ASC ," & _
                            "SortAsc06 ASC ," & _
                            "SortAsc07 ASC ," & _
                            "SortDsc01 DESC ," & _
                            "SortDsc02 DESC ," & _
                            "SortDsc03 DESC "

            'ソート後の値をテーブルに格納する。
            tempTable = tempView.ToTable()

            '使用済テーブルを開放する
            PSDataTable = Nothing

            waitDialog.PerformStep()

            Application.DoEvents()

            ''------------------------------------------------------------------
            ''      データ出力
            ''------------------------------------------------------------------
            '延長候補リスト明細シートにデータをセットする
            Call MakeExtensionListData(tempTable, xlExtSheet)

            waitDialog.PerformStep()

            Application.DoEvents()

            '延長候補リストの各件数をカウントする
            Call ExtensionListCount(tempTable)

            '延長候補リスト出力結果シートにデータをセットする
            Call ExtensionOutput(xlExtOutSheet)

            waitDialog.PerformStep()

            ''------------------------------------------------------------------
            ''      Book保存
            ''------------------------------------------------------------------
            '名前の定義削除
            'START 変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
            xlNames = xlExtBook.Names
            For intCnt As Integer = xlNames.Count To 1 Step -1
                xlName = xlNames.Item(intCnt)
                If xlName.Name.IndexOf("延長_Payment開始年") = -1 And _
                   xlName.Name.IndexOf("延長_契約開始") = -1 And _
                   xlName.Name.IndexOf("延長_契約終了") = -1 Then
                    Call xlName.Delete()
                End If
                ExcelObjRelease.ReleaseExcelObj(xlName, ExcelObjRelease.OBJECT_NOTHING)
            Next
            ExcelObjRelease.ReleaseExcelObj(xlNames, ExcelObjRelease.OBJECT_NOTHING)
            'For Each xlName In xlExtBook.Names
            '    'wStr = xlName.Name
            '    If xlName.Name.IndexOf("延長_Payment開始年") = -1 And _
            '       xlName.Name.IndexOf("延長_契約開始") = -1 And _
            '       xlName.Name.IndexOf("延長_契約終了") = -1 Then
            '        Call xlName.Delete()
            '    End If
            'Next
            'END   変更管理#3?（Excel.exeの解放対応)　2017/01 sugo

            '各シート先頭に位置付け
            xlExtSheet.Activate()
            xlCell = xlExtSheet.Cells(1, 1)
            xlApp.Goto(xlCell)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            xlExtOutSheet.Activate()
            xlCell = xlExtOutSheet.Cells(1, 1)
            xlApp.Goto(xlCell)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            waitDialog.PerformStep()

            'セーブ
            xlExtBook.Save()

            MakeExtensionList = True

        Catch ex As Exception
            MsgBox(ex)
        Finally
            ExcelObjRelease.ReleaseExcelObj(xlName, ExcelObjRelease.OBJECT_NOTHING)
            'START 変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
            ExcelObjRelease.ReleaseExcelObj(xlNames, ExcelObjRelease.OBJECT_NOTHING)
            'END   変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPDSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlExtOutSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlExtSheet, ExcelObjRelease.OBJECT_NOTHING)
            'START 変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
            ExcelObjRelease.ReleaseExcelObj(xlExtSheets, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPSSheets, ExcelObjRelease.OBJECT_NOTHING)
            'END   変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
            xlApp.DisplayAlerts = False
            If IsNothing(xlPSBook) = False Then
                xlPSBook.Close()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.DisplayAlerts = False
            If IsNothing(xlExtBook) = False Then
                xlExtBook.Close()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlExtBook, ExcelObjRelease.OBJECT_NOTHING)
            'START 変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
            ExcelObjRelease.ReleaseExcelObj(xlBooks, ExcelObjRelease.OBJECT_NOTHING)
            'END   変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()

        End Try

    End Function

    ''' <summary>
    ''' 概 要：延長候補リスト詳細シートを作成する。
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub PaymentDetailEdit(ByRef xlPDSheet As Excel.Worksheet)
        Dim ew As New ExcelWrite

        ''Excel変数の宣言
        Dim xlApp As New Excel.Application
        Dim xlCopyRange As Excel.Range
        Dim xlPasteRange As Excel.Range

        Const CopyCount As Integer = 1000           ''一度のｺﾋﾟｰ行数
        Dim pasteCount As Integer                   ''貼付回数
        Dim strCopyIdx As Integer                   ''ｺﾋﾟｰ範囲：開始位置
        Dim endCopyIdx As Integer                   ''ｺﾋﾟｰ範囲：終了位置

        ''MDBからﾃﾞｰﾀを取得        
        Dim Con As OleDbConnection
        Dim mmc As New MasterMdbControl

        Try
            ''接続取得
            Con = mmc.GetOleTmpDBConnection(CommonVariable.CPNO, CommonVariable.MdbPW)

            ''Sql取得
            Dim sql_Tbl1 As String = GetSql_PaymentDetailTable()

            ''ﾃﾞｰﾀ取得
            Dim Table1_Data As New DataTable
            Dim da_Tbl1 As New OleDbDataAdapter(sql_Tbl1, Con)
            Call da_Tbl1.Fill(Table1_Data)

            Dim MyArray(1, ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE) As Object

            'データがなければ処理終了
            If IsNothing(Table1_Data) Then 'If Table1_Data.Rows.Count = 0 Then
                Exit Sub
            End If

            '件数セット
            ExtPDTotal = Table1_Data.Rows.Count

            'テンプレート行コピー
            pasteCount = Math.Truncate((ExtPDTotal - 1) / CopyCount) + 1
            xlCopyRange = xlPDSheet.Rows(3)
            xlCopyRange.Hidden = False

            For PasteIdx As Integer = 1 To pasteCount
                ''開始/終了位置を取得
                strCopyIdx = (PasteIdx - 1) * CopyCount + EXCEL_PAYMENTLINEDETAIL_OUTROW
                If ExtPDTotal >= (PasteIdx * CopyCount) Then
                    endCopyIdx = (PasteIdx * CopyCount) + EXCEL_PAYMENTLINEDETAIL_OUTROW - 1
                Else
                    endCopyIdx = strCopyIdx + (ExtPDTotal Mod CopyCount) - 1
                End If

                ''コピペ実行
                xlPasteRange = xlPDSheet.Rows(strCopyIdx & ":" & endCopyIdx)
                Call xlCopyRange.Copy()
                Call xlPasteRange.PasteSpecial()
            Next
            xlCopyRange.Hidden = True

            'データ貼り込み
            For Idx As Integer = 0 To Table1_Data.Rows.Count - 1
                ''PaymentTBL取得
                For ii As Integer = 1 To ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE
                    MyArray(0, ii - 1) = Table1_Data.Rows(Idx).Item(ii)
                Next

                ''１行貼り込み
                xlPasteRange = xlPDSheet.Range(ew.ChgExcelRowNumberToChar(ExcelWrite.ExcelPaymentLineDetailColumn.UPDATE_FLAG) & _
                                               Idx + ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW & ":" & _
                                               ew.ChgExcelRowNumberToChar(ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE) & _
                                               Idx + ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW)
                xlPasteRange.Value = MyArray
            Next

            Con.Close()

        Catch ex As Exception
            MsgBox(ex)
        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCopyRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPasteRange, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()

        End Try
    End Sub

    ''' <summary>
    ''' 概 要：締結済MDBを読み込んでデータテーブルを作成する。
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetPSDataTable() As PSExcelDataTable

        Dim rtnTable As New PSExcelDataTable
        Dim row As DataRow
        Dim row2 As DataRow

        'Mdbの値を保持
        Dim MdbDataList(,) As Object
        Dim i As Integer

        Try
            'MDBから情報を取得
            Call GetMDBDateInArray(MdbDataList)

            If IsNothing(MdbDataList) Then
                GetPSDataTable = Nothing
                Exit Function
            End If

            For i = 1 To MdbDataList.GetLength(0) - 1
                row = rtnTable.NewRow
                row2 = Item10Table.NewRow

                '１行のデータを配列に取得
                For j As Integer = ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG To ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12
                    row("CellNM" & j) = MdbDataList(i, j)
                Next

                If Trim(MdbDataList(i, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10)) <> "" Then
                    row2("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10) = MdbDataList(i, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10)
                End If

                ''行情報初期設定
                row("ExcelRow") = i.ToString
                row("DataKBN") = ""
                row("RowSTATUS") = ""
                row("DataKBN2") = ""
                row("ErrReason") = ""
                row("ENDDATE") = ""
                row("EOSDATE") = ""
                row("PsKBN") = ""
                row("DeleteNO") = ""
                row("TDateSTART") = ""
                row("TDateEND") = ""
                row("MDateSTART") = ""
                row("MDateEND") = ""

                row("SortAsc01") = ""
                row("SortAsc02") = ""
                row("SortAsc03") = ""
                row("SortAsc04") = ""
                row("SortAsc05") = ""
                row("SortAsc06") = ""
                row("SortAsc07") = ""
                row("SortDsc01") = 0
                row("SortDsc02") = 0
                row("SortDsc03") = 0

                '１行追加
                rtnTable.Rows.Add(row)
                Item10Table.Rows.Add(row2)
            Next

            Return rtnTable

        Catch ex As Exception
            Throw ex
        Finally
        End Try
    End Function

    ''' <summary>
    ''' 概 要：Paymentデータテーブルに、各行情報を付与する。
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function EditRowInfo(ByVal PSDataTable As PSExcelDataTable) As PSExcelDataTable

        ''戻り値
        Dim rtnTable As New PSExcelDataTable
        Dim LINENO As String

        Try
            Dim wStartDate1 As String
            Dim wStartDate2 As String
            Dim wEndDate1 As String
            Dim wEndDate2 As String
            Dim wDeleteNo As String
            Dim wDate1 As Date
            Dim wDate2 As Date
            Dim wDate3 As Date
            Dim wStrDate1 As String
            Dim wStrDate2 As String
            Dim wStrDate3 As String
            Dim wStr1 As String
            Dim wInt1 As Integer
            Dim mDateEnd As Date

            Dim wDate As Date
            Dim Date1 As DateTime
            Dim Date2 As DateTime
            Dim Date3 As DateTime
            Dim Date4 As DateTime
            Dim Cnt As Integer = 0

            '通常行処理 ===========================================================================
            'For Each row As DataRow In PSDataTable.Select()
            For Each row As DataRow In PSDataTable.Rows
                wDate = Now
                Cnt = Cnt + 1

                '共通情報取得 =====================================================================

                '開始日付取得(月末日として取得)
                wStartDate1 = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11)
                row.Item("TDateSTART") = wStartDate1
                If Not IsDate(wStartDate1) Then
                    wStartDate1 = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE)
                    If Not IsDate(wStartDate1) Then
                        wStartDate1 = "不明"
                    End If
                End If

                '終了日付取得(月末日として取得)
                wEndDate1 = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12)
                row.Item("TDateEND") = wEndDate1
                If Not IsDate(wEndDate1) Then
                    wEndDate1 = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE)
                    If Not IsDate(wEndDate1) Then
                        wEndDate1 = "不明"
                    End If
                End If

                'Payment種別をセット
                row.Item("PsKBN") = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG)

                '削除元情報を検索してセット
                wDeleteNo = GetDeleteNo(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO), _
                                        row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10))
                row.Item("DeleteNO") = wDeleteNo
                row.Item("SortAsc02") = wDeleteNo

                LINENO = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO)

                'パターンNO別処理 =================================================================
                Select Case Trim(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD))
                    Case "5", "7", "9", "10"
                        '01:AASHW -----------------------------------------------------------------
                        '共通パラメータセット
                        row.Item("DataKBN") = "01"
                        row.Item("DataKBN2") = "SWMA"
                        row.Item("ENDDATE") = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.WD_DATE)
                        row.Item("MDateSTART") = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE)

                        'ソートパラメータセット
                        row.Item("SortAsc01") = "01"
                        row.Item("SortAsc03") = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM04)
                        row.Item("SortAsc04") = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02)
                        row.Item("SortAsc05") = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01)
                        row.Item("SortAsc06") = wStartDate1
                        row.Item("SortDsc01") = Val(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH))

                        If wStartDate1 = "不明" Or wEndDate1 = "不明" Then
                            '要確認
                            row.Item("RowSTATUS") = "01"
                        Else
                            If IsSWMA(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01)) = True Then
                                'サービス期間判定
                                '開始年月 + Swma year項目を年数として加算した値　＞＝　現在のOIO基本契約期間 終了　且つ、
                                '開始年月 + Swma year項目を年数として加算した値　＜　延長後のOIO基本契約期間 終了　の場合出力対象
                                wStrDate1 = CDate(wStartDate1).AddYears(Val(wSwmaYear)).ToString("yyyy/MM") & "/01"
                                wDate1 = CDate(wStrDate1).AddDays(-1)                       '前月末日にする
                                wStrDate2 = CDate(OioEndDate).ToString("yyyy/MM") & "/01"
                                wDate2 = CDate(wStrDate2).AddMonths(1).AddDays(-1)          '月末日にする
                                wStrDate3 = wExtYear & "/" & wExtMonth & "/01"
                                wDate3 = CDate(wStrDate3).AddMonths(1).AddDays(-1)          '月末日にする

                                mDateEnd = CDate(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE)).AddYears(Val(wSwmaYear)).ToString("yyyy/MM") & "/01"
                                row.Item("MDateEND") = CDate(mDateEnd).AddDays(-1)

                                If wDate1 >= wDate2 And wDate1 < wDate3 Then
                                    '出力対象
                                    row.Item("RowSTATUS") = "00"
                                Else
                                    '出力対象外
                                    row.Item("RowSTATUS") = "99"
                                End If
                            Else
                                '出力対象外
                                row.Item("RowSTATUS") = "99"
                            End If
                        End If

                    Case "13", "15", "16", "17", "18", "19"
                        '02:HWMA ------------------------------------------------------------------
                        '共通パラメータセット
                        row.Item("DataKBN") = "02"
                        row.Item("EOSDATE") = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.WD_DATE)
                        row.Item("MDateSTART") = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE)

                        'ソートパラメータセット
                        row.Item("SortAsc01") = "02"
                        If Trim(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD)) = "13" Then
                            row.Item("SortAsc03") = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM04)
                        Else
                            row.Item("SortAsc03") = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01)
                        End If
                        row.Item("SortAsc04") = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02)
                        row.Item("SortAsc05") = wStartDate1
                        row.Item("SortDsc01") = Val(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH))

                        Select Case Trim(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD))

                            Case "1", "2", "3"
                                '※2015/11月以降の対応予定：まだここの処理は実行されません
                                row.Item("DataKBN2") = "HW"

                                If wStartDate1 = "不明" Or wEndDate1 = "不明" Then
                                    '要確認
                                    row.Item("RowSTATUS") = "01"
                                Else
                                    'ＨＷ製品番号（項目１）とシリアル（項目２）が一致する以下のパターンNOが存在する。→対象外
                                    'ﾊﾟﾀｰﾝNO = "13","15","16","18"が対象
                                    If IsHW(PSDataTable, _
                                            row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01), _
                                            row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02)) = False Then

                                        'ﾌｧｲﾙ名/ﾌｧｲﾙ内構成連番/契約順番が一致する以下のパターンNOが存在する。→対象外
                                        'ﾊﾟﾀｰﾝNO = "13","15","16","17","18","19"が対象
                                        If IsSameContract(PSDataTable, _
                                                          row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME), _
                                                          row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR), _
                                                          row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT)) = False Then

                                            'StdMainteテーブルに製品番号が存在する
                                            If IsStdMainte(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01)) = True Then

                                                'WCatテーブルに製品番号が存在する
                                                If GetWCat(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01), wInt1) = True Then

                                                    '開始日付取得(月末日として取得)
                                                    wStartDate1 = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE)
                                                    If IsDate(wStartDate1) Then
                                                        wStartDate1 = CDate(wStartDate1).ToString("yyyy/MM") & "/01"
                                                        wStartDate1 = CDate(wStartDate1).AddMonths(1).AddDays(-1).ToString("yyyy/MM/dd")
                                                    Else
                                                        wStartDate1 = "不明"
                                                    End If

                                                    '終了日付取得(月末日として取得)
                                                    wEndDate1 = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE)
                                                    If IsDate(wEndDate1) Then
                                                        wEndDate1 = CDate(wEndDate1).ToString("yyyy/MM") & "/01"
                                                        wEndDate1 = CDate(wEndDate1).AddMonths(1).AddDays(-1).ToString("yyyy/MM/dd")
                                                    Else
                                                        wEndDate1 = "不明"
                                                    End If
                                                    row.Item("TDateSTART") = wStartDate1
                                                    row.Item("TDateEND") = wEndDate1

                                                    If IsDate(wStartDate1) And IsDate(wEndDate1) Then
                                                        '請求期間　開始年月 + 保証期間 + 標準保守　＞＝　現在のOIO基本契約期間 終了　且つ、
                                                        '請求期間　開始年月 + 保証期間 + 標準保守　＜　延長後のOIO基本契約期間 終了　の場合出力対象
                                                        wStrDate1 = CDate(wStartDate1).AddYears(wInt1).AddMonths(24).ToString("yyyy/MM") & "/01"
                                                        wDate1 = CDate(wStrDate1).AddDays(-1)                       '前月末日にする
                                                        wStrDate2 = CDate(OioEndDate).ToString("yyyy/MM") & "/01"
                                                        wDate2 = CDate(wStrDate2).AddMonths(1).AddDays(-1)          '月末日にする
                                                        wStrDate3 = wExtYear & "/" & wExtMonth & "/01"
                                                        wDate3 = CDate(wStrDate3).AddMonths(1).AddDays(-1)          '月末日にする

                                                        row.Item("TDateEND") = wDate1
                                                        row.Item("MDateEND") = wDate1

                                                        If wDate1 >= wDate2 And wDate1 < wDate3 Then
                                                            '出力対象
                                                            row.Item("RowSTATUS") = "00"
                                                            '出力対象外
                                                            row.Item("RowSTATUS") = "99"
                                                        Else
                                                            '出力対象外
                                                            row.Item("RowSTATUS") = "99"
                                                        End If
                                                    Else
                                                        '出力対象外
                                                        row.Item("RowSTATUS") = "99"
                                                    End If
                                                Else
                                                    '出力対象外
                                                    row.Item("RowSTATUS") = "99"
                                                End If
                                            Else
                                                '出力対象外
                                                row.Item("RowSTATUS") = "99"
                                            End If
                                        Else
                                            '出力対象外
                                            row.Item("RowSTATUS") = "99"
                                        End If
                                    Else
                                        '出力対象外
                                        row.Item("RowSTATUS") = "99"
                                    End If
                                End If

                            Case "13"
                                row.Item("DataKBN2") = "ServicePac"

                                If wStartDate1 = "不明" Or wEndDate1 = "不明" Then
                                    '要確認
                                    row.Item("RowSTATUS") = "01"
                                Else

                                    If IsDate(wStartDate1) Then
                                        'SPYearを取得
                                        wStr1 = GetSPYear(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01))

                                        If IsNumeric(wStr1) Then
                                            '開始年月 + サービス提供期間を年数として加算した値　＞＝　現在のOIO基本契約期間 終了　且つ、
                                            '開始年月 + サービス提供期間を年数として加算した値　＜　延長後のOIO基本契約期間 終了　の場合出力対象
                                            wStrDate1 = CDate(wStartDate1).AddYears(Val(wStr1)).ToString("yyyy/MM") & "/01"
                                            wDate1 = CDate(wStrDate1).AddDays(-1)                       '前月末日にする
                                            wStrDate2 = CDate(OioEndDate).ToString("yyyy/MM") & "/01"
                                            wDate2 = CDate(wStrDate2).AddMonths(1).AddDays(-1)          '月末日にする
                                            wStrDate3 = wExtYear & "/" & wExtMonth & "/01"
                                            wDate3 = CDate(wStrDate3).AddMonths(1).AddDays(-1)          '月末日にする

                                            'row.Item("TDateEND") = wDate1
                                            mDateEnd = CDate(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE)).AddYears(Val(wStr1)).ToString("yyyy/MM") & "/01"
                                            row.Item("MDateEND") = CDate(mDateEnd).AddDays(-1)

                                            If wDate1 >= wDate2 And _
                                               wDate1 < wDate3 Then
                                                '出力対象
                                                row.Item("RowSTATUS") = "00"
                                            Else
                                                '出力対象外
                                                row.Item("RowSTATUS") = "99"
                                            End If
                                        Else
                                            '要確認
                                            row.Item("RowSTATUS") = "01"
                                            row.Item("MDateEND") = "不明"
                                        End If
                                    Else
                                        '要確認
                                        row.Item("RowSTATUS") = "01"
                                        row.Item("MDateEND") = "不明"
                                    End If
                                End If

                            Case "15", "16", "17"
                                row.Item("DataKBN2") = "HWMA"

                                If wStartDate1 = "不明" Or wEndDate1 = "不明" Then
                                    '要確認
                                    row.Item("RowSTATUS") = "01"
                                Else
                                    Select Case row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD)
                                        Case "一括"
                                            '出力対象外
                                            row.Item("RowSTATUS") = "99"

                                        Case "変則", "月額"

                                            '終了日付再取得
                                            wStrDate1 = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12)
                                            If IsDate(wStrDate1) Then
                                                'ｻｰﾋﾞｽ提供期間　終了の年月
                                                wStrDate1 = CDate(wStrDate1).ToString("yyyy/MM")
                                            Else
                                                '請求期間　終了年月
                                                wStrDate1 = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE)
                                                If IsDate(wStrDate1) Then
                                                    wStrDate1 = CDate(wStrDate1).ToString("yyyy/MM")
                                                End If
                                            End If

                                            wStrDate2 = CDate(OioEndDate).ToString("yyyy/MM")

                                            row.Item("MDateEND") = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE)

                                            'ｻｰﾋﾞｽ提供期間　終了の年月　＝　現在のＯＩＯ基本契約期間終了の年月　ならば出力対象
                                            '請求期間　終了年月　＝　現在のＯＩＯ基本契約期間終了の年月　ならば出力対象
                                            If wStrDate1 = wStrDate2 Then
                                                '出力対象
                                                row.Item("RowSTATUS") = "00"
                                            Else
                                                '出力対象外
                                                row.Item("RowSTATUS") = "99"
                                            End If

                                        Case "年額"
                                            '終了日付再取得
                                            wStrDate1 = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12)
                                            If IsDate(wStrDate1) Then
                                                'ｻｰﾋﾞｽ提供期間　終了の年月
                                                wStrDate1 = CDate(wStrDate1).ToString("yyyy/MM")

                                            Else
                                                '請求期間　終了年月　＋　1年
                                                wStrDate1 = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE)
                                                If IsDate(wStrDate1) Then
                                                    wStrDate1 = CDate(wStrDate1).AddYears(1).ToString("yyyy/MM") & "/01"
                                                    wStrDate1 = CDate(wStrDate1).AddDays(-1).ToString("yyyy/MM")  '1年後の前月にする

                                                End If
                                            End If

                                            mDateEnd = CDate(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE)).AddYears(1).ToString("yyyy/MM") & "/01"
                                            row.Item("MDateEND") = CDate(mDateEnd).AddDays(-1).ToString("yyyy/MM")

                                            '現在のＯＩＯ基本契約期間終了の年月
                                            '延長後のＯＩＯ基本契約期間終了の年月
                                            wStrDate2 = CDate(OioEndDate).ToString("yyyy/MM")
                                            wStrDate3 = CDate(wExtYear & "/" & wExtMonth & "/01").ToString("yyyy/MM")

                                            If wStrDate1 >= wStrDate2 And _
                                               wStrDate1 < wStrDate3 Then
                                                '出力対象
                                                row.Item("RowSTATUS") = "00"
                                            Else
                                                '出力対象外
                                                row.Item("RowSTATUS") = "99"
                                            End If
                                        Case Else
                                            '出力対象外
                                            row.Item("RowSTATUS") = "99"
                                    End Select
                                End If

                            Case "18", "19"
                                row.Item("DataKBN2") = "保証ｵﾌﾟｼｮﾝ"

                                If wStartDate1 = "不明" Or wEndDate1 = "不明" Then
                                    '要確認
                                    row.Item("RowSTATUS") = "01"
                                Else

                                    If IsDate(wStrDate1) Then
                                        'WCatテーブルに製品番号が存在する
                                        If GetWCat(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01), wInt1) = True Then
                                            '開始年月 + サービス提供期間を年数として加算した値　＞＝　現在のOIO基本契約期間 終了　且つ、
                                            '開始年月 + サービス提供期間を年数として加算した値　＜　延長後のOIO基本契約期間 終了　の場合出力対象
                                            wStrDate1 = CDate(wStartDate1).AddMonths(wInt1).ToString("yyyy/MM") & "/01"
                                            wDate1 = CDate(wStrDate1).AddDays(-1)                       '前月末日にする
                                            wStrDate2 = CDate(OioEndDate).ToString("yyyy/MM") & "/01"
                                            wDate2 = CDate(wStrDate2).AddMonths(1).AddDays(-1)          '月末日にする
                                            wStrDate3 = wExtYear & "/" & wExtMonth & "/01"
                                            wDate3 = CDate(wStrDate3).AddMonths(1).AddDays(-1)          '月末日にする

                                            'row.Item("TDateEND") = wDate1
                                            mDateEnd = CDate(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE)).AddMonths(wInt1).ToString("yyyy/MM") & "/01"
                                            row.Item("MDateEND") = CDate(mDateEnd).AddDays(-1)

                                            If wDate1 >= wDate2 And _
                                               wDate1 < wDate3 Then
                                                '出力対象
                                                row.Item("RowSTATUS") = "00"
                                            Else
                                                '出力対象外
                                                row.Item("RowSTATUS") = "99"
                                            End If
                                        Else
                                            '要確認
                                            row.Item("RowSTATUS") = "01"
                                            row.Item("MDateEND") = "不明"
                                        End If
                                    Else
                                        '要確認
                                        row.Item("RowSTATUS") = "01"
                                    End If
                                End If
                        End Select

                    Case "11"
                        '03:PA --------------------------------------------------------------------
                        '共通パラメータセット
                        row.Item("DataKBN") = "03"
                        row.Item("DataKBN2") = "継続S&S"
                        row.Item("ENDDATE") = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.WD_DATE)
                        row.Item("MDateSTART") = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE)
                        'row.Item("MDateEND") = wEndDate1

                        'ソートパラメータセット
                        row.Item("SortAsc01") = "03"
                        row.Item("SortAsc03") = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01)
                        row.Item("SortAsc04") = wStartDate1
                        row.Item("SortDsc01") = Val(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.QTY))
                        row.Item("SortDsc02") = Val(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH))

                        'M_Pa_Mediaテーブルに存在
                        If IsPaMedia(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01)) = True Then

                            If wStartDate1 = "不明" Or wEndDate1 = "不明" Then
                                '要確認
                                row.Item("RowSTATUS") = "01"
                            Else
                                '開始日付再取得
                                wStartDate1 = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11)
                                If IsDate(wStartDate1) Then
                                    wStartDate1 = CDate(wStartDate1).ToString("yyyy/MM") & "/01"
                                    wStartDate1 = CDate(wStartDate1).AddMonths(1).AddDays(-1).ToString("yyyy/MM/dd")
                                End If
                                wStartDate2 = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE)
                                If IsDate(wStartDate2) Then
                                    wStartDate2 = CDate(wStartDate2).ToString("yyyy/MM") & "/01"
                                    wStartDate2 = CDate(wStartDate2).AddMonths(1).AddDays(-1).ToString("yyyy/MM/dd")
                                End If

                                '終了日付再取得
                                wEndDate1 = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12)
                                If IsDate(wEndDate1) Then
                                    wEndDate1 = CDate(wEndDate1).ToString("yyyy/MM") & "/01"
                                    wEndDate1 = CDate(wEndDate1).AddMonths(1).AddDays(-1).ToString("yyyy/MM/dd")
                                End If
                                wEndDate2 = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE)
                                If IsDate(wEndDate2) Then
                                    wEndDate2 = CDate(wEndDate2).ToString("yyyy/MM") & "/01"
                                    wEndDate2 = CDate(wEndDate2).AddMonths(1).AddDays(-1).ToString("yyyy/MM/dd")
                                End If

                                '延長後のOIO基本契約期間
                                wStrDate1 = wExtYear & "/" & wExtMonth & "/01"
                                wStrDate1 = CDate(wStrDate1).AddMonths(1).AddDays(-1).ToString("yyyy/MM/dd")

                                mDateEnd = GetNextAnivDate(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE), row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM05))
                                row.Item("MDateEND") = CDate(mDateEnd).AddDays(-1).ToString("yyyy/MM/dd")

                                '項目12(サービス提供期間 終了)が日付、且つ
                                '項目12(サービス提供期間 終了) >= OIO期本契約期間 終了年月の末日
                                '項目12(サービス提供期間 終了) < 延長後のOIO期本契約期間 終了年月の末日
                                If IsDate(wEndDate1) And _
                                   wEndDate1 >= OioEndDate And _
                                   wEndDate1 < wStrDate1 Then
                                    '出力対象
                                    row.Item("RowSTATUS") = "00"
                                Else
                                    '項目12(サービス提供期間 終了)が日付以外、且つ
                                    '請求期間 開始年月 から計算して次のアニバーサリーDateの1日 >= OIO基本契約期間 終了年月の末日
                                    '請求期間 開始年月 から計算して次のアニバーサリーDateの1日 < 延長後のOIO基本契約期間 終了年月の末日
                                    wStrDate2 = GetNextAnivDate(wStartDate2, row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM05))

                                    If wStrDate2 >= OioEndDate And _
                                       wStrDate2 < wStrDate1 Then
                                        '出力対象
                                        row.Item("RowSTATUS") = "00"
                                    Else
                                        '出力対象外
                                        row.Item("RowSTATUS") = "99"
                                    End If
                                End If
                            End If
                        Else
                            '出力対象外
                            row.Item("RowSTATUS") = "99"
                        End If

                    Case "12", "20", "21", "22", "23", "24", "32", "33", "34", "37", "42", "43", "44"
                        '04:その他 ----------------------------------------------------------------
                        '共通パラメータセット
                        row.Item("DataKBN") = "04"
                        row.Item("MDateSTART") = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE)
                        'row.Item("MDateEND") = wEndDate1

                        'ソートパラメータセット
                        row.Item("SortAsc01") = "04"
                        row.Item("SortAsc03") = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01)
                        row.Item("SortAsc04") = wStartDate1
                        row.Item("SortDsc01") = Val(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.QTY))
                        row.Item("SortDsc02") = Val(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH))

                        Select Case Trim(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD))
                            Case "12"
                                row.Item("DataKBN2") = "VLS"
                                row.Item("ENDDATE") = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.WD_DATE)
                            Case "20"
                                row.Item("DataKBN2") = "他社製品(MVMS)"
                            Case "21"
                                row.Item("DataKBN2") = "CISCO保守"
                            Case "22"
                                row.Item("DataKBN2") = "S-Link"
                            Case "23"
                                row.Item("DataKBN2") = "保守拡張"
                            Case "24"
                                row.Item("DataKBN2") = "ﾎｽﾄ系SW"
                            Case "32"
                                row.Item("DataKBN2") = "FMA"
                            Case "33"
                                row.Item("DataKBN2") = "ｵﾌｧﾘﾝｸﾞSW(SRO/ESSO/ELA)"
                            Case "34"
                                row.Item("DataKBN2") = "ｼｽﾃﾑ･ｻｰﾋﾞｽ"
                            Case "37"
                                row.Item("DataKBN2") = "Primo使用サービス"
                            Case "42"
                                row.Item("DataKBN2") = "SO"
                            Case "43"
                                row.Item("DataKBN2") = "ﾍﾞｰｼｯｸ･ｾﾚｸｼｮﾝ"
                            Case "44"
                                row.Item("DataKBN2") = "ﾍﾞｰｼｯｸ･ｾﾚｸｼｮﾝ 追加ｻｰﾋﾞｽ"
                        End Select

                        If wStartDate1 = "不明" Or wEndDate1 = "不明" Then
                            '要確認
                            row.Item("RowSTATUS") = "01"
                        Else
                            '開始日付再取得
                            wStartDate2 = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE)
                            If IsDate(wStartDate2) Then
                                wStartDate2 = CDate(wStartDate2).ToString("yyyy/MM") & "/01"
                            End If

                            '終了日付再取得
                            wEndDate1 = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12)
                            If IsDate(wEndDate1) Then
                                wEndDate1 = CDate(wEndDate1).ToString("yyyy/MM") & "/01"
                                wEndDate1 = CDate(wEndDate1).AddMonths(1).AddDays(-1).ToString("yyyy/MM/dd")
                            End If
                            wEndDate2 = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE)
                            If IsDate(wEndDate2) Then
                                wEndDate2 = CDate(wEndDate2).ToString("yyyy/MM") & "/01"
                                wEndDate2 = CDate(wEndDate2).AddMonths(1).AddDays(-1).ToString("yyyy/MM/dd")
                            End If

                            mDateEnd = wEndDate2
                            row.Item("MDateEND") = mDateEnd

                            Select Case row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD)
                                Case "一括"
                                    '出力対象外
                                    row.Item("RowSTATUS") = "99"

                                Case "変則", "月額"

                                    If IsDate(wEndDate1) Then
                                        'ｻｰﾋﾞｽ提供期間　終了の年月　＝　現在のＯＩＯ基本契約期間終了の年月　ならば出力対象
                                        wStrDate1 = CDate(wEndDate1).ToString("yyyy/MM")
                                        wStrDate2 = CDate(OioEndDate).ToString("yyyy/MM")

                                        If wStrDate1 = wStrDate2 Then
                                            '出力対象
                                            row.Item("RowSTATUS") = "00"
                                        Else
                                            '出力対象外
                                            row.Item("RowSTATUS") = "99"
                                        End If
                                    Else
                                        '請求期間　終了年月　＝　現在のＯＩＯ基本契約期間終了の年月　ならば出力対象
                                        wStrDate1 = CDate(wEndDate2).ToString("yyyy/MM")
                                        wStrDate2 = CDate(OioEndDate).ToString("yyyy/MM")

                                        If wStrDate1 = wStrDate2 Then
                                            '出力対象
                                            row.Item("RowSTATUS") = "00"
                                        Else
                                            '出力対象外
                                            row.Item("RowSTATUS") = "99"
                                        End If
                                    End If

                                Case "年額"

                                    mDateEnd = CDate(wStartDate2).AddYears(1).AddDays(-1).ToString("yyyy/MM")
                                    row.Item("MDateEND") = mDateEnd

                                    If IsDate(wEndDate1) Then
                                        'ｻｰﾋﾞｽ提供期間　終了の年月　＞＝　現在のＯＩＯ基本契約期間終了の年月　且つ、
                                        'ｻｰﾋﾞｽ提供期間　終了の年月　＜　　延長後のＯＩＯ基本契約期間終了の年月　ならば出力対象
                                        wStrDate1 = CDate(wEndDate1).ToString("yyyy/MM")
                                        wStrDate2 = CDate(OioEndDate).ToString("yyyy/MM")
                                        wStrDate3 = CDate(wExtYear & "/" & wExtMonth & "/01").ToString("yyyy/MM")

                                        row.Item("MDateEND") = wStrDate1

                                        If wStrDate1 >= wStrDate2 And _
                                           wStrDate1 < wStrDate3 Then
                                            '出力対象
                                            row.Item("RowSTATUS") = "00"
                                        Else
                                            '出力対象外
                                            row.Item("RowSTATUS") = "99"
                                        End If
                                    Else
                                        '請求期間　開始年月　＋　1年　＞＝　現在のＯＩＯ基本契約期間終了の年月　且つ、
                                        '請求期間　開始年月　＋　1年　＜　　延長後のＯＩＯ基本契約期間終了の年月　ならば出力対象
                                        wStrDate1 = CDate(wStartDate2).AddYears(1).AddDays(-1).ToString("yyyy/MM")
                                        wStrDate2 = CDate(OioEndDate).ToString("yyyy/MM")
                                        wStrDate3 = CDate(wExtYear & "/" & wExtMonth & "/01").ToString("yyyy/MM")

                                        row.Item("MDateEND") = wStrDate1

                                        If wStrDate1 >= wStrDate2 And _
                                           wStrDate1 < wStrDate3 Then
                                            '出力対象
                                            row.Item("RowSTATUS") = "00"
                                        Else
                                            '出力対象外
                                            row.Item("RowSTATUS") = "99"
                                        End If
                                    End If
                            End Select
                        End If

                    Case Else
                        '99:対象外 ------------------------------------------------------------
                        row.Item("DataKBN") = "99"
                        row.Item("SortAsc01") = "99"

                End Select

                rtnTable.ImportRow(row)

                Application.DoEvents()
            Next


            'IGF処理 ==============================================================================
            '            For Each row As DataRow In PSDataTable.Select()
            For Each row As DataRow In PSDataTable.Rows
                If Trim(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_APPLIED)) = "Y" And _
                   Trim(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD)) <> "29" Then
                    '05:IGF -----------------------------------------------------------------------
                    '共通パラメータセット
                    row.Item("DataKBN") = "05"
                    row.Item("TDateSTART") = ""
                    row.Item("TDateEND") = ""
                    row.Item("MDateSTART") = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_START_DATE)
                    row.Item("MDateEND") = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_END_DATE)

                    'ソートパラメータセット
                    row.Item("SortAsc01") = "05"
                    row.Item("SortAsc03") = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01)
                    row.Item("SortAsc04") = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_END_DATE)

                    '削除元情報を検索してセット
                    wDeleteNo = GetDeleteNo(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO), _
                                            row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10))
                    row.Item("DeleteNO") = wDeleteNo
                    row.Item("SortAsc02") = wDeleteNo

                    'Payment種別をセット
                    row.Item("PsKBN") = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG)

                    If Trim(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD)) = "30" Then
                        'IGF再リース
                        row.Item("DataKBN2") = "再リース"
                    Else
                        'IGF再リース以外
                        row.Item("DataKBN2") = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_FORM)
                    End If

                    '開始日付再取得
                    wStartDate1 = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_START_DATE)
                    If IsDate(wStartDate1) Then
                        wStartDate1 = CDate(wStartDate1).ToString("yyyy/MM") & "/01"
                        wStartDate1 = CDate(wStartDate1).AddMonths(1).AddDays(-1).ToString("yyyy/MM/dd")
                    Else
                        '要確認
                        row.Item("RowSTATUS") = "01"
                    End If

                    '終了日付再取得
                    wEndDate1 = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_END_DATE)
                    If IsDate(wEndDate1) Then
                        wEndDate1 = CDate(wEndDate1).ToString("yyyy/MM") & "/01"
                        wEndDate1 = CDate(wEndDate1).AddMonths(1).AddDays(-1).ToString("yyyy/MM/dd")
                    Else
                        '要確認
                        row.Item("RowSTATUS") = "01"
                    End If


                    'ＩＧＦ支払期間　終了年月　＞＝　現在のＯＩＯ基本契約期間終了の年月　且つ、
                    'ＩＧＦ支払期間　終了年月　＜　　延長後のＯＩＯ基本契約期間終了の年月　ならば出力対象
                    'IGF終了日付取得
                    If IsDate(wEndDate1) Then
                        'IGF支払期間
                        wStrDate1 = CDate(wEndDate1).ToString("yyyy/MM")

                        '延長後のOIO基本契約期間
                        wStrDate2 = CDate(wExtYear & "/" & wExtMonth & "/01").ToString("yyyy/MM")

                        If wStrDate1 >= CDate(OioEndDate).ToString("yyyy/MM") And _
                           wStrDate1 < wStrDate2 Then
                            '出力対象
                            row.Item("RowSTATUS") = "00"
                        Else
                            '対象外
                            row.Item("RowSTATUS") = "99"
                        End If
                    Else
                        '要確認
                        row.Item("RowSTATUS") = "01"
                    End If

                    rtnTable.ImportRow(row)

                    Application.DoEvents()
                End If
            Next

            Return rtnTable

        Catch ex As Exception
            ''Throw ex
            MsgBox("エラーが発生しました。 LINE_NO=[" & LINENO & "]")
        End Try
    End Function

    ''' <summary>
    ''' 概 要：Paymentデータテーブルを元に延長候補明細シートを作成する。
    ''' 説 明：
    ''' </summary>
    ''' <param name="xlIocSheet">Paymentデータテーブル(入力)</param>
    ''' <param name="ExtensionFilePath">延長候補リスト明細シート(出力)</param>
    ''' <param name="PaymentPeriod">Payment展開期間</param>
    ''' <remarks></remarks>
    Private Sub MakeExtensionListData(ByVal PSDataTable As DataTable, _
                                      ByVal xlExtsheet As Excel.Worksheet)
        Dim ew As New ExcelWrite

        ''Excel変数の宣言
        Dim xlApp As New Excel.Application
        'RANGE
        Dim xlPasteCell As Excel.Range
        Dim xlCopyCell As Excel.Range
        'BORDER
        Dim xlBorder As Excel.Border

        Const ConfirmMsg01 As String = "削除情報があります"
        Const confirmMsg02 As String = "ｻｰﾋﾞｽ提供期間が不明です"

        Dim MyArray(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12 + ExtPlusCol) As Object

        Dim ii As Integer
        Dim LL As Integer

        Const CopyCount As Integer = 1000           ''一度のｺﾋﾟｰ行数
        Dim pasteCount As Integer                   ''貼付回数
        Dim strCopyIdx As Integer                   ''ｺﾋﾟｰ範囲：開始位置
        Dim endCopyIdx As Integer                   ''ｺﾋﾟｰ範囲：終了位置
        Dim wCount As Integer = 0

        Try
            ''------------------------------------------------------------------
            ''      テンプレート行コピー
            ''------------------------------------------------------------------
            '件数カウント
            For Each row As DataRow In PSDataTable.Select()
                If row.Item("DataKBN") <> "99" Then
                    If row.Item("RowSTATUS") <> "99" Then
                        If row.Item("PsKBN") <> "D" Then
                            wCount = wCount + 1
                        Else
                            If row.Item("RowSTATUS") = "01" Then
                                wCount = wCount + 1
                            Else
                                If wDelDataOutput = True Then
                                    wCount = wCount + 1
                                End If
                            End If
                        End If
                    End If
                End If
            Next

            'テンプレート行コピー
            pasteCount = Math.Truncate((wCount - 1) / CopyCount) + 1
            xlCopyCell = xlExtsheet.Rows(3)
            xlCopyCell.Hidden = False

            For PasteIdx As Integer = 1 To pasteCount
                ''開始/終了位置を取得
                strCopyIdx = (PasteIdx - 1) * CopyCount + EXCEL_EXTENSIONLIST_OUTROW
                If wCount >= (PasteIdx * CopyCount) Then
                    endCopyIdx = (PasteIdx * CopyCount) + EXCEL_EXTENSIONLIST_OUTROW - 1
                Else
                    endCopyIdx = strCopyIdx + (wCount Mod CopyCount) - 1
                End If

                ''コピペ実行
                xlPasteCell = xlExtsheet.Rows(strCopyIdx & ":" & endCopyIdx)
                Call xlCopyCell.Copy()
                Call xlPasteCell.PasteSpecial()
            Next
            xlCopyCell.Hidden = True

            ''------------------------------------------------------------------
            ''      データ行コピー
            ''------------------------------------------------------------------
            'データ部登録
            ii = EXCEL_EXTENSIONLIST_OUTROW
            For Each row As DataRow In PSDataTable.Select()
                MyArray(0, 1) = ""
                MyArray(0, 3) = ""

                'データテーブルの値を配列にセット

                'データ区分
                Select Case row.Item("DataKBN")
                    Case "01"
                        MyArray(0, 0) = "AAS SW"
                    Case "02"
                        MyArray(0, 0) = "HWMA"
                    Case "03"
                        MyArray(0, 0) = "PA"
                    Case "04"
                        MyArray(0, 0) = "その他"
                    Case "05"
                        MyArray(0, 0) = "IGF"
                    Case "99"
                        MyArray(0, 0) = "OTHER"     '最終的に出力しない
                End Select

                ''削除情報を出さない場合、行をオミット
                If row.Item("DeleteNO") <> "" Then
                    MyArray(0, 1) = "要確認"
                    MyArray(0, 3) = ConfirmMsg01
                End If

                'チェック結果
                Select Case row.Item("RowSTATUS")
                    Case "", "00"
                        If MyArray(0, 1) = "" Then
                            MyArray(0, 1) = "対象"
                        End If
                    Case "01"
                        MyArray(0, 1) = "要確認"
                        If MyArray(0, 3) = "" Then
                            MyArray(0, 3) = confirmMsg02
                        Else
                            MyArray(0, 3) = MyArray(0, 3) & vbCrLf & confirmMsg02
                        End If
                    Case "99"
                        MyArray(0, 1) = "OMIT"  '最終的に出力しない
                End Select

                'Payment種別="D"のデータをオミット
                If row.Item("PsKBN") = "D" And _
                   wDelDataOutput = False Then
                    MyArray(0, 1) = "DELETE"    '最終的に出力しない
                End If

                '種類
                MyArray(0, 2) = row.Item("DataKBN2")
                '製品活動終了予定
                MyArray(0, 4) = row.Item("ENDDATE")
                'EOS予定
                MyArray(0, 5) = row.Item("EOSDATE")
                '削除情報
                MyArray(0, 6) = row.Item("DeleteNO")
                '提供開始
                MyArray(0, 7) = row.Item("TDateSTART")
                '提供終了
                MyArray(0, 8) = row.Item("TDateEND")
                'マスタ開始
                MyArray(0, 9) = row.Item("MDateSTART")
                'マスタ終了
                MyArray(0, 10) = row.Item("MDateEND")

                'Payment部データ
                For LL = ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG To ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12
                    MyArray(0, LL + ExtPlusCol - 1) = row.Item("CellNM" & LL)
                Next

                If MyArray(0, 0) = "OTHER" Or _
                   MyArray(0, 1) = "DELETE" Or _
                   MyArray(0, 1) = "OMIT" Then
                    'デバッグ時、対象外行を残したい場合はここ↓にELSE以下をコピーする
                Else
                    ''データ貼り込み
                    xlPasteCell = xlExtsheet.Range(ew.ChgExcelRowNumberToChar(ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG) & ii & ":" & _
                                                   ew.ChgExcelRowNumberToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12 + ExtPlusCol) & ii)
                    xlPasteCell.Value = MyArray

                    '要確認行に色を付ける
                    If MyArray(0, 1) = "要確認" Then
                        xlPasteCell = xlExtsheet.Range("A" & ii & ":" & _
                                                       ew.ChgExcelRowNumberToChar(ExtPlusCol) & ii)
                        xlPasteCell.Interior.Color = RGB(255, 255, 0).ToString
                    End If
                    ExcelObjRelease.ReleaseExcelObj(xlCopyCell, ExcelObjRelease.OBJECT_NOTHING)
                    ExcelObjRelease.ReleaseExcelObj(xlPasteCell, ExcelObjRelease.OBJECT_NOTHING)

                    ii = ii + 1
                End If
            Next

            ''------------------------------------------------------------------
            ''      範囲外データ非表示・削除
            ''------------------------------------------------------------------
            '年額非表示
            For ii = ColYearStart To ColYearEnd
                If ii - ColYearStart = CommonVariable.PaymentPeriod Then
                    xlCopyCell = xlExtsheet.Columns(ew.ChgExcelRowNumberToChar(ii) & ":" & ew.ChgExcelRowNumberToChar(ColYearEnd))
                    xlCopyCell.Hidden = True
                    Exit For
                End If
            Next

            '月額非表示部分を削除する
            For ii = 20 To 1 Step -1
                If ii > CommonVariable.PaymentPeriod Then
                    'IBM Confidentialを前年位置に移動する
                    xlCopyCell = xlExtsheet.Cells(4, ColMonthStart + ii * 12 - 1)
                    xlPasteCell = xlExtsheet.Cells(4, ColMonthStart + ii * 12 - 13)
                    Call xlCopyCell.Copy()
                    Call xlPasteCell.PasteSpecial()

                    '列の削除
                    xlCopyCell = xlExtsheet.Columns(ew.ChgExcelRowNumberToChar(ColMonthStart + ii * 12 - 12) & ":" & _
                                                    ew.ChgExcelRowNumberToChar(ColMonthStart + ii * 12 - 1))
                    xlCopyCell.Delete()

                    '罫線の引き直し
                    xlCopyCell = xlExtsheet.Cells(5, ColMonthStart + ii * 12 - 13)
                    xlBorder = xlCopyCell.Borders(Excel.XlBordersIndex.xlEdgeRight)
                    xlBorder.LineStyle = Excel.XlLineStyle.xlContinuous
                End If
            Next

        Catch ex As Exception
            MsgBox(ex)
        Finally
            ExcelObjRelease.ReleaseExcelObj(xlBorder, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCopyCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPasteCell, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' 概 要：延長候補リストの各件数をカウントする。
    ''' 説 明：
    ''' </summary>
    ''' <param name="ExtDataTable">延長候補明細テーブル</param>
    ''' <remarks></remarks>
    Private Sub ExtensionListCount(ByVal ExtDataTable As DataTable)
        ''Excel変数の宣言
        Dim xlApp As New Excel.Application

        Try
            ''------------------------------------------------------------------
            ''      パターンNO毎にカウント
            ''------------------------------------------------------------------
            ''
            For Each row As DataRow In ExtDataTable.Select()
                'パターンNO判定
                Select Case row.Item("DataKBN")
                    Case "01"
                        'AASHW
                        ExtAASHW.Total = ExtAASHW.Total + 1

                        If wDelDataOutput = True Then
                            '削除情報を出力する
                            Select Case row.Item("RowSTATUS")
                                Case "", "00"
                                    If row.Item("PsKBN") <> "B" And _
                                       row.Item("PsKBN") <> "D" Then
                                        '通常行
                                        ExtAASHW.Target = ExtAASHW.Target + 1
                                    Else
                                        '削除行(要確認)
                                        If row.Item("DeleteNO") = "" Then
                                            ExtAASHW.Target = ExtAASHW.Target + 1
                                        Else
                                            ExtAASHW.Confirm = ExtAASHW.Confirm + 1
                                        End If
                                        '2015/11 延長候補修正 End
                                    End If
                                Case "01"
                                    ExtAASHW.Confirm = ExtAASHW.Confirm + 1
                                Case Else   '"99"
                                    ExtAASHW.NonTarget = ExtAASHW.NonTarget + 1
                            End Select
                        Else
                            '削除情報を出力しない
                            Select Case row.Item("RowSTATUS")
                                Case "", "00"
                                    If row.Item("PsKBN") <> "B" And _
                                       row.Item("PsKBN") <> "D" Then
                                        '通常行
                                        ExtAASHW.Target = ExtAASHW.Target + 1
                                    Else
                                        If row.Item("PsKBN") = "D" And _
                                            row.Item("DeleteNO") <> "" Then
                                            '削除行(対象外)
                                            ExtAASHW.NonTarget = ExtAASHW.NonTarget + 1
                                        Else
                                            ExtAASHW.Confirm = ExtAASHW.Confirm + 1
                                        End If
                                    End If
                                Case "01"
                                    ExtAASHW.Confirm = ExtAASHW.Confirm + 1
                                Case Else   '"99"
                                    ExtAASHW.NonTarget = ExtAASHW.NonTarget + 1
                            End Select
                        End If

                    Case "02"
                        'HWMA
                        ExtHWMA.Total = ExtHWMA.Total + 1

                        If wDelDataOutput = True Then
                            '削除情報を出力する
                            Select Case row.Item("RowSTATUS")
                                Case "", "00"
                                    If row.Item("PsKBN") <> "B" And _
                                       row.Item("PsKBN") <> "D" Then
                                        '通常行
                                        ExtHWMA.Target = ExtHWMA.Target + 1
                                    Else
                                        '削除行(要確認)
                                        If row.Item("DeleteNO") = "" Then
                                            ExtHWMA.Target = ExtHWMA.Target + 1
                                        Else
                                            ExtHWMA.Confirm = ExtHWMA.Confirm + 1
                                        End If
                                    End If
                                Case "01"
                                    ExtHWMA.Confirm = ExtHWMA.Confirm + 1
                                Case Else   '"99"
                                    ExtHWMA.NonTarget = ExtHWMA.NonTarget + 1
                            End Select
                        Else
                            '削除情報を出力しない
                            Select Case row.Item("RowSTATUS")
                                Case "", "00"
                                    If row.Item("PsKBN") <> "B" And _
                                       row.Item("PsKBN") <> "D" Then
                                        '通常行
                                        ExtHWMA.Target = ExtHWMA.Target + 1
                                    Else
                                        If row.Item("PsKBN") = "D" And _
                                            row.Item("DeleteNO") <> "" Then
                                            '削除行(対象外)
                                            ExtHWMA.NonTarget = ExtHWMA.NonTarget + 1
                                        Else
                                            ExtHWMA.Confirm = ExtHWMA.Confirm + 1
                                        End If
                                    End If
                                Case "01"
                                    ExtHWMA.Confirm = ExtHWMA.Confirm + 1
                                Case Else   '"99"
                                    ExtHWMA.NonTarget = ExtHWMA.NonTarget + 1
                            End Select
                        End If

                    Case "03"
                        'PA
                        ExtPA.Total = ExtPA.Total + 1

                        If wDelDataOutput = True Then
                            '削除情報を出力する
                            Select Case row.Item("RowSTATUS")
                                Case "", "00"
                                    If row.Item("PsKBN") <> "B" And _
                                       row.Item("PsKBN") <> "D" Then
                                        '通常行
                                        ExtPA.Target = ExtPA.Target + 1
                                    Else
                                        '削除行(要確認)
                                        If row.Item("DeleteNO") = "" Then
                                            ExtPA.Target = ExtPA.Target + 1
                                        Else
                                            ExtPA.Confirm = ExtPA.Confirm + 1
                                        End If
                                        ''ExtPA.Confirm = ExtPA.Confirm + 1
                                    End If
                                Case "01"
                                    ExtPA.Confirm = ExtPA.Confirm + 1
                                Case Else   '"99"
                                    ExtPA.NonTarget = ExtPA.NonTarget + 1
                            End Select
                        Else
                            '削除情報を出力しない
                            Select Case row.Item("RowSTATUS")
                                Case "", "00"
                                    If row.Item("PsKBN") <> "B" And _
                                       row.Item("PsKBN") <> "D" Then
                                        '通常行
                                        ExtPA.Target = ExtPA.Target + 1
                                    Else
                                        If row.Item("PsKBN") = "D" And _
                                            row.Item("DeleteNO") <> "" Then
                                            '削除行(対象外)
                                            ExtPA.NonTarget = ExtPA.NonTarget + 1
                                        Else
                                            ExtPA.Confirm = ExtPA.Confirm + 1
                                        End If
                                    End If
                                Case "01"
                                    ExtPA.Confirm = ExtPA.Confirm + 1
                                Case Else   '"99"
                                    ExtPA.NonTarget = ExtPA.NonTarget + 1
                            End Select
                        End If

                    Case "04"
                        'その他
                        ExtOther.Total = ExtOther.Total + 1

                        If wDelDataOutput = True Then
                            '削除情報を出力する
                            Select Case row.Item("RowSTATUS")
                                Case "", "00"
                                    If row.Item("PsKBN") <> "B" And _
                                       row.Item("PsKBN") <> "D" Then
                                        '通常行
                                        ExtOther.Target = ExtOther.Target + 1
                                    Else
                                        '削除行(要確認)
                                        If row.Item("DeleteNO") = "" Then
                                            ExtOther.Target = ExtOther.Target + 1
                                        Else
                                            ExtOther.Confirm = ExtOther.Confirm + 1
                                        End If
                                    End If
                                Case "01"
                                    ExtOther.Confirm = ExtOther.Confirm + 1
                                Case Else   '"99"
                                    ExtOther.NonTarget = ExtOther.NonTarget + 1
                            End Select
                        Else
                            '削除情報を出力しない
                            Select Case row.Item("RowSTATUS")
                                Case "", "00"
                                    If row.Item("PsKBN") <> "B" And _
                                       row.Item("PsKBN") <> "D" Then
                                        '通常行
                                        ExtOther.Target = ExtOther.Target + 1
                                    Else
                                        If row.Item("PsKBN") = "D" And _
                                            row.Item("DeleteNO") <> "" Then
                                            '削除行(対象外)
                                            ExtOther.NonTarget = ExtOther.NonTarget + 1
                                        Else
                                            ExtOther.Confirm = ExtOther.Confirm + 1
                                        End If
                                    End If
                                Case "01"
                                    ExtOther.Confirm = ExtOther.Confirm + 1
                                Case Else   '"99"
                                    ExtOther.NonTarget = ExtOther.NonTarget + 1
                            End Select
                        End If

                    Case "05"
                    Case Else
                        '対象外
                        ExtNonTarget.Total = ExtNonTarget.Total + 1
                End Select

                'IGFカウント
                If row.Item("DataKBN") = "05" Then
                    If row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD) = "30" Then
                        'IGF再リース
                        ExtIgfLease.Total = ExtIgfLease.Total + 1

                        If wDelDataOutput = True Then
                            '削除情報を出力する
                            Select Case row.Item("RowSTATUS")
                                Case "", "00"
                                    If row.Item("PsKBN") <> "B" And _
                                       row.Item("PsKBN") <> "D" Then
                                        '通常行
                                        ExtIgfLease.Target = ExtIgfLease.Target + 1
                                    Else
                                        '削除行(要確認)
                                        If row.Item("DeleteNO") = "" Then
                                            ExtIgfLease.Target = ExtIgfLease.Target + 1
                                        Else
                                            ExtIgfLease.Confirm = ExtIgfLease.Confirm + 1
                                        End If
                                    End If
                                Case "01"
                                    ExtIgfLease.Confirm = ExtIgfLease.Confirm + 1
                                Case Else   '"99"
                                    ExtIgfLease.NonTarget = ExtIgfLease.NonTarget + 1
                            End Select
                        Else
                            '削除情報を出力しない
                            Select Case row.Item("RowSTATUS")
                                Case "", "00"
                                    If row.Item("PsKBN") <> "B" And _
                                       row.Item("PsKBN") <> "D" Then
                                        '通常行
                                        ExtIgfLease.Target = ExtIgfLease.Target + 1
                                    Else
                                        If row.Item("PsKBN") = "D" And _
                                            row.Item("DeleteNO") <> "" Then
                                            '削除行(対象外)
                                            ExtIgfLease.NonTarget = ExtIgfLease.NonTarget + 1
                                        Else
                                            ExtIgfLease.Confirm = ExtIgfLease.Confirm + 1
                                        End If
                                    End If
                                Case "01"
                                    ExtIgfLease.Confirm = ExtIgfLease.Confirm + 1
                                Case Else   '"99"
                                    ExtIgfLease.NonTarget = ExtIgfLease.NonTarget + 1
                            End Select
                        End If
                    Else
                        'IGF再リース以外
                        ExtIgfExLease.Total = ExtIgfExLease.Total + 1

                        If wDelDataOutput = True Then
                            '削除情報を出力する
                            Select Case row.Item("RowSTATUS")
                                Case "", "00"
                                    If row.Item("PsKBN") <> "B" And _
                                       row.Item("PsKBN") <> "D" Then
                                        '通常行
                                        ExtIgfExLease.Target = ExtIgfExLease.Target + 1
                                    Else
                                        If row.Item("DeleteNO") = "" Then
                                            ExtIgfExLease.Target = ExtIgfExLease.Target + 1
                                        Else
                                            ExtIgfExLease.Confirm = ExtIgfExLease.Confirm + 1
                                        End If
                                    End If
                                Case "01"
                                    ExtIgfExLease.Confirm = ExtIgfExLease.Confirm + 1
                                Case Else   '"99"
                                    ExtIgfExLease.NonTarget = ExtIgfExLease.NonTarget + 1
                            End Select
                        Else
                            '削除情報を出力しない
                            Select Case row.Item("RowSTATUS")
                                Case "", "00"
                                    If row.Item("PsKBN") <> "B" And _
                                       row.Item("PsKBN") <> "D" Then
                                        '通常行
                                        ExtIgfExLease.Target = ExtIgfExLease.Target + 1
                                    Else
                                        If row.Item("PsKBN") = "D" And _
                                            row.Item("DeleteNO") <> "" Then
                                            '削除行(対象外)
                                            ExtIgfExLease.NonTarget = ExtIgfExLease.NonTarget + 1
                                        Else
                                            ExtIgfExLease.Confirm = ExtIgfExLease.Confirm + 1
                                        End If
                                    End If
                                Case "01"
                                    ExtIgfExLease.Confirm = ExtIgfExLease.Confirm + 1
                                Case Else   '"99"
                                    ExtIgfExLease.NonTarget = ExtIgfExLease.NonTarget + 1
                            End Select
                        End If
                    End If
                End If
            Next

        Catch ex As Exception
            MsgBox(ex)
        Finally
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()

        End Try
    End Sub

    ''' <summary>
    ''' 概 要：延長候補リストの出力結果シートにデータをセットする。
    ''' 説 明：
    ''' </summary>
    ''' <param name="ExtSheet">延長候補出力結果シート</param>
    ''' <remarks></remarks>
    Private Sub ExtensionOutput(ByVal ExtSheet As Excel.Worksheet)

        ''Excel変数の宣言
        Dim xlApp As New Excel.Application
        Dim xlCell As Excel.Range

        Try
            ''------------------------------------------------------------------
            ''      共通項目をセット
            ''------------------------------------------------------------------
            xlCell = ExtSheet.Cells(4, 2)
            xlCell.Value = CommonVariable.CPNO

            xlCell = ExtSheet.Cells(4, 3)
            xlCell.Value = CommonVariable.CUSTOMERNAME

            xlCell = ExtSheet.Cells(4, 6)
            xlCell.Value = CommonVariable.ContractStart.ToString

            xlCell = ExtSheet.Cells(4, 7)
            xlCell.Value = CDate(OioEndYear & "/" & OioEndMonth & "/01")

            xlCell = ExtSheet.Cells(4, 8)
            xlCell.Value = CommonVariable.PaymentStart.ToString("yyyy")

            xlCell = ExtSheet.Cells(4, 9)
            xlCell.Value = CommonVariable.PaymentStart.AddYears(CommonVariable.PaymentPeriod).ToString("yyyy")

            '作成日
            xlCell = ExtSheet.Cells(6, 3)
            xlCell.Value = Now.ToString
            '延長後の基本契約期間終了
            xlCell = ExtSheet.Cells(7, 3)
            xlCell.Value = wExtYear & "年" & wExtMonth & "月"
            '削除データ出力
            xlCell = ExtSheet.Cells(8, 3)
            If wDelDataOutput = True Then
                xlCell.Value = "する"
            Else
                xlCell.Value = "しない"
            End If

            'PaymentLine数
            xlCell = ExtSheet.Cells(6, 6)
            xlCell.Value = ExtPSTotal
            '詳細Line数
            xlCell = ExtSheet.Cells(7, 6)
            xlCell.Value = ExtPDTotal

            ''------------------------------------------------------------------
            ''      パターンNO別件数をセット
            ''------------------------------------------------------------------
            'AASHW件数
            xlCell = ExtSheet.Cells(13, 3)
            xlCell.Value = ExtAASHW.Total

            xlCell = ExtSheet.Cells(13, 4)
            xlCell.Value = ExtAASHW.Target

            xlCell = ExtSheet.Cells(13, 5)
            xlCell.Value = ExtAASHW.Confirm

            xlCell = ExtSheet.Cells(13, 6)
            xlCell.Value = ExtAASHW.NonTarget

            'HWMA件数
            xlCell = ExtSheet.Cells(14, 3)
            xlCell.Value = ExtHWMA.Total

            xlCell = ExtSheet.Cells(14, 4)
            xlCell.Value = ExtHWMA.Target

            xlCell = ExtSheet.Cells(14, 5)
            xlCell.Value = ExtHWMA.Confirm

            xlCell = ExtSheet.Cells(14, 6)
            xlCell.Value = ExtHWMA.NonTarget

            'PA件数
            xlCell = ExtSheet.Cells(15, 3)
            xlCell.Value = ExtPA.Total

            xlCell = ExtSheet.Cells(15, 4)
            xlCell.Value = ExtPA.Target

            xlCell = ExtSheet.Cells(15, 5)
            xlCell.Value = ExtPA.Confirm

            xlCell = ExtSheet.Cells(15, 6)
            xlCell.Value = ExtPA.NonTarget

            'その他件数
            xlCell = ExtSheet.Cells(16, 3)
            xlCell.Value = ExtOther.Total

            xlCell = ExtSheet.Cells(16, 4)
            xlCell.Value = ExtOther.Target

            xlCell = ExtSheet.Cells(16, 5)
            xlCell.Value = ExtOther.Confirm

            xlCell = ExtSheet.Cells(16, 6)
            xlCell.Value = ExtOther.NonTarget

            '対象外件数
            xlCell = ExtSheet.Cells(17, 3)
            xlCell.Value = ExtNonTarget.Total

            'IGF再リース件数
            xlCell = ExtSheet.Cells(22, 3)
            xlCell.Value = ExtIgfLease.Total

            xlCell = ExtSheet.Cells(22, 4)
            xlCell.Value = ExtIgfLease.Target

            xlCell = ExtSheet.Cells(22, 5)
            xlCell.Value = ExtIgfLease.Confirm

            xlCell = ExtSheet.Cells(22, 6)
            xlCell.Value = ExtIgfLease.NonTarget

            'IGF再リース以外件数
            xlCell = ExtSheet.Cells(23, 3)
            xlCell.Value = ExtIgfExLease.Total

            xlCell = ExtSheet.Cells(23, 4)
            xlCell.Value = ExtIgfExLease.Target

            xlCell = ExtSheet.Cells(23, 5)
            xlCell.Value = ExtIgfExLease.Confirm

            xlCell = ExtSheet.Cells(23, 6)
            xlCell.Value = ExtIgfExLease.NonTarget

        Catch ex As Exception
            MsgBox(ex)
        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()

        End Try
    End Sub

    ''' <summary>
    ''' 概 要：削除番号取得
    ''' 説 明：削除元、削除先であればNOを返す
    ''' </summary>
    ''' <param name="LINE_NO">LINE_NOの値</param>
    ''' <param name="ITEM10">項目１０の値</param>
    ''' <remarks></remarks>
    Private Function GetDeleteNo(ByVal LINE_NO As String, _
                                 ByVal ITEM10 As String) As String

        Const DeleteNM As String = "削除元NO = "

        Dim filter As New StringBuilder

        Try
            GetDeleteNo = ""

            If ITEM10.IndexOf(DeleteNM) = -1 Then
                '項目１０に「削除元NO = 」が含まれていない → テーブルを検索
                filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10)
                filter.Append(CommonConstant.SQL_STR_EQUAL)
                filter.Append(StringEdit.EncloseSingleQuotation(DeleteNM & Val(LINE_NO)))

                For Each row As DataRow In Item10Table.Select(filter.ToString)
                    '検索された削除NOを取得
                    GetDeleteNo = Replace(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10), DeleteNM, "")
                    Exit For
                Next
            Else
                '項目１０に「削除元NO = 」が含まれている → 削除NOをそのまま返す
                GetDeleteNo = Replace(ITEM10, DeleteNM, "")
            End If

        Catch ex As Exception
            MsgBox("削除情報の取得に失敗しました。 [" & LINE_NO & "}")
            Throw ex

        End Try

    End Function


    ''' <summary>
    ''' 概 要：HW製品番号・シリアル存在確認
    ''' 説 明：
    ''' </summary>
    ''' <param name="PSDataTable">Paymentデータテーブル</param>
    ''' <param name="PROD_ITEM01">項目０１値</param>
    ''' <param name="PROD_ITEM02">項目０２値</param>
    ''' <remarks></remarks>
    Private Function IsHW(ByVal PSDataTable As PSExcelDataTable, _
                          ByVal PROD_ITEM01 As String, _
                          ByVal PROD_ITEM02 As String) As Boolean
        Dim filter As New StringBuilder

        IsHW = False

        ''項目１０を後方一致検索
        filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(PROD_ITEM01))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(PROD_ITEM02))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD)
        filter.Append(CommonConstant.SQL_STR_IN)
        filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        filter.Append(StringEdit.EncloseSingleQuotation("13"))
        filter.Append(CommonConstant.STR_COMMA)
        filter.Append(StringEdit.EncloseSingleQuotation("15"))
        filter.Append(CommonConstant.STR_COMMA)
        filter.Append(StringEdit.EncloseSingleQuotation("16"))
        filter.Append(CommonConstant.STR_COMMA)
        filter.Append(StringEdit.EncloseSingleQuotation("18"))
        filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

        For Each row As DataRow In PSDataTable.Select(filter.ToString)
            '存在すればTRUE
            IsHW = True
        Next

    End Function

    ''' <summary>
    ''' 概 要：HW製品番号・シリアル存在確認
    ''' 説 明：
    ''' </summary>
    ''' <param name="PSDataTable">Paymentデータテーブル</param>
    ''' <param name="FILE_NAME">ファイル名</param>
    ''' <param name="SUFFIX">ファイル内構成連番</param>
    ''' <param name="CONTRACT">契約順番</param>
    ''' <remarks></remarks>
    Private Function IsSameContract(ByVal PSDataTable As PSExcelDataTable, _
                                    ByVal FILE_NAME As String, _
                                    ByVal SUFFIX As String, _
                                    ByVal CONTRACT As String) As Boolean
        Dim filter As New StringBuilder

        IsSameContract = False

        ''項目１０を後方一致検索
        filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(FILE_NAME))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(SUFFIX))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(CONTRACT))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD)
        filter.Append(CommonConstant.SQL_STR_IN)
        filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        filter.Append(StringEdit.EncloseSingleQuotation("13"))
        filter.Append(CommonConstant.STR_COMMA)
        filter.Append(StringEdit.EncloseSingleQuotation("15"))
        filter.Append(CommonConstant.STR_COMMA)
        filter.Append(StringEdit.EncloseSingleQuotation("16"))
        filter.Append(CommonConstant.STR_COMMA)
        filter.Append(StringEdit.EncloseSingleQuotation("17"))
        filter.Append(CommonConstant.STR_COMMA)
        filter.Append(StringEdit.EncloseSingleQuotation("18"))
        filter.Append(CommonConstant.STR_COMMA)
        filter.Append(StringEdit.EncloseSingleQuotation("19"))
        filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

        For Each row As DataRow In PSDataTable.Select(filter.ToString)
            '存在すればTRUE
            IsSameContract = True
        Next

    End Function

    ''' <summary>
    ''' 概 要：継続製品番号判定
    ''' 説 明：
    ''' </summary>
    ''' <param name="PROD_ITEM01">項目０１値</param>
    ''' <remarks></remarks>
    Private Function IsSWMA(ByVal PROD_ITEM01 As String) As Boolean

        Dim wStr1 As String
        Dim wStr2 As String
        Dim wInt1 As Integer
        Dim wRows As DataRow()
        Dim filter As New StringBuilder

        Try
            IsSWMA = False

            '項目１の値を、ハイフンで前後に切り分ける
            wInt1 = InStr(1, PROD_ITEM01, "-")
            If wInt1 > 0 Then
                wStr1 = Mid(PROD_ITEM01, 1, wInt1 - 1)
                wStr2 = Mid(PROD_ITEM01, wInt1 + 1)
            Else
                'ハイフンが無ければ、文字数で切り出す
                wStr1 = Strings.Left(PROD_ITEM01, 4)
                wStr2 = Strings.Right(PROD_ITEM01, 3)
            End If

            ''swmaテーブルを検索
            filter.Append(SwmaTable.COLUMN_NAME_MACHINETYPE)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(wStr1))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append(SwmaTable.COLUMN_NAME_MODEL)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(wStr2))

            For Each row As DataRow In SwmaTBL.Select(filter.ToString)
                If Not IsDBNull(row.Item("SwmaYear")) Then
                    wSwmaYear = row.Item("SwmaYear")
                    IsSWMA = True
                    Exit For
                End If
            Next

        Catch ex As Exception
            MsgBox("swmaからの読み込みに失敗しました。 [" & PROD_ITEM01 & "}")
            Throw ex
        End Try
    End Function

    ''' <summary>
    ''' 概 要：StdMainte存在確認
    ''' 説 明：
    ''' </summary>
    ''' <param name="PROD_ITEM01">項目０１値</param>
    ''' <remarks></remarks>
    Private Function IsStdMainte(ByVal PROD_ITEM01 As String) As Boolean

        Dim con As OleDbConnection
        Dim mmc As New MasterMdbControl
        Dim stm As New OleDbStdMainte
        con = mmc.GetOleDBConnection(CommonVariable.MdbPW)

        Dim wStr1 As String
        Dim wStr2 As String
        Dim wInt1 As Integer
        Dim wRows As DataRow()

        Try
            IsStdMainte = False

            '項目１の値を、ハイフンで前後に切り分ける
            wInt1 = InStr(1, PROD_ITEM01, "-")
            If wInt1 > 0 Then
                wStr1 = Mid(PROD_ITEM01, 1, wInt1 - 1)
                wStr2 = Mid(PROD_ITEM01, wInt1 + 1)
            Else
                'ハイフンが無ければ、文字数で切り出す
                wStr1 = Strings.Left(PROD_ITEM01, 4)
                wStr2 = Strings.Right(PROD_ITEM01, 3)
            End If

            ''項目１の値でStdMainteを検索
            wRows = stm.SelectData(con, wStr1, wStr2)

            For Each row As DataRow In wRows
                '存在すればTRUE
                IsStdMainte = True
            Next

        Catch ex As Exception
            MsgBox("StdMainteからの読み込みに失敗しました。 [" & PROD_ITEM01 & "]")
            Throw ex
        End Try
    End Function

    ''' <summary>
    ''' 概 要：WCat取得
    ''' 説 明：
    ''' </summary>
    ''' <param name="PROD_ITEM01">項目０１値</param>
    ''' <param name="Months">取得した月数</param>
    ''' <remarks></remarks>
    Private Function GetWCat(ByVal PROD_ITEM01 As String, ByRef Months As Integer) As Boolean

        Dim con As OleDbConnection
        Dim mmc As New MasterMdbControl
        Dim wcat As New OleDbWcat
        Dim wRows As DataRow()

        Dim wStr1 As String
        Dim wStr2 As String
        Dim wInt1 As Integer

        con = mmc.GetOleDBConnection(CommonVariable.MdbPW)

        Try
            GetWCat = False
            Months = 0

            '項目１の値を、ハイフンで前後に切り分ける
            wInt1 = InStr(1, PROD_ITEM01, "-")
            If wInt1 > 0 Then
                wStr1 = Mid(PROD_ITEM01, 1, wInt1 - 1)
                wStr2 = Mid(PROD_ITEM01, wInt1 + 1)
            Else
                'ハイフンが無ければ、文字数で切り出す
                wStr1 = Strings.Left(PROD_ITEM01, 4)
                wStr2 = Strings.Right(PROD_ITEM01, 3)
            End If

            '項目１の値でWCatを検索
            wRows = wcat.SelectData(con, wStr1, wStr2)

            'レコードがあれば、年数を取得する
            For Each row As DataRow In wRows
                If Not IsDBNull(row.Item("Wcat")) Then
                    GetWCat = True
                    Months = Val(row.Item("Wcat"))
                    Exit For
                End If
            Next

        Catch ex As Exception
            MsgBox("WCatからの読み込みに失敗しました。 [" & PROD_ITEM01 & "]")
            Throw ex
        End Try
    End Function

    ''' <summary>
    ''' 概 要：ServicePac_ALLからSP_Yearを取得
    ''' 説 明：
    ''' </summary>
    ''' <param name="PROD_ITEM01">項目０１値</param>
    ''' <remarks></remarks>
    Private Function GetSPYear(ByVal PROD_ITEM01 As String) As String
        Dim filter As New StringBuilder

        Try
            GetSPYear = ""

            ''ServicePac_ALLテーブルを検索
            filter.Append(ServicePac_ALLTable.COLUMN_NAME_PRODUCTID)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(PROD_ITEM01))

            For Each row As DataRow In SpaTBL.Select(filter.ToString)
                If Not IsDBNull(row.Item("SP_Year")) Then
                    GetSPYear = row.Item("SP_Year")
                    Exit For
                End If
            Next

        Catch ex As Exception
            MsgBox("M_ServicePac_ALLからの読み込みに失敗しました。 [" & PROD_ITEM01 & "]")
            Throw ex
        End Try
    End Function

    ''' <summary>
    ''' 概 要：PaMedia判定
    ''' 説 明：
    ''' </summary>
    ''' <param name="PROD_ITEM01">項目０１値</param>
    ''' <remarks></remarks>
    Private Function IsPaMedia(ByVal PROD_ITEM01 As String) As Boolean

        Dim con As OleDbConnection
        Dim mmc As New MasterMdbControl
        Dim mpm As New OleDbM_PA_MEDIA
        Dim wDTable As DataTable
        Dim wStr As String

        con = mmc.GetOleDBConnection(CommonVariable.MdbPW)

        Try
            IsPaMedia = False

            ''項目１の値でM_Pa_Mediaを検索
            ''※DB内でPARTNO後方にブランクが付いているため、キー指定での検索不可　→　全件検索してテーブルサーチ

            wStr = PROD_ITEM01 & Space(15 - Len(PROD_ITEM01))
            wDTable = mpm.SelectDataTable(con, wStr)

            For Each row As DataRow In wDTable.Rows
                '条件一致の時、TRUE
                'If Not IsDBNull(row.Item("PARTNO")) Then
                If (Not IsDBNull(row.Item("PARTNO"))) And _
                   (Not IsDBNull(row.Item("PROD_TYPE_CD"))) And _
                   (Not IsDBNull(row.Item("LICENSE_MASK_CD"))) Then
                    If Trim(row.Item("PARTNO")) = PROD_ITEM01 And _
                       row.Item("PROD_TYPE_CD") = "01" And _
                       row.Item("LICENSE_MASK_CD") = "4" Then
                        IsPaMedia = True
                        Exit Function
                    End If
                End If
            Next

        Catch ex As Exception
            MsgBox("M_PA_Mediaからの読み込みに失敗しました。 [" & PROD_ITEM01 & "]")
            Throw ex
        End Try

    End Function

    ''' <summary>
    ''' 概 要：次のAnniversaryDate取得
    ''' 説 明：
    ''' </summary>
    ''' <param name="SeikyuDate">請求開始日</param>
    ''' <param name="Aniv">AnniversaryDate</param>
    ''' <remarks></remarks>
    Private Function GetNextAnivDate(ByVal SeikyuDate As String, _
                                     ByVal Aniv As String) As String

        '請求期間　開始年月の月部分　<  アニバーサリーDate ならば、同年のアニバーサリーDateの1日
        '請求期間　開始年月の月部分　>= アニバーサリーDate ならば、翌年のアニバーサリーDateの1日
        Dim wMM As String

        GetNextAnivDate = ""

        If Not IsDate(SeikyuDate) Then
            Exit Function
        End If

        wMM = CDate(SeikyuDate).ToString("MM")

        If Val(wMM) < Val(Aniv) Then
            GetNextAnivDate = CDate(CDate(SeikyuDate).ToString("yyyy") & "/" & Aniv & "/01").ToString("yyyy/MM/dd")
        Else
            GetNextAnivDate = CDate(CDate(SeikyuDate).AddYears(1).ToString("yyyy") & "/" & Aniv & "/01").ToString("yyyy/MM/dd")
        End If

    End Function

    ''' <summary>
    ''' 概 要：Payment詳細TBLの取得SQL
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_PaymentDetailTable() As String

        ''戻り値
        Dim rtnValue As New StringBuilder

        ''Select句
        rtnValue.Append(CommonConstant.SQL_STR_SELECT)
        rtnValue.Append(CommonConstant.SQL_STR_ASTERISK)
        ''From句
        rtnValue.Append(CommonConstant.SQL_STR_FROM)
        rtnValue.Append(" PaymentDetailTBL ")
        ''Order By句
        rtnValue.Append(CommonConstant.SQL_STR_ORDER_BY)
        rtnValue.Append(" DETAIL_ID ")

        Return rtnValue.ToString

    End Function

    'Req.1612 別紙B自動作成 2017/12 Str
    ''' <summary>
    ''' Codeテーブル取得
    ''' </summary>
    ''' <param name="CPNO">CPNO</param>
    ''' <remarks></remarks>
    Private Function GetCode(ByVal CPNO As String) As Boolean
        Dim mdc As New MasterMdbControl
        Dim dbCon As OleDbConnection
        Dim odc As New OleDbCode
        Dim dbTable As DataTable
        Dim ii As Integer
        'Req.1612 別紙B自動作成 2018/03 Str
        Dim wc As New WebDb.WebDbCommon
        Dim dt As New M_CONTRACT_BASETable
        Dim wRet As Boolean
        Dim wMsg As String
        'Req.1612 別紙B自動作成 2018/03 End

        GetCode = False

        Try
            'Req.1612 別紙B自動作成 2018/03 Str
            '認証設定
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW

            wRet = wc.GetContractBaseData(CommonVariable.CPNO, dt, wMsg)
            If wRet = False Then
                Throw New Exception(wMsg)
                Exit Function
            End If

            If dt.Rows.Count > 0 Then
                If Mid(dt.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_CONTRACT_PATERN).ToString, 1, 1) = "1" Then
                    GetCode = True
                End If
            End If

            ''認証設定
            'dbCon = mdc.GetOleDBConnection(CommonVariable.MdbPW)

            ''CODEテーブル取得
            'dbTable = odc.SelectDataTable(dbCon, "PRCPNO")

            ''取得内容チェック
            'If dbTable.Rows.Count > 0 Then
            '    For ii = 0 To dbTable.Rows.Count - 1
            '        If dbTable.Rows(ii).Item("ItemValue") = CPNO Then
            '            '当該CPNOの登録あり
            '            GetCode = True
            '            Exit Function
            '        End If
            '    Next
            'End If
            'Req.1612 別紙B自動作成 2018/03 End

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "GetCode")

        Finally
            'Req.1612 別紙B自動作成 2018/03 Str
            'dbCon.Close()
            'Req.1612 別紙B自動作成 2018/03 End

        End Try

    End Function
    'Req.1612 別紙B自動作成 2017/12 End

    'Req.1690 シリアル重複チェックリスト変更 2018/12 Str
    ''' <summary>
    ''' 機能：サービス名称作成(シリアル重複チェック用)
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub MakeSvcName()

        Dim strSQL As String
        Dim rsTbl1 As New ADODB.Recordset
        Dim con As New ADODB.Connection
        Dim mmc As New MasterMdbControl

        Try
            '接続の作成
            con = mmc.GetAdoTmpDBConnection(CommonVariable.CPNO, CommonVariable.MdbPW)

            strSQL = "SELECT * FROM SerialCheckPaymentTBL1 "

            rsTbl1.Open(strSQL, con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)

            Do Until rsTbl1.EOF = True
                'サービス種類
                Select Case rsTbl1.Fields("PATTERN_CD").Value
                    Case "15", "16", "17"
                        rsTbl1.Fields("SERVICE_NAME").Value = "HWMA"
                    Case "20"
                        rsTbl1.Fields("SERVICE_NAME").Value = "MVMS"
                    Case "21"
                        rsTbl1.Fields("SERVICE_NAME").Value = "CISCO保守"
                    Case "34"
                        rsTbl1.Fields("SERVICE_NAME").Value = "システムサービス"
                    Case "43"
                        rsTbl1.Fields("SERVICE_NAME").Value = "ベーシックセレクション(M09)"
                    Case "44"
                        rsTbl1.Fields("SERVICE_NAME").Value = "ベーシックセレクション(" & Mid(rsTbl1.Fields("PROD_ITEM04").Value, 2, 3) & ")"
                End Select

                rsTbl1.Update()

                rsTbl1.MoveNext()
            Loop

            Call rsTbl1.Close()

        Catch ex As Exception
            Throw ex

        Finally
            If con.State <> ADODB.ObjectStateEnum.adStateClosed Then
                con.Close()
            End If
        End Try

    End Sub
    'Req.1690 シリアル重複チェックリスト変更 2018/12 End


#End Region

    Private Sub lbl_Contract_Click(sender As System.Object, e As System.EventArgs) Handles lbl_Contract.Click

    End Sub
End Class