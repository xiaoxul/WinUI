﻿Imports System.IO
Imports System.Net
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.XmlClass.SheetFoumulate
Imports MUSE.Utility.OioBamaCommmon

Public Class ImportCsv
#Region "定数"
    Public Const CD_IMPORT_CSV As Integer = 0
    Public Const CD_IMPORT_MDB As Integer = 1
    Public Const CD_IMPORT_CSVMDB As Integer = 2
#End Region

#Region "構造体"
    ''サーバーCsvパス
    Public Structure ServerCsvPath
        Dim PSCsv As String
        Dim PSValCsv As String
        Dim PSRefCsv As String

        Dim DetailCsv As String
        Dim DetailValCsv As String
        Dim DetailRefCsv As String
        Dim PSUpdTime As String
    End Structure
    ''Import件数
    Public Structure ImportCount
        Dim MDBCount As Integer
        Dim MDBDetailCount As Integer
        Dim CreatingMdbCount As Integer
        Dim CreatingMdbDetailCount As Integer
        Dim PSCount As Integer
        Dim PSValidationlogCount As Integer
        Dim PSReferenceCount As Integer
        Dim DetailCount As Integer
        Dim DetailValidationlogCount As Integer
        Dim DetailReferenceCount As Integer
    End Structure

    ''Import失敗件数
    Public Structure ImportErrCount
        Dim MDBCount As Integer
        Dim MDBDetailCount As Integer
        Dim CreatingMdbCount As Integer
        Dim CreatingMdbDetailCount As Integer
        Dim PSCount As Integer
        Dim PSValidationlogCount As Integer
        Dim PSReferenceCount As Integer
        Dim DetailCount As Integer
        Dim DetailValidationlogCount As Integer
        Dim DetailReferenceCount As Integer
    End Structure

    ''ﾌｫﾙﾀﾞとﾌｧｲﾙのパス
    Public Structure usedFilePath
        Dim MDBPath As String
        Dim PaymentPath As String
        Dim PaymentName As String
        Dim PaymentValidationlogPath As String
        Dim PaymentValidationlogName As String
        Dim PaymentReferencePath As String
        Dim PaymentReferenceName As String
        Dim PaymentDetailPath As String
        Dim PaymentDetailName As String
        Dim PaymentDetailValidationlogPath As String
        Dim PaymentDetailValidationlogName As String
        Dim PaymentDetailReferencePath As String
        Dim PaymentDetailReferenceName As String
    End Structure

#End Region

#Region "Public"
    ''' <summary>
    ''' 機能：ｻｰﾊﾞｰCSVﾃﾞｰﾀ取得MDB変換（単一CPNOのみ）
    ''' </summary>
    ''' <param name="intImportCd"></param>
    ''' <param name="strContractNo"></param>
    ''' <param name="strLockFlag"></param>
    ''' <param name="strExcelYear"></param>
    ''' <param name="strDownloadCsvPath"></param>
    ''' <param name="intPaymnetPeriod"></param>
    ''' <param name="filePath"></param>
    ''' <param name="importCount"></param>
    ''' <param name="importErrCount"></param>
    ''' <param name="strErrMsg"></param>
    ''' <param name="OUTERR"></param>
    ''' <param name="blnFrmWaitShow"></param>
    ''' <param name="blnCreatingMdb">作成中MDBﾌﾗｸﾞ　True：作成する、False：作成しない</param>
    ''' <param name="frmWait"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function SetServerCsvToTemMdb(ByVal intImportCd As Integer,
                                         ByVal strContractNo As String,
                                         ByVal strLockFlag As String,
                                         ByVal strExcelYear As String,
                                         ByVal strDownloadCsvPath As String,
                                         ByVal intPaymnetPeriod As Integer,
                                         ByRef filePath As ImportCsv.ServerCsvPath,
                                         ByRef importCount As ImportCount,
                                         ByRef importErrCount As ImportErrCount,
                                         ByRef strErrMsg As String,
                                         ByRef OUTERR As OutputErrorList,
                                         ByVal blnFrmWaitShow As Boolean,
                                         ByVal blnCreatingMdb As Boolean,
                                         Optional ByRef frmWait As Frm_WaitDialog = Nothing) As Boolean

        Dim blnRet As Boolean
        Dim alPsCreating As New ArrayList
        Dim alPsCreated As New ArrayList
        Dim alPsdCreating As New ArrayList
        Dim alPsdCreated As New ArrayList
        Dim alPsCreatingMdb As New ArrayList
        Dim alPsdCreatingMdb As New ArrayList

        SetServerCsvToTemMdb = False

        Try
            '==========================================
            'CSVダウンロード
            '==========================================
            If blnFrmWaitShow = True Then
                frmWait.ProgressValue = 2
                frmWait.lbl_Message.Text = FileReader.GetMessage("MSG_0461")
                frmWait.Refresh()
            End If
            OUTERR.OutImportErrorList(FileReader.GetMessage("MSG_0430"), "Import")

            ''Csv取得
            blnRet = GetServerCsv(True, strContractNo, strLockFlag, strDownloadCsvPath, filePath, strErrMsg)
            If blnRet = False Then
                OUTERR.OutImportErrorList(strErrMsg & "(ImportCsv.SetServerCsvToTemMdb)", "Import")
                Exit Function
            End If

            OUTERR.OutImportErrorList(FileReader.GetMessage("MSG_0431"), "Import")

            '==========================================
            'データを配列に保存（Refresh、Validation以外）
            '==========================================
            If blnFrmWaitShow = True Then
                frmWait.ProgressValue = 3
                frmWait.lbl_Message.Text = FileReader.GetMessage("MSG_0462")
                frmWait.Refresh()
            End If
            OUTERR.OutImportErrorList(FileReader.GetMessage("MSG_0463"), "Import")
            blnRet = GetCsvData(intImportCd,
                                filePath,
                                intPaymnetPeriod,
                                alPsCreating,
                                alPsCreatingMdb,
                                alPsCreated,
                                alPsdCreating,
                                alPsdCreatingMdb,
                                alPsdCreated,
                                importCount,
                                importErrCount,
                                OUTERR,
                                blnFrmWaitShow,
                                frmWait)
            If blnRet = False Then
                Exit Function
            End If
            OUTERR.OutImportErrorList(FileReader.GetMessage("MSG_0464"), "Import")

            '==========================================
            'MDB保存
            '==========================================
            If blnFrmWaitShow = True Then
                frmWait.ProgressValue = 4
                frmWait.lbl_Message.Text = FileReader.GetMessage("MSG_0335")
                frmWait.Refresh()
            End If
            blnRet = ImportDb(alPsCreated,
                              alPsdCreated,
                              strExcelYear,
                              importCount,
                              OUTERR,
                              blnFrmWaitShow,
                              blnCreatingMdb,
                              frmWait)
            If blnRet = False Then
                strErrMsg = FileReader.GetMessage("MSG_0338")
                OUTERR.OutImportErrorList(strErrMsg & "(ImportCsv.SetServerCsvToTemMdb)", "Import")
                Exit Function
            End If

            '価格承認済MDB保存
            blnRet = ImportDb(alPsCreatingMdb,
                              alPsdCreatingMdb,
                              strExcelYear,
                              importCount,
                              OUTERR,
                              blnFrmWaitShow,
                              True,
                              frmWait)
            If blnRet = False Then
                OUTERR.OutImportErrorList(FileReader.GetMessage("MSG_0338") & "(ImportCsv.SetServerCsvToTemMdb)", "Import")
                Exit Function
            End If

            SetServerCsvToTemMdb = True

        Catch ex As Exception
            strErrMsg = ex.Message.ToString & "(ImportCsv.SetServerCsvToTemMdb)"
        End Try

    End Function

    ''' <summary>
    ''' 機能：データを配列に保存（Refresh、Validation以外）
    ''' </summary>
    ''' <param name="intImportCd"></param>
    ''' <param name="filePath"></param>
    ''' <param name="intPaymentPeriod"></param>
    ''' <param name="alPsCreating"></param>
    ''' <param name="alPsCreated"></param>
    ''' <param name="alPsdCreating"></param>
    ''' <param name="alPsdCreated"></param>
    ''' <param name="importCount"></param>
    ''' <param name="importErrCount"></param>
    ''' <param name="OUTERR"></param>
    ''' <param name="blnFrmWaitShow"></param>
    ''' <param name="frmWait"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetCsvData(ByVal intImportCd As Integer,
                               ByVal filePath As ServerCsvPath,
                               ByVal intPaymentPeriod As Integer,
                               ByRef alPsCreating As ArrayList,
                               ByVal alPsCreatingMdb As ArrayList,
                               ByRef alPsCreated As ArrayList,
                               ByRef alPsdCreating As ArrayList,
                               ByRef alPsdCreatingMdb As ArrayList,
                               ByRef alPsdCreated As ArrayList,
                               ByRef importCount As ImportCount,
                               ByRef importErrCount As ImportErrCount,
                               ByRef OUTERR As OutputErrorList,
                               ByVal blnFrmWaitShow As Boolean,
                               Optional ByRef frmWait As Frm_WaitDialog = Nothing) As Boolean

        Dim oe As New OutputExcel

        GetCsvData = False

        Try
            '==========================================
            'Payment
            '==========================================
            'ダイアログ表示＆ログ出力
            If blnFrmWaitShow = True Then
                frmWait.lbl_Message.Text = FileReader.GetMessage("MSG_0307")
                frmWait.Refresh()
            End If
            OUTERR.OutImportErrorList(FileReader.GetMessage("MSG_0289"), "Import")

            'PaymentCSVﾃﾞｰﾀを配列に格納
            importCount.PSCount = oe.GetPsCsvData(intImportCd,
                                                  filePath.PSCsv,
                                                  intPaymentPeriod,
                                                  alPsCreating,
                                                  alPsCreatingMdb,
                                                  alPsCreated,
                                                  importErrCount.PSCount,
                                                  OUTERR)

            '異常終了　
            If importCount.PSCount = -1 Then
                OUTERR.OutImportErrorList(FileReader.GetMessage("MSG_0313"), "Import")
                Exit Function
            End If

            'ログ出力
            OUTERR.OutImportErrorList(FileReader.GetMessage("MSG_0290"), "Import")

            '==========================================
            '詳細
            '==========================================
            'ログ：個別詳細Csvファイルの処理を開始します。
            If blnFrmWaitShow = True Then
                frmWait.lbl_Message.Text = FileReader.GetMessage("MSG_0310")
                frmWait.Refresh()
            End If
            OUTERR.OutImportErrorList(FileReader.GetMessage("MSG_0295"), "Import")

            '詳細CSV取得
            importCount.DetailCount = oe.GetPsdCsvData(intImportCd,
                                                       filePath.DetailCsv,
                                                       CommonVariable.CPNO,
                                                       alPsdCreating,
                                                       alPsdCreatingMdb,
                                                       alPsdCreated,
                                                       importErrCount.DetailCount,
                                                       OUTERR)

            '異常終了
            If importCount.DetailCount = -1 Then
                OUTERR.OutImportErrorList(FileReader.GetMessage("MSG_0315"), "Import")
                Exit Function
            End If

            'ログ出力
            OUTERR.OutImportErrorList(FileReader.GetMessage("MSG_0296"), "Import")

            GetCsvData = True

        Catch ex As Exception
            OUTERR.OutImportErrorList(ex.Message.ToString & "(GetCsvData.Exception)", "Import")
            Throw ex
        End Try

    End Function

    ''' <summary>
    ''' 機能：CSVダウンロード
    ''' </summary>
    ''' <param name="isImportMDB"></param>
    ''' <param name="strContractNo"></param>
    ''' <param name="strLockFlag"></param>
    ''' <param name="strDownloadCsvPath"></param>
    ''' <param name="rtnCsvPath"></param>
    ''' <param name="errMsg"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetServerCsv(ByVal isImportMDB As Boolean,
                                 ByVal strContractNo As String,
                                 ByVal strLockFlag As String,
                                 ByVal strDownloadCsvPath As String,
                                 ByRef rtnCsvPath As ServerCsvPath,
                                 ByRef errMsg As String) As Boolean

        Dim sc As New ServerCsv
        Dim intRet As Integer
        Dim strMsg As String
        Dim strObamaUrl As String
        Dim cc As CookieContainer = New CookieContainer()       'クッキー設定
        Dim strCsvPsFileName(0 To 5) As String
        Dim strFullFileName As String
        Dim strUpdateTime As String
        Dim ofm As New OioFileManage
        Dim oe As New OutputExcel
        Dim blnRet As Boolean

        GetServerCsv = False

        Try
            '==============================================
            'サーバーログイン
            '==============================================
            intRet = sc.LoginServer(OutputExcel.CD_PROC_NEW, cc, strObamaUrl, strMsg)
            If intRet <> ServerCsv.RET_OK Then
                If intRet = ServerCsv.RET_SYS_ERROR Then
                    errMsg = FileReader.GetMessage("MSG_0402")
                    Exit Function
                End If
            End If

            '==============================================
            'サーバーからCSVファイルを取得
            '==============================================
            With sc
                .GetPsCsvFlg = True
                .GetPsRefCsvFlg = Not isImportMDB
                .GetPsValCsvFlg = Not isImportMDB
                .GetDetailCsvFlg = True
                .GetDetailRefCsvFlg = Not isImportMDB
                .GetDetailValCsvFlg = Not isImportMDB
            End With
            intRet = sc.GetServerCsvs(CommonVariable.CPNO, strContractNo, strLockFlag, strObamaUrl, cc, strDownloadCsvPath, strCsvPsFileName, strMsg)
            If intRet = ServerCsv.RET_SYS_ERROR Then
                errMsg = FileReader.GetMessage("MSG_0402")
                Exit Function
            End If

            '==============================================
            'パスの取得
            '==============================================
            'Payment Line（統合）
            If IsNothing(strCsvPsFileName(0)) = False Then
                strFullFileName = strDownloadCsvPath & strCsvPsFileName(0)
                strUpdateTime = File.GetLastWriteTime(strFullFileName).ToString("yyyy/MM/dd HH:mm:ss")
            Else
                strFullFileName = ""
                strUpdateTime = ""
            End If
            rtnCsvPath.PSCsv = strFullFileName
            rtnCsvPath.PSUpdTime = strUpdateTime

            If isImportMDB = False Then
                'Payment Line インポートValidation Log
                If IsNothing(strCsvPsFileName(1)) = False Then
                    strFullFileName = strDownloadCsvPath & strCsvPsFileName(1)
                    strUpdateTime = File.GetLastWriteTime(strFullFileName).ToString("yyyy/MM/dd HH:mm:ss")
                Else
                    strFullFileName = ""
                    strUpdateTime = ""
                End If
                rtnCsvPath.PSValCsv = strFullFileName

                'Payment Line リフレッシュValidation Log
                If IsNothing(strCsvPsFileName(2)) = False Then
                    strFullFileName = strDownloadCsvPath & strCsvPsFileName(2)
                    strUpdateTime = File.GetLastWriteTime(strFullFileName).ToString("yyyy/MM/dd HH:mm:ss")
                Else
                    strFullFileName = ""
                    strUpdateTime = ""
                End If
                rtnCsvPath.PSRefCsv = strFullFileName
            End If

            '個別詳細（統合）
            If IsNothing(strCsvPsFileName(3)) = False Then
                strFullFileName = strDownloadCsvPath & strCsvPsFileName(3)
                strUpdateTime = File.GetLastWriteTime(strFullFileName).ToString("yyyy/MM/dd HH:mm:ss")
            Else
                strFullFileName = ""
                strUpdateTime = ""
            End If
            rtnCsvPath.DetailCsv = strFullFileName

            If isImportMDB = False Then
                '個別詳細 インポートValidation Log
                If IsNothing(strCsvPsFileName(4)) = False Then
                    strFullFileName = strDownloadCsvPath & strCsvPsFileName(4)
                    strUpdateTime = File.GetLastWriteTime(strFullFileName).ToString("yyyy/MM/dd HH:mm:ss")
                Else
                    strFullFileName = ""
                    strUpdateTime = ""
                End If
                rtnCsvPath.DetailValCsv = strFullFileName

                '個別詳細 リフレッシュValidation Log
                If IsNothing(strCsvPsFileName(5)) = False Then
                    strFullFileName = strDownloadCsvPath & strCsvPsFileName(5)
                    strUpdateTime = File.GetLastWriteTime(strFullFileName).ToString("yyyy/MM/dd HH:mm:ss")
                Else
                    strFullFileName = ""
                    strUpdateTime = ""
                End If
                rtnCsvPath.DetailRefCsv = strFullFileName
            End If

            If intRet = ServerCsv.RET_NO_FILE Then
                errMsg = strMsg
                Exit Function
            End If

            '==============================================
            'ファイル名チェック
            '==============================================
            blnRet = ChkCsvContract(isImportMDB, rtnCsvPath, errMsg)
            If blnRet = False Then
                Exit Function
            End If

            ''戻り値
            GetServerCsv = True

        Catch ex As Exception
            errMsg = ex.Message.ToString

        End Try

    End Function

    ''' <summary>
    ''' 機能：MDB保存
    ''' </summary>
    ''' <param name="alPsCreated"></param>
    ''' <param name="alPsdCreated"></param>
    ''' <param name="strExcelYear"></param>
    ''' <param name="importCount"></param>
    ''' <param name="OUTERR"></param>
    ''' <param name="blnFrmWaitShow"></param>
    ''' <param name="blnCreatingMdb">作成中MDBﾌﾗｸﾞ　True：作成する、False：作成しない</param>
    ''' <param name="frmWait"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function ImportDb(ByVal alPsCreated As ArrayList,
                             ByVal alPsdCreated As ArrayList,
                             ByVal strExcelYear As String,
                             ByRef importCount As ImportCount,
                             ByRef OUTERR As OutputErrorList,
                             ByVal blnFrmWaitShow As Boolean,
                             ByVal blnCreatingMdb As Boolean,
                             Optional ByRef frmWait As Frm_WaitDialog = Nothing) As Boolean

        Dim ct As New CreateTempDb
        Dim strMdbPath As String
        Dim intCount As Integer
        Dim strMsgStart As String
        Dim strMsgEnd As String
        Dim strMSgErr As String
        Dim strMsgForm As String

        ImportDb = False

        Try
            '==========================================
            'Payment
            '==========================================
            '処理区分によるメッセージ設定
            If blnCreatingMdb = False Then
                strMsgForm = FileReader.GetMessage("MSG_0335")
                strMsgStart = FileReader.GetMessage("MSG_0336")
                strMsgEnd = FileReader.GetMessage("MSG_0337")
                strMSgErr = FileReader.GetMessage("MSG_0338")
            Else
                strMsgForm = FileReader.GetMessage("MSG_0504")
                strMsgStart = FileReader.GetMessage("MSG_0505")
                strMsgEnd = FileReader.GetMessage("MSG_0506")
                strMSgErr = FileReader.GetMessage("MSG_0507")
            End If

            'ダイアログ表示＆ログ出力
            If blnFrmWaitShow = True Then
                frmWait.lbl_Message.Text = strMsgForm
                frmWait.Refresh()
            End If
            OUTERR.OutImportErrorList(strMsgStart, "Import")

            '締結済MDBの作成処理
            intCount = ct.CreateDataKeepMDB(strMdbPath,
                                            alPsCreated,
                                            strExcelYear,
                                            importCount.MDBCount,
                                            OUTERR,
                                            blnCreatingMdb)
            If blnCreatingMdb = False Then
                importCount.MDBCount = intCount
            Else
                importCount.CreatingMdbCount = intCount
            End If
            '異常終了　
            If intCount = -1 Then
                OUTERR.OutImportErrorList(strMSgErr, "Import")
                Exit Function
            End If

            'ログ出力
            OUTERR.OutImportErrorList(strMsgEnd, "Import")

            '==========================================
            '詳細
            '==========================================
            '処理区分によるメッセージ設定
            If blnCreatingMdb = False Then
                strMsgForm = FileReader.GetMessage("MSG_0387")
                strMsgStart = FileReader.GetMessage("MSG_0388")
                strMsgEnd = FileReader.GetMessage("MSG_0389")
                strMSgErr = FileReader.GetMessage("MSG_0390")
            Else
                strMsgForm = FileReader.GetMessage("MSG_0508")
                strMsgStart = FileReader.GetMessage("MSG_0509")
                strMsgEnd = FileReader.GetMessage("MSG_0510")
                strMSgErr = FileReader.GetMessage("MSG_0511")
            End If

            'ダイアログ表示＆ログ出力
            If blnFrmWaitShow = True Then
                frmWait.lbl_Message.Text = strMsgForm
                frmWait.Refresh()
            End If
            OUTERR.OutImportErrorList(strMsgStart, "Import")


            '詳細締結済MDBの作成処理
            intCount = ct.CreateDataKeepDetailMDB(strMdbPath, _
                                                  alPsdCreated, _
                                                  importCount.MDBDetailCount, _
                                                  OUTERR,
                                                  blnCreatingMdb)
            If blnCreatingMdb = False Then
                importCount.MDBDetailCount = intCount
            Else
                importCount.CreatingMdbDetailCount = intCount
            End If
            '異常終了
            If intCount = -1 Then
                OUTERR.OutImportErrorList(strMSgErr, "Import")
                Exit Function
            End If

            'ログ出力
            OUTERR.OutImportErrorList(strMsgEnd, "Import")

            ImportDb = True

        Catch ex As Exception
            OUTERR.OutImportErrorList(ex.Message.ToString & "(ImportDb.Exception)", "Import")
            Throw ex
        End Try

    End Function

#End Region

#Region "Private"

    ''' <summary>
    ''' 機能：ｻｰﾊﾞｰからDownLoadしたCsvﾌｧｲﾙのCPNO/契約順番が正しいかﾁｪｯｸ
    ''' </summary>
    ''' <param name="intImportCd"></param>
    ''' <param name="filePath"></param>
    ''' <param name="msg"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ChkCsvContract(ByVal intImportCd As Integer,
                                    ByVal filePath As ServerCsvPath, _
                                    ByRef msg As String) As Boolean

        Dim psCpno As String
        Dim psContract As String

        ChkCsvContract = False

        If System.IO.Path.GetFileName(filePath.PSCsv) = "PaymentLine" & CommonVariable.CPNO & "_export.csv" Then
            msg = FileReader.GetMessage("MSG_0470")
            Exit Function
        End If

        'CsvﾌｧｲﾙのCpno/契約順番が正しいか判定
        If intImportCd = CD_IMPORT_CSV Then
            'Csvﾌｧｲﾙ名から、CPNO/契約順番に分割
            psCpno = System.IO.Path.GetFileName(filePath.PSCsv).Substring(0, 6)
            psContract = System.IO.Path.GetFileName(filePath.PSCsv).Substring(7, 3)

            '古いファイル名に対応
            If IsNumeric(psContract) = False Then
                psCpno = System.IO.Path.GetFileName(filePath.PSCsv).Substring(11, 6)
                psContract = System.IO.Path.GetFileName(filePath.PSCsv).Substring(19, 3)
            End If

            If psCpno <> CommonVariable.CPNO Then
                ''不要になったCSVを削除
                If System.IO.File.Exists(filePath.PSCsv) Then
                    System.IO.File.Delete(filePath.PSCsv)
                End If
                If System.IO.File.Exists(filePath.PSValCsv) Then
                    System.IO.File.Delete(filePath.PSValCsv)
                End If
                If System.IO.File.Exists(filePath.PSRefCsv) Then
                    System.IO.File.Delete(filePath.PSRefCsv)
                End If
                If System.IO.File.Exists(filePath.DetailCsv) Then
                    System.IO.File.Delete(filePath.DetailCsv)
                End If
                If System.IO.File.Exists(filePath.DetailValCsv) Then
                    System.IO.File.Delete(filePath.DetailValCsv)
                End If
                If System.IO.File.Exists(filePath.DetailRefCsv) Then
                    System.IO.File.Delete(filePath.DetailRefCsv)
                End If
                msg = FileReader.GetMessage("MSG_0222")
                Exit Function
            End If
        End If

        ChkCsvContract = True

    End Function
#End Region

End Class
