﻿Imports System.Text
Imports System.IO
Imports System.Data.OleDb
Imports Microsoft.Office.Interop
Imports MUSE.Utility
Imports MUSE.Utility.OioBamaCommmon
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.UserMessageBox
Imports System.Data

Public Class ExcelAsrManage

#Region "定数"
    'PaymentLine データ開始行
    Private Const EXCEL_PAYMENTLINEDATE_OUTROW As Integer = ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW
    '実行管理ファイルExport データ開始行
    Private Const EXCEL_WORKMANAGEEXPORT_OUTROW As Integer = 8

    Private Const EXCEL_DELIVERYEXPORT_OUTROW As Integer = 11
    'DeliveryExport 雛型の行
    Private Const EXCEL_DELIVERYEXPORT_TEMPTROW As Integer = 6

    ''処理完了メッセージの区分
    Public Const MSG_OK As String = "OK"
    Public Const MSG_CRITICAL As String = "CRITICAL"
    Public Const MSG_UPDFLGERR As String = "UPDFLGERR"
    Public Const MSG_SHEETCHKERR As String = "SHEETCHKERR"

    Private Const EXCEL_PAYMNETSAMPLE_FILENAME As String = "PaymentLineSample.xlsm"
    Private Const SHEET_NAME_WS1 As String = ExcelWrite.EXCEL_PAYMENTLINEDATE_WS1
    Private Const SHEET_NAME_PS As String = ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET

    Private Const CD_ACT_NON_LETTERID As Integer = 0                '通知書番号無
    Private Const CD_ACT_REFERENCE_DATA As Integer = 1              '
    Private Const CD_ACT_MAKE As Integer = 0                        '作成
    Private Const CD_ACT_REFERENCE As Integer = 1                   '読込
    Private Const CD_ASR_ACT As Integer = 0                         '実行管理
    Private Const CD_ASR_DELIVERY As Integer = 1                    'デリバリ
    Public Const CD_ACT_OUTPUT1 As Integer = 0                      '①要回答未実行（過去－２ヶ月）
    Public Const CD_ACT_OUTPUT2 As Integer = 1                      '②任意回答未実行（3ヶ月以降）
    Public Const CD_ACT_OUTPUT3 As Integer = 2                      '③要確認EOS価格改定
    Public Const CD_ACT_OUTPUT4 As Integer = 3                      '④参考未発注（過去－２ヶ月）
    'Req.1702 実行支援シート追加 2018/12 Str
    Public Const CD_ACT_OUTPUT5 As Integer = 4                      '⑤要確認保守廃止
    'Req.1702 実行支援シート追加 2018/12 End
    Private Const STR_SHEET_NAME_ACT_1 As String = "①要回答未実行（過去－２ヶ月）"
    Private Const STR_SHEET_NAME_ACT_2 As String = "②任意回答未実行（3ヶ月以降）"
    Private Const STR_SHEET_NAME_ACT_3 As String = "③要確認EOS価格改定"
    Private Const STR_SHEET_NAME_ACT_4 As String = "④参考未発注（過去－２ヶ月）"
    'Req.1702 実行支援シート追加 2018/12 Str
    Private Const STR_SHEET_NAME_ACT_5 As String = "⑤要確認保守廃止"
    'Req.1702 実行支援シート追加 2018/12 End
    Private Const STR_SHEET_LIST As String = "リスト"
    Private Const RANGE_PAYMENT_START As String = "DH6"             'Payment開始年書込位置
    Private Const COL_ACT_PRICE_YEAR1_MONTH1 As Integer = 112
    Private Const COL_ACT_PRICE_YEAR20_MONTH12 As Integer = 351
    '項目10の値
    Private Const ProdItem10_Value_CopyNo As String = "ｺﾋﾟｰ元NO = "
    Private Const ProdItem10_Value_DelNo As String = "削除元NO = "
#End Region

#Region "変数"
    Public TEMP_DIR_PATH As String
    Public TEMP_DERI_FILE_NAME As String
    Public DERI_OUT_DIR As String
    Public ContractMDBPath As String
#End Region

#Region "列挙体"
    ''ｼﾘｱﾙシートの項目位置
    Private Enum SerialSheetColumns
        UPDATE_FLAG = 1                     ''更新FLG
        LOCK_FLAG                           ''ﾛｯｸFLG
        VALID_FLAG                          ''有効/無効
        LINE_NO                             ''NO
        FILE_NAME                           ''ﾌｧｲﾙ名
        FILE_NAME_SUFFIX                    ''ﾌｧｲﾙ名Suffix
        FILE_NAME_SUFFIX_INTR               ''ﾌｧｲﾙ内Suffix
        CONTRACT                            ''契約順番
        PROJ_ID                             ''案件番号
        CONTRACT_SEQ                        ''契約通番
        NEW_EXIST                           ''新規/既存
        CUST_CATEGORY                       ''お客様集計ｶﾃｺﾞﾘ
        LETTER_ACCEPT_DATE                  ''実行通知書_受領日
        ORDER_DATE                          ''発注完了日
        LETTER_ID                           ''実行通知書番号
        LETTER_PLAN_DATE                    ''業務メモ情報
        ORDERCODE                           ''請求コード
        BU                                  ''Brand Category_BU
        BRAND                               ''Brand Category_Brand
        SUM_CATEGORY                        ''Brand Category_ｻﾏﾘｰ用ｶﾃｺﾞﾘ
        BRAND_SUB                           ''Brand Category_SubBrand
        OP1                                 ''Brand Category_Option1
        OP2                                 ''Brand Category_Option2
        BRAND_SIZE                          ''Brand Category_Size
        NON_SBO                             ''Brand Category_SBO制限
        POSTSCRIPT                          ''Brand Category_追記事項
        TOPACS_CPNO                         ''Brand承認_TOPACS CPNO
        BRAND_AP_FORM                       ''Brand承認_起票番号
        BRAND_AP_REQ                        ''Brand承認_申請番号
        BRAND_AP_CONF                       ''Brand承認_承認番号
        PATTERN_CD                          ''入力項目ﾊﾟﾀｰﾝ SEQ
        PATTERN                             ''入力項目ﾊﾟﾀｰﾝ
        PROD_ITEM01                         ''ﾊﾟﾀｰﾝ別入力項目_項目１
        PROD_ITEM02                         ''ﾊﾟﾀｰﾝ別入力項目_項目２
        PROD_TmpSerial                      ''仮ｼﾘｱﾙ
        PROD_Serial                         ''実ｼﾘｱﾙ
        PROD_ITEM04                         ''ﾊﾟﾀｰﾝ別入力項目_項目４
        PROD_ITEM05                         ''ﾊﾟﾀｰﾝ別入力項目_項目５
        PROD_ITEM06                         ''ﾊﾟﾀｰﾝ別入力項目_項目６
        PROD_ITEM07                         ''ﾊﾟﾀｰﾝ別入力項目_項目７
        PROD_ITEM08                         ''ﾊﾟﾀｰﾝ別入力項目_項目８
        PROD_ITEM09                         ''ﾊﾟﾀｰﾝ別入力項目_項目９
        PROD_ITEM10                         ''ﾊﾟﾀｰﾝ別入力項目_項目１０
        PROD_ITEM11                         ''ﾊﾟﾀｰﾝ別入力項目_項目１１
        PROD_ITEM12                         ''ﾊﾟﾀｰﾝ別入力項目_項目１２
        PROD_ITEM13                         ''ﾊﾟﾀｰﾝ別入力項目_項目１３
        PROD_ITEM14                         ''ﾊﾟﾀｰﾝ別入力項目_項目１４
        PROD_ITEM15                         ''ﾊﾟﾀｰﾝ別入力項目_項目１５
        PROD_ITEM16                         ''ﾊﾟﾀｰﾝ別入力項目_項目１６
        PROD_ITEM17                         ''ﾊﾟﾀｰﾝ別入力項目_項目１７
        PROD_ITEM18                         ''ﾊﾟﾀｰﾝ別入力項目_項目１８
        PROD_ITEM19                         ''ﾊﾟﾀｰﾝ別入力項目_項目１９
        PROD_ITEM20                         ''ﾊﾟﾀｰﾝ別入力項目_項目２０
        PROD_ITEM22                         ''ﾊﾟﾀｰﾝ別入力項目_項目２２
        PROD_ITEM23                         ''ﾊﾟﾀｰﾝ別入力項目_項目２３
        PROD_ITEM24                         ''ﾊﾟﾀｰﾝ別入力項目_項目２４
        WD_ANNT_DATE                        ''製品･ｻｰﾋﾞｽ廃止発表日
        WD_DATE                             ''製品･ｻｰﾋﾞｽ廃止予定
        PRICE_CHG_DATE                      ''価格改定予定日
        QTY                                 ''数量
        INST_DATE                           ''導入_年月
        PAY_START_DATE                      ''請求開始_年月
        PAY_END_DATE                        ''請求終了_年月
        IGF_START_DATE                      ''IGF計算開始_年月
        IGF_END_DATE                        ''IGF計算終了_年月
        PAY_FLAG                            ''変則Payment_FLG
        BID_FLAG                            ''定額BID_FLG
        PAY_MONTHS                          ''請求期間
        PAY_VALIDATION                      ''サーバー制御
        PAY_METHOD                          ''支払方法
        IGF_APPLIED                         ''IGF_対象
        IGF_CONT_NO                         ''IGF契約番号
        IGF_CONT_FORM                       ''IGF契約形態
        IGF_CONT_MANAGMENT                  ''IGF契約物件管理
        IGF_RATE_IOC                        ''IGF_IOC料率
        LIST_PRICE_PROPOSAL                 ''Listprice(単価)_提案時
        LIST_PRICE_REFLESH                  ''Listprice(単価)_ﾘﾌﾚｯｼｭ後
        LIST_PRICE_TOTAL_PROPOSAL           ''Listprice(合計)_提案時	
        LIST_PRICE_TOTAL_REFLESH            ''Listprice(合計)_ﾘﾌﾚｯｼｭ後	
        DP_IOC                              ''IOC D%
        PRICE_UNIT_IOC                      ''IOC単価
        PRICE_UNIT_IOC_VAL                  ''OfferingPrice_Validation後
        PRICE_QTY_IOC                       ''IOC合計
        PRICE_TO_SPLIT                      ''展開金額
        LIST_PRICE_TOTAL_IOC                ''Listprice_期間合計
        PRICE_TOTAL_IOC                     ''D%適用後_期間合計
        PRICE_TOTAL_IGF                     ''IGF適用後 期間合計
        CONTRACT_IN                         ''契約期間内
        CONTRACT_OUT                        ''契約期間外
        PRICE_DEFF_IGF                      ''IGF金利(差額)
        PRICE_YEAR1                         ''年度情報1
        PRICE_YEAR2                         ''年度情報2
        PRICE_YEAR3                         ''年度情報3
        PRICE_YEAR4                         ''年度情報4
        PRICE_YEAR5                         ''年度情報5
        PRICE_YEAR6                         ''年度情報6
        PRICE_YEAR7                         ''年度情報7
        PRICE_YEAR8                         ''年度情報8
        PRICE_YEAR9                         ''年度情報9
        PRICE_YEAR10                        ''年度情報10
        PRICE_YEAR11                        ''年度情報11
        PRICE_YEAR12                        ''年度情報12
        PRICE_YEAR13                        ''年度情報13
        PRICE_YEAR14                        ''年度情報14
        PRICE_YEAR15                        ''年度情報15
        PRICE_YEAR16                        ''年度情報16
        PRICE_YEAR17                        ''年度情報17
        PRICE_YEAR18                        ''年度情報18
        PRICE_YEAR19                        ''年度情報19
        PRICE_YEAR20                        ''年度情報20
        PAST_PRICE_TOTAL                    ''過去の契約金額合計
        PRICE_YEAR1_MONTH1                  ''年度1_月度情報1
        PRICE_YEAR1_MONTH2                  ''年度1_月度情報2
        PRICE_YEAR1_MONTH3                  ''年度1_月度情報3
        PRICE_YEAR1_MONTH4                  ''年度1_月度情報4
        PRICE_YEAR1_MONTH5                  ''年度1_月度情報5
        PRICE_YEAR1_MONTH6                  ''年度1_月度情報6
        PRICE_YEAR1_MONTH7                  ''年度1_月度情報7
        PRICE_YEAR1_MONTH8                  ''年度1_月度情報8
        PRICE_YEAR1_MONTH9                  ''年度1_月度情報9
        PRICE_YEAR1_MONTH10                 ''年度1_月度情報10
        PRICE_YEAR1_MONTH11                 ''年度1_月度情報11
        PRICE_YEAR1_MONTH12                 ''年度1_月度情報12
        PRICE_YEAR2_MONTH1                  ''年度2_月度情報1
        PRICE_YEAR2_MONTH2                  ''年度2_月度情報2
        PRICE_YEAR2_MONTH3                  ''年度2_月度情報3
        PRICE_YEAR2_MONTH4                  ''年度2_月度情報4
        PRICE_YEAR2_MONTH5                  ''年度2_月度情報5
        PRICE_YEAR2_MONTH6                  ''年度2_月度情報6
        PRICE_YEAR2_MONTH7                  ''年度2_月度情報7
        PRICE_YEAR2_MONTH8                  ''年度2_月度情報8
        PRICE_YEAR2_MONTH9                  ''年度2_月度情報9
        PRICE_YEAR2_MONTH10                 ''年度2_月度情報10
        PRICE_YEAR2_MONTH11                 ''年度2_月度情報11
        PRICE_YEAR2_MONTH12                 ''年度2_月度情報12
        PRICE_YEAR3_MONTH1                  ''年度3_月度情報1
        PRICE_YEAR3_MONTH2                  ''年度3_月度情報2
        PRICE_YEAR3_MONTH3                  ''年度3_月度情報3
        PRICE_YEAR3_MONTH4                  ''年度3_月度情報4
        PRICE_YEAR3_MONTH5                  ''年度3_月度情報5
        PRICE_YEAR3_MONTH6                  ''年度3_月度情報6
        PRICE_YEAR3_MONTH7                  ''年度3_月度情報7
        PRICE_YEAR3_MONTH8                  ''年度3_月度情報8
        PRICE_YEAR3_MONTH9                  ''年度3_月度情報9
        PRICE_YEAR3_MONTH10                 ''年度3_月度情報10
        PRICE_YEAR3_MONTH11                 ''年度3_月度情報11
        PRICE_YEAR3_MONTH12                 ''年度3_月度情報12
        PRICE_YEAR4_MONTH1                  ''年度4_月度情報1
        PRICE_YEAR4_MONTH2                  ''年度4_月度情報2
        PRICE_YEAR4_MONTH3                  ''年度4_月度情報3
        PRICE_YEAR4_MONTH4                  ''年度4_月度情報4
        PRICE_YEAR4_MONTH5                  ''年度4_月度情報5
        PRICE_YEAR4_MONTH6                  ''年度4_月度情報6
        PRICE_YEAR4_MONTH7                  ''年度4_月度情報7
        PRICE_YEAR4_MONTH8                  ''年度4_月度情報8
        PRICE_YEAR4_MONTH9                  ''年度4_月度情報9
        PRICE_YEAR4_MONTH10                 ''年度4_月度情報10
        PRICE_YEAR4_MONTH11                 ''年度4_月度情報11
        PRICE_YEAR4_MONTH12                 ''年度4_月度情報12
        PRICE_YEAR5_MONTH1                  ''年度5_月度情報1
        PRICE_YEAR5_MONTH2                  ''年度5_月度情報2
        PRICE_YEAR5_MONTH3                  ''年度5_月度情報3
        PRICE_YEAR5_MONTH4                  ''年度5_月度情報4
        PRICE_YEAR5_MONTH5                  ''年度5_月度情報5
        PRICE_YEAR5_MONTH6                  ''年度5_月度情報6
        PRICE_YEAR5_MONTH7                  ''年度5_月度情報7
        PRICE_YEAR5_MONTH8                  ''年度5_月度情報8
        PRICE_YEAR5_MONTH9                  ''年度5_月度情報9
        PRICE_YEAR5_MONTH10                 ''年度5_月度情報10
        PRICE_YEAR5_MONTH11                 ''年度5_月度情報11
        PRICE_YEAR5_MONTH12                 ''年度5_月度情報12
        PRICE_YEAR6_MONTH1                  ''年度6_月度情報1
        PRICE_YEAR6_MONTH2                  ''年度6_月度情報2
        PRICE_YEAR6_MONTH3                  ''年度6_月度情報3
        PRICE_YEAR6_MONTH4                  ''年度6_月度情報4
        PRICE_YEAR6_MONTH5                  ''年度6_月度情報5
        PRICE_YEAR6_MONTH6                  ''年度6_月度情報6
        PRICE_YEAR6_MONTH7                  ''年度6_月度情報7
        PRICE_YEAR6_MONTH8                  ''年度6_月度情報8
        PRICE_YEAR6_MONTH9                  ''年度6_月度情報9
        PRICE_YEAR6_MONTH10                 ''年度6_月度情報10
        PRICE_YEAR6_MONTH11                 ''年度6_月度情報11
        PRICE_YEAR6_MONTH12                 ''年度6_月度情報12
        PRICE_YEAR7_MONTH1                  ''年度7_月度情報1
        PRICE_YEAR7_MONTH2                  ''年度7_月度情報2
        PRICE_YEAR7_MONTH3                  ''年度7_月度情報3
        PRICE_YEAR7_MONTH4                  ''年度7_月度情報4
        PRICE_YEAR7_MONTH5                  ''年度7_月度情報5
        PRICE_YEAR7_MONTH6                  ''年度7_月度情報6
        PRICE_YEAR7_MONTH7                  ''年度7_月度情報7
        PRICE_YEAR7_MONTH8                  ''年度7_月度情報8
        PRICE_YEAR7_MONTH9                  ''年度7_月度情報9
        PRICE_YEAR7_MONTH10                 ''年度7_月度情報10
        PRICE_YEAR7_MONTH11                 ''年度7_月度情報11
        PRICE_YEAR7_MONTH12                 ''年度7_月度情報12
        PRICE_YEAR8_MONTH1                  ''年度8_月度情報1
        PRICE_YEAR8_MONTH2                  ''年度8_月度情報2
        PRICE_YEAR8_MONTH3                  ''年度8_月度情報3
        PRICE_YEAR8_MONTH4                  ''年度8_月度情報4
        PRICE_YEAR8_MONTH5                  ''年度8_月度情報5
        PRICE_YEAR8_MONTH6                  ''年度8_月度情報6
        PRICE_YEAR8_MONTH7                  ''年度8_月度情報7
        PRICE_YEAR8_MONTH8                  ''年度8_月度情報8
        PRICE_YEAR8_MONTH9                  ''年度8_月度情報9
        PRICE_YEAR8_MONTH10                 ''年度8_月度情報10
        PRICE_YEAR8_MONTH11                 ''年度8_月度情報11
        PRICE_YEAR8_MONTH12                 ''年度8_月度情報12
        PRICE_YEAR9_MONTH1                  ''年度9_月度情報1
        PRICE_YEAR9_MONTH2                  ''年度9_月度情報2
        PRICE_YEAR9_MONTH3                  ''年度9_月度情報3
        PRICE_YEAR9_MONTH4                  ''年度9_月度情報4
        PRICE_YEAR9_MONTH5                  ''年度9_月度情報5
        PRICE_YEAR9_MONTH6                  ''年度9_月度情報6
        PRICE_YEAR9_MONTH7                  ''年度9_月度情報7
        PRICE_YEAR9_MONTH8                  ''年度9_月度情報8
        PRICE_YEAR9_MONTH9                  ''年度9_月度情報9
        PRICE_YEAR9_MONTH10                 ''年度9_月度情報10
        PRICE_YEAR9_MONTH11                 ''年度9_月度情報11
        PRICE_YEAR9_MONTH12                 ''年度9_月度情報12
        PRICE_YEAR10_MONTH1                 ''年度10_月度情報1
        PRICE_YEAR10_MONTH2                 ''年度10_月度情報2
        PRICE_YEAR10_MONTH3                 ''年度10_月度情報3
        PRICE_YEAR10_MONTH4                 ''年度10_月度情報4
        PRICE_YEAR10_MONTH5                 ''年度10_月度情報5
        PRICE_YEAR10_MONTH6                 ''年度10_月度情報6
        PRICE_YEAR10_MONTH7                 ''年度10_月度情報7
        PRICE_YEAR10_MONTH8                 ''年度10_月度情報8
        PRICE_YEAR10_MONTH9                 ''年度10_月度情報9
        PRICE_YEAR10_MONTH10                ''年度10_月度情報10
        PRICE_YEAR10_MONTH11                ''年度10_月度情報11
        PRICE_YEAR10_MONTH12                ''年度10_月度情報12
        PRICE_YEAR11_MONTH1                 ''年度11_月度情報1
        PRICE_YEAR11_MONTH2                 ''年度11_月度情報2
        PRICE_YEAR11_MONTH3                 ''年度11_月度情報3
        PRICE_YEAR11_MONTH4                 ''年度11_月度情報4
        PRICE_YEAR11_MONTH5                 ''年度11_月度情報5
        PRICE_YEAR11_MONTH6                 ''年度11_月度情報6
        PRICE_YEAR11_MONTH7                 ''年度11_月度情報7
        PRICE_YEAR11_MONTH8                 ''年度11_月度情報8
        PRICE_YEAR11_MONTH9                 ''年度11_月度情報9
        PRICE_YEAR11_MONTH10                ''年度11_月度情報10
        PRICE_YEAR11_MONTH11                ''年度11_月度情報11
        PRICE_YEAR11_MONTH12                ''年度11_月度情報12
        PRICE_YEAR12_MONTH1                 ''年度12_月度情報1
        PRICE_YEAR12_MONTH2                 ''年度12_月度情報2
        PRICE_YEAR12_MONTH3                 ''年度12_月度情報3
        PRICE_YEAR12_MONTH4                 ''年度12_月度情報4
        PRICE_YEAR12_MONTH5                 ''年度12_月度情報5
        PRICE_YEAR12_MONTH6                 ''年度12_月度情報6
        PRICE_YEAR12_MONTH7                 ''年度12_月度情報7
        PRICE_YEAR12_MONTH8                 ''年度12_月度情報8
        PRICE_YEAR12_MONTH9                 ''年度12_月度情報9
        PRICE_YEAR12_MONTH10                ''年度12_月度情報10
        PRICE_YEAR12_MONTH11                ''年度12_月度情報11
        PRICE_YEAR12_MONTH12                ''年度12_月度情報12
        PRICE_YEAR13_MONTH1                 ''年度13_月度情報1
        PRICE_YEAR13_MONTH2                 ''年度13_月度情報2
        PRICE_YEAR13_MONTH3                 ''年度13_月度情報3
        PRICE_YEAR13_MONTH4                 ''年度13_月度情報4
        PRICE_YEAR13_MONTH5                 ''年度13_月度情報5
        PRICE_YEAR13_MONTH6                 ''年度13_月度情報6
        PRICE_YEAR13_MONTH7                 ''年度13_月度情報7
        PRICE_YEAR13_MONTH8                 ''年度13_月度情報8
        PRICE_YEAR13_MONTH9                 ''年度13_月度情報9
        PRICE_YEAR13_MONTH10                ''年度13_月度情報10
        PRICE_YEAR13_MONTH11                ''年度13_月度情報11
        PRICE_YEAR13_MONTH12                ''年度13_月度情報12
        PRICE_YEAR14_MONTH1                 ''年度14_月度情報1
        PRICE_YEAR14_MONTH2                 ''年度14_月度情報2
        PRICE_YEAR14_MONTH3                 ''年度14_月度情報3
        PRICE_YEAR14_MONTH4                 ''年度14_月度情報4
        PRICE_YEAR14_MONTH5                 ''年度14_月度情報5
        PRICE_YEAR14_MONTH6                 ''年度14_月度情報6
        PRICE_YEAR14_MONTH7                 ''年度14_月度情報7
        PRICE_YEAR14_MONTH8                 ''年度14_月度情報8
        PRICE_YEAR14_MONTH9                 ''年度14_月度情報9
        PRICE_YEAR14_MONTH10                ''年度14_月度情報10
        PRICE_YEAR14_MONTH11                ''年度14_月度情報11
        PRICE_YEAR14_MONTH12                ''年度14_月度情報12
        PRICE_YEAR15_MONTH1                 ''年度15_月度情報1
        PRICE_YEAR15_MONTH2                 ''年度15_月度情報2
        PRICE_YEAR15_MONTH3                 ''年度15_月度情報3
        PRICE_YEAR15_MONTH4                 ''年度15_月度情報4
        PRICE_YEAR15_MONTH5                 ''年度15_月度情報5
        PRICE_YEAR15_MONTH6                 ''年度15_月度情報6
        PRICE_YEAR15_MONTH7                 ''年度15_月度情報7
        PRICE_YEAR15_MONTH8                 ''年度15_月度情報8
        PRICE_YEAR15_MONTH9                 ''年度15_月度情報9
        PRICE_YEAR15_MONTH10                ''年度15_月度情報10
        PRICE_YEAR15_MONTH11                ''年度15_月度情報11
        PRICE_YEAR15_MONTH12                ''年度15_月度情報12
        PRICE_YEAR16_MONTH1                 ''年度16_月度情報1
        PRICE_YEAR16_MONTH2                 ''年度16_月度情報2
        PRICE_YEAR16_MONTH3                 ''年度16_月度情報3
        PRICE_YEAR16_MONTH4                 ''年度16_月度情報4
        PRICE_YEAR16_MONTH5                 ''年度16_月度情報5
        PRICE_YEAR16_MONTH6                 ''年度16_月度情報6
        PRICE_YEAR16_MONTH7                 ''年度16_月度情報7
        PRICE_YEAR16_MONTH8                 ''年度16_月度情報8
        PRICE_YEAR16_MONTH9                 ''年度16_月度情報9
        PRICE_YEAR16_MONTH10                ''年度16_月度情報10
        PRICE_YEAR16_MONTH11                ''年度16_月度情報11
        PRICE_YEAR16_MONTH12                ''年度16_月度情報12
        PRICE_YEAR17_MONTH1                 ''年度17_月度情報1
        PRICE_YEAR17_MONTH2                 ''年度17_月度情報2
        PRICE_YEAR17_MONTH3                 ''年度17_月度情報3
        PRICE_YEAR17_MONTH4                 ''年度17_月度情報4
        PRICE_YEAR17_MONTH5                 ''年度17_月度情報5
        PRICE_YEAR17_MONTH6                 ''年度17_月度情報6
        PRICE_YEAR17_MONTH7                 ''年度17_月度情報7
        PRICE_YEAR17_MONTH8                 ''年度17_月度情報8
        PRICE_YEAR17_MONTH9                 ''年度17_月度情報9
        PRICE_YEAR17_MONTH10                ''年度17_月度情報10
        PRICE_YEAR17_MONTH11                ''年度17_月度情報11
        PRICE_YEAR17_MONTH12                ''年度17_月度情報12
        PRICE_YEAR18_MONTH1                 ''年度18_月度情報1
        PRICE_YEAR18_MONTH2                 ''年度18_月度情報2
        PRICE_YEAR18_MONTH3                 ''年度18_月度情報3
        PRICE_YEAR18_MONTH4                 ''年度18_月度情報4
        PRICE_YEAR18_MONTH5                 ''年度18_月度情報5
        PRICE_YEAR18_MONTH6                 ''年度18_月度情報6
        PRICE_YEAR18_MONTH7                 ''年度18_月度情報7
        PRICE_YEAR18_MONTH8                 ''年度18_月度情報8
        PRICE_YEAR18_MONTH9                 ''年度18_月度情報9
        PRICE_YEAR18_MONTH10                ''年度18_月度情報10
        PRICE_YEAR18_MONTH11                ''年度18_月度情報11
        PRICE_YEAR18_MONTH12                ''年度18_月度情報12
        PRICE_YEAR19_MONTH1                 ''年度19_月度情報1
        PRICE_YEAR19_MONTH2                 ''年度19_月度情報2
        PRICE_YEAR19_MONTH3                 ''年度19_月度情報3
        PRICE_YEAR19_MONTH4                 ''年度19_月度情報4
        PRICE_YEAR19_MONTH5                 ''年度19_月度情報5
        PRICE_YEAR19_MONTH6                 ''年度19_月度情報6
        PRICE_YEAR19_MONTH7                 ''年度19_月度情報7
        PRICE_YEAR19_MONTH8                 ''年度19_月度情報8
        PRICE_YEAR19_MONTH9                 ''年度19_月度情報9
        PRICE_YEAR19_MONTH10                ''年度19_月度情報10
        PRICE_YEAR19_MONTH11                ''年度19_月度情報11
        PRICE_YEAR19_MONTH12                ''年度19_月度情報12
        PRICE_YEAR20_MONTH1                 ''年度20_月度情報1
        PRICE_YEAR20_MONTH2                 ''年度20_月度情報2
        PRICE_YEAR20_MONTH3                 ''年度20_月度情報3
        PRICE_YEAR20_MONTH4                 ''年度20_月度情報4
        PRICE_YEAR20_MONTH5                 ''年度20_月度情報5
        PRICE_YEAR20_MONTH6                 ''年度20_月度情報6
        PRICE_YEAR20_MONTH7                 ''年度20_月度情報7
        PRICE_YEAR20_MONTH8                 ''年度20_月度情報8
        PRICE_YEAR20_MONTH9                 ''年度20_月度情報9
        PRICE_YEAR20_MONTH10                ''年度20_月度情報10
        PRICE_YEAR20_MONTH11                ''年度20_月度情報11
        PRICE_YEAR20_MONTH12                ''年度20_月度情報12
    End Enum

    ''Paymentシートの項目位置
    Private Enum PaymentSheetColumns
        ACT_CONTROL = 1                     ''実行管理
        TOPACS_FLG                          ''Topacs
        UPDATE_FLAG                         ''更新FLG
        LOCK_FLAG                           ''ﾛｯｸFLG
        VALID_FLAG                          ''有効/無効
        LINE_NO                             ''NO
        FILE_NAME                           ''ﾌｧｲﾙ名
        FILE_NAME_SUFFIX                    ''ﾌｧｲﾙ名Suffix
        FILE_NAME_SUFFIX_INTR               ''ﾌｧｲﾙ内Suffix
        CONTRACT                            ''契約順番
        PROJ_ID                             ''案件番号
        CONTRACT_SEQ                        ''契約通番
        NEW_EXIST                           ''新規/既存
        CUST_CATEGORY                       ''お客様集計ｶﾃｺﾞﾘ
        LETTER_ACCEPT_DATE                  ''実行通知書_受領日
        ORDER_DATE                          ''発注完了日
        LETTER_ID                           ''実行通知書番号
        LETTER_PLAN_DATE                    ''実行通知書_発行予定日
        ORDERCODE                           ''請求コード
        BU                                  ''Brand Category_BU
        BRAND                               ''Brand Category_Brand
        SUM_CATEGORY                        ''Brand Category_ｻﾏﾘｰ用ｶﾃｺﾞﾘ
        BRAND_SUB                           ''Brand Category_SubBrand
        OP1                                 ''Brand Category_Option1
        OP2                                 ''Brand Category_Option2
        BRAND_SIZE                          ''Brand Category_Size
        NON_SBO                             ''Brand Category_SBO制限
        POSTSCRIPT                          ''Brand Category_追記事項
        TOPACS_CPNO                         ''Brand承認_TOPACS CPNO
        BRAND_AP_FORM                       ''Brand承認_起票番号
        BRAND_AP_REQ                        ''Brand承認_申請番号
        BRAND_AP_CONF                       ''Brand承認_承認番号
        PATTERN_CD                          ''入力項目ﾊﾟﾀｰﾝ SEQ
        PATTERN                             ''入力項目ﾊﾟﾀｰﾝ
        PROD_ITEM01                         ''ﾊﾟﾀｰﾝ別入力項目_項目１
        PROD_ITEM02                         ''ﾊﾟﾀｰﾝ別入力項目_項目２
        PROD_ITEM03                         ''ﾊﾟﾀｰﾝ別入力項目_項目３
        PROD_SERIAL                         ''ｼﾘｱﾙ
        PROD_ITEM04                         ''ﾊﾟﾀｰﾝ別入力項目_項目４
        PROD_ITEM05                         ''ﾊﾟﾀｰﾝ別入力項目_項目５
        PROD_ITEM06                         ''ﾊﾟﾀｰﾝ別入力項目_項目６
        PROD_ITEM07                         ''ﾊﾟﾀｰﾝ別入力項目_項目７
        PROD_ITEM08                         ''ﾊﾟﾀｰﾝ別入力項目_項目８
        PROD_ITEM09                         ''ﾊﾟﾀｰﾝ別入力項目_項目９
        PROD_ITEM10                         ''ﾊﾟﾀｰﾝ別入力項目_項目１０
        PROD_ITEM11                         ''ﾊﾟﾀｰﾝ別入力項目_項目１１
        PROD_ITEM12                         ''ﾊﾟﾀｰﾝ別入力項目_項目１２
        PROD_ITEM13                         ''ﾊﾟﾀｰﾝ別入力項目_項目１３
        PROD_ITEM14                         ''ﾊﾟﾀｰﾝ別入力項目_項目１４
        PROD_ITEM15                         ''ﾊﾟﾀｰﾝ別入力項目_項目１５
        PROD_ITEM16                         ''ﾊﾟﾀｰﾝ別入力項目_項目１６
        PROD_ITEM17                         ''ﾊﾟﾀｰﾝ別入力項目_項目１７
        PROD_ITEM18                         ''ﾊﾟﾀｰﾝ別入力項目_項目１８
        PROD_ITEM19                         ''ﾊﾟﾀｰﾝ別入力項目_項目１９
        PROD_ITEM20                         ''ﾊﾟﾀｰﾝ別入力項目_項目２０
        PROD_ITEM22                         ''ﾊﾟﾀｰﾝ別入力項目_項目２２
        PROD_ITEM23                         ''ﾊﾟﾀｰﾝ別入力項目_項目２３
        PROD_ITEM24                         ''ﾊﾟﾀｰﾝ別入力項目_項目２４
        WD_ANNT_DATE                        ''製品･ｻｰﾋﾞｽ廃止発表日
        WD_DATE                             ''製品･ｻｰﾋﾞｽ廃止予定
        PRICE_CHG_DATE                      ''価格改定予定日
        QTY                                 ''数量
        INST_DATE                           ''導入_年月
        PAY_START_DATE                      ''請求開始_年月
        PAY_END_DATE                        ''請求終了_年月
        IGF_START_DATE                      ''IGF計算開始_年月
        IGF_END_DATE                        ''IGF計算終了_年月
        PAY_FLAG                            ''変則Payment_FLG
        BID_FLAG                            ''定額BID_FLG
        PAY_MONTHS                          ''請求期間
        PAY_VALIDATION                      ''サーバー制御
        PAY_METHOD                          ''支払方法
        IGF_APPLIED                         ''IGF_対象
        IGF_CONT_NO                         ''IGF契約番号
        IGF_CONT_FORM                       ''IGF契約形態
        IGF_CONT_MANAGMENT                  ''IGF契約物件管理
        IGF_RATE_IOC                        ''IGF_IOC料率
        LIST_PRICE_PROPOSAL                 ''Listprice(単価)_提案時
        LIST_PRICE_REFLESH                  ''Listprice(単価)_ﾘﾌﾚｯｼｭ後
        LIST_PRICE_TOTAL_PROPOSAL           ''Listprice(合計)_提案時	
        LIST_PRICE_TOTAL_REFLESH            ''Listprice(合計)_ﾘﾌﾚｯｼｭ後	
        DP_IOC                              ''IOC D%
        PRICE_UNIT_IOC                      ''IOC単価
        PRICE_UNIT_IOC_VAL                  ''OfferingPrice_Validation後
        PRICE_QTY_IOC                       ''IOC合計
        PRICE_TO_SPLIT                      ''展開金額
        LIST_PRICE_TOTAL_IOC                ''Listprice_期間合計
        PRICE_TOTAL_IOC                     ''D%適用後_期間合計
        PRICE_TOTAL_IGF                     ''IGF適用後 期間合計
        CONTRACT_IN                         ''契約期間内
        CONTRACT_OUT                        ''契約期間外
        PRICE_DEFF_IGF                      ''IGF金利(差額)
        PRICE_YEAR1                         ''年度情報1
        PRICE_YEAR2                         ''年度情報2
        PRICE_YEAR3                         ''年度情報3
        PRICE_YEAR4                         ''年度情報4
        PRICE_YEAR5                         ''年度情報5
        PRICE_YEAR6                         ''年度情報6
        PRICE_YEAR7                         ''年度情報7
        PRICE_YEAR8                         ''年度情報8
        PRICE_YEAR9                         ''年度情報9
        PRICE_YEAR10                        ''年度情報10
        PRICE_YEAR11                        ''年度情報11
        PRICE_YEAR12                        ''年度情報12
        PRICE_YEAR13                        ''年度情報13
        PRICE_YEAR14                        ''年度情報14
        PRICE_YEAR15                        ''年度情報15
        PRICE_YEAR16                        ''年度情報16
        PRICE_YEAR17                        ''年度情報17
        PRICE_YEAR18                        ''年度情報18
        PRICE_YEAR19                        ''年度情報19
        PRICE_YEAR20                        ''年度情報20
        PAST_PRICE_TOTAL                    ''過去の契約金額合計
        PRICE_YEAR1_MONTH1                  ''年度1_月度情報1
        PRICE_YEAR1_MONTH2                  ''年度1_月度情報2
        PRICE_YEAR1_MONTH3                  ''年度1_月度情報3
        PRICE_YEAR1_MONTH4                  ''年度1_月度情報4
        PRICE_YEAR1_MONTH5                  ''年度1_月度情報5
        PRICE_YEAR1_MONTH6                  ''年度1_月度情報6
        PRICE_YEAR1_MONTH7                  ''年度1_月度情報7
        PRICE_YEAR1_MONTH8                  ''年度1_月度情報8
        PRICE_YEAR1_MONTH9                  ''年度1_月度情報9
        PRICE_YEAR1_MONTH10                 ''年度1_月度情報10
        PRICE_YEAR1_MONTH11                 ''年度1_月度情報11
        PRICE_YEAR1_MONTH12                 ''年度1_月度情報12
        PRICE_YEAR2_MONTH1                  ''年度2_月度情報1
        PRICE_YEAR2_MONTH2                  ''年度2_月度情報2
        PRICE_YEAR2_MONTH3                  ''年度2_月度情報3
        PRICE_YEAR2_MONTH4                  ''年度2_月度情報4
        PRICE_YEAR2_MONTH5                  ''年度2_月度情報5
        PRICE_YEAR2_MONTH6                  ''年度2_月度情報6
        PRICE_YEAR2_MONTH7                  ''年度2_月度情報7
        PRICE_YEAR2_MONTH8                  ''年度2_月度情報8
        PRICE_YEAR2_MONTH9                  ''年度2_月度情報9
        PRICE_YEAR2_MONTH10                 ''年度2_月度情報10
        PRICE_YEAR2_MONTH11                 ''年度2_月度情報11
        PRICE_YEAR2_MONTH12                 ''年度2_月度情報12
        PRICE_YEAR3_MONTH1                  ''年度3_月度情報1
        PRICE_YEAR3_MONTH2                  ''年度3_月度情報2
        PRICE_YEAR3_MONTH3                  ''年度3_月度情報3
        PRICE_YEAR3_MONTH4                  ''年度3_月度情報4
        PRICE_YEAR3_MONTH5                  ''年度3_月度情報5
        PRICE_YEAR3_MONTH6                  ''年度3_月度情報6
        PRICE_YEAR3_MONTH7                  ''年度3_月度情報7
        PRICE_YEAR3_MONTH8                  ''年度3_月度情報8
        PRICE_YEAR3_MONTH9                  ''年度3_月度情報9
        PRICE_YEAR3_MONTH10                 ''年度3_月度情報10
        PRICE_YEAR3_MONTH11                 ''年度3_月度情報11
        PRICE_YEAR3_MONTH12                 ''年度3_月度情報12
        PRICE_YEAR4_MONTH1                  ''年度4_月度情報1
        PRICE_YEAR4_MONTH2                  ''年度4_月度情報2
        PRICE_YEAR4_MONTH3                  ''年度4_月度情報3
        PRICE_YEAR4_MONTH4                  ''年度4_月度情報4
        PRICE_YEAR4_MONTH5                  ''年度4_月度情報5
        PRICE_YEAR4_MONTH6                  ''年度4_月度情報6
        PRICE_YEAR4_MONTH7                  ''年度4_月度情報7
        PRICE_YEAR4_MONTH8                  ''年度4_月度情報8
        PRICE_YEAR4_MONTH9                  ''年度4_月度情報9
        PRICE_YEAR4_MONTH10                 ''年度4_月度情報10
        PRICE_YEAR4_MONTH11                 ''年度4_月度情報11
        PRICE_YEAR4_MONTH12                 ''年度4_月度情報12
        PRICE_YEAR5_MONTH1                  ''年度5_月度情報1
        PRICE_YEAR5_MONTH2                  ''年度5_月度情報2
        PRICE_YEAR5_MONTH3                  ''年度5_月度情報3
        PRICE_YEAR5_MONTH4                  ''年度5_月度情報4
        PRICE_YEAR5_MONTH5                  ''年度5_月度情報5
        PRICE_YEAR5_MONTH6                  ''年度5_月度情報6
        PRICE_YEAR5_MONTH7                  ''年度5_月度情報7
        PRICE_YEAR5_MONTH8                  ''年度5_月度情報8
        PRICE_YEAR5_MONTH9                  ''年度5_月度情報9
        PRICE_YEAR5_MONTH10                 ''年度5_月度情報10
        PRICE_YEAR5_MONTH11                 ''年度5_月度情報11
        PRICE_YEAR5_MONTH12                 ''年度5_月度情報12
        PRICE_YEAR6_MONTH1                  ''年度6_月度情報1
        PRICE_YEAR6_MONTH2                  ''年度6_月度情報2
        PRICE_YEAR6_MONTH3                  ''年度6_月度情報3
        PRICE_YEAR6_MONTH4                  ''年度6_月度情報4
        PRICE_YEAR6_MONTH5                  ''年度6_月度情報5
        PRICE_YEAR6_MONTH6                  ''年度6_月度情報6
        PRICE_YEAR6_MONTH7                  ''年度6_月度情報7
        PRICE_YEAR6_MONTH8                  ''年度6_月度情報8
        PRICE_YEAR6_MONTH9                  ''年度6_月度情報9
        PRICE_YEAR6_MONTH10                 ''年度6_月度情報10
        PRICE_YEAR6_MONTH11                 ''年度6_月度情報11
        PRICE_YEAR6_MONTH12                 ''年度6_月度情報12
        PRICE_YEAR7_MONTH1                  ''年度7_月度情報1
        PRICE_YEAR7_MONTH2                  ''年度7_月度情報2
        PRICE_YEAR7_MONTH3                  ''年度7_月度情報3
        PRICE_YEAR7_MONTH4                  ''年度7_月度情報4
        PRICE_YEAR7_MONTH5                  ''年度7_月度情報5
        PRICE_YEAR7_MONTH6                  ''年度7_月度情報6
        PRICE_YEAR7_MONTH7                  ''年度7_月度情報7
        PRICE_YEAR7_MONTH8                  ''年度7_月度情報8
        PRICE_YEAR7_MONTH9                  ''年度7_月度情報9
        PRICE_YEAR7_MONTH10                 ''年度7_月度情報10
        PRICE_YEAR7_MONTH11                 ''年度7_月度情報11
        PRICE_YEAR7_MONTH12                 ''年度7_月度情報12
        PRICE_YEAR8_MONTH1                  ''年度8_月度情報1
        PRICE_YEAR8_MONTH2                  ''年度8_月度情報2
        PRICE_YEAR8_MONTH3                  ''年度8_月度情報3
        PRICE_YEAR8_MONTH4                  ''年度8_月度情報4
        PRICE_YEAR8_MONTH5                  ''年度8_月度情報5
        PRICE_YEAR8_MONTH6                  ''年度8_月度情報6
        PRICE_YEAR8_MONTH7                  ''年度8_月度情報7
        PRICE_YEAR8_MONTH8                  ''年度8_月度情報8
        PRICE_YEAR8_MONTH9                  ''年度8_月度情報9
        PRICE_YEAR8_MONTH10                 ''年度8_月度情報10
        PRICE_YEAR8_MONTH11                 ''年度8_月度情報11
        PRICE_YEAR8_MONTH12                 ''年度8_月度情報12
        PRICE_YEAR9_MONTH1                  ''年度9_月度情報1
        PRICE_YEAR9_MONTH2                  ''年度9_月度情報2
        PRICE_YEAR9_MONTH3                  ''年度9_月度情報3
        PRICE_YEAR9_MONTH4                  ''年度9_月度情報4
        PRICE_YEAR9_MONTH5                  ''年度9_月度情報5
        PRICE_YEAR9_MONTH6                  ''年度9_月度情報6
        PRICE_YEAR9_MONTH7                  ''年度9_月度情報7
        PRICE_YEAR9_MONTH8                  ''年度9_月度情報8
        PRICE_YEAR9_MONTH9                  ''年度9_月度情報9
        PRICE_YEAR9_MONTH10                 ''年度9_月度情報10
        PRICE_YEAR9_MONTH11                 ''年度9_月度情報11
        PRICE_YEAR9_MONTH12                 ''年度9_月度情報12
        PRICE_YEAR10_MONTH1                 ''年度10_月度情報1
        PRICE_YEAR10_MONTH2                 ''年度10_月度情報2
        PRICE_YEAR10_MONTH3                 ''年度10_月度情報3
        PRICE_YEAR10_MONTH4                 ''年度10_月度情報4
        PRICE_YEAR10_MONTH5                 ''年度10_月度情報5
        PRICE_YEAR10_MONTH6                 ''年度10_月度情報6
        PRICE_YEAR10_MONTH7                 ''年度10_月度情報7
        PRICE_YEAR10_MONTH8                 ''年度10_月度情報8
        PRICE_YEAR10_MONTH9                 ''年度10_月度情報9
        PRICE_YEAR10_MONTH10                ''年度10_月度情報10
        PRICE_YEAR10_MONTH11                ''年度10_月度情報11
        PRICE_YEAR10_MONTH12                ''年度10_月度情報12
        PRICE_YEAR11_MONTH1                 ''年度11_月度情報1
        PRICE_YEAR11_MONTH2                 ''年度11_月度情報2
        PRICE_YEAR11_MONTH3                 ''年度11_月度情報3
        PRICE_YEAR11_MONTH4                 ''年度11_月度情報4
        PRICE_YEAR11_MONTH5                 ''年度11_月度情報5
        PRICE_YEAR11_MONTH6                 ''年度11_月度情報6
        PRICE_YEAR11_MONTH7                 ''年度11_月度情報7
        PRICE_YEAR11_MONTH8                 ''年度11_月度情報8
        PRICE_YEAR11_MONTH9                 ''年度11_月度情報9
        PRICE_YEAR11_MONTH10                ''年度11_月度情報10
        PRICE_YEAR11_MONTH11                ''年度11_月度情報11
        PRICE_YEAR11_MONTH12                ''年度11_月度情報12
        PRICE_YEAR12_MONTH1                 ''年度12_月度情報1
        PRICE_YEAR12_MONTH2                 ''年度12_月度情報2
        PRICE_YEAR12_MONTH3                 ''年度12_月度情報3
        PRICE_YEAR12_MONTH4                 ''年度12_月度情報4
        PRICE_YEAR12_MONTH5                 ''年度12_月度情報5
        PRICE_YEAR12_MONTH6                 ''年度12_月度情報6
        PRICE_YEAR12_MONTH7                 ''年度12_月度情報7
        PRICE_YEAR12_MONTH8                 ''年度12_月度情報8
        PRICE_YEAR12_MONTH9                 ''年度12_月度情報9
        PRICE_YEAR12_MONTH10                ''年度12_月度情報10
        PRICE_YEAR12_MONTH11                ''年度12_月度情報11
        PRICE_YEAR12_MONTH12                ''年度12_月度情報12
        PRICE_YEAR13_MONTH1                 ''年度13_月度情報1
        PRICE_YEAR13_MONTH2                 ''年度13_月度情報2
        PRICE_YEAR13_MONTH3                 ''年度13_月度情報3
        PRICE_YEAR13_MONTH4                 ''年度13_月度情報4
        PRICE_YEAR13_MONTH5                 ''年度13_月度情報5
        PRICE_YEAR13_MONTH6                 ''年度13_月度情報6
        PRICE_YEAR13_MONTH7                 ''年度13_月度情報7
        PRICE_YEAR13_MONTH8                 ''年度13_月度情報8
        PRICE_YEAR13_MONTH9                 ''年度13_月度情報9
        PRICE_YEAR13_MONTH10                ''年度13_月度情報10
        PRICE_YEAR13_MONTH11                ''年度13_月度情報11
        PRICE_YEAR13_MONTH12                ''年度13_月度情報12
        PRICE_YEAR14_MONTH1                 ''年度14_月度情報1
        PRICE_YEAR14_MONTH2                 ''年度14_月度情報2
        PRICE_YEAR14_MONTH3                 ''年度14_月度情報3
        PRICE_YEAR14_MONTH4                 ''年度14_月度情報4
        PRICE_YEAR14_MONTH5                 ''年度14_月度情報5
        PRICE_YEAR14_MONTH6                 ''年度14_月度情報6
        PRICE_YEAR14_MONTH7                 ''年度14_月度情報7
        PRICE_YEAR14_MONTH8                 ''年度14_月度情報8
        PRICE_YEAR14_MONTH9                 ''年度14_月度情報9
        PRICE_YEAR14_MONTH10                ''年度14_月度情報10
        PRICE_YEAR14_MONTH11                ''年度14_月度情報11
        PRICE_YEAR14_MONTH12                ''年度14_月度情報12
        PRICE_YEAR15_MONTH1                 ''年度15_月度情報1
        PRICE_YEAR15_MONTH2                 ''年度15_月度情報2
        PRICE_YEAR15_MONTH3                 ''年度15_月度情報3
        PRICE_YEAR15_MONTH4                 ''年度15_月度情報4
        PRICE_YEAR15_MONTH5                 ''年度15_月度情報5
        PRICE_YEAR15_MONTH6                 ''年度15_月度情報6
        PRICE_YEAR15_MONTH7                 ''年度15_月度情報7
        PRICE_YEAR15_MONTH8                 ''年度15_月度情報8
        PRICE_YEAR15_MONTH9                 ''年度15_月度情報9
        PRICE_YEAR15_MONTH10                ''年度15_月度情報10
        PRICE_YEAR15_MONTH11                ''年度15_月度情報11
        PRICE_YEAR15_MONTH12                ''年度15_月度情報12
        PRICE_YEAR16_MONTH1                 ''年度16_月度情報1
        PRICE_YEAR16_MONTH2                 ''年度16_月度情報2
        PRICE_YEAR16_MONTH3                 ''年度16_月度情報3
        PRICE_YEAR16_MONTH4                 ''年度16_月度情報4
        PRICE_YEAR16_MONTH5                 ''年度16_月度情報5
        PRICE_YEAR16_MONTH6                 ''年度16_月度情報6
        PRICE_YEAR16_MONTH7                 ''年度16_月度情報7
        PRICE_YEAR16_MONTH8                 ''年度16_月度情報8
        PRICE_YEAR16_MONTH9                 ''年度16_月度情報9
        PRICE_YEAR16_MONTH10                ''年度16_月度情報10
        PRICE_YEAR16_MONTH11                ''年度16_月度情報11
        PRICE_YEAR16_MONTH12                ''年度16_月度情報12
        PRICE_YEAR17_MONTH1                 ''年度17_月度情報1
        PRICE_YEAR17_MONTH2                 ''年度17_月度情報2
        PRICE_YEAR17_MONTH3                 ''年度17_月度情報3
        PRICE_YEAR17_MONTH4                 ''年度17_月度情報4
        PRICE_YEAR17_MONTH5                 ''年度17_月度情報5
        PRICE_YEAR17_MONTH6                 ''年度17_月度情報6
        PRICE_YEAR17_MONTH7                 ''年度17_月度情報7
        PRICE_YEAR17_MONTH8                 ''年度17_月度情報8
        PRICE_YEAR17_MONTH9                 ''年度17_月度情報9
        PRICE_YEAR17_MONTH10                ''年度17_月度情報10
        PRICE_YEAR17_MONTH11                ''年度17_月度情報11
        PRICE_YEAR17_MONTH12                ''年度17_月度情報12
        PRICE_YEAR18_MONTH1                 ''年度18_月度情報1
        PRICE_YEAR18_MONTH2                 ''年度18_月度情報2
        PRICE_YEAR18_MONTH3                 ''年度18_月度情報3
        PRICE_YEAR18_MONTH4                 ''年度18_月度情報4
        PRICE_YEAR18_MONTH5                 ''年度18_月度情報5
        PRICE_YEAR18_MONTH6                 ''年度18_月度情報6
        PRICE_YEAR18_MONTH7                 ''年度18_月度情報7
        PRICE_YEAR18_MONTH8                 ''年度18_月度情報8
        PRICE_YEAR18_MONTH9                 ''年度18_月度情報9
        PRICE_YEAR18_MONTH10                ''年度18_月度情報10
        PRICE_YEAR18_MONTH11                ''年度18_月度情報11
        PRICE_YEAR18_MONTH12                ''年度18_月度情報12
        PRICE_YEAR19_MONTH1                 ''年度19_月度情報1
        PRICE_YEAR19_MONTH2                 ''年度19_月度情報2
        PRICE_YEAR19_MONTH3                 ''年度19_月度情報3
        PRICE_YEAR19_MONTH4                 ''年度19_月度情報4
        PRICE_YEAR19_MONTH5                 ''年度19_月度情報5
        PRICE_YEAR19_MONTH6                 ''年度19_月度情報6
        PRICE_YEAR19_MONTH7                 ''年度19_月度情報7
        PRICE_YEAR19_MONTH8                 ''年度19_月度情報8
        PRICE_YEAR19_MONTH9                 ''年度19_月度情報9
        PRICE_YEAR19_MONTH10                ''年度19_月度情報10
        PRICE_YEAR19_MONTH11                ''年度19_月度情報11
        PRICE_YEAR19_MONTH12                ''年度19_月度情報12
        PRICE_YEAR20_MONTH1                 ''年度20_月度情報1
        PRICE_YEAR20_MONTH2                 ''年度20_月度情報2
        PRICE_YEAR20_MONTH3                 ''年度20_月度情報3
        PRICE_YEAR20_MONTH4                 ''年度20_月度情報4
        PRICE_YEAR20_MONTH5                 ''年度20_月度情報5
        PRICE_YEAR20_MONTH6                 ''年度20_月度情報6
        PRICE_YEAR20_MONTH7                 ''年度20_月度情報7
        PRICE_YEAR20_MONTH8                 ''年度20_月度情報8
        PRICE_YEAR20_MONTH9                 ''年度20_月度情報9
        PRICE_YEAR20_MONTH10                ''年度20_月度情報10
        PRICE_YEAR20_MONTH11                ''年度20_月度情報11
        PRICE_YEAR20_MONTH12                ''年度20_月度情報12
    End Enum

#End Region

#Region "構造体"
    ''ﾃﾞﾘﾊﾞﾘﾌｧｲﾙの件数
    Public Structure derivaryCount
        Dim InsertCount As Integer                 ''全体の取込件数

        Dim Topacs_MachCount As Integer            ''正常終了
        Dim Topacs_UnMachCount As Integer          ''取込失敗
        Dim Topacs_DataErrCount As Integer         ''取込対象外

        Dim ACT_MachCount As Integer               ''正常終了
        Dim ACT_UnMachCount As Integer             ''取込失敗
        Dim ACT_DataErrCount As Integer            ''取込対象外

        Dim Serial_MachCount As Integer            ''正常終了
        Dim Serial_UnMachCount As Integer          ''取込失敗
        Dim Serial_DataErrCount As Integer         ''取込対象外
    End Structure
#End Region

#Region "Public Method"

#Region "実行管理作成"

    ''' <summary>
    ''' 機　能：実行管理作成処理
    ''' 概　要：TempMDBから実行管理（EXCEL）を作成する。
    ''' </summary>
    ''' <param name="strOutputExcelPath">出力先フォルダ</param>
    ''' <param name="intContractStart">契約開始</param>
    ''' <param name="intContractEnd">契約終了</param>
    ''' <param name="intPaymentStart">Payment開始年</param>
    ''' <param name="intPaymentPeriod">Payment展開期間</param>
    ''' <param name="blnOutputSheet">シート出力有無フラグ</param>
    ''' <param name="strErrMsg">エラーメッセージ</param>
    ''' <returns>True:正常、False:異常</returns>
    ''' <remarks>TempMDBから実行管理（EXCEL）を作成する</remarks>
    'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
    Public Function OutputActExcel(ByVal strOutputExcelPath As String,
                                   ByVal intContractStart As Integer,
                                   ByVal intContractEnd As Integer,
                                   ByVal intPaymentStart As Integer,
                                   ByVal intPaymentPeriod As Integer,
                                   ByVal blnOutputSheet() As Boolean,
                                   ByRef strFileActAll As String,
                                   ByRef strFileActOffer As String,
                                   ByRef strErrMsg As String) As Boolean
        'Public Function OutputActExcel(ByVal strOutputExcelPath As String,
        '                               ByVal intContractStart As Integer,
        '                               ByVal intContractEnd As Integer,
        '                               ByVal intPaymentStart As Integer,
        '                               ByVal intPaymentPeriod As Integer,
        '                               ByVal blnOutputSheet() As Boolean,
        '                               ByRef strErrMsg As String) As Boolean
        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

        Dim blnRet As Boolean
        Dim strTempMdb As String
        Dim con As New OleDbConnection
        Dim conStr As New StringBuilder
        Dim ofm As New OioFileManage
        Dim frmWait As New Frm_WaitDialog
        'Excelオブジェクト
        Dim xlApp As Excel.Application = Nothing
        Dim xlBooks As Excel.Workbooks = Nothing

        OutputActExcel = False

        Try
            '''' 処理：TempMDB Open
            Dim mmc As New MasterMdbControl
            con = mmc.GetOleTmpDBConnection(CommonVariable.CPNO, CommonVariable.MdbPW)

            '2018/10/18 MDB無しエラー回避 str
            If IsNothing(con) = True Then
                Exit Function
            End If
            '2018/10/18 MDB無しエラー回避 end

            '----------------------------
            'EXCEL 初期設定
            '----------------------------
            '''' 処理：Excelｵﾌﾞｼﾞｪｸﾄの初期設定
            xlApp = New Excel.Application
            '警告メッセージの非表示
            xlApp.DisplayAlerts = False
            xlApp.EnableEvents = False
            xlApp.Visible = False
            xlBooks = xlApp.Workbooks

            '----------------------------
            '実行管理作成
            '----------------------------
            '''' 処理：実行管理作成処理()を呼び出す
            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            blnRet = ActOutputMain(strOutputExcelPath,
                                   con,
                                   xlApp,
                                   xlBooks,
                                   intContractStart,
                                   intContractEnd,
                                   intPaymentStart,
                                   intPaymentPeriod,
                                   blnOutputSheet,
                                   strFileActAll,
                                   strFileActOffer,
                                   strErrMsg)
            'blnRet = ActOutputMain(strOutputExcelPath,
            '                       con,
            '                       xlApp,
            '                       xlBooks,
            '                       intContractStart,
            '                       intContractEnd,
            '                       intPaymentStart,
            '                       intPaymentPeriod,
            '                       blnOutputSheet,
            '                       strErrMsg)
            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            '''' 条件：処理結果判定
            '''' ケース：処理結果が異常の場合、処理を中断する
            If blnRet = False Then
                Exit Function
            End If

            OutputActExcel = True

        Catch ex As Exception
            strErrMsg = ex.Message.ToString

        Finally
            '2018/10/18 MDB無しエラー回避 str
            If IsNothing(con) = False Then
                con.Close()
            End If
            '2018/10/18 MDB無しエラー回避 end

            '''' 処理：Excelｵﾌﾞｼﾞｪｸﾄ解放
            ExcelObjRelease.ReleaseExcelObj(xlBooks, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try

    End Function
#End Region

#Region "実行管理読込"
    ''' <summary>
    ''' 機　能：実行管理ファイル読込み処理
    ''' 説　明：
    ''' </summary>
    ''' <param name="sourceFilePath"></param>
    ''' <param name="destFilePath"></param>
    ''' <param name="intOutputCnt"></param>
    ''' <param name="frmWait"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function ImportActData(ByVal sourceFilePath As String,
                                  ByVal destFilePath As String,
                                  ByVal intPaymentPeriod As Integer,
                                  ByRef intOutputCnt As Integer,
                                  ByRef strMsg As String) As Boolean

        Dim con As New OleDbConnection
        Dim conStr As New StringBuilder
        Dim xlApp As New Excel.Application
        Dim xlInBook As Excel.Workbook = Nothing
        Dim xlInTmpSerialSheet As Excel.Worksheet = Nothing
        Dim xlInPSSheet As Excel.Worksheet = Nothing
        Dim xlOutBook As Excel.Workbook = Nothing
        Dim xlOutOBAMASheet As Excel.Worksheet = Nothing
        Dim xlCell As Excel.Range = Nothing
        Dim xlSortCell As Excel.Range = Nothing
        Dim strWork As String
        Dim updFlgU As Boolean
        Dim strTempMdb As String

        ImportActData = False

        Try
            '''' 処理：Excelオブジェクトの設定
            xlApp.EnableEvents = False
            xlInBook = xlApp.Workbooks.Open(sourceFilePath)
            xlOutBook = xlApp.Workbooks.Open(destFilePath)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = False

            '''' 処理：Excelのオートフィルタを初期化
            xlOutOBAMASheet = xlOutBook.Worksheets(SHEET_NAME_PS)
            Dim excelWrite As New ExcelWrite
            Call excelWrite.CrearAutoFilter(xlOutOBAMASheet)


            '''' 繰返し_開始：Paymentシート
            '''' 　OIOシートのEOF行検索と更新FLG = U、LockFlg = Pのデータ検索
            updFlgU = False
            Dim eofLine As Integer
            For eofLine = EXCEL_PAYMENTLINEDATE_OUTROW To xlOutOBAMASheet.Rows.Count - 1

                '''' 　条件：NO判定（最終行判定）
                '''' 　ケース：NOが空白の場合、繰り返しを抜ける
                xlCell = xlOutOBAMASheet.Cells(eofLine, excelWrite.ExcelPaymentLineColumn.LINE_NO)
                strWork = excelWrite.changeDBNullToString(xlCell.Value)
                If strWork = "" Then
                    eofLine = eofLine - 1
                    Exit For
                End If

                '''' 　条件：作業FLG判定
                '''' 　ケース：作業FLGが更新(U)の場合、正常で処理を抜ける
                xlCell = xlOutOBAMASheet.Cells(eofLine, excelWrite.ExcelPaymentLineColumn.UPDATE_FLAG)
                If excelWrite.changeDBNullToString(xlCell.Value) = "U" Then
                    updFlgU = True
                    Exit For
                End If

                '''' 　条件：Status判定
                '''' 　ケース：Statusが価格承認済(P)の場合、正常で処理を抜ける
                xlCell = xlOutOBAMASheet.Cells(eofLine, excelWrite.ExcelPaymentLineColumn.LOCK_FLAG)
                If excelWrite.changeDBNullToString(xlCell.Value) = "P" Then
                    updFlgU = True
                    Exit For
                End If

            Next
            '''' 繰返し_終了：
            If updFlgU = True Then
                intOutputCnt = -1
                ImportActData = True
                Exit Function
            End If

            '''' 処理：MDBのｺﾋﾟｰ(CopyTmpMDB())を呼び出す
            Call CopyTmpMDB()

            ''----------------------------
            ''DBオープン
            ''----------------------------
            '''' 処理：TempMDB Open
            Dim mmc As New MasterMdbControl
            con = mmc.GetOleWorkTmpDBConnection(CommonVariable.CPNO, CommonVariable.MdbPW)

            '----------------------------
            '実行管理のデータをMDBにセットする
            '----------------------------
            '''' 処理：以下のシートの実行管理データTempMDB保存処理(UpdASRPaymentACTDataTable())を呼び出す
            '''' 　①要回答未実行（過去－２ヶ月）
            '''' 　②任意回答未実行（3ヶ月以降）
            Dim blnOutputSheet As Boolean = False
            For Each xlInPSSheet In xlInBook.Worksheets
                If xlInPSSheet.Name = "①要回答未実行（過去－２ヶ月）" Or
                    xlInPSSheet.Name = "②任意回答未実行（3ヶ月以降）" Then
                    blnOutputSheet = True
                    Call UpdASRPaymentACTDataTable(con, xlInPSSheet)
                End If
                ExcelObjRelease.ReleaseExcelObj(xlInPSSheet, ExcelObjRelease.OBJECT_NOTHING)
            Next

            '----------------------------
            'Data Import
            '----------------------------
            '''' 処理：Payment反映処理(WriteASRPaymentACTData())を呼び出す
            Call WriteASRPaymentACTData(con, eofLine, intPaymentPeriod, xlOutOBAMASheet, intOutputCnt)

            xlOutOBAMASheet.Activate()
            xlCell = xlOutOBAMASheet.Range("A1")
            xlCell.Select()
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlOutOBAMASheet, ExcelObjRelease.OBJECT_NOTHING)

            '''' 処理：Payment保存
            xlOutBook.Save()
            '''' 条件：反映対象シート有無判定
            If blnOutputSheet = True Then
                '''' ケース：反映対象のシートが有る場合、取込件数メッセージ作成
                strMsg = "@件、取り込みました。".Replace("@", intOutputCnt.ToString)
            Else
                '''' ケース：反映対象のシートが無い場合、メッセージを取得（反映対象のシートがありません。）
                strMsg = FileReader.GetMessage("MSG_0496")
                Exit Function
            End If

            ImportActData = True

        Catch ex As Exception
            strMsg = ex.Message.ToString

        Finally
            con.Close()

            ''Excelの解放
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSortCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlOutOBAMASheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlInPSSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlInTmpSerialSheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlOutBook) = False Then
                xlOutBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlOutBook, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlInBook) = False Then
                xlInBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlInBook, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()

        End Try

    End Function

#End Region

#Region "ﾃﾞﾘﾊﾞﾘ管理作成"
    ''' <summary>
    ''' デリバリーファイルExcel処理
    ''' </summary>
    ''' <param name="intPaymentPeriod">Payment展開期間</param>
    ''' <param name="strMsg">メッセージ</param>
    ''' <remarks></remarks>
    'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
    Public Sub OutputDeriFile(ByVal intPaymentPeriod As Integer,
                              ByRef strFileDelivery As String,
                              ByRef strMsg As String)
        'Public Sub OutputDeriFile(ByVal intPaymentPeriod As Integer,
        '                      ByRef strMsg As String)
        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
        ''テンプレートファイル名取得
        Dim ofm As New OioFileManage
        Dim TmpDeliveryPath As String
        TmpDeliveryPath = TEMP_DIR_PATH + TEMP_DERI_FILE_NAME

        Try

            ''出力するシート数を取得
            Dim MaxSheetNo As Integer           ''出力するOIOシートのMax数
            Dim MaxMdbCount As Integer          ''MDBのMAX件数
            Dim MaxSheetLine As Integer         ''1シート出力するMAX件数
            MaxSheetNo = 1                      ''ファイル分割保留のため、出力数 = "1"固定値
            MaxMdbCount = GetMaxMdbCount(ContractMDBPath)
            MaxSheetLine = MaxMdbCount

            ''出力するファイル名を取得
            Dim outFileNM As String
            Dim outFilePath As String
            Dim outFileList As New ArrayList
            Dim i As Integer
            For i = 1 To MaxSheetNo

                ''1ﾌｧｲﾙのみなら、ﾌｧｲﾙ枝番を採番しない。
                If MaxSheetNo = 1 Then
                    outFileNM = "Delivery_Export_" & _
                                CommonVariable.CPNO & _
                                "(" & CommonVariable.CUSTOMERNAME & ")_" & _
                                Now.ToString("yyyyMMddHHmm") & _
                                ".xlsm"
                End If


                ''ファイルﾊﾟｽ
                outFilePath = DERI_OUT_DIR + "\" + outFileNM
                outFileList.Add(outFilePath)

            Next


            '''' 条件：ﾃﾞﾘﾊﾞﾘファイルのOPENチェック(OioFileManage.ChkOpenedExcelFile)
            '''' 　※ﾃﾞﾘﾊﾞﾘファイルはファイル名に日付時刻がつかないため、Openしているとエラーになる。
            '''' ケース：OPEN中の場合、エラーメッセージを表示し処理を中断する
            '''' 　メッセージ：ID:MSG_0325
            '''' 　　既にファイルがOPENしています。ファイル名：xxxxxxxxxxxxxxxxxx
            Dim filePath As String
            Dim fileManage As New OioFileManage
            For Each filePath In outFileList
                If File.Exists(filePath) Then
                    If fileManage.ChkOpenedExcelFile(filePath) = False Then
                        strMsg = FileReader.GetMessage("MSG_0325") & "　ファイル名：" & Path.GetFileName(filePath)
                        Exit Sub
                    End If
                End If
            Next


            '''' 処理：テンプレートファイルをコピーし、申請シートを作成する。
            Dim intOutPsCnt As Integer = 0
            Dim intOutSerialCnt As Integer = 0
            Call CreateOutSheet(outFileList,
                                TmpDeliveryPath,
                                MaxSheetLine,
                                MaxMdbCount,
                                intPaymentPeriod,
                                intOutPsCnt,
                                intOutSerialCnt)

            '''' 処理：ﾃﾞﾘﾊﾞﾘ・実行管理の文言作成
            strMsg = "　ｼﾘｱﾙ           " & intOutSerialCnt.ToString & "件" & vbCrLf & "　Payment       " & intOutPsCnt.ToString & "件"

            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            strFileDelivery = filePath
            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

        Catch ex As Exception
            strMsg = ex.Message.ToString & "(OutputDeriFile)"

        End Try

    End Sub

#End Region

#Region "ﾃﾞﾘﾊﾞﾘ管理読込"
    ''' <summary>
    ''' デリバリー情報読込み（Ｉｍｐｏｒｔ）処理
    ''' </summary>
    ''' <param name="intPaymentPeriod"></param>
    ''' <param name="sourceFilePath"></param>
    ''' <param name="destFilePath"></param>
    ''' <param name="derivaryCount"></param>
    ''' <param name="updFlgU"></param>
    ''' <param name="sheetChkFlg"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function deliveryReflection(ByVal intPaymentPeriod As Integer,
                                       ByVal sourceFilePath As String, _
                                       ByVal destFilePath As String, _
                                       ByRef derivaryCount As derivaryCount,
                                       ByRef updFlgU As Boolean, _
                                       ByRef sheetChkFlg As Boolean) As Boolean

        sheetChkFlg = True
        deliveryReflection = False

        Dim con As New ADODB.Connection()
        Dim xlApp As New Excel.Application
        'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
        Dim xlBooks As Excel.Workbooks
        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
        Dim xlInBook As Excel.Workbook = Nothing
        Dim xlInTmpSerialSheet As Excel.Worksheet = Nothing
        Dim xlInPSSheet As Excel.Worksheet = Nothing
        Dim xlOutBook As Excel.Workbook = Nothing
        Dim xlOutOBAMASheet As Excel.Worksheet = Nothing
        Dim xlCell As Excel.Range = Nothing
        Dim xlSortCell As Excel.Range = Nothing
        Dim ofm As New OioFileManage

        Try
            Debug.Print(Now.ToString("yyyy/MM/dd HH:mm:ss ") & "デリバリ開始")
            '''' 処理：Excelオブジェクトの設定
            xlApp.EnableEvents = False
            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            xlBooks = xlApp.Workbooks
            xlInBook = xlBooks.Open(sourceFilePath)
            xlOutBook = xlBooks.Open(destFilePath)
            'xlInBook = xlApp.Workbooks.Open(sourceFilePath)
            'xlOutBook = xlApp.Workbooks.Open(destFilePath)
            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            xlApp.EnableEvents = False
            xlApp.DisplayAlerts = False

            '''' 処理：Excelのオートフィルタを初期化
            xlOutOBAMASheet = xlOutBook.Worksheets(SHEET_NAME_PS)
            Dim excelWrite As New ExcelWrite
            Call excelWrite.CrearAutoFilter(xlOutOBAMASheet)

            '''' 繰返し_開始：Paymentシート
            '''' 　OIOシートのEOF行検索と更新FLG = U、LockFlg = Pのデータ検索
            updFlgU = False
            Dim eofLine As Integer
            For eofLine = EXCEL_PAYMENTLINEDATE_OUTROW To xlOutOBAMASheet.Rows.Count - 1
                '''' 　条件：NO判定（最終行判定）
                '''' 　ケース：NOが空白の場合、繰り返しを抜ける
                xlCell = xlOutOBAMASheet.Cells(eofLine, excelWrite.ExcelPaymentLineColumn.LINE_NO)
                If excelWrite.changeDBNullToString(xlCell.Value) = "" Then
                    eofLine = eofLine - 1
                    Exit For
                End If
                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

                '''' 　条件：作業FLG判定
                '''' 　ケース：作業FLGが更新(U)の場合、正常で処理を抜ける
                xlCell = xlOutOBAMASheet.Cells(eofLine, excelWrite.ExcelPaymentLineColumn.UPDATE_FLAG)
                If excelWrite.changeDBNullToString(xlCell.Value) = "U" Then
                    updFlgU = True
                    Exit For
                End If
                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

                '''' 　条件：Status判定
                '''' 　ケース：Statusが価格承認済(P)の場合、正常で処理を抜ける
                xlCell = xlOutOBAMASheet.Cells(eofLine, excelWrite.ExcelPaymentLineColumn.LOCK_FLAG)
                If excelWrite.changeDBNullToString(xlCell.Value) = "P" Then
                    updFlgU = True
                    Exit For
                End If
                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

            Next
            '''' 繰返し_終了：
            If updFlgU = True Then
                deliveryReflection = True
                Exit Function
            End If

            '''' 処理：各ｼｰﾄ（ﾃﾞﾘﾊﾞﾘPayment、ﾃﾞﾘﾊﾞﾘSerial）のセット
            xlInPSSheet = xlInBook.Worksheets(CommonConstant.SHEETNAME_DERI_PS)
            xlInTmpSerialSheet = xlInBook.Worksheets(CommonConstant.SHEETNAME_DERI_SERIAL)

            '''' 処理：デリバリ管理ファイルの入力チェックマクロの起動
            Dim Result0 As String = DirectCast(xlApp.Run("'" & xlInBook.Name & "'!入力チェックボタンの処理", "EVENT"), String)

            '''' 処理：各ｼｰﾄの入力チェックが完了判定
            '''' ケース：１つでも「OK」以外の場合、処理を中断する
            Dim sheetInputChk(1) As String
            xlCell = xlInPSSheet.Range("B3")
            sheetInputChk(0) = excelWrite.changeDBNullToString(xlCell.Value)
            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            xlCell = xlInTmpSerialSheet.Range("B3")
            sheetInputChk(1) = excelWrite.changeDBNullToString(xlCell.Value)
            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            If sheetInputChk(0) <> "チェック結果：OK" Or _
               sheetInputChk(1) <> "チェック結果：OK" Then
                deliveryReflection = True
                sheetChkFlg = False
                Exit Function
            End If

            '''' 処理：MDBのｺﾋﾟｰ(CopyTmpMDB())を呼び出す
            Call CopyTmpMDB()

            Debug.Print(Now.ToString("yyyy/MM/dd HH:mm:ss ") & "DBの接続情報取得")
            '''' 処理：DBの接続
            Dim mmc As New MasterMdbControl
            con = mmc.GetAdoWorkTmpDBConnection(CommonVariable.CPNO, CommonVariable.MdbPW)

            Debug.Print(Now.ToString("yyyy/MM/dd HH:mm:ss ") & "実行管理のデータをMDBにセットする")
            '''' 処理：実行管理のデータをMDBにセットする(UpdASRPaymentACTDataTable())
            Call UpdASRPaymentACTDataTable(con, xlInPSSheet)

            Debug.Print(Now.ToString("yyyy/MM/dd HH:mm:ss ") & "ｼﾘｱﾙのデータをMDBにセットする")
            '''' 処理：ｼﾘｱﾙのデータをMDBにセットする
            Call UpdASRSerialDataTable(con, xlInTmpSerialSheet)

            ''データ出力
            ''======================================================
            '''' 処理：検索用ワークテーブル作成(MakeWorkData())
            Debug.Print(Now.ToString("yyyy/MM/dd HH:mm:ss ") & "検索用ワークテーブル作成")
            Call MakeWorkData(con)

            Debug.Print(Now.ToString("yyyy/MM/dd HH:mm:ss ") & "Delivery情報をOBAMASheetに反映する")
            '''' 処理：Payment反映処理
            Call WriteDeliveryToPayment(con, eofLine, xlOutOBAMASheet)

            '''' 処理：開始年設定処理(SetStartMonth())
            Call SetStartMonth(xlOutOBAMASheet, CD_ASR_DELIVERY)

            '''' 処理：Payment展開期間分列削除処理(excelWrite.CreatePaymentPeriod)
            Debug.Print(Now.ToString("yyyy/MM/dd HH:mm:ss ") & "Payment展開期間分列削除")
            Call excelWrite.CreatePaymentPeriod(xlOutOBAMASheet,
                                                excelWrite.chgExcelColumnIdxToChar(excelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1),
                                                intPaymentPeriod)

            Debug.Print(Now.ToString("yyyy/MM/dd HH:mm:ss ") & "Topacs、実行管理、ｼﾘｱﾙのログを書込み")
            '''' 処理：Topacs、実行管理、ｼﾘｱﾙのログを書込み処理(WriteDerivaryLog())
            Call WriteDerivaryLog(intPaymentPeriod, con, xlInPSSheet, xlInTmpSerialSheet)

            Debug.Print(Now.ToString("yyyy/MM/dd HH:mm:ss ") & "データ出力件数をカウント")
            '''' 処理：データ出力件数取得処理(GetDeriOutCount())
            Call GetDeriOutCount(con, derivaryCount)

            Debug.Print(Now.ToString("yyyy/MM/dd HH:mm:ss ") & "保存")
            '''' 処理：ﾃﾞﾘﾊﾞﾘﾌｧｲﾙのログを更新
            xlApp.DisplayAlerts = False
            xlInBook.Save()

            Debug.Print(Now.ToString("yyyy/MM/dd HH:mm:ss ") & "OIO-Sheetのソート")
            '''' 処理：Paymentｼｰﾄのソート
            Call SortOioSheet(xlOutOBAMASheet)

            '''' 処理：Paymentﾌｧｲﾙ保存
            '''' 　個別PSの保存 ※Paymetファイルを新規作成済に反映するため、別名保存不要
            xlApp.EnableEvents = False
            Call xlOutBook.Save()
            xlApp.EnableEvents = True

            deliveryReflection = True
            Debug.Print(Now.ToString("yyyy/MM/dd HH:mm:ss ") & "デリバリ終了")

        Catch ex As Exception
            Throw ex

        Finally

            ''MDB接続のClose
            If con.State = ADODB.ObjectStateEnum.adStateOpen Then
                con.Close()
            End If

            '''' 処理：Excelｵﾌﾞｼﾞｪｸﾄの解放
            ''==========================================================================
            ''Cellの解放
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSortCell, ExcelObjRelease.OBJECT_NOTHING)


            ''Sheetの解放
            ExcelObjRelease.ReleaseExcelObj(xlOutOBAMASheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlInPSSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlInTmpSerialSheet, ExcelObjRelease.OBJECT_NOTHING)

            ''Bookの解放
            xlApp.EnableEvents = False
            If IsNothing(xlOutBook) = False Then
                xlOutBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlOutBook, ExcelObjRelease.OBJECT_NOTHING)

            If IsNothing(xlInBook) = False Then
                xlInBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlInBook, ExcelObjRelease.OBJECT_NOTHING)

            ''APPの解放
            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            ExcelObjRelease.ReleaseExcelObj(xlBooks, ExcelObjRelease.OBJECT_NOTHING)
            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            xlApp.EnableEvents = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()

        End Try

    End Function

    ''' <summary>
    ''' 処理の完了メッセージを取得する。
    ''' </summary>
    ''' <param name="msg"></param>
    ''' <param name="msgKB"></param>
    ''' <param name="strPSFilePath"></param>
    ''' <param name="derivaryCount"></param>
    ''' <param name="updFlgU"></param>
    ''' <param name="sheetChkFlg"></param>
    ''' <remarks></remarks>
    Public Sub GetExitMsg(ByRef msg As String, _
                           ByRef msgKB As String, _
                           ByVal strPSFilePath As String, _
                           ByVal derivaryCount As ExcelAsrManage.derivaryCount, _
                           ByVal updFlgU As Boolean, _
                           ByVal sheetChkFlg As Boolean)

        ''===================================================
        ''	①区分のチェック：正常終了か警告終了か判定する。
        ''===================================================

        ''正常終了
        ''※取込対象外、取込失敗件数が全て0の場合
        '''' 条件：取込件数判定
        '''' ケース：全てが０件の場合、メッセージ区分を正常終了
        If derivaryCount.Topacs_UnMachCount = 0 And _
           derivaryCount.Topacs_DataErrCount = 0 And _
           derivaryCount.ACT_UnMachCount = 0 And _
           derivaryCount.ACT_DataErrCount = 0 And _
           derivaryCount.Serial_UnMachCount = 0 And _
           derivaryCount.Serial_DataErrCount = 0 Then
            msgKB = MSG_OK
        Else
            '''' ケース：０件以外がある場合、メッセージ区分を警告終了
            msgKB = MSG_CRITICAL
        End If

        ''更新FLG = U
        '''' 条件：更新フラグ判定
        '''' ケース：更新フラグ有の場合、メッセージ区分を更新エラー終了
        If updFlgU = True Then
            msgKB = MSG_UPDFLGERR
        End If

        '''' 条件：入力チェック判定
        '''' ケース：「チェック結果：OK」以外の場合、メッセージ区分をチェックエラー終了
        If sheetChkFlg = False Then
            msgKB = MSG_SHEETCHKERR
        End If

        ''===================================================
        ''	②メッセージを取得する。
        ''===================================================
        '''' 条件:メッセージ区分を判定
        Select Case msgKB

            Case MSG_OK
                '''' ケース：メッセージ区分が正常終了の場合、以下のメッセージを作成する
                '''' 　【ｼﾘｱﾙｼｰﾄ：実ｼﾘｱﾙ情報】
                '''' 　取込みが成功しました。
                '''' 　xx件
                '''' 　【Paymentｼｰﾄ：実行管理情報】
                '''' 　取込みが成功しました。
                '''' 　xx件
                '''' 　【Paymentｼｰﾄ：Topacs情報】
                '''' 　取込みが成功しました。
                '''' 　xx件
                '''' 　にxx行の更新ﾃﾞｰﾀを追加しました。

                ''実ｼﾘｱﾙ情報
                msg = msg & "【ｼﾘｱﾙｼｰﾄ：実ｼﾘｱﾙ情報】" + vbCrLf +
                            " 取込みが成功しました。" + vbCrLf +
                            " @件".Replace("@", derivaryCount.Serial_MachCount) + vbCrLf


                ''実行管理情報
                msg = msg & "【Paymentｼｰﾄ：実行支援情報】" + vbCrLf +
                            " 取込みが成功しました。" + vbCrLf +
                            " @件".Replace("@", derivaryCount.ACT_MachCount) + vbCrLf

                ''Topacs情報
                msg = msg & "【Paymentｼｰﾄ：Topacs情報】" + vbCrLf +
                            " 取込みが成功しました。" + vbCrLf +
                            " @件".Replace("@", derivaryCount.Topacs_MachCount) + vbCrLf

                ''末尾
                msg = msg + vbCrLf + Path.GetFileName(strPSFilePath) + vbCrLf + _
                            "に@行の更新ﾃﾞｰﾀを追加しました。".Replace("@", derivaryCount.InsertCount)


            Case MSG_CRITICAL
                '''' ケース：メッセージ区分が警告終了の場合、以下の処理を行う
                '''' 　条件：実ｼﾘｱﾙ情報件数判定
                '''' 　ケース：取込成功の場合、以下のメッセージを作成する
                '''' 　　【ｼﾘｱﾙｼｰﾄ：実ｼﾘｱﾙ情報】
                '''' 　　取込みが成功しました。
                '''' 　　xx件
                '''' 　ケース：未取込データがある場合、以下のメッセージを作成する
                '''' 　　【ｼﾘｱﾙｼｰﾄ：実ｼﾘｱﾙ情報】
                '''' 　　未取込のデータがあります。
                '''' 　　正常　 ：xx件
                '''' 　　異常　 ：xx件
                '''' 　　対象外 ：xx件
                ''実ｼﾘｱﾙ情報
                If derivaryCount.Serial_UnMachCount = 0 And
                derivaryCount.Serial_DataErrCount = 0 Then

                    ''取込成功
                    msg = msg & "【ｼﾘｱﾙｼｰﾄ：実ｼﾘｱﾙ情報】" + vbCrLf +
                                " 取込みが成功しました。" + vbCrLf +
                                " @件".Replace("@", derivaryCount.Serial_MachCount) + vbCrLf
                Else

                    ''未取込のデータあり
                    msg = msg & "【ｼﾘｱﾙｼｰﾄ：実ｼﾘｱﾙ情報】" + vbCrLf +
                                " 未取込のデータがあります。" + vbCrLf +
                                " 正常　 ：@件".Replace("@", derivaryCount.Serial_MachCount) + vbCrLf +
                                " 異常　 ：@件".Replace("@", derivaryCount.Serial_UnMachCount) + vbCrLf +
                                " 対象外 ：@件".Replace("@", derivaryCount.Serial_DataErrCount) + vbCrLf

                End If

                '''' 　条件：実行管理件数判定
                '''' 　ケース：取込成功の場合、以下のメッセージを作成する
                '''' 　　【Paymentｼｰﾄ：実行管理情報】
                '''' 　　取込みが成功しました。
                '''' 　　xx件
                '''' 　ケース：未取込データがある場合、以下のメッセージを作成する
                '''' 　　【Paymentｼｰﾄ：実行管理情報】
                '''' 　　未取込のデータがあります。
                '''' 　　正常　 ：xx件
                '''' 　　異常　 ：xx件
                '''' 　　対象外 ：xx件
                ''実行管理
                If derivaryCount.ACT_UnMachCount = 0 And
                derivaryCount.ACT_DataErrCount = 0 Then

                    ''取込成功
                    msg = msg & "【Paymentｼｰﾄ：実行支援情報】" + vbCrLf +
                                " 取込みが成功しました。" + vbCrLf +
                                " @件".Replace("@", derivaryCount.ACT_MachCount) + vbCrLf
                Else

                    ''未取込のデータあり
                    msg = msg & "【Paymentｼｰﾄ：実行支援情報】" + vbCrLf +
                                " 未取込のデータがあります。" + vbCrLf +
                                " 正常　 ：@件".Replace("@", derivaryCount.ACT_MachCount) + vbCrLf +
                                " 異常　 ：@件".Replace("@", derivaryCount.ACT_UnMachCount) + vbCrLf +
                                " 対象外 ：@件".Replace("@", derivaryCount.ACT_DataErrCount) + vbCrLf

                End If

                '''' 　条件：Topacs情報件数判定
                '''' 　ケース：取込成功の場合、以下のメッセージを作成する
                '''' 　　【Paymentｼｰﾄ：Topacs情報】
                '''' 　　取込みが成功しました。
                '''' 　　xx件
                '''' 　ケース：未取込データがある場合、以下のメッセージを作成する
                '''' 　　【Paymentｼｰﾄ：Topacs情報】
                '''' 　　未取込のデータがあります。
                '''' 　　正常　 ：xx件
                '''' 　　異常　 ：xx件
                '''' 　　対象外 ：xx件
                ''Topacs情報
                If derivaryCount.Topacs_UnMachCount = 0 And
                derivaryCount.Topacs_DataErrCount = 0 Then

                    ''取込成功
                    msg = msg & "【Paymentｼｰﾄ：Topacs情報】" + vbCrLf +
                                " 取込みが成功しました。" + vbCrLf +
                                " @件".Replace("@", derivaryCount.Topacs_MachCount) + vbCrLf
                Else

                    ''未取込のデータあり
                    msg = msg & "【Paymentｼｰﾄ：Topacs情報】" + vbCrLf +
                                " 未取込のデータがあります。" + vbCrLf +
                                " 正常　 ：@件".Replace("@", derivaryCount.Topacs_MachCount) + vbCrLf +
                                " 異常　 ：@件".Replace("@", derivaryCount.Topacs_UnMachCount) + vbCrLf +
                                " 対象外 ：@件".Replace("@", derivaryCount.Topacs_DataErrCount) + vbCrLf

                End If

                '''' 　処理：末尾にメッセージを追加
                '''' 　　ファイル名
                '''' 　　にxx行の更新ﾃﾞｰﾀを追加しました。
                '''' 　　取込出来なかったﾃﾞｰﾀが存在します。
                '''' 　　ﾃﾞﾘﾊﾞﾘ管理ﾌｧｲﾙの取込ｴﾗｰLOG列を参照して下さい。
                ''末尾
                msg = msg + vbCrLf + Path.GetFileName(strPSFilePath) + vbCrLf + _
                            "に@行の更新ﾃﾞｰﾀを追加しました。".Replace("@", derivaryCount.InsertCount) + vbCrLf + _
                            "取込出来なかったﾃﾞｰﾀが存在します。" + vbCrLf + _
                            "ﾃﾞﾘﾊﾞﾘ管理ﾌｧｲﾙの取込ｴﾗｰLOG列を参照して下さい。"

            Case MSG_UPDFLGERR
                '''' ケース：メッセージ区分が更新エラー終了の場合、以下のメッセージを作成する
                '''' 　PaymentSheetに更新FLG=U、又はﾛｯｸFLG=Pのデータが存在するため処理を終了します。
                msg = "PaymentSheetに更新FLG=U、又はﾛｯｸFLG=Pのデータが存在するため処理を終了します。"

            Case MSG_SHEETCHKERR
                '''' ケース：メッセージ区分がチェックエラー終了の場合、以下のメッセージを作成する
                '''' 　支援ファイルのｼﾘｱﾙ、又はPaymentｼｰﾄの「チェック済み項目」に「チェック結果：OK」以外の値がセットされています。
                '''' 　支援ファイルで「入力ﾁｪｯｸ」ﾎﾞﾀﾝを押下し、入力ﾁｪｯｸを完了してください。
                msg = "支援ファイルのｼﾘｱﾙ、又はPaymentｼｰﾄの「チェック済み項目」に「チェック結果：OK」以外の値がセットされています。" & vbCrLf & _
                      "支援ファイルで「入力ﾁｪｯｸ」ﾎﾞﾀﾝを押下し、入力ﾁｪｯｸを完了してください。"

        End Select

    End Sub

    ''' <summary>
    ''' 申請ファイルをリネームする
    ''' </summary>
    ''' <param name="DeriFile">リネームするファイル名</param>
    ''' <param name="strRetFile">変更後ファイル名</param>
    ''' <remarks></remarks>
    'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
    Public Sub ReNameBKFile(ByVal DeriFile As String, Optional ByRef strRetFile As String = "")
        'Public Sub ReNameBKFile(ByVal DeriFile As String)
        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

        Try

            '''' 処理：リネーム対象のフォルダとファイル名
            Dim chkDir As String
            Dim chkFile As String
            chkDir = System.IO.Path.GetDirectoryName(DeriFile)
            chkFile = System.IO.Path.GetFileNameWithoutExtension(DeriFile)

            '''' 処理：BKﾌｧｲﾙのMaxIndexを取得する。
            Dim bkFileList() As String
            Dim bkFile As String
            Dim maxBKIndex As String
            bkFileList = System.IO.Directory.GetFiles(chkDir, "BK_*" & chkFile & "*")
            Call Array.Sort(bkFileList)
            If bkFileList.Length = 0 Then
                maxBKIndex = "BK_000"
            Else
                bkFile = System.IO.Path.GetFileName(bkFileList(UBound(bkFileList)))
                If IsNumeric(bkFile.Substring(3, 3)) Then
                    maxBKIndex = "BK" & "_" & (CInt(bkFile.Substring(3, 3)) + 1).ToString("000")
                End If
            End If

            '''' 処理：BKﾌｧｲﾙにリネームする。
            Dim cngFileList() As String
            Dim cngFile As String
            cngFileList = System.IO.Directory.GetFiles(chkDir, chkFile & "*")
            For Each cngFile In cngFileList
                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                strRetFile = System.IO.Path.GetDirectoryName(cngFile) & "\" & maxBKIndex & System.IO.Path.GetFileName(cngFile)
                Call Rename(cngFile,strRetFile)
                'Call Rename(cngFile,
                '            System.IO.Path.GetDirectoryName(cngFile) & "\" & maxBKIndex & System.IO.Path.GetFileName(cngFile))
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            Next

        Catch ex As Exception
            Throw ex

        End Try

    End Sub

#End Region

#End Region

#Region "Private Method"

#Region "実行管理関連"

    ''' <summary>
    ''' 実行管理作成
    ''' </summary>
    ''' <param name="strOutputExcelPath"></param>
    ''' <param name="con"></param>
    ''' <param name="xlApp"></param>
    ''' <param name="xlBooks"></param>
    ''' <param name="intContractStart"></param>
    ''' <param name="intContractEnd"></param>
    ''' <param name="intPaymentStart"></param>
    ''' <param name="intPaymentPeriod"></param>
    ''' <param name="blnOutputSheet"></param>
    ''' <param name="strErrMsg"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
    Private Function ActOutputMain(ByVal strOutputExcelPath As String,
                                   ByVal con As OleDbConnection,
                                   ByRef xlApp As Excel.Application,
                                   ByRef xlBooks As Excel.Workbooks,
                                   ByVal intContractStart As Integer,
                                   ByVal intContractEnd As Integer,
                                   ByVal intPaymentStart As Integer,
                                   ByVal intPaymentPeriod As Integer,
                                   ByVal blnOutputSheet() As Boolean,
                                   ByRef strFileActAll As String,
                                   ByRef strFileActOffer As String,
                                   ByRef strErrMsg As String) As Boolean
        'Private Function ActOutputMain(ByVal strOutputExcelPath As String,
        '                               ByVal con As OleDbConnection,
        '                               ByRef xlApp As Excel.Application,
        '                               ByRef xlBooks As Excel.Workbooks,
        '                               ByVal intContractStart As Integer,
        '                               ByVal intContractEnd As Integer,
        '                               ByVal intPaymentStart As Integer,
        '                               ByVal intPaymentPeriod As Integer,
        '                               ByVal blnOutputSheet() As Boolean,
        '                               ByRef strErrMsg As String) As Boolean
        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

        Dim blnRet As Boolean
        Dim ofm As New OioFileManage
        'Req.1702 実行支援シート追加 2018/12 Str
        'Dim intOutputCnt(0 To 3) As Integer
        Dim intOutputCnt(0 To 4) As Integer
        'Req.1702 実行支援シート追加 2018/12 End
        Dim dtNowDate As Date = System.DateTime.Now
        Dim arDelId As New ArrayList
        Dim arExemptId As New ArrayList
        Dim arOutputId1 As New ArrayList
        Dim strSQL As String
        'Req.1702 実行支援シート追加 2018/12 Str
        Dim arExemptId2 As New ArrayList
        'Dim strSheets() As String = {STR_SHEET_NAME_ACT_1,
        '                             STR_SHEET_NAME_ACT_2,
        '                             STR_SHEET_NAME_ACT_3,
        '                             STR_SHEET_NAME_ACT_4}
        Dim strSheets() As String = {STR_SHEET_NAME_ACT_1,
                                     STR_SHEET_NAME_ACT_2,
                                     STR_SHEET_NAME_ACT_3,
                                     STR_SHEET_NAME_ACT_4,
                                     STR_SHEET_NAME_ACT_5}
        'Req.1702 実行支援シート追加 2018/12 End

        'Excelオブジェクト
        Dim xlBook As Excel.Workbook = Nothing
        Dim xlSheets As Excel.Sheets = Nothing
        Dim xlSheet As Excel.Worksheet = Nothing
        Dim xlCell As Excel.Range = Nothing
        Dim xlRange As Excel.Range = Nothing

        ActOutputMain = False

        Try
            '----------------------------
            '削除済みIDを取得
            '----------------------------
            '''' 処理：削除済みIDを取得
            Console.WriteLine(Now.ToString("yyyy/MM/dd HH:mm:ss") & ",削除済みIDを取得開始")
            blnRet = GeOutputtDuplicateId(con, arDelId, strErrMsg)
            If blnRet = False Then
                Exit Function
            End If
            Console.WriteLine(Now.ToString("yyyy/MM/dd HH:mm:ss") & ",削除済みIDを取得終了")

            '----------------------------
            '件数取得
            '----------------------------
            '''' 処理：以下のシートの出力件数を取得する
            '''' 　①要回答未実行（過去－２ヶ月）
            blnRet = GetActOutputCnt(con,
                                     dtNowDate,
                                     CD_ACT_OUTPUT1,
                                     intOutputCnt(CD_ACT_OUTPUT1),
                                     arDelId,
                                     arExemptId,
                                     strErrMsg)
            If blnRet = False Then
                Exit Function
            End If
            '''' 　②任意回答未実行（3ヶ月以降）
            blnRet = GetActOutputCnt2(con,
                                      dtNowDate,
                                      intOutputCnt(CD_ACT_OUTPUT2),
                                      arDelId,
                                      strErrMsg)
            If blnRet = False Then
                Exit Function
            End If
            '''' 　③要確認EOS価格改定
            blnRet = GetActOutputCnt(con,
                                     dtNowDate,
                                     CD_ACT_OUTPUT3,
                                     intOutputCnt(CD_ACT_OUTPUT3),
                                     arDelId,
                                     arExemptId,
                                     strErrMsg)
            If blnRet = False Then
                Exit Function
            End If
            '''' 　④参考未発注（過去－２ヶ月）
            blnRet = GetActOutputCnt(con,
                                     dtNowDate,
                                     CD_ACT_OUTPUT4,
                                     intOutputCnt(CD_ACT_OUTPUT4),
                                     arDelId,
                                     arExemptId,
                                     strErrMsg)
            If blnRet = False Then
                Exit Function
            End If
            'Req.1702 実行支援シート追加 2018/12 Str
            '''' 　⑤要確認保守廃止
            blnRet = GetActOutputCnt(con,
                                     dtNowDate,
                                     CD_ACT_OUTPUT5,
                                     intOutputCnt(CD_ACT_OUTPUT5),
                                     arDelId,
                                     arExemptId2,
                                     strErrMsg)
            If blnRet = False Then
                Exit Function
            End If
            'Req.1702 実行支援シート追加 2018/12 End

            '''' 条件：各シートの出力件数判定
            '''' ケース：件数（データ）が１シート（１件以上）でもある場合、以下の処理を行う
            'Req.1702 実行支援シート追加 2018/12 Str
            'If intOutputCnt(CD_ACT_OUTPUT1) > 0 Or intOutputCnt(CD_ACT_OUTPUT2) > 0 Or intOutputCnt(CD_ACT_OUTPUT3) > 0 Or intOutputCnt(CD_ACT_OUTPUT4) Then
            If intOutputCnt(CD_ACT_OUTPUT1) > 0 Or _
               intOutputCnt(CD_ACT_OUTPUT2) > 0 Or _
               intOutputCnt(CD_ACT_OUTPUT3) > 0 Or _
               intOutputCnt(CD_ACT_OUTPUT4) > 0 Or _
               intOutputCnt(CD_ACT_OUTPUT5) > 0 Then
                'Req.1702 実行支援シート追加 2018/12 End

                '----------------------------
                'テンプレートをコピー
                '----------------------------
                '''' 　処理：　Templateをコピーする
                Dim strSrcPath As String = FileManager.GetLocalFolderPath(CommonConstant.FOLDERNAME_TEMPLATE)
                Dim strSrcFileName As String = "実行支援Sample.xlsm"
                Dim strDestPath As String = ""
                strDestPath = strOutputExcelPath
                Dim strDestFileName As String = "実行支援_" & CommonVariable.CPNO & "(" & CommonVariable.CUSTOMERNAME & ")_" & Now.ToString("yyyyMMdd_HHmm") & "_全.xlsm"
                File.Copy(strSrcPath & strSrcFileName, strDestPath & strDestFileName, True)

                '----------------------------
                'EXCEL OPEN
                '----------------------------
                '''' 　処理：ExcelｵﾌﾞｼﾞｪｸﾄOPEN
                xlBook = xlBooks.Open(strDestPath & strDestFileName)
                xlSheets = xlBook.Worksheets
                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                strFileActAll = strDestPath & strDestFileName
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

                '----------------------------
                '契約開始・終了出力
                '----------------------------
                '''' 　処理：①～④のシートにA1：契約開始、A2：契約終了を出力
                For intCnt As Integer = 0 To strSheets.Length - 1
                    xlSheet = xlSheets.Item(strSheets(intCnt))
                    '契約開始
                    xlCell = xlSheet.Cells
                    xlRange = DirectCast(xlCell(1, 1), Excel.Range)
                    xlRange.Value = intContractStart
                    ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                    ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                    '契約終了
                    xlCell = xlSheet.Cells
                    xlRange = DirectCast(xlCell(1, 2), Excel.Range)
                    xlRange.Value = intContractEnd
                    ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                    ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                    'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                    ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
                    'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                Next
                ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

                '----------------------------
                'データ出力
                '----------------------------
                '''' 　処理：①要回答未実行（過去－２ヶ月）のデータ出力
                '''' 　　　　ActOutputData()を呼び出す
                xlSheet = xlSheets.Item(STR_SHEET_NAME_ACT_1)
                blnRet = ActOutputData(con,
                                       CD_ACT_OUTPUT1,
                                       intOutputCnt(CD_ACT_OUTPUT1),
                                       arDelId,
                                       arExemptId,
                                       intPaymentStart,
                                       intPaymentPeriod,
                                       arOutputId1,
                                       xlSheet,
                                       strErrMsg)
                '''' 　条件：処理結果判定
                '''' 　ケース：処理結果が異常の場合、処理を中断する
                If blnRet = False Then
                    Exit Function
                End If
                ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
                '''' 　処理：②任意回答未実行（3ヶ月以降）のデータ出力
                '''' 　　　ActOutputData()を呼び出す
                xlSheet = xlSheets.Item(STR_SHEET_NAME_ACT_2)
                blnRet = ActOutputData(con,
                                       CD_ACT_OUTPUT2,
                                       intOutputCnt(CD_ACT_OUTPUT2),
                                       arDelId,
                                       arExemptId,
                                       intPaymentStart,
                                       intPaymentPeriod,
                                       arOutputId1,
                                       xlSheet,
                                       strErrMsg)
                '''' 　条件：処理結果判定
                '''' 　ケース：処理結果が異常の場合、処理を中断する
                If blnRet = False Then
                    Exit Function
                End If
                ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
                '③要確認EOS価格改定
                '''' 　処理：③要確認EOS価格改定のデータ出力
                '''' 　　　ActOutputData()を呼び出す
                xlSheet = xlSheets.Item(STR_SHEET_NAME_ACT_3)
                blnRet = ActOutputData(con,
                                       CD_ACT_OUTPUT3,
                                       intOutputCnt(CD_ACT_OUTPUT3),
                                       arDelId,
                                       arExemptId,
                                       intPaymentStart,
                                       intPaymentPeriod,
                                       arOutputId1,
                                       xlSheet,
                                       strErrMsg)
                '''' 　条件：処理結果判定
                '''' 　ケース：処理結果が異常の場合、処理を中断する
                If blnRet = False Then
                    Exit Function
                End If
                ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
                '''' 　処理：④参考未発注（過去－２ヶ月）のデータ出力
                '''' 　　　ActOutputData()を呼び出す
                xlSheet = xlSheets.Item(STR_SHEET_NAME_ACT_4)
                blnRet = ActOutputData(con,
                                       CD_ACT_OUTPUT4,
                                       intOutputCnt(CD_ACT_OUTPUT4),
                                       arDelId,
                                       arExemptId,
                                       intPaymentStart,
                                       intPaymentPeriod,
                                       arOutputId1,
                                       xlSheet,
                                       strErrMsg)
                '''' 　条件：処理結果判定
                '''' 　ケース：処理結果が異常の場合、処理を中断する
                If blnRet = False Then
                    Exit Function
                End If
                ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

                'Req.1702 実行支援シート追加 2018/12 Str
                '''' 　処理：⑤要確認保守廃止のデータ出力
                '''' 　　　ActOutputData()を呼び出す
                xlSheet = xlSheets.Item(STR_SHEET_NAME_ACT_5)
                blnRet = ActOutputData(con,
                                       CD_ACT_OUTPUT5,
                                       intOutputCnt(CD_ACT_OUTPUT5),
                                       arDelId,
                                       arExemptId2,
                                       intPaymentStart,
                                       intPaymentPeriod,
                                       arOutputId1,
                                       xlSheet,
                                       strErrMsg)
                If blnRet = False Then
                    Exit Function
                End If
                ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
                'Req.1702 実行支援シート追加 2018/12 End

                '----------------------------
                '年度情報
                '----------------------------
                '''' 　処理：①～④のシートに年度を出力
                For intCnt As Integer = 0 To strSheets.Length - 1
                    xlSheet = xlSheets.Item(strSheets(intCnt))
                    xlRange = xlSheet.Range(RANGE_PAYMENT_START)
                    xlRange.Value = intPaymentStart.ToString
                    ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                    'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                    'ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                    'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                    ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
                Next

                '''' 　処理：①～④シートのカーソル位置を「C1」にセット
                For intCnt As Integer = xlSheets.Count To 1 Step -1
                    xlSheet = xlSheets.Item(intCnt)
                    If xlSheet.Name <> STR_SHEET_LIST Then
                        xlSheet.Activate()
                        xlCell = xlSheet.Range("C1")
                        xlCell.Select()
                        ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                    End If
                    ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
                Next

                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

                '''' 　判定：実行管理出力有無判定
                '''' 　ケース：出力有の場合、シート保護処理(ExcelSheetProtect())を呼び出す
                If strDestFileName <> "" Then
                    Call ExcelSheetProtect(xlApp, xlBook.Name)
                End If

                '''' 　処理：Bookの保存
                xlBook.Save()

                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                'ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                If IsNothing(xlBook) = False Then
                    xlBook.Close(False)
                End If
                ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)

                '--------------------------------------
                '連携ファイル作成
                '--------------------------------------
                '''' 処理：連携ファイル作成処理(CreateActCooperation())を呼び出す
                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                blnRet = CreateActCooperation(xlBooks,
                                              strDestPath,
                                              strDestFileName,
                                              blnOutputSheet,
                                              strFileActOffer,
                                              strErrMsg)
                'blnRet = CreateActCooperation(xlBooks,
                '                              strDestPath,
                '                              strDestFileName,
                '                              blnOutputSheet,
                '                              strErrMsg)
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                If blnRet = False Then
                    Exit Function
                End If
            Else
                '''' ケース：上記以外の場合、エラーメッセージを作成
                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                strErrMsg = strErrMsg & "出力データ無"
                'strErrMsg = strErrMsg & vbCrLf & "出力データ無"
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            End If

            ActOutputMain = True

        Catch ex As Exception
            strErrMsg = ex.Message.ToString

        Finally
            ''エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBook) = False Then
                xlBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)

            ''ガベージコレクトの起動
            GC.Collect()

        End Try

    End Function

    ''' <summary>
    ''' 出力件数取得
    ''' </summary>
    ''' <param name="con">MDBのコネクション</param>
    ''' <param name="dtNowDate">作成日時</param>
    ''' <param name="intOutputCd"></param>
    ''' <param name="intOutputCnt"></param>
    ''' <param name="arDelId">削除ﾃﾞｰﾀID</param>
    ''' <param name="arExemptId">対象外ID</param>
    ''' <param name="strErrMsg">エラーメッセージ</param>
    ''' <returns>True:正常、False:異常</returns>
    ''' <remarks>削除行を除いた件数を取得する</remarks>
    Private Function GetActOutputCnt(ByVal con As OleDbConnection,
                                     ByVal dtNowDate As Date,
                                     ByVal intOutputCd As Integer,
                                     ByRef intOutputCnt As Integer,
                                     ByVal arDelId As ArrayList,
                                     ByRef arExemptId As ArrayList,
                                     ByRef strErrMsg As String) As Boolean

        Dim cmdCount As New OleDbCommand
        Dim blnRet As Boolean
        Dim drPt1Pt2 As OleDbDataReader
        Dim strId As String
        Dim strDate As String

        GetActOutputCnt = False
        intOutputCnt = 0

        Try
            cmdCount.Connection = con

            '''' 処理：削除済み外と請求期間_終了年月が作成日の未来日の件数を取得
            '''' 　①SQL文作成(MakeExcelWorkManagementCountSQL())
            '''' 　②SQL文実行
            '''' 　③データが無くなるまで繰り返す（削除済みデータ外のIDを取得）
            cmdCount.CommandText = MakeExcelWorkManagementCountSQL(dtNowDate, intOutputCd)
            Debug.Print(cmdCount.CommandText)
            drPt1Pt2 = cmdCount.ExecuteReader
            While drPt1Pt2.Read = True
                strId = GetDbData(drPt1Pt2, "ID")
                If arDelId.Contains(strId) = True Then
                    Continue While
                End If
                If intOutputCd = CD_ACT_OUTPUT3 Then
                    strDate = GetDbData(drPt1Pt2, "PAY_END_DATE")
                    If IsDate(strDate) = True Then
                        If Date.Parse(dtNowDate.ToString("yyyy/MM") & "/01") > Date.Parse(strDate) Then
                            arExemptId.Add(strId)
                            Continue While
                        End If
                        '作成日時より未来日にPaymentがあるか判定
                        blnRet = GetFuturePaymentZero(con, strId, dtNowDate)
                        If blnRet = True Then
                            arExemptId.Add(strId)
                            Continue While
                        End If
                    End If
                End If

                'Req.1702 実行支援シート追加 2018/12 Str
                If intOutputCd = CD_ACT_OUTPUT5 Then
                    strDate = GetDbData(drPt1Pt2, "WD_DATE")
                    If IsDate(strDate) = False Then
                        '廃止発表日が日付でない
                        arExemptId.Add(strId)
                        Continue While
                    End If

                    Select Case GetDbData(drPt1Pt2, "PATTERN_CD")
                        Case "15", "16", "17", "21"
                        Case Else
                            '対象外PTNCD
                            arExemptId.Add(strId)
                            Continue While
                    End Select

                    strDate = GetDbData(drPt1Pt2, "PROD_ITEM12")
                    If IsDate(strDate) = False Then
                        'サービス終了日が日付でない
                        arExemptId.Add(strId)
                        Continue While
                    End If

                    If GetDbData(drPt1Pt2, "PROD_ITEM08") = "" Then
                        '終了廃止発表日 > サービス期間終了
                        If CDate(GetDbData(drPt1Pt2, "WD_DATE")) > CDate(GetDbData(drPt1Pt2, "PROD_ITEM12")) Then
                            arExemptId.Add(strId)
                            Continue While
                        End If

                    Else
                        'サービス期間終了が直近６ヶ月(現在日付＋６ヶ月)外
                        If Date.Parse(dtNowDate.ToString("yyyy/MM") & "/01").AddMonths(6) < Date.Parse(strDate) Then
                            arExemptId.Add(strId)
                            Continue While
                        End If

                    End If
                End If
                'Req.1702 実行支援シート追加 2018/12 End

                intOutputCnt = intOutputCnt + 1
            End While

            GetActOutputCnt = True

        Catch ex As Exception
            strErrMsg = ex.Message.ToString

        Finally
            cmdCount.Dispose()

        End Try

    End Function

    ''' <summary>
    ''' 出力件数取得
    ''' </summary>
    ''' <param name="con">DBのコネクション</param>
    ''' <param name="dtNowDate">現在日時</param>
    ''' <param name="intOutputCnt">出力件数</param>
    ''' <param name="arDelId">削除ﾃﾞｰﾀID</param>
    ''' <param name="strErrMsg">エラーメッセージ</param>
    ''' <returns></returns>
    ''' <remarks>削除行、①要回答未実行（過去－２ヶ月）で出力した行を除いた件数を取得する</remarks>
    Private Function GetActOutputCnt2(ByVal con As OleDbConnection,
                                     ByVal dtNowDate As Date,
                                     ByRef intOutputCnt As Integer,
                                     ByVal arDelId As ArrayList,
                                     ByRef strErrMsg As String) As Boolean

        Dim cmdPt1Pt2 As New OleDbCommand
        Dim drPt1Pt2 As OleDbDataReader
        Dim blnRet As Boolean
        Dim arOutputId1 As New ArrayList
        Dim arOutputId2 As New ArrayList
        Dim strId As String

        GetActOutputCnt2 = False

        Try
            cmdPt1Pt2.Connection = con
            '''' 処理：①要回答未実行（過去－２ヶ月）のID取得
            '''' 　①SQL文作成(MakeExcelWorkManagementSQL())
            '''' 　②SQL文実行
            '''' 　③データが無くなるまで繰り返す
            cmdPt1Pt2.CommandText = MakeExcelWorkManagementSQL(dtNowDate, CD_ACT_OUTPUT1)
            drPt1Pt2 = cmdPt1Pt2.ExecuteReader()
            While drPt1Pt2.Read = True
                arOutputId1.Add(GetDbData(drPt1Pt2, "ID"))
            End While
            drPt1Pt2.Close()

            intOutputCnt = arOutputId1.Count

            '''' 処理：②任意回答未実行（3ヶ月以降）のID取得
            '''' 　①SQL文作成(MakeExcelWorkManagementSQL())
            '''' 　②SQL文実行
            '''' 　③データが無くなるまで繰り返す（削除済みデータ外のIDを取得）
            cmdPt1Pt2.CommandText = MakeExcelWorkManagementSQL(dtNowDate, CD_ACT_OUTPUT2)
            drPt1Pt2 = cmdPt1Pt2.ExecuteReader()
            While drPt1Pt2.Read = True
                strId = GetDbData(drPt1Pt2, "ID")
                If arOutputId1.Contains(strId) = True Or arDelId.Contains(strId) = True Then
                    Continue While
                End If
                arOutputId2.Add(strId)
            End While
            drPt1Pt2.Close()

            intOutputCnt = arOutputId2.Count

            GetActOutputCnt2 = True

        Catch ex As Exception
            strErrMsg = ex.Message.ToString

        Finally
            cmdPt1Pt2.Dispose()

        End Try

    End Function

    ''' <summary>
    ''' データ出力
    ''' </summary>
    ''' <param name="con"></param>
    ''' <param name="intOutputCd"></param>
    ''' <param name="intOutputCnt"></param>
    ''' <param name="arDelId">削除ﾃﾞｰﾀID</param>
    ''' <param name="arExemptId">対象外ﾃﾞｰﾀID</param>
    ''' <param name="intPaymentStart"></param>
    ''' <param name="intPaymentPeriod"></param>
    ''' <param name="arOutputId1"></param>
    ''' <param name="xlSheet"></param>
    ''' <param name="strErrMsg"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ActOutputData(ByVal con As OleDbConnection,
                                   ByVal intOutputCd As Integer,
                                   ByVal intOutputCnt As Integer,
                                   ByVal arDelId As ArrayList,
                                   ByVal arExemptId As ArrayList,
                                   ByVal intPaymentStart As Integer,
                                   ByVal intPaymentPeriod As Integer,
                                   ByRef arOutputId1 As ArrayList,
                                   ByRef xlSheet As Excel.Worksheet,
                                   ByRef strErrMsg As String) As Boolean

        Dim strSQL As String
        Dim cmdCount As New OleDbCommand
        Dim lngRecordCnt As Long = intOutputCnt
        Dim cmdPt1Pt2 As New OleDbCommand
        Dim drPt1Pt2 As OleDbDataReader
        Dim cmdPt3 As New OleDbCommand
        Dim drPt3 As OleDbDataReader
        Dim strOutData As String
        Dim strItemValue As String
        Dim strOutYear As String
        Dim strOutMonth As String
        Dim intYearCnt As Integer
        Dim intFieldCnt As Integer
        Dim strRange As String
        Dim ofm As New OioFileManage
        Dim dtNowDate As Date = System.DateTime.Now
        Dim strMsg As String
        Dim strId As String
        'Req.1702 実行支援シート追加 2018/12 Str
        'Dim strCompleteMsg() As String = {"①要回答未実行（過去－２ヶ月）  ",
        '                                  "②任意回答未実行（３ヶ月以降）  ",
        '                                  "③要確認EOS価格改定             ",
        '                                  "④参考未発注（過去－２ヶ月）     "}
        Dim strCompleteMsg() As String = {"①要回答未実行（過去－２ヶ月）  ",
                                          "②任意回答未実行（３ヶ月以降）  ",
                                          "③要確認EOS価格改定             ",
                                          "④参考未発注（過去－２ヶ月）     ",
                                          "⑤要確認保守廃止                 "}
        'Req.1702 実行支援シート追加 2018/12 End
        Dim strPastPriceTotal As String
        Dim strYear As String
        Dim strPathCsv As String
        Dim strFileNameCsv As String
        Dim strWork As String
        'Excelオブジェクト
        Dim xlCell As Excel.Range = Nothing
        Dim xlRange As Excel.Range = Nothing
        Dim xlBorder As Excel.Border = Nothing

        ActOutputData = False

        Try
            '----------------------------
            '枠だけコピー
            '----------------------------
            '''' 処理：罫線作成
            '''' 　①出力件数から５００件ごとに８行目のTemplate行をコピーする
            Const DIVISION_LINES As Long = 1000
            Dim lngSho As Long = lngRecordCnt \ DIVISION_LINES
            Dim lngAmari As Long = lngRecordCnt Mod DIVISION_LINES
            Dim lngCnt As Long

            Const EXCEL_ROW_START As Integer = 8
            For lngCnt = 1 To lngSho
                xlCell = xlSheet.Range("8:8")
                xlCell.Copy()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                strRange = (EXCEL_ROW_START + (lngCnt - 1) * DIVISION_LINES).ToString() & ":" & (EXCEL_ROW_START + lngCnt * DIVISION_LINES - 1).ToString()
                Debug.Print("枠コピー１：" & strRange)
                xlCell = xlSheet.Range(strRange)
                xlCell.Insert()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            Next
            If lngAmari > 0 Then
                xlCell = xlSheet.Range("8:8")
                xlCell.Copy()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                strRange = (EXCEL_ROW_START + (lngSho * DIVISION_LINES)).ToString() & ":" & (EXCEL_ROW_START + (lngSho * DIVISION_LINES + lngAmari) - 1).ToString()
                Debug.Print("枠コピー２：" & strRange)
                xlCell = xlSheet.Range(strRange)
                xlCell.Insert()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            End If
            '''' 処理：最終行削除（空白行）
            xlCell = xlSheet.Range((lngRecordCnt + EXCEL_ROW_START).ToString & ":" & (lngRecordCnt + EXCEL_ROW_START).ToString)
            xlCell.Delete()
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            '----------------------------
            'データ取得
            '----------------------------
            '''' 処理：PaymentTBL1、PaymentTBL2のデータ取得
            '''' 　①SQL文作成(MakeExcelWorkManagementSQL())
            '''' 　②SQL文実行
            cmdPt1Pt2.Connection = con
            cmdPt1Pt2.CommandText = MakeExcelWorkManagementSQL(dtNowDate, intOutputCd)
            Debug.Print(cmdPt1Pt2.CommandText)
            drPt1Pt2 = cmdPt1Pt2.ExecuteReader()

            cmdPt3.Connection = con
            strOutData = ""

            ''''   処理：中間ファイル作成
            strPathCsv = Path.GetFullPath("../log/")
            strFileNameCsv = strPathCsv & "WorkCsv_ActionData_" & Now.ToString("yyyyMMdd_HHmmss") & ".csv"
            Using sw As New StreamWriter(strFileNameCsv, False, System.Text.Encoding.Default)

                '''' 繰返し_開始：PaymentTBL1、PaymentTBL2のデータが無くなるまで
                While drPt1Pt2.Read = True
                    '''' 　条件：削除済みデータ判定
                    '''' 　ケース：削除済みデータの場合、次のデータへ
                    strId = GetDbData(drPt1Pt2, "ID")
                    If arDelId.Contains(strId) = True Then
                        Continue While
                    End If

                    '''' 　条件：各シート処理判定
                    '''' 　　※①要回答未実行（過去－２ヶ月）ｼｰﾄの場合、IDを保管
                    '''' 　　※②任意回答未実行（3ヶ月以降）ｼｰﾄ場合、①要回答未実行（過去－２ヶ月）ｼｰﾄで出力したデータを出力しない
                    '''' 　　※③要確認EOS価格改定ｼｰﾄの場合、対象外データであれば出力しない
                    Select Case intOutputCd
                        Case CD_ACT_OUTPUT1
                            arOutputId1.Add(strId)
                        Case CD_ACT_OUTPUT2
                            If arOutputId1.Contains(strId) = True Then
                                Continue While
                            End If
                            'Req.1702 実行支援シート追加 2018/12 Str
                            'Case CD_ACT_OUTPUT3
                        Case CD_ACT_OUTPUT3, CD_ACT_OUTPUT5
                            'Req.1702 実行支援シート追加 2018/12 End
                            If arExemptId.Contains(strId) = True Then
                                Continue While
                            End If
                    End Select

                    '----------------------------
                    '年額月額展開以外の項目
                    '----------------------------
                    '''' 　処理：出力データ作成（年額月額展開以外の項目）
                    strItemValue = ""
                    For intFieldCnt = 0 To (drPt1Pt2.FieldCount - 1)
                        Select Case drPt1Pt2.GetName(intFieldCnt)
                            Case "ID"
                            Case "PAST_PRICE_TOTAL"
                                strPastPriceTotal = """" & GetDbData(drPt1Pt2, "PAST_PRICE_TOTAL") & ""","
                            Case Else
                                strWork = GetDbData(drPt1Pt2, drPt1Pt2.GetName(intFieldCnt))
                                strWork = strWork.Replace("""", """""")
                                strItemValue = strItemValue & """" & strWork & ""","
                        End Select
                    Next

                    '----------------------------
                    '年額月額展開取得
                    '----------------------------
                    '''' 　処理：出力データ作成（年額月額展開と展開金額の項目）
                    '''' 　　①PaymentTBL1、PaymentTBL2に該当するIDでPaymentTBL3を検索する
                    '''' 　　②年額展開、月額展開のデータを取得する
                    strSQL = "SELECT * FROM PaymentTBL3 WHERE ID='" & drPt1Pt2.Item("ID") & "' ORDER BY INT(IOC_YEAER)"
                    cmdPt3.CommandText = strSQL
                    drPt3 = cmdPt3.ExecuteReader()
                    strOutYear = ""
                    strOutMonth = ""
                    While drPt3.Read = True
                        strYear = GetDbData(drPt3, "IOC_YEAER")
                        '年額展開取得
                        strWork = GetDbData(drPt3, "IOC_YYYY")
                        strWork = strWork.Replace("""", """""")
                        strOutYear = strOutYear & """" & strWork & ""","
                        '月額展開取得
                        If Integer.Parse(strYear) < (intPaymentStart + intPaymentPeriod) Then
                            For intYearCnt = 1 To 12
                                strWork = GetDbData(drPt3, "IOC_" & intYearCnt.ToString("00"))
                                strWork = strWork.Replace("""", """""")
                                strOutMonth = strOutMonth & """" & strWork & ""","
                            Next
                        End If
                    End While
                    strOutData = strItemValue & strOutYear & strPastPriceTotal & strOutMonth
                    drPt3.Close()

                    sw.WriteLine(strOutData)
                End While
                '''' 繰返し_終了：
            End Using

            '''' 処理：Paymentに中間ﾌｧｲﾙを出力
            Dim intDataType(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12 - 1) As Integer
            Call ExcelWrite.SetExcelDataTypePayment(intDataType)
            strRange = "A" & EXCEL_ROW_START.ToString
            Call ExcelWrite.LoadCsvToExcel(strFileNameCsv, 1, xlSheet.Name, strRange, xlSheet, intDataType)

            '----------------------------
            '''' 処理：ヘッダ部分出力（作成日）
            '----------------------------
            '作成日
            xlCell = xlSheet.Cells
            xlRange = DirectCast(xlCell(2, 4), Excel.Range)
            xlRange.Value = dtNowDate.ToString("yyyy/MM/dd")
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            '----------------------------
            '''' 処理：Payment展開期間分列削除(ExcelWrite.CreatePaymentPeriod)
            '----------------------------
            Call ExcelWrite.CreatePaymentPeriod(xlSheet,
                                                ExcelWrite.chgExcelColumnIdxToChar(COL_ACT_PRICE_YEAR1_MONTH1),
                                                intPaymentPeriod)

            '----------------------------
            '''' 処理：完了ログメッセージ作成
            '----------------------------
            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            strErrMsg = strErrMsg & strCompleteMsg(intOutputCd) & lngRecordCnt.ToString & "件、"
            'strErrMsg = strErrMsg & vbCrLf & strCompleteMsg(intOutputCd) & lngRecordCnt.ToString & "件"
            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

            ActOutputData = True

        Catch ex As Exception
            strErrMsg = ex.Message.ToString & "(ActOutputData)"

        Finally
            'ﾜｰｸﾌｧｲﾙ削除
            Call ofm.DeleteWorkFile(strPathCsv)

            cmdPt3.Dispose()
            cmdCount.Dispose()
            cmdPt1Pt2.Dispose()

            '''' 処理：Excelｵﾌﾞｼﾞｪｸﾄの解放
            ExcelObjRelease.ReleaseExcelObj(xlBorder, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            ''ガベージコレクトの起動
            GC.Collect()
        End Try

    End Function

    ''' <summary>
    ''' 項目取得ＳＱＬ
    ''' </summary>
    ''' <param name="dtNow">作成日時</param>
    ''' <param name="intOutputCd"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function MakeExcelWorkManagementSQL(ByVal dtNow As Date, ByVal intOutputCd As Integer) As String

        Dim strSQL As String = ""

        '''' 処理：抽出項目設定
        strSQL = strSQL & "SELECT " & vbCrLf
        strSQL = strSQL & "PT1.ID," & vbCrLf
        strSQL = strSQL & "PT1.UPDATE_FLAG," & vbCrLf
        strSQL = strSQL & "PT1.LOCK_FLAG," & vbCrLf
        strSQL = strSQL & "PT1.VALID_FLAG," & vbCrLf
        strSQL = strSQL & "PT1.LINE_NO," & vbCrLf
        strSQL = strSQL & "PT1.FILE_NAME," & vbCrLf
        strSQL = strSQL & "PT1.FILE_NAME_SUFFIX," & vbCrLf
        strSQL = strSQL & "PT1.FILE_NAME_SUFFIX_INTR," & vbCrLf
        strSQL = strSQL & "PT1.CONTRACT," & vbCrLf
        strSQL = strSQL & "PT1.PROJ_ID," & vbCrLf
        strSQL = strSQL & "PT1.CONTRACT_SEQ," & vbCrLf
        strSQL = strSQL & "PT1.NEW_EXIST," & vbCrLf
        strSQL = strSQL & "PT1.CUST_CATEGORY," & vbCrLf
        strSQL = strSQL & "PT1.LETTER_PLAN_DATE," & vbCrLf
        strSQL = strSQL & "PT1.LETTER_ACCEPT_DATE," & vbCrLf
        strSQL = strSQL & "PT1.ORDER_DATE," & vbCrLf
        strSQL = strSQL & "PT1.LETTER_ID," & vbCrLf
        strSQL = strSQL & """"" AS LETTER_DELIVERY," & vbCrLf
        strSQL = strSQL & "PT1.BILLING_CD," & vbCrLf
        strSQL = strSQL & "PT1.BU," & vbCrLf
        strSQL = strSQL & "PT1.BRAND," & vbCrLf
        strSQL = strSQL & "PT1.SUM_CATEGORY," & vbCrLf
        strSQL = strSQL & "PT1.BRAND_SUB," & vbCrLf
        strSQL = strSQL & "PT1.T_OP1," & vbCrLf
        strSQL = strSQL & "PT1.T_OP2," & vbCrLf
        strSQL = strSQL & "PT1.T_SIZE," & vbCrLf
        strSQL = strSQL & "PT1.NON_SBO," & vbCrLf
        strSQL = strSQL & "PT1.ADDITION_ITEM," & vbCrLf
        strSQL = strSQL & "PT1.TOPACS_CPNO," & vbCrLf
        strSQL = strSQL & "PT1.BRAND_AP_FORM," & vbCrLf
        strSQL = strSQL & "PT1.BRAND_AP_REQ," & vbCrLf
        strSQL = strSQL & "PT1.BRAND_AP_CONF," & vbCrLf
        strSQL = strSQL & "PT1.PATTERN_CD," & vbCrLf
        strSQL = strSQL & "PT1.PATTERN," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM01," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM02," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM03," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM04," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM05," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM06," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM07," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM08," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM09," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM10," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM11," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM12," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM13," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM14," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM15," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM16," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM17," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM18," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM19," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM20," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM22," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM23," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM24," & vbCrLf
        strSQL = strSQL & "PT2.WD_ANNT_DATE," & vbCrLf
        strSQL = strSQL & "PT2.WD_DATE," & vbCrLf
        strSQL = strSQL & "PT2.PRICE_CHG_DATE," & vbCrLf
        strSQL = strSQL & "PT2.QTY," & vbCrLf
        strSQL = strSQL & "PT2.INST_DATE," & vbCrLf
        strSQL = strSQL & "PT2.PAY_START_DATE," & vbCrLf
        strSQL = strSQL & "PT2.PAY_END_DATE," & vbCrLf
        strSQL = strSQL & "PT2.IGF_START_DATE," & vbCrLf
        strSQL = strSQL & "PT2.IGF_END_DATE," & vbCrLf
        strSQL = strSQL & "PT2.PAY_FLAG," & vbCrLf
        strSQL = strSQL & "PT2.BID_FLAG," & vbCrLf
        strSQL = strSQL & "PT2.PAY_MONTHS," & vbCrLf
        strSQL = strSQL & "PT2.VALID_CTRL," & vbCrLf
        strSQL = strSQL & "PT2.PAY_METHOD," & vbCrLf
        strSQL = strSQL & "PT2.IGF_APPLIED," & vbCrLf
        strSQL = strSQL & "PT2.IGF_CONT_NO," & vbCrLf
        strSQL = strSQL & "PT2.IGF_CONT_TYPE," & vbCrLf
        strSQL = strSQL & "PT2.IGF_PROPERTY," & vbCrLf
        strSQL = strSQL & "PT2.IGF_RATE_IOC," & vbCrLf
        strSQL = strSQL & "PT2.LIST_PRICE_PROPOSAL," & vbCrLf
        strSQL = strSQL & "PT2.LIST_PRICE," & vbCrLf
        strSQL = strSQL & "PT2.LIST_PRICE_TOTAL_PROPOSAL," & vbCrLf
        strSQL = strSQL & "PT2.LIST_PRICE_TOTAL," & vbCrLf
        strSQL = strSQL & "PT2.DP_IOC," & vbCrLf
        strSQL = strSQL & "PT2.PRICE_UNIT_IOC," & vbCrLf
        strSQL = strSQL & "PT2.PRICE_UNIT_IOC_VAL," & vbCrLf
        strSQL = strSQL & "PT2.PRICE_QTY_IOC," & vbCrLf
        strSQL = strSQL & "PT2.PRICE_TO_SPLIT," & vbCrLf
        strSQL = strSQL & "PT2.LIST_PRICE_TOTAL_IOC," & vbCrLf
        strSQL = strSQL & "PT2.PRICE_TOTAL_IOC," & vbCrLf
        strSQL = strSQL & "PT2.PRICE_IGF_TOTAL," & vbCrLf
        strSQL = strSQL & "PT2.PRICE_CONT_TOTAL," & vbCrLf
        strSQL = strSQL & "PT2.PRICE_OO_CONT_TOTAL," & vbCrLf
        strSQL = strSQL & "PT2.IGF_DIF_INTEREST, " & vbCrLf
        strSQL = strSQL & "PT2.PAST_PRICE_TOTAL " & vbCrLf
        strSQL = strSQL & "FROM PaymentTBL1 PT1 INNER JOIN PaymentTBL2 PT2 ON PT1.ID = PT2.ID " & vbCrLf
        '''' 処理：条件文ＳＱＬ作成処理(MakeSQLWhereComm())を呼び出す
        strSQL = strSQL & MakeSQLWhereComm(dtNow, intOutputCd, False)
        '''' 処理：ソート順設定
        strSQL = strSQL & "ORDER BY LETTER_ID, CLNG(LINE_NO)" & vbCrLf

        Debug.Print(strSQL)

        MakeExcelWorkManagementSQL = strSQL

    End Function

    ''' <summary>
    ''' 件数取得ＳＱＬ作成
    ''' </summary>
    ''' <param name="dtNow">作成日時</param>
    ''' <param name="intOutputCd"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function MakeExcelWorkManagementCountSQL(ByVal dtNow As Date, ByVal intOutputCd As Integer) As String

        Dim strSQL As String = ""

        '''' 処理：抽出項目設定
        strSQL = strSQL & "SELECT " & vbCrLf
        strSQL = strSQL & "PT1.ID " & vbCrLf
        If intOutputCd = CD_ACT_OUTPUT3 Then
            strSQL = strSQL & ", PT2.PAY_END_DATE " & vbCrLf
        End If
        'Req.1702 実行支援シート追加 2018/12 Str
        If intOutputCd = CD_ACT_OUTPUT5 Then
            strSQL = strSQL & ", PT2.WD_DATE " & vbCrLf
            strSQL = strSQL & ", PT1.PROD_ITEM08 " & vbCrLf
            strSQL = strSQL & ", PT1.PROD_ITEM12 " & vbCrLf
            strSQL = strSQL & ", PT1.PATTERN_CD " & vbCrLf
        End If
        'Req.1702 実行支援シート追加 2018/12 Str
        strSQL = strSQL & "FROM PaymentTBL1 PT1 INNER JOIN PaymentTBL2 PT2 ON PT1.ID = PT2.ID " & vbCrLf
        '''' 処理：条件文ＳＱＬ作成処理(MakeSQLWhereComm())を呼び出す
        strSQL = strSQL & MakeSQLWhereComm(dtNow, intOutputCd, False)

        Debug.Print(strSQL)

        MakeExcelWorkManagementCountSQL = strSQL

    End Function

    ''' <summary>
    ''' 条件文ＳＱＬ作成（共通）
    ''' </summary>
    ''' <param name="dtNow">現在日時</param>
    ''' <param name="intOutputCd">処理区分</param>
    ''' <param name="blnDelFlg">削除済条件かどうか True:削除済条件、False:非削除済条件</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function MakeSQLWhereComm(ByVal dtNow As Date, ByVal intOutputCd As Integer, ByVal blnDelFlg As Boolean) As String

        Dim strSQL As String = ""

        strSQL = strSQL & "WHERE " & vbCrLf
        '---------------------------------------------------
        '共通条件
        '---------------------------------------------------
        '''' 処理：共通条件ＳＱＬ文作成
        strSQL = strSQL & "(    " & vbCrLf
        '''' 　ロックFLG ＝ 「C」(契約済み)
        strSQL = strSQL & "        (PT1.LOCK_FLAG='C') " & vbCrLf
        '''' 　有効無効FLG ≠ 「N」(作業指示)、「C」(コメント)
        strSQL = strSQL & "    AND (PT1.VALID_FLAG<>'N' AND PT1.VALID_FLAG<>'C') " & vbCrLf
        '''' 　入力パターン ≠ 「0」「26」「28」「29」「30」「35」「36」「37」「38」「99」
        '''' 　入力パターン名称 以下の文字列を含まない　
        '''' 　「HW Brand Service」「請求統合」「IGF(再ﾘｰｽ)」「ExcessTCV」「CIS」「Primo使用サービス」「S&D RENTAL」
        '''' 　※「CIS」は「CISCO保守」と被るため「CIS%」は使えない
        strSQL = strSQL & "    AND (PT1.PATTERN_CD<>'0') " & vbCrLf
        strSQL = strSQL & "    AND (PT1.PATTERN_CD<>'26') " & vbCrLf
        strSQL = strSQL & "    AND (PT1.PATTERN_CD<>'28') " & vbCrLf
        strSQL = strSQL & "    AND (PT1.PATTERN_CD<>'29') " & vbCrLf
        strSQL = strSQL & "    AND (PT1.PATTERN_CD<>'30') " & vbCrLf
        strSQL = strSQL & "    AND (PT1.PATTERN_CD<>'35') " & vbCrLf
        strSQL = strSQL & "    AND (PT1.PATTERN_CD<>'36') " & vbCrLf
        strSQL = strSQL & "    AND (PT1.PATTERN_CD<>'37') " & vbCrLf
        strSQL = strSQL & "    AND (PT1.PATTERN_CD<>'38') " & vbCrLf
        strSQL = strSQL & "    AND (PT1.PATTERN_CD<>'45') " & vbCrLf
        strSQL = strSQL & "    AND (PT1.PATTERN_CD<>'46') " & vbCrLf
        strSQL = strSQL & "    AND (PT1.PATTERN_CD<>'99') " & vbCrLf
        strSQL = strSQL & "    AND (PT1.PATTERN NOT LIKE 'HW Brand Service%') " & vbCrLf
        strSQL = strSQL & "    AND (PT1.PATTERN NOT LIKE '請求統合%') " & vbCrLf
        strSQL = strSQL & "    AND (PT1.PATTERN NOT LIKE 'IGF金利%') " & vbCrLf
        strSQL = strSQL & "    AND (PT1.PATTERN NOT LIKE 'IGF(再ﾘｰｽ)%') " & vbCrLf
        strSQL = strSQL & "    AND (PT1.PATTERN NOT LIKE 'ExcessTCV%') " & vbCrLf
        strSQL = strSQL & "    AND (PT1.PATTERN<>'CIS') " & vbCrLf
        strSQL = strSQL & "    AND (PT1.PATTERN<>'CIS 削除ﾃﾞｰﾀ') " & vbCrLf
        strSQL = strSQL & "    AND (PT1.PATTERN NOT LIKE 'Primo使用サービス%') " & vbCrLf
        strSQL = strSQL & "    AND (PT1.PATTERN NOT LIKE 'S&D RENTAL%') " & vbCrLf
        strSQL = strSQL & "    AND (PT1.PATTERN NOT LIKE 'Allotment%') " & vbCrLf
        strSQL = strSQL & "    AND (PT1.PATTERN NOT LIKE 'Variance Cash%') " & vbCrLf
        '
        strSQL = strSQL & ") " & vbCrLf

        '''' 　条件：削除済フラグ判定
        '''' 　ケース：非削除済の場合、各シート毎に条件SQL文を呼び出す
        If blnDelFlg = False Then
            Select Case intOutputCd
                Case CD_ACT_OUTPUT1
                    strSQL = strSQL & MakeSQLWhere1(dtNow)
                Case CD_ACT_OUTPUT2
                    strSQL = strSQL & MakeSQLWhere2(dtNow)
                Case CD_ACT_OUTPUT3
                    strSQL = strSQL & MakeSQLWhere3(dtNow)
                Case CD_ACT_OUTPUT4
                    strSQL = strSQL & MakeSQLWhere4(dtNow)
            End Select
        End If

        MakeSQLWhereComm = strSQL

    End Function

    ''' <summary>
    ''' 条件文ＳＱＬ作成（①要回答未実行（過去－２ヶ月））
    ''' </summary>
    ''' <param name="dtNow">現在日時</param>
    ''' <returns>SQL文</returns>
    ''' <remarks></remarks>
    Private Function MakeSQLWhere1(ByVal dtNow As Date) As String

        Dim strSQL As String = ""
        Dim strLastMonth As String = dtNow.AddMonths(2).AddDays(-1).ToString("yyyy/MM/dd")
        Dim strNow As String = Format(dtNow, "yyyy/MM/dd")

        '---------------------------------------------------
        '''' 処理：条件文ＳＱＬ作成（①要回答未実行（過去－２ヶ月））
        '''' 　通知書番号　 ＝ 空白
        '''' 　導入年月     ≦ 現在日付の年月＋２ヶ月
        '''' 　元本開始年月 ≦ 現在日付の年月＋２ヶ月
        ''''   IGF開始年月　≦ 現在日付の年月＋２ヶ月
        ''''   サービス提供開始 ≦ 現在日付の年月＋２ヶ月
        '---------------------------------------------------
        strSQL = strSQL & "AND " & vbCrLf
        '通知書番号　＝　空白
        strSQL = strSQL & "     PT1.LETTER_ID='' " & vbCrLf
        '導入年月 ≦ 現在日付の年月+２ヶ月
        strSQL = strSQL & "        AND " & vbCrLf
        strSQL = strSQL & "        ( " & vbCrLf
        '
        strSQL = strSQL & "            (PT2.INST_DATE IS NOT NULL " & vbCrLf
        strSQL = strSQL & "                 AND PT2.INST_DATE<>'' " & vbCrLf
        strSQL = strSQL & "                 AND CDATE(PT2.INST_DATE)<=DATEADD('m',2,CDATE('" & strNow & "'))) " & vbCrLf
        '元本計算開始年月 ≦ 現在日付の年月+2ヶ月
        strSQL = strSQL & "         OR (PT2.PAY_START_DATE IS NOT NULL " & vbCrLf
        strSQL = strSQL & "                 AND PT2.PAY_START_DATE<>'' " & vbCrLf
        strSQL = strSQL & "                 AND CDATE(PT2.PAY_START_DATE)<=DATEADD('m',2,CDATE('" & strNow & "'))) " & vbCrLf
        'IGF計算開始年月 ≦ 現在日付の年月+2ヶ月
        strSQL = strSQL & "         OR (PT2.IGF_START_DATE IS NOT NULL " & vbCrLf
        strSQL = strSQL & "                 AND PT2.IGF_START_DATE<>'' " & vbCrLf
        strSQL = strSQL & "                 AND CDATE(PT2.IGF_START_DATE)<=DATEADD('m',2,CDATE('" & strNow & "'))) " & vbCrLf
        'サービス提供開始対応 ≦ 現在日付の年月+2ヶ月
        strSQL = strSQL & "         OR (IsDate(PT1.PROD_ITEM11) = True " & vbCrLf
        strSQL = strSQL & "                 AND CDATE(PT1.PROD_ITEM11)<=#" & strLastMonth & "# " & vbCrLf
        strSQL = strSQL & "            )" & vbCrLf
        strSQL = strSQL & "        ) " & vbCrLf

        MakeSQLWhere1 = strSQL

    End Function

    ''' <summary>
    ''' 条件文ＳＱＬ作成（②任意回答未実行（3ヶ月以降））
    ''' </summary>
    ''' <param name="dtNow">現在日時</param>
    ''' <returns>SQL文</returns>
    ''' <remarks></remarks>
    Private Function MakeSQLWhere2(ByVal dtNow As Date) As String

        Dim strSQL As String = ""
        Dim strFirstMonth As String = CDate(dtNow.Year & "/" & _
                                           dtNow.Month & "/" & _
                                           "01").AddMonths(3).ToString("yyyy/MM/dd")
        Dim strNow As String = Format(dtNow, "yyyy/MM/dd")

        '---------------------------------------------------
        '''' 処理：条件文ＳＱＬ作成（②任意回答未実行（3ヶ月以降））
        '''' 　通知書番号　 ＝ 空白
        '''' 　導入年月     ≧ 現在日付の年月＋３ヶ月
        '''' 　元本開始年月 ≧ 現在日付の年月＋３ヶ月
        ''''   IGF開始年月　≧ 現在日付の年月＋３ヶ月
        ''''   サービス提供開始 ≧ 現在日付の年月＋３ヶ月
        '---------------------------------------------------
        strSQL = strSQL & "AND " & vbCrLf
        '通知書番号　＝　空白
        strSQL = strSQL & "     PT1.LETTER_ID='' " & vbCrLf
        '導入年月 ≧ 現在日付の年月+３ヶ月
        strSQL = strSQL & "        AND " & vbCrLf
        strSQL = strSQL & "        ( " & vbCrLf
        '
        strSQL = strSQL & "            (PT2.INST_DATE IS NOT NULL " & vbCrLf
        strSQL = strSQL & "                 AND PT2.INST_DATE<>'' " & vbCrLf
        strSQL = strSQL & "                 AND CDATE(PT2.INST_DATE)>=DATEADD('m',3,CDATE('" & strNow & "'))) " & vbCrLf
        '元本計算開始年月 ≧ 現在日付の年月+３ヶ月
        strSQL = strSQL & "         OR (PT2.PAY_START_DATE IS NOT NULL " & vbCrLf
        strSQL = strSQL & "                 AND PT2.PAY_START_DATE<>'' " & vbCrLf
        strSQL = strSQL & "                 AND CDATE(PT2.PAY_START_DATE)>=DATEADD('m',3,CDATE('" & strNow & "'))) " & vbCrLf
        'IGF計算開始年月 ≧ 現在日付の年月+３ヶ月
        strSQL = strSQL & "         OR (PT2.IGF_START_DATE IS NOT NULL " & vbCrLf
        strSQL = strSQL & "                 AND PT2.IGF_START_DATE<>'' " & vbCrLf
        strSQL = strSQL & "                 AND CDATE(PT2.IGF_START_DATE)>=DATEADD('m',3,CDATE('" & strNow & "'))) " & vbCrLf
        'サービス提供開始対応 ≧ 現在日付の年月+３ヶ月
        strSQL = strSQL & "         OR (IsDate(PT1.PROD_ITEM11) = True " & vbCrLf
        strSQL = strSQL & "                 AND CDATE(PT1.PROD_ITEM11)>=#" & strFirstMonth & "# " & vbCrLf
        strSQL = strSQL & "            )" & vbCrLf
        strSQL = strSQL & "        ) " & vbCrLf

        MakeSQLWhere2 = strSQL

    End Function

    ''' <summary>
    ''' 条件文ＳＱＬ作成（要確認EOS価格改定）
    ''' </summary>
    ''' <param name="dtNow">作成日時</param>
    ''' <returns>SQL文</returns>
    ''' <remarks></remarks>
    Private Function MakeSQLWhere3(ByVal dtNow As Date) As String

        Dim strSQL As String = ""
        Dim strNow As String = Format(dtNow, "yyyy/MM/dd")

        '---------------------------------------------------
        '''' 処理：条件文ＳＱＬ作成（要確認EOS価格改定）
        '''' 　将来に廃止発表、廃止予定、価格改定が発生するﾃﾞｰﾀ
        '''' 　※9999/12/31は対象外
        '''' 　HWMAはﾃﾞﾘﾊﾞﾘ管理項目が全て埋まっていても出力
        '''' 　HWMA以外はﾃﾞﾘﾊﾞﾘ管理項目が１つでも埋まっていないデータを出力(空白 or 8888/1/1ならば埋まっていないと判定)
        '''' 　　通知書お客様捺印日 ＝ 空白 or 8888/1/1
        '''' 　　発注完了確認日 ＝ 空白 or 8888/1/1
        ''''   現在年月≦請求期間_終了年月
        '---------------------------------------------------
        strSQL = strSQL & "AND " & vbCrLf
        strSQL = strSQL & "            (" & vbCrLf
        '製品･ｻｰﾋﾞｽ_廃止発表日 > 現在日付
        strSQL = strSQL & "               (PT2.WD_ANNT_DATE IS NOT NULL " & vbCrLf
        strSQL = strSQL & "                    AND PT2.WD_ANNT_DATE<>'' " & vbCrLf
        strSQL = strSQL & "                    AND CDATE(PT2.WD_ANNT_DATE)>#" & strNow & "# " & vbCrLf
        strSQL = strSQL & "                    AND CDATE(PT2.WD_ANNT_DATE)<>#9999/12/31#) " & vbCrLf
        '製品･ｻｰﾋﾞｽ_廃止予定日 > 現在日付
        strSQL = strSQL & "            OR (PT2.WD_DATE IS NOT NULL " & vbCrLf
        strSQL = strSQL & "                    AND PT2.WD_DATE<>'' " & vbCrLf
        strSQL = strSQL & "                    AND CDATE(PT2.WD_DATE)>#" & strNow & "# " & vbCrLf
        strSQL = strSQL & "                    AND CDATE(PT2.WD_DATE)<>#9999/12/31#)" & vbCrLf
        '価格改定予定日 > 現在日付
        strSQL = strSQL & "            OR (PT2.PRICE_CHG_DATE IS NOT NULL " & vbCrLf
        strSQL = strSQL & "                    AND PT2.PRICE_CHG_DATE<>'' " & vbCrLf
        strSQL = strSQL & "                    AND CDATE(PT2.PRICE_CHG_DATE)>#" & strNow & "# " & vbCrLf
        strSQL = strSQL & "                    AND CDATE(PT2.PRICE_CHG_DATE)<>#9999/12/31#)" & vbCrLf
        '
        strSQL = strSQL & "          ) " & vbCrLf
        'HWMAはﾃﾞﾘﾊﾞﾘ管理項目が全て埋まっていても出力
        strSQL = strSQL & "            AND " & vbCrLf
        strSQL = strSQL & "               ( " & vbCrLf
        strSQL = strSQL & "                   ( " & vbCrLf
        strSQL = strSQL & "                             PT1.PATTERN LIKE 'IBM HWMA AAS BOX%' " & vbCrLf
        strSQL = strSQL & "                          OR PT1.PATTERN LIKE 'IBM HWMA AAS MES%' " & vbCrLf
        strSQL = strSQL & "                          OR PT1.PATTERN LIKE 'IBM HWMA QCOS' " & vbCrLf
        strSQL = strSQL & "                          OR PT1.PATTERN LIKE 'IBM HWMA QCOS 削除ﾃﾞｰﾀ' " & vbCrLf
        strSQL = strSQL & "                          OR PT1.PATTERN LIKE 'HWBrandSW AAS%' " & vbCrLf
        strSQL = strSQL & "                          OR PT1.PATTERN LIKE 'HWBrandSW QCOS%' " & vbCrLf
        strSQL = strSQL & "                          OR PT1.PATTERN LIKE 'HWBrandSWMA AAS%' " & vbCrLf
        strSQL = strSQL & "                          OR PT1.PATTERN LIKE 'HWBrandSWMA QCOS%' " & vbCrLf
        strSQL = strSQL & "                          OR PT1.PATTERN LIKE 'SWBrandSW%' " & vbCrLf
        strSQL = strSQL & "                          OR PT1.PATTERN LIKE 'SWBrandSWMA%' " & vbCrLf
        strSQL = strSQL & "                   ) " & vbCrLf

        'HWMA以外はﾃﾞﾘﾊﾞﾘ管理項目が１つでも埋まっていないデータを出力(空白 or 8888/1/1ならば埋まっていないと判定)
        strSQL = strSQL & "                   OR " & vbCrLf
        strSQL = strSQL & "                   ( " & vbCrLf
        strSQL = strSQL & "                       ( " & vbCrLf
        '②通知書お客様捺印日 ＝ 空白 or 8888/1/1
        strSQL = strSQL & "                             ((PT1.LETTER_ACCEPT_DATE='' OR PT1.LETTER_ACCEPT_DATE IS NULL) " & vbCrLf
        strSQL = strSQL & "                                  OR (PT1.LETTER_ACCEPT_DATE<>'' AND PT1.LETTER_ACCEPT_DATE IS NOT NULL AND CDATE(PT1.LETTER_ACCEPT_DATE)=#8888/1/1#)) " & vbCrLf
        '③発注完了確認日 ＝ 空白 or 8888/1/1
        strSQL = strSQL & "                          OR ((PT1.ORDER_DATE='' OR PT1.ORDER_DATE IS NULL) " & vbCrLf
        strSQL = strSQL & "                                  OR (PT1.ORDER_DATE<>'' AND PT1.ORDER_DATE IS NOT NULL AND CDATE(PT1.ORDER_DATE)=#8888/1/1#)) " & vbCrLf
        '
        strSQL = strSQL & "                       ) AND (" & vbCrLf
        strSQL = strSQL & "                              PT1.PATTERN NOT LIKE 'IBM HWMA AAS BOX%' " & vbCrLf
        strSQL = strSQL & "                          AND PT1.PATTERN NOT LIKE 'IBM HWMA AAS MES%' " & vbCrLf
        strSQL = strSQL & "                          OR PT1.PATTERN LIKE 'IBM HWMA QCOS' " & vbCrLf
        strSQL = strSQL & "                          OR PT1.PATTERN LIKE 'IBM HWMA QCOS 削除ﾃﾞｰﾀ' " & vbCrLf
        strSQL = strSQL & "                          AND PT1.PATTERN NOT LIKE 'HWBrandSW AAS%' " & vbCrLf
        strSQL = strSQL & "                          AND PT1.PATTERN NOT LIKE 'HWBrandSW QCOS%' " & vbCrLf
        strSQL = strSQL & "                          AND PT1.PATTERN NOT LIKE 'HWBrandSWMA AAS%' " & vbCrLf
        strSQL = strSQL & "                          AND PT1.PATTERN NOT LIKE 'HWBrandSWMA QCOS%' " & vbCrLf
        strSQL = strSQL & "                          AND PT1.PATTERN NOT LIKE 'SWBrandSW%' " & vbCrLf
        strSQL = strSQL & "                          AND PT1.PATTERN NOT LIKE 'SWBrandSWMA%' " & vbCrLf
        strSQL = strSQL & "                       ) " & vbCrLf
        strSQL = strSQL & "                   ) " & vbCrLf
        strSQL = strSQL & "               ) " & vbCrLf
        '現在年月≦請求期間_終了年月
        strSQL = strSQL & "            AND (CDATE('" & Format(dtNow, "yyyy/MM/01") & "')<=CDATE(IIF(IsDate(PT2.PAY_END_DATE)=True,PT2.PAY_END_DATE,'1900/1/1'))) " & vbCrLf

        MakeSQLWhere3 = strSQL

    End Function

    ''' <summary>
    ''' 条件文ＳＱＬ作成（参考未発注（過去－２ヶ月））
    ''' </summary>
    ''' <param name="dtNow">作成日時</param>
    ''' <returns>SQL文</returns>
    ''' <remarks></remarks>
    Private Function MakeSQLWhere4(ByVal dtNow As Date) As String

        Dim strSQL As String = ""
        Dim strLastMonth As String = Now.AddMonths(2).AddDays(-1).ToString("yyyy/MM/dd")

        Dim strNow As String = Format(dtNow, "yyyy/MM/dd")

        '---------------------------------------------------
        '''' 処理：条件文ＳＱＬ作成（要確認EOS価格改定）
        '''' 条件に該当するデータ
        ''''   ① and ② and ③ and (④ or ⑤ or ⑥ or ⑦)
        '''' 
        '''' 　①通知書番号 ≠ 空白
        '''' 　②通知書お客様捺印日 ≠ (空白 or 8888/1/1)
        ''''   ③発注完了確認日 ＝ (空白 or 8888/1/1)
        '''' 　④導入年月 ≦ 現在日付の年月＋２ヵ月
        '''' 　⑤元本開始年月 ≦ 現在日付の年月＋２ヵ月
        '''' 　⑥IGF計算開始年月 ≦ 現在日付の年月＋２ヵ月
        ''''   ⑦ｻｰﾋﾞｽ提供期間開始 ≦ 現在日付の年月＋２ヵ月
        '---------------------------------------------------
        strSQL = strSQL & "AND " & vbCrLf
        '①通知書番号　≠　空白
        strSQL = strSQL & "     PT1.LETTER_ID<>'' " & vbCrLf
        '②客様捺印日 ≠ (空白 or 8888/1/1)
        strSQL = strSQL & "        AND NOT (PT1.LETTER_ACCEPT_DATE='' OR PT1.LETTER_ACCEPT_DATE IS NULL) " & vbCrLf
        strSQL = strSQL & "        AND NOT (PT1.LETTER_ACCEPT_DATE<>'' AND PT1.LETTER_ACCEPT_DATE IS NOT NULL AND CDATE(PT1.LETTER_ACCEPT_DATE)=#8888/1/1#) " & vbCrLf
        '③発注完了確認日 ＝ (空白 or 8888/1/1)
        strSQL = strSQL & "        AND (      (PT1.ORDER_DATE='' OR PT1.ORDER_DATE IS NULL) " & vbCrLf
        strSQL = strSQL & "                OR (PT1.ORDER_DATE<>'' AND PT1.ORDER_DATE IS NOT NULL AND CDATE(PT1.ORDER_DATE)=#8888/1/1#) " & vbCrLf
        strSQL = strSQL & "            )" & vbCrLf
        '④導入年月 ≦ 現在日付の年月+２ヶ月
        strSQL = strSQL & "        AND " & vbCrLf
        strSQL = strSQL & "        ( " & vbCrLf
        '
        strSQL = strSQL & "            (PT2.INST_DATE IS NOT NULL " & vbCrLf
        strSQL = strSQL & "                 AND PT2.INST_DATE<>'' " & vbCrLf
        strSQL = strSQL & "                 AND CDATE(PT2.INST_DATE)<=DATEADD('m',2,CDATE('" & strNow & "'))) " & vbCrLf
        '元本計算開始年月 ≦ 現在日付の年月+2ヶ月
        strSQL = strSQL & "         OR (PT2.PAY_START_DATE IS NOT NULL " & vbCrLf
        strSQL = strSQL & "                 AND PT2.PAY_START_DATE<>'' " & vbCrLf
        strSQL = strSQL & "                 AND CDATE(PT2.PAY_START_DATE)<=DATEADD('m',2,CDATE('" & strNow & "'))) " & vbCrLf
        'IGF計算開始年月 ≦ 現在日付の年月+2ヶ月
        strSQL = strSQL & "         OR (PT2.IGF_START_DATE IS NOT NULL " & vbCrLf
        strSQL = strSQL & "                 AND PT2.IGF_START_DATE<>'' " & vbCrLf
        strSQL = strSQL & "                 AND CDATE(PT2.IGF_START_DATE)<=DATEADD('m',2,CDATE('" & strNow & "'))) " & vbCrLf
        'サービス提供開始対応 ≦ 現在日付の年月+2ヶ月
        strSQL = strSQL & "         OR (IsDate(PT1.PROD_ITEM11) = True " & vbCrLf
        strSQL = strSQL & "                 AND CDATE(PT1.PROD_ITEM11)<=#" & strLastMonth & "# " & vbCrLf
        strSQL = strSQL & "            )" & vbCrLf
        strSQL = strSQL & "        ) " & vbCrLf

        MakeSQLWhere4 = strSQL

    End Function

    ''' <summary>
    ''' 条件文ＳＱＬ作成
    ''' </summary>
    ''' <returns>SQL文</returns>
    ''' <remarks></remarks>
    Private Function MakeSQLWhereNonLetterId() As String

        Dim strSQL As String = ""

        strSQL = strSQL & "WHERE PT1.LOCK_FLAG='C' "
        strSQL = strSQL & "AND PT1.LETTER_ID='' "
        strSQL = strSQL & "AND PT1.PATTERN_CD NOT IN ('0','29','99') "

        MakeSQLWhereNonLetterId = strSQL

    End Function

    ''' <summary>
    ''' ＤＢの値取得
    ''' </summary>
    ''' <param name="drData">DataReader</param>
    ''' <param name="strFieldName">フィールド名</param>
    ''' <returns></returns>
    ''' <remarks>値がNull値の場合、空文字に変換</remarks>
    Private Function GetDbData(ByVal drData As OleDbDataReader, ByVal strFieldName As String) As String

        GetDbData = ""

        Try
            '''' 条件：
            '''' ケース：Null値の場合、空文字を返す
            '''' ケース：Null値以外の場合、そのままの値を返す
            If IsDBNull(drData.Item(strFieldName)) = True Then
                GetDbData = ""
            Else
                GetDbData = drData.Item(strFieldName)
            End If

        Catch ex As Exception
            Throw ex
        End Try

    End Function

    ''' <summary>
    ''' ＤＢの値取得
    ''' </summary>
    ''' <param name="rsData">DataReader</param>
    ''' <param name="strFieldName">フィールド名</param>
    ''' <returns>値がNull値の場合、空文字に変換</returns>
    ''' <remarks></remarks>
    Private Function GetAdodbData(ByVal rsData As ADODB.Recordset, ByVal strFieldName As String) As String

        GetAdodbData = ""

        Try
            '''' 条件：
            '''' ケース：Null値の場合、空文字を返す
            '''' ケース：Null値以外の場合、そのままの値を返す
            If IsDBNull(rsData.Fields(strFieldName).Value) = True Then
                GetAdodbData = ""
            Else
                GetAdodbData = rsData.Fields(strFieldName).Value
            End If

        Catch ex As Exception
            Throw ex
        End Try

    End Function

    ''' <summary>
    ''' Work作業用のMDBを作成する。
    ''' </summary>
    ''' <param name="intIndex"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Sub CopyTmpMDB()

        Try
            '''' 処理：Pathを取得する
            Dim ofm As New OioFileManage
            Dim copyPath As String
            Dim pastePath As String

            copyPath = ofm.GetDataKeepMDBPath(CommonVariable.CPNO)
            pastePath = ofm.GetDataWorkMDBPath(CommonVariable.CPNO)

            '''' 処理：ﾌｧｲﾙのｺﾋﾟｰ
            File.Copy(copyPath, pastePath, True)

        Catch ex As Exception
            Throw ex

        End Try

    End Sub

    ''' <summary>
    ''' 実行管理情報をTempMDBにセット（実行管理ファイル）
    ''' </summary>
    ''' <param name="con">MDBのコネクション</param>
    ''' <param name="xlInPSSheet"></param>
    ''' <remarks></remarks>
    Private Sub UpdASRPaymentACTDataTable(ByRef con As OleDbConnection, ByRef xlInPSSheet As Excel.Worksheet)

        Dim strSQL As String
        Dim cmdIns As New OleDbCommand
        Dim intIndex As Integer
        Dim xlCell As Excel.Range
        Dim cellObj(,) As Object

        Const ColumNM_LINE_NO As Integer = 4                    ''行番号
        Const ColumNM_LETTER_ID As Integer = 16                 ''実行通知書番号

        Try
            '''' 処理：オートフィルターがある場合、解除する 
            If Not xlInPSSheet.AutoFilter Is Nothing Then
                xlInPSSheet.AutoFilterMode = False
            End If

            cmdIns.Connection = con

            intIndex = EXCEL_WORKMANAGEEXPORT_OUTROW
            '''' 繰返し_開始:ループ
            Do
                '''' 処理：Excelの1行取得            
                xlCell = xlInPSSheet.Range("A@:R@".Replace("@", intIndex))
                cellObj = xlCell.Value

                '''' 条件：EOF判定(CheckRowLetter())
                '''' ケース：EOFの場合、ループを抜ける
                Dim blnRet As Boolean
                blnRet = CheckRowLetter(cellObj)
                If blnRet = False Then
                    Exit Do
                End If

                '''' 条件：通知書番号判定
                '''' ケース：通知書番号が空白以外の場合、以下の項目をTempMDBに取り込む
                '''' 　行番、通知書番号、NO
                If ExcelWrite.changeDBNullToString(cellObj(1, ColumNM_LETTER_ID)) <> "" Then
                    strSQL = "INSERT INTO FrmASRReadPaymentACT (EXCEL_ROW,LETTER_ID,LINE_NO) VALUES ("
                    strSQL = strSQL & "'" & intIndex.ToString.PadLeft(6, "0") & "',"
                    strSQL = strSQL & "'" & ExcelWrite.changeDBNullToString(cellObj(1, ColumNM_LETTER_ID)) & "',"
                    strSQL = strSQL & "'" & ExcelWrite.changeDBNullToString(cellObj(1, ColumNM_LINE_NO)) & "'"
                    strSQL = strSQL & ")"
                    Debug.Print(strSQL)
                    cmdIns.CommandText = strSQL
                    cmdIns.ExecuteNonQuery()
                End If
                '''' 処理：次行へ
                intIndex = intIndex + 1
            Loop
            '''' 繰返し_終了：

        Catch ex As Exception
            Throw ex
        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            cmdIns.Dispose()
            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' 実行支援の情報をOBAMASheetに反映する。
    ''' </summary>
    ''' <param name="con">MDBのコネクション</param>
    ''' <param name="eofLine"></param>
    ''' <param name="intPaymentPeriod"></param>
    ''' <param name="xlOutOBAMASheet"></param>
    ''' <param name="intOutputCnt"></param>
    ''' <remarks></remarks>
    Private Sub WriteASRPaymentACTData(ByRef con As OleDbConnection,
                                       ByVal eofLine As Integer,
                                       ByVal intPaymentPeriod As Integer,
                                       ByRef xlOutOBAMASheet As Excel.Worksheet,
                                       ByRef intOutputCnt As Integer)

        Dim strSQL As String
        Dim cmdCount As New OleDbCommand
        Dim intRecordCnt As Integer
        Dim cmdPt1Pt2 As New OleDbCommand
        Dim drPt1Pt2 As OleDbDataReader
        Dim cmdPt3 As New OleDbCommand
        Dim drPt3 As OleDbDataReader
        Dim intFieldCnt As Integer
        Dim strItemValue As String
        Dim strOutYear As String
        Dim strOutMonth As String
        Dim intYearCnt As Integer
        Dim strOutData As String
        Dim strFileName As String
        Dim sw As StreamWriter
        Dim strWork As String
        Dim strCsvPath As String
        Dim ofm As New OioFileManage
        Dim strRange As String
        Dim strPastPriceTotal As String
        Dim xlCell As Excel.Range = Nothing
        Dim xlRange As Excel.Range = Nothing
        Dim xlEntireRow As Excel.Range = Nothing

        Try
            '----------------------------
            '件数取得
            '----------------------------
            '''' 処理：出力件数取得
            '''' 　①ＳＱＬ文作成(MakeExcelPaymentSQLFrom())
            '''' 　②ＳＱＬ文実行
            cmdCount.Connection = con
            strSQL = "SELECT COUNT(PT1.ID) " & vbCrLf
            strSQL = strSQL & MakeExcelPaymentSQLFrom() & vbCrLf
            Debug.Print(strSQL)
            cmdCount.CommandText = strSQL
            intRecordCnt = cmdCount.ExecuteScalar

            '----------------------------
            '開始年設定
            '----------------------------
            '''' 処理：開始年設定(開始年設定())
            Call SetStartMonth(xlOutOBAMASheet, CD_ASR_ACT)
            '''' 条件：出力件数有無
            '''' ケース：出力件数が１件以上の場合、以下の処理を行う
            If intRecordCnt > 0 Then
                '----------------------------
                '枠だけコピー
                '----------------------------
                '''' 　処理：罫線作成
                '''' 　　①出力件数から５００件ごとに２行目のTemplate行をコピーする
                Const DIVISION_LINES As Long = 500
                Dim lngSho As Long = intRecordCnt \ DIVISION_LINES
                Dim lngAmari As Long = intRecordCnt Mod DIVISION_LINES
                Dim lngCnt As Long

                For lngCnt = 1 To lngSho
                    xlCell = xlOutOBAMASheet.Range("2:2")
                    xlCell.Copy()
                    ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                    strRange = (EXCEL_PAYMENTLINEDATE_OUTROW + (lngCnt - 1) * DIVISION_LINES).ToString() & ":" & (EXCEL_PAYMENTLINEDATE_OUTROW + lngCnt * DIVISION_LINES - 1).ToString()
                    Debug.Print("枠コピー１：" & strRange)
                    xlCell = xlOutOBAMASheet.Range(strRange)
                    xlCell.Insert()
                    ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                Next
                If lngAmari > 0 Then
                    xlCell = xlOutOBAMASheet.Range("2:2")
                    xlCell.Copy()
                    ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                    strRange = (EXCEL_PAYMENTLINEDATE_OUTROW + (lngSho * DIVISION_LINES)).ToString() & ":" & (EXCEL_PAYMENTLINEDATE_OUTROW + (lngSho * DIVISION_LINES + lngAmari) - 1).ToString()
                    Debug.Print("枠コピー２：" & strRange)
                    xlCell = xlOutOBAMASheet.Range(strRange)
                    xlCell.Insert()
                    ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                End If
                '''' 　処理：行の再表示（隠し行になっているため）
                strRange = (ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW - 1).ToString() & ":" & (eofLine + (lngSho * DIVISION_LINES + lngAmari) + 1).ToString()
                Debug.Print("再表示：" & strRange)
                xlCell = xlOutOBAMASheet.Range(strRange)
                xlEntireRow = xlCell.EntireRow
                xlEntireRow.Hidden = False
                ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)

                '----------------------------
                'データ取得
                '----------------------------
                '''' 　処理：PaymentTBL1、PaymentTBL2のデータ取得
                '''' 　　①SQL文作成(MakeExcelPaymentSQL())
                '''' 　　②SQL文実行
                cmdPt1Pt2.Connection = con
                cmdPt1Pt2.CommandText = MakeExcelPaymentSQL(CD_ACT_REFERENCE)
                drPt1Pt2 = cmdPt1Pt2.ExecuteReader()

                cmdPt3.Connection = con

                ''''   処理：中間ファイル作成
                strCsvPath = Path.GetFullPath("../log/")
                strFileName = strCsvPath & "WorkCsv_ActionDataPs_" & Now.ToString("yyyyMMdd_HHmmss") & ".csv"
                sw = New StreamWriter(strFileName, False, System.Text.Encoding.Default)

                '''' 　繰返し_開始：PaymentTBL1、PaymentTBL2のデータが無くなるまで
                While drPt1Pt2.Read = True
                    '----------------------------
                    '項目取得
                    '----------------------------
                    '''' 　　処理：出力データ作成（年額月額展開以外の項目）
                    strItemValue = ""
                    For intFieldCnt = 0 To (drPt1Pt2.FieldCount - 1)
                        Select Case drPt1Pt2.GetName(intFieldCnt)
                            Case "ID"
                            Case "PAST_PRICE_TOTAL"
                                strPastPriceTotal = """" & GetDbData(drPt1Pt2, "PAST_PRICE_TOTAL") & ""","
                            Case Else
                                strWork = GetDbData(drPt1Pt2, drPt1Pt2.GetName(intFieldCnt))
                                strWork = strWork.Replace("""", """""")
                                strItemValue = strItemValue & """" & strWork & ""","
                        End Select
                    Next

                    '----------------------------
                    '年額月額展開取得
                    '----------------------------
                    '''' 　　処理：出力データ作成（年額月額展開と展開金額の項目）
                    '''' 　　　①PaymentTBL1、PaymentTBL2に該当するIDでPaymentTBL3を検索する
                    '''' 　　　②年額展開、月額展開のデータを取得する
                    strSQL = "SELECT * FROM PaymentTBL3 WHERE ID='" & drPt1Pt2.Item(0) & "' ORDER BY INT(IOC_YEAER)"
                    cmdPt3.CommandText = strSQL
                    drPt3 = cmdPt3.ExecuteReader()
                    strOutYear = ""
                    strOutMonth = ""
                    While drPt3.Read = True
                        '年額展開取得
                        strWork = GetDbData(drPt3, "IOC_YYYY")
                        strWork = strWork.Replace("""", """""")
                        strOutYear = strOutYear & """" & strWork & ""","
                        '月額展開取得
                        For intYearCnt = 1 To 12
                            strWork = GetDbData(drPt3, "IOC_" & intYearCnt.ToString("00"))
                            strWork = strWork.Replace("""", """""")
                            strOutMonth = strOutMonth & """" & strWork & ""","
                        Next
                    End While
                    strOutData = strItemValue & strOutYear & strPastPriceTotal & strOutMonth
                    drPt3.Close()

                    sw.WriteLine(strOutData)
                End While
                sw.Close()

                '''' 処理：Paymentに中間ﾌｧｲﾙを出力
                Dim intDataType(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12 - 1) As Integer
                Call ExcelWrite.SetExcelDataTypePayment(intDataType)
                strRange = "A" & EXCEL_PAYMENTLINEDATE_OUTROW.ToString
                Call ExcelWrite.LoadCsvToExcel(strFileName, 1, "Payment", strRange, xlOutOBAMASheet, intDataType)

            End If
            '==========================================================
            '''' 処理：Payment展開期間分列削除(ExcelWrite.CreatePaymentPeriod)
            '==========================================================
            Call ExcelWrite.CreatePaymentPeriod(xlOutOBAMASheet,
                                                ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1),
                                                intPaymentPeriod)

            intOutputCnt = intRecordCnt

        Catch ex As Exception
            Throw ex
        Finally
            'ﾜｰｸﾌｧｲﾙ削除
            Call ofm.DeleteWorkFile(strCsvPath)

            cmdPt3.Dispose()
            cmdCount.Dispose()
            cmdPt1Pt2.Dispose()

            '''' 処理：Excelｵﾌﾞｼﾞｪｸﾄの解放
            ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ''ガベージコレクトの起動
            GC.Collect()
        End Try

    End Sub

    ''' <summary>
    ''' 行チェック
    ''' </summary>
    ''' <param name="cellObj">Excel１行のデータ配列</param>
    ''' <returns>True：ある　False：ない</returns>
    ''' <remarks>行番にデータあるかチェックする</remarks>
    Private Function CheckRowLetter(ByRef cellObj(,) As Object) As Boolean

        CheckRowLetter = False

        Try
            '''' 条件：NO判定
            '''' ケース：NOが空文字の場合、データ無
            '''' ケース：上記以外、データ有
            If ExcelWrite.changeDBNullToString(cellObj(1, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)) = "" Then
                Exit Function
            End If

            CheckRowLetter = True

        Catch ex As Exception
            Throw ex

        End Try


    End Function

    ''' <summary>
    ''' Payment出力データ取得SQL
    ''' </summary>
    ''' <param name="intKbn"></param>
    ''' <returns>SQL文</returns>
    ''' <remarks></remarks>
    Private Function MakeExcelPaymentSQL(ByVal intKbn) As String

        Dim strSQL As String = ""

        '''' 処理：抽出項目設定
        strSQL = strSQL & "SELECT " & vbCrLf
        strSQL = strSQL & "PT1.ID," & vbCrLf
        '※現在CD_ACT_MAKEは使用していない
        If intKbn = CD_ACT_MAKE Then
            strSQL = strSQL & "PT1.UPDATE_FLAG," & vbCrLf
        Else
            strSQL = strSQL & """U""," & vbCrLf
        End If
        strSQL = strSQL & "PT1.LOCK_FLAG," & vbCrLf
        strSQL = strSQL & "PT1.VALID_FLAG," & vbCrLf
        strSQL = strSQL & "PT1.LINE_NO," & vbCrLf
        strSQL = strSQL & "PT1.FILE_NAME," & vbCrLf
        strSQL = strSQL & "PT1.FILE_NAME_SUFFIX," & vbCrLf
        strSQL = strSQL & "PT1.FILE_NAME_SUFFIX_INTR," & vbCrLf
        strSQL = strSQL & "PT1.CONTRACT," & vbCrLf
        strSQL = strSQL & "PT1.ST_COST," & vbCrLf
        strSQL = strSQL & "PT1.ST_APPROVAL," & vbCrLf
        strSQL = strSQL & "PT1.PROJ_ID," & vbCrLf
        strSQL = strSQL & "PT1.CONTRACT_SEQ," & vbCrLf
        strSQL = strSQL & "PT1.NEW_EXIST," & vbCrLf
        strSQL = strSQL & "PT1.CUST_CATEGORY," & vbCrLf
        strSQL = strSQL & "PT1.LETTER_PLAN_DATE," & vbCrLf
        strSQL = strSQL & "PT1.LETTER_ACCEPT_DATE," & vbCrLf
        strSQL = strSQL & "PT1.ORDER_DATE," & vbCrLf
        '※現在CD_ACT_MAKEは使用していない
        If intKbn = CD_ACT_MAKE Then
            strSQL = strSQL & "PT1.LETTER_ID," & vbCrLf
        Else
            strSQL = strSQL & "ACT.LETTER_ID," & vbCrLf
        End If
        strSQL = strSQL & "PT1.BILLING_CD," & vbCrLf
        strSQL = strSQL & "PT1.BU," & vbCrLf
        strSQL = strSQL & "PT1.BRAND," & vbCrLf
        strSQL = strSQL & "PT1.SUM_CATEGORY," & vbCrLf
        strSQL = strSQL & "PT1.BRAND_SUB," & vbCrLf
        strSQL = strSQL & "PT1.T_OP1," & vbCrLf
        strSQL = strSQL & "PT1.T_OP2," & vbCrLf
        strSQL = strSQL & "PT1.T_SIZE," & vbCrLf
        strSQL = strSQL & "PT1.NON_SBO," & vbCrLf
        strSQL = strSQL & "PT1.ADDITION_ITEM," & vbCrLf
        strSQL = strSQL & "PT1.TOPACS_CPNO," & vbCrLf
        strSQL = strSQL & "PT1.BRAND_AP_FORM," & vbCrLf
        strSQL = strSQL & "PT1.BRAND_AP_REQ," & vbCrLf
        strSQL = strSQL & "PT1.BRAND_AP_CONF," & vbCrLf
        strSQL = strSQL & "PT1.PATTERN_CD," & vbCrLf
        strSQL = strSQL & "PT1.PATTERN," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM01," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM02," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM03," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM04," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM05," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM06," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM07," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM08," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM09," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM10," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM11," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM12," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM13," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM14," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM15," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM16," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM17," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM18," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM19," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM20," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM22," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM23," & vbCrLf
        strSQL = strSQL & "PT1.PROD_ITEM24," & vbCrLf
        strSQL = strSQL & "PT2.WD_ANNT_DATE," & vbCrLf
        strSQL = strSQL & "PT2.WD_DATE," & vbCrLf
        strSQL = strSQL & "PT2.PRICE_CHG_DATE," & vbCrLf
        strSQL = strSQL & "PT2.QTY," & vbCrLf
        strSQL = strSQL & "PT2.INST_DATE," & vbCrLf
        strSQL = strSQL & "PT2.PAY_START_DATE," & vbCrLf
        strSQL = strSQL & "PT2.PAY_END_DATE," & vbCrLf
        strSQL = strSQL & "PT2.IGF_START_DATE," & vbCrLf
        strSQL = strSQL & "PT2.IGF_END_DATE," & vbCrLf
        strSQL = strSQL & "PT2.PAY_FLAG," & vbCrLf
        strSQL = strSQL & "PT2.BID_FLAG," & vbCrLf
        strSQL = strSQL & "PT2.PAY_MONTHS," & vbCrLf
        strSQL = strSQL & "PT2.VALID_CTRL," & vbCrLf
        strSQL = strSQL & "PT2.PAY_METHOD," & vbCrLf
        strSQL = strSQL & "PT2.IGF_APPLIED," & vbCrLf
        strSQL = strSQL & "PT2.IGF_CONT_NO," & vbCrLf
        strSQL = strSQL & "PT2.IGF_CONT_TYPE," & vbCrLf
        strSQL = strSQL & "PT2.IGF_PROPERTY," & vbCrLf
        strSQL = strSQL & "PT2.IGF_RATE_IOC," & vbCrLf
        strSQL = strSQL & "PT2.LIST_PRICE_PROPOSAL," & vbCrLf
        strSQL = strSQL & "PT2.LIST_PRICE," & vbCrLf
        strSQL = strSQL & "PT2.LIST_PRICE_TOTAL_PROPOSAL," & vbCrLf
        strSQL = strSQL & "PT2.LIST_PRICE_TOTAL," & vbCrLf
        strSQL = strSQL & "PT2.DP_IOC," & vbCrLf
        strSQL = strSQL & "PT2.PRICE_UNIT_IOC," & vbCrLf
        strSQL = strSQL & "PT2.PRICE_UNIT_IOC_VAL," & vbCrLf
        strSQL = strSQL & "PT2.PRICE_QTY_IOC," & vbCrLf
        strSQL = strSQL & "PT2.COST_RATE," & vbCrLf
        strSQL = strSQL & "PT2.COST," & vbCrLf
        strSQL = strSQL & "PT2.COST_TOTAL," & vbCrLf
        strSQL = strSQL & "PT2.COST_INPUT_DATE," & vbCrLf
        strSQL = strSQL & "PT2.PRICE_TO_SPLIT," & vbCrLf
        strSQL = strSQL & "PT2.LIST_PRICE_TOTAL_IOC," & vbCrLf
        strSQL = strSQL & "PT2.PRICE_TOTAL_IOC," & vbCrLf
        strSQL = strSQL & "PT2.COST_TOTAL_IOC," & vbCrLf
        strSQL = strSQL & "PT2.PRICE_IGF_TOTAL," & vbCrLf
        strSQL = strSQL & "PT2.PRICE_CONT_TOTAL," & vbCrLf
        strSQL = strSQL & "PT2.PRICE_OO_CONT_TOTAL," & vbCrLf
        strSQL = strSQL & "PT2.IGF_DIF_INTEREST, " & vbCrLf
        strSQL = strSQL & "PT2.PAST_PRICE_TOTAL " & vbCrLf
        '※現在CD_ACT_MAKEは使用していない
        If intKbn = CD_ACT_MAKE Then
            strSQL = strSQL & "FROM PaymentTBL1 PT1 INNER JOIN PaymentTBL2 PT2 ON PT1.ID = PT2.ID " & vbCrLf
            strSQL = strSQL & MakeSQLWhereNonLetterId() & vbCrLf
        Else
            '''' 処理：条件文ＳＱＬ作成処理(MakeExcelPaymentSQLFrom())を呼び出す
            strSQL = strSQL & MakeExcelPaymentSQLFrom() & vbCrLf
        End If
        '''' 処理：ソート順設定
        strSQL = strSQL & "ORDER BY PT1.LETTER_ID, PT1.ID"

        Debug.Print(strSQL)

        MakeExcelPaymentSQL = strSQL

    End Function

    ''' <summary>
    ''' 条件ＳＱＬ文作成処理
    ''' </summary>
    ''' <returns>条件ＳＱＬ文</returns>
    ''' <remarks>Payment出力データ取得(FROM以降)SQL</remarks>
    Private Function MakeExcelPaymentSQLFrom() As String

        MakeExcelPaymentSQLFrom = "FROM PaymentTBL2 PT2 INNER JOIN (PaymentTBL1 PT1 INNER JOIN FrmASRReadPaymentACT ACT ON PT1.LINE_NO = ACT.LINE_NO AND ((PT1.LETTER_ID IS NULL OR PT1.LETTER_ID='') AND ACT.LETTER_ID IS NOT NULL)) ON PT2.ID = PT1.ID"

    End Function

    ''' <summary>
    ''' 連携実行支援ファイル作成
    ''' </summary>
    ''' <param name="xlBooks">Booksｵﾌﾞｼﾞｪｸﾄ</param>
    ''' <param name="strSrcPath">実行支援ファイル保存先</param>
    ''' <param name="strSrcFileName">実行支援ファイル名</param>
    ''' <param name="blnOutputSheet">出力シートフラグ</param>
    ''' <param name="strErrMsg">エラーメッセージ</param>
    ''' <returns>True:正常、False:異常</returns>
    ''' <remarks></remarks>
    'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
    Private Function CreateActCooperation(ByRef xlBooks As Excel.Workbooks,
                                          ByVal strSrcPath As String,
                                          ByVal strSrcFileName As String,
                                          ByVal blnOutputSheet() As Boolean,
                                          ByRef strFileActOffer As String,
                                          ByRef strErrMsg As String) As Boolean
        'Private Function CreateActCooperation(ByRef xlBooks As Excel.Workbooks,
        '                              ByVal strSrcPath As String,
        '                              ByVal strSrcFileName As String,
        '                              ByVal blnOutputSheet() As Boolean,
        '                              ByRef strErrMsg As String) As Boolean
        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

        Dim strDestFileName As String
        'Excelオブジェクト
        Dim xlBook As Excel.Workbook = Nothing
        Dim xlSheets As Excel.Sheets = Nothing
        Dim xlSheet As Excel.Worksheet = Nothing

        CreateActCooperation = False

        Try
            '''' 条件：チェック判定
            '''' ケース：チェックが１つでもある場合、以下の処理を行う
            '1702 実行支援シート追加 str
            'If blnOutputSheet(CD_ACT_OUTPUT1) = True Or
            '    blnOutputSheet(CD_ACT_OUTPUT2) = True Or
            '    blnOutputSheet(CD_ACT_OUTPUT3) = True Or
            '    blnOutputSheet(CD_ACT_OUTPUT4) = True Then

            If blnOutputSheet(CD_ACT_OUTPUT1) = True Or
                blnOutputSheet(CD_ACT_OUTPUT2) = True Or
                blnOutputSheet(CD_ACT_OUTPUT3) = True Or
                blnOutputSheet(CD_ACT_OUTPUT4) = True Or
                blnOutputSheet(CD_ACT_OUTPUT5) = True Then
                '1702 実行支援シート追加 end

                '''' 処理：全ファイルを連携用にコピー
                strDestFileName = strSrcFileName.Replace("_全", "_連携")
                File.Copy(strSrcPath & strSrcFileName, strSrcPath & strDestFileName, True)

                '''' 処理：EXCEL OPEN
                xlBook = xlBooks.Open(strSrcPath & strDestFileName)
                xlSheets = xlBook.Worksheets
                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                strFileActOffer = strSrcPath & strDestFileName
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

                '''' 処理：該当シート削除
                '1702 実行支援シート追加 str
                'Dim strSheetName() As String = {STR_SHEET_NAME_ACT_1,
                '                                STR_SHEET_NAME_ACT_2,
                '                                STR_SHEET_NAME_ACT_3,
                '                                STR_SHEET_NAME_ACT_4}

                Dim strSheetName() As String = {STR_SHEET_NAME_ACT_1,
                                                STR_SHEET_NAME_ACT_2,
                                                STR_SHEET_NAME_ACT_3,
                                                STR_SHEET_NAME_ACT_4,
                                                STR_SHEET_NAME_ACT_5}
                '1702 実行支援シート追加 end
                For intCnt As Integer = 0 To blnOutputSheet.Length - 1
                    If blnOutputSheet(intCnt) = False Then
                        xlSheet = xlSheets.Item(strSheetName(intCnt))
                        xlSheet.Delete()
                        ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
                    End If
                Next

                '''' 処理：保存
                xlBook.Save()

                ''プロパティにファイル名を記載 str
                'Dim obj As Object
                'Dim fso As Object

                'fso = CreateObject("Scripting.FileSystemObject")
                'obj = GetObject(xlBook.Path & "\" & xlBook.Name)

                'obj.BuiltinDocumentProperties("Category") = xlBook.Name
                'obj.save()

                'obj = Nothing
                'fso = Nothing

                Dim properties As Object
                properties = xlBook.BuiltinDocumentProperties
                properties.Item("Category").value = xlBook.Name
                xlBook.Save()

                properties = Nothing
                ''プロパティにファイル名を記載 end

            End If

            CreateActCooperation = True

        Catch ex As Exception
            strErrMsg = ex.Message.ToString
        Finally
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBook) = False Then
                xlBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)

            '''' 処理：ｴﾗｰの場合、連携ファイル削除
            If CreateActCooperation = False Then
                File.Delete(strSrcPath & strDestFileName)
            End If

            ''ガベージコレクトの起動
            GC.Collect()

        End Try

    End Function

    ''' <summary>
    ''' 削除済みIDを取得
    ''' </summary>
    ''' <param name="con">MDBのコネクション</param>
    ''' <param name="arDelFlg">削除済みID</param>
    ''' <param name="strErrMsg">エラーメッセージ</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GeOutputtDuplicateId(ByVal con As OleDbConnection,
                                          ByRef arDelFlg As ArrayList,
                                          ByRef strErrMsg As String) As Boolean

        Dim strSQL As String
        Dim strSQLUpdate As String
        Dim cmd As New OleDbCommand
        Dim cmdUpdate As New OleDbCommand
        Dim dr As OleDbDataReader
        Dim drSelect As OleDbDataReader
        Dim strItem10No As String
        Dim strParentNo As String
        Dim strNowParentNo As String
        Dim strMyNo As String
        Dim arWhereIn As ArrayList
        Dim blnRet As Boolean

        GeOutputtDuplicateId = False

        Try
            cmd.Connection = con

            '''' 処理：DuplicateIdﾃｰﾌﾞﾙのﾃﾞｰﾀ削除
            strSQL = "DELETE FROM DuplicateId"
            cmd.CommandText = strSQL
            cmd.ExecuteNonQuery()

            '''' 処理：DuplicateIdﾃｰﾌﾞﾙにPaymentTBL1から必要なデータをInsert
            strSQL = ""
            strSQL = strSQL & "INSERT INTO DuplicateId (ID, VALID_FLAG, LINE_NO, PROD_ITEM10) " & vbCrLf
            strSQL = strSQL & "SELECT ID, VALID_FLAG, FORMAT(LINE_NO,'0000000000'), PROD_ITEM10 " & vbCrLf
            strSQL = strSQL & "FROM PaymentTBL1 " & vbCrLf
            strSQL = strSQL & "WHERE LOCK_FLAG='C' " & vbCrLf
            strSQL = strSQL & "AND (PATTERN_CD<>'0') " & vbCrLf
            strSQL = strSQL & "AND (PATTERN_CD<>'26') " & vbCrLf
            strSQL = strSQL & "AND (PATTERN_CD<>'28') " & vbCrLf
            strSQL = strSQL & "AND (PATTERN_CD<>'29') " & vbCrLf
            strSQL = strSQL & "AND (PATTERN_CD<>'30') " & vbCrLf
            strSQL = strSQL & "AND (PATTERN_CD<>'35') " & vbCrLf
            strSQL = strSQL & "AND (PATTERN_CD<>'36') " & vbCrLf
            strSQL = strSQL & "AND (PATTERN_CD<>'37') " & vbCrLf
            strSQL = strSQL & "AND (PATTERN_CD<>'38') " & vbCrLf
            strSQL = strSQL & "AND (PATTERN_CD<>'45') " & vbCrLf
            strSQL = strSQL & "AND (PATTERN_CD<>'46') " & vbCrLf
            strSQL = strSQL & "AND (PATTERN_CD<>'99') " & vbCrLf
            strSQL = strSQL & "AND (PATTERN NOT LIKE 'HW Brand Service%') " & vbCrLf
            strSQL = strSQL & "AND (PATTERN NOT LIKE '請求統合%') " & vbCrLf
            strSQL = strSQL & "AND (PATTERN NOT LIKE 'IGFAND (再ﾘｰｽ)%') " & vbCrLf
            strSQL = strSQL & "AND (PATTERN NOT LIKE 'ExcessTCV%') " & vbCrLf
            strSQL = strSQL & "AND (PATTERN<>'CIS') " & vbCrLf
            strSQL = strSQL & "AND (PATTERN<>'CIS 削除ﾃﾞｰﾀ') " & vbCrLf
            strSQL = strSQL & "AND (PATTERN NOT LIKE 'Primo使用サービス%') " & vbCrLf
            strSQL = strSQL & "AND (PATTERN NOT LIKE 'S&D RENTAL%') " & vbCrLf
            strSQL = strSQL & "AND (PATTERN NOT LIKE 'Allotment%') " & vbCrLf
            strSQL = strSQL & "AND (PATTERN NOT LIKE 'Variance Cash%') " & vbCrLf
            strSQL = strSQL & "AND VALID_FLAG='D' " & vbCrLf
            Debug.Print(strSQL)
            cmd.CommandText = strSQL
            cmd.ExecuteNonQuery()

            '''' 繰返し_開始	：項目１０にコピー元NO/削除元NOがあるもとに対して繰り返す
            cmdUpdate.Connection = con
            strSQL = ""
            strSQL = strSQL & "SELECT " & vbCrLf
            strSQL = strSQL & "ID, " & vbCrLf
            strSQL = strSQL & "PROD_ITEM10 " & vbCrLf
            strSQL = strSQL & "FROM DuplicateId " & vbCrLf
            strSQL = strSQL & "WHERE PROD_ITEM10 LIKE '" & ProdItem10_Value_CopyNo & "%' " & vbCrLf
            strSQL = strSQL & "or PROD_ITEM10 LIKE '" & ProdItem10_Value_DelNo & "%' " & vbCrLf
            cmd.CommandText = strSQL
            dr = cmd.ExecuteReader
            While dr.Read = True
                '''' 　条件：項目１０に削除元NO/コピー元NOがあるか判定
                '''' 　ケース：有る場合、削除元コピー元NOにNOで更新
                strItem10No = GetDbData(dr, "PROD_ITEM10")
                strItem10No = GetItem10No(strItem10No)
                If strItem10No <> "" Then
                    strSQLUpdate = ""
                    strSQLUpdate = strSQLUpdate & "UPDATE " & vbCrLf
                    strSQLUpdate = strSQLUpdate & "DuplicateId " & vbCrLf
                    strSQLUpdate = strSQLUpdate & "SET Item10NO = '" & strItem10No & "' " & vbCrLf
                    strSQLUpdate = strSQLUpdate & "WHERE ID='" & GetDbData(dr, "ID") & "' " & vbCrLf
                    cmdUpdate.CommandText = strSQLUpdate
                    cmdUpdate.ExecuteNonQuery()
                End If
            End While
            dr.Close()
            '''' 繰返し_終了	：

            '''' 繰返し_開始	：削除元コピー元にNOがあるものに対して繰り返す
            strSQL = ""
            strSQL = strSQL & "SELECT * FROM DuplicateId " & vbCrLf
            strSQL = strSQL & "WHERE Item10NO IS NOT NULL " & vbCrLf
            strSQL = strSQL & "ORDER BY ID"
            cmd.CommandText = strSQL
            dr = cmd.ExecuteReader
            While dr.Read = True
                strItem10No = GetDbData(dr, "Item10NO")

                '''' 処理：自分レコードの削除元コピー元NOから削除元コピー元NOと親NOが空白のNOを検索
                ''''       一致レコードがある場合、一致したレコードの親NOに自分レコードの削除元コピー元NOで更新
                strSQLUpdate = ""
                strSQLUpdate = strSQLUpdate & "UPDATE DuplicateId" & vbCrLf
                strSQLUpdate = strSQLUpdate & "SET ParentNO='" & strItem10No & "' " & vbCrLf
                strSQLUpdate = strSQLUpdate & "WHERE LINE_NO='" & strItem10No & "' " & vbCrLf
                strSQLUpdate = strSQLUpdate & "AND Item10NO IS NULL " & vbCrLf
                strSQLUpdate = strSQLUpdate & "AND ParentNO IS NULL " & vbCrLf
                cmdUpdate.CommandText = strSQLUpdate
                cmdUpdate.ExecuteNonQuery()

                '''' 処理：自分レコードの親NOが空白の場合、自分レコードの親NOを自分レコードの削除元コピー元で更新
                ''''       ※親NOが更新されている可能性があるため新たに親NOを取得する
                strParentNo = GetParentNo(con, GetDbData(dr, "ID"))
                If strParentNo = "" Then
                    strSQLUpdate = ""
                    strSQLUpdate = strSQLUpdate & "UPDATE DuplicateId " & vbCrLf
                    strSQLUpdate = strSQLUpdate & "SET ParentNO='" & strItem10No & "' " & vbCrLf
                    strSQLUpdate = strSQLUpdate & "WHERE ID='" & GetDbData(dr, "ID") & "' " & vbCrLf
                    cmdUpdate.CommandText = strSQLUpdate
                    cmdUpdate.ExecuteNonQuery()
                    strParentNo = strItem10No
                End If

                '''' 処理：自分レコードのNOを元に削除元コピー元を検索
                ''''       一致レコードの親NOに自分レコードの親NOで更新
                strMyNo = GetDbData(dr, "LINE_NO")
                strSQLUpdate = ""
                strSQLUpdate = strSQLUpdate & "UPDATE DuplicateId " & vbCrLf
                strSQLUpdate = strSQLUpdate & "SET ParentNO='" & strParentNo & "' " & vbCrLf
                strSQLUpdate = strSQLUpdate & "WHERE Item10NO='" & strMyNo & "' " & vbCrLf
                cmdUpdate.CommandText = strSQLUpdate
                cmdUpdate.ExecuteNonQuery()
            End While
            dr.Close()
            '''' 繰返し_終了	：

            '親NOが同じIDを取得
            '''' 繰返し_開始	：Statusが「D」且つ親NOがあるデータを繰り返す
            strSQL = ""
            strSQL = strSQL & "SELECT " & vbCrLf
            strSQL = strSQL & "ID, ParentNo " & vbCrLf
            strSQL = strSQL & "FROM DuplicateId " & vbCrLf
            strSQL = strSQL & "WHERE ParentNo IS NOT NULL " & vbCrLf
            strSQL = strSQL & "AND VALID_FLAG='D' " & vbCrLf
            strSQL = strSQL & "ORDER BY ParentNo, ID " & vbCrLf
            Debug.Print(strSQL)
            cmd.CommandText = strSQL
            dr = cmd.ExecuteReader
            strParentNo = ""
            arWhereIn = New ArrayList
            While dr.Read = True
                '''' 　処理：親NOを取得
                strNowParentNo = GetDbData(dr, "ParentNo")
                '''' 　条件：親NOと前親NOが異なるか判定
                '''' 　ケース：異なる場合、以下の処理を行う
                If strParentNo <> strNowParentNo Then
                    '''' 　　処理：月額金額打ち消しあいデータ削除FLG更新処理(UpdateDelFlg())
                    blnRet = UpdateDelFlg(con, arWhereIn)
                    If blnRet = False Then
                        Exit Function
                    End If
                    arWhereIn = New ArrayList
                End If
                strParentNo = strNowParentNo
                arWhereIn.Add(GetDbData(dr, "ID"))
            End While
            dr.Close()
            '''' 繰返し_終了	：

            '''' 処理：月額金額打ち消しあいデータ削除FLG更新処理(UpdateDelFlg())
            blnRet = UpdateDelFlg(con, arWhereIn)
            If blnRet = False Then
                Exit Function
            End If

            '''' 処理：削除済みIDを取得
            strSQL = "SELECT ID FROM DuplicateId WHERE DelFlg='1'"
            cmd.CommandText = strSQL
            dr = cmd.ExecuteReader
            While dr.Read = True
                arDelFlg.Add(GetDbData(dr, "ID"))
            End While
            dr.Close()

            GeOutputtDuplicateId = True

        Catch ex As Exception
            strErrMsg = ex.Message.ToString & "(GeOutputtDuplicateId)"
        Finally

        End Try

    End Function

    ''' <summary>
    ''' 月額金額打ち消しあいデータ削除FLG更新
    ''' </summary>
    ''' <param name="con"></param>
    ''' <param name="arWhereIn"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function UpdateDelFlg(ByVal con As OleDbConnection,
                                  ByVal arWhereIn As ArrayList) As Boolean

        Dim blnZero As Boolean
        Dim strWhereIn As String
        Dim strSQL As String
        Dim strSQLUpdate As String
        Dim cmd As New OleDbCommand
        Dim cmdUpdate As New OleDbCommand
        Dim dr As OleDbDataReader

        UpdateDelFlg = False

        Try
            '''' 条件：該当するIDがあるか判定
            '''' ケース：IDがある場合、以下の処理を行う
            If arWhereIn.Count > 0 Then
                '''' 　処理：IDに該当する年毎に各月額を合計し、それらを１つにした値を取得する
                '''' 　条件：年毎の合計が全て０か判定
                '''' 　ケース：合計が０の場合、該当するIDでDuplicateIdﾃｰﾌﾞﾙの削除FLGを１で更新する
                strWhereIn = ""
                For intCnt As Integer = 0 To arWhereIn.Count - 1
                    strWhereIn = strWhereIn & "'" & arWhereIn(intCnt) & "',"
                Next
                strWhereIn = strWhereIn.Substring(0, strWhereIn.Length - 1)
                strSQL = ""
                strSQL = strSQL & "SELECT " & vbCrLf
                strSQL = strSQL & "IOC_YEAER, " & vbCrLf
                strSQL = strSQL & "sum(IOC_01) + " & vbCrLf
                strSQL = strSQL & "sum(IOC_02) + " & vbCrLf
                strSQL = strSQL & "sum(IOC_03) + " & vbCrLf
                strSQL = strSQL & "sum(IOC_04) + " & vbCrLf
                strSQL = strSQL & "sum(IOC_05) + " & vbCrLf
                strSQL = strSQL & "sum(IOC_06) + " & vbCrLf
                strSQL = strSQL & "sum(IOC_07) + " & vbCrLf
                strSQL = strSQL & "sum(IOC_08) + " & vbCrLf
                strSQL = strSQL & "sum(IOC_09) + " & vbCrLf
                strSQL = strSQL & "sum(IOC_10) + " & vbCrLf
                strSQL = strSQL & "sum(IOC_11) + " & vbCrLf
                strSQL = strSQL & "sum(IOC_12) AS SumTotal " & vbCrLf
                strSQL = strSQL & "FROM (" & vbCrLf
                strSQL = strSQL & "    SELECT " & vbCrLf
                strSQL = strSQL & "    IOC_YEAER, " & vbCrLf
                strSQL = strSQL & "    IOC_01, " & vbCrLf
                strSQL = strSQL & "    IOC_02, " & vbCrLf
                strSQL = strSQL & "    IOC_03, " & vbCrLf
                strSQL = strSQL & "    IOC_04, " & vbCrLf
                strSQL = strSQL & "    IOC_05, " & vbCrLf
                strSQL = strSQL & "    IOC_06, " & vbCrLf
                strSQL = strSQL & "    IOC_07, " & vbCrLf
                strSQL = strSQL & "    IOC_08, " & vbCrLf
                strSQL = strSQL & "    IOC_09, " & vbCrLf
                strSQL = strSQL & "    IOC_10, " & vbCrLf
                strSQL = strSQL & "    IOC_11, " & vbCrLf
                strSQL = strSQL & "    IOC_12 " & vbCrLf
                strSQL = strSQL & "    FROM PaymentTBL3 " & vbCrLf
                strSQL = strSQL & "    WHERE ID IN (" & strWhereIn & ") " & vbCrLf
                strSQL = strSQL & ")" & vbCrLf
                strSQL = strSQL & "GROUP BY IOC_YEAER " & vbCrLf
                strSQL = strSQL & "ORDER BY IOC_YEAER " & vbCrLf
                Debug.Print(strSQL)
                cmd.Connection = con
                cmd.CommandText = strSQL
                dr = cmd.ExecuteReader
                blnZero = True
                While dr.Read = True
                    If Long.Parse(GetDbData(dr, "SumTotal")) > 0 Then
                        blnZero = False
                        Exit While
                    End If
                End While
                If blnZero = True Then
                    strSQLUpdate = ""
                    strSQLUpdate = strSQLUpdate & "UPDATE DuplicateId " & vbCrLf
                    strSQLUpdate = strSQLUpdate & "SET DelFlg='1' " & vbCrLf
                    strSQLUpdate = strSQLUpdate & "WHERE ID IN (" & strWhereIn & ")" & vbCrLf
                    Debug.Print(strSQLUpdate)
                    cmdUpdate.Connection = con
                    cmdUpdate.CommandText = strSQLUpdate
                    cmdUpdate.ExecuteNonQuery()
                End If
                dr.Close()
            End If

            UpdateDelFlg = True

        Catch ex As Exception
            Throw ex
        End Try

    End Function

    ''' <summary>
    ''' 親NO取得
    ''' </summary>
    ''' <param name="con">MDBのコネクション</param>
    ''' <param name="strId">ID</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetParentNo(ByVal con As OleDbConnection, ByVal strId As String) As String

        Dim cmd As New OleDbCommand
        Dim dr As OleDbDataReader

        GetParentNo = ""

        Try
            '''' 処理：該当IDでDuplicateIdﾃｰﾌﾞﾙの親NOを取得
            cmd.Connection = con
            cmd.CommandText = "SELECT ParentNo FROM DuplicateId WHERE ID='" & strId & "'"
            dr = cmd.ExecuteReader

            While dr.Read = True
                GetParentNo = GetDbData(dr, "ParentNo")
                Exit While
            End While
            dr.Close()

        Catch ex As Exception
            Throw ex
        End Try
    End Function

    ''' <summary>
    ''' 機能：
    ''' </summary>
    ''' <param name="Item10">項目10の元データ</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetItem10No(ByVal Item10 As String) As String

        ''初期化
        GetItem10No = ""

        ''OKな文言をセット
        Dim OKList As New ArrayList
        OKList.Add("*一部削除")
        OKList.Add("* 一部削除")

        ''Copy元No/削除元Noの削除
        Dim rtnNo As String
        Dim chkValue As String
        rtnNo = Item10
        chkValue = Item10
        If chkValue.IndexOf(ProdItem10_Value_DelNo) = 0 Then
            chkValue = chkValue.Replace(ProdItem10_Value_DelNo, "").Trim
        ElseIf chkValue.IndexOf(ProdItem10_Value_CopyNo) = 0 Then
            chkValue = chkValue.Replace(ProdItem10_Value_CopyNo, "").Trim
        Else
            Exit Function
        End If
        Dim intPos As Integer
        intPos = chkValue.IndexOf("_")
        If intPos <> -1 Then
            chkValue = chkValue.Substring(0, intPos)
        End If
        rtnNo = chkValue

        ''先頭1文字が文字の場合、NG
        If chkNumeric(chkValue.Substring(0, 1)) = False Then
            Exit Function
        End If

        ''OK文言
        For Each OKWord As String In OKList
            If chkValue.IndexOf(OKWord) <> -1 Then
                chkValue = chkValue.Replace(OKWord, "").Trim
                rtnNo = chkValue
            End If
        Next

        ''文字のチェック
        If chkNumeric(chkValue) = False Then
            Exit Function
        End If

        ''戻り値
        Return rtnNo.PadLeft(10, "0")

    End Function

    ''' <summary>
    ''' 機能：文字列の存在ﾁｪｯｸ
    ''' 説明：※IsNumericだと指数表現等を数値と判定するため、On Code
    ''' </summary>
    ''' <remarks></remarks>
    Private Function chkNumeric(ByVal value As String) As Boolean

        ''初期化
        chkNumeric = True
        Dim chkChar As String
        For i As Integer = 1 To value.Length
            chkChar = value.Substring(i - 1, 1)
            Select Case chkChar
                Case "0", _
                     "1", _
                     "2", _
                     "3", _
                     "4", _
                     "5", _
                     "6", _
                     "7", _
                     "8", _
                     "9"
                Case Else
                    chkNumeric = False
                    Exit Function
            End Select
        Next
    End Function

    Private Function GetFuturePaymentZero(ByVal con As OleDbConnection,
                                          ByVal strId As String,
                                          ByVal dtNow As Date) As Boolean

        Dim strSQL As String
        Dim cmd As New OleDbCommand
        Dim dr As OleDbDataReader
        Dim lngTotal As Long = 0
        Dim strWork As String

        GetFuturePaymentZero = False

        Try
            cmd.Connection = con

            strSQL = ""
            strSQL = strSQL & "SELECT " & vbCrLf
            strSQL = strSQL & "IOC_YEAER, " & vbCrLf
            strSQL = strSQL & "sum(IOC_01) AS Sum01, " & vbCrLf
            strSQL = strSQL & "sum(IOC_02) AS Sum02, " & vbCrLf
            strSQL = strSQL & "sum(IOC_03) AS Sum03, " & vbCrLf
            strSQL = strSQL & "sum(IOC_04) AS Sum04, " & vbCrLf
            strSQL = strSQL & "sum(IOC_05) AS Sum05, " & vbCrLf
            strSQL = strSQL & "sum(IOC_06) AS Sum06, " & vbCrLf
            strSQL = strSQL & "sum(IOC_07) AS Sum07, " & vbCrLf
            strSQL = strSQL & "sum(IOC_08) AS Sum08, " & vbCrLf
            strSQL = strSQL & "sum(IOC_09) AS Sum09, " & vbCrLf
            strSQL = strSQL & "sum(IOC_10) AS Sum10, " & vbCrLf
            strSQL = strSQL & "sum(IOC_11) AS Sum11, " & vbCrLf
            strSQL = strSQL & "sum(IOC_12) AS Sum12  " & vbCrLf
            strSQL = strSQL & "FROM (" & vbCrLf
            strSQL = strSQL & "    SELECT " & vbCrLf
            strSQL = strSQL & "    IOC_YEAER, " & vbCrLf
            strSQL = strSQL & "    IOC_01, " & vbCrLf
            strSQL = strSQL & "    IOC_02, " & vbCrLf
            strSQL = strSQL & "    IOC_03, " & vbCrLf
            strSQL = strSQL & "    IOC_04, " & vbCrLf
            strSQL = strSQL & "    IOC_05, " & vbCrLf
            strSQL = strSQL & "    IOC_06, " & vbCrLf
            strSQL = strSQL & "    IOC_07, " & vbCrLf
            strSQL = strSQL & "    IOC_08, " & vbCrLf
            strSQL = strSQL & "    IOC_09, " & vbCrLf
            strSQL = strSQL & "    IOC_10, " & vbCrLf
            strSQL = strSQL & "    IOC_11, " & vbCrLf
            strSQL = strSQL & "    IOC_12 " & vbCrLf
            strSQL = strSQL & "    FROM PaymentTBL3 " & vbCrLf
            strSQL = strSQL & "    WHERE ID='" & strId & "' " & vbCrLf
            strSQL = strSQL & "    AND " & dtNow.ToString("yyyy") & "<=CINT(IOC_YEAER) " & vbCrLf
            strSQL = strSQL & ")" & vbCrLf
            strSQL = strSQL & "GROUP BY IOC_YEAER " & vbCrLf
            strSQL = strSQL & "ORDER BY IOC_YEAER " & vbCrLf
            Debug.Print(strSQL)
            cmd.CommandText = strSQL
            dr = cmd.ExecuteReader
            While dr.Read = True
                For intMonthCnt As Integer = 1 To 12
                    strWork = GetDbData(dr, "IOC_YEAER") & intMonthCnt.ToString("00")
                    If Integer.Parse(strWork) >= Integer.Parse(dtNow.ToString("yyyyMM")) Then
                        lngTotal = lngTotal + Long.Parse(GetDbData(dr, "Sum" & intMonthCnt.ToString("00")))
                    End If
                Next
            End While
            dr.Close()

            If lngTotal = 0 Then
                GetFuturePaymentZero = True
            End If

        Catch ex As Exception
            Throw ex

        End Try

    End Function
#End Region

#Region "ﾃﾞﾘﾊﾞﾘ関連"
    ''' <summary>
    ''' 契約締結済みMDBからMAX件数を取得する。
    ''' </summary>
    ''' <param name="strContractMDBPath">MDBパス</param>
    ''' <returns>件数</returns>
    ''' <remarks></remarks>
    Private Function GetMaxMdbCount(ByVal strContractMDBPath As String) As Integer

        ''初期化
        GetMaxMdbCount = 0

        Try
            '''' 処理：接続情報設定
            Dim ofm As New OioFileManage
            Dim con As New OleDbConnection
            Dim conStr As New StringBuilder


            '''' 処理：接続情報設定
            Dim mmc As New MasterMdbControl
            con = mmc.GetOleTmpDBConnection(CommonVariable.CPNO, CommonVariable.MdbPW)

            '2018/10/18 MDB無しエラー回避 str
            If IsNothing(con) = True Then
                Exit Function
            End If
            '2018/10/18 MDB無しエラー回避 end


            '''' 処理：抽出条件作成
            '''' 　　　select count(id) from PaymentTBL1
            Dim dr As OleDbDataReader
            Dim cmd As New OleDbCommand()
            Dim sqlCountRec As New StringBuilder
            sqlCountRec.Append(CommonConstant.SQL_STR_SELECT)
            sqlCountRec.Append(CommonConstant.SQL_STR_COUNT)
            sqlCountRec.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            sqlCountRec.Append("ID")
            sqlCountRec.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
            sqlCountRec.Append(CommonConstant.SQL_STR_FROM)
            sqlCountRec.Append("PaymentTBL1")
            cmd.Connection = con
            cmd.CommandText = sqlCountRec.ToString


            '''' 処理：データ抽出
            Dim MaxCount As Integer
            dr = cmd.ExecuteReader()
            If dr.Read() = True Then
                MaxCount = dr.Item(0)
            End If
            dr.Close()
            con.Close()

            Return MaxCount

        Catch ex As Exception
            Throw ex
        End Try

    End Function

    ''' <summary>
    ''' テンプレートファイルを出力ファイル数コピーし、申請ファイルを作成
    ''' </summary>
    ''' <param name="outFilePath"></param>
    ''' <param name="TmpPSFilePath"></param>
    ''' <param name="MaxSheetLine"></param>
    ''' <param name="MaxMdbCount"></param>
    ''' <param name="intPaymentPeriod"></param>
    ''' <param name="intOutPsCnt"></param>
    ''' <param name="intOutSerialCnt"></param>
    ''' <remarks></remarks>
    Private Sub CreateOutSheet(ByRef outFilePath As ArrayList, _
                               ByVal TmpPSFilePath As String, _
                               ByVal MaxSheetLine As String, _
                               ByVal MaxMdbCount As Integer, _
                               ByVal intPaymentPeriod As Integer,
                               ByRef intOutPsCnt As Integer, _
                               ByRef intOutSerialCnt As Integer)


        ''Excelオブジェクトの宣言
        Dim xlApp As New Excel.Application
        'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
        Dim xlBooks As Excel.Workbooks
        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
        Dim xlOutBook As Excel.Workbook
        Dim xlPSBook As Excel.Workbook
        Dim xlWS1Sheet As Excel.Worksheet
        Dim xlOIOSheet As Excel.Worksheet
        Dim xlOutSerialSheet As Excel.Worksheet
        Dim xlOutPSSheet As Excel.Worksheet
        Dim xlChkSheet As Excel.Worksheet
        Dim xlCopyRange As Excel.Range              ''契約期間内/外のコピペに使用
        Dim xlPasteRange As Excel.Range             ''契約期間内/外のコピペに使用
        Dim xlCell As Excel.Range
        Dim con As New OleDbConnection
        Dim ReaderTBL1 As OleDbDataReader
        Dim ReaderTBL2 As OleDbDataReader
        Dim ReaderTBL3 As OleDbDataReader

        Try
            '''' 処理：Excelｵﾌﾞｼﾞｪｸﾄの初期設定		
            xlApp.DisplayAlerts = False
            xlApp.EnableEvents = False
            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            xlBooks = xlApp.Workbooks
            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

            '''' 処理：分割ファイル名が無くなるまでTemplateをコピーする
            Dim i As Integer
            For i = 1 To outFilePath.Count
                File.Copy(TmpPSFilePath, outFilePath.Item(i - 1), True)
            Next

            '''' 条件：データ件数判定
            '''' ケース：データ件数=0件なら、処理を終了する。
            If MaxMdbCount = 0 Then
                Exit Sub
            End If

            '''' 処理：WS1シートコピー用にPayment.xlsのPathを取得
            Dim ofm As New OioFileManage
            Dim paymentBookPath As String
            paymentBookPath = ofm.GetLocalTemplateFolder & EXCEL_PAYMNETSAMPLE_FILENAME
            If File.Exists(paymentBookPath) = False Then
                Throw New Exception(FileReader.GetMessage("MSG_0334"))
            End If

            ''分割ファイルのOioシートを作成する。
            ''※現在分割する仕様は保留中のため、必ずCountは1がセットされている。
            intOutPsCnt = 0
            intOutSerialCnt = 0
            Dim j As Integer
            '''' 繰返し_開始：分割ファイル名がなくなるまで
            For j = 1 To outFilePath.Count
                '''' 　処理：シートのセット
                Const SerialSheetNM As String = "ｼﾘｱﾙ"
                Const PSSheetNM As String = "Payment"
                Const ChkSheetNM As String = "入力ﾁｪｯｸ"
                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                xlOutBook = xlBooks.Open(outFilePath.Item(j - 1))
                'xlOutBook = xlApp.Workbooks.Open(outFilePath.Item(j - 1))
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                xlApp.Calculation = Excel.XlCalculation.xlCalculationManual

                xlOutSerialSheet = xlOutBook.Worksheets(SerialSheetNM)
                xlOutPSSheet = xlOutBook.Worksheets(PSSheetNM)
                xlChkSheet = xlOutBook.Worksheets(ChkSheetNM)

                '''' 　処理：サンプルからWS1をコピー
                Dim cws1 As New CreateWS1
                Dim xlTmpBook As Excel.Workbook
                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                xlTmpBook = xlBooks.Open(paymentBookPath)
                'xlTmpBook = xlApp.Workbooks.Open(paymentBookPath)
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                xlWS1Sheet = xlTmpBook.Worksheets(SHEET_NAME_WS1)
                Call xlWS1Sheet.Copy(Before:=xlOutSerialSheet)
                ExcelObjRelease.ReleaseExcelObj(xlWS1Sheet, ExcelObjRelease.OBJECT_NOTHING)
                xlTmpBook.Close()
                ExcelObjRelease.ReleaseExcelObj(xlTmpBook, ExcelObjRelease.OBJECT_NOTHING)

                '''' 　処理：WS1作成処理(CreateWS1.WS1の作成)を呼び出す
                Dim msg As String
                Dim pw As String
                pw = CommonVariable.PaymentPW
                Call cws1.WS1の作成(xlOutBook,
                                    intPaymentPeriod,
                                    pw)

                '''' 　処理：各ｼｰﾄに必要な初期値をセット
                Dim xlWS1 As Excel.Worksheet = Nothing
                xlWS1 = xlOutBook.Worksheets(SHEET_NAME_WS1)
                Call InitSheetDataAll(xlWS1,
                                      xlOutSerialSheet,
                                      xlOutPSSheet,
                                      xlChkSheet)
                '1680 str
                '                ExcelObjRelease.ReleaseExcelObj(xlWS1, ExcelObjRelease.OBJECT_NOTHING)
                '1680 end

                '''' 　処理：接続情報設定
                Dim mmc As New MasterMdbControl
                con = mmc.GetOleTmpDBConnection(CommonVariable.CPNO, CommonVariable.MdbPW)

                '''' 　処理：PaymentTBL1～PaymentTBL3 のﾃﾞｰﾀ取得
                '''' 　　　　GetMdbTblDate()を呼び出す
                Dim TBL1 As DataTable
                Dim TBL2 As DataTable
                Dim TBL3 As DataTable
                Call GetMdbTblDate(con, TBL1, TBL2, TBL3)

                '''' 　処理：削除ﾃﾞｰﾀのIDを取得する
                ''''   　    DelPaymentTBLDFlg2()を呼び出す
                Dim DelRowList As New ArrayList
                Call DelPaymentTBLDFlg2(DelRowList, TBL1, TBL2, TBL3)

                ''契約MDBの値をｼﾘｱﾙシートに書き出す
                Dim DistinctSerialTBL As New DataTable              ''重複している仮シリアルを判定する。
                DistinctSerialTBL.Columns.Add("Cell" & SerialSheetColumns.PATTERN_CD)
                DistinctSerialTBL.Columns.Add("Cell" & SerialSheetColumns.PROD_TmpSerial)
                DistinctSerialTBL.Columns.Add("Cell" & SerialSheetColumns.LINE_NO)
                DistinctSerialTBL.Columns.Add("Cell" & SerialSheetColumns.PROD_ITEM01)
                Dim OutSerialArrayList As New ArrayList              ''まとめて貼り付け処理をするために、ArrayListに保持
                Dim OutPSArrayList As New ArrayList                  ''まとめて貼り付け処理をするために、ArrayListに保持
                Dim OutSerialXlsCellInfo(,) As Object                ''Serialシート1行分の貼り付け情報
                Dim OutPSXlsCellInfo(,) As Object                    ''Paymentシート1行分の貼り付け情報
                '''' 　繰返し_開始：PaymentTBL1のデータがなくなるまで
                For intIndex As Integer = 0 To TBL1.Rows.Count - 1

                    If DelRowList.IndexOf(ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("ID"))) = -1 Then
                        '''' 　　処理：PaymentTBL1～3のSerialシート1行分情報を配列に格納
                        OutSerialXlsCellInfo = GetSerialCreateData(intIndex, TBL1, TBL2, TBL3)

                        '''' 　　処理：Serialシート1行分情報をPaymentシート1行分のデータに移し替える。
                        '''' 　　　　　※SerialシートとPaymentシートの項目値はほとんど同じため、コピーする
                        OutPSXlsCellInfo = GetPSCreateData(OutSerialXlsCellInfo)

                        '''' 　　処理：AAS HWが存在しなくても、ｼﾘｱﾙ情報を出力する。
                        '''' 　　条件：出力対象外かどうか判定(Serialシート)
                        '''' 　　ケース：出力対象の場合、以下の処理を行う
                        '1680 str
                        If ChkSerialSheetOutPut(OutSerialXlsCellInfo, xlWS1) Then
                            'If ChkSerialSheetOutPut(OutSerialXlsCellInfo) Then
                            '1680 end

                            ''''       処理：SWの場合、項目１に項目４をセットする
                            Call CheckPatternChangeItem01(OutSerialXlsCellInfo)

                            '''' 　　　処理：重複チェック用のデータを追加
                            Call SetDistinctSerialTBL(DistinctSerialTBL, OutSerialXlsCellInfo)

                            '''' 　　　処理：Serialシート出力用データの追加
                            Call OutSerialArrayList.Add(OutSerialXlsCellInfo)
                        End If

                        '''' 　　条件：出力対象外かどうか判定(Paymentシート)
                        '''' 　　ケース：出力対象の場合、以下の処理を行う
                        If ChkPSSheetOutPut(OutPSXlsCellInfo) Then
                            '''' 　　処理：Paymentシートの書込用データの追加
                            Call OutPSArrayList.Add(OutPSXlsCellInfo)
                            intOutPsCnt = intOutPsCnt + 1
                        End If
                    End If
                Next
                '1680 str
                ExcelObjRelease.ReleaseExcelObj(xlWS1, ExcelObjRelease.OBJECT_NOTHING)
                '1680 end
                '''' 　繰返し_終了:

                '''' 　処理：削除ﾃﾞｰﾀ(削除ﾃﾞｰﾀ作成で作成されるﾃﾞｰﾀ)を削除する。
                ''''　　　※重複したデータを削除
                Call DelDistinctSerialDate(DistinctSerialTBL, OutSerialArrayList)

                '''' 　処理：ｼﾘｱﾙシートの書き込み。
                If OutSerialArrayList.Count <> 0 Then
                    Call SetSerialSheet(OutSerialArrayList, xlOutSerialSheet)
                    intOutSerialCnt = OutSerialArrayList.Count
                End If

                '''' 　処理：Paymentシートの書き込み。
                If OutPSArrayList.Count <> 0 Then
                    Call SetPSSheet(OutPSArrayList, OutSerialArrayList, xlOutPSSheet)
                End If

                '''' 　処理：PaymentｼｰﾄのPayment展開期間分列削除
                Call ExcelWrite.CreatePaymentPeriod(xlOutPSSheet,
                                                    ExcelWrite.chgExcelColumnIdxToChar(PaymentSheetColumns.PRICE_YEAR1_MONTH1),
                                                    intPaymentPeriod)

                '''' 　不要項目削除処理(DeleteUnnecessaryColum())を呼び出す
                Call DeleteUnnecessaryColum(xlOutSerialSheet, xlOutPSSheet)

                '''' 　処理：NOを保護する
                Call ExcelSheetProtect(xlApp, xlOutBook.Name)

                'Payment展開期間分列削除
                '''' 　処理：カーソル位置設定（ｼﾘｱﾙ：A1、Payment:A1）
                xlOutPSSheet.Activate()
                xlCell = xlOutPSSheet.Range("A1")
                xlCell.Select()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                xlOutSerialSheet.Activate()
                xlCell = xlOutSerialSheet.Range("A1")
                xlCell.Select()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

                '''' 　処理：保存してBookを閉じる
                xlApp.Calculation = Excel.XlCalculation.xlCalculationAutomatic
                xlOutBook.Save()

                ''プロパティにファイル名を記載 str
                'Dim obj As Object
                'Dim fso As Object

                'fso = CreateObject("Scripting.FileSystemObject")
                'obj = GetObject(xlOutBook.Path & "\" & xlOutBook.Name)

                'obj.BuiltinDocumentProperties("Category") = xlOutBook.Name
                'obj.save()

                'obj = Nothing
                'fso = Nothing

                Dim properties As Object
                properties = xlOutBook.BuiltinDocumentProperties
                properties.Item("Category").value = xlOutBook.Name
                xlOutBook.Save()

                properties = Nothing
                ''プロパティにファイル名を記載 end

                xlOutBook.Close()

                If IsNothing(xlPSBook) = False Then
                    xlPSBook.Close()
                End If
                xlApp.EnableEvents = True
                xlApp.DisplayAlerts = True

            Next

        Catch ex As Exception
            Throw ex

        Finally
            If IsNothing(ReaderTBL1) = False AndAlso ReaderTBL1.IsClosed = False Then
                ReaderTBL1.Close()
            End If
            If IsNothing(ReaderTBL2) = False AndAlso ReaderTBL2.IsClosed = False Then
                ReaderTBL2.Close()
            End If
            If IsNothing(ReaderTBL3) = False AndAlso ReaderTBL3.IsClosed = False Then
                ReaderTBL3.Close()
            End If
            If con.State = ConnectionState.Open Then
                con.Close()
            End If

            ExcelObjRelease.ReleaseExcelObj(xlCopyRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPasteRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlWS1Sheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlOIOSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlOutSerialSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlOutPSSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlChkSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlOutBook, ExcelObjRelease.OBJECT_NOTHING)
            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            ExcelObjRelease.ReleaseExcelObj(xlBooks, ExcelObjRelease.OBJECT_NOTHING)
            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            xlApp.Quit()
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' ﾃﾞﾘﾊﾞﾘﾌｧｲﾙ作成時、ｼｰﾄに必要な初期設定を行う（一括用）
    ''' </summary>
    ''' <param name="xlWS1Sheet"></param>
    ''' <param name="xlOutSerialSheet"></param>
    ''' <param name="xlOutPSSheet"></param>
    ''' <param name="xlChkSheet"></param>
    ''' <remarks>CreateOutSheetの処理量が増えてきたため、一部処理を関数化</remarks>
    Private Sub InitSheetDataAll(ByVal xlWS1Sheet As Excel.Worksheet, _
                                 ByRef xlOutSerialSheet As Excel.Worksheet, _
                                 ByRef xlOutPSSheet As Excel.Worksheet, _
                                 ByRef xlChkSheet As Excel.Worksheet)

        Dim xlCell As Excel.Range = Nothing
        Dim strYear As String
        Dim objExcel(5, 1)
        Dim objTerm(240) As Object
        Dim intCnt As Integer
        Dim dtWork As Date
        Dim dtStart As Date
        Dim dtEnd As Date

        Try
            'WS1 契約開始年月・契約開始年月・契約終了年月 取得
            xlCell = xlWS1Sheet.Range("F7:H7")
            objExcel = xlCell.Value
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            '契約開始年月取得
            dtStart = objExcel(1, 1)
            '契約終了年月取得(末日)
            dtEnd = objExcel(1, 2)
            dtEnd = (dtEnd.AddMonths(1)).AddDays(-1)
            'Payment出力 開始年 取得
            strYear = objExcel(1, 3).ToString

            '契約期間内外設定
            For intCnt = 0 To 239
                dtWork = CDate(strYear & "/1/1").AddMonths(intCnt)
                If dtWork >= dtStart And dtWork <= dtEnd Then
                    objTerm(intCnt) = "契約期間内"
                Else
                    objTerm(intCnt) = "契約期間外"
                End If
            Next

            '-------------------------------------------------
            'ｼﾘｱﾙシート
            '-------------------------------------------------
            'Payment出力 開始年書込
            xlCell = xlOutSerialSheet.Range("DH9")
            xlCell.Value = strYear
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            '契約期間内外書込
            xlCell = xlOutSerialSheet.Range("DH8:MM8")
            xlCell.Value = objTerm
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            '-------------------------------------------------
            'Paymentシート
            '-------------------------------------------------
            'Payment出力 開始年書込
            xlCell = xlOutPSSheet.Range("DJ9")
            xlCell.Value = strYear
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            '契約期間内外書込
            xlCell = xlOutPSSheet.Range("DJ8:MO8")
            xlCell.Value = objTerm
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            '-------------------------------------------------
            '　      以下、入力ﾁｪｯｸ結果のCpno項目をｾｯﾄ
            '-------------------------------------------------
            'ｼﾘｱﾙｼｰﾄ
            xlCell = xlOutSerialSheet.Range("H2")
            xlCell.Value = CommonVariable.CPNO
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            'Paymentｼｰﾄ
            xlCell = xlOutPSSheet.Range("B2")
            xlCell.Value = CommonVariable.CPNO
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            '入力ﾁｪｯｸｼｰﾄ
            xlCell = xlChkSheet.Range("F2")
            xlCell.Value = CommonVariable.CPNO
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            Call GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' 機　能：締結済MDBのPaymentTBLﾃﾞｰﾀをﾃﾞｰﾀﾃｰﾌﾞﾙにｽﾄｱする。
    ''' 説　明：
    ''' </summary>  
    ''' <remarks></remarks>
    Private Sub GetMdbTblDate(ByRef Con As OleDbConnection, _
                              ByRef TBL1 As DataTable, _
                              ByRef TBL2 As DataTable, _
                              ByRef TBL3 As DataTable)

        ''戻り値　※初期化
        Dim rtnTBL1 As New DataTable
        Dim rtnTBL2 As New DataTable
        Dim rtnTBL3 As New DataTable

        ''            以下、PaymentTBL1 ～ PaymentTBL3の値をｾｯﾄする。
        ''----------------------------------------------------------------------
        Try

            ''ﾃﾞｰﾀｱﾀﾞﾌﾟﾀの宣言
            Dim AdapterTBL1 As OleDbDataAdapter
            Dim AdapterTBL2 As OleDbDataAdapter
            Dim AdapterTBL3 As OleDbDataAdapter

            ''Sqlの宣言
            Dim TBL1filter As New StringBuilder
            Dim TBL2filter As New StringBuilder
            Dim TBL3filter As New StringBuilder

            ''PaymentTBL1の取得
            TBL1filter.Append(CommonConstant.SQL_STR_SELECT)
            TBL1filter.Append(CommonConstant.SQL_STR_ASTERISK)
            TBL1filter.Append(CommonConstant.SQL_STR_FROM)
            TBL1filter.Append(" PaymentTBL1 ")
            TBL1filter.Append(CommonConstant.SQL_STR_ORDER_BY)
            TBL1filter.Append(" ID ")
            AdapterTBL1 = New OleDbDataAdapter(TBL1filter.ToString, Con)
            Call AdapterTBL1.Fill(rtnTBL1)

            ''PaymentTBL2の取得
            TBL2filter.Append(CommonConstant.SQL_STR_SELECT)
            TBL2filter.Append(CommonConstant.SQL_STR_ASTERISK)
            TBL2filter.Append(CommonConstant.SQL_STR_FROM)
            TBL2filter.Append(" PaymentTBL2 ")
            TBL2filter.Append(CommonConstant.SQL_STR_ORDER_BY)
            TBL2filter.Append(" ID ")
            AdapterTBL2 = New OleDbDataAdapter(TBL2filter.ToString, Con)
            Call AdapterTBL2.Fill(rtnTBL2)

            ''PaymentTBL3の取得
            TBL3filter.Append(CommonConstant.SQL_STR_SELECT)
            TBL3filter.Append(CommonConstant.SQL_STR_ASTERISK)
            TBL3filter.Append(CommonConstant.SQL_STR_FROM)
            TBL3filter.Append(" PaymentTBL3 ")
            TBL3filter.Append(CommonConstant.SQL_STR_ORDER_BY)
            TBL3filter.Append(" ID ")
            TBL3filter.Append(CommonConstant.STR_COMMA)
            TBL3filter.Append(" IOC_YEAER ")
            AdapterTBL3 = New OleDbDataAdapter(TBL3filter.ToString, Con)
            Call AdapterTBL3.Fill(rtnTBL3)

            ''戻り値
            TBL1 = rtnTBL1
            TBL2 = rtnTBL2
            TBL3 = rtnTBL3

        Catch ex As Exception
            Throw ex

        End Try

    End Sub

    ''' <summary>
    ''' 機　能：Payment.Xlsの「削除データ作成」で作成された不要なデータを削除する。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub DelPaymentTBLDFlg(ByRef TBL1 As DataTable, _
                                  ByRef TBL2 As DataTable, _
                                  ByRef TBL3 As DataTable)


        ''以下、削除ﾃﾞｰﾀ作成で作成された以下のﾃﾞｰﾀは削除する。
        ''・削除元ﾃﾞｰﾀ削除： ※項目10 に 「削除元 = XXXXX」のﾃﾞｰﾀ + Dがついているﾃﾞｰﾀ
        ''・削除ﾃﾞｰﾀ削除  ： ※「削除元 = XXXXX」の削除元(XXXXX)のLineNoのﾃﾞｰﾀ
        '' ------------------------------------------------------------------------        
        Dim DelRowList As New ArrayList             ''削除対象ﾃﾞｰﾀをｽﾄｱする。

        ''Item10に「削除元」の文言を持つﾚｺｰﾄﾞをｽﾄｱ 
        Dim fromRows() As DataRow                   ''削除元NO = のﾃﾞｰﾀをｽﾄｱ
        Dim filter As New StringBuilder             ''削除元NO = のﾃﾞｰﾀ取得用SQL
        filter.Append(" PROD_ITEM10 ")
        filter.Append(CommonConstant.SQL_STR_LIKE)
        filter.Append(StringEdit.EncloseSingleQuotation("削除元NO =*"))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(" VALID_FLAG ")
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation("D"))

        fromRows = TBL1.Select(filter.ToString)
        For Each row As DataRow In fromRows

            ''削除対象ﾃﾞｰﾀ Add
            DelRowList.Add(row)
        Next


        ''「削除元」に紐づくﾃﾞｰﾀを取得
        Dim chkRows() As DataRow
        Dim refLinno As String                      ''「削除元No = XXXX」　の「XXXX」部分を格納
        Dim refFilter As New StringBuilder              ''削除元Noを検索するSQL 
        For Each chkRow As DataRow In fromRows

            ''参照先のLineNoを取得
            refLinno = chkRow.Item("PROD_ITEM10")
            refLinno = refLinno.Replace("削除元NO = ", "")
            If IsNumeric(refLinno) = False Then
                refLinno = ""
            Else
                refLinno = CInt(refLinno).ToString
            End If

            ''参照先の検索
            refFilter.Length = 0
            refFilter.Append(" LINE_NO ")
            refFilter.Append(CommonConstant.SQL_STR_EQUAL)
            refFilter.Append(StringEdit.EncloseSingleQuotation(refLinno))
            For Each row As DataRow In TBL1.Select(refFilter.ToString)

                ''削除対象ﾃﾞｰﾀ Add
                If DelRowList.IndexOf(row) = -1 Then
                    DelRowList.Add(row)
                End If
            Next
        Next


        ''  以下削除対象ﾃﾞｰﾀから、ID情報をKeyにTBL1～TBL3のﾃﾞｰﾀを削除
        ''---------------------------------------------------------------
        Dim i As Integer
        Dim DelID As String                         ''削除対象のID
        Dim delFilter As New StringBuilder          ''削除対象を検索するSQL
        Try
            For Each row As DataRow In DelRowList

                ''削除条件セット
                delFilter.Length = 0
                delFilter.Append(" ID ")
                delFilter.Append(CommonConstant.SQL_STR_EQUAL)
                delFilter.Append(StringEdit.EncloseSingleQuotation(row.Item("ID")))

                ''TBL1削除
                For Each dRow As DataRow In TBL1.Select(delFilter.ToString)
                    Call TBL1.Rows.RemoveAt(TBL1.Rows.IndexOf(dRow))
                Next

                ''TBL2削除
                For Each dRow As DataRow In TBL2.Select(delFilter.ToString)
                    Call TBL2.Rows.RemoveAt(TBL2.Rows.IndexOf(dRow))
                Next

                ''TBL3削除
                For Each dRow As DataRow In TBL3.Select(delFilter.ToString)
                    Call TBL3.Rows.RemoveAt(TBL3.Rows.IndexOf(dRow))
                Next

            Next

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' 機能：削除ﾃﾞｰﾀのIDを取得する
    ''' </summary>
    ''' <param name="DelRowList"></param>
    ''' <param name="TBL1"></param>
    ''' <param name="TBL2"></param>
    ''' <param name="TBL3"></param>
    ''' <remarks></remarks>
    Private Sub DelPaymentTBLDFlg2(ByRef DelRowList As ArrayList,
                                   ByRef TBL1 As DataTable,
                                   ByRef TBL2 As DataTable,
                                   ByRef TBL3 As DataTable)


        ''以下、削除ﾃﾞｰﾀ作成で作成された以下のﾃﾞｰﾀは削除する。
        ''・削除元ﾃﾞｰﾀ削除： ※項目10 に 「削除元 = XXXXX」のﾃﾞｰﾀ + Dがついているﾃﾞｰﾀ
        ''・削除ﾃﾞｰﾀ削除  ： ※「削除元 = XXXXX」の削除元(XXXXX)のLineNoのﾃﾞｰﾀ
        '' ------------------------------------------------------------------------        

        ''Item10に「削除元」の文言を持つﾚｺｰﾄﾞをｽﾄｱ 
        Dim fromRows() As DataRow                   ''削除元NO = のﾃﾞｰﾀをｽﾄｱ
        Dim filter As New StringBuilder             ''削除元NO = のﾃﾞｰﾀ取得用SQL
        filter.Append(" PROD_ITEM10 ")
        filter.Append(CommonConstant.SQL_STR_LIKE)
        filter.Append(StringEdit.EncloseSingleQuotation("削除元NO =*"))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(" VALID_FLAG ")
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation("D"))

        fromRows = TBL1.Select(filter.ToString)
        For Each row As DataRow In fromRows
            ''削除対象ﾃﾞｰﾀ Add
            DelRowList.Add(row("ID"))
        Next

        ''「削除元」に紐づくﾃﾞｰﾀを取得
        Dim chkRows() As DataRow
        Dim refLinno As String                      ''「削除元No = XXXX」　の「XXXX」部分を格納
        Dim refFilter As New StringBuilder              ''削除元Noを検索するSQL 
        For Each chkRow As DataRow In fromRows
            ''参照先のLineNoを取得
            refLinno = chkRow.Item("PROD_ITEM10")
            If refLinno.IndexOf("削除元NO = ") = 0 Then
                refLinno = refLinno.Replace("削除元NO = ", "")
                Dim intPos As Integer
                intPos = refLinno.IndexOf("_")
                If intPos <> -1 Then
                    refLinno = refLinno.Substring(0, intPos)
                End If
                If IsNumeric(refLinno) = False Then
                    refLinno = ""
                Else
                    refLinno = CLng(refLinno).ToString
                End If
            Else
                refLinno = ""
            End If

            ''参照先の検索
            refFilter.Length = 0
            refFilter.Append(" LINE_NO ")
            refFilter.Append(CommonConstant.SQL_STR_EQUAL)
            refFilter.Append(StringEdit.EncloseSingleQuotation(refLinno))
            For Each row As DataRow In TBL1.Select(refFilter.ToString)
                ''削除対象ﾃﾞｰﾀ Add
                If DelRowList.IndexOf(row) = -1 Then
                    DelRowList.Add(row("ID"))
                End If
            Next
        Next

    End Sub

    ''' <summary>
    ''' 機　能：ｼﾘｱﾙシート出力用のデータを整形する(1行分)
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSerialCreateData(ByVal intIndex As Integer, _
                                         ByRef TBL1 As DataTable, _
                                         ByRef TBL2 As DataTable, _
                                         ByRef TBL3 As DataTable) As Object(,)

        ''戻り値
        Dim rtnValue(0, 351) As Object

        ''TBL1のデータをセットする。
        rtnValue(0, SerialSheetColumns.UPDATE_FLAG - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("UPDATE_FLAG"))
        rtnValue(0, SerialSheetColumns.LOCK_FLAG - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("LOCK_FLAG"))
        rtnValue(0, SerialSheetColumns.VALID_FLAG - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("VALID_FLAG"))
        rtnValue(0, SerialSheetColumns.LINE_NO - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("LINE_NO"))
        rtnValue(0, SerialSheetColumns.FILE_NAME - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("FILE_NAME"))
        rtnValue(0, SerialSheetColumns.FILE_NAME_SUFFIX - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("FILE_NAME_SUFFIX"))
        rtnValue(0, SerialSheetColumns.FILE_NAME_SUFFIX_INTR - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("FILE_NAME_SUFFIX_INTR"))
        rtnValue(0, SerialSheetColumns.CONTRACT - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("CONTRACT"))
        rtnValue(0, SerialSheetColumns.PROJ_ID - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("PROJ_ID"))
        rtnValue(0, SerialSheetColumns.CONTRACT_SEQ - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("CONTRACT_SEQ"))
        rtnValue(0, SerialSheetColumns.NEW_EXIST - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("NEW_EXIST"))
        rtnValue(0, SerialSheetColumns.CUST_CATEGORY - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("CUST_CATEGORY"))
        rtnValue(0, SerialSheetColumns.LETTER_PLAN_DATE - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("LETTER_PLAN_DATE"))
        rtnValue(0, SerialSheetColumns.LETTER_ACCEPT_DATE - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("LETTER_ACCEPT_DATE"))
        rtnValue(0, SerialSheetColumns.ORDER_DATE - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("ORDER_DATE"))
        rtnValue(0, SerialSheetColumns.LETTER_ID - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("LETTER_ID"))
        rtnValue(0, SerialSheetColumns.ORDERCODE - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("BILLING_CD"))
        rtnValue(0, SerialSheetColumns.BU - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("BU"))
        rtnValue(0, SerialSheetColumns.BRAND - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("BRAND"))
        rtnValue(0, SerialSheetColumns.SUM_CATEGORY - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("SUM_CATEGORY"))
        rtnValue(0, SerialSheetColumns.BRAND_SUB - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("BRAND_SUB"))
        rtnValue(0, SerialSheetColumns.OP1 - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("T_OP1"))
        rtnValue(0, SerialSheetColumns.OP2 - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("T_OP2"))
        rtnValue(0, SerialSheetColumns.BRAND_SIZE - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("T_SIZE"))
        rtnValue(0, SerialSheetColumns.NON_SBO - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("NON_SBO"))
        rtnValue(0, SerialSheetColumns.POSTSCRIPT - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("ADDITION_ITEM"))
        rtnValue(0, SerialSheetColumns.TOPACS_CPNO - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("TOPACS_CPNO"))
        rtnValue(0, SerialSheetColumns.BRAND_AP_FORM - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("BRAND_AP_FORM"))
        rtnValue(0, SerialSheetColumns.BRAND_AP_REQ - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("BRAND_AP_REQ"))
        rtnValue(0, SerialSheetColumns.BRAND_AP_CONF - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("BRAND_AP_CONF"))
        rtnValue(0, SerialSheetColumns.PATTERN_CD - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("PATTERN_CD"))
        rtnValue(0, SerialSheetColumns.PATTERN - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("PATTERN"))
        rtnValue(0, SerialSheetColumns.PROD_ITEM01 - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("PROD_ITEM01"))
        rtnValue(0, SerialSheetColumns.PROD_ITEM02 - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("PROD_ITEM03"))
        rtnValue(0, SerialSheetColumns.PROD_TmpSerial - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("PROD_ITEM02"))
        rtnValue(0, SerialSheetColumns.PROD_Serial - 1) = ""
        rtnValue(0, SerialSheetColumns.PROD_ITEM04 - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("PROD_ITEM04"))
        rtnValue(0, SerialSheetColumns.PROD_ITEM05 - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("PROD_ITEM05"))
        rtnValue(0, SerialSheetColumns.PROD_ITEM06 - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("PROD_ITEM06"))
        rtnValue(0, SerialSheetColumns.PROD_ITEM07 - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("PROD_ITEM07"))
        rtnValue(0, SerialSheetColumns.PROD_ITEM08 - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("PROD_ITEM08"))
        rtnValue(0, SerialSheetColumns.PROD_ITEM09 - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("PROD_ITEM09"))
        rtnValue(0, SerialSheetColumns.PROD_ITEM10 - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("PROD_ITEM10"))
        rtnValue(0, SerialSheetColumns.PROD_ITEM11 - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("PROD_ITEM11"))
        rtnValue(0, SerialSheetColumns.PROD_ITEM12 - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("PROD_ITEM12"))
        rtnValue(0, SerialSheetColumns.PROD_ITEM13 - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("PROD_ITEM13"))
        rtnValue(0, SerialSheetColumns.PROD_ITEM14 - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("PROD_ITEM14"))
        rtnValue(0, SerialSheetColumns.PROD_ITEM15 - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("PROD_ITEM15"))
        rtnValue(0, SerialSheetColumns.PROD_ITEM16 - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("PROD_ITEM16"))
        rtnValue(0, SerialSheetColumns.PROD_ITEM17 - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("PROD_ITEM17"))
        rtnValue(0, SerialSheetColumns.PROD_ITEM18 - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("PROD_ITEM18"))
        rtnValue(0, SerialSheetColumns.PROD_ITEM19 - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("PROD_ITEM19"))
        rtnValue(0, SerialSheetColumns.PROD_ITEM20 - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("PROD_ITEM20"))
        rtnValue(0, SerialSheetColumns.PROD_ITEM22 - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("PROD_ITEM22"))
        rtnValue(0, SerialSheetColumns.PROD_ITEM23 - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("PROD_ITEM23"))
        rtnValue(0, SerialSheetColumns.PROD_ITEM23 - 1) = ExcelWrite.changeDBNullToString(TBL1.Rows(intIndex).Item("PROD_ITEM24"))

        ''TBL2のデータをセットする。
        rtnValue(0, SerialSheetColumns.WD_ANNT_DATE - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("WD_ANNT_DATE"))
        rtnValue(0, SerialSheetColumns.WD_DATE - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("WD_DATE"))
        rtnValue(0, SerialSheetColumns.PRICE_CHG_DATE - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("PRICE_CHG_DATE"))
        rtnValue(0, SerialSheetColumns.QTY - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("QTY"))
        rtnValue(0, SerialSheetColumns.INST_DATE - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("INST_DATE"))
        rtnValue(0, SerialSheetColumns.PAY_START_DATE - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("PAY_START_DATE"))
        rtnValue(0, SerialSheetColumns.PAY_END_DATE - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("PAY_END_DATE"))
        rtnValue(0, SerialSheetColumns.IGF_START_DATE - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("IGF_START_DATE"))
        rtnValue(0, SerialSheetColumns.IGF_END_DATE - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("IGF_END_DATE"))
        rtnValue(0, SerialSheetColumns.PAY_FLAG - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("PAY_FLAG"))
        rtnValue(0, SerialSheetColumns.BID_FLAG - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("BID_FLAG"))
        rtnValue(0, SerialSheetColumns.PAY_MONTHS - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("PAY_MONTHS"))
        rtnValue(0, SerialSheetColumns.PAY_VALIDATION - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("VALID_CTRL"))
        rtnValue(0, SerialSheetColumns.PAY_METHOD - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("PAY_METHOD"))
        rtnValue(0, SerialSheetColumns.IGF_APPLIED - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("IGF_APPLIED"))
        rtnValue(0, SerialSheetColumns.IGF_CONT_NO - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("IGF_CONT_NO"))
        rtnValue(0, SerialSheetColumns.IGF_CONT_FORM - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("IGF_CONT_TYPE"))
        rtnValue(0, SerialSheetColumns.IGF_CONT_MANAGMENT - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("IGF_PROPERTY"))
        rtnValue(0, SerialSheetColumns.IGF_RATE_IOC - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("IGF_RATE_IOC"))
        rtnValue(0, SerialSheetColumns.LIST_PRICE_PROPOSAL - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("LIST_PRICE_PROPOSAL"))
        rtnValue(0, SerialSheetColumns.LIST_PRICE_REFLESH - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("LIST_PRICE"))
        rtnValue(0, SerialSheetColumns.LIST_PRICE_TOTAL_PROPOSAL - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("LIST_PRICE_TOTAL_PROPOSAL"))
        rtnValue(0, SerialSheetColumns.LIST_PRICE_TOTAL_REFLESH - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("LIST_PRICE_TOTAL"))
        rtnValue(0, SerialSheetColumns.DP_IOC - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("DP_IOC"))
        rtnValue(0, SerialSheetColumns.PRICE_UNIT_IOC - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("PRICE_UNIT_IOC"))
        rtnValue(0, SerialSheetColumns.PRICE_UNIT_IOC_VAL - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("PRICE_UNIT_IOC_VAL"))
        rtnValue(0, SerialSheetColumns.PRICE_QTY_IOC - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("PRICE_QTY_IOC"))
        rtnValue(0, SerialSheetColumns.PRICE_TO_SPLIT - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("PRICE_TO_SPLIT"))
        rtnValue(0, SerialSheetColumns.LIST_PRICE_TOTAL_IOC - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("LIST_PRICE_TOTAL_IOC"))
        rtnValue(0, SerialSheetColumns.PRICE_TOTAL_IOC - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("PRICE_TOTAL_IOC"))
        rtnValue(0, SerialSheetColumns.PRICE_TOTAL_IGF - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("PRICE_IGF_TOTAL"))
        rtnValue(0, SerialSheetColumns.CONTRACT_IN - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("PRICE_CONT_TOTAL"))
        rtnValue(0, SerialSheetColumns.CONTRACT_OUT - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("PRICE_OO_CONT_TOTAL"))
        rtnValue(0, SerialSheetColumns.PRICE_DEFF_IGF - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("IGF_DIF_INTEREST"))
        '過去の契約金額合計
        rtnValue(0, SerialSheetColumns.PAST_PRICE_TOTAL - 1) = ExcelWrite.changeDBNullToString(TBL2.Rows(intIndex).Item("PAST_PRICE_TOTAL"))

        ''TBL3のデータをセット(年額/月額)
        Dim i As Integer
        Dim j As Integer
        Dim rowIdx As Integer
        Dim yearIdx As Integer
        Dim yearColumnNM As String
        Dim monthIdx As Integer
        Dim monthColumnNM As String
        For i = 1 To 20

            ''年額
            rowIdx = (intIndex * 20) + (i - 1)
            yearIdx = (SerialSheetColumns.PRICE_YEAR1 - 1) + (i - 1)
            yearColumnNM = "IOC_YYYY"
            rtnValue(0, yearIdx) = ExcelWrite.changeDBNullToString(TBL3.Rows(rowIdx).Item(yearColumnNM))

            ''月額
            For j = 1 To 12

                monthIdx = (SerialSheetColumns.PRICE_YEAR1_MONTH1 - 1) + (j - 1)
                monthIdx = monthIdx + ((i - 1) * 12)
                monthColumnNM = "IOC_@".Replace("@", j.ToString.PadLeft(2, "0"))
                rtnValue(0, monthIdx) = ExcelWrite.changeDBNullToString(TBL3.Rows(rowIdx).Item(monthColumnNM))

            Next
        Next
        Return rtnValue

    End Function

    ''' <summary>
    ''' 機　能：Paymentシート出力用のデータを整形する(1行分)
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetPSCreateData(ByRef OutSerialXlsCellInfo(,) As Object) As Object(,)

        ''戻り値
        Dim rtnValue(0, 353) As Object


        ''TBL以外の値
        rtnValue(0, PaymentSheetColumns.ACT_CONTROL - 1) = ""         ''空白で初期化：実行管理対象FLGは出力対象判定で更新する。                                                                                                                   
        rtnValue(0, PaymentSheetColumns.TOPACS_FLG - 1) = ""          ''空白で初期化：Topacs対象FLGは出力対象判定で更新する。                                                                                                          


        ''TBL1項目のデータをセットする。
        rtnValue(0, PaymentSheetColumns.UPDATE_FLAG - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.UPDATE_FLAG - 1)
        rtnValue(0, PaymentSheetColumns.LOCK_FLAG - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.LOCK_FLAG - 1)
        rtnValue(0, PaymentSheetColumns.VALID_FLAG - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.VALID_FLAG - 1)
        rtnValue(0, PaymentSheetColumns.LINE_NO - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.LINE_NO - 1)
        rtnValue(0, PaymentSheetColumns.FILE_NAME - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.FILE_NAME - 1)
        rtnValue(0, PaymentSheetColumns.FILE_NAME_SUFFIX - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.FILE_NAME_SUFFIX - 1)
        rtnValue(0, PaymentSheetColumns.FILE_NAME_SUFFIX_INTR - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.FILE_NAME_SUFFIX_INTR - 1)
        rtnValue(0, PaymentSheetColumns.CONTRACT - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.CONTRACT - 1)
        rtnValue(0, PaymentSheetColumns.PROJ_ID - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PROJ_ID - 1)
        rtnValue(0, PaymentSheetColumns.CONTRACT_SEQ - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.CONTRACT_SEQ - 1)
        rtnValue(0, PaymentSheetColumns.NEW_EXIST - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.NEW_EXIST - 1)
        rtnValue(0, PaymentSheetColumns.CUST_CATEGORY - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.CUST_CATEGORY - 1)
        rtnValue(0, PaymentSheetColumns.LETTER_PLAN_DATE - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.LETTER_PLAN_DATE - 1)
        rtnValue(0, PaymentSheetColumns.LETTER_ACCEPT_DATE - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.LETTER_ACCEPT_DATE - 1)
        rtnValue(0, PaymentSheetColumns.ORDER_DATE - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.ORDER_DATE - 1)
        rtnValue(0, PaymentSheetColumns.LETTER_ID - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.LETTER_ID - 1)
        rtnValue(0, PaymentSheetColumns.ORDERCODE - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.ORDERCODE - 1)
        rtnValue(0, PaymentSheetColumns.BU - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.BU - 1)
        rtnValue(0, PaymentSheetColumns.BRAND - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.BRAND - 1)
        rtnValue(0, PaymentSheetColumns.SUM_CATEGORY - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.SUM_CATEGORY - 1)
        rtnValue(0, PaymentSheetColumns.BRAND_SUB - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.BRAND_SUB - 1)
        rtnValue(0, PaymentSheetColumns.OP1 - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.OP1 - 1)
        rtnValue(0, PaymentSheetColumns.OP2 - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.OP2 - 1)
        rtnValue(0, PaymentSheetColumns.BRAND_SIZE - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.BRAND_SIZE - 1)
        rtnValue(0, PaymentSheetColumns.NON_SBO - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.NON_SBO - 1)
        rtnValue(0, PaymentSheetColumns.POSTSCRIPT - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.POSTSCRIPT - 1)
        rtnValue(0, PaymentSheetColumns.TOPACS_CPNO - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.TOPACS_CPNO - 1)
        rtnValue(0, PaymentSheetColumns.BRAND_AP_FORM - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.BRAND_AP_FORM - 1)
        rtnValue(0, PaymentSheetColumns.BRAND_AP_REQ - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.BRAND_AP_REQ - 1)
        rtnValue(0, PaymentSheetColumns.BRAND_AP_CONF - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.BRAND_AP_CONF - 1)
        rtnValue(0, PaymentSheetColumns.PATTERN_CD - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PATTERN_CD - 1)
        rtnValue(0, PaymentSheetColumns.PATTERN - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PATTERN - 1)
        rtnValue(0, PaymentSheetColumns.PROD_ITEM01 - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PROD_ITEM01 - 1)
        rtnValue(0, PaymentSheetColumns.PROD_ITEM02 - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PROD_TmpSerial - 1)
        rtnValue(0, PaymentSheetColumns.PROD_ITEM03 - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PROD_ITEM02 - 1)

        ''※実シリアルは、シート情報の書込時に仮シリアルシートの参照式を埋込
        rtnValue(0, PaymentSheetColumns.PROD_SERIAL - 1) = ""
        rtnValue(0, PaymentSheetColumns.PROD_ITEM04 - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PROD_ITEM04 - 1)
        rtnValue(0, PaymentSheetColumns.PROD_ITEM05 - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PROD_ITEM05 - 1)
        rtnValue(0, PaymentSheetColumns.PROD_ITEM06 - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PROD_ITEM06 - 1)
        rtnValue(0, PaymentSheetColumns.PROD_ITEM07 - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PROD_ITEM07 - 1)
        rtnValue(0, PaymentSheetColumns.PROD_ITEM08 - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PROD_ITEM08 - 1)
        rtnValue(0, PaymentSheetColumns.PROD_ITEM09 - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PROD_ITEM09 - 1)
        rtnValue(0, PaymentSheetColumns.PROD_ITEM10 - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PROD_ITEM10 - 1)
        rtnValue(0, PaymentSheetColumns.PROD_ITEM11 - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PROD_ITEM11 - 1)
        rtnValue(0, PaymentSheetColumns.PROD_ITEM12 - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PROD_ITEM12 - 1)
        rtnValue(0, PaymentSheetColumns.PROD_ITEM13 - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PROD_ITEM13 - 1)
        rtnValue(0, PaymentSheetColumns.PROD_ITEM14 - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PROD_ITEM14 - 1)
        rtnValue(0, PaymentSheetColumns.PROD_ITEM15 - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PROD_ITEM15 - 1)
        rtnValue(0, PaymentSheetColumns.PROD_ITEM16 - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PROD_ITEM16 - 1)
        rtnValue(0, PaymentSheetColumns.PROD_ITEM17 - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PROD_ITEM17 - 1)
        rtnValue(0, PaymentSheetColumns.PROD_ITEM18 - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PROD_ITEM18 - 1)
        rtnValue(0, PaymentSheetColumns.PROD_ITEM19 - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PROD_ITEM19 - 1)
        rtnValue(0, PaymentSheetColumns.PROD_ITEM20 - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PROD_ITEM20 - 1)
        rtnValue(0, PaymentSheetColumns.PROD_ITEM22 - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PROD_ITEM22 - 1)
        rtnValue(0, PaymentSheetColumns.PROD_ITEM23 - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PROD_ITEM23 - 1)
        rtnValue(0, PaymentSheetColumns.PROD_ITEM24 - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PROD_ITEM24 - 1)

        ''TBL2項目のデータをセットする。                                
        rtnValue(0, PaymentSheetColumns.WD_ANNT_DATE - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.WD_ANNT_DATE - 1)
        rtnValue(0, PaymentSheetColumns.WD_DATE - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.WD_DATE - 1)
        rtnValue(0, PaymentSheetColumns.PRICE_CHG_DATE - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PRICE_CHG_DATE - 1)
        rtnValue(0, PaymentSheetColumns.QTY - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.QTY - 1)
        rtnValue(0, PaymentSheetColumns.INST_DATE - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.INST_DATE - 1)
        rtnValue(0, PaymentSheetColumns.PAY_START_DATE - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PAY_START_DATE - 1)
        rtnValue(0, PaymentSheetColumns.PAY_END_DATE - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PAY_END_DATE - 1)
        rtnValue(0, PaymentSheetColumns.IGF_START_DATE - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.IGF_START_DATE - 1)
        rtnValue(0, PaymentSheetColumns.IGF_END_DATE - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.IGF_END_DATE - 1)
        rtnValue(0, PaymentSheetColumns.PAY_FLAG - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PAY_FLAG - 1)
        rtnValue(0, PaymentSheetColumns.BID_FLAG - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.BID_FLAG - 1)
        rtnValue(0, PaymentSheetColumns.PAY_MONTHS - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PAY_MONTHS - 1)
        rtnValue(0, PaymentSheetColumns.PAY_VALIDATION - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PAY_VALIDATION - 1)
        rtnValue(0, PaymentSheetColumns.PAY_METHOD - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PAY_METHOD - 1)
        rtnValue(0, PaymentSheetColumns.IGF_APPLIED - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.IGF_APPLIED - 1)
        rtnValue(0, PaymentSheetColumns.IGF_CONT_NO - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.IGF_CONT_NO - 1)
        rtnValue(0, PaymentSheetColumns.IGF_CONT_FORM - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.IGF_CONT_FORM - 1)
        rtnValue(0, PaymentSheetColumns.IGF_CONT_MANAGMENT - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.IGF_CONT_MANAGMENT - 1)
        rtnValue(0, PaymentSheetColumns.IGF_RATE_IOC - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.IGF_RATE_IOC - 1)
        rtnValue(0, PaymentSheetColumns.LIST_PRICE_PROPOSAL - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.LIST_PRICE_PROPOSAL - 1)
        rtnValue(0, PaymentSheetColumns.LIST_PRICE_REFLESH - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.LIST_PRICE_REFLESH - 1)
        rtnValue(0, PaymentSheetColumns.LIST_PRICE_TOTAL_PROPOSAL - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.LIST_PRICE_TOTAL_PROPOSAL - 1)
        rtnValue(0, PaymentSheetColumns.LIST_PRICE_TOTAL_REFLESH - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.LIST_PRICE_TOTAL_REFLESH - 1)
        rtnValue(0, PaymentSheetColumns.DP_IOC - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.DP_IOC - 1)
        rtnValue(0, PaymentSheetColumns.PRICE_UNIT_IOC - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PRICE_UNIT_IOC - 1)
        rtnValue(0, PaymentSheetColumns.PRICE_UNIT_IOC_VAL - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PRICE_UNIT_IOC_VAL - 1)
        rtnValue(0, PaymentSheetColumns.PRICE_QTY_IOC - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PRICE_QTY_IOC - 1)
        rtnValue(0, PaymentSheetColumns.PRICE_TO_SPLIT - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PRICE_TO_SPLIT - 1)
        rtnValue(0, PaymentSheetColumns.LIST_PRICE_TOTAL_IOC - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.LIST_PRICE_TOTAL_IOC - 1)
        rtnValue(0, PaymentSheetColumns.PRICE_TOTAL_IOC - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PRICE_TOTAL_IOC - 1)
        rtnValue(0, PaymentSheetColumns.PRICE_TOTAL_IGF - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PRICE_TOTAL_IGF - 1)
        rtnValue(0, PaymentSheetColumns.CONTRACT_IN - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.CONTRACT_IN - 1)
        rtnValue(0, PaymentSheetColumns.CONTRACT_OUT - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.CONTRACT_OUT - 1)
        rtnValue(0, PaymentSheetColumns.PRICE_DEFF_IGF - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PRICE_DEFF_IGF - 1)

        ''年額/月額をセットする
        Const deffPS_Serial As Integer = PaymentSheetColumns.PRICE_YEAR1 - SerialSheetColumns.PRICE_YEAR1
        Dim psYearMonthIdx As Integer
        Dim serialYearMonthIdx As Integer
        '年月をセットする
        For psYearMonthIdx = PaymentSheetColumns.PRICE_YEAR1 - 1 To PaymentSheetColumns.PRICE_YEAR20 - 1
            serialYearMonthIdx = psYearMonthIdx - deffPS_Serial
            rtnValue(0, psYearMonthIdx) = OutSerialXlsCellInfo(0, serialYearMonthIdx)
        Next
        '過去の契約金額合計
        rtnValue(0, PaymentSheetColumns.PAST_PRICE_TOTAL - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PAST_PRICE_TOTAL - 1)
        '月額をセットする
        For psYearMonthIdx = PaymentSheetColumns.PRICE_YEAR1_MONTH1 - 1 To PaymentSheetColumns.PRICE_YEAR20_MONTH12 - 1
            serialYearMonthIdx = psYearMonthIdx - deffPS_Serial
            rtnValue(0, psYearMonthIdx) = OutSerialXlsCellInfo(0, serialYearMonthIdx)
        Next
        Return rtnValue

    End Function

    ''' <summary>
    ''' ｼﾘｱﾙシートへ出力対象外かどうか判定する。
    ''' </summary>
    ''' <param name="OutSerialXlsCellInfo"></param>
    ''' <returns>True:対象、False:対象外</returns>
    ''' <remarks></remarks>
    '1680 str
    Private Function ChkSerialSheetOutPut(ByRef OutSerialXlsCellInfo(,) As Object, ByVal xlWS1Sheet As Excel.Worksheet) As Boolean
        '    Private Function ChkSerialSheetOutPut(ByRef OutSerialXlsCellInfo(,) As Object) As Boolean

        'Excel開始年を取得
        Dim ExcelYear As Integer
        Dim startcol As Integer
        Dim endcol As Integer
        Dim idx As Integer
        Dim Month_Check As Boolean

        ExcelYear = CInt(xlWS1Sheet.Range("H7").Value)
        '1680 end

        ''初期化
        ChkSerialSheetOutPut = False

        '''' 条件：出力対象外のパターン
        '''' ケース：26,28,30,35,36,37,42
        Dim strPatternCd As String
        strPatternCd = ExcelWrite.changeDBNullToString(OutSerialXlsCellInfo(0, SerialSheetColumns.PATTERN_CD - 1))
        Select Case strPatternCd
            Case CommonConstant.PATTERNCD_TYPE_HW_Brand_Service,
                CommonConstant.PATTERNCD_TYPE_UNIFICATION,
                CommonConstant.PATTERNCD_TYPE_IGF_RELEASE,
                CommonConstant.PATTERNCD_TYPE_CIS,
                CommonConstant.PATTERNCD_TYPE_ExcessTCV,
                CommonConstant.PATTERNCD_TYPE_PRIMO,
                CommonConstant.PATTERNCD_TYPE_SO
                Exit Function
        End Select

        '''' 条件：②HW Serialが存在有無判定
        '''' ケース：存在しない場合、対象外とする
        If ExcelWrite.changeDBNullToString(OutSerialXlsCellInfo(0, SerialSheetColumns.PROD_TmpSerial - 1)).IndexOf("@") = -1 Then
            Exit Function
        End If

        '''' 条件：③コメント行か判定
        '''' ケース：コメント行の場合、対象外とする
        If ExcelWrite.changeDBNullToString(OutSerialXlsCellInfo(0, SerialSheetColumns.VALID_FLAG - 1)) = "C" Then
            Exit Function
        End If

        '''' 条件：④N行か判定
        '''' ケース：N行の場合、対象外とする
        If ExcelWrite.changeDBNullToString(OutSerialXlsCellInfo(0, SerialSheetColumns.VALID_FLAG - 1)) = "N" Then
            Exit Function
        End If

        '''' 条件：現在日付が導入年月前後６ヶ月以内か判定
        '''' ケース：範囲外（導入年月＜現在年月－６ヶ月 or 導入年月＞現在年月＋６ヶ月）の場合、対象外とする
        Dim dtNow As Date = Now
        Dim strInstDate As String = ExcelWrite.changeDBNullToString(OutSerialXlsCellInfo(0, SerialSheetColumns.INST_DATE - 1))

        '1680 str

        'CISCO保守とそれ以外で条件を分ける
        If strPatternCd = CommonConstant.PATTERNCD_TYPE_CISCO_MAINTENANCE Then

            startcol = (Integer.Parse(dtNow.ToString("yyyy")) - ExcelYear) * 12 - 6 + Me.COL_ACT_PRICE_YEAR1_MONTH1 + dtNow.Month - 2
            endcol = (Integer.Parse(dtNow.ToString("yyyy")) - ExcelYear) * 12 + 6 + Me.COL_ACT_PRICE_YEAR1_MONTH1 + dtNow.Month - 2

            '開始年の1月よりも前6ヶ月が古い場合、開始年の1月をセット
            If startcol < Me.COL_ACT_PRICE_YEAR1_MONTH1 Then
                startcol = Me.COL_ACT_PRICE_YEAR1_MONTH1
            End If

            '前後６ヶ月内に0円以上の値が存在すれば出力する
            Month_Check = False
            For idx = startcol To endcol
                If OutSerialXlsCellInfo(0, idx) > 0 Then
                    Month_Check = True
                End If
            Next idx

            If Month_Check = False Then
                Exit Function
            End If

        Else
            If IsDate(strInstDate) = True Then
                If Integer.Parse(Date.Parse(strInstDate).ToString("yyyyMM")) < Integer.Parse(dtNow.AddMonths(-6).ToString("yyyyMM")) Or
                    Integer.Parse(Date.Parse(strInstDate).ToString("yyyyMM")) > Integer.Parse(dtNow.AddMonths(6).ToString("yyyyMM")) Then
                    Exit Function
                End If
            End If
        End If

        'If IsDate(strInstDate) = True Then
        '    If Integer.Parse(Date.Parse(strInstDate).ToString("yyyyMM")) < Integer.Parse(dtNow.AddMonths(-6).ToString("yyyyMM")) Or
        '        Integer.Parse(Date.Parse(strInstDate).ToString("yyyyMM")) > Integer.Parse(dtNow.AddMonths(6).ToString("yyyyMM")) Then
        '        Exit Function
        '    End If
        'End If
        '1680 end

        Return True

    End Function

    ''' <summary>
    ''' SWの場合、項目１に項目４の値をセットする
    ''' </summary>
    ''' <param name="OutSerialXlsCellInfo"></param>
    ''' <remarks></remarks>
    Private Sub CheckPatternChangeItem01(ByRef OutSerialXlsCellInfo(,) As Object)

        Dim strPatternCd As String

        strPatternCd = ExcelWrite.changeDBNullToString(OutSerialXlsCellInfo(0, SerialSheetColumns.PATTERN_CD - 1))
        Select Case strPatternCd
            Case "5", "7", "9", "10", "13"
                OutSerialXlsCellInfo(0, SerialSheetColumns.PROD_ITEM01 - 1) = OutSerialXlsCellInfo(0, SerialSheetColumns.PROD_ITEM04 - 1)
        End Select

    End Sub

    ''' <summary>
    ''' 重複データをテーブルにセットする。
    ''' </summary>
    ''' <param name="DistinctSerialTBL"></param>
    ''' <param name="OutSerialXlsCellInfo"></param>
    ''' <remarks></remarks>
    Private Sub SetDistinctSerialTBL(ByRef DistinctSerialTBL As DataTable, _
                                     ByRef OutSerialXlsCellInfo(,) As Object)

        '''' 処理：パターンCDの取得
        Dim changePatternCd As String
        changePatternCd = ExcelWrite.GetPatternCD(ExcelWrite.changeDBNullToString(OutSerialXlsCellInfo(0, SerialSheetColumns.PATTERN_CD - 1)),
                                                  ExcelWrite.changeDBNullToString(OutSerialXlsCellInfo(0, SerialSheetColumns.PATTERN - 1)))


        '''' 処理：重複情報の取得
        Dim insRow As DataRow
        insRow = DistinctSerialTBL.NewRow
        insRow.Item("Cell" & SerialSheetColumns.PATTERN_CD) = changePatternCd
        insRow.Item("Cell" & SerialSheetColumns.PROD_TmpSerial) = ExcelWrite.changeDBNullToString(OutSerialXlsCellInfo(0, SerialSheetColumns.PROD_TmpSerial - 1))
        insRow.Item("Cell" & SerialSheetColumns.LINE_NO) = ExcelWrite.changeDBNullToString(OutSerialXlsCellInfo(0, SerialSheetColumns.LINE_NO - 1))
        insRow.Item("Cell" & SerialSheetColumns.PROD_ITEM01) = ExcelWrite.changeDBNullToString(OutSerialXlsCellInfo(0, SerialSheetColumns.PROD_ITEM01 - 1))
        DistinctSerialTBL.Rows.Add(insRow)

    End Sub

    ''' <summary>
    ''' 機　能：Paymentシートへ出力対象外かどうか判定する。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function ChkPSSheetOutPut(ByRef OutPSXlsCellInfo(,) As Object) As Boolean

        ''初期化
        ChkPSSheetOutPut = True
        Dim isActControl As Boolean = True      ''実行管理出力対象かどうか

        ''================================================================
        ''                        以下、除外条件
        ''================================================================        

        ''実行通知、Topacs共通条件
        ''------------------------------------------------
        Dim changePatternCd As String
        changePatternCd = ExcelWrite.GetPatternCD(ExcelWrite.changeDBNullToString(OutPSXlsCellInfo(0, PaymentSheetColumns.PATTERN_CD - 1)),
                                                  ExcelWrite.changeDBNullToString(OutPSXlsCellInfo(0, PaymentSheetColumns.PATTERN - 1)))

        '''' 条件：出力対象外のパターン
        '''' ケース：26,28,30,35,36,37,42,45,46
        Select Case changePatternCd
            Case CommonConstant.PATTERNCD_TYPE_HW_Brand_Service,
                CommonConstant.PATTERNCD_TYPE_UNIFICATION,
                CommonConstant.PATTERNCD_TYPE_IGF_RELEASE,
                CommonConstant.PATTERNCD_TYPE_CIS,
                CommonConstant.PATTERNCD_TYPE_ExcessTCV,
                CommonConstant.PATTERNCD_TYPE_PRIMO,
                CommonConstant.PATTERNCD_TYPE_SO,
                CommonConstant.PATTERNCD_TYPE_Allotment,
                CommonConstant.PATTERNCD_TYPE_VarianceCash
                ChkPSSheetOutPut = False
                Exit Function
        End Select

        ''IGF行
        If changePatternCd = "29" Then
            isActControl = False
        End If

        ''コメント行
        If ExcelWrite.changeDBNullToString(OutPSXlsCellInfo(0, PaymentSheetColumns.VALID_FLAG - 1)) = "C" Then
            isActControl = False
        End If

        ''N行
        If ExcelWrite.changeDBNullToString(OutPSXlsCellInfo(0, PaymentSheetColumns.VALID_FLAG - 1)) = "N" Then
            isActControl = False
        End If

        ''作成中と価格承認済みは出力対象外
        If ExcelWrite.changeDBNullToString(OutPSXlsCellInfo(0, PaymentSheetColumns.LOCK_FLAG - 1)) = "" Or _
           ExcelWrite.changeDBNullToString(OutPSXlsCellInfo(0, PaymentSheetColumns.LOCK_FLAG - 1)) = "P" Then
            isActControl = False
        End If

        ''実行通知書番号未入力は対象外
        If ExcelWrite.changeDBNullToString(OutPSXlsCellInfo(0, PaymentSheetColumns.LETTER_ID - 1)) = "" Then
            isActControl = False
        End If


        ''実行管理　の条件
        ''------------------------------------------------
        ''「通知書受領日」「発注完了日」全て空白
        If ChkInputDate(OutPSXlsCellInfo(0, PaymentSheetColumns.LETTER_ACCEPT_DATE - 1), PaymentSheetColumns.LETTER_ACCEPT_DATE) <> "" And _
           ChkInputDate(OutPSXlsCellInfo(0, PaymentSheetColumns.ORDER_DATE - 1), PaymentSheetColumns.ORDER_DATE) <> "" Then
            isActControl = False
        End If

        ''実行管理に○をセット
        If isActControl = True Then
            OutPSXlsCellInfo(0, PaymentSheetColumns.ACT_CONTROL - 1) = "○"
        End If

        ''戻り値
        If isActControl = False Then
            ChkPSSheetOutPut = False
        End If

    End Function

    ''' <summary>
    ''' 機　能：仮シリアルの重複データを削除する。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub DelDistinctSerialDate(ByRef DistinctSerialTBL As DataTable, _
                                      ByRef OutSerialArrayList As ArrayList)

        Dim strMtdl As String
        Dim strKey As String
        ''出力対象ﾃﾞｰﾀ
        Dim NGDataTBL As DataTable
        NGDataTBL = DistinctSerialTBL.Clone


        ''AASのHWは優先して出力する。
        Dim chkDistinctSerialList As New ArrayList
        Dim filter As New StringBuilder
        filter.Append("Cell" & SerialSheetColumns.PATTERN_CD)
        filter.Append(CommonConstant.SQL_STR_IN)
        filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        filter.Append("1")
        filter.Append(CommonConstant.STR_COMMA)
        filter.Append("2")
        filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
        Dim insRow As DataRow
        For Each insRow In DistinctSerialTBL.Select(filter.ToString, "Cell" & SerialSheetColumns.LINE_NO)
            strKey = insRow("Cell" & SerialSheetColumns.PROD_ITEM01) & insRow("Cell" & SerialSheetColumns.PROD_TmpSerial)
            If chkDistinctSerialList.IndexOf(strKey) = -1 Then
                chkDistinctSerialList.Add(strKey)
            Else
                NGDataTBL.ImportRow(insRow)
            End If
        Next

        ''AASのHW以外の情報をセットする。
        filter.Length = 0
        filter.Append("Cell" & SerialSheetColumns.PATTERN_CD)
        filter.Append(CommonConstant.SQL_STR_NOT)
        filter.Append(CommonConstant.SQL_STR_IN)
        filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        filter.Append("1")
        filter.Append(CommonConstant.STR_COMMA)
        filter.Append("2")
        filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
        For Each insRow In DistinctSerialTBL.Select(filter.ToString, "Cell" & SerialSheetColumns.LINE_NO)
            strKey = insRow("Cell" & SerialSheetColumns.PROD_ITEM01) & insRow("Cell" & SerialSheetColumns.PROD_TmpSerial)
            If chkDistinctSerialList.IndexOf(strKey) = -1 Then
                chkDistinctSerialList.Add(strKey)
            Else
                NGDataTBL.ImportRow(insRow)
            End If
        Next

        ''NG情報からデータを削除
        Dim sLineNo As String
        Dim OutSerialXlsCellInfo(,) As Object
        Dim delIndx As Integer
        delIndx = OutSerialArrayList.Count - 1
        For j As Integer = delIndx To 0 Step -1
            OutSerialXlsCellInfo = OutSerialArrayList(j)
            sLineNo = OutSerialXlsCellInfo(0, SerialSheetColumns.LINE_NO - 1)

            filter.Length = 0
            filter.Append("Cell" & SerialSheetColumns.LINE_NO)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(sLineNo))
            If NGDataTBL.Select(filter.ToString).Length <> 0 Then
                Call OutSerialArrayList.RemoveAt(j)
            End If
        Next

    End Sub

    ''' <summary>
    ''' 機　能：ｼﾘｱﾙシートの書き込みを行う。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetSerialSheet(ByRef OutSerialArrayList As ArrayList, _
                               ByRef xlOutSerialSheet As Excel.Worksheet)


        Dim tmpXlsRow As Excel.Range
        Dim pstXlsRow As Excel.Range

        Try
            ''テンプレート行のコピペ
            'EXCELの範囲サイズエラーになる可能性があるため
            Const CopyMaxRow As Integer = 1000      ''1度にコピーするMax行数    
            Dim copyCount As Integer                ''コピーする回数
            Dim rowCount As Integer                 ''出力する行数
            rowCount = OutSerialArrayList.Count
            copyCount = System.Math.Truncate(rowCount / CopyMaxRow)
            tmpXlsRow = xlOutSerialSheet.Rows(EXCEL_DELIVERYEXPORT_TEMPTROW)
            tmpXlsRow.Hidden = False
            tmpXlsRow.Copy()

            Dim i As Integer
            Dim pasteStr As Integer                 ''貼付開始位置
            Dim pasteEnd As Integer                 ''貼付終了位置
            For i = 1 To copyCount
                pasteStr = EXCEL_DELIVERYEXPORT_OUTROW + ((i - 1) * CopyMaxRow)
                pasteEnd = EXCEL_DELIVERYEXPORT_OUTROW + ((i) * CopyMaxRow) - 1
                pstXlsRow = xlOutSerialSheet.Rows("@Str:@End".Replace("@Str", pasteStr).Replace("@End", pasteEnd))
                Call pstXlsRow.PasteSpecial()
                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                ExcelObjRelease.ReleaseExcelObj(pstXlsRow, ExcelObjRelease.OBJECT_NOTHING)
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            Next
            If rowCount > pasteEnd - EXCEL_DELIVERYEXPORT_OUTROW + 1 Or copyCount = 0 Then
                pasteStr = EXCEL_DELIVERYEXPORT_OUTROW + ((copyCount) * CopyMaxRow)
                pasteEnd = EXCEL_DELIVERYEXPORT_OUTROW + rowCount - 1
                pstXlsRow = xlOutSerialSheet.Rows("@Str:@End".Replace("@Str", pasteStr).Replace("@End", pasteEnd))
                Call pstXlsRow.PasteSpecial()
                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                ExcelObjRelease.ReleaseExcelObj(pstXlsRow, ExcelObjRelease.OBJECT_NOTHING)
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            End If
            tmpXlsRow.Hidden = True

            ''値の貼り付け
            Dim pasteRowCount As Integer
            Dim obj(,) As Object
            For pasteRowCount = EXCEL_DELIVERYEXPORT_OUTROW To EXCEL_DELIVERYEXPORT_OUTROW + rowCount - 1

                obj = OutSerialArrayList(pasteRowCount - EXCEL_DELIVERYEXPORT_OUTROW)
                pstXlsRow = xlOutSerialSheet.Range("A@:MM@".Replace("@", pasteRowCount))
                pstXlsRow.Value = obj
                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                ExcelObjRelease.ReleaseExcelObj(pstXlsRow, ExcelObjRelease.OBJECT_NOTHING)
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

            Next

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(tmpXlsRow, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(pstXlsRow, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' 機　能：ｼﾘｱﾙシートの書き込みを行う。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetPSSheet(ByRef OutPSArrayList As ArrayList, _
                           ByRef OutSerialArrayList As ArrayList, _
                           ByRef xlOutPSSheet As Excel.Worksheet)


        Dim tmpXlsRow As Excel.Range
        Dim pstXlsRow As Excel.Range

        Try
            ''テンプレート行のコピペ
            Const CopyMaxRow As Integer = 1000      ''1度にコピーするMax行数    
            Dim copyCount As Integer                ''コピーする回数
            Dim rowCount As Integer                 ''出力する行数
            rowCount = OutPSArrayList.Count
            copyCount = System.Math.Truncate(rowCount / CopyMaxRow)
            tmpXlsRow = xlOutPSSheet.Rows(EXCEL_DELIVERYEXPORT_TEMPTROW)
            tmpXlsRow.Hidden = False
            tmpXlsRow.Copy()

            Dim i As Integer
            Dim pasteStr As Integer                 ''貼付開始位置
            Dim pasteEnd As Integer                 ''貼付終了位置
            For i = 1 To copyCount
                pasteStr = EXCEL_DELIVERYEXPORT_OUTROW + ((i - 1) * CopyMaxRow)
                pasteEnd = EXCEL_DELIVERYEXPORT_OUTROW + ((i) * CopyMaxRow) - 1
                pstXlsRow = xlOutPSSheet.Rows("@Str:@End".Replace("@Str", pasteStr).Replace("@End", pasteEnd))
                Call pstXlsRow.PasteSpecial()
                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                ExcelObjRelease.ReleaseExcelObj(pstXlsRow, ExcelObjRelease.OBJECT_NOTHING)
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            Next
            If rowCount > pasteEnd - EXCEL_DELIVERYEXPORT_OUTROW + 1 Or copyCount = 0 Then
                pasteStr = EXCEL_DELIVERYEXPORT_OUTROW + ((copyCount) * CopyMaxRow)
                pasteEnd = EXCEL_DELIVERYEXPORT_OUTROW + rowCount - 1
                pstXlsRow = xlOutPSSheet.Rows("@Str:@End".Replace("@Str", pasteStr).Replace("@End", pasteEnd))
                Call pstXlsRow.PasteSpecial()
                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                ExcelObjRelease.ReleaseExcelObj(pstXlsRow, ExcelObjRelease.OBJECT_NOTHING)
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            End If
            tmpXlsRow.Hidden = True

            ''値の貼り付け
            Dim searchCount As Integer
            Dim pasteRowCount As Integer
            Dim obj(,) As Object
            Dim searchObj(,) As Object
            Dim searchSerialCount As Integer
            Dim strPatternCd As String
            Dim strPsMtdl As String

            For pasteRowCount = EXCEL_DELIVERYEXPORT_OUTROW To EXCEL_DELIVERYEXPORT_OUTROW + rowCount - 1

                ''仮シリアルが一致するデータがあれば、参照式をセット
                If OutPSArrayList(pasteRowCount - EXCEL_DELIVERYEXPORT_OUTROW)(0, PaymentSheetColumns.PROD_ITEM02 - 1) <> "" Then

                    searchSerialCount = 0
                    For searchCount = 0 To OutSerialArrayList.Count - 1
                        strPatternCd = OutPSArrayList(pasteRowCount - EXCEL_DELIVERYEXPORT_OUTROW)(0, PaymentSheetColumns.PATTERN_CD - 1)
                        Select Case strPatternCd
                            Case "5", "7", "9", "10", "13"
                                strPsMtdl = OutPSArrayList(pasteRowCount - EXCEL_DELIVERYEXPORT_OUTROW)(0, PaymentSheetColumns.PROD_ITEM04 - 1)
                            Case Else
                                strPsMtdl = OutPSArrayList(pasteRowCount - EXCEL_DELIVERYEXPORT_OUTROW)(0, PaymentSheetColumns.PROD_ITEM01 - 1)
                        End Select
                        If OutSerialArrayList(searchCount)(0, SerialSheetColumns.PROD_TmpSerial - 1) = _
                           OutPSArrayList(pasteRowCount - EXCEL_DELIVERYEXPORT_OUTROW)(0, PaymentSheetColumns.PROD_ITEM02 - 1) And
                           OutSerialArrayList(searchCount)(0, SerialSheetColumns.PROD_ITEM01 - 1) = strPsMtdl Then
                            searchSerialCount = searchCount + EXCEL_DELIVERYEXPORT_OUTROW
                            Exit For
                        End If
                    Next
                    If searchSerialCount <> 0 Then
                        OutPSArrayList(pasteRowCount - EXCEL_DELIVERYEXPORT_OUTROW)(0, PaymentSheetColumns.PROD_SERIAL - 1) = "=ｼﾘｱﾙ!AJ@".Replace("@", searchSerialCount)
                    End If
                End If

                obj = OutPSArrayList(pasteRowCount - EXCEL_DELIVERYEXPORT_OUTROW)
                pstXlsRow = xlOutPSSheet.Range("A@:MO@".Replace("@", pasteRowCount))
                pstXlsRow.Formula = obj

            Next

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(tmpXlsRow, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(pstXlsRow, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' 機　能：デリバリーファイルの特殊文字を変換する。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function ChkInputDate(ByVal chkValue As String,
                                  ByVal ColumnNM As Integer) As String

        ''初期化
        ChkInputDate = chkValue


        Select Case ColumnNM

            Case PaymentSheetColumns.LETTER_ACCEPT_DATE,
                 PaymentSheetColumns.ORDER_DATE

                ''※「1900/01/01」の場合、再出力とみなして空白を返す。
                ''「1900/01/01 ⇒ 8888/01/01」 
                If chkValue = "8888/01/01" Then
                    ChkInputDate = ""

                ElseIf chkValue = "9999/01/01" Then
                    ChkInputDate = chkValue

                Else
                    ChkInputDate = chkValue

                End If

            Case PaymentSheetColumns.LETTER_ID

                ''承認番号,実行通知番号
                ''※「*」 or「*発注MAX確認不可」の場合、再出力対象とするため値をセット
                If chkValue = "*" Or chkValue = "*発注MAX確認不可" Then
                    ChkInputDate = "*"

                ElseIf chkValue = "対象外" Then
                    ChkInputDate = ""

                Else
                    ChkInputDate = chkValue

                End If

            Case PaymentSheetColumns.BRAND_AP_CONF,
                 PaymentSheetColumns.BRAND_AP_REQ

                ''承認番号,実行通知番号
                ''※「*」 or「*発注MAX確認不可」の場合、再出力対象とするため値をセット
                If chkValue = "*" Or chkValue = "*発注MAX確認不可" Then
                    ChkInputDate = ""

                ElseIf chkValue = "対象外" Then
                    ChkInputDate = chkValue

                Else
                    ChkInputDate = chkValue

                End If

            Case Else

        End Select

    End Function

    ''' <summary>
    ''' 機　能：Topacsの情報をWorkMDBにセットする。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub UpdASRPaymentTopacsDataTable(ByRef con As ADODB.Connection,
                                             ByRef xlInPSSheet As Excel.Worksheet)

        Dim xlCell As Excel.Range
        Dim cellObj(,) As Object
        Dim rsIns As New ADODB.Recordset

        Try

            ''Recordsetの設定
            Dim sqlFilter As New StringBuilder
            sqlFilter.Append(CommonConstant.SQL_STR_SELECT)
            sqlFilter.Append(CommonConstant.SQL_STR_ASTERISK)
            sqlFilter.Append(CommonConstant.SQL_STR_FROM)
            sqlFilter.Append("FrmASRReadPaymentTopacs")
            Call rsIns.Open(sqlFilter.ToString, con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)


            'インプットのWS1編集情報をデータテーブルに格納する
            Const ColumNM_TOPACS_FLG As Integer = 2                   ''Topacs対象
            Const ColumNM_LINE_NO As Integer = 4                      ''行番号
            Const ColumNM_LETTER_PLAN_DATE As Integer = 10            ''業務メモ情報
            Const ColumNM_BRAND_AP_REQ As Integer = 13                ''申請番号
            Const ColumNM_BRAND_AP_CONF As Integer = 14               ''承認番号
            Dim LIndex As Integer = EXCEL_DELIVERYEXPORT_OUTROW

            Do
                ''1行取得            
                xlCell = xlInPSSheet.Range("A@:N@".Replace("@", LIndex))
                cellObj = xlCell.Value
                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

                ''EOF判定
                If ExcelWrite.changeDBNullToString(cellObj(1, ColumNM_LINE_NO)) = "" Then
                    Exit Sub
                End If

                ''MDBのInsert
                rsIns.AddNew()
                rsIns.Fields("EXCEL_ROW").Value = LIndex.ToString.PadLeft(6, "0")
                rsIns.Fields("TOPACS_FLG").Value = ExcelWrite.changeDBNullToString(cellObj(1, ColumNM_TOPACS_FLG))
                rsIns.Fields("LETTER_PLAN_DATE").Value = ExcelWrite.changeDBNullToString(cellObj(1, ColumNM_LETTER_PLAN_DATE))
                rsIns.Fields("LINE_NO").Value = ExcelWrite.changeDBNullToString(cellObj(1, ColumNM_LINE_NO))
                rsIns.Fields("BRAND_AP_REQ").Value = ExcelWrite.changeDBNullToString(cellObj(1, ColumNM_BRAND_AP_REQ))
                rsIns.Fields("BRAND_AP_CONF").Value = ExcelWrite.changeDBNullToString(cellObj(1, ColumNM_BRAND_AP_CONF))
                rsIns.Fields("OUT_LOG").Value = ""
                rsIns.Update()
                LIndex = LIndex + 1
            Loop

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            If rsIns.State = ADODB.ObjectStateEnum.adStateOpen Then
                rsIns.Close()
            End If
            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' 機　能：(ﾃﾞﾘﾊﾞﾘ支援の)実行管理情報をWorkMDBにセットする。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub UpdASRPaymentACTDataTable(ByRef con As ADODB.Connection,
                                          ByRef xlInPSSheet As Excel.Worksheet)

        Dim xlCell As Excel.Range
        Dim cellObj(,) As Object
        Dim rsIns As New ADODB.Recordset

        Try

            ''Recordsetの設定
            Dim sqlFilter As New StringBuilder
            sqlFilter.Append(CommonConstant.SQL_STR_SELECT)
            sqlFilter.Append(CommonConstant.SQL_STR_ASTERISK)
            sqlFilter.Append(CommonConstant.SQL_STR_FROM)
            sqlFilter.Append("FrmASRReadPaymentACT")
            Call rsIns.Open(sqlFilter.ToString, con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)


            'インプットのWS2編集情報をデータテーブルに格納する
            Const ColumNM_ACT_FLG As Integer = 1                    ''実行管理FLG
            Const ColumNM_LINE_NO As Integer = 4                    ''行番号
            Const ColumNM_PROJ_ID As Integer = 6                    ''案件番号
            Const ColumNM_LETTER_ACCEPT_DATE As Integer = 7         ''通知書お客様捺印日
            Const ColumNM_ORDER_DATE As Integer = 8                 ''発注完了確認日
            Const ColumNM_LETTER_ID As Integer = 9                  ''通知書番号
            Const ColumNM_LETTER_PLAN_DATE As Integer = 10          ''業務メモ情報

            Dim LIndex As Integer = EXCEL_DELIVERYEXPORT_OUTROW

            Do
                ''1行取得            
                xlCell = xlInPSSheet.Range("A@:S@".Replace("@", LIndex))
                cellObj = xlCell.Value
                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

                ''EOF判定
                If ExcelWrite.changeDBNullToString(cellObj(1, ColumNM_LINE_NO)) = "" Then
                    Exit Sub
                End If

                ''MDBのInsert
                rsIns.AddNew()
                rsIns.Fields("EXCEL_ROW").Value = LIndex.ToString.PadLeft(6, "0")
                rsIns.Fields("ACT_FLG").Value = ExcelWrite.changeDBNullToString(cellObj(1, ColumNM_ACT_FLG))
                rsIns.Fields("LETTER_ID").Value = ExcelWrite.changeDBNullToString(cellObj(1, ColumNM_LETTER_ID))
                rsIns.Fields("LINE_NO").Value = ExcelWrite.changeDBNullToString(cellObj(1, ColumNM_LINE_NO))
                rsIns.Fields("PROJ_ID").Value = ExcelWrite.changeDBNullToString(cellObj(1, ColumNM_PROJ_ID))
                rsIns.Fields("LETTER_PLAN_DATE").Value = ExcelWrite.changeDBNullToString(cellObj(1, ColumNM_LETTER_PLAN_DATE))
                If IsDate(ExcelWrite.changeDBNullToString(cellObj(1, ColumNM_LETTER_ACCEPT_DATE))) Then
                    rsIns.Fields("LETTER_ACCEPT_DATE").Value = Format(CDate(ExcelWrite.changeDBNullToString(cellObj(1, ColumNM_LETTER_ACCEPT_DATE))), "yyyy/MM/dd")
                Else
                    rsIns.Fields("LETTER_ACCEPT_DATE").Value = ExcelWrite.changeDBNullToString(cellObj(1, ColumNM_LETTER_ACCEPT_DATE))
                End If
                If IsDate(ExcelWrite.changeDBNullToString(cellObj(1, ColumNM_ORDER_DATE))) Then
                    rsIns.Fields("ORDER_DATE").Value = Format(CDate(ExcelWrite.changeDBNullToString(cellObj(1, ColumNM_ORDER_DATE))), "yyyy/MM/dd")
                Else
                    rsIns.Fields("ORDER_DATE").Value = ExcelWrite.changeDBNullToString(cellObj(1, ColumNM_ORDER_DATE))
                End If
                rsIns.Fields("OUT_LOG").Value = ""
                rsIns.Update()
                LIndex = LIndex + 1
            Loop

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            If rsIns.State = ADODB.ObjectStateEnum.adStateOpen Then
                rsIns.Close()
            End If
            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' 機　能：ｼﾘｱﾙシートの情報をWorkMDBにセットする。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub UpdASRSerialDataTable(ByRef con As ADODB.Connection,
                                      ByRef xlInTmpSerialSheet As Excel.Worksheet)

        Dim xlCell As Excel.Range
        Dim cellObj(,) As Object
        Dim rsIns As New ADODB.Recordset

        Try

            ''Recordsetの設定
            Dim sqlFilter As New StringBuilder
            sqlFilter.Append(CommonConstant.SQL_STR_SELECT)
            sqlFilter.Append(CommonConstant.SQL_STR_ASTERISK)
            sqlFilter.Append(CommonConstant.SQL_STR_FROM)
            sqlFilter.Append("FrmASRReadSerial")
            Call rsIns.Open(sqlFilter.ToString, con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)


            'インプットのWS3編集情報をデータテーブルに格納する
            Const ColumnNM_LINE_NO As Integer = 1       ''行番号
            Const ColumnNM_MTDL As Integer = 15         ''MTDL
            Const ColumnNM_TMP_SERIAL As Integer = 17   ''仮シリアル
            Const ColumnNM_SERIAL As Integer = 18       ''実シリアル
            Const ColumnNM_N_QTY As Integer = 22        ''数量
            Const ColumnNM_INST_DATE As Integer = 23    ''導入年月
            Const ColumnNM_LIST_PRICE As Integer = 29   ''List Price(小計)Validation後

            Dim LIndex As Integer = EXCEL_DELIVERYEXPORT_OUTROW

            Do
                ''1行取得            
                xlCell = xlInTmpSerialSheet.Range("A@:AE@".Replace("@", LIndex))
                cellObj = xlCell.Value
                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

                ''EOF判定
                Dim blnRet As Boolean
                blnRet = CheckRowSerial(cellObj)
                If blnRet = False Then
                    Exit Do
                End If

                ''MDBのInsert
                rsIns.AddNew()
                rsIns.Fields("EXCEL_ROW").Value = LIndex.ToString.PadLeft(6, "0")
                Dim inst_YM As String
                inst_YM = ExcelWrite.changeDBNullToString(cellObj(1, ColumnNM_INST_DATE))
                rsIns.Fields("INST_YM").Value = inst_YM
                rsIns.Fields("LINE_NO").Value = ExcelWrite.changeDBNullToString(cellObj(1, ColumnNM_LINE_NO))
                rsIns.Fields("MTDL").Value = ExcelWrite.changeDBNullToString(cellObj(1, ColumnNM_MTDL))
                rsIns.Fields("TMP_SERIAL").Value = ExcelWrite.changeDBNullToString(cellObj(1, ColumnNM_TMP_SERIAL))
                Dim serial As String
                If ExcelWrite.changeDBNullToString(cellObj(1, ColumnNM_SERIAL)) = "*" Then
                    rsIns.Fields("SERIAL").Value = ExcelWrite.changeDBNullToString(cellObj(1, ColumnNM_TMP_SERIAL)) & "*"
                Else
                    rsIns.Fields("SERIAL").Value = ExcelWrite.changeDBNullToString(cellObj(1, ColumnNM_SERIAL))
                End If
                rsIns.Fields("N_QTY").Value = ExcelWrite.changeDBNullToString(cellObj(1, ColumnNM_N_QTY))
                rsIns.Fields("LIST_PRICE").Value = ExcelWrite.changeDBNullToString(cellObj(1, ColumnNM_LIST_PRICE))
                rsIns.Fields("OUT_LOG").Value = ""
                rsIns.Update()

                LIndex = LIndex + 1
            Loop

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            If rsIns.State = ADODB.ObjectStateEnum.adStateOpen Then
                rsIns.Close()
            End If
            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' Payment反映処理
    ''' </summary>
    ''' <param name="con">Connection</param>
    ''' <param name="eofLine"></param>
    ''' <param name="xlOutOBAMASheet"></param>
    ''' <remarks></remarks>
    Private Sub WriteDeliveryToPayment(ByRef con As ADODB.Connection,
                                       ByVal eofLine As Integer,
                                       ByRef xlOutOBAMASheet As Excel.Worksheet)

        Dim strSQL As String
        Dim strRange As String
        Dim strPathCsv As String
        Dim strFileNameCsv As String
        Dim rsPT1PT2 As ADODB.Recordset
        Dim rsPT3 As ADODB.Recordset
        Dim intRecCnt As Integer
        Dim ofm As New OioFileManage
        Dim strOutputLine As String
        Dim intFieldCnt As Integer
        Dim strPastPriceTotal As String
        Dim strWork As String
        Dim strOutYear As String
        Dim strOutMonth As String

        Dim xlCell As Excel.Range = Nothing
        Dim xlRange As Excel.Range = Nothing
        Dim xlEntireRow As Excel.Range = Nothing

        Try
            strSQL = WriteDeliveryToPaymentSQL()
            Debug.Print(strSQL)
            rsPT1PT2 = New ADODB.Recordset
            Call rsPT1PT2.Open(strSQL, con, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic)
            intRecCnt = rsPT1PT2.RecordCount
            If intRecCnt > 0 Then

                '----------------------------
                '罫線作成
                '----------------------------
                Const DIVISION_LINES As Long = 1000
                Dim lngSho As Long = intRecCnt \ DIVISION_LINES
                Dim lngAmari As Long = intRecCnt Mod DIVISION_LINES
                Dim lngCnt As Long

                xlCell = xlOutOBAMASheet.Range("2:2")
                xlEntireRow = xlCell.EntireRow
                xlEntireRow.Hidden = False
                ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)
                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

                For lngCnt = 1 To lngSho
                    xlCell = xlOutOBAMASheet.Range("2:2")
                    xlCell.Copy()
                    ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                    strRange = (EXCEL_PAYMENTLINEDATE_OUTROW + (lngCnt - 1) * DIVISION_LINES).ToString() & ":" & (EXCEL_PAYMENTLINEDATE_OUTROW + lngCnt * DIVISION_LINES - 1).ToString()
                    Debug.Print("枠コピー１：" & strRange)
                    xlCell = xlOutOBAMASheet.Range(strRange)
                    xlCell.Insert()
                    ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                Next
                If lngAmari > 0 Then
                    xlCell = xlOutOBAMASheet.Range("2:2")
                    xlCell.Copy()
                    ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                    strRange = (EXCEL_PAYMENTLINEDATE_OUTROW + (lngSho * DIVISION_LINES)).ToString() & ":" & (EXCEL_PAYMENTLINEDATE_OUTROW + (lngSho * DIVISION_LINES + lngAmari) - 1).ToString()
                    Debug.Print("枠コピー２：" & strRange)
                    xlCell = xlOutOBAMASheet.Range(strRange)
                    xlCell.Insert()
                    ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                End If
                xlCell = xlOutOBAMASheet.Range("2:2")
                xlEntireRow = xlCell.EntireRow
                xlEntireRow.Hidden = True
                ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)
                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

                '----------------------------
                '中間ファイル作成
                '----------------------------
                strPathCsv = Path.GetFullPath("../log/")
                strFileNameCsv = strPathCsv & "WorkCsv_DeliveryDataPs_" & Now.ToString("yyyyMMdd_HHmmss") & ".csv"
                Using sw As New StreamWriter(strFileNameCsv, False, System.Text.Encoding.Default)

                    rsPT1PT2.MoveFirst()
                    While rsPT1PT2.EOF = False
                        '----------------------------
                        '項目取得
                        '----------------------------
                        '''' 　　処理：出力データ作成（年額月額展開以外の項目）
                        strOutputLine = ""

                        For intFieldCnt = 0 To (rsPT1PT2.Fields.Count - 1)
                            Select Case rsPT1PT2.Fields(intFieldCnt).Name
                                Case "ID"
                                Case "PAST_PRICE_TOTAL"
                                    strPastPriceTotal = """" & GetAdodbData(rsPT1PT2, "PAST_PRICE_TOTAL") & ""","
                                Case Else
                                    strWork = GetAdodbData(rsPT1PT2, rsPT1PT2.Fields(intFieldCnt).Name)
                                    strWork = strWork.Replace("""", """""")
                                    strOutputLine = strOutputLine & """" & strWork & ""","
                            End Select
                        Next

                        '----------------------------
                        '年額月額展開取得
                        '----------------------------
                        '''' 　　処理：出力データ作成（年額月額展開と展開金額の項目）
                        '''' 　　　①PaymentTBL1、PaymentTBL2に該当するIDでPaymentTBL3を検索する
                        '''' 　　　②年額展開、月額展開のデータを取得する
                        rsPT3 = New ADODB.Recordset
                        strSQL = "SELECT * FROM PaymentTBL3 WHERE ID='" & GetAdodbData(rsPT1PT2, "ID") & "' ORDER BY INT(IOC_YEAER)"
                        Call rsPT3.Open(strSQL, con, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic)
                        strOutYear = ""
                        strOutMonth = ""
                        rsPT3.MoveFirst()
                        While rsPT3.EOF = False
                            '年額展開取得
                            strWork = GetAdodbData(rsPT3, "IOC_YYYY")
                            strWork = strWork.Replace("""", """""")
                            strOutYear = strOutYear & """" & strWork & ""","
                            '月額展開取得
                            For intYearCnt As Integer = 1 To 12
                                strWork = GetAdodbData(rsPT3, "IOC_" & intYearCnt.ToString("00"))
                                strWork = strWork.Replace("""", """""")
                                strOutMonth = strOutMonth & """" & strWork & ""","
                            Next
                            rsPT3.MoveNext()
                        End While
                        strOutputLine = strOutputLine & strOutYear & strPastPriceTotal & strOutMonth
                        rsPT3.Close()

                        sw.WriteLine(strOutputLine)

                        rsPT1PT2.MoveNext()
                    End While
                    rsPT1PT2.Close()
                End Using

                '----------------------------
                'Paymentに反映
                '----------------------------
                Dim intDataType(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12 - 1) As Integer
                Call ExcelWrite.SetExcelDataTypePayment(intDataType)
                strRange = "A" & EXCEL_PAYMENTLINEDATE_OUTROW.ToString
                Call ExcelWrite.LoadCsvToExcel(strFileNameCsv, 1, "Payment", strRange, xlOutOBAMASheet, intDataType)
            End If

        Catch ex As Exception
            Throw ex
        Finally
            '''' ﾜｰｸﾌｧｲﾙ削除
            Call ofm.DeleteWorkFile(strPathCsv)

            '''' 処理：Excelｵﾌﾞｼﾞｪｸﾄの解放
            ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try

    End Sub

    ''' <summary>
    ''' デリバリ情報をPaymentに反映するSQLを作成
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function WriteDeliveryToPaymentSQL() As String

        Dim strSQL As String = ""

        WriteDeliveryToPaymentSQL = ""

        Try
            strSQL = "SELECT " & vbCrLf
            strSQL = strSQL & "    TBL1.ID, " & vbCrLf
            strSQL = strSQL & "    'U' AS UPDATE_FLAG, " & vbCrLf
            strSQL = strSQL & "    TBL1.LOCK_FLAG, " & vbCrLf
            strSQL = strSQL & "    TBL1.VALID_FLAG, " & vbCrLf
            strSQL = strSQL & "    TBL1.LINE_NO, " & vbCrLf
            strSQL = strSQL & "    TBL1.FILE_NAME, " & vbCrLf
            strSQL = strSQL & "    TBL1.FILE_NAME_SUFFIX, " & vbCrLf
            strSQL = strSQL & "    TBL1.FILE_NAME_SUFFIX_INTR, " & vbCrLf
            strSQL = strSQL & "    TBL1.CONTRACT, " & vbCrLf
            strSQL = strSQL & "    TBL1.ST_COST, " & vbCrLf
            strSQL = strSQL & "    TBL1.ST_APPROVAL, " & vbCrLf
            strSQL = strSQL & "    TBL1.PROJ_ID, " & vbCrLf
            strSQL = strSQL & "    TBL1.CONTRACT_SEQ, " & vbCrLf
            strSQL = strSQL & "    TBL1.NEW_EXIST, " & vbCrLf
            strSQL = strSQL & "    TBL1.CUST_CATEGORY, " & vbCrLf
            strSQL = strSQL & "    IIf(IDList.TBL1_DATA='有り' Or IDList.TBL2_DATA='有り',IDList.LETTER_PLAN_DATE,TBL1.LETTER_PLAN_DATE) AS LETTER_PLAN_DATE, " & vbCrLf
            strSQL = strSQL & "    IIf(IDList.TBL2_DATA='有り',IDList.LETTER_ACCEPT_DATE,TBL1.LETTER_ACCEPT_DATE) AS LETTER_ACCEPT_DATE, " & vbCrLf
            strSQL = strSQL & "    IIf(IDList.TBL2_DATA='有り',IDList.ORDER_DATE,TBL1.ORDER_DATE) AS ORDER_DATE, " & vbCrLf
            strSQL = strSQL & "    IIf(IDList.TBL2_DATA='有り',IDList.LETTER_ID,TBL1.LETTER_ID) AS LETTER_ID, " & vbCrLf
            strSQL = strSQL & "    TBL1.BILLING_CD, " & vbCrLf
            strSQL = strSQL & "    TBL1.BU, " & vbCrLf
            strSQL = strSQL & "    TBL1.BRAND, " & vbCrLf
            strSQL = strSQL & "    TBL1.SUM_CATEGORY, " & vbCrLf
            strSQL = strSQL & "    TBL1.BRAND_SUB, " & vbCrLf
            strSQL = strSQL & "    TBL1.T_OP1, " & vbCrLf
            strSQL = strSQL & "    TBL1.T_OP2, " & vbCrLf
            strSQL = strSQL & "    TBL1.T_SIZE, " & vbCrLf
            strSQL = strSQL & "    TBL1.NON_SBO, " & vbCrLf
            strSQL = strSQL & "    TBL1.ADDITION_ITEM, " & vbCrLf
            strSQL = strSQL & "    TBL1.TOPACS_CPNO, " & vbCrLf
            strSQL = strSQL & "    TBL1.BRAND_AP_FORM, " & vbCrLf
            strSQL = strSQL & "    TBL1.BRAND_AP_REQ, " & vbCrLf
            strSQL = strSQL & "    TBL1.BRAND_AP_CONF, " & vbCrLf
            strSQL = strSQL & "    TBL1.PATTERN_CD, TBL1.PATTERN, " & vbCrLf
            strSQL = strSQL & "    TBL1.PROD_ITEM01, " & vbCrLf
            strSQL = strSQL & "    IIf(IDList.TBL3_DATA='有り',IDList.SERIAL,TBL1.PROD_ITEM02) AS PROD_ITEM02, " & vbCrLf
            strSQL = strSQL & "    TBL1.PROD_ITEM03, " & vbCrLf
            strSQL = strSQL & "    TBL1.PROD_ITEM04, " & vbCrLf
            strSQL = strSQL & "    TBL1.PROD_ITEM05, " & vbCrLf
            strSQL = strSQL & "    TBL1.PROD_ITEM06, " & vbCrLf
            strSQL = strSQL & "    TBL1.PROD_ITEM07, " & vbCrLf
            strSQL = strSQL & "    TBL1.PROD_ITEM08, " & vbCrLf
            strSQL = strSQL & "    TBL1.PROD_ITEM09, " & vbCrLf
            strSQL = strSQL & "    TBL1.PROD_ITEM10, " & vbCrLf
            strSQL = strSQL & "    TBL1.PROD_ITEM11, " & vbCrLf
            strSQL = strSQL & "    TBL1.PROD_ITEM12, " & vbCrLf
            strSQL = strSQL & "    TBL1.PROD_ITEM13, " & vbCrLf
            strSQL = strSQL & "    TBL1.PROD_ITEM14, " & vbCrLf
            strSQL = strSQL & "    TBL1.PROD_ITEM15, " & vbCrLf
            strSQL = strSQL & "    TBL1.PROD_ITEM16, " & vbCrLf
            strSQL = strSQL & "    TBL1.PROD_ITEM17, " & vbCrLf
            strSQL = strSQL & "    TBL1.PROD_ITEM18, " & vbCrLf
            strSQL = strSQL & "    TBL1.PROD_ITEM19, " & vbCrLf
            strSQL = strSQL & "    TBL1.PROD_ITEM20, " & vbCrLf
            strSQL = strSQL & "    TBL1.PROD_ITEM22, " & vbCrLf
            strSQL = strSQL & "    TBL1.PROD_ITEM23, " & vbCrLf
            strSQL = strSQL & "    TBL1.PROD_ITEM24, " & vbCrLf
            strSQL = strSQL & "    TBL2.WD_ANNT_DATE, " & vbCrLf
            strSQL = strSQL & "    TBL2.WD_DATE, " & vbCrLf
            strSQL = strSQL & "    TBL2.PRICE_CHG_DATE, " & vbCrLf
            strSQL = strSQL & "    TBL2.QTY, " & vbCrLf
            strSQL = strSQL & "    TBL2.INST_DATE, " & vbCrLf
            strSQL = strSQL & "    TBL2.PAY_START_DATE, " & vbCrLf
            strSQL = strSQL & "    TBL2.PAY_END_DATE, " & vbCrLf
            strSQL = strSQL & "    TBL2.IGF_START_DATE, " & vbCrLf
            strSQL = strSQL & "    TBL2.IGF_END_DATE, " & vbCrLf
            strSQL = strSQL & "    TBL2.PAY_FLAG, " & vbCrLf
            strSQL = strSQL & "    TBL2.BID_FLAG, " & vbCrLf
            strSQL = strSQL & "    TBL2.PAY_MONTHS, " & vbCrLf
            strSQL = strSQL & "    TBL2.VALID_CTRL, " & vbCrLf
            strSQL = strSQL & "    TBL2.PAY_METHOD, " & vbCrLf
            strSQL = strSQL & "    TBL2.IGF_APPLIED, " & vbCrLf
            strSQL = strSQL & "    TBL2.IGF_CONT_NO, " & vbCrLf
            strSQL = strSQL & "    TBL2.IGF_CONT_TYPE, " & vbCrLf
            strSQL = strSQL & "    TBL2.IGF_PROPERTY, " & vbCrLf
            strSQL = strSQL & "    TBL2.IGF_RATE_IOC, " & vbCrLf
            strSQL = strSQL & "    TBL2.LIST_PRICE_PROPOSAL, " & vbCrLf
            strSQL = strSQL & "    TBL2.LIST_PRICE, " & vbCrLf
            strSQL = strSQL & "    TBL2.LIST_PRICE_TOTAL_PROPOSAL, " & vbCrLf
            strSQL = strSQL & "    TBL2.LIST_PRICE_TOTAL, " & vbCrLf
            strSQL = strSQL & "    TBL2.DP_IOC, " & vbCrLf
            strSQL = strSQL & "    TBL2.PRICE_UNIT_IOC, " & vbCrLf
            strSQL = strSQL & "    TBL2.PRICE_UNIT_IOC_VAL, " & vbCrLf
            strSQL = strSQL & "    TBL2.PRICE_QTY_IOC, " & vbCrLf
            strSQL = strSQL & "    TBL2.COST_RATE, " & vbCrLf
            strSQL = strSQL & "    TBL2.COST, " & vbCrLf
            strSQL = strSQL & "    TBL2.COST_TOTAL, " & vbCrLf
            strSQL = strSQL & "    TBL2.COST_INPUT_DATE, " & vbCrLf
            strSQL = strSQL & "    TBL2.PRICE_TO_SPLIT, " & vbCrLf
            strSQL = strSQL & "    TBL2.LIST_PRICE_TOTAL_IOC, " & vbCrLf
            strSQL = strSQL & "    TBL2.PRICE_TOTAL_IOC, " & vbCrLf
            strSQL = strSQL & "    TBL2.COST_TOTAL_IOC, " & vbCrLf
            strSQL = strSQL & "    TBL2.PRICE_IGF_TOTAL, " & vbCrLf
            strSQL = strSQL & "    TBL2.PRICE_CONT_TOTAL, " & vbCrLf
            strSQL = strSQL & "    TBL2.PRICE_OO_CONT_TOTAL, " & vbCrLf
            strSQL = strSQL & "    TBL2.IGF_DIF_INTEREST, " & vbCrLf
            strSQL = strSQL & "    TBL2.PAST_PRICE_TOTAL " & vbCrLf
            strSQL = strSQL & "    FROM " & vbCrLf
            strSQL = strSQL & "    PaymentTBL2 AS TBL2 INNER JOIN (PaymentTBL1 AS TBL1 INNER JOIN FrmASRRead_IDList_T AS IDList ON TBL1.ID = IDList.ID) ON TBL2.ID = TBL1.ID;" & vbCrLf

            WriteDeliveryToPaymentSQL = strSQL

        Catch ex As Exception
            Throw ex

        End Try

    End Function

    ''' <summary>
    ''' ﾃﾞﾘﾊﾞﾘﾌｧｲﾙにLogを書き戻す
    ''' </summary>
    ''' <param name="intPaymentPeriod">Payment展開期間</param>
    ''' <param name="con">Mdbのｺﾈｸｯｼｮﾝ</param>
    ''' <param name="xlInPSSheet">Paymentｼｰﾄのｵﾌﾞｼﾞｪｸﾄ</param>
    ''' <param name="xlInTmpSerialSheet">ｼﾘｱﾙｼｰﾄのｵﾌﾞｼﾞｪｸﾄ</param>
    ''' <remarks></remarks>
    Private Sub WriteDerivaryLog(ByVal intPaymentPeriod As Integer,
                                 ByRef con As ADODB.Connection,
                                 ByRef xlInPSSheet As Excel.Worksheet,
                                 ByRef xlInTmpSerialSheet As Excel.Worksheet)

        Dim xlCell As Excel.Range
        Dim rsIns As New ADODB.Recordset
        Dim strColSerialLog As String
        Dim strColPsLogAct As String

        Try
            ''ログ情報の初期化
            ''※再取込時用に、エラーログ列を非表示/初期化にする。
            Dim isFirstLog As Boolean
            Const POS_SERIAL_LOG As Integer = 34
            Const POS_PS_TOTALPRICE As Integer = 38

            strColSerialLog = ExcelWrite.ChgExcelRowNumberToChar(POS_SERIAL_LOG)
            strColPsLogAct = ExcelWrite.ChgExcelRowNumberToChar(POS_PS_TOTALPRICE + intPaymentPeriod * 12 + 1)
            xlCell = xlInTmpSerialSheet.Columns(strColSerialLog)
            xlCell.Hidden = True
            xlCell = xlInPSSheet.Columns(strColPsLogAct)
            xlCell.Hidden = True
            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

            ''実行管理のログ情報を書き込み
            Dim sqlFilter As New StringBuilder
            sqlFilter.Remove(0, sqlFilter.Length)
            sqlFilter.Append(CommonConstant.SQL_STR_SELECT)
            sqlFilter.Append(" OutLog ")
            sqlFilter.Append(CommonConstant.SQL_STR_FROM)
            sqlFilter.Append(" FrmASRRead_OUTACTLOG_T")
            sqlFilter.Append(" ORDER BY EXCEL_ROW")
            Call rsIns.Open(sqlFilter.ToString, con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)
            isFirstLog = True
            If rsIns.EOF = False Then
                If isFirstLog Then
                    xlCell = xlInPSSheet.Columns(strColPsLogAct)
                    xlCell.Hidden = False
                    'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                    ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                    'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                    isFirstLog = False
                End If
                Call rsIns.MoveFirst()

                xlCell = xlInPSSheet.Range(strColPsLogAct & EXCEL_DELIVERYEXPORT_OUTROW)
                xlCell.CopyFromRecordset(rsIns)
                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            End If
            rsIns.Close()


            ''ｼﾘｱﾙのログ情報を書き込み
            sqlFilter.Remove(0, sqlFilter.Length)
            sqlFilter.Append(CommonConstant.SQL_STR_SELECT)
            sqlFilter.Append("OutLog")
            sqlFilter.Append(CommonConstant.SQL_STR_FROM)
            sqlFilter.Append(" FrmASRRead_OUTSerialLOG_T")
            sqlFilter.Append(" ORDER BY EXCEL_ROW")
            Call rsIns.Open(sqlFilter.ToString, con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)
            isFirstLog = True
            If rsIns.EOF = False Then
                If isFirstLog Then
                    xlCell = xlInTmpSerialSheet.Columns(strColSerialLog)
                    xlCell.Hidden = False
                    'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                    ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                    'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                    isFirstLog = False
                End If
                Call rsIns.MoveFirst()

                xlCell = xlInTmpSerialSheet.Range(strColSerialLog & EXCEL_DELIVERYEXPORT_OUTROW)
                xlCell.CopyFromRecordset(rsIns)
                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            End If
            rsIns.Close()

        Catch ex As Exception
            Throw ex

        Finally
            ''MDB解放
            If rsIns.State = ADODB.ObjectStateEnum.adStateOpen Then
                rsIns.Close()
            End If

            ''Excel解放
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub

    ' ''' <summary>
    ' ''' 機　能：ﾃﾞﾘﾊﾞﾘﾌｧｲﾙにLogを書き戻す
    ' ''' 説　明：
    ' ''' </summary>
    ' ''' <remarks></remarks>
    Private Sub GetDeriOutCount(ByRef con As ADODB.Connection,
                                ByRef derivaryCount As derivaryCount)

        Dim rsIns As New ADODB.Recordset
        Dim InsertCount As Integer          ''PaymentにInsertした総数
        Dim ACTImportOKRow As Integer
        Dim ACTImportNGRow As Integer
        Dim ACTNoDateRow As Integer
        Dim SerialImportOKRow As Integer
        Dim SerialImportNGRow As Integer
        Dim SerialNoDateRow As Integer

        Try

            Dim sqlBase As New StringBuilder
            Dim sqlWhere As New StringBuilder
            sqlBase.Append(CommonConstant.SQL_STR_SELECT)
            sqlBase.Append(CommonConstant.SQL_STR_COUNT)
            sqlBase.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            sqlBase.Append("1")
            sqlBase.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
            sqlBase.Append(CommonConstant.SQL_STR_FROM)


            Debug.Print(Now.ToString("yyyy/MM/dd HH:mm:ss ") & "PaymentシートInsert総数")
            ''PaymentシートInsert総数
            ''=============================================
            sqlWhere.Remove(0, sqlWhere.Length)
            sqlWhere.Append(CommonConstant.SQL_STR_SELECT)
            sqlWhere.Append(CommonConstant.SQL_STR_COUNT)
            sqlWhere.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            sqlWhere.Append("1")
            sqlWhere.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
            sqlWhere.Append(CommonConstant.SQL_STR_FROM)
            sqlWhere.Append(" FrmASRRead_IDList_T ")
            Debug.Print(sqlWhere.ToString)
            Call rsIns.Open(sqlWhere.ToString, con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)
            If rsIns.EOF = False Then
                InsertCount = CInt(rsIns.Fields(0).Value)
            End If
            rsIns.Close()

            ''ACTの出力件数を取得
            ''=============================================
            Debug.Print(Now.ToString("yyyy/MM/dd HH:mm:ss ") & "ACTの出力件数を取得:正常取込み")
            ''正常取込み
            sqlWhere.Remove(0, sqlWhere.Length)
            sqlWhere.Append("FrmASRRead_OUTACTLOG_T")
            sqlWhere.Append(CommonConstant.SQL_STR_WHERE)
            sqlWhere.Append("OutLog")
            sqlWhere.Append(CommonConstant.SQL_STR_EQUAL)
            sqlWhere.Append(StringEdit.EncloseSingleQuotation(""))
            sqlWhere.Append(CommonConstant.SQL_STR_AND)
            sqlWhere.Append("CHKFLG")
            sqlWhere.Append(CommonConstant.SQL_STR_EQUAL)
            sqlWhere.Append(StringEdit.EncloseSingleQuotation("○"))
            Debug.Print(sqlBase.ToString & sqlWhere.ToString)
            Call rsIns.Open(sqlBase.ToString & sqlWhere.ToString, con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)
            If rsIns.EOF = False Then
                ACTImportOKRow = CInt(rsIns.Fields(0).Value)
            End If
            rsIns.Close()

            Debug.Print(Now.ToString("yyyy/MM/dd HH:mm:ss ") & "ACTの出力件数を取得:異常取込み")
            ''異常取込み
            sqlWhere.Remove(0, sqlWhere.Length)
            sqlWhere.Append("FrmASRRead_OUTACTLOG_T")
            sqlWhere.Append(CommonConstant.SQL_STR_WHERE)
            sqlWhere.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            sqlWhere.Append("OutLog")
            sqlWhere.Append(CommonConstant.SQL_STR_EQUAL)
            sqlWhere.Append(StringEdit.EncloseSingleQuotation("異常：行番号が一致するデータが見つかりませんでした。"))
            sqlWhere.Append(CommonConstant.SQL_STR_OR)
            sqlWhere.Append("OutLog")
            sqlWhere.Append(CommonConstant.SQL_STR_EQUAL)
            sqlWhere.Append(StringEdit.EncloseSingleQuotation("異常：通知書受領日、発注完了日に日付に変換できない文字が入力されています。"))
            sqlWhere.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
            Debug.Print(sqlBase.ToString & sqlWhere.ToString)
            Call rsIns.Open(sqlBase.ToString & sqlWhere.ToString, con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)
            If rsIns.EOF = False Then
                ACTImportNGRow = CInt(rsIns.Fields(0).Value)
            End If
            rsIns.Close()

            Debug.Print(Now.ToString("yyyy/MM/dd HH:mm:ss ") & "ACTの出力件数を取得:対象外取込み")
            ''対象外取込み
            sqlWhere.Remove(0, sqlWhere.Length)
            sqlWhere.Append("FrmASRRead_OUTACTLOG_T")
            sqlWhere.Append(CommonConstant.SQL_STR_WHERE)
            sqlWhere.Append("OutLog")
            sqlWhere.Append(CommonConstant.SQL_STR_EQUAL)
            sqlWhere.Append(StringEdit.EncloseSingleQuotation("対象外：通知書受領日、発注完了日、実行通知書番号の変更がありませんでした。"))

            Debug.Print(sqlBase.ToString & sqlWhere.ToString)
            Call rsIns.Open(sqlBase.ToString & sqlWhere.ToString, con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)
            If rsIns.EOF = False Then
                ACTNoDateRow = CInt(rsIns.Fields(0).Value)
            End If
            rsIns.Close()


            ''Serialの出力件数を取得
            ''=============================================
            Debug.Print(Now.ToString("yyyy/MM/dd HH:mm:ss ") & "Serialの出力件数を取得:正常取込み")
            ''正常取込み
            sqlWhere.Remove(0, sqlWhere.Length)
            sqlWhere.Append("FrmASRRead_OUTSerialLOG_T")
            sqlWhere.Append(CommonConstant.SQL_STR_WHERE)
            sqlWhere.Append("OutLog")
            sqlWhere.Append(CommonConstant.SQL_STR_EQUAL)
            sqlWhere.Append(StringEdit.EncloseSingleQuotation(""))
            Debug.Print(sqlBase.ToString & sqlWhere.ToString)
            Call rsIns.Open(sqlBase.ToString & sqlWhere.ToString, con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)
            If rsIns.EOF = False Then
                SerialImportOKRow = CInt(rsIns.Fields(0).Value)
            End If
            rsIns.Close()

            Debug.Print(Now.ToString("yyyy/MM/dd HH:mm:ss ") & "Serialの出力件数を取得:異常取込み")
            ''異常取込み
            sqlWhere.Remove(0, sqlWhere.Length)
            sqlWhere.Append("FrmASRRead_OUTSerialLOG_T")
            sqlWhere.Append(CommonConstant.SQL_STR_WHERE)
            sqlWhere.Append("OutLog")
            sqlWhere.Append(CommonConstant.SQL_STR_EQUAL)
            sqlWhere.Append(StringEdit.EncloseSingleQuotation("異常：仮シリアルが一致するデータが見つかりませんでした。"))
            Debug.Print(sqlBase.ToString & sqlWhere.ToString)
            Call rsIns.Open(sqlBase.ToString & sqlWhere.ToString, con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)
            If rsIns.EOF = False Then
                SerialImportNGRow = CInt(rsIns.Fields(0).Value)
            End If
            rsIns.Close()

            Debug.Print(Now.ToString("yyyy/MM/dd HH:mm:ss ") & "Serialの出力件数を取得:対象外取込み")
            ''対象外取込み
            sqlWhere.Remove(0, sqlWhere.Length)
            sqlWhere.Append("FrmASRRead_OUTSerialLOG_T")
            sqlWhere.Append(CommonConstant.SQL_STR_WHERE)
            sqlWhere.Append("OutLog")
            sqlWhere.Append(CommonConstant.SQL_STR_EQUAL)
            sqlWhere.Append(StringEdit.EncloseSingleQuotation("対象外：実シリアルが未入力のため、取込みませんでした。"))
            Debug.Print(sqlBase.ToString & sqlWhere.ToString)
            Call rsIns.Open(sqlBase.ToString & sqlWhere.ToString, con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)
            If rsIns.EOF = False Then
                SerialNoDateRow = CInt(rsIns.Fields(0).Value)
            End If
            rsIns.Close()


            Debug.Print(Now.ToString("yyyy/MM/dd HH:mm:ss ") & "抽出結果をセット")
            ''抽出結果をセット
            ''=============================================
            derivaryCount.InsertCount = InsertCount
            derivaryCount.ACT_MachCount = ACTImportOKRow
            derivaryCount.ACT_UnMachCount = ACTImportNGRow
            derivaryCount.ACT_DataErrCount = ACTNoDateRow
            derivaryCount.Serial_MachCount = SerialImportOKRow
            derivaryCount.Serial_UnMachCount = SerialImportNGRow
            derivaryCount.Serial_DataErrCount = SerialNoDateRow

        Catch ex As Exception
            Throw ex

        Finally
            ''MDB解放
            If rsIns.State = ADODB.ObjectStateEnum.adStateOpen Then
                rsIns.Close()
            End If

        End Try

    End Sub

    ''' <summary>
    ''' OIO-Sheetの並べ替えを行う
    ''' </summary>
    ''' <param name="xlOutOBAMASheet">Paymentのﾜｰｸｼｰﾄｵﾌﾞｼﾞｪｸﾄ</param>
    ''' <remarks></remarks>
    Private Sub SortOioSheet(ByRef xlOutOBAMASheet As Excel.Worksheet)

        Dim targetRange As Excel.Range
        Dim sortRow As Excel.Range
        Try

            targetRange = xlOutOBAMASheet.Rows(EXCEL_PAYMENTLINEDATE_OUTROW & ":" & (xlOutOBAMASheet.Rows.Count - 1).ToString)
            sortRow = xlOutOBAMASheet.Cells(EXCEL_PAYMENTLINEDATE_OUTROW, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)
            Call targetRange.Sort(Key1:=sortRow, Orientation:=Excel.XlSortOrientation.xlSortColumns)

        Catch ex As Exception
            Throw ex

        Finally

            ExcelObjRelease.ReleaseExcelObj(targetRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(sortRow, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' ｼﾘｱﾙｼｰﾄの行チェック
    ''' </summary>
    ''' <param name="cellObj"></param>
    ''' <returns>True：ある　False：ない</returns>
    ''' <remarks>行番にデータあるかチェックする</remarks>
    Private Function CheckRowSerial(ByRef cellObj(,) As Object) As Boolean

        CheckRowSerial = False

        Try
            '''' 条件：仮シリアルの値判定
            '''' ケース：仮シリアルが空文字の場合、データ無しとする
            Const ColumnNM_LINE_NO As Integer = 1       ''行番号
            If ExcelWrite.changeDBNullToString(cellObj(1, ColumnNM_LINE_NO)) = "" Then
                Exit Function
            End If

        Catch ex As Exception
            Throw ex

        End Try

        CheckRowSerial = True

    End Function

    ''' <summary>
    ''' 検索用ワークテーブル作成
    ''' </summary>
    ''' <param name="con">MDBのコネクション</param>
    ''' <remarks></remarks>
    Private Sub MakeWorkData(ByVal con As ADODB.Connection)

        Dim cmd As New ADODB.Command

        Try
            Application.DoEvents()              ''応答なし対応

            'MDBのConnection
            cmd.ActiveConnection = con

            '''' 処理：以下のワークテーブルデータを削除する
            '''' 　FrmASRRead_IDList_T
            '''' 　FrmASRRead_OUTACTLOG_T
            '''' 　FrmASRRead_OUTSerialLOG_T
            cmd.CommandText = "DELETE FROM FrmASRRead_IDList_T"
            cmd.CommandType = CommandType.Text
            cmd.Execute()

            cmd.CommandText = "DELETE FROM FrmASRRead_OUTACTLOG_T"
            cmd.CommandType = CommandType.Text
            cmd.Execute()

            cmd.CommandText = "DELETE FROM FrmASRRead_OUTSerialLOG_T"
            cmd.CommandType = CommandType.Text
            cmd.Execute()


            '''' 処理：以下のワークテーブルにデータを登録
            '''' 　ｸｴﾘ：INS_FrmASRRead_IDList　      ﾃｰﾌﾞﾙ：FrmASRRead_IDList_T
            '''' 　ｸｴﾘ：INS_FrmASRRead_OUTACTLOG     ﾃｰﾌﾞﾙ：FrmASRRead_OUTACTLOG_T
            '''' 　ｸｴﾘ：INS_FrmASRRead_OUTSerialLOG　ﾃｰﾌﾞﾙ：FrmASRRead_OUTSerialLOG_T
            cmd.CommandText = "INS_FrmASRRead_IDList"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Execute()

            cmd.CommandText = "INS_FrmASRRead_OUTACTLOG"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Execute()

            cmd.CommandText = "INS_FrmASRRead_OUTSerialLOG"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Execute()

        Catch ex As Exception
            Debug.Print(ex.Message.ToString & "(MakeWorkData)")
            Throw ex
        Finally

        End Try

    End Sub

    ''' <summary>
    ''' 不要項目削除処理
    ''' </summary>
    ''' <param name="xlOutSerialSheet">ｼﾘｱﾙｼｰﾄｵﾌﾞｼﾞｪｸﾄ</param>
    ''' <param name="xlOutPSSheet">Paymentｼｰﾄｵﾌﾞｼﾞｪｸﾄ</param>
    ''' <remarks></remarks>
    Private Sub DeleteUnnecessaryColum(ByRef xlOutSerialSheet As Excel.Worksheet, ByRef xlOutPSSheet As Excel.Worksheet)

        Try
            '------------------------------------
            'ｼﾘｱﾙｼｰﾄ
            '------------------------------------
            '''' 処理：以下のｼﾘｱﾙｼｰﾄの列を右側から左に向けて削除する
            '''' 　展開金額から後ろ最大年月まで(CF:MM)
            Call DeleteColumn("CF:MM", xlOutSerialSheet)
            '''' 　D%(CC)
            Call DeleteColumn("CB:CB", xlOutSerialSheet)
            '''' 　List Price(小計)提案時(CA)
            Call DeleteColumn("BZ:BZ", xlOutSerialSheet)
            '''' 　契約形態 - List Price(単価)提案時(BV:BY)
            Call DeleteColumn("BU:BX", xlOutSerialSheet)
            '''' 　IGF支払期間_開始年月 - 支払方法(BM:BS)
            Call DeleteColumn("BL:BR", xlOutSerialSheet)
            '''' 　項目１６ - 価格改定予定日(AW:BH)
            Call DeleteColumn("AW:BG", xlOutSerialSheet)
            'Call DeleteColumn("CC:CC", xlOutSerialSheet)
            '''' 　項目９ - 項目１３(AP:AT)
            Call DeleteColumn("AP:AT", xlOutSerialSheet)
            '''' 　項目４ - 項目７(AK:AN)
            Call DeleteColumn("AK:AN", xlOutSerialSheet)
            '''' 　ﾊﾟﾀｰﾝNO(AE)
            Call DeleteColumn("AE:AE", xlOutSerialSheet)
            '''' 　Summary Category - 起票番号(T:AB)
            Call DeleteColumn("T:AB", xlOutSerialSheet)
            '''' 　請求ｲﾆｼｬﾙ(Q)
            Call DeleteColumn("Q:Q", xlOutSerialSheet)
            '''' 　案件番号(I)
            Call DeleteColumn("I:I", xlOutSerialSheet)
            '''' 　ﾌｧｲﾙ名 - ﾌｧｲﾙ内構成連番(E:G)
            Call DeleteColumn("E:G", xlOutSerialSheet)
            '''' 　作業指示FLG - Payment種別(A:C)
            Call DeleteColumn("A:C", xlOutSerialSheet)

            '------------------------------------
            'Paymetｼｰﾄ
            '------------------------------------
            '''' 処理：以下のPaymentｼｰﾄの列を右側から左に向けて削除する
            '''' 　支払総額(金利込) - 過去の契約金額合計(CK:DI)
            Call DeleteColumn("CK:DI", xlOutPSSheet)
            '''' 　展開金額 - List Price合計(CH:CI)
            Call DeleteColumn("CH:CI", xlOutPSSheet)
            '''' 　D%(CE)
            Call DeleteColumn("CD:CD", xlOutPSSheet)
            '''' 　List Price(小計)提案時(CC)
            Call DeleteColumn("CB:CB", xlOutPSSheet)
            '''' 　契約形態 - List Price(小計)提案時(BX:CA)
            Call DeleteColumn("BW:BZ", xlOutPSSheet)
            '''' 　Payment展開 - 支払方法(BQ:BU)
            Call DeleteColumn("BP:BT", xlOutPSSheet)
            '''' 　項目１６ - 価格改定予定日(AY:BJ)
            Call DeleteColumn("AY:BI", xlOutPSSheet)

            '''' 　項目１３(AV)
            Call DeleteColumn("AV:AV", xlOutPSSheet)
            '''' 　項目９ - 取込元情報(AR:AS)
            Call DeleteColumn("AR:AS", xlOutPSSheet)
            '''' 　項目５ - 項目７(AN:AP)
            Call DeleteColumn("AN:AP", xlOutPSSheet)
            '''' 　項目３(AK)
            Call DeleteColumn("AK:AK", xlOutPSSheet)
            '''' 　ﾊﾟﾀｰﾝNO(AG)
            Call DeleteColumn("AG:AG", xlOutPSSheet)
            '''' 　Summary Category - 起票番号(V:AD)
            Call DeleteColumn("V:AD", xlOutPSSheet)
            '''' 　請求ｲﾆｼｬﾙ(S)
            Call DeleteColumn("S:S", xlOutPSSheet)
            '''' 　保守種別 - お客様集計カテゴリ(M:N)
            Call DeleteColumn("M:N", xlOutPSSheet)
            '''' 　案件番号(K)
            Call DeleteColumn("K:K", xlOutPSSheet)
            '''' 　ﾌｧｲﾙ名 - ﾌｧｲﾙ内構成連番(G:I)
            Call DeleteColumn("G:I", xlOutPSSheet)
            '''' 　作業指示FLG - Status(C:D)
            Call DeleteColumn("C:D", xlOutPSSheet)

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' 列削除
    ''' </summary>
    ''' <param name="strRange">削除範囲</param>
    ''' <param name="xlSheet">Worksheetｵﾌﾞｼﾞｪｸﾄ</param>
    ''' <remarks></remarks>
    Private Sub DeleteColumn(ByVal strRange As String, ByRef xlSheet As Excel.Worksheet)

        Dim xlRange As Excel.Range

        Try
            '''' 処理：範囲列を削除する
            xlRange = xlSheet.Columns(strRange)
            xlRange.Delete()
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)

        Catch ex As Exception
            Throw ex
        Finally
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)

        End Try

    End Sub

#End Region

#Region "共通"

    ''' <summary>
    ''' 月額展開開始年をセット
    ''' </summary>
    ''' <param name="xlPs">PaymentのWorksheetｵﾌﾞｼﾞｪｸﾄ</param>
    ''' <param name="intAsrCd">未使用</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function SetStartMonth(ByRef xlPs As Excel.Worksheet, ByVal intAsrCd As Integer) As Boolean

        Dim xlCell As Excel.Range = Nothing

        SetStartMonth = False

        Try
            '----------------------------
            '開始年設定
            '----------------------------
            '''' 処理：Paymentシートに開始年を設定する
            xlCell = xlPs.Cells(4, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1)
            xlCell.Value = CommonVariable.PaymentStart.ToString("yyyy")
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            SetStartMonth = True

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

        End Try

    End Function

    ''' <summary>
    ''' シート保護処理
    ''' </summary>
    ''' <param name="xlApp">Excel.Applicationｵﾌﾞｼﾞｪｸﾄ</param>
    ''' <param name="strFileName">マクロを呼び出すファイル名</param>
    ''' <remarks>実行管理・ﾃﾞﾘﾊﾞﾘ管理で同じ関数名を使用</remarks>
    Private Sub ExcelSheetProtect(ByRef xlApp As Excel.Application, ByVal strFileName As String)

        '''' 処理：シート保護マクロを呼び出す
        Dim ResultT As String = DirectCast(xlApp.Run("'" & strFileName & "'!SheetProtect"), String)

    End Sub

#End Region

#End Region

End Class
