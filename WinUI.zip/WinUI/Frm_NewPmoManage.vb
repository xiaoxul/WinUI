﻿Imports System.IO
Imports System.Text
Imports Microsoft.Office.Interop
Imports System.Data.OleDb
Imports MUSE.Utility
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.OioBamaCommmon
Imports MUSE.Utility.UserMessageBox
Imports MUSE.WinUI.OioBamaCommmon
Imports MUSE.Utility.UserDataTable.Master
Imports MUSE.DataAccess.OleDb

Public Class Frm_NewPmoManage

#Region "構造体"
    Structure OutMessage
        Dim MsgKind As Integer      'メッセージの種類
        Dim Msg As String           '出力メッセージ
    End Structure
#End Region

#Region "列挙体"
    '処理区分
    Private Enum ProcCd
        Cost = 0                    'COST開示
        Igf                         'IGF集計
        Topacs                      'TOPACS申請
        SLink                       'S-LINK情報
        ContractDoc                 '契約書別紙基本情報
        PsSplit                     'Payment分割
        ElaFile                     'ELAファイル
        CiscoMa                     'CiscoMa
        ePricer                     'ePricer起票
        NissayPaDoc                 '日生向け契約書別紙(PA)
    End Enum

    'メッセージの種類
    Private Enum MsgKind
        Infomation = 0              '情報出力
        Warning                     'ワーニング出力
        Ng                          'NG出力
    End Enum
#End Region

#Region "定数"
    ''入力のダイアルログ画面
    Private Const INPUTDIALOG_FILTER_XLS As String = "ﾍﾟｲﾒﾝﾄｼｰﾄ ﾌｧｲﾙ (*.xlsm)|*.xlsm"
    Private Const INPUTDIALOG_FILTER_KAKAKUKAIJI_XLS As String = "価格開示 ﾌｧｲﾙ (*.xlsm)|*.xlsm"
    Private Const INPUTDIALOG_FILTER_TOPACS_XLS As String = "TOPACS申請 ﾌｧｲﾙ (*.xlsm)|*.xlsm"
    Private Const INPUTDIALOG_FILTER_IGF_XLS As String = "IGF集計 ﾌｧｲﾙ (*.xlsm)|*.xlsm"
    Private Const INPUTDIALOG_DESCRIPTION_COST As String = "COST開示ファイルの格納フォルダの指定"
    Private Const INPUTDIALOG_FILTER_SLINK_XLS As String = "S-LINK情報 ﾌｧｲﾙ (*.xlsm)|*.xlsm"
    Private Const INPUTDIALOG_FILTER_ELA_XLS As String = "ELA情報 ﾌｧｲﾙ (*.xlsm)|*.xlsm"
    Private Const INPUTDIALOG_DESCRIPTION_ISAT As String = "ISAT見積ファイルの格納フォルダの指定"
    Private Const INPUTDIALOG_FILTER_EPRICER_XLS As String = "EPRICER情報 ﾌｧｲﾙ (*.xlsm)|*.xlsm"

    '==============================
    'EXCEL行位置
    '==============================
    ''処理中ダイアログ表示用
    Private Const STR_CREATING As String = "作成中・・・"
    Private Const STR_MESSAGE_CREATE_FILE As String = "ﾌｧｲﾙを作成中です。"

    '処理区分
    Private Const CD_BTN_INPUT As Integer = 0           '作成処理
    Private Const CD_BTN_OUTPUT As Integer = 1          '読込処理
#End Region

#Region "メンバ変数"
    Private FileContractno As String = ""
    Private OUTPUT_DIR As String
    Private TEMP_DIR_PATH As String
    Private OUTPUT_TEMPFOLDER As String
    Private createFileTime As String
#End Region

#Region "コンストラクタ"
    'コンストラクタ
    Public Sub New()

        ' この呼び出しは Windows フォーム デザイナで必要です。
        InitializeComponent()

        ''固定パスを相対パスへ変更
        OUTPUT_DIR = FileManager.GetLocalFolderPath(CommonConstant.FOLDERNAME_OUTPUT)
        TEMP_DIR_PATH = FileManager.GetLocalFolderPath(CommonConstant.FOLDERNAME_TEMPLATE)
        OUTPUT_TEMPFOLDER = FileManager.GetLocalFolderPath(CommonConstant.FOLDERNAME_LOG)
    End Sub

#End Region

#Region "イベント処理"
    ''' <summary>
    ''' ログアウトボタン
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnLogOut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogOut.Click
        Me.Close()
    End Sub

    ''' <summary>
    ''' 戻るボタン
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Btn_Rtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Rtn.Click
        Dim frm As New Frm_Menu()

        Me.Hide()

        frm.ShowDialog()
        Me.Close()
    End Sub

    ''' <summary>
    ''' ロード時の処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Frm_PmoManage_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try
            '''' 処理：画面項目のセット
            Me.txb_DispCpno.Text = CommonVariable.CPNO
            Me.txb_DispCustNm.Text = CommonVariable.CUSTOMERNAME
            Me.txb_Contact_No_Name.Text = CommonVariable.CONTRACTNONAME
            Me.txb_DispKeiyakuZyunban.Text = CommonVariable.CONTRACTNO.ToString.PadLeft(3, "0c")

            FileContractno = CommonVariable.CONTRACTNO.ToString.PadLeft(3, "0c")
            gbSystem.Text = "COST開示ファイル"
            cbCost.Checked = True
            cbTopacs.Checked = False
            cbIgf.Checked = False
            cbSlink.Checked = False
            cbContractDoc.Checked = False
            '''' 処理：別紙B出力対象CD取得し、契約書別紙基本情報の表示設定を行う
            Select Case IsEnableAttachedSheetBtn()
                Case 0
                    cbContractDoc.Visible = False
                Case 1
                    cbContractDoc.Visible = True
                Case 2
                    cbContractDoc.Visible = True
            End Select

            'Payment分割ボックス表示切り替え
            If isSplit(CommonVariable.CPNO) = True Then
                cbPaymentSplit.Visible = True
            Else
                cbPaymentSplit.Visible = False
            End If

            Call DispPSDetailTextBox()

            Me.Text = CommonVariable.OBAMATITLE

        Catch ex As Exception
            MuseMessageBox.ShowError(ex.Message, Me.Text)

        End Try
    End Sub

    ''' <summary>
    ''' 参照ボタンクリック
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Btn_InputFileDisp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_InputFileDisp.Click,
                                                                                                            btnSysReference.Click

        Dim ofd As OpenFileDialog = New OpenFileDialog
        Dim strFolderPath As String
        Dim ofm As New OioFileManage

        '''' 条件：処理ボタン判定
        '''' ケース：Payment(作業用)ファイル指定の参照ボタンの場合、以下の処理を行う
        If sender.name = "Btn_InputFileDisp" Then
            '------------------------------------
            'Payment IOCの参照
            '------------------------------------

            '''' 　処理：フォルダの初期位置(CPNO、契約順番)を設定
            ofd.Filter = INPUTDIALOG_FILTER_XLS
            strFolderPath = ofm.GetLocalCPNOFolder(Me.txb_DispCpno.Text.Trim, CInt(FileContractno))
            '''' 　条件：フォルダ存在チェック
            '''' 　ケース：フォルダが存在しない場合、警告メッセージを表示する
            '''' 　　メッセージ：ID;MSG_0208
            '''' 　　　該当するフォルダが存在しません。
            If Directory.Exists(strFolderPath) = False Then
                MuseMessageBox.ShowWarning(FileReader.GetMessage("MSG_0208"), Me.Text)
                strFolderPath = FileManager.GetLocalFolderPath(CommonConstant.FOLDERNAME_EXCEL)
            End If

            '''' 　処理：ダイアログ表示
            '''' 　条件：ダイアログの結果判定
            '''' 　ケース：OKの場合、以下の処理を行う
            ofd.InitialDirectory = strFolderPath
            If ofd.ShowDialog() = DialogResult.OK Then
                Dim fileName As String = ofd.FileName

                '''' 　　条件：Paymentファイル名のCPNO,契約順番チェック
                '''' 　　ケース：処理結果が異常の場合、エラーメッセージを表示し処理を中断する
                '''' 　　　メッセージ：ID:MSG_0276
                '''' 　　　　CPNO、契約順番が異なるファイルを指定しています。
                If ofm.ChackPaymentFileNMAtArgs(Path.GetFileName(fileName), CommonVariable.CPNO, CommonVariable.CONTRACTNO) = False Then
                    MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0276"), Me.Text)
                    Return
                End If

                '''' 　　条件：PaymentﾌｧｲﾙのOpenチェック
                '''' 　　ケース：PaymentﾌｧｲﾙがOPEN中の場合、エラーメッセージを表示する
                '''' 　　　メッセージ：ID:MSG_0324
                '''' 　　　　読込処理対象のファイルがOPENされています。&#10;ﾌｧｲﾙを閉じてください。
                '''' 　　　　ファイル名：xxxxxxxxxxxxxxxxxxxxxx
                If ofm.ChkOpenedExcelFile(fileName) = False Then
                    Call MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0324") & vbCrLf & vbCrLf _
                                                  & "ファイル名：" & Path.GetFileName(fileName), Me.Text)
                    Exit Sub
                End If
                Me.txb_InputFile.Text = fileName
            End If

        Else
            '''' ケース：取込指定の参照ボタンの場合、以下の処理を行う
            '------------------------------------
            '各処理の参照
            '------------------------------------
            '''' 　処理：処理のチェック数取得
            Dim intCheckedCnt As Integer = 0
            If cbCost.Checked = True Then
                intCheckedCnt = intCheckedCnt+1
            End If
            If cbTopacs.Checked = True Then
                intCheckedCnt = intCheckedCnt + 1
            End If
            If cbIgf.Checked = True Then
                intCheckedCnt = intCheckedCnt + 1
            End If
            If cbSlink.Checked = True Then
                intCheckedCnt = intCheckedCnt + 1
            End If
            If cbElaFile.Checked = True Then
                intCheckedCnt = intCheckedCnt + 1
            End If
            If cbIsatMa.Checked = True Then
                intCheckedCnt = intCheckedCnt + 1
            End If
            If cbEpricer.Checked = True Then
                intCheckedCnt = intCheckedCnt + 1
            End If

            '''' 　条件：チェック数判定
            '''' 　ケース：チェック数が０の場合、エラーメッセージを表示して処理を中断する
            '''' 　　メッセージ：ID：MSG_0493
            '''' 　　　１つもチェックされていません。
            If intCheckedCnt = 0 Then
                MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0493"), Me.Text)
                Exit Sub
            End If

            '''' 　条件：チェック数判定
            '''' 　ケース：チェック数が２件以上の場合、エラーメッセージを表示して処理を中断する
            '''' 　　メッセージ：ID：MSG_0494
            '''' 　　　読込処理は１つのみです。
            If intCheckedCnt > 1 Then
                MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0494"), Me.Text)
                Exit Sub
            End If

            '''' 　条件：コスト開示チェック判定
            '''' 　ケース：チェック有の場合、以下の処理を行う
            If cbCost.Checked = True Or cbIsatMa.Checked = True Then
                Dim fbd As New FolderBrowserDialog
                Dim strSelectedPath As String

                '''' 　　処理：ダイアログのタイトル、フォルダの初期位置を設定
                strSelectedPath = ofm.GetLocalOutputCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
                If cbCost.Checked = True Then
                    fbd.Description = INPUTDIALOG_DESCRIPTION_COST
                Else
                    fbd.Description = INPUTDIALOG_DESCRIPTION_ISAT
                    strSelectedPath = strSelectedPath & "ISAT見積\"
                End If
                fbd.SelectedPath = strSelectedPath
                fbd.ShowNewFolderButton = False

                '''' 　　処理：フォルダ指定ダイアルログを表示
                '''' 　　条件：ダイアログの結果判定
                '''' 　　ケース：OKの場合、以下の処理を行う
                '''' 　　　条件：読込ﾌｧｲﾙOPENチェック
                '''' 　　　ケース：読込ﾌｧｲﾙがOPEN中の場合、エラーメッセージを表示し処理を中断する
                '''' 　　　　メッセージ：ID:MSG_0324
                '''' 　　　　　読込処理対象のファイルがOPENされています。&#10;ﾌｧｲﾙを閉じてください。
                '''' 　　　　　ファイル名：xxxxxxxxxxxxxxx
                If fbd.ShowDialog = DialogResult.OK Then
                    Dim strFolderName As String = fbd.SelectedPath
                    Dim errFilePath As String
                    If ofm.ChkOpenedExcelInFolder(strFolderName, errFilePath) = False Then
                        Call MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0324") & vbCrLf & vbCrLf _
                                                      & "ファイル名：" & Path.GetFileName(errFilePath), Me.Text)
                        Exit Sub
                    End If
                    '''' 　　処理：取込用テキストボックスにファイル名を設定
                    Me.txtRefInputFile.Text = strFolderName
                End If
                strFolderPath = "NotFolderPathCheck"

            Else
                '''' 　ケース：上記外の場合、以下の処理を行う
                Dim strFilter As String

                If cbTopacs.Checked = True Then
                    'TOPACS申請
                    strFilter = INPUTDIALOG_FILTER_TOPACS_XLS
                ElseIf cbIgf.Checked = True Then
                    'IGF集計
                    strFilter = INPUTDIALOG_FILTER_IGF_XLS
                ElseIf cbSlink.Checked = True Then
                    'S-LINK情報
                    strFilter = INPUTDIALOG_FILTER_SLINK_XLS
                ElseIf cbElaFile.Checked = True Then
                    'ELA情報
                    strFilter = INPUTDIALOG_FILTER_ELA_XLS
                ElseIf cbEpricer.Checked = True Then
                    'EPRICER情報
                    strFilter = INPUTDIALOG_FILTER_EPRICER_XLS
                End If

                '''' 　　処理：フィルタ、フォルダの初期位置を設定
                ofd.Filter = strFilter
                strFolderPath = OUTPUT_DIR + _
                                    CommonVariable.CPNO.Trim.PadLeft(8, "0") + "_" + _
                                    CommonVariable.CONTRACTNO.ToString().PadLeft(3, "0c") + "\"
                ofd.InitialDirectory = strFolderPath
                '''' 　　条件：ダイアログの結果判定
                '''' 　　ケース：OKの場合、以下の処理を行う
                '''' 　　　条件：読込ﾌｧｲﾙOPENチェック
                '''' 　　　ケース：読込ﾌｧｲﾙがOPEN中の場合、エラーメッセージを表示し処理を中断する
                '''' 　　　　メッセージ：ID:MSG_0324
                '''' 　　　　　読込処理対象のファイルがOPENされています。&#10;ﾌｧｲﾙを閉じてください。
                '''' 　　　　　ファイル名：xxxxxxxxxxxxxxx
                If ofd.ShowDialog() = DialogResult.OK Then
                    Dim fileName As String = ofd.FileName
                    If ofm.ChkOpenedExcelFile(fileName) = False Then
                        Call MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0324") & vbCrLf & vbCrLf _
                                                      & "ファイル名：" & Path.GetFileName(fileName), Me.Text)
                        Exit Sub
                    End If

                    '''' 　　処理：取込用テキストボックスにファイル名を設定
                    Me.txtRefInputFile.Text = fileName
                End If
            End If
        End If

        '''' 条件：フォルダが存在チェック
        '''' ケース：フォルダが存在しない場合、エラーメッセージを表示し処理を中断する
        '''' 　メッセージ：ID:MSG_0208
        '''' 　　該当するフォルダが存在しません。
        If strFolderPath = "" Then
            MuseMessageBox.ShowWarning(FileReader.GetMessage("MSG_0208"), Me.Text)
            strFolderPath = FileManager.GetLocalFolderPath(CommonConstant.FOLDERNAME_EXCEL)
        End If

        ofd.InitialDirectory = strFolderPath

    End Sub

    ''' <summary>
    ''' 処理区分チェックボックス変更
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub ProcCheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cbCost.CheckedChanged,
                                                                                                cbTopacs.CheckedChanged,
                                                                                                cbIgf.CheckedChanged,
                                                                                                cbSlink.CheckedChanged,
                                                                                                cbContractDoc.CheckedChanged,
                                                                                                cbPaymentSplit.CheckedChanged,
                                                                                                cbElaFile.CheckedChanged,
                                                                                                cbIsatMa.CheckedChanged,
                                                                                                cbEpricer.CheckedChanged

        '''' 処理：チェック数取得
        Dim intCheckedCnt As Integer = 0
        If cbTopacs.Checked = True Then
            intCheckedCnt = intCheckedCnt + 1
        End If
        If cbCost.Checked = True Then
            intCheckedCnt = intCheckedCnt + 1
        End If
        If cbIgf.Checked = True Then
            intCheckedCnt = intCheckedCnt + 1
        End If
        If cbSlink.Checked = True Then
            intCheckedCnt = intCheckedCnt + 1
        End If
        If cbContractDoc.Checked = True Then
            intCheckedCnt = intCheckedCnt + 1
        End If
        If cbElaFile.Checked = True Then
            intCheckedCnt = intCheckedCnt + 1
        End If
        If cbIsatMa.Checked = True Then
            intCheckedCnt = intCheckedCnt + 1
        End If
        If cbEpricer.Checked = True Then
            intCheckedCnt = intCheckedCnt + 1
        End If

        '''' 条件：チェック数判定
        '''' ケース：チェック数が１の場合、以下の処理を行う
        '''' 　処理：処理区分によってコントロールを設定する
        If intCheckedCnt = 1 Then
            If cbTopacs.Checked = True Then
                gbSystem.Enabled = True
                gbSystem.Text = "ＴＯＰＡＣＳ申請ファイル"
                lblMessage.Text = "起票番号読込み　ＴＯＰＡＣＳ申請読込みファイル指定"
                btnOutput.Visible = True
                btnInput.Visible = True

            ElseIf cbCost.Checked = True Then
                gbSystem.Enabled = True
                gbSystem.Text = "COST開示ファイル"
                lblMessage.Text = "COST読込み　COST開示読込みファィル指定"
                btnOutput.Visible = True
                btnInput.Visible = True

            ElseIf cbIgf.Checked = True Then
                gbSystem.Enabled = True
                gbSystem.Text = "ＩＧＦ集計ファイル"
                lblMessage.Text = "ＩＧＦ作成データ読込み　ＩＧＦ集計読込みファイル指定"
                btnOutput.Visible = True
                btnInput.Visible = True

            ElseIf cbSlink.Checked = True Then
                gbSystem.Enabled = True
                gbSystem.Text = "S-LINK情報ファイル"
                lblMessage.Text = "S-LINK作成データ読込み　S-LINK情報読込みファイル指定"
                btnOutput.Visible = True
                btnInput.Visible = True

            ElseIf cbContractDoc.Checked = True Then
                gbSystem.Enabled = False
                gbSystem.Text = ""
                lblMessage.Text = ""
                btnOutput.Visible = True
                btnInput.Visible = False
            ElseIf cbPaymentSplit.Checked = True Then
                gbSystem.Enabled = False
                gbSystem.Text = ""
                lblMessage.Text = ""
                btnOutput.Visible = True
                btnInput.Visible = False
            ElseIf cbElaFile.Checked = True Then
                gbSystem.Enabled = True
                gbSystem.Text = "ELA情報ファイル"
                lblMessage.Text = "ELAデータ読込み　ファイル指定"
                btnOutput.Visible = False
                btnInput.Visible = True
            ElseIf cbIsatMa.Checked = True Then
                gbSystem.Enabled = True
                gbSystem.Text = "既存MA情報ファイル"
                lblMessage.Text = "既存MAデータ読込み　ファイル指定"
                btnOutput.Visible = False
                btnInput.Visible = True
            ElseIf cbEpricer.Checked = True Then
                gbSystem.Enabled = True
                gbSystem.Text = "Epricer情報ファイル"
                lblMessage.Text = "Epricerデータ読込み　ファイル指定"
                btnOutput.Visible = True
                btnInput.Visible = True
            End If
        Else
            '''' ケース：チェック数が１以外の場合、以下の処理を行う
            gbSystem.Enabled = True
            gbSystem.Text = ""
            lblMessage.Text = ""
            btnOutput.Visible = True
            btnInput.Visible = True

        End If

    End Sub

    ''' <summary>
    ''' 概 要：ﾌｫﾙﾀﾞ表示ボタンクリック
    ''' 説 明：※フォルダの表示先はBtnDispExplorer1～4全て同じため、このモジュールでHandleする。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub BtnDispExplorer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnDispExplorer1.Click

        Dim ofm As New OioFileManage

        Try
            ''Explorer表示
            If cbIsatMa.Checked = True Then
                Dim strFolder As String
                strFolder = ofm.GetLocalOutputCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO) & "ISAT見積"
                System.Diagnostics.Process.Start(strFolder)

            Else
                If ofm.DispExplorer(CommonConstant.FOLDERNAME_OUTPUT, CommonVariable.CPNO, CommonVariable.CONTRACTNO) = False Then
                    MsgBox(FileReader.GetMessage("MSG_0208"), MsgBoxStyle.Exclamation, "")
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "ﾌｫﾙﾀﾞ表示")
        End Try

    End Sub

    ''' <summary>
    ''' 作成ボタンクリック
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnOutput_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOutput.Click

        Dim om(9) As OutMessage
        Dim intCheckedMax As Integer = 0
        Dim intProgressCnt As Integer = 0
        Dim blnRet As Boolean
        Dim strRetMsg As String = ""
        Dim waitDialog As New Frm_WaitDialog
        Dim ofm As New OioFileManage

        Try
            '''' 処理：処理中ダイアログ表示
            Call SetWaitDialogInit(waitDialog)
            waitDialog.Show()
            waitDialog.Activate2(Me)
            Me.Cursor = Cursors.WaitCursor
            Me.Enabled = False

            '''' 処理：画面の入力値チェック(CheckFormInputData())
            '''' 条件：処理結果判定
            '''' ケース：処理結果が異常の場合、処理を中断する
            waitDialog.lbl_Message.Text = "入力チェック中"
            waitDialog.Update()
            If CheckFormInputData(CD_BTN_OUTPUT, intCheckedMax) = False Then
                Exit Sub
            End If

            Dim rdbNM As String
            Dim strPSFilePath As String = Me.txb_InputFile.Text
            Dim blnSkipCheck As Boolean = False
            '''' 条件：処理区分判定
            '''' ケース：契約別紙以外にチェック有の場合、以下の処理を行う
            '''' 　　　　※契約別紙以外のPaymentチェックは同様のチェックのため１つ(COST開示)のチェックで行う
            '''' 　条件Paymentエラー判定処理(ExcelWrite.ChkPaymentErr)
            '''' 　ケース：エラーの場合、処理を中断する
            If cbCost.Checked = True Or
                cbTopacs.Checked = True Or
                cbIgf.Checked = True Or
                cbSlink.Checked = True Or
                cbPaymentSplit.Checked = True Or
                cbEpricer.Checked = True Then
                blnSkipCheck = True
                If ExcelWrite.ChkPaymentErr(Me.Name,
                                            sender.Name,
                                            CommonVariable.CPNO,
                                            CommonVariable.CONTRACTNO,
                                            cbCost.Name,
                                            strPSFilePath) = False Then
                    Exit Sub
                End If
            End If

            '''' 条件：処理区分判定
            '''' ケース：契約書別紙基本情報にチェック有の場合、以下の処理を行う
            '''' 　条件Paymentエラー判定処理(ExcelWrite.ChkPaymentErr)
            '''' 　ケース：エラーの場合、処理を中断する
            If cbContractDoc.Checked = True Then
                If ExcelWrite.ChkPaymentErr(Me.Name,
                                            sender.Name,
                                            CommonVariable.CPNO,
                                            CommonVariable.CONTRACTNO,
                                            cbContractDoc.Name,
                                            strPSFilePath,
                                            blnSkipCheck) = False Then
                    Exit Sub
                End If
            End If

            '===========================================
            'COST開示
            '===========================================
            '''' 条件：COST開示チェック判定
            '''' ケース：チェック有の場合、以下の処理を行う
            If cbCost.Checked = True Then
                Dim strErrMsg As String
                If ofm.CheckExistsMdb(OioFileManage.enmMdbType.Master, CommonVariable.MdbPW, strErrMsg) = False Then
                    Call MuseMessageBox.ShowError(strErrMsg, Me.Text)
                    Exit Sub
                End If

                '''' 　処理：待ちフォームプログレスバーメモリ表示
                Call ProgressBarCount(intProgressCnt,
                                      intCheckedMax,
                                      "COST開示" & STR_MESSAGE_CREATE_FILE,
                                      waitDialog)
                'PSファイル名の取得
                Dim strPSFileName As String = Me.txb_InputFile.Text

                '''' 　処理：Excel作成(COST開示)(ExcelNewKakakukaiji.OutputExcelKakakukaiji)
                om(ProcCd.Cost).Msg = "■COST開示"
                strRetMsg = ""
                Dim exlKakaku As New ExcelNewKakakukaiji
                blnRet = exlKakaku.OutputExcelKakakukaiji(strPSFileName, strRetMsg)
                If blnRet = True Then
                    '正常の場合
                    om(ProcCd.Cost).MsgKind = MsgKind.Infomation
                Else
                    '異常の場合
                    om(ProcCd.Cost).MsgKind = MsgKind.Ng
                End If
                om(ProcCd.Cost).Msg = om(ProcCd.Cost).Msg & vbCrLf &
                                      strRetMsg & vbCrLf & vbCrLf
                intProgressCnt = intProgressCnt + 1
            End If

            '===========================================
            'IGF集計
            '===========================================
            '''' 条件：IGF集計チェック判定
            '''' ケース：チェック有の場合、以下の処理を行う
            If cbIgf.Checked = True Then
                '''' 　処理：待ちフォームプログレスバーメモリ表示
                Call ProgressBarCount(intProgressCnt,
                                      intCheckedMax,
                                      "IGF集計" & STR_MESSAGE_CREATE_FILE,
                                      waitDialog)
                '''' 　処理：IGFフォルダ作成(OioFileManage.CreateLocalIGFSummaryFileFolder)
                Dim createTime As String = Date.Now.ToString("yyyyMMdd_HHmmss")
                Call ofm.CreateLocalIGFSummaryFileFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, createTime)

                ''PSファイルパス
                Dim xlsPSFilePath As String = Me.txb_InputFile.Text
                ''IGFテンプレートパス
                Dim xlsIGFTempFilePath As String = ofm.GetLocalIGFTemplatePath
                ''IGFファイルパス
                Dim xlsIGFFilePath As String = ofm.GetLocalIGFFileFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, createTime) & _
                                               ofm.GetOutIGFSummaryFileNM(CommonVariable.CPNO, CommonVariable.CONTRACTNO, createTime)

                '''' 　処理：IGF集計作成(NewExcelIGF.OutputExcelIGF)
                Dim exlIGF As New NewExcelIGF
                Dim exitState As String
                om(ProcCd.Igf).Msg = "■IGF集計"
                strRetMsg = ""
                blnRet = exlIGF.OutputExcelIGF(xlsPSFilePath, xlsIGFTempFilePath, xlsIGFFilePath, exitState, strRetMsg)

                '''' 条件：処理結果判定
                If blnRet = True Then
                    '''' ケース：処理結果が正常の場合、以下の処理を行う
                    If exitState = exlIGF.IGFCREATE_EXITSTATE_DATAZERO Then
                        '''' 処理：0件出力の場合、メッセージの設定
                        '''' 　メッセージ：ID:MSG_0340
                        '''' 　　該当するデータが存在しません。
                        om(ProcCd.Igf).Msg = om(ProcCd.Igf).Msg & vbCrLf &
                                             "　" & FileReader.GetMessage("MSG_0340") & vbCrLf & vbCrLf
                        om(ProcCd.Igf).MsgKind = MsgKind.Warning
                    Else
                        '''' 処理：正常出力の場合、メッセージの設定
                        '''' 　メッセージ：ID:MSG_0073
                        '''' 　　ファイルを作成しました。
                        om(ProcCd.Igf).Msg = om(ProcCd.Igf).Msg & vbCrLf &
                                             "　" & FileReader.GetMessage("MSG_0073") & vbCrLf & vbCrLf
                        om(ProcCd.Igf).MsgKind = MsgKind.Infomation
                    End If
                Else
                    '''' ケース：処理結果が異常の場合、メッセージ設定
                    om(ProcCd.Igf).MsgKind = MsgKind.Ng
                    om(ProcCd.Igf).Msg = "　" & om(ProcCd.Igf).Msg & vbCrLf &
                                               strRetMsg & vbCrLf & vbCrLf
                End If
                intProgressCnt = intProgressCnt + 1
            End If

            '===========================================
            'TOPACS申請
            '===========================================
            '''' 条件：TOPACS申請チェック判定
            '''' ケース：チェック有の場合、以下の処理を行う
            If cbTopacs.Checked = True Then
                '''' 処理：待ちフォームプログレスバーメモリ表示
                Call ProgressBarCount(intProgressCnt,
                                      intCheckedMax,
                                      "TOPACS申請" & STR_MESSAGE_CREATE_FILE,
                                      waitDialog)
                ''＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝
                ''以下、ファイル名の取得
                ''＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝
                '''' 　処理：ファイルの作成日時を作成
                Me.createFileTime = Now.ToString("yyyyMMdd_HHmmss")

                '''' 　処理：Topacsファイル格納フォルダ作成(OioFileManage.CreateLocalTopacsFileFolder)
                Call ofm.CreateLocalTopacsFileFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

                '''' 　処理：Topacsファイル名作成(OioFileManage.GetOutTopacsFileNM)
                Dim strOutFileName As String
                strOutFileName = ofm.GetOutTopacsFileNM(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

                '''' 　処理：Topacsフォルダ名作成
                Dim strOutDirName As String
                strOutDirName = ofm.GetLocalTopacsFileFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

                '''' 　処理：Topacsパス作成
                Dim strDestFileName As String = strOutDirName + strOutFileName

                '''' 　処理：PSファイル名の取得
                Dim strPSFileName As String = Me.txb_InputFile.Text

                '''' 　処理：雛型ファイルパスの取得
                Dim templatePath As String
                templatePath = ofm.GetLocalTopacsTemplatePath

                '''' 　処理：Topacsファイルの作成処理(NewExcelTOPACS.OutputExcelTOPACS)
                Dim exlTOPACS As New NewExcelTOPACS
                Dim isZero As Boolean = False
                om(ProcCd.Topacs).Msg = "■TOPACS申請"
                Dim isSuccess As Boolean = exlTOPACS.OutputExcelTOPACS(strPSFileName,
                                                                       strDestFileName,
                                                                       templatePath,
                                                                       isZero,
                                                                       strRetMsg)
                '''' 　条件：処理結果判定
                '''' 　ケース：処理結果が正常の場合、以下の処理を行う
                If isSuccess = True Then
                    '''' 　　条件：0件判定
                    '''' 　　ケース：0件の場合、メッセージの設定
                    '''' 　　　メッセージ：ID:MSG_0340
                    '''' 　　　　該当するデータが存在しません。
                    If isZero = True Then
                        om(ProcCd.Topacs).Msg = om(ProcCd.Topacs).Msg & vbCrLf &
                                                "　" & FileReader.GetMessage("MSG_0340") & vbCrLf & vbCrLf
                        om(ProcCd.Topacs).MsgKind = MsgKind.Warning
                    Else
                        '''' 　　処理：WS1をコピー(NewExcelTOPACS.CopyWS1)
                        Call exlTOPACS.CopyWS1(strDestFileName, strPSFileName)

                        '''' 　　ケース：0件以外の場合、メッセージの設定
                        '''' 　　　メッセージ：ID:MSG_0073
                        '''' 　　　　ファイルを作成しました。
                        om(ProcCd.Topacs).Msg = om(ProcCd.Topacs).Msg & vbCrLf &
                                                "　" & FileReader.GetMessage("MSG_0073") & vbCrLf & vbCrLf
                        om(ProcCd.Topacs).MsgKind = MsgKind.Infomation
                    End If
                Else
                    '''' 　ケース：処理結果が異常の場合、メッセージ設定
                    om(ProcCd.Topacs).MsgKind = MsgKind.Ng
                    om(ProcCd.Topacs).Msg = "　" & om(ProcCd.Topacs).Msg & vbCrLf &
                                                   strRetMsg & vbCrLf & vbCrLf
                End If
                intProgressCnt = intProgressCnt + 1
            End If

            '===========================================
            'S-LINK情報
            '===========================================
            '''' 条件：S-LINK情報チェック判定
            '''' ケース：チェック有の場合、以下の処理を行う
            If cbSlink.Checked = True Then
                '''' 　処理：待ちフォームプログレスバーメモリ表示
                Call ProgressBarCount(intProgressCnt,
                                      intCheckedMax,
                                      "S-LINK情報" & STR_MESSAGE_CREATE_FILE,
                                      waitDialog)
                Dim es As New ExcelSLink
                Dim intPsCount As Integer = 0

                '''' 　処理：S-Linkデータ作成(ExcelSLink.OutputSlink)
                om(ProcCd.SLink).Msg = "■S-LINK情報"
                strRetMsg = ""
                blnRet = es.OutputSlink(txb_InputFile.Text.Trim, intPsCount, strRetMsg)
                '''' 　条件：処理結果判定
                If blnRet = True Then
                    '''' 　ケース：処理結果が正常の場合、以下の処理を行う
                    '''' 　　条件：出力件数判定
                    ''1543 S-Link連携ファイルの作成機能変更 START
                    '''' 　　　メッセージ：ID:MSG_0073
                    '''' 　　　　ファイルを作成しました。
                    om(ProcCd.SLink).MsgKind = MsgKind.Infomation
                    om(ProcCd.SLink).Msg = om(ProcCd.SLink).Msg & vbCrLf &
                                               "　" & FileReader.GetMessage("MSG_0073") & vbCrLf & vbCrLf
                    '''' 　　ケース：0件出力の場合、メッセージの設定
                    '''' 　　　メッセージ：ID:MSG_0340
                    '''' 　　　　該当するデータが存在しません。
                    'If intPsCount = 0 Then
                    '    om(ProcCd.SLink).MsgKind = MsgKind.Warning
                    '    om(ProcCd.SLink).Msg = om(ProcCd.SLink).Msg & vbCrLf &
                    '                           "　" & FileReader.GetMessage("MSG_0340") & vbCrLf & vbCrLf
                    'Else
                    '    '''' 　　ケース：0件以外の場合、メッセージの設定
                    '    '''' 　　　メッセージ：ID:MSG_0073
                    '    '''' 　　　　ファイルを作成しました。
                    '    om(ProcCd.SLink).MsgKind = MsgKind.Infomation
                    '    om(ProcCd.SLink).Msg = om(ProcCd.SLink).Msg & vbCrLf &
                    '                           "　" & FileReader.GetMessage("MSG_0073") & vbCrLf & vbCrLf
                    'End If
                    ''1543 S-Link連携ファイルの作成機能変更 END
                Else
                    '''' 　ケース：処理結果が異常の場合、メッセージ設定
                    om(ProcCd.SLink).MsgKind = MsgKind.Ng
                    om(ProcCd.SLink).Msg = "　" & om(ProcCd.SLink).Msg & vbCrLf &
                                                 strRetMsg & vbCrLf & vbCrLf
                End If
                intProgressCnt = intProgressCnt + 1
            End If

            '===========================================
            '契約書別紙基本情報
            '===========================================
            '''' 条件：契約書別紙基本情報チェック判定
            '''' ケース：チェック有の場合、以下の処理を行う
            If cbContractDoc.Checked = True Then
                ''''   処理：別紙B出力対象CD取得
                Dim intRet As Integer
                intRet = IsEnableAttachedSheetBtn()
                ''''   条件：別紙B出力対象CD判定
                ''''   ケース：1(JRI)の場合、以下の処理を行う
                If intRet = 1 Then
                    '''' 　  処理：待ちフォームプログレスバーメモリ表示
                    Call ProgressBarCount(intProgressCnt,
                                          intCheckedMax,
                                          "契約書別紙基本情報" & STR_MESSAGE_CREATE_FILE,
                                          waitDialog)
                    '''' 　  処理：契約書別紙基本情報処理(OutAttachedSheet.OutAttachedSheet)
                    Dim attachedSheet As New OutAttachedSheet
                    om(ProcCd.ContractDoc).Msg = "■契約書別紙情報"
                    blnRet = attachedSheet.OutAttachedSheet(Me.txb_InputFile.Text, strRetMsg)
                    '''' 　  条件：処理結果判定
                    If blnRet = False Then
                        '''' 　  ケース：処理結果が異常の場合、メッセージ設定
                        om(ProcCd.ContractDoc).MsgKind = MsgKind.Ng
                        om(ProcCd.ContractDoc).Msg = om(ProcCd.ContractDoc).Msg & vbCrLf &
                                                     "　" & strRetMsg & vbCrLf & vbCrLf
                    Else
                        '''' 　  ケース：正常出力の場合、メッセージの設定
                        '''' 　　  メッセージ：ID:MSG_0073
                        '''' 　　　  ファイルを作成しました。
                        om(ProcCd.ContractDoc).MsgKind = MsgKind.Infomation
                        om(ProcCd.ContractDoc).Msg = om(ProcCd.ContractDoc).Msg & vbCrLf &
                                                     "　" & FileReader.GetMessage("MSG_0073") & vbCrLf & vbCrLf
                    End If
                    ''''   条件：別紙B出力対象CD判定
                    ''''   ケース：2(NISSAY)の場合、以下の処理を行う
                ElseIf intRet = 2 Then
                    '''' 　  処理：待ちフォームプログレスバーメモリ表示
                    Call ProgressBarCount(intProgressCnt,
                                          intCheckedMax,
                                          "契約書別紙基本情報" & STR_MESSAGE_CREATE_FILE,
                                          waitDialog)
                    '''' 　  処理：契約書別紙基本情報処理(OutAttachedSheet.OutAttachedSheet)
                    om(ProcCd.NissayPaDoc).Msg = "■契約書別紙情報"

                    Dim en As New ExcelNissay
                    blnRet = en.OutputPa(Me.txb_InputFile.Text, strRetMsg)
                    '''' 　  条件：処理結果判定
                    If blnRet = False Then
                        '''' 　  ケース：処理結果が異常の場合、メッセージ設定
                        om(ProcCd.NissayPaDoc).MsgKind = MsgKind.Ng
                        om(ProcCd.NissayPaDoc).Msg = om(ProcCd.NissayPaDoc).Msg & vbCrLf &
                                                     "　" & strRetMsg & vbCrLf & vbCrLf
                    Else
                        '''' 　  ケース：正常出力の場合、メッセージの設定
                        '''' 　　  メッセージ：ID:MSG_0073
                        '''' 　　　  ファイルを作成しました。
                        om(ProcCd.NissayPaDoc).MsgKind = MsgKind.Infomation
                        om(ProcCd.NissayPaDoc).Msg = om(ProcCd.NissayPaDoc).Msg & vbCrLf &
                                                     "　" & FileReader.GetMessage("MSG_0073") & vbCrLf & vbCrLf
                    End If
                End If


                intProgressCnt = intProgressCnt + 1
            End If

            '===========================================
            'Payment分割
            '===========================================
            '''' 条件：Payment分割チェック判定
            '''' ケース：チェック有の場合、以下の処理を行う
            If cbPaymentSplit.Checked = True Then
                '''' 　処理：待ちフォームプログレスバーメモリ表示
                Call ProgressBarCount(intProgressCnt,
                                      intCheckedMax,
                                      "Payment分割" & STR_MESSAGE_CREATE_FILE,
                                      waitDialog)
                '''' 　処理：契約書別紙基本情報処理(OutAttachedSheet.OutAttachedSheet)
                Dim ps As New PsSplit
                Dim FileName1 As String
                Dim FileName2 As String

                om(ProcCd.PsSplit).Msg = "■Payment分割"

                blnRet = ps.PsSplit(Me.txb_InputFile.Text, _
                                    FileName1, _
                                    FileName2, _
                                    strRetMsg)
                '''' 　条件：処理結果判定
                If blnRet = False Then
                    '''' 　ケース：処理結果が異常の場合、メッセージ設定
                    om(ProcCd.PsSplit).MsgKind = MsgKind.Ng
                    om(ProcCd.PsSplit).Msg = om(ProcCd.PsSplit).Msg & vbCrLf &
                                                 "　" & strRetMsg & vbCrLf & vbCrLf
                Else
                    '''' 　ケース：正常出力の場合、メッセージの設定
                    '''' 　　メッセージ：ID:MSG_0073
                    '''' 　　　ファイルを作成しました。
                    om(ProcCd.PsSplit).MsgKind = MsgKind.Infomation
                    om(ProcCd.PsSplit).Msg = om(ProcCd.PsSplit).Msg & vbCrLf &
                                                 "　" & FileReader.GetMessage("MSG_0073") & vbCrLf & vbCrLf
                End If
                intProgressCnt = intProgressCnt + 1
            End If

            '===========================================
            'ELAファイル
            '===========================================
            '''' 条件：ELAファイルチェック判定
            '''' ケース：チェック有の場合、何もしない
            If cbElaFile.Checked = True Then

            End If

            '===========================================
            'CiscoMaファイル
            '===========================================
            '''' 条件：CiscoMaファイルチェック判定
            '''' ケース：チェック有の場合、何もしない
            If cbIsatMa.Checked = True Then

            End If

            '===========================================
            'ePricer起票依頼ファイル
            '===========================================
            '''' 条件：ePricer起票依頼ファイルチェック判定
            '''' ケース：チェック有の場合、ePricer起票依頼ファイルの作成
            If cbEpricer.Checked = True Then

                '''' 処理：待ちフォームプログレスバーメモリ表示
                Call ProgressBarCount(intProgressCnt,
                                      intCheckedMax,
                                      "EPRICER申請" & STR_MESSAGE_CREATE_FILE,
                                      waitDialog)
                ''＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝
                ''以下、ファイル名の取得
                ''＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝
                '''' 　処理：ファイルの作成日時を作成
                Me.createFileTime = Now.ToString("yyyyMMdd_HHmmss")

                '''' 　処理：Epricerファイル格納フォルダ作成(OioFileManage.CreateLocalEpricerFileFolder)
                Call ofm.CreateLocalEpricerFileFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

                '''' 　処理：Epricerファイル名作成(OioFileManage.GetOutEpricerFileNM)
                Dim strOutFileName As String
                strOutFileName = ofm.GetOutEpricerFileNM(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

                '''' 　処理：Epricerフォルダ名作成
                Dim strOutDirName As String
                strOutDirName = ofm.GetLocalEpricerFileFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

                '''' 　処理：Epricerパス作成
                Dim strDestFileName As String = strOutDirName + strOutFileName

                '''' 　処理：PSファイル名の取得
                Dim strPSFileName As String = Me.txb_InputFile.Text

                '''' 　処理：雛型ファイルパスの取得
                Dim templatePath As String
                templatePath = ofm.GetLocalEpricerTemplatePath

                '''' 　処理：Epricerファイルの作成処理(NewExcelEPRICER.OutputExcelEPRICER)
                Dim exlEPRICER As New NewExcelEPRICER
                Dim isZero As Boolean = False
                om(ProcCd.ePricer).Msg = "■EPRICER申請"
                Dim isSuccess As Boolean = exlEPRICER.OutputExcelEPRICER(strPSFileName,
                                                                         strDestFileName,
                                                                         templatePath,
                                                                         isZero,
                                                                         strRetMsg)
                '''' 　条件：処理結果判定
                '''' 　ケース：処理結果が正常の場合、以下の処理を行う
                If isSuccess = True Then
                    '''' 　　条件：0件判定
                    '''' 　　ケース：0件の場合、メッセージの設定
                    '''' 　　　メッセージ：ID:MSG_0340
                    '''' 　　　　該当するデータが存在しません。
                    If isZero = True Then
                        om(ProcCd.ePricer).Msg = om(ProcCd.ePricer).Msg & vbCrLf &
                                                "　" & FileReader.GetMessage("MSG_0340") & vbCrLf & vbCrLf
                        om(ProcCd.ePricer).MsgKind = MsgKind.Warning
                    Else
                        '''' 　　処理：WS1をコピー(NewExcelEPRICER.CopyWS1)
                        Call exlEPRICER.CopyWS1(strDestFileName, strPSFileName)

                        '''' 　　ケース：0件以外の場合、メッセージの設定
                        '''' 　　　メッセージ：ID:MSG_0073
                        '''' 　　　　ファイルを作成しました。
                        om(ProcCd.ePricer).Msg = om(ProcCd.ePricer).Msg & vbCrLf &
                                                "　" & FileReader.GetMessage("MSG_0073") & vbCrLf & vbCrLf
                        om(ProcCd.ePricer).MsgKind = MsgKind.Infomation
                    End If
                Else
                    '''' 　ケース：処理結果が異常の場合、メッセージ設定
                    om(ProcCd.ePricer).MsgKind = MsgKind.Ng
                    om(ProcCd.ePricer).Msg = "　" & om(ProcCd.ePricer).Msg & vbCrLf &
                                                   strRetMsg & vbCrLf & vbCrLf
                End If
                intProgressCnt = intProgressCnt + 1
            End If

            '''' 処理：各処理メッセージ表示
            waitDialog.Close()
            Dim strMsg As String = ""
            Dim blnOK As Boolean = True
            For intCnt As Integer = ProcCd.Cost To ProcCd.NissayPaDoc
                If om(intCnt).Msg <> "" Then
                    strMsg = strMsg & om(intCnt).Msg
                End If
                If om(intCnt).MsgKind = MsgKind.Ng Or om(intCnt).MsgKind = MsgKind.Warning Then
                    blnOK = False
                End If
            Next
            If strMsg <> "" Then
                If blnOK = True Then
                    MuseMessageBox.ShowInformation(strMsg, Me.Text)
                Else
                    MuseMessageBox.ShowWarning(strMsg, Me.Text)
                End If
            End If

        Catch ex As Exception
            waitDialog.Close()
            waitDialog = Nothing
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")

        Finally
            If IsNothing(waitDialog) = False Then
                waitDialog.Close()
            End If
            Me.Enabled = True
            Me.Cursor = Cursors.Default

        End Try

    End Sub

    ''' <summary>
    ''' 機能：読込ボタンクリック
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnInput_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInput.Click

        '処理中ダイアログ定義
        Dim waitDialog As New Frm_WaitDialog
        Dim strPSFilePath As String = Me.txb_InputFile.Text
        Dim ofm As New OioFileManage
        Dim intCheckedCnt As Integer = 0
        Dim wRet As Boolean

        Try
            '''' 処理：処理中ダイアログ表示
            Call SetWaitDialogInit(waitDialog)
            Call waitDialog.Show()
            Me.Cursor = Cursors.WaitCursor
            Me.Enabled = False

            '''' 処理：画面の入力値チェック
            If CheckFormInputData(CD_BTN_INPUT, intCheckedCnt) = False Then
                Exit Sub
            End If

            Dim rdbNM As String
            If cbCost.Checked = True Then
                rdbNM = cbCost.Name
            End If
            If cbTopacs.Checked = True Then
                rdbNM = cbTopacs.Name
            End If
            If cbIgf.Checked = True Then
                rdbNM = cbIgf.Name
            End If
            If cbSlink.Checked = True Then
                rdbNM = cbSlink.Name
            End If
            If cbContractDoc.Checked = True Then
                rdbNM = cbContractDoc.Name
            End If
            If cbElaFile.Checked = True Then
                rdbNM = cbElaFile.Name
            End If
            If cbIsatMa.Checked = True Then
                rdbNM = cbIsatMa.Name
            End If
            If cbEpricer.Checked = True Then
                rdbNM = cbEpricer.Name
            End If

            '取込フォーマットチェック
            If InputFileFormatCheck() = False Then
                MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0524"), Me.Text)
                Exit Sub
            End If

            If ExcelWrite.ChkPaymentErr(Me.Name, sender.Name, _
                                        CommonVariable.CPNO, CommonVariable.CONTRACTNO, rdbNM, strPSFilePath) = False Then
                Exit Sub
            End If

            '------------------------------------
            'COST開示
            '------------------------------------
            If cbCost.Checked = True Then
                '価格開示読込み
                Dim exlKakaku As New ExcelNewKakakukaiji
                Dim InitialDirectory As New OioFileManage
                Dim costFileNMArray() As String
                Dim rtnMessage As String

                waitDialog.PerformStep()

                costFileNMArray = GetCostFileArray(Me.txtRefInputFile.Text)
                If IsNothing(costFileNMArray) = False Then
                    'PS書込み処理
                    Call exlKakaku.KakakukaijiReflection(costFileNMArray, strPSFilePath, rtnMessage)
                Else
                    rtnMessage = FileReader.GetMessage("MSG_0442")
                End If

                waitDialog.PerformStep()
                waitDialog.Close()
                Me.Enabled = True
                Me.Cursor = Cursors.Default

                Call DispPSDetailTextBox()

                '完了メッセージ
                MuseMessageBox.ShowInformation(rtnMessage, Me.Text)

            ElseIf cbTopacs.Checked = True Then
                '------------------------------------
                'TOPACS申請
                '------------------------------------

                waitDialog.PerformStep()
                waitDialog.PerformStep()

                'PS書込み処理
                Dim outCntPS As Integer = 0
                Dim outCntUnMatchPS As Integer = 0
                Dim outCntNotEntry As Integer = 0
                Dim exitMsg As String = ""
                Dim exlTOPACS As New NewExcelTOPACS
                Dim isSuccess As Boolean = exlTOPACS.TOPACSReflection(Me.txtRefInputFile.Text,
                                                                        strPSFilePath,
                                                                        outCntPS,
                                                                        outCntUnMatchPS,
                                                                        outCntNotEntry,
                                                                        exitMsg)

                waitDialog.PerformStep()
                waitDialog.Close()

                ''反映処理中に、ユーザー定義エラー（例外[Exception]以外のエラー）があった場合の処理()
                If exitMsg <> "" Then
                    MuseMessageBox.ShowWarning(exitMsg, Me.Text)
                    Me.Enabled = True
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If

                Me.Enabled = True
                Me.Cursor = Cursors.Default

                If isSuccess = True Then
                    '処理が正常取り込みできた場合のみ、リネーム
                    Call CreateBKTopacsFile(Me.txtRefInputFile.Text)
                    'PSファイルパスの初期設定
                    Call DispPSDetailTextBox()

                    '完了メッセージ
                    MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0085") + vbCrLf + _
                                                    Path.GetFileName(strPSFilePath) + vbCrLf + _
                                                    "　正常　：" + outCntPS.ToString() + "件" + vbCrLf + _
                                                    "　異常　：" + outCntUnMatchPS.ToString() + "件" + vbCrLf + _
                                                    "　対象外：" + outCntNotEntry.ToString() + "件" _
                                                    , Me.Text)

                End If

            ElseIf cbIgf.Checked = True Then
                '------------------------------------
                'IGF集計
                '------------------------------------
                Dim filePaths(1) As String
                Dim rtncd As Integer
                Dim rtnMsg As String
                filePaths(0) = Me.txb_InputFile.Text
                filePaths(1) = Me.txtRefInputFile.Text

                Dim exlIGF As New NewExcelIGF
                ''IGFファイル
                Dim xlIGFBook As Excel.Workbook
                Dim xlIGFResultSheet As Excel.Worksheet
                Dim xlApp As New Excel.Application
                ''Excelオブジェクトの読込
                xlApp.EnableEvents = False
                xlApp.DisplayAlerts = False
                xlIGFBook = xlApp.Workbooks.Open(Me.txtRefInputFile.Text)
                xlIGFResultSheet = xlIGFBook.Worksheets("依頼後")
                'チェック結果チェック
                rtnMsg = exlIGF.ChkXlsInputErr(xlIGFResultSheet)
                If rtnMsg <> "" Then
                    '終了オブジェクト破棄
                    ExcelObjRelease.ReleaseExcelObj(xlIGFResultSheet, ExcelObjRelease.OBJECT_NOTHING)
                    If IsNothing(xlIGFBook) = False Then
                        xlIGFBook.Close(False)
                    End If
                    ExcelObjRelease.ReleaseExcelObj(xlIGFBook, ExcelObjRelease.OBJECT_NOTHING)

                    xlApp.DisplayAlerts = True
                    xlApp.EnableEvents = True
                    If IsNothing(xlApp) = False Then
                        xlApp.Quit()
                    End If
                    ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

                    xlIGFResultSheet = Nothing
                    xlIGFBook = Nothing
                    xlApp = Nothing

                    'エラー発生
                    MsgBox(rtnMsg, vbExclamation, Me.Text)

                    'エラー発生
                    ''Throw New Exception(rtnMsg)
                    Exit Sub
                End If
                '終了オブジェクト破棄
                ExcelObjRelease.ReleaseExcelObj(xlIGFResultSheet, ExcelObjRelease.OBJECT_NOTHING)
                If IsNothing(xlIGFBook) = False Then
                    xlIGFBook.Close(False)
                End If
                ExcelObjRelease.ReleaseExcelObj(xlIGFBook, ExcelObjRelease.OBJECT_NOTHING)

                xlApp.DisplayAlerts = True
                xlApp.EnableEvents = True
                If IsNothing(xlApp) = False Then
                    xlApp.Quit()
                End If
                ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

                xlIGFResultSheet = Nothing
                xlIGFBook = Nothing
                xlApp = Nothing

                rtncd = ExcelWrite.chkPayPeriod(rtnMsg,
                        ExcelWrite.enmChkPayPeriodCallMethod.importIGF,
                        filePaths)
                Select Case rtncd
                    Case ExcelWrite.enmChkPayPeriodRtnCd.ChkOK              'OK
                    Case ExcelWrite.enmChkPayPeriodRtnCd.ChkNG,
                         ExcelWrite.enmChkPayPeriodRtnCd.ChkException       'NG/例外
                        waitDialog.Close()
                        Me.Enabled = True
                        Me.Cursor = Cursors.Default
                        MsgBox(rtnMsg, MsgBoxStyle.Critical)
                        Exit Sub
                End Select

                Dim countIGFRow As Integer              ''IGFファイルのデータ件数(集計行を除く)
                Dim countOutputRow As Integer           ''PaymentSheet.Xlsへの反映件数
                Dim isSuccess As Boolean = exlIGF.IGFReflection(Me.txtRefInputFile.Text, _
                                                                strPSFilePath, _
                                                                countIGFRow, _
                                                                countOutputRow)

                ''画面の制御を戻す
                waitDialog.Close()
                Me.Enabled = True
                Me.Cursor = Cursors.Default

                If isSuccess = True Then
                    '処理が正常取り込みできた場合のみ、リネーム
                    Call CreateBKIGFFile(Me.txtRefInputFile.Text)
                    'PSファイルパスの初期設定
                    Call DispPSDetailTextBox()
                    '完了メッセージ
                    MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0085"), Me.Text)

                Else
                    'NGメッセージ
                    Dim colErrInfoNM As String = ExcelWrite.chgExcelColumnIdxToChar(exlIGF.GetIGFColIdxMonthlyEnd(exlIGF.enmIGFColIdxType.TypeErrInfo))
                    MuseMessageBox.ShowWarning(FileReader.GetMessage("MSG_0281") + vbCrLf + _
                                                Path.GetFileName(Me.txtRefInputFile.Text) & "の" & colErrInfoNM & "列を参照してください。", Me.Text)
                End If

            ElseIf cbSlink.Checked = True Then
                '------------------------------------
                'S-LINK情報
                '------------------------------------
                Dim es As New ExcelSLink
                Dim blnRet As Boolean
                Dim intOutputCnt As Integer = 0

                blnRet = es.InputSlink(strPSFilePath, txtRefInputFile.Text, intOutputCnt, waitDialog)
                If blnRet = False Then
                    Exit Sub
                End If

                waitDialog.Close()
                Me.Enabled = True
                Me.Cursor = Cursors.Default

                If intOutputCnt = 0 Then
                    '０件メッセージ
                    MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0419"), Me.Text)
                Else
                    '完了メッセージ
                    MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0418"), Me.Text)
                End If

            ElseIf cbElaFile.Checked = True Then
                '------------------------------------
                'Ela File情報
                '------------------------------------

                Dim es As New ExcelEla
                Dim blnRet As Boolean
                Dim intOutputCnt As Integer = 0

                blnRet = es.InputEla(strPSFilePath, txtRefInputFile.Text, intOutputCnt, waitDialog)
                If blnRet = False Then
                    Exit Sub
                End If

                waitDialog.Close()
                Me.Enabled = True
                Me.Cursor = Cursors.Default

                If intOutputCnt = 0 Then
                    '０件メッセージ
                    MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0525"), Me.Text)
                Else
                    '完了メッセージ
                    MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0526"), Me.Text)
                End If

            ElseIf cbIsatMa.Checked = True Then
                '------------------------------------
                'ISAT情報
                '------------------------------------
                Dim MA As New ExceIsatMA
                Dim intRet As Integer
                Dim strIsatFileNames() As String
                strIsatFileNames = GetIsatFileArray(Me.txtRefInputFile.Text)
                If strIsatFileNames Is Nothing Then
                    'ファイルなし
                    MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0550"), Me.Text)
                    Exit Sub
                End If
                Dim intOutputCnt As Integer = 0
                Dim countCiscoMARow As Integer = 0

                intRet = MA.IsatMaReflection(strPSFilePath, _
                                             strIsatFileNames,
                                             intOutputCnt)

                waitDialog.Close()
                Me.Enabled = True
                Me.Cursor = Cursors.Default

                If intOutputCnt = 0 Then
                    '０件メッセージ
                    MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0513"), Me.Text)
                Else
                    '完了メッセージ
                    MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0512"), Me.Text)
                End If

            ElseIf cbEpricer.Checked = True Then
                '------------------------------------
                'ePricer申請
                '------------------------------------

                waitDialog.PerformStep()
                waitDialog.PerformStep()

                'PS書込み処理
                Dim outCntPS As Integer = 0
                Dim outCntUnMatchPS As Integer = 0
                Dim outCntNotEntry As Integer = 0
                Dim exitMsg As String = ""
                Dim exlEpricer As New NewExcelEPRICER
                Dim isSuccess As Boolean = exlEpricer.EPRICERReflection(Me.txtRefInputFile.Text,
                                                                        strPSFilePath,
                                                                        outCntPS,
                                                                        outCntUnMatchPS,
                                                                        outCntNotEntry,
                                                                        exitMsg)

                waitDialog.PerformStep()
                waitDialog.Close()

                ''反映処理中に、ユーザー定義エラー（例外[Exception]以外のエラー）があった場合の処理()
                If exitMsg <> "" Then
                    MuseMessageBox.ShowWarning(exitMsg, Me.Text)
                    Me.Enabled = True
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If

                Me.Enabled = True
                Me.Cursor = Cursors.Default

                If isSuccess = True Then
                    '処理が正常取り込みできた場合のみ、リネーム
                    Call CreateBKEpricerFile(Me.txtRefInputFile.Text)
                    'PSファイルパスの初期設定
                    Call DispPSDetailTextBox()

                    '完了メッセージ
                    MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0085") + vbCrLf + _
                                                    Path.GetFileName(strPSFilePath) + vbCrLf + _
                                                    "　正常　：" + outCntPS.ToString() + "件" + vbCrLf + _
                                                    "　異常　：" + outCntUnMatchPS.ToString() + "件" + vbCrLf + _
                                                    "　対象外：" + outCntNotEntry.ToString() + "件" _
                                                    , Me.Text)

                End If

            End If

        Catch ex As Exception

            waitDialog.Close()
            Me.Enabled = True
            Me.Cursor = Cursors.Default

            If cbIgf.Checked = True Then
                Select Case ex.Message
                    Case FileReader.GetMessage("MSG_0355"), _
                         FileReader.GetMessage("MSG_0356")
                        MsgBox(ex.Message, vbExclamation, Me.Text)
                    Case Else
                        MsgBox(ex.Message, vbCritical, Me.Text)
                End Select
            Else
                MsgBox(ex.Message, vbCritical, Me.Text)
            End If

        Finally
            Me.Enabled = True
            Me.Cursor = Cursors.Default
            If IsNothing(waitDialog) = False Then
                waitDialog.Close()
            End If

        End Try

    End Sub

    ''' <summary>
    ''' 機能：Payment分割チェックボックスクリック
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub cbPaymentSplit_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbPaymentSplit.CheckedChanged
        If cbPaymentSplit.Checked = True Then
            btnSysReference.Enabled = False
            btnInput.Enabled = False
        Else
            btnSysReference.Enabled = True
            btnInput.Enabled = True
        End If
    End Sub

    ''' <summary>
    ''' 機能：ELAファイル　チェックボックスクリック
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub cbElaFile_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbElaFile.CheckedChanged
        If cbElaFile.Checked = True Then
            btnSysReference.Enabled = True
            btnInput.Enabled = True
        Else
            btnSysReference.Enabled = True
            btnInput.Enabled = True
        End If
    End Sub

    ''' <summary>
    ''' 機能：CISCO MAファイル　チェックボックスクリック
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub cbCiscoMa_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbIsatMa.CheckedChanged
        If cbIsatMa.Checked = True Then
            btnSysReference.Enabled = True
            btnInput.Enabled = True
        Else
            btnSysReference.Enabled = True
            btnInput.Enabled = True
        End If
    End Sub

    ''' <summary>
    ''' 機能：ePricer起票ファイル　チェックボックスクリック
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub cbePricer_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbEpricer.CheckedChanged
        If cbEpricer.Checked = True Then
            btnSysReference.Enabled = True
            btnInput.Enabled = True
        Else
            btnSysReference.Enabled = True
            btnInput.Enabled = True
        End If
    End Sub

#End Region

#Region "プライベートメソッド"
    ''' <summary>
    ''' 対象フォルダ直下のCost開示ファイル名を取得
    ''' </summary>
    ''' <param name="costFolder">COST開示フォルダのパス</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetCostFileArray(ByVal costFolder As String) As String()

        '''' 処理：.xlsmファイルを全て抽出(GetDirFileNMs())
        Dim dirFileNMs() As String
        dirFileNMs = GetDirFileNMs(costFolder)

        '''' 処理：対象のCost開示ファイルのみ取得(GetCostFile())
        Dim rtnFileNMs() As String
        rtnFileNMs = GetCostFile(dirFileNMs)

        Return rtnFileNMs

    End Function

    ''' <summary>
    ''' 対象フォルダ直下のISATファイル名を取得
    ''' </summary>
    ''' <param name="costFolder"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetIsatFileArray(ByVal isatFolder As String) As String()

        '''' 処理：.xlsxﾌｧｲﾙを全て抽出
        Dim dirFileNMs() As String
        dirFileNMs = Directory.GetFiles(isatFolder, "*.xlsx")

        '''' 処理：対象のIsatﾌｧｲﾙのみ取得(GetCostFile())
        Dim rtnFileNMs() As String
        rtnFileNMs = GetCostFile(dirFileNMs)

        Return rtnFileNMs

    End Function

    ''' <summary>
    ''' COST開示の文言を含むファイルを全て抽出
    ''' </summary>
    ''' <param name="costFolder">COST開示フォルダのパス</param>
    ''' <returns>指定フォルダの全.xlsmファイル名</returns>
    ''' <remarks></remarks>
    Private Function GetDirFileNMs(ByVal costFolder As String) As String()

        GetDirFileNMs = System.IO.Directory.GetFiles(costFolder, "*.xlsm")

    End Function

    ''' <summary>
    ''' 対象のCost開示ファイルのみ取得
    ''' </summary>
    ''' <param name="dirFileNMs">xlmsファイル名</param>
    ''' <returns>COST開示用ファイル名</returns>
    ''' <remarks></remarks>
    Private Function GetCostFile(ByVal dirFileNMs() As String) As String()

        Dim rtnFiles() As String
        Dim arrayindex As Integer = 0

        '''' 処理：BK_ファイルを除外する
        For Each dirfileNM As String In dirFileNMs

            If dirfileNM.IndexOf("BK_") = -1 Then
                ReDim Preserve rtnFiles(arrayindex)
                rtnFiles(arrayindex) = dirfileNM
                arrayindex = arrayindex + 1
            End If

        Next
        Return rtnFiles
    End Function

    ''' <summary>
    ''' ファイル名よりBKファイルかどうか判定
    ''' </summary>
    ''' <param name="fileNM">ファイル名</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function IsBKFile(ByVal fileNM As String) As Boolean

        IsBKFile = False

        '''' 処理：ファイル名に「BK_」が含まれるか判定
        If fileNM.IndexOf("BK_") <> -1 Then
            IsBKFile = True
        End If

    End Function

    ''' <summary>
    ''' Topacs起票ファイルのバックアップファイルの作成
    ''' </summary>
    ''' <param name="TopacsFilePath">TOPACSフォルダパス</param>
    ''' <remarks></remarks>
    Private Sub CreateBKTopacsFile(ByVal TopacsFilePath As String)
        Try
            ''バックアップファイル名の取得
            Dim TopacsFileNM As String
            Dim BKFilePath As String
            Dim BKFileDir As String
            Dim BKFileNM As String

            BKFileDir = Path.GetDirectoryName(TopacsFilePath)

            '''' 処理：ファイル名取得
            TopacsFileNM = Path.GetFileName(TopacsFilePath)
            BKFileNM = GetTopacsBKFileNM(BKFileDir, TopacsFileNM)

            '''' 処理：パス取得			
            BKFilePath = BKFileDir & "\" & BKFileNM

            '''' 処理：BKファイルの作成(リネーム)
            System.IO.File.Move(TopacsFilePath, BKFilePath)

        Catch ex As Exception

            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' Topacs起票ファイルのバックアップファイル名の取得
    ''' </summary>
    ''' <param name="BKFileDir">バックアップフォルダのパス</param>
    ''' <param name="TopacsFileNM">TOPACSファイル名</param>
    ''' <returns>Topacs起票ファイルのバックアップファイル名</returns>
    ''' <remarks></remarks>
    Private Function GetTopacsBKFileNM(ByVal BKFileDir As String,
                                       ByVal TopacsFileNM As String) As String

        GetTopacsBKFileNM = ""

        '''' 処理：フォルダ内の.xlsmファイル名を全て取得
        Dim dirFileNMs() As String
        dirFileNMs = System.IO.Directory.GetFiles(BKFileDir, "BK_*.xlsm")

        '''' 処理：ファイル名プレフィクスの取得
        Dim filePrefix As String = ""
        Dim matchFileCount As Integer = 0
        Dim matchBKFileNMes() As String
        For Each dirFileNm As String In dirFileNMs

            dirFileNm = Path.GetFileName(dirFileNm)
            ''ファイル名が一致するBKファイルの取得
            If dirFileNm.IndexOf(TopacsFileNM) = ("BK_999").Length And
               TopacsFileNM.Length = dirFileNm.Length - ("BK_999").Length Then

                ReDim Preserve matchBKFileNMes(matchFileCount)
                matchBKFileNMes(matchFileCount) = dirFileNm
                matchFileCount = matchFileCount + 1

            End If
        Next

        '''' 処理：プレフィクス番号が最大のファイル名を取得
        Dim tempFileNm As String
        If IsNothing(matchBKFileNMes) = False Then
            Call Array.Sort(matchBKFileNMes)
            tempFileNm = matchBKFileNMes(matchBKFileNMes.Length - 1)
            filePrefix = (CInt(tempFileNm.Substring("BK_".Length, "000".Length)) + 1).ToString.PadLeft(3, "0")
        End If

        '''' 処理：BKファイルが存在しなければ、"000"とする。
        If filePrefix = "" Then
            filePrefix = "000"
        End If

        '''' 処理：ファイル名の取得
        Dim rtnFileNM As String
        rtnFileNM = "BK_" & filePrefix & TopacsFileNM

        Return rtnFileNM

    End Function

    ''' <summary>
    ''' IGF起票ファイルのバックアップファイルの作成
    ''' </summary>
    ''' <param name="IGFFilePath">IGFフォルダパス</param>
    ''' <remarks></remarks>
    Private Sub CreateBKIGFFile(ByVal IGFFilePath As String)
        Try
            ''バックアップファイル名の取得
            Dim IGFFileNM As String
            Dim BKFilePath As String
            Dim BKFileDir As String
            Dim BKFileNM As String

            ''フォルダ取得
            BKFileDir = Path.GetDirectoryName(IGFFilePath)

            '''' 処理：ファイル名取得
            IGFFileNM = Path.GetFileName(IGFFilePath)
            BKFileNM = GetIGFBKFileNM(BKFileDir, IGFFileNM)

            '''' 処理：パス取得			
            BKFilePath = BKFileDir & "\" & BKFileNM

            '''' 処理：BKファイルの作成(リネーム)
            System.IO.File.Move(IGFFilePath, BKFilePath)

        Catch ex As Exception

            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' IGF起票ファイルのバックアップファイル名の取得
    ''' </summary>
    ''' <param name="BKFileDir">バックアップフォルダ名</param>
    ''' <param name="IGFFileNM">IGFファイル名</param>
    ''' <returns>IGF起票ファイルのバックアップファイル名</returns>
    ''' <remarks></remarks>
    Private Function GetIGFBKFileNM(ByVal BKFileDir As String,
                                       ByVal IGFFileNM As String) As String

        GetIGFBKFileNM = ""

        '''' 処理：フォルダ内の.xlsmファイル名を全て取得
        Dim dirFileNMs() As String
        dirFileNMs = System.IO.Directory.GetFiles(BKFileDir, "BK_*.xlsm")

        '''' 処理：ファイル名プレフィクスの取得
        Dim filePrefix As String = ""
        Dim matchFileCount As Integer = 0
        Dim matchBKFileNMes() As String
        For Each dirFileNm As String In dirFileNMs

            dirFileNm = Path.GetFileName(dirFileNm)
            ''ファイル名が一致するBKファイルの取得
            If dirFileNm.IndexOf(IGFFileNM) = ("BK_999").Length And
               IGFFileNM.Length = dirFileNm.Length - ("BK_999").Length Then

                ReDim Preserve matchBKFileNMes(matchFileCount)
                matchBKFileNMes(matchFileCount) = dirFileNm
                matchFileCount = matchFileCount + 1

            End If
        Next

        '''' 処理：プレフィクス番号が最大のファイル名を取得
        Dim tempFileNm As String
        If IsNothing(matchBKFileNMes) = False Then
            Call Array.Sort(matchBKFileNMes)
            tempFileNm = matchBKFileNMes(matchBKFileNMes.Length - 1)
            filePrefix = (CInt(tempFileNm.Substring("BK_".Length, "000".Length)) + 1).ToString.PadLeft(3, "0")
        End If

        '''' 処理：BKファイルが存在しなければ、"000"とする。
        If filePrefix = "" Then
            filePrefix = "000"
        End If

        '''' 処理：ファイル名の取得設定
        Dim rtnFileNM As String
        rtnFileNM = "BK_" & filePrefix & IGFFileNM

        Return rtnFileNM

    End Function

    ''' <summary>
    ''' Epricer起票ファイルのバックアップファイルの作成
    ''' </summary>
    ''' <param name="TopacsFilePath">EPRICERフォルダパス</param>
    ''' <remarks></remarks>
    Private Sub CreateBKEpricerFile(ByVal EpricerFilePath As String)
        Try
            ''バックアップファイル名の取得
            Dim EpricerFileNM As String
            Dim BKFilePath As String
            Dim BKFileDir As String
            Dim BKFileNM As String

            BKFileDir = Path.GetDirectoryName(EpricerFilePath)

            '''' 処理：ファイル名取得
            EpricerFileNM = Path.GetFileName(EpricerFilePath)
            BKFileNM = GetEpricerBKFileNM(BKFileDir, EpricerFileNM)

            '''' 処理：パス取得			
            BKFilePath = BKFileDir & "\" & BKFileNM

            '''' 処理：BKファイルの作成(リネーム)
            System.IO.File.Move(EpricerFilePath, BKFilePath)

        Catch ex As Exception

            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' Epricer起票ファイルのバックアップファイル名の取得
    ''' </summary>
    ''' <param name="BKFileDir">バックアップフォルダのパス</param>
    ''' <param name="TopacsFileNM">EPRICERファイル名</param>
    ''' <returns>Epricer起票ファイルのバックアップファイル名</returns>
    ''' <remarks></remarks>
    Private Function GetEpricerBKFileNM(ByVal BKFileDir As String,
                                       ByVal EpricerFileNM As String) As String

        GetEpricerBKFileNM = ""

        '''' 処理：フォルダ内の.xlsmファイル名を全て取得
        Dim dirFileNMs() As String
        dirFileNMs = System.IO.Directory.GetFiles(BKFileDir, "BK_*.xlsm")

        '''' 処理：ファイル名プレフィクスの取得
        Dim filePrefix As String = ""
        Dim matchFileCount As Integer = 0
        Dim matchBKFileNMes() As String
        For Each dirFileNm As String In dirFileNMs

            dirFileNm = Path.GetFileName(dirFileNm)
            ''ファイル名が一致するBKファイルの取得
            If dirFileNm.IndexOf(EpricerFileNM) = ("BK_999").Length And
               EpricerFileNM.Length = dirFileNm.Length - ("BK_999").Length Then

                ReDim Preserve matchBKFileNMes(matchFileCount)
                matchBKFileNMes(matchFileCount) = dirFileNm
                matchFileCount = matchFileCount + 1

            End If
        Next

        '''' 処理：プレフィクス番号が最大のファイル名を取得
        Dim tempFileNm As String
        If IsNothing(matchBKFileNMes) = False Then
            Call Array.Sort(matchBKFileNMes)
            tempFileNm = matchBKFileNMes(matchBKFileNMes.Length - 1)
            filePrefix = (CInt(tempFileNm.Substring("BK_".Length, "000".Length)) + 1).ToString.PadLeft(3, "0")
        End If

        '''' 処理：BKファイルが存在しなければ、"000"とする。
        If filePrefix = "" Then
            filePrefix = "000"
        End If

        '''' 処理：ファイル名の取得
        Dim rtnFileNM As String
        rtnFileNM = "BK_" & filePrefix & EpricerFileNM

        Return rtnFileNM

    End Function

    ''' <summary>
    ''' 処理中ﾀﾞｲｱﾙﾛｸﾞ画面の初期化
    ''' </summary>
    ''' <param name="waitDialog">待ち画面フォーム</param>
    ''' <remarks></remarks>
    Private Sub SetWaitDialogInit(ByRef waitDialog As Frm_WaitDialog)

        '''' 処理：初期値をセット
        waitDialog.Text = STR_CREATING
        waitDialog.lbl_Message.Text = STR_MESSAGE_CREATE_FILE
        waitDialog.Pic_Excel.Visible = True
        waitDialog.ProgressMin = 0
        waitDialog.ProgressMax = 100
        waitDialog.Show()
        waitDialog.Refresh()
    End Sub

    ''' <summary>
    ''' 画面の入力値をチェック
    ''' </summary>
    ''' <param name="intSysCd">作成読込区分</param>
    ''' <param name="intCheckCnt">処理数</param>
    ''' <returns>True:正常、False:異常</returns>
    ''' <remarks></remarks>
    Private Function CheckFormInputData(ByVal intInOutCd As Integer, ByRef intCheckedCnt As Integer) As Boolean

        Dim strPSFilePath As String = Me.txb_InputFile.Text.Trim
        Dim strRefFilePath As String = Me.txtRefInputFile.Text.Trim
        Dim ofm As New OioFileManage

        CheckFormInputData = False

        Try
            '''' 条件：画面のPaymentPath入力
            '''' ケース：未入力の場合、エラーメッセージを表示し処理を中断する
            '''' 　メッセージ：ID：MSG_0081
            '''' 　　正しいファイルを指定してください。
            If strPSFilePath = "" Then
                MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0081"), Me.Text)
                Exit Function
            End If

            '''' 条件：PSファイルの存在チェック
            '''' ケース：PSファイルが存在しない場合、エラーメッセージを表示し処理を中断する
            '''' 　メッセージ：ID：MSG_0084
            '''' 　　最新のPaymentﾌｧｲﾙ(作業用)が存在しません。
            If File.Exists(strPSFilePath) = False Then
                MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0084"), Me.Text)
                Exit Function
            End If

            'Excelが書込可能な状態か判定
            '''' 条件：Excelが書込可能な状態か判定
            '''' ケース：書込不可、エラーメッセージを表示し処理を中断する
            '''' 　メッセージ：ID：MSG_0280
            '''' 　　更新対象のファイルがOPENされています。&#10;ﾌｧｲﾙを閉じてください。
            '''' 　　ファイル名：xxxxxxxxxxxxxxxxx
            If ofm.ChkOpenedExcelFile(strPSFilePath) = False Then
                'PSファイルパスの初期設定
                Call MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0280") & vbCrLf & vbCrLf _
                                              & "ファイル名：" & Path.GetFileName(strPSFilePath), Me.Text)
                Exit Function
            End If

            '''' 処理：チェック数取得
            If cbCost.Checked = True Then
                intCheckedCnt = intCheckedCnt + 1
            End If
            If cbTopacs.Checked = True Then
                intCheckedCnt = intCheckedCnt + 1
            End If
            If cbIgf.Checked = True Then
                intCheckedCnt = intCheckedCnt + 1
            End If
            If cbSlink.Checked = True Then
                intCheckedCnt = intCheckedCnt + 1
            End If
            If cbContractDoc.Checked = True Then
                intCheckedCnt = intCheckedCnt + 1
            End If
            If cbPaymentSplit.Checked = True Then
                intCheckedCnt = intCheckedCnt + 1
            End If
            If cbElaFile.Checked = True Then
                intCheckedCnt = intCheckedCnt + 1
            End If
            If cbIsatMa.Checked = True Then
                intCheckedCnt = intCheckedCnt + 1
            End If
            If cbEpricer.Checked = True Then
                intCheckedCnt = intCheckedCnt + 1
            End If

            '''' 条件：チェック数判定
            '''' ケース：チェック数が０の場合、エラーメッセージを表示して処理を中断する
            '''' 　メッセージ：ID：MSG_0493
            '''' 　　１つもチェックされていません。。
            If intCheckedCnt = 0 Then
                MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0493"), Me.Text)
                Exit Function
            End If

            '''' 条件：作成読込判定
            '''' ケース：読込処理の場合、以下の処理を行う
            If intInOutCd = CD_BTN_INPUT Then
                '''' 　条件：チェック数判定
                '''' 　ケース：チェック数が２件以上の場合、エラーメッセージを表示して処理を中断する
                '''' 　　メッセージ：ID：MSG_0494
                '''' 　　　読込処理は１つのみです。
                If intCheckedCnt > 1 Then
                    MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0494"), Me.Text)
                    Exit Function
                End If

                '''' 　条件：読込用エリアが有効無効判定
                '''' 　ケース：有効の場合、ファイル存在チェック
                '不要なロジックを削除 str
                '                If gbSystem.Enabled = True Then
                '不要なロジックを削除 end
                '''' 　　条件：ファイル名チェック
                '''' 　　ケース：ファイルが指定されていない場合、エラーメッセージを表示して処理を中断する
                '''' 　　　メッセージ：ID：MSG_0081
                '''' 　　　　正しいファイルを指定してください。
                If strRefFilePath = String.Empty Then
                    MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0081"), Me.Text)
                    Exit Function
                End If

                '''' 　　条件：ファイル名がBKファイルかどうか判定
                '''' 　　ケース：BKファイルをの場合、エラーメッセージを表示して処理を中断する
                '''' 　　　メッセージ：ID：MSG_0275
                '''' 　　　　BACK UPファイルは指定できません。
                If IsBKFile(Path.GetFileName(strRefFilePath)) = True Then
                    MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0275"), Me.Text)
                    Exit Function
                End If
                '不要なロジックを削除 str
                '            End If
                '不要なロジックを削除 end
            End If

            CheckFormInputData = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "CheckFormInputData")

        End Try

    End Function

    ''' <summary>
    ''' 別紙B出力対象CD取得
    ''' </summary>
    ''' <returns>別紙B出力対象CD</returns>
    ''' <remarks></remarks>
    Private Function IsEnableAttachedSheetBtn() As Integer

        Dim blnRet As Boolean
        Dim strMsg As String = ""
        Dim wc As New WebDb.WebDbCommon
        Dim dt As New M_CONTRACT_BASETable

        IsEnableAttachedSheetBtn = False

        Try
            '''' 処理：認証設定
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW

            '''' 処理：契約基本情報取得(WebDb.WebDbCommon.GetContractBaseData)
            '''' 条件：処理結果判定
            '''' ケース：処理結果が異常の場合、処理を中断する
            blnRet = wc.GetContractBaseData(CommonVariable.CPNO, dt, strMsg)
            If blnRet = False Then
                Throw New Exception(strMsg)
                Exit Function
            End If

            '''' 条件：契約基本情報データ件数判定
            '''' ケース：件数が１件以上ある場合、別紙B出力対象CDを返す
            If dt.Rows.Count > 0 Then
                'Req.1612：別紙Bの自動分割 2018/03 Str
                Select Case Mid(dt.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_CONTRACT_PATERN).ToString, 2, 1)
                    'Select Case dt.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_CONTRACT_PATERN).ToString
                    Case "1"
                        'Case "01"
                        'Req.1612：別紙Bの自動分割 2018/03 Str
                        Return 1
                        'Req.1612：別紙Bの自動分割 2018/03 Str
                        'Case "02"
                    Case "2"
                        'Req.1612：別紙Bの自動分割 2018/03 End
                        Return 2
                    Case Else
                        Return 0
                End Select
            Else
                Return 0
            End If

        Catch ex As Exception
            Throw ex
        End Try

    End Function

    ''' <summary>
    ''' Paymentファイル初期表示
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub DispPSDetailTextBox()

        Dim ofm As New OioFileManage
        Dim PSPath As String
        PSPath = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, _
                                            CommonVariable.CONTRACTNO) & _
                    ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, _
                                                    CommonVariable.CONTRACTNO)
        '''' 処理：ファイルが存在する場合のみ表示
        If File.Exists(PSPath) = True Then
            Me.txb_InputFile.Text = PSPath
        Else
            Me.txb_InputFile.Text = ""
        End If
    End Sub

    ''' <summary>
    ''' 待ちフォームプログレスバーメモリ表示
    ''' </summary>
    ''' <param name="intCnt">処理件数</param>
    ''' <param name="intMax">最大処理数</param>
    ''' <param name="strMsg">表示メッセージ</param>
    ''' <param name="frm">待ちフォーム</param>
    ''' <remarks></remarks>
    Private Sub ProgressBarCount(ByVal intCnt As Integer, ByVal intMax As Integer, ByVal strMsg As String, ByRef frm As Frm_WaitDialog)

        '''' 処理：メッセージ表示
        frm.lbl_Message.Text = strMsg
        '''' 処理：プログレスバーのメモリ設定（100／全体処理件数×処理中件数）
        frm.ProgressValue = Math.Floor(100 / intMax * intCnt)
        frm.Update()

    End Sub

    ''' <summary>
    ''' Payment分割対象判定
    ''' </summary>
    ''' <param name="CPNO">CPNO</param>
    ''' <remarks></remarks>
    Private Function isSplit(ByVal CPNO) As Boolean
        Dim mdc As New MasterMdbControl
        Dim dbCon As OleDbConnection
        Dim odc As New OleDbCode
        Dim dbTable As DataTable
        Dim ii As Integer

        '認証設定
        dbCon = mdc.GetOleDBConnection(CommonVariable.MdbPW)

        'CODEテーブル取得
        dbTable = odc.SelectDataTable(dbCon, "PsSplit")

        '取得内容チェック
        If dbTable.Rows.Count = 0 Then
            isSplit = False     '分割不可
        Else
            Dim filterSel As New StringBuilder

            '当該CPNO検索
            filterSel.Append("ItemValue")
            filterSel.Append(CommonConstant.SQL_STR_EQUAL)
            filterSel.Append(StringEdit.EncloseSingleQuotation(CPNO))

            If dbTable.Select(filterSel.ToString).Length = 0 Then
                isSplit = False     '分割不可
            Else
                isSplit = True      '分割可
            End If
        End If

        dbCon.Close()

    End Function

    ''' <summary>
    ''' Payment分割対象判定
    ''' </summary>
    ''' <param name="CPNO">CPNO</param>
    ''' <remarks></remarks>
    Private Function PsSplit() As Boolean

    End Function

    ''' <summary>
    ''' 取込対象ファイルのフォーマットチェック
    ''' </summary>
    ''' <remarks></remarks>
    Private Function InputFileFormatCheck() As Boolean

        InputFileFormatCheck = False

        Const EXCEL_MAX_ROW As Integer = 1048576

        'シート名定義
        Const cPayment As String = "Payment"
        Const cDetail As String = "詳細"
        Const cSankou As String = "参考シート"
        'Req:1484 Rewrite対応 str
        '        Const cComponent As String = "component"
        Const cComp_Prices As String = "Comp_Prices"
        'Req:1484 Rewrite対応 end
        Const cSummary As String = "Summary"
        Const cIgf01 As String = "依頼後"
        Const cSlink01 As String = "取得結果(基本情報)"
        Const cSlink02 As String = "取得結果(Pricing)"
        Const cCiscoMA As String = "貼付シート"
        Const cELA01 As String = "データ"
        Const cWS1 As String = "WS1"

        Dim Flag1 As Boolean
        Dim Flag2 As Boolean
        Dim ii As Integer
        Dim wStr1 As String

        ''Excelオブジェクト
        Dim xlApp As New Excel.Application
        Dim xlBook As Excel.Workbook
        Dim xlSheet As Excel.Worksheet

        ''Excelオブジェクトの設定
        xlApp.EnableEvents = False
        xlApp.DisplayAlerts = False

        Try
            If cbCost.Checked = True Then
                '=== COST開示ファイルチェック =================================

                Dim eNkk As New ExcelNewKakakukaiji
                Dim costFileNMArray() As String
                Dim costFileNM As String
                Dim PatternCD As String

                '対象ファイル名群取得
                costFileNMArray = GetCostFileArray(Me.txtRefInputFile.Text)
                'START 変更管理#40（既存バグ修正)　2017/04 sugo
                If costFileNMArray Is Nothing Then
                    InputFileFormatCheck = True
                    Exit Function
                End If
                'END   変更管理#40（既存バグ修正)　2017/04 sugo

                'ファイル毎処理
                For Each costFileNM In costFileNMArray
                    'ファイルOPEN時VBA内部で使用するため、各ファイルを呼び出す前にPaymentシートが存在するかを確認する()
                    'シート存在チェック
                    xlBook = xlApp.Workbooks.Open(costFileNM)
                    Flag1 = False
                    For Each xlSheet In xlBook.Worksheets
                        If xlSheet.Name = cPayment Then
                            Flag1 = True
                            Exit For
                        End If
                    Next
                    If Flag1 = False Then
                        Exit Function
                    End If

                    'パターンコード取得
                    PatternCD = eNkk.GetFileType(costFileNM)

                    Select Case PatternCD
                        Case "Topacs"
                            'シート存在チェック
                            Flag1 = False
                            For Each xlSheet In xlBook.Worksheets
                                If xlSheet.Name = cSummary Then
                                    Flag1 = True
                                    Exit For
                                End If
                            Next
                            If Flag1 = False Then
                                Exit Function
                            End If

                            '詳細フォーマットチェック
                            'タイトル部文言チェック
                            If CheckTitleArea(xlSheet, "B", 8, "B", 8) = False Then
                                Exit Function
                            End If
                            If CheckTitleArea(xlSheet, "D", 8, "D", 8) = False Then
                                Exit Function
                            End If
                            If CheckTitleArea(xlSheet, "F", 8, "N", 9) = False Then
                                Exit Function
                            End If
                            If CheckTitleArea(xlSheet, "P", 8, "S", 9) = False Then
                                Exit Function
                            End If

                        Case "e-Pricer"
                            'シート存在チェック
                            Flag1 = False
                            For Each xlSheet In xlBook.Worksheets
                                'Req:1484 Rewrite対応 str
                                'If xlSheet.Name = cComponent Then
                                If xlSheet.Name = cComp_Prices Then
                                    'Req:1484 Rewrite対応 end
                                    Flag1 = True
                                    Exit For
                                End If
                            Next
                            If Flag1 = False Then
                                Exit Function
                            End If

                            '詳細フォーマットチェック
                            'タイトル部文言チェック
                            'Req:1484 Rewrite対応 str
                            'If CheckTitleArea(xlSheet, "A", 2, "HT", 2) = False Then
                            If CheckTitleArea(xlSheet, "A", 2, "J", 2) = False Then
                                'Req:1484 Rewrite対応 end
                                Exit Function
                            End If

                        Case "4"
                            'CISCO HW
                            'シート存在チェック
                            Flag1 = False
                            For Each xlSheet In xlBook.Worksheets
                                If xlSheet.Name = cDetail Then
                                    Flag1 = True
                                    Exit For
                                End If
                            Next
                            If Flag1 = False Then
                                Exit Function
                            End If

                            '詳細フォーマットチェック
                            'タイトル部文言チェック
                            If CheckTitleArea(xlSheet, "A", 2, "Q", 5) = False Then
                                Exit Function
                            End If

                            'Paymentフォーマットチェック
                            For Each xlSheet In xlBook.Worksheets
                                If xlSheet.Name = cPayment Then
                                    Exit For
                                End If
                            Next
                            'タイトル部文言チェック
                            If CheckTitleArea(xlSheet, "A", 3, "V", 5) = False Then
                                Exit Function
                            End If

                        Case "15"
                            'AAS HWMA
                            'シート存在チェック
                            Flag1 = False
                            For Each xlSheet In xlBook.Worksheets
                                If xlSheet.Name = cSankou Then
                                    Flag1 = True
                                    Exit For
                                End If
                            Next
                            If Flag1 = False Then
                                Exit Function
                            End If

                            '詳細フォーマットチェック
                            'タイトル部文言チェック
                            If CheckTitleArea(xlSheet, "A", 4, "AB", 5) = False Then
                                Exit Function
                            End If

                        Case "12", "32", "34", "39", "40", "41"
                            'シート存在チェック
                            Flag1 = False
                            For Each xlSheet In xlBook.Worksheets
                                If xlSheet.Name = cPayment Then
                                    Flag1 = True
                                    Exit For
                                End If
                            Next
                            If Flag1 = False Then
                                Exit Function
                            End If

                            '詳細フォーマットチェック
                            'タイトル部文言チェック
                            If CheckTitleArea(xlSheet, "A", 4, "AC", 5) = False Then
                                Exit Function
                            End If

                        Case "13", "14", "17", "18", "19", "43", "44", "SI"
                            'シート存在チェック
                            Flag1 = False
                            For Each xlSheet In xlBook.Worksheets
                                If xlSheet.Name = cPayment Then
                                    Flag1 = True
                                    Exit For
                                End If
                            Next
                            If Flag1 = False Then
                                Exit Function
                            End If

                            '詳細フォーマットチェック
                            'タイトル部文言チェック
                            If CheckTitleArea(xlSheet, "A", 4, "AC", 5) = False Then
                                Exit Function
                            End If

                        Case "31"
                            '中古HW
                            'シート存在チェック
                            Flag1 = False
                            For Each xlSheet In xlBook.Worksheets
                                If xlSheet.Name = cDetail Then
                                    Flag1 = True
                                    Exit For
                                End If
                            Next
                            If Flag1 = False Then
                                Exit Function
                            End If

                            '詳細フォーマットチェック
                            'タイトル部文言チェック
                            If CheckTitleArea(xlSheet, "A", 5, "R", 6) = False Then
                                Exit Function
                            End If
                    End Select
                Next

            ElseIf cbTopacs.Checked = True Then
                '=== Topacs申請ファイルチェック ===============================

                'シート存在チェック
                xlBook = xlApp.Workbooks.Open(Me.txtRefInputFile.Text)
                Flag1 = False
                For Each xlSheet In xlBook.Worksheets
                    If xlSheet.Name = cPayment Then
                        Flag1 = True
                        Exit For
                    End If
                Next
                If Flag1 = False Then
                    Exit Function
                End If

            ElseIf cbIgf.Checked = True Then
                '=== IGF集計ファイルチェック ==================================

                'シート存在チェック
                xlBook = xlApp.Workbooks.Open(Me.txtRefInputFile.Text)
                Flag1 = False
                For Each xlSheet In xlBook.Worksheets
                    If xlSheet.Name = cWS1 Then
                        Flag1 = True
                        Exit For
                    End If
                Next
                If Flag1 = False Then
                    Exit Function
                End If

                Flag1 = False
                For Each xlSheet In xlBook.Worksheets
                    If xlSheet.Name = cIgf01 Then
                        Flag1 = True
                        Exit For
                    End If
                Next
                If Flag1 = False Then
                    Exit Function
                End If

                '詳細フォーマットチェック
                '月額部
                ' Payment保有年数取得
                Dim dummyCpno, rtnMsg As String
                Dim dummyExcelStrYear As Integer
                Dim wPayPeriod As Integer
                rtnMsg = GetWS1PayPeriod(Me.txtRefInputFile.Text, dummyCpno, dummyExcelStrYear, wPayPeriod)

                'タイトル部文言チェック
                If CheckTitleArea(xlSheet, "A", 8, ExcelWrite.chgExcelColumnIdxToChar(100 + wPayPeriod * 12), 9) = False Then
                    Exit Function
                End If

            ElseIf cbSlink.Checked = True Then
                '=== S-Link情報ファイルチェック ===============================

                'シート存在チェック
                xlBook = xlApp.Workbooks.Open(Me.txtRefInputFile.Text)
                Flag1 = False
                Flag2 = False
                For Each xlSheet In xlBook.Worksheets
                    If xlSheet.Name = cSlink01 Then
                        Flag1 = True
                    End If
                    If xlSheet.Name = cSlink02 Then
                        Flag2 = True
                    End If
                Next
                If Flag1 = False Or Flag2 = False Then
                    Exit Function
                End If

                '詳細フォーマットチェック
                ' 取得結果(基本情報)ｼｰﾄ
                xlSheet = xlBook.Worksheets(cSlink01)
                'タイトル部文言チェック
                If CheckTitleArea(xlSheet, "A", 1, "Q", 1) = False Then
                    Exit Function
                End If
                'データ部チェック
                For i As Integer = 2 To EXCEL_MAX_ROW
                    If Trim(xlSheet.Range("A" & i).Value) = "" Then
                        'データ行終了
                        Exit For
                    End If

                    '年月部
                    If (Not IsDate(xlSheet.Range("K" & i).Value)) And _
                       (Trim(xlSheet.Range("K" & i).Value) <> "") Then
                        Exit Function
                    End If
                    If (Not IsDate(xlSheet.Range("L" & i).Value)) And _
                       (Trim(xlSheet.Range("L" & i).Value) <> "") Then
                        Exit Function
                    End If
                    '数値部
                    If (Not IsNumeric(xlSheet.Range("M" & i).Value)) And _
                       (Trim(xlSheet.Range("M" & i).Value) <> "") Then
                        Exit Function
                    End If
                    If (Not IsNumeric(xlSheet.Range("N" & i).Value)) And _
                       (Trim(xlSheet.Range("N" & i).Value) <> "") Then
                        Exit Function
                    End If
                Next

                ' 取得結果(Pricing)ｼｰﾄ
                xlSheet = xlBook.Worksheets(cSlink02)
                'タイトル部文言チェック
                If CheckTitleArea(xlSheet, "A", 1, "J", 1) = False Then
                    Exit Function
                End If
                'データ部チェック
                For i As Integer = 2 To EXCEL_MAX_ROW
                    If Trim(xlSheet.Range("A" & i).Value) = "" Then
                        'データ行終了
                        Exit For
                    End If

                    '年月部
                    If (Not IsDate(xlSheet.Range("D" & i).Value)) And _
                       (Trim(xlSheet.Range("D" & i).Value) <> "") Then
                        Exit Function
                    End If
                    If (Not IsDate(xlSheet.Range("E" & i).Value)) And _
                       (Trim(xlSheet.Range("E" & i).Value) <> "") Then
                        Exit Function
                    End If
                    'BillingAmount
                    If (Not IsNumeric(xlSheet.Range("F" & i).Value)) And _
                       (Trim(xlSheet.Range("F" & i).Value) <> "") Then
                        Exit Function
                    End If
                Next

            ElseIf cbElaFile.Checked = True Then
                '=== ELAファイルチェック ======================================

                'シート存在チェック
                xlBook = xlApp.Workbooks.Open(Me.txtRefInputFile.Text)
                Flag1 = False
                For Each xlSheet In xlBook.Worksheets
                    If xlSheet.Name = cELA01 Then
                        Flag1 = True
                        Exit For
                    End If
                Next
                If Flag1 = False Then
                    Exit Function
                End If

                '詳細フォーマットチェック
                'タイトル部文言チェック
                If CheckTitleArea(xlSheet, "A", 2, "IS", 3) = False Then
                    Exit Function
                End If

                'データ部チェック
                For i As Integer = 4 To EXCEL_MAX_ROW
                    If Trim(xlSheet.Range("A" & i).Value) = "" And _
                        Trim(xlSheet.Range("D" & i).Value) = "" And _
                        Trim(xlSheet.Range("E" & i).Value) = "" And _
                        Trim(xlSheet.Range("F" & i).Value) = "" And _
                        Trim(xlSheet.Range("G" & i).Value) = "" And _
                        Trim(xlSheet.Range("H" & i).Value) = "" And _
                        Trim(xlSheet.Range("I" & i).Value) = "" And _
                        Trim(xlSheet.Range("J" & i).Value) = "" Then
                        'データ行終了
                        Exit For
                    End If

                    Select Case Trim(xlSheet.Range("A" & i).Value)
                        Case "MLC", "ALC", "OTC"
                        Case Else
                            Exit Function
                    End Select
                    '年月部
                    If (Not IsDate(xlSheet.Range("D" & i).Value)) And _
                       (Trim(xlSheet.Range("D" & i).Value) <> "") Then
                        Exit Function
                    End If
                    If (Not IsDate(xlSheet.Range("E" & i).Value)) And _
                       (Trim(xlSheet.Range("E" & i).Value) <> "") Then
                        Exit Function
                    End If
                    If (Not IsDate(xlSheet.Range("F" & i).Value)) And _
                       (Trim(xlSheet.Range("F" & i).Value) <> "") Then
                        Exit Function
                    End If
                    If (Not IsDate(xlSheet.Range("G" & i).Value)) And _
                       (Trim(xlSheet.Range("G" & i).Value) <> "") Then
                        Exit Function
                    End If
                    If (Not IsDate(xlSheet.Range("H" & i).Value)) And _
                       (Trim(xlSheet.Range("H" & i).Value) <> "") Then
                        Exit Function
                    End If
                    '展開方法
                    Select Case Trim(xlSheet.Range("I" & i).Value)
                        Case "", "変則"
                        Case Else
                            Exit Function
                    End Select
                    '支払方法
                    Select Case Trim(xlSheet.Range("J" & i).Value)
                        Case "一括", "月額", "年額", "変則"
                        Case Else
                            Exit Function
                    End Select
                    '金額部
                    For ii = 11 To 253
                        wStr1 = xlSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ii) & i).Value
                        If Trim(wStr1) <> "" Then
                            If Not IsNumeric(wStr1) Then
                                Exit Function
                            End If
                        End If
                    Next
                Next

            ElseIf cbEpricer.Checked = True Then
                '=== e-Pricer申請ファイルチェック =============================

                'シート存在チェック
                xlBook = xlApp.Workbooks.Open(Me.txtRefInputFile.Text)
                Flag1 = False
                For Each xlSheet In xlBook.Worksheets
                    If xlSheet.Name = cPayment Then
                        Flag1 = True
                        Exit For
                    End If
                Next
                If Flag1 = False Then
                    Exit Function
                End If

                '詳細フォーマットチェック
                'タイトル部文言チェック
                If CheckTitleArea(xlSheet, "A", 4, "AL", 5) = False Then
                    Exit Function
                End If
            End If

            'チェック結果：正常
            InputFileFormatCheck = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "InputFileFormatCheck")

        Finally
            'エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBook) = False Then
                xlBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try

    End Function

    ''' <summary>
    ''' タイトルエリアチェック
    ''' </summary>
    ''' <param name="xlSheet">チェックする対象シート</param>
    ''' <param name="StartCol">開始カラム位置</param>
    ''' <param name="StartRow">開始行位置</param>
    ''' <param name="EndCol">終了カラム位置</param>
    ''' <param name="EndRow">終了行位置</param>
    ''' <remarks></remarks>
    Private Function CheckTitleArea(ByRef xlSheet As Excel.Worksheet, _
                                    ByVal StartCol As String, _
                                    ByVal StartRow As Integer, _
                                    ByVal EndCol As String, _
                                    ByVal EndRow As Integer) As Boolean
        Dim hh As Integer
        Dim ii As Integer
        Dim wStartCol As Integer
        Dim wEndCol As Integer
        Dim wStr1 As String
        Dim Flg1 As Boolean

        CheckTitleArea = False

        'カラム位置を列数に変換
        wStartCol = ExcelWrite.GetColumnNoFromColumnName(StartCol)
        wEndCol = ExcelWrite.GetColumnNoFromColumnName(EndCol)

        '範囲内検索
        For ii = wStartCol To wEndCol       '列ループ
            Flg1 = False
            For hh = StartRow To EndRow     '行ループ
                wStr1 = xlSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ii) & hh).Value
                'タイトル部にデータが入力されている
                If Trim(wStr1) <> "" Then
                    Flg1 = True
                End If
            Next
            If Flg1 = False Then
                'タイトル部に未入力列がある→エラー
                Exit Function
            End If
        Next

        '範囲外の次の列が空白か確認する
        Flg1 = False
        For hh = StartRow To EndRow     '行ループ
            wStr1 = xlSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(wEndCol + 1) & hh).Value
            'データが入力されている
            If Trim(wStr1) <> "" Then
                Flg1 = True
            End If
        Next
        If Flg1 = True Then
            'タイトル部外に入力列がある→エラー
            Exit Function
        End If

        'チェック正常
        CheckTitleArea = True
    End Function

    '※ExcelWriteにある同関数を再定義：終わるまでマクロを活性化させないVer
    Private Function GetWS1PayPeriod(ByVal PSPath As String,
                                     ByRef cpNo As String,
                                     ByRef excelStrYear As Integer,
                                     ByRef payPeriod As Integer) As String
        '初期化
        GetWS1PayPeriod = ""
        cpNo = ""
        excelStrYear = 0
        payPeriod = 0

        '定数
        Const MSG_001 As String = "数値に変換できない値が入力されています。「Payment出力開始」を確認して下さい。"
        Const MSG_002 As String = "数値に変換できない値が入力されています。「Payment出力終了」を確認して下さい。"
        Const MSG_003 As String = "「Payment出力開始」未満の「Payment出力終了」が入力されています。"
        Const CELL_CPNO As String = "B7"
        Const CELL_EXCELSTARTYEAR As String = "H7"
        Const CELL_EXCELENDYEAR As String = "I7"

        Dim tmpCpno As String
        Dim tmpStrYear, tmpEndYear, tmpPayPeriod As Integer
        Dim xlApp As New Excel.Application
        Dim xlPSBook As Excel.Workbook
        Dim xlWS1Sheet As Excel.Worksheet
        Dim xlCell As Excel.Range
        Try
            'WS1シートの日付を取得
            xlApp.EnableEvents = False
            xlApp.DisplayAlerts = False
            xlPSBook = xlApp.Workbooks.Open(PSPath)
            xlWS1Sheet = xlPSBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_WS1)
            'Payment開始年月
            xlCell = xlWS1Sheet.Range(CELL_EXCELSTARTYEAR)
            tmpStrYear = xlCell.Value
            If IsNumeric(tmpStrYear) = False Then
                GetWS1PayPeriod = FileReader.GetMessage("MSG_0485") & vbCrLf & MSG_001
                Exit Function
            End If

            'Payment終了年月
            xlCell = xlWS1Sheet.Range(CELL_EXCELENDYEAR)
            tmpEndYear = xlCell.Value
            If IsNumeric(tmpEndYear) = False Then
                GetWS1PayPeriod = FileReader.GetMessage("MSG_0485") & vbCrLf & MSG_002
                Exit Function
            End If

            '保有年月
            tmpPayPeriod = tmpEndYear - tmpStrYear
            If tmpPayPeriod < 0 Then
                GetWS1PayPeriod = FileReader.GetMessage("MSG_0485") & vbCrLf & MSG_003
                Exit Function
            End If

            'CPNO
            xlCell = xlWS1Sheet.Range(CELL_CPNO)
            tmpCpno = CStr(xlCell.Value)

            '戻り値
            cpNo = tmpCpno
            excelStrYear = tmpStrYear
            payPeriod = tmpPayPeriod + 1

        Catch ex As Exception
            GetWS1PayPeriod = FileReader.GetMessage("MSG_0485") & vbCrLf & ex.Message

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlWS1Sheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlPSBook) = False Then
                xlPSBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try
    End Function

#End Region

End Class