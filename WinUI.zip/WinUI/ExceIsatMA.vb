﻿Imports Microsoft.Office.Interop
Imports System.IO
Imports System.Text
Imports System.Data.OleDb
Imports MUSE.Controller
Imports MUSE.DataAccess.OleDb
Imports MUSE.Utility
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.OioBamaCommmon
Imports MUSE.Utility.UserMessageBox
Imports MUSE.Utility.UserDataTable.Master
Imports MUSE.Utility.UserDataTable.Transaction

Public Class ExceIsatMA

#Region "定数"

    '==============================
    'EXCEL行位置
    '==============================
    'EXCELの最終行
    Private Const EXCEL_MAX_ROW As Integer = 1048576
    Private Const CD_MESFLG_NON As Integer = 0
    Private Const CD_MESFLG_NO As Integer = 1
    Private Const CD_MESFLG_ON As Integer = 2

#End Region

#Region "構造体"
    Private Structure DetailData
        Dim FileName As String
        Dim SUFFIX As String
        Dim INTR As String
        Dim CONTRACT As String
    End Structure
#End Region

#Region "インナークラス"

    Private Class CiscoMATable
        Inherits DataTable

        Public Sub New()
            Me.TableName = "CiscoMATable"

            Me.Columns.Add("Cell_ROWID", Type.GetType("System.String"))         '行ID
            Me.Columns.Add("Cell_COUNT", Type.GetType("System.String"))         '明細件数
            Me.Columns.Add("Cell_FLAG", Type.GetType("System.String"))          '処理済区分(-1:検索対象外、0:、1:、2:)
            '対応PSシート情報
            Me.Columns.Add("Cell_PSROW", Type.GetType("System.String"))         'PSシート対応行番号
            Me.Columns.Add("Cell_LINENO", Type.GetType("System.String"))        'PSシート対応LINENO番号
            Me.Columns.Add("Cell_FileName", Type.GetType("System.String"))      'PSシート対応ファイル名
            Me.Columns.Add("Cell_SUFFIX", Type.GetType("System.String"))        'PSシート対応ファイル名SUFFIX
            Me.Columns.Add("Cell_INTR", Type.GetType("System.String"))          'PSシート対応ファイル名SUFFIX_INTR
            Me.Columns.Add("Cell_CONTRACT", Type.GetType("System.String"))      'PSシート対応契約順番
            '対応CISCOシート情報
            Me.Columns.Add("Cell_CiscoRowStart", Type.GetType("System.String")) 'Cisocoシート対応開始行
            Me.Columns.Add("Cell_CiscoRowEnd", Type.GetType("System.String"))   'Cisocoシート対応終了行
            Me.Columns.Add("Cell_QTY", Type.GetType("System.String"))           '数量合計
            'CISCO情報
            Me.Columns.Add("Cell_HOSYU_KATABAN", Type.GetType("System.String")) '保守型番
            Me.Columns.Add("Cell_HOSYU_SERIAL", Type.GetType("System.String"))  '保守シリアル
            Me.Columns.Add("Cell_ServiceKIND", Type.GetType("System.String"))   'サービス種類
            Me.Columns.Add("Cell_ListPrice", Type.GetType("System.String"))     'ListPrice
            Me.Columns.Add("Cell_PayMethod", Type.GetType("System.String"))     '支払方法
            Me.Columns.Add("Cell_GroupNo", Type.GetType("System.String"))       '全ISATデータの紐付くNO
            Me.Columns.Add("Cell_MesFlg", Type.GetType("System.String"))        'MES_FLG
            '明細情報
            Me.Columns.Add("Cell_Machine01", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count01", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine02", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count02", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine03", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count03", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine04", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count04", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine05", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count05", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine06", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count06", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine07", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count07", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine08", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count08", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine09", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count09", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine10", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count10", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine11", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count11", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine12", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count12", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine13", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count13", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine14", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count14", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine15", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count15", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine16", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count16", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine17", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count17", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine18", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count18", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine19", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count19", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine20", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count20", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine21", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count21", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine22", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count22", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine23", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count23", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine24", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count24", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine25", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count25", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine26", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count26", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine27", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count27", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine28", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count28", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine29", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count29", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine30", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count30", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine31", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count31", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine32", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count32", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine33", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count33", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine34", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count34", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine35", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count35", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine36", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count36", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine37", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count37", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine38", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count38", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine39", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count39", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine40", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count40", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine41", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count41", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine42", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count42", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine43", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count43", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine44", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count44", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine45", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count45", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine46", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count46", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine47", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count47", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine48", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count48", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine49", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count49", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine50", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count50", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine51", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count51", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine52", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count52", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine53", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count53", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine54", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count54", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine55", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count55", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine56", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count56", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine57", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count57", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine58", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count58", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine59", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count59", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine60", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count60", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine61", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count61", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine62", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count62", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine63", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count63", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine64", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count64", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine65", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count65", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine66", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count66", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine67", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count67", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine68", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count68", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine69", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count69", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine70", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count70", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine71", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count71", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine72", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count72", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine73", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count73", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine74", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count74", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine75", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count75", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine76", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count76", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine77", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count77", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine78", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count78", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine79", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count79", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine80", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count80", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine81", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count81", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine82", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count82", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine83", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count83", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine84", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count84", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine85", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count85", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine86", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count86", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine87", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count87", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine88", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count88", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine89", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count89", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine90", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count90", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine91", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count91", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine92", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count92", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine93", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count93", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine94", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count94", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine95", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count95", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine96", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count96", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine97", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count97", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine98", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count98", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine99", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count99", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Machine100", Type.GetType("System.String"))
            Me.Columns.Add("Cell_Count100", Type.GetType("System.String"))
        End Sub
    End Class

    Private Class PSDataTable
        Inherits DataTable

        Public Sub New()

            Me.TableName = "PSDataTable"

            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT, Type.GetType("System.String"))
            'START 変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD, Type.GetType("System.String"))
            'END   変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD, Type.GetType("System.String"))
            ''以下、Excel行
            Me.Columns.Add("ExcelRow", Type.GetType("System.Int32"))
            '反映FLG 0:未反映　1:反映
            Me.Columns.Add("ReflectionFlg", Type.GetType("System.String"))
        End Sub

    End Class

    ''個別詳細.Xlsの値を格納
    Private Class DetailDataTable
        Inherits DataTable

        Public Sub New()

            Me.TableName = "DetailDataTable"

            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.UPDATE_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.LOCK_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.VALID_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.SEQ, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.IDENTITY_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.PROD_NO, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.PROD_NAME, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.WD_ANNT_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.WD_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.PRICE_CHG_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.MES_CATEGORY, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.MES_GROUP, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.SPECIAL_FEATURE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.QTY_INTEGER, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.LIST_PRICE_PROPOSAL, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.LIST_PRICE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.LIST_PRICE_TOTAL_PROPOSAL, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.LIST_PRICE_TOTAL, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.COST_RATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.COST, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.COST_TOTAL, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.COST_INPUT_DATE, Type.GetType("System.String"))
            Me.Columns.Add("ExcelRow", Type.GetType("System.Int32"))
        End Sub

    End Class

    Private Class LogListData
        Inherits DataTable

        Public Sub New()

            Me.TableName = "LogListData"

            Me.Columns.Add("LINE_NO", Type.GetType("System.String"))
            Me.Columns.Add("FILE_NAME", Type.GetType("System.String"))
            Me.Columns.Add("TYPE", Type.GetType("System.String"))
            Me.Columns.Add("MODEL", Type.GetType("System.String"))
            Me.Columns.Add("SERIAL", Type.GetType("System.String"))
            Me.Columns.Add("ListPrice", Type.GetType("System.String"))
            Me.Columns.Add("ROW_CNT", Type.GetType("System.Int32"))
            Me.Columns.Add("GroupNo", Type.GetType("System.Int32"))
            Me.Columns.Add("OUTPUT_FLG", Type.GetType("System.String"))
        End Sub

    End Class

#End Region

#Region "ISAT見積反映処理"
    ''' <summary>
    ''' 機能：連携ファイル管理画面からISAT見積データをPaymentに反映する
    ''' </summary>
    ''' <param name="strPsFileName"></param>
    ''' <param name="strIsatMaFileNames"></param>
    ''' <param name="intOutputCnt"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function IsatMaReflection(ByVal strPsFileName As String,
                                     ByVal strIsatMaFileNames() As String,
                                     ByRef intOutputCnt As Integer) As Integer

        Dim CiscoNewTable As New CiscoMATable
        Dim isatData As New IsatTable
        Dim blnRet As Boolean
        Dim ew As New ExcelWrite
        Dim xlApp As Excel.Application
        Dim xlBooks As Excel.Workbooks = Nothing
        Dim xlBook As Excel.Workbook = Nothing
        Dim xlSheets As Excel.Sheets = Nothing
        Dim xlSheetPs As Excel.Worksheet = Nothing
        '1680 str CISCO MA(新規)を対象外にする
        'Dim xlSheetPsd As Excel.Worksheet = Nothing
        '1680 end CISCO MA(新規)を対象外にする
        Dim intSortKey1Col As Integer
        Dim intSortKey2Col As Integer

        IsatMaReflection = -1

        Try
            '-------------------------------------
            'ISATﾌｧｲﾙ読込
            '-------------------------------------
            blnRet = GetIsatExcel(strIsatMaFileNames, isatData, CiscoNewTable)
            If blnRet = False Then
                Call ProcEnd()
                Exit Function
            End If

            '-------------------------------------
            'Excelオブジェクトの設定
            '-------------------------------------
            xlApp = New Excel.Application
            xlApp.EnableEvents = False
            xlApp.DisplayAlerts = False
            xlBooks = xlApp.Workbooks

            '-------------------------------------
            'PaymentSheetのデータを取得
            '-------------------------------------
            Dim PSTable As PSDataTable
            xlBook = xlBooks.Open(strPsFileName)
            xlSheets = xlBook.Worksheets
            xlSheetPs = xlSheets.Item(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)
            PSTable = GetPSDataTable(xlSheetPs)

            'Excelのオートフィルタを初期化
            Call ew.CrearAutoFilter(xlSheetPs)

            '-------------------------------------
            'ソート用初期値セット
            '-------------------------------------
            blnRet = SetSortIni(xlSheetPs, intSortKey1Col, intSortKey2Col)
            If blnRet = False Then
                Exit Function
            End If

            intOutputCnt = 0
            '-------------------------------------
            'CISCOMA(新規)以外反映
            '-------------------------------------
            blnRet = IsatMAReflectionNew(xlSheetPs, isatData, PSTable, intOutputCnt, intSortKey2Col)
            If blnRet = False Then
                Exit Function
            End If

            '1680 str CISCO MA(新規)を対象外にする
            ''-------------------------------------
            ''CISCOMA(新規)　
            ''-------------------------------------
            'If CiscoNewTable.Rows.Count > 0 Then
            '    xlSheetPsd = xlBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)
            '    blnRet = CiscoMAReflection(xlSheetPs, xlSheetPsd, intOutputCnt, PSTable, CiscoNewTable, intSortKey2Col)
            '    If blnRet = False Then
            '        Exit Function
            '    End If
            'End If

            'ExcelObjRelease.ReleaseExcelObj(xlSheetPsd, ExcelObjRelease.OBJECT_NOTHING)
            '1680 end CISCO MA(新規)を対象外にする

            '-------------------------------------
            'ソート用処理
            '-------------------------------------
            blnRet = PaymentSort(xlSheetPs, intSortKey1Col, intSortKey2Col)
            If blnRet = False Then
                Exit Function
            End If
            ExcelObjRelease.ReleaseExcelObj(xlSheetPs, ExcelObjRelease.OBJECT_NOTHING)

            'Bookの保存(別名保存のマクロをキックする)
            Call ExcelWrite.KickVBABookSave(xlApp, xlBook, ExcelWrite.VBActNMList.CISCOMA取込, CommonVariable.USERID, CommonVariable.USERPW)

            '取込ﾌｧｲﾙにBK_を付与
            Call RenameInputFile(strIsatMaFileNames)

            '-------------------------------------
            'List出力
            '-------------------------------------
            Call OutputList(isatData, CiscoNewTable, xlBooks)

            IsatMaReflection = intOutputCnt

        Catch ex As Exception
            Throw ex

        Finally
            'PaymentSheet.Xls
            '1680 str CISCO MA(新規)を対象外にする
            'ExcelObjRelease.ReleaseExcelObj(xlSheetPsd, ExcelObjRelease.OBJECT_NOTHING)
            '1680 end CISCO MA(新規)を対象外にする
            ExcelObjRelease.ReleaseExcelObj(xlSheetPs, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBook) = False Then
                xlBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlBooks, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlApp) = False Then
                xlApp.DisplayAlerts = True
                xlApp.EnableEvents = True
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

        End Try

    End Function

#End Region

#Region "プライベートメソッド"

#Region "共通"
    ''' <summary>
    ''' 機能：ISATﾌｧｲﾙ読込
    ''' </summary>
    ''' <param name="strIsatMaFileNames"></param>
    ''' <param name="IsatData"></param>
    ''' <param name="CiscoNewTable"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetIsatExcel(ByVal strIsatMaFileNames() As String,
                                  ByRef IsatData As IsatTable,
                                  ByRef CiscoNewTable As CiscoMATable) As Boolean

        Dim blnRet As Boolean
        Dim intCnt As Integer
        Dim control As New OioControl
        Dim strFilter As String
        Dim intGroupNo As Integer

        GetIsatExcel = False

        Try
            For intCnt = 0 To (strIsatMaFileNames.Length - 1)
                '------------------------------------------
                'ISAT全ﾃﾞｰﾀ取得
                '------------------------------------------
                If strIsatMaFileNames(intCnt).IndexOf("結果ログISAT見積") = -1 Then
                    blnRet = control.GetIsatData(strIsatMaFileNames(intCnt), IsatData, intGroupNo)
                    If blnRet = False Then
                        Exit Function
                    End If
                End If
            Next
            If IsatData.Rows.Count > 0 Then
                '------------------------------------------
                '独自Table突合せ処理
                '------------------------------------------
                blnRet = control.CompareTableIsat(CommonVariable.MdbPW, IsatData)
                If blnRet = False Then
                    Exit Function
                End If
            End If

            '------------------------------------------
            'CISCO MA（新規）データ取得
            '------------------------------------------
            strFilter = IsatTable.COLUMN_NAME_NEW_EXIST & "='新規'"
            Dim rows() As DataRow = IsatData.Select(strFilter, IsatTable.COLUMN_NAME_RECORD_NO)
            If rows.Length > 0 Then
                CiscoNewTable = GetCiscoDataTable(rows)
            End If

            GetIsatExcel = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "GetIsatExcel")

        End Try

    End Function

    ''' <summary>
    ''' 機能：取込ﾌｧｲﾙにBK_を付与
    ''' </summary>
    ''' <param name="strFiles"></param>
    ''' <remarks></remarks>
    Private Sub RenameInputFile(ByVal strFiles() As String)

        Dim strPath As String
        Dim strFileName As String

        Try
            For Each strFile As String In strFiles
                strPath = Path.GetDirectoryName(strFile)
                strFileName = Path.GetFileName(strFile)
                If strFileName.IndexOf("結果ログISAT見積") = -1 Then
                    File.Move(strFile, strPath & "\BK_" & strFileName)
                End If
            Next

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' 機能：List出力
    ''' </summary>
    ''' <param name="isatData"></param>
    ''' <param name="CiscoNewTable"></param>
    ''' <param name="xlBooks"></param>
    ''' <remarks></remarks>
    Private Sub OutputList(ByVal isatData As IsatTable,
                           ByVal CiscoNewTable As CiscoMATable,
                           ByRef xlBooks As Excel.Workbooks)

        Dim LogList As New LogListData
        Dim ofm As New OioFileManage
        Dim strTmpFileName As String
        Dim strPath As String
        Dim strFileName As String
        Dim strLogFileName As String
        Dim row As DataRow
        Dim strFilter As String
        Dim strSort As String
        Dim objData(,) As Object
        Dim strRange As String
        Dim intRow As Integer = 4
        Dim strOuntputFlg As String
        Dim blnRet As Boolean
        Dim xlCells As Excel.Range
        Dim xlBook As Excel.Workbook = Nothing
        Dim xlSheets As Excel.Sheets = Nothing
        Dim xlSheet As Excel.Worksheet = Nothing
        Dim xlEntireRow As Excel.Range = Nothing

        Try
            '--------------------------------------
            '結果突合せ処理
            '--------------------------------------
            blnRet = LogCompare(isatData, CiscoNewTable, LogList)
            If blnRet = False Then
                Exit Sub
            End If

            '--------------------------------------
            'Templateコピー
            '--------------------------------------
            strTmpFileName = ofm.GetLocalTemplateFolder & "結果ログISAT見積Sample.xlsx"
            strPath = ofm.GetLocalOutputCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO) & "ISAT見積\"
            strFileName = Path.GetFileNameWithoutExtension(strTmpFileName)
            strFileName = strFileName.Replace("Sample", Now.ToString("_yyyyMMdd_HHmmss")) & ".xlsx"
            strLogFileName = strPath & strFileName
            File.Copy(strTmpFileName, strLogFileName)

            '--------------------------------------
            '出力
            '--------------------------------------
            xlBook = xlBooks.Open(strLogFileName)
            xlSheets = xlBook.Worksheets
            xlSheet = xlSheets.Item("結果")

            '罫線作成
            Const DIVISION_LINES As Long = 1000
            Dim lngRecordCnt As Long = LogList.Rows.Count
            Dim lngSho As Long = lngRecordCnt \ DIVISION_LINES
            Dim lngAmari As Long = lngRecordCnt Mod DIVISION_LINES
            Dim lngCnt As Long
            Const EXCEL_ROW_START As Integer = 4

            xlCells = xlSheet.Range("1:1")
            xlEntireRow = xlCells.EntireRow
            xlEntireRow.Hidden = False
            ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)
            xlCells.Copy()
            ExcelObjRelease.ReleaseExcelObj(xlCells, ExcelObjRelease.OBJECT_NOTHING)
            For lngCnt = 1 To lngSho
                strRange = (EXCEL_ROW_START + (lngCnt - 1) * DIVISION_LINES).ToString() & ":" & (EXCEL_ROW_START + lngCnt * DIVISION_LINES - 1).ToString()
                xlCells = xlSheet.Range(strRange)
                xlCells.Insert()
                ExcelObjRelease.ReleaseExcelObj(xlCells, ExcelObjRelease.OBJECT_NOTHING)
            Next
            If lngAmari > 0 Then
                strRange = (EXCEL_ROW_START + (lngSho * DIVISION_LINES)).ToString() & ":" & (EXCEL_ROW_START + (lngSho * DIVISION_LINES + lngAmari) - 1).ToString()
                xlCells = xlSheet.Range(strRange)
                xlCells.Insert()
                ExcelObjRelease.ReleaseExcelObj(xlCells, ExcelObjRelease.OBJECT_NOTHING)
            End If
            xlCells = xlSheet.Range("1:1")
            xlEntireRow = xlCells.EntireRow
            xlEntireRow.Hidden = True
            ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCells, ExcelObjRelease.OBJECT_NOTHING)

            'データ出力
            strFilter = ""
            strSort = "FILE_NAME, ROW_CNT"
            For Each row In LogList.Select(strFilter, strSort)
                strRange = "A" & intRow.ToString & ": H" & intRow.ToString
                xlCells = xlSheet.Range(strRange)
                objData = xlCells.Value
                objData(1, 1) = row.Item("LINE_NO").ToString
                objData(1, 2) = row.Item("FILE_NAME").ToString
                objData(1, 3) = row.Item("TYPE").ToString
                objData(1, 4) = row.Item("MODEL").ToString
                objData(1, 5) = row.Item("SERIAL").ToString
                objData(1, 6) = row.Item("ListPrice").ToString
                objData(1, 7) = row.Item("ROW_CNT").ToString
                strOuntputFlg = row.Item("OUTPUT_FLG").ToString
                If strOuntputFlg = "1" Then
                    objData(1, 8) = ""
                Else
                    objData(1, 8) = "Paymentへ反映できませんでした"
                End If
                xlCells.Value = objData
                ExcelObjRelease.ReleaseExcelObj(xlCells, ExcelObjRelease.OBJECT_NOTHING)

                intRow = intRow + 1
            Next
            ExcelObjRelease.ReleaseExcelObj(xlCells, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)

            '--------------------------------------
            '保存
            '--------------------------------------
            xlBook.Save()

        Catch ex As Exception
            Throw New Exception(ex.Message.ToString & "(OutputList)")

            ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCells, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBook) = False Then
                xlBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)

            ''ガベージコレクトの起動
            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' 機能：結果突合せ処理
    ''' </summary>
    ''' <param name="isatData"></param>
    ''' <param name="CiscoNewTable"></param>
    ''' <param name="LogList"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function LogCompare(ByVal isatData As IsatTable,
                                ByVal CiscoNewTable As CiscoMATable,
                                ByRef LogList As LogListData) As Boolean

        Dim row As DataRow
        Dim rowIns As DataRow
        Dim strListPrice As String
        Dim strGroupNo As String
        Dim intMesFlg As String
        Dim strMesFlg As String

        LogCompare = False

        Try
            '
            For Each row In isatData.Select(IsatTable.COLUMN_NAME_BOX_FEATURE & "='B'")
                strGroupNo = row.Item(IsatTable.COLUMN_NAME_GROUP_NO)
                rowIns = LogList.NewRow
                rowIns.Item("LINE_NO") = row.Item(IsatTable.COLUMN_NAME_REFLECTION_LINE_NO)
                rowIns.Item("FILE_NAME") = row.Item(IsatTable.COLUMN_NAME_FILE_NAME)
                'START 変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo
                Select Case row.Item(IsatTable.COLUMN_NAME_PATTERN_CD)
                    Case "18", "19", "41"
                        rowIns.Item("TYPE") = ""
                        rowIns.Item("MODEL") = ""
                    Case Else
                        rowIns.Item("TYPE") = row.Item(IsatTable.COLUMN_NAME_TYPE)
                        rowIns.Item("MODEL") = row.Item(IsatTable.COLUMN_NAME_MODEL)
                End Select
                'rowIns.Item("TYPE") = row.Item(IsatTable.COLUMN_NAME_TYPE)
                'rowIns.Item("MODEL") = row.Item(IsatTable.COLUMN_NAME_MODEL)
                'END   変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo
                rowIns.Item("SERIAL") = row.Item(IsatTable.COLUMN_NAME_SERIAL)
                rowIns.Item("GroupNo") = strGroupNo
                rowIns.Item("OUTPUT_FLG") = row.Item(IsatTable.COLUMN_NAME_REFLECTION_FLG)

                strMesFlg = row.Item(IsatTable.COLUMN_NAME_MES_FLG)
                If strMesFlg = "M" Then
                    intMesFlg = CD_MESFLG_ON
                Else
                    intMesFlg = CD_MESFLG_NO
                End If
                'START 変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo
                Select Case row.Item(IsatTable.COLUMN_NAME_PATTERN_CD)
                    Case "18", "19", "41"
                        strListPrice = row.Item(IsatTable.COLUMN_NAME_PRICE)
                    Case Else
                        strListPrice = CalcListPrice(isatData, strGroupNo, intMesFlg)
                End Select
                'strListPrice = CalcListPrice(isatData, strGroupNo, intMesFlg)
                'END   変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo
                rowIns.Item("ListPrice") = strListPrice
                rowIns.Item("ROW_CNT") = row.Item(IsatTable.COLUMN_NAME_ROW) - 1

                LogList.Rows.Add(rowIns)
            Next

            'CISCO MA(既存)の出力データをISATデータに反映する
            If CiscoNewTable.Rows.Count > 0 Then
                For Each rowCisco As DataRow In CiscoNewTable.Select("Cell_FLAG='2'")
                    For Each row In LogList.Select("GroupNo='" & rowCisco.Item("Cell_GroupNo") & "'")
                        row.Item("LINE_NO") = Integer.Parse(rowCisco.Item("Cell_LINENO")).ToString("00000000")
                        row.Item("OUTPUT_FLG") = "1"
                    Next
                Next
                isatData.AcceptChanges()
            End If

            LogCompare = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "LogCompare")

        End Try

    End Function

    Private Sub ProcEnd()

    End Sub

    ''' <summary>
    ''' 機能：ソート文字初期値セット
    ''' </summary>
    ''' <param name="xlSheet"></param>
    ''' <param name="intMaxRowPs"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function SetSortIni(ByRef xlSheet As Excel.Worksheet,
                                ByRef intSortKey1Col As Integer,
                                ByRef intSortKey2Col As Integer) As Boolean

        Dim objData(,) As Object
        Dim strRange As String
        Dim xlCells As Excel.Range
        Dim xlRange As Excel.Range
        Dim intRowMax As Integer
        Dim intColMax As Integer
        Dim intRowCnt As Integer

        SetSortIni = False

        Try
            '最終行、最終列取得
            Call GetLastCell(xlSheet, intColMax, intRowMax)

            'ソートキー列設定
            intSortKey1Col = intColMax + 2
            intSortKey2Col = intColMax + 3
            strRange = ExcelWrite.R1ToA1(ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW, intSortKey1Col) & ":" & ExcelWrite.R1ToA1(intRowMax, intSortKey2Col)
            Call ExcelWrite.GetCellValue(xlSheet, strRange, objData)

            For intRowCnt = 1 To (intRowMax - ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + 1)
                objData(intRowCnt, 1) = intRowCnt - 1 + ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW
                objData(intRowCnt, 2) = 0
            Next

            xlCells = xlSheet.Range(strRange)
            xlCells.Value = objData

            SetSortIni = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "SetSortIni")

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCells, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try

    End Function

    ''' <summary>
    ''' 機能：ソート処理
    ''' </summary>
    ''' <param name="intMaxRowPs"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function PaymentSort(ByRef xlSheet As Excel.Worksheet,
                                 ByVal intSortKey1Col As Integer,
                                 ByVal intSortKey2Col As Integer) As Boolean

        Dim strRange As String
        Dim xlRange As Excel.Range
        Dim intRowMax As Integer
        Dim xlSortKey1 As Excel.Range
        Dim xlSortKey2 As Excel.Range

        PaymentSort = False

        Try
            '最終行取得
            intRowMax = ExcelWrite.GetLastRow(xlSheet, ExcelWrite.CsvPaymentLineColumn.LINE_NO)

            'ソート処理
            xlRange = xlSheet.Rows(ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW.ToString & ":" & (intRowMax).ToString)
            xlSortKey1 = xlSheet.Cells(ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW, intSortKey1Col)
            xlSortKey2 = xlSheet.Cells(ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW, intSortKey2Col)
            xlRange.Sort(Key1:=xlSortKey1, Key2:=xlSortKey2, Orientation:=Excel.XlSortOrientation.xlSortColumns)
            ExcelObjRelease.ReleaseExcelObj(xlSortKey1, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSortKey2, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)

            'ソート文字削除
            strRange = ExcelWrite.chgExcelColumnIdxToChar(intSortKey1Col) & ":" & ExcelWrite.chgExcelColumnIdxToChar(intSortKey2Col)
            xlRange = xlSheet.Range(strRange)
            xlRange.ClearContents()

            PaymentSort = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "PaymentSort")

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlSortKey1, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSortKey2, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try

    End Function

    ''' <summary>
    ''' 機能：最終行、最終列取得
    ''' </summary>
    ''' <param name="xlSheet"></param>
    ''' <param name="intColMax"></param>
    ''' <param name="intRowMax"></param>
    ''' <remarks></remarks>
    Private Sub GetLastCell(ByVal xlSheet As Excel.Worksheet, ByRef intColMax As Integer, ByRef intRowMax As Integer)

        Dim xlRange As Excel.Range
        Dim xlCells As Excel.Range

        Try
            '最終行、最終列取得
            xlCells = xlSheet.Cells
            xlRange = xlCells.SpecialCells(Excel.XlCellType.xlCellTypeLastCell)
            intColMax = xlRange.Column
            intRowMax = xlRange.Row

        Catch ex As Exception
            Throw New Exception(ex.Message.ToString & "(GetLastCell)")

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCells, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try

    End Sub

#End Region

    '1680 str CISCO MA(新規)を対象外にする
    '#Region "CISCO MA（新規）ファイルPS反映処理"

    '    ''' <summary>
    '    ''' CISCO MAファイル読込処理
    '    ''' </summary>
    '    ''' <param name="xlSheetPs"></param>
    '    ''' <param name="xlSheetPsd"></param>
    '    ''' <param name="CiscoNewTable"></param>
    '    ''' <param name="intOutputCnt"></param>
    '    ''' <returns></returns>
    '    ''' <remarks></remarks>
    '    Private Function CiscoMAReflection(ByRef xlSheetPs As Excel.Worksheet,
    '                                       ByRef xlSheetPsd As Excel.Worksheet,
    '                                       ByRef intOutputCnt As Integer,
    '                                       ByRef PSTable As PSDataTable,
    '                                       ByVal CiscoNewTable As CiscoMATable,
    '                                       ByVal intSortKey2Col As Integer) As Boolean

    '        Dim wRet As Boolean

    '        CiscoMAReflection = False

    '        Try
    '            ''詳細Sheetのデータを取得
    '            Dim DetailTable As DetailDataTable
    '            DetailTable = GetDetailDataTable(xlSheetPsd)

    '            '' 各不要レコード削除
    '            wRet = DeleteTables(PSTable, DetailTable, CiscoNewTable)

    '            '' 各テーブル突き合わせ
    '            wRet = MatchTables(PSTable, DetailTable, CiscoNewTable)

    '            '' PSシートに反映
    '            intOutputCnt = intOutputCnt + PSReflection(xlSheetPs, PSTable, CiscoNewTable, intSortKey2Col)

    '            ''正常終了
    '            CiscoMAReflection = True

    '        Catch ex As Exception
    '            Throw ex

    '        End Try

    '    End Function
    '1680 end CISCO MA(新規)を対象外にする

    ''' <summary>
    ''' 概 要：Paymentシートの情報をデータテーブルへ格納する。
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetPSDataTable(ByRef xlPSSheet As Excel.Worksheet) As PSDataTable

        Dim rtnTable As New PSDataTable
        Dim xlRange As Excel.Range
        Dim EXCEL_PAYMENT_LINE_RANGE As String = "A@:AG@"
        Dim strPatternCd As String
        Dim i As Integer

        Dim MyArray(1, ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD) As Object

        Try
            For i = ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW To EXCEL_MAX_ROW

                xlRange = xlPSSheet.Range(EXCEL_PAYMENT_LINE_RANGE.Replace("@", i.ToString))

                ''EOF判定
                If ExcelWrite.changeDBNullToString(xlRange(1, ExcelWrite.ExcelPaymentLineColumn.LINE_NO).Value) = "" Then
                    Exit For
                End If

                ''対象データ判定
                If ExcelWrite.changeDBNullToString(xlRange(1, ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG).Value) <> "" Then
                    Continue For
                End If
                strPatternCd = ExcelWrite.changeDBNullToString(xlRange(1, ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD).Value)
                'START 変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo
                Select Case strPatternCd
                    Case "15", "17", "18", "19", "20", "21", "41"
                    Case Else
                        Continue For
                End Select
                'If strPatternCd <> "15" And strPatternCd <> "17" And strPatternCd <> "20" And strPatternCd <> "21" Then
                '    Continue For
                'End If
                'END   変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo

                MyArray = xlPSSheet.Range(ExcelWrite.EXCEL_PAYMENT_LINE_RANGE.Replace("@", i.ToString)).Value

                'Paymentの数量がマイナスの場合、対象外とする
                If Integer.Parse(ExcelWrite.changeDBNullToZero(MyArray(1, ExcelWrite.ExcelPaymentLineColumn.QTY))) <= 0 Then
                    Continue For
                End If

                'Paymentの値をセットする
                Dim row As DataRow
                row = rtnTable.NewRow

                For j As Integer = ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG To ExcelWrite.ExcelPaymentLineColumn.CONTRACT
                    'Paymentの値をValue（固定値）で取得
                    row("CellNM" & j) = ExcelWrite.changeDBNullToString(MyArray(1, j))
                Next
                'START 変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo
                row("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD) = ExcelWrite.changeDBNullToString(MyArray(1, ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD))
                'END   変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo
                row("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01) = ExcelWrite.changeDBNullToString(MyArray(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01))
                row("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02) = ExcelWrite.changeDBNullToString(MyArray(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02))
                row("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD) = ExcelWrite.changeDBNullToString(MyArray(1, ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD))
                ''Excelの行番号
                row("ExcelRow") = i
                '反映FLG：未反映
                row("ReflectionFlg") = "0"

                ''データを追加する。
                rtnTable.Rows.Add(row)
            Next

            '-------------------------------------------
            'デバッグ用
            '-------------------------------------------
            Dim strLine As String
            'START 変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo
            Debug.Print("作業指示FLG,Status,Payment種別,NO,ﾌｧｲﾙ名,構成種別,ﾌｧｲﾙ内構成連番,契約順番,ﾊﾟﾀｰﾝNO,項目１（製品番号）,項目２（ｼﾘｱﾙ）,支払方法,ExcelRow,ReflectionFlg")
            'Debug.Print("作業指示FLG,Status,Payment種別,NO,ﾌｧｲﾙ名,構成種別,ﾌｧｲﾙ内構成連番,契約順番,項目１（製品番号）,項目２（ｼﾘｱﾙ）,支払方法,ExcelRow,ReflectionFlg")
            'END   変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo
            For Each row As DataRow In rtnTable.Select("", "ExcelRow")
                strLine = ""
                For j As Integer = ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG To ExcelWrite.ExcelPaymentLineColumn.CONTRACT
                    strLine = strLine & row("CellNM" & j) & ","
                Next
                'START 変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo
                strLine = strLine & row("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD) & ","
                'END   変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo
                strLine = strLine & row("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01) & ","
                strLine = strLine & row("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02) & ","
                strLine = strLine & row("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD) & ","
                strLine = strLine & row("ExcelRow") & ","
                strLine = strLine & row("ReflectionFlg")
                Debug.Print(strLine)
            Next

            Return rtnTable

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try
    End Function

    '1680 str CISCO MA(新規)を対象外にする
    ' ''' <summary>
    ' ''' 概 要：詳細シートの情報をデータテーブルへ格納する。
    ' ''' 説 明：
    ' ''' </summary>
    ' ''' <remarks></remarks>
    'Private Function GetDetailDataTable(ByVal xlDetailSheet As Excel.Worksheet) As DetailDataTable

    '    Dim rtnTable As New DetailDataTable
    '    Dim xlRange As Excel.Range

    '    Try

    '        For i As Integer = ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW To EXCEL_MAX_ROW

    '            xlRange = xlDetailSheet.Range(("A@:Z@").Replace("@", i))

    '            ''EOF判定
    '            If ExcelWrite.changeDBNullToString(xlRange(1, ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT).Value) = "" And
    '               ExcelWrite.changeDBNullToString(xlRange(1, ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME).Value) = "" And
    '               ExcelWrite.changeDBNullToString(xlRange(1, ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX).Value) = "" And
    '               ExcelWrite.changeDBNullToString(xlRange(1, ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR).Value) = "" And
    '               ExcelWrite.changeDBNullToString(xlRange(1, ExcelWrite.ExcelPaymentLineDetailColumn.SEQ).Value) = "" Then

    '                Exit For
    '            End If

    '            ''Paymentの値をセットする
    '            Dim row As DataRow
    '            row = rtnTable.NewRow
    '            For j As Integer = ExcelWrite.ExcelPaymentLineDetailColumn.UPDATE_FLAG To ExcelWrite.ExcelPaymentLineDetailColumn.COST_INPUT_DATE
    '                row("CellNM" & j) = ExcelWrite.changeDBNullToString(xlRange(1, j).Value)
    '            Next

    '            ''Excelの行番号
    '            row("ExcelRow") = i

    '            ''データを追加する。
    '            rtnTable.Rows.Add(row)

    '        Next

    '        Return rtnTable

    '    Catch ex As Exception
    '        Throw ex

    '    Finally
    '        ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
    '        GC.Collect()
    '    End Try
    'End Function
    '1680 end CISCO MA(新規)を対象外にする

    ''' <summary>
    ''' 概 要：CISCOMAシートのデータを取得
    ''' </summary>
    ''' <param name="rowsIsat"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetCiscoDataTable(ByVal rowsIsat() As DataRow) As CiscoMATable

        Dim cmaWork As New CiscoMATable
        Dim rtnTable As New CiscoMATable
        Dim row As DataRow
        Dim lngListPrice As Long
        Dim intRowCnt As Integer
        Dim intDetailCnt As Integer
        Dim intStartRow As Integer

        Try
            intDetailCnt = 0
            For intRowCnt = 0 To (rowsIsat.Length - 1)
                'BOX判定
                If rowsIsat(intRowCnt).Item(IsatTable.COLUMN_NAME_BOX_FEATURE) = "B" Then
                    If intRowCnt <> 0 Then
                        '１行分データ書き出し
                        row("Cell_ROWID") = Format(intStartRow, "00000")
                        row("Cell_COUNT") = Format(intDetailCnt, "000")
                        row("Cell_CiscoRowStart") = intStartRow
                        row("Cell_CiscoRowEnd") = rowsIsat(intRowCnt).Item(IsatTable.COLUMN_NAME_ROW) - 2
                        row("Cell_ListPrice") = lngListPrice
                        cmaWork.Rows.Add(row)
                    End If
                    '初期化
                    intDetailCnt = 0
                    lngListPrice = 0
                    row = cmaWork.NewRow

                    '処理区分
                    row("Cell_FLAG") = "0"
                    '対応PSシート情報
                    row("Cell_PSROW") = ""
                    row("Cell_LINENO") = ""
                    row("Cell_FIleName") = ""
                    row("Cell_SUFFIX") = ""
                    row("Cell_INTR") = ""
                    row("Cell_CONTRACT") = ""
                    '対応CISCOシート情報
                    row("Cell_QTY") = "0"
                    'CISCO情報
                    row("Cell_PayMethod") = rowsIsat(intRowCnt).Item(IsatTable.COLUMN_NAME_PAY_METHOD)
                    row("Cell_GroupNo") = rowsIsat(intRowCnt).Item(IsatTable.COLUMN_NAME_GROUP_NO)
                    row("Cell_HOSYU_KATABAN") = rowsIsat(intRowCnt).Item(IsatTable.COLUMN_NAME_TYPE) & rowsIsat(intRowCnt).Item(IsatTable.COLUMN_NAME_MODEL)
                    row("Cell_HOSYU_SERIAL") = rowsIsat(intRowCnt).Item(IsatTable.COLUMN_NAME_SERIAL)
                    row("Cell_ServiceKIND") = rowsIsat(intRowCnt).Item(IsatTable.COLUMN_NAME_SVC_LEVEL)
                    row("Cell_MesFlg") = rowsIsat(intRowCnt).Item(IsatTable.COLUMN_NAME_MES_FLG)

                    intStartRow = rowsIsat(intRowCnt).Item(IsatTable.COLUMN_NAME_ROW)
                End If
                '明細情報
                intDetailCnt = intDetailCnt + 1
                '機械番号 / 機械名称
                row("Cell_Machine" & Format(intDetailCnt, "00")) = rowsIsat(intRowCnt).Item(IsatTable.COLUMN_NAME_DESCRIPTION)
                '台数
                row("Cell_Count" & Format(intDetailCnt, "00")) = rowsIsat(intRowCnt).Item(IsatTable.COLUMN_NAME_QTY).ToString
                '保守料金
                lngListPrice = lngListPrice + rowsIsat(intRowCnt).Item(IsatTable.COLUMN_NAME_PRICE)
            Next

            '残りデータ書き出し
            row("Cell_ROWID") = Format(intStartRow, "00000")
            row("Cell_COUNT") = Format(intDetailCnt, "000")
            row("Cell_CiscoRowStart") = intStartRow
            row("Cell_CiscoRowEnd") = rowsIsat(intRowCnt - 1).Item(IsatTable.COLUMN_NAME_ROW)
            row("Cell_ListPrice") = lngListPrice
            cmaWork.Rows.Add(row)

            'MESがある構成の場合、検索対象外(処理区分)とする
            For Each rowMes As DataRow In cmaWork.Select("Cell_MesFlg='M'")
                For Each row In cmaWork.Select("Cell_MesFlg='' and Cell_GroupNo='" & rowMes.Item("Cell_GroupNo") & "'")
                    row.Item("Cell_FLAG") = "-1"
                Next
            Next

            'テーブルソート処理 
            'ソート実行(明細行数の降順)
            Dim tempView As DataView = New DataView(cmaWork)
            Dim tempTable As DataTable
            tempView.Sort = "Cell_COUNT" & CommonConstant.SQL_STR_DESC

            'ソート後の値をテーブルに格納する。
            tempTable = tempView.ToTable()
            For Each row In tempTable.Select
                rtnTable.ImportRow(row)
            Next

            Return rtnTable

        Catch ex As Exception
            Throw ex

        End Try

    End Function

    '1680 str CISCO MA(新規)を対象外にする
    ' ''' <summary>
    ' ''' 概 要：Payment,詳細の各データテーブルより、不要行を削除する。
    ' ''' </summary>
    ' ''' <param name="PSTable"></param>
    ' ''' <param name="DetailTable"></param>
    ' ''' <param name="CiscoTable"></param>
    ' ''' <returns></returns>
    ' ''' <remarks></remarks>
    'Private Function DeleteTables(ByRef PSTable As PSDataTable, _
    '                              ByRef DetailTable As DetailDataTable, _
    '                              ByRef CiscoTable As CiscoMATable) As Boolean
    '    Dim filter As New StringBuilder
    '    Dim fFind As Boolean
    '    Dim TargetRows() As DataRow

    '    ''戻り値
    '    Try
    '        '主キーを定義
    '        PSTable.PrimaryKey = New DataColumn() {PSTable.Columns("ExcelRow")}
    '        DetailTable.PrimaryKey = New DataColumn() {DetailTable.Columns("ExcelRow")}

    '        'PSを全件走査
    '        For Each row As DataRow In PSTable.Select("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME & " <> ''")

    '            If row.RowState <> DataRowState.Deleted Then
    '                '詳細検索SQLを編集
    '                filter.Length = 0
    '                filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
    '                filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME)
    '                filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                filter.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME)))
    '                filter.Append(CommonConstant.SQL_STR_AND)
    '                filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX)
    '                filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                filter.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX)))
    '                filter.Append(CommonConstant.SQL_STR_AND)
    '                filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR)
    '                filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                filter.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR)))
    '                filter.Append(CommonConstant.SQL_STR_AND)
    '                filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT)
    '                filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                filter.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT)))
    '                filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

    '                '該当無し→レコード削除
    '                If DetailTable.Select(filter.ToString).Length = 0 Then
    '                    filter.Length = 0
    '                    'PS削除SQLを編集
    '                    filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
    '                    filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME)
    '                    filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                    filter.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME)))
    '                    filter.Append(CommonConstant.SQL_STR_AND)
    '                    filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX)
    '                    filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                    filter.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX)))
    '                    filter.Append(CommonConstant.SQL_STR_AND)
    '                    filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR)
    '                    filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                    filter.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR)))
    '                    filter.Append(CommonConstant.SQL_STR_AND)
    '                    filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT)
    '                    filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                    filter.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT)))
    '                    filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

    '                    TargetRows = PSTable.Select(filter.ToString)
    '                    '見つかった行を削除
    '                    For Each r As DataRow In TargetRows
    '                        r.Delete()
    '                    Next
    '                End If
    '            End If
    '        Next
    '        PSTable.AcceptChanges()

    '        '詳細を全件走査
    '        For Each row As DataRow In DetailTable.Select("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME & " <> ''")

    '            If row.RowState <> DataRowState.Deleted Then
    '                'PS検索SQLを編集
    '                filter.Length = 0
    '                filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
    '                filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME)
    '                filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                filter.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME)))
    '                filter.Append(CommonConstant.SQL_STR_AND)
    '                filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX)
    '                filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                filter.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX)))
    '                filter.Append(CommonConstant.SQL_STR_AND)
    '                filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR)
    '                filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                filter.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR)))
    '                filter.Append(CommonConstant.SQL_STR_AND)
    '                filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT)
    '                filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                filter.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT)))
    '                filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

    '                '該当無し→レコード削除
    '                If PSTable.Select(filter.ToString).Length = 0 Then
    '                    filter.Length = 0
    '                    '詳細削除SQLを編集
    '                    filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
    '                    filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME)
    '                    filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                    filter.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME)))
    '                    filter.Append(CommonConstant.SQL_STR_AND)
    '                    filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX)
    '                    filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                    filter.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX)))
    '                    filter.Append(CommonConstant.SQL_STR_AND)
    '                    filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR)
    '                    filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                    filter.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR)))
    '                    filter.Append(CommonConstant.SQL_STR_AND)
    '                    filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT)
    '                    filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                    filter.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT)))
    '                    filter.Append(CommonConstant.SQL_STR_AND)
    '                    filter.Append("ExcelRow")
    '                    filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                    filter.Append(row.Item("ExcelRow"))
    '                    filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

    '                    TargetRows = DetailTable.Select(filter.ToString)
    '                    '見つかった行を削除
    '                    For Each r As DataRow In TargetRows
    '                        r.Delete()
    '                    Next
    '                End If
    '            End If
    '        Next

    '        DetailTable.AcceptChanges()

    '        Return True

    '    Catch ex As Exception
    '        Throw ex
    '    End Try

    'End Function

    ' ''' <summary>
    ' ''' 概 要：Payment,詳細の各データテーブルを突き合わせる。
    ' ''' </summary>
    ' ''' <param name="PSTable"></param>
    ' ''' <param name="DetailTable"></param>
    ' ''' <param name="CiscoTable"></param>
    ' ''' <returns></returns>
    ' ''' <remarks></remarks>
    'Private Function MatchTables(ByRef PSTable As PSDataTable, _
    '                             ByRef DetailTable As DetailDataTable, _
    '                             ByRef CiscoTable As CiscoMATable) As Boolean
    '    Dim filter As New StringBuilder
    '    Dim fFind As Boolean
    '    Dim TargetRows() As DataRow
    '    Dim ii As Integer
    '    Dim hh As Integer

    '    Dim Details() As DetailData
    '    Dim FileName As String
    '    Dim SUFFIX As String
    '    Dim INTR As String
    '    Dim CONTRACT As String

    '    Dim DCount As Integer = 0
    '    Dim QTY As Integer
    '    Dim TargetRow As DataRow

    '    Try
    '        Dim Str As String = ""

    '        '詳細を全件走査 → キー値一覧テーブルを作成する
    '        For Each row As DataRow In DetailTable.Select("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME & " <> ''")
    '            'キー値を取得
    '            FileName = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME).ToString
    '            SUFFIX = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX).ToString
    '            INTR = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR).ToString
    '            CONTRACT = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT).ToString

    '            If DCount = 0 Then
    '                '初期データ
    '                DCount = 1
    '                ReDim Details(DCount)

    '                Details(0).FileName = FileName
    '                Details(0).SUFFIX = SUFFIX
    '                Details(0).INTR = INTR
    '                Details(0).CONTRACT = CONTRACT
    '            Else
    '                fFind = False
    '                For ii = 0 To DCount - 1
    '                    If Details(ii).FileName = FileName And _
    '                       Details(ii).SUFFIX = SUFFIX And _
    '                       Details(ii).INTR = INTR And _
    '                       Details(ii).CONTRACT = CONTRACT Then
    '                        'キー一致
    '                        fFind = True
    '                        Exit For
    '                    End If
    '                Next

    '                If fFind = False Then
    '                    DCount = DCount + 1
    '                    ReDim Preserve Details(DCount)

    '                    Details(DCount - 1).FileName = FileName
    '                    Details(DCount - 1).SUFFIX = SUFFIX
    '                    Details(DCount - 1).INTR = INTR
    '                    Details(DCount - 1).CONTRACT = CONTRACT
    '                End If
    '            End If
    '        Next

    '        'CISCOテーブルを全件走査
    '        For Each row As DataRow In CiscoTable.Select("Cell_COUNT > '0' AND Cell_FLAG = '0'", "Cell_COUNT DESC")
    '            '詳細を全件走査してCISCO明細と突き合わせる
    '            For hh = 0 To DCount - 1
    '                fFind = True

    '                If Details(hh).FileName <> "" Then
    '                    'CISCOテーブル内と詳細を全件突き合わせ
    '                    For ii = 1 To Val(row.Item("Cell_COUNT"))
    '                        filter.Length = 0
    '                        filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
    '                        filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME)
    '                        filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                        filter.Append(StringEdit.EncloseSingleQuotation(Details(hh).FileName))
    '                        filter.Append(CommonConstant.SQL_STR_AND)
    '                        filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX)
    '                        filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                        filter.Append(StringEdit.EncloseSingleQuotation(Details(hh).SUFFIX))
    '                        filter.Append(CommonConstant.SQL_STR_AND)
    '                        filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR)
    '                        filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                        filter.Append(StringEdit.EncloseSingleQuotation(Details(hh).INTR))
    '                        filter.Append(CommonConstant.SQL_STR_AND)
    '                        filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT)
    '                        filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                        filter.Append(StringEdit.EncloseSingleQuotation(Details(hh).CONTRACT))
    '                        filter.Append(CommonConstant.SQL_STR_AND)
    '                        filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.IDENTITY_FLAG)
    '                        filter.Append(CommonConstant.SQL_STR_NOT_EQUAL)
    '                        filter.Append(StringEdit.EncloseSingleQuotation("S"))
    '                        filter.Append(CommonConstant.SQL_STR_AND)
    '                        filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.PROD_NO)
    '                        filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                        filter.Append(StringEdit.EncloseSingleQuotation(row.Item("Cell_Machine" & Format(ii, "00"))))
    '                        filter.Append(CommonConstant.SQL_STR_AND)
    '                        filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.QTY_INTEGER)
    '                        filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                        filter.Append(StringEdit.EncloseSingleQuotation(row.Item("Cell_COUNT" & Format(ii, "00"))))
    '                        filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

    '                        '数量合計
    '                        QTY = QTY + Val(row.Item("Cell_Count" & Format(ii, "00")))

    '                        '該当詳細無し → 検索終了
    '                        If DetailTable.Select(filter.ToString).Length = 0 Then

    '                            fFind = False
    '                            Exit For
    '                        End If
    '                    Next

    '                    '全データあり
    '                    If fFind = True Then
    '                        'キー値情報をCISCOテーブルに更新
    '                        row.Item("Cell_FLAG") = "1"         '更新対象
    '                        row.Item("Cell_FileName") = Details(hh).FileName
    '                        row.Item("Cell_SUFFIX") = Details(hh).SUFFIX
    '                        row.Item("Cell_INTR") = Details(hh).INTR
    '                        row.Item("Cell_CONTRACT") = Details(hh).CONTRACT
    '                        row.Item("Cell_QTY") = QTY

    '                        CiscoTable.AcceptChanges()

    '                        '見つかった詳細データは削除
    '                        filter.Length = 0
    '                        '詳細検索SQLを編集
    '                        filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
    '                        filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME)
    '                        filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                        filter.Append(StringEdit.EncloseSingleQuotation(Details(hh).FileName))
    '                        filter.Append(CommonConstant.SQL_STR_AND)
    '                        filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX)
    '                        filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                        filter.Append(StringEdit.EncloseSingleQuotation(Details(hh).SUFFIX))
    '                        filter.Append(CommonConstant.SQL_STR_AND)
    '                        filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR)
    '                        filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                        filter.Append(StringEdit.EncloseSingleQuotation(Details(hh).INTR))
    '                        filter.Append(CommonConstant.SQL_STR_AND)
    '                        filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT)
    '                        filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                        filter.Append(StringEdit.EncloseSingleQuotation(Details(hh).CONTRACT))
    '                        filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

    '                        TargetRows = DetailTable.Select(filter.ToString)
    '                        '見つかった行を削除
    '                        For Each r As DataRow In TargetRows
    '                            r.Delete()
    '                        Next
    '                        DetailTable.AcceptChanges()

    '                        Details(hh).FileName = ""
    '                        Details(hh).SUFFIX = ""
    '                        Details(hh).INTR = ""
    '                        Details(hh).CONTRACT = ""
    '                    End If

    '                    If fFind = True Then
    '                        Exit For
    '                    End If
    '                End If
    '            Next
    '        Next

    '        'MESかつ詳細ｼｰﾄに一致したﾃﾞｰﾀがあった場合、親構成の処理区分、CISCO情報を更新する
    '        For Each rowMes As DataRow In CiscoTable.Select("Cell_MesFlg='M' and Cell_FLAG='1'")
    '            For Each row As DataRow In CiscoTable.Select("Cell_MesFlg='' and Cell_GroupNo='" & rowMes.Item("Cell_GroupNo") & "'")
    '                row.Item("Cell_FLAG") = "1"
    '                row.Item("Cell_FileName") = rowMes.Item("Cell_FileName")
    '                row.Item("Cell_SUFFIX") = rowMes.Item("Cell_SUFFIX")
    '                row.Item("Cell_INTR") = rowMes.Item("Cell_INTR")
    '                row.Item("Cell_CONTRACT") = rowMes.Item("Cell_CONTRACT")
    '            Next
    '        Next

    '        Return True

    '    Catch ex As Exception
    '        Throw ex
    '    End Try

    'End Function

    '    ''' <summary>
    '    ''' 概 要：PaymentシートにCISCO情報を反映させる。
    '    ''' </summary>
    '    ''' <param name="xlPSSheet"></param>
    '    ''' <param name="PSTable"></param>
    '    ''' <param name="CiscoTable"></param>
    '    ''' <param name="intSortKey2Col"></param>
    '    ''' <returns></returns>
    '    ''' <remarks></remarks>
    '    Private Function PSReflection(ByRef xlPSSheet As Excel.Worksheet, _
    '                                  ByRef PSTable As PSDataTable, _
    '                                  ByRef CiscoTable As CiscoMATable, _
    '                                  ByVal intSortKey2Col As Integer) As Integer

    '        Dim filter As New StringBuilder
    '        Dim PCount As Integer = 0
    '        Dim FileName As String
    '        Dim SUFFIX As String
    '        Dim INTR As String
    '        Dim CONTRACT As String
    '        Dim wStr As String
    '        Dim rtnTable As New PSDataTable
    '        Dim xlRange As Excel.Range
    '        Dim MyArray(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12) As Object
    '        Dim strWork As String
    '        Dim strPayMethod As String
    '        Dim intYearMax As Integer
    '        Dim intYearCnt As Integer
    '        Dim strSvcStart As String
    '        Dim strSvcEnd As String
    '        Dim strPayStart As String
    '        Dim intRow As Integer
    '        Dim strRange As String
    '        Dim objData(,) As Object
    '        Dim intAddRow As Integer
    '        Dim dtWork As Date
    '        Dim strListPrice As String
    '        Dim intOutputRow As Integer
    '        Dim strItem02 As String
    '        Dim strGroupNo As String
    '        Dim lngListPrice As Long
    '        Dim strLineNo As String

    '        Try
    '            'CISCOテーブルを全件走査
    '            For Each row As DataRow In CiscoTable.Select("Cell_FLAG = '1'")
    '                If row.Item("Cell_Filename") <> "" Then
    '                    'PS検索SQLを編集
    '                    filter.Length = 0
    '                    filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
    '                    filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME)
    '                    filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                    filter.Append(StringEdit.EncloseSingleQuotation(row.Item("Cell_Filename")))
    '                    filter.Append(CommonConstant.SQL_STR_AND)
    '                    filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX)
    '                    filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                    filter.Append(StringEdit.EncloseSingleQuotation(row.Item("Cell_SUFFIX")))
    '                    filter.Append(CommonConstant.SQL_STR_AND)
    '                    filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR)
    '                    filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                    filter.Append(StringEdit.EncloseSingleQuotation(row.Item("Cell_INTR")))
    '                    filter.Append(CommonConstant.SQL_STR_AND)
    '                    filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT)
    '                    filter.Append(CommonConstant.SQL_STR_EQUAL)
    '                    filter.Append(StringEdit.EncloseSingleQuotation(row.Item("Cell_CONTRACT")))
    '                    filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

    '                    'データあり
    '                    For Each row2 As DataRow In PSTable.Select(filter.ToString)
    '                        '行情報をCISCOテーブルに更新
    '                        row.Item("Cell_PSROW") = row2.Item("ExcelRow")

    '                        CiscoTable.AcceptChanges()
    '                        Exit For
    '                    Next
    '                    CiscoTable.AcceptChanges()
    '                End If
    '            Next

    '            '最終行取得
    '            intAddRow = ExcelWrite.GetLastRow(xlPSSheet, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)

    '            'PSを全行検索
    '            For i As Integer = ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW To EXCEL_MAX_ROW

    '                xlRange = xlPSSheet.Range(ExcelWrite.EXCEL_PAYMENT_LINE_RANGE.Replace("@", i.ToString))

    '                ''EOF判定
    '                If ExcelWrite.changeDBNullToString(xlRange(1, ExcelWrite.ExcelPaymentLineColumn.LINE_NO).Value) = "" Then
    '                    Exit For
    '                End If

    '                'CISCOテーブルを全件走査
    '                For Each row2 As DataRow In CiscoTable.Select("Cell_FLAG = '1' and Cell_MesFlg=''")

    '                    '当該行のデータの場合
    '                    If i = Val(row2.Item("Cell_PSROW")) Then
    '                        '対象データ更新
    '                        '項目１
    '                        xlRange = xlPSSheet.Cells(i, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01)
    '                        xlRange.Value = row2.Item("Cell_HOSYU_KATABAN")
    '                        ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
    '                        '項目２
    '                        strWork = row2.Item("Cell_HOSYU_SERIAL")
    '                        If IsNumeric(strWork) = True And strWork.Length < 7 Then
    '                            strItem02 = strWork.PadLeft(7, "0"c)
    '                        Else
    '                            strItem02 = strWork
    '                        End If
    '                        If strWork = "" Or strWork = "別途連絡" Then
    '                            strItem02 = ""
    '                        Else
    '                            strWork = strWork.Substring(0, 2)
    '                            '"SE","OR"(仮シリアル)の時は空白にする
    '                            If strWork = "SE" Or strWork = "OR" Then
    '                                strItem02 = ""
    '                            End If
    '                        End If
    '                        xlRange = xlPSSheet.Cells(i, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02)
    '                        xlRange.Value = strItem02
    '                        ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
    '                        '項目４
    '                        Select Case row2.Item("Cell_ServiceKIND")
    '                            Case "NA1"
    '                                strWork = "ESA BASE"
    '                            Case "NA2"
    '                                strWork = "ESA HALF"
    '                            Case "NA3"
    '                                strWork = "ESA MID"
    '                            Case "NA4"
    '                                strWork = "ESA FULL"
    '                            Case "NB1"
    '                                strWork = "ESB BASE"
    '                            Case "NB2"
    '                                strWork = "ESB HALF"
    '                            Case "NB3"
    '                                strWork = "ESB MID"
    '                            Case "NB4"
    '                                strWork = "ESB FULL"
    '                            Case Else
    '                                strWork = ""
    '                        End Select
    '                        xlRange = xlPSSheet.Cells(i, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM04)
    '                        xlRange.Value = strWork
    '                        ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
    '                        'ListPrice
    '                        strGroupNo = row2.Item("Cell_GroupNo")
    '                        '構成＋MESのListPrice
    '                        lngListPrice = CalcListPrice(CiscoTable, strGroupNo)
    '                        lngListPrice = lngListPrice / Long.Parse(row2.Item("Cell_Count01"))
    '                        xlRange = xlPSSheet.Cells(i, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL)
    '                        xlRange.Value = lngListPrice
    '                        ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
    '                        xlRange = xlPSSheet.Cells(i, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH)
    '                        xlRange.Value = lngListPrice
    '                        ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)

    '                        PCount = PCount + 1

    '                        row2.Item("Cell_FLAG") = "2"
    '                        xlRange = xlPSSheet.Cells(i, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)
    '                        strLineNo = xlRange.Value
    '                        ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
    '                        row2.Item("Cell_LINENO") = strLineNo
    '                        'MESがある構成の場合、更新する
    '                        For Each rowMes As DataRow In CiscoTable.Select("Cell_MesFlg='M' and Cell_GroupNo='" & strGroupNo & "'")
    '                            rowMes.Item("Cell_FLAG") = "2"
    '                            rowMes.Item("Cell_LINENO") = strLineNo
    '                        Next

    '                        '--------------------------------------------------
    '                        '支払方法：年額　処理
    '                        '--------------------------------------------------
    '                        'Paymentの1行取得
    '                        intRow = Integer.Parse(ExcelWrite.changeDBNullToZero(row2.Item("Cell_PSROW")))
    '                        strRange = ExcelWrite.EXCEL_PAYMENT_LINE_RANGE.Replace("@", intRow.ToString)
    '                        Call ExcelWrite.GetCellValue(xlPSSheet, strRange, objData)
    '                        ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)

    '                        '------------------------------------------------
    '                        'ISAT見積の支払方法判定
    '                        '------------------------------------------------
    '                        strPayMethod = ExcelWrite.changeDBNullToString(row2.Item("Cell_PayMethod"))
    '                        If strPayMethod = "A" Then
    '                            '年額の場合、支払年数を取得する
    '                            intYearMax = 1
    '                            strSvcStart = ExcelWrite.changeDBNullToString(objData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11))
    '                            strSvcEnd = ExcelWrite.changeDBNullToString(objData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12))
    '                            strPayStart = ExcelWrite.changeDBNullToString(objData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE))
    '                            If IsDate(strSvcStart) = True And IsDate(strSvcEnd) = True Then
    '                                intYearMax = Date.Parse(strSvcEnd).Year - Date.Parse(strSvcStart).Year
    '                                If Date.Parse(strSvcEnd).Month - Date.Parse(strSvcStart).Month >= 0 Then
    '                                    intYearMax = intYearMax + 1
    '                                End If
    '                            End If

    '                            '------------------------------------------------
    '                            '年額かつ複数年有る場合の処理
    '                            '------------------------------------------------
    '                            If intYearMax > 1 Then
    '                                '支払年数-1の行数を最下行に追加する
    '                                xlRange = xlPSSheet.Range(i.ToString & ":" & i.ToString)
    '                                xlRange.Copy()
    '                                ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
    '                                strRange = (intAddRow + 1).ToString & ":" & (intAddRow + intYearMax - 1).ToString()
    '                                xlRange = xlPSSheet.Range(strRange)
    '                                xlRange.PasteSpecial()
    '                                ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)

    '                                For intYearCnt = 1 To intYearMax
    '                                    If intYearCnt = 1 Then
    '                                        '1年目は既にある行を書き換える
    '                                        intOutputRow = i
    '                                    Else
    '                                        '2年目以降は行を追加する
    '                                        intAddRow = intAddRow + 1
    '                                        intOutputRow = intAddRow

    '                                        'NO
    '                                        xlRange = xlPSSheet.Cells(intOutputRow, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)
    '                                        xlRange.Value = 0
    '                                        ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
    '                                    End If
    '                                    '項目１１（ｻｰﾋﾞｽ期間開始）
    '                                    dtWork = Date.Parse(strSvcStart).AddYears(intYearCnt - 1)
    '                                    xlRange = xlPSSheet.Cells(intOutputRow, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11)
    '                                    xlRange.Value = dtWork.ToString("yyyy/MM/dd")
    '                                    ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
    '                                    '項目１２（ｻｰﾋﾞｽ期間終了）
    '                                    dtWork = Date.Parse(strSvcStart).AddYears(intYearCnt).AddDays(-1)
    '                                    xlRange = xlPSSheet.Cells(intOutputRow, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12)
    '                                    xlRange.Value = dtWork.ToString("yyyy/MM/dd")
    '                                    ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
    '                                    '支払方法
    '                                    xlRange = xlPSSheet.Cells(intOutputRow, ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD)
    '                                    xlRange.Value = "年額"
    '                                    ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
    '                                    '請求期間開始年月
    '                                    dtWork = Date.Parse(strPayStart).AddYears(intYearCnt - 1)
    '                                    xlRange = xlPSSheet.Cells(intOutputRow, ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE)
    '                                    xlRange.Value = dtWork.ToString("yyyy/MM/dd")
    '                                    ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
    '                                    '請求期間終了年月
    '                                    xlRange = xlPSSheet.Cells(intOutputRow, ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE)
    '                                    xlRange.Value = dtWork.ToString("yyyy/MM/dd")
    '                                    ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
    '                                    'Listprice単価(提案時)
    '                                    strListPrice = objData(1, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL)
    '                                    xlRange = xlPSSheet.Cells(intOutputRow, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL)
    '                                    xlRange.Value = strListPrice
    '                                    ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
    '                                    'Listprice単価(Validation後)
    '                                    xlRange = xlPSSheet.Cells(intOutputRow, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH)
    '                                    xlRange.Value = strListPrice
    '                                    ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
    '                                    'ソートキー２
    '                                    xlRange = xlPSSheet.Cells(intOutputRow, intSortKey2Col)
    '                                    xlRange.Value = intYearCnt - 1
    '                                    ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)

    '                                    PCount = PCount + 1
    '                                Next
    '                            End If
    '                        End If
    '                    End If
    '                Next
    '            Next
    '            CiscoTable.AcceptChanges()

    '            Return PCount

    '        Catch ex As Exception
    '            Throw ex

    '        Finally
    '            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
    '            GC.Collect()
    '        End Try

    '    End Function

    '#End Region
    '1680 end CISCO MA(新規)を対象外にする

#Region "CISCO MA（既存）ファイルPS反映処理"
    ''' <summary>
    ''' 機能：CISCOMA(新規)以外反映
    ''' </summary>
    ''' <param name="xlSheetPs"></param>
    ''' <param name="isatData"></param>
    ''' <param name="PSTable"></param>
    ''' <param name="intOutputCnt"></param>
    ''' <param name="intSortKey2Col"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function IsatMAReflectionNew(ByRef xlSheetPs As Excel.Worksheet,
                                         ByVal isatData As IsatTable,
                                         ByRef PSTable As PSDataTable,
                                         ByRef intOutputCnt As Integer,
                                         ByVal intSortKey2Col As Integer) As Boolean

        Dim sbFilter As New StringBuilder
        Dim strPatternCd As String
        Dim strMtdl As String
        Dim rows() As DataRow
        Dim intRowCnt As Integer
        Dim intRowMax As Integer
        Dim intRow As Integer
        Dim strPayMethod As String
        Dim strPayMethodIsat As String
        Dim strPayMethodPs As String
        Dim strListPrice As String
        Dim strGroupNo As String
        Dim xlRange As Excel.Range
        Dim xlCells As Excel.Range
        Dim intAddRow As Integer
        Dim strRange As String
        Dim objData(,) As Object
        Dim intYearMax As Integer
        Dim strSvcStart As String
        Dim strSvcEnd As String
        Dim strPayStart As String
        Dim intYearCnt As Integer
        Dim intOutputRow As Integer
        Dim dtWork As Date
        Dim blnRet As Boolean
        Dim strSvcLevel As String
        Dim strFilter As String
        Dim strItem03 As String

        IsatMAReflectionNew = False

        Try
            '最終行取得
            intAddRow = ExcelWrite.GetLastRow(xlSheetPs, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)

            strFilter = IsatTable.COLUMN_NAME_BOX_FEATURE & "='B' AND " &
                        IsatTable.COLUMN_NAME_NEW_EXIST & "<>'新規' AND " &
                        IsatTable.COLUMN_NAME_MES_FLG & "=''"
            For Each rowIsat As DataRow In isatData.Select(strFilter, IsatTable.COLUMN_NAME_ROW)
                strMtdl = rowIsat.Item(IsatTable.COLUMN_NAME_TYPE) & "-" & rowIsat.Item(IsatTable.COLUMN_NAME_MODEL)
                strPatternCd = rowIsat.Item(IsatTable.COLUMN_NAME_PATTERN_CD)
                If strPatternCd <> "15" Then
                    strMtdl = strMtdl.Replace("-", "")
                End If
                sbFilter.Length = 0
                'START 変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo
                sbFilter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                sbFilter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD)
                sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
                sbFilter.Append(StringEdit.EncloseSingleQuotation(rowIsat.Item(IsatTable.COLUMN_NAME_PATTERN_CD)))
                Select Case strPatternCd
                    Case "18", "19", "41"
                    Case Else
                        sbFilter.Append(CommonConstant.SQL_STR_AND)
                        sbFilter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01)
                        sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
                        sbFilter.Append(StringEdit.EncloseSingleQuotation(strMtdl))
                End Select
                sbFilter.Append(CommonConstant.SQL_STR_AND)
                sbFilter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02)
                sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
                sbFilter.Append(StringEdit.EncloseSingleQuotation(rowIsat.Item(IsatTable.COLUMN_NAME_SERIAL)))
                sbFilter.Append(CommonConstant.SQL_STR_AND)
                sbFilter.Append("ReflectionFlg")
                sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
                sbFilter.Append(StringEdit.EncloseSingleQuotation("0"))
                sbFilter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                'sbFilter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                'sbFilter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01)
                'sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
                'sbFilter.Append(StringEdit.EncloseSingleQuotation(strMtdl))
                'sbFilter.Append(CommonConstant.SQL_STR_AND)
                'sbFilter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02)
                'sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
                'sbFilter.Append(StringEdit.EncloseSingleQuotation(rowIsat.Item(IsatTable.COLUMN_NAME_SERIAL)))
                'sbFilter.Append(CommonConstant.SQL_STR_AND)
                'sbFilter.Append("ReflectionFlg")
                'sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
                'sbFilter.Append(StringEdit.EncloseSingleQuotation("0"))
                'sbFilter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                'END   変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo

                '支払方法(ISAT見積)
                Debug.Print(sbFilter.ToString)
                Select Case rowIsat.Item(IsatTable.COLUMN_NAME_PAY_METHOD).ToString
                    Case "M"
                        strPayMethodIsat = "月額"
                    Case "A"
                        strPayMethodIsat = "年額"
                        'START 変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo
                    Case "O"
                        strPayMethodIsat = "一括"
                        'END   変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo
                    Case Else
                        strPayMethodIsat = ""
                End Select

                rows = PSTable.Select(sbFilter.ToString, "ExcelRow")
                If rows.Length > 0 Then
                    intRow = rows(0).Item("ExcelRow")

                    'Paymentの支払方法を取得
                    xlCells = xlSheetPs.Cells
                    xlRange = DirectCast(xlCells(intRow, ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD), Excel.Range)
                    strPayMethodPs = xlRange.Value
                    ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                    ExcelObjRelease.ReleaseExcelObj(xlCells, ExcelObjRelease.OBJECT_NOTHING)

                    '支払方法判定
                    blnRet = CheckPayMetod(rows, strPayMethodPs, strPayMethodIsat)
                    If blnRet = False Then
                        Continue For
                    End If

                    'ListPriceの合計を取得
                    strGroupNo = rowIsat.Item(IsatTable.COLUMN_NAME_GROUP_NO).ToString
                    'START 変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo
                    Select Case strPatternCd
                        Case "18", "19", "41"
                            strListPrice = rowIsat.Item(IsatTable.COLUMN_NAME_PRICE)
                        Case Else
                            strListPrice = CalcListPrice(isatData, strGroupNo)
                    End Select
                    'strListPrice = CalcListPrice(isatData, strGroupNo)
                    'END   変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo

                    If (strPayMethodPs = "月額" And strPayMethodIsat = "月額") Then
                        intRowMax = 0
                        strPayMethod = "月額"
                    ElseIf (strPayMethodPs = "年額" And strPayMethodIsat = "年額") Then
                        intRowMax = rows.Length - 1
                        strPayMethod = "年額"
                    ElseIf (strPayMethodPs = "月額" And strPayMethodIsat = "年額") Then
                        intRowMax = 0
                        strPayMethod = "年額"
                        'START 変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo
                    ElseIf strPayMethodIsat = "一括" Then
                        intRowMax = 0
                        strPayMethod = "一括"
                        'END   変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo
                    End If

                    For intRowCnt = 0 To intRowMax
                        intRow = rows(intRowCnt).Item("ExcelRow")
                        '項目３
                        xlCells = xlSheetPs.Cells
                        xlRange = DirectCast(xlCells(intRow, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03), Excel.Range)
                        'START 変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo
                        strItem03 = GetItem03(strPatternCd, isatData, rowIsat)
                        'If strPatternCd <> "21" Then
                        '    strItem03 = rowIsat.Item(IsatTable.COLUMN_NAME_DESCRIPTION)
                        'Else
                        '    strItem03 = rowIsat.Item(IsatTable.COLUMN_NAME_DESCRIPTION_CISCO)
                        'End If
                        'END   変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo
                        xlRange.Value = strItem03
                        ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                        ExcelObjRelease.ReleaseExcelObj(xlCells, ExcelObjRelease.OBJECT_NOTHING)
                        'START 変更管理#40（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo
                        If strPatternCd <> "20" And strPatternCd <> "18" And strPatternCd <> "19" And strPatternCd <> "41" Then
                            'If strPatternCd <> "20" Then
                            'END   変更管理#40（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo
                            '項目４
                            Select Case ExcelWrite.changeDBNullToString(rowIsat.Item(IsatTable.COLUMN_NAME_SVC_LEVEL))
                                Case "L17"
                                    strSvcLevel = "IOS 月～日 12時間"
                                Case "L57"
                                    strSvcLevel = "IOS 月～日 18時間"
                                Case "L58"
                                    strSvcLevel = "IOS 月～土 12時間"
                                Case "M0R"
                                    strSvcLevel = "ｽｰﾊﾟｰMA 月～日 24時間"
                                Case "M19"
                                    strSvcLevel = "IOS 月～日 24時間"
                                Case "M1L"
                                    strSvcLevel = "IOS 月～日 24時間"
                                Case "M3P"
                                    strSvcLevel = "IOS 月～土 12時間"
                                Case "SSA"
                                    strSvcLevel = "IOS 月～日 24時間"
                                Case "SSB"
                                    strSvcLevel = "IOS 月～日 24時間"
                                Case "NA1"
                                    strSvcLevel = "ESA BASE"
                                Case "NA2"
                                    strSvcLevel = "ESA HALF"
                                Case "NA3"
                                    strSvcLevel = "ESA MID"
                                Case "NA4"
                                    strSvcLevel = "ESA FULL"
                                Case "NB1"
                                    strSvcLevel = "ESB BASE"
                                Case "NB2"
                                    strSvcLevel = "ESB HALF"
                                Case "NB3"
                                    strSvcLevel = "ESB MID"
                                Case "NB4"
                                    strSvcLevel = "ESB FULL"
                                Case Else
                                    strSvcLevel = ""
                            End Select
                            xlCells = xlSheetPs.Cells
                            xlRange = DirectCast(xlCells(intRow, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM04), Excel.Range)
                            xlRange.Value = strSvcLevel
                            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                            ExcelObjRelease.ReleaseExcelObj(xlCells, ExcelObjRelease.OBJECT_NOTHING)
                        End If
                        '支払方法
                        xlCells = xlSheetPs.Cells
                        xlRange = DirectCast(xlCells(intRow, ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD), Excel.Range)
                        xlRange.Value = strPayMethod
                        ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                        ExcelObjRelease.ReleaseExcelObj(xlCells, ExcelObjRelease.OBJECT_NOTHING)
                        'ListPrice(単価)提案時
                        xlCells = xlSheetPs.Cells
                        xlRange = DirectCast(xlCells(intRow, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL), Excel.Range)
                        xlRange.Value = strListPrice
                        ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                        ExcelObjRelease.ReleaseExcelObj(xlCells, ExcelObjRelease.OBJECT_NOTHING)
                        'ListPrice(単価)Validation後
                        xlCells = xlSheetPs.Cells
                        xlRange = DirectCast(xlCells(intRow, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH), Excel.Range)
                        xlRange.Value = strListPrice
                        ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                        ExcelObjRelease.ReleaseExcelObj(xlCells, ExcelObjRelease.OBJECT_NOTHING)

                        '反映LINE_NO
                        xlCells = xlSheetPs.Cells
                        xlRange = DirectCast(xlCells(intRow, ExcelWrite.ExcelPaymentLineColumn.LINE_NO), Excel.Range)
                        rowIsat.Item(IsatTable.COLUMN_NAME_REFLECTION_LINE_NO) = xlRange.Value.ToString.PadLeft(8, "0")
                        ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                        ExcelObjRelease.ReleaseExcelObj(xlCells, ExcelObjRelease.OBJECT_NOTHING)
                        '反映FLG
                        rowIsat.Item(IsatTable.COLUMN_NAME_REFLECTION_FLG) = "1"

                        rows(intRowCnt).Item("ReflectionFlg") = "1"
                        intOutputCnt = intOutputCnt + 1

                        For Each rowMes As DataRow In isatData.Select(IsatTable.COLUMN_NAME_MES_FLG & "='M' and " &
                                                                      IsatTable.COLUMN_NAME_GROUP_NO & "=" & strGroupNo)
                            rowMes.Item(IsatTable.COLUMN_NAME_REFLECTION_LINE_NO) = rowIsat.Item(IsatTable.COLUMN_NAME_REFLECTION_LINE_NO)
                            rowMes.Item(IsatTable.COLUMN_NAME_REFLECTION_FLG) = "1"
                        Next
                    Next

                    If (strPayMethodPs = "月額" And strPayMethodIsat = "年額") Then
                        'Paymentの1行取得
                        intRow = Integer.Parse(ExcelWrite.changeDBNullToZero(rows(0).Item("ExcelRow")))
                        strRange = ExcelWrite.EXCEL_PAYMENT_LINE_RANGE.Replace("@", intRow.ToString)
                        Call ExcelWrite.GetCellValue(xlSheetPs, strRange, objData)
                        ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)

                        '年額の場合、支払年数を取得する
                        intYearMax = 1
                        strSvcStart = ExcelWrite.changeDBNullToString(objData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11))
                        strSvcEnd = ExcelWrite.changeDBNullToString(objData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12))
                        strPayStart = ExcelWrite.changeDBNullToString(objData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE))
                        If IsDate(strSvcStart) = True And IsDate(strSvcEnd) = True Then
                            intYearMax = Date.Parse(strSvcEnd).Year - Date.Parse(strSvcStart).Year
                            If Date.Parse(strSvcEnd).Month - Date.Parse(strSvcStart).Month >= 0 Then
                                intYearMax = intYearMax + 1
                            End If
                        End If

                        '支払年数-1の行数を最下行に追加する
                        xlRange = xlSheetPs.Range(intRow.ToString & ":" & intRow.ToString)
                        xlRange.Copy()
                        ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                        strRange = (intAddRow + 1).ToString & ":" & (intAddRow + intYearMax - 1).ToString()
                        xlRange = xlSheetPs.Range(strRange)
                        xlRange.PasteSpecial()
                        ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)

                        '年数分に行を追加する
                        For intYearCnt = 1 To intYearMax
                            If intYearCnt = 1 Then
                                '1年目は既にある行を書き換える
                                intOutputRow = intRow
                            Else
                                '2年目以降は行を追加する
                                intAddRow = intAddRow + 1
                                intOutputRow = intAddRow
                                intOutputCnt = intOutputCnt + 1

                                'NO
                                xlRange = xlSheetPs.Cells(intOutputRow, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)
                                xlRange.Value = 0
                                ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                            End If
                            '項目１１（ｻｰﾋﾞｽ期間開始）
                            dtWork = Date.Parse(strSvcStart).AddYears(intYearCnt - 1)
                            xlRange = xlSheetPs.Cells(intOutputRow, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11)
                            xlRange.Value = dtWork.ToString("yyyy/MM/dd")
                            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                            '項目１２（ｻｰﾋﾞｽ期間終了）
                            dtWork = Date.Parse(strSvcStart).AddYears(intYearCnt).AddDays(-1)
                            xlRange = xlSheetPs.Cells(intOutputRow, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12)
                            xlRange.Value = dtWork.ToString("yyyy/MM/dd")
                            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                            '請求期間開始年月
                            dtWork = Date.Parse(strPayStart).AddYears(intYearCnt - 1)
                            xlRange = xlSheetPs.Cells(intOutputRow, ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE)
                            xlRange.Value = dtWork.ToString("yyyy/MM/dd")
                            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                            '請求期間終了年月
                            xlRange = xlSheetPs.Cells(intOutputRow, ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE)
                            xlRange.Value = dtWork.ToString("yyyy/MM/dd")
                            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                            'Listprice単価(提案時)
                            strListPrice = objData(1, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL).ToString
                            xlRange = xlSheetPs.Cells(intOutputRow, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL)
                            xlRange.Value = strListPrice
                            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                            'Listprice単価(Validation後)
                            xlRange = xlSheetPs.Cells(intOutputRow, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH)
                            xlRange.Value = strListPrice
                            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                            'ソートキー２
                            xlRange = xlSheetPs.Cells(intOutputRow, intSortKey2Col)
                            xlRange.Value = intYearCnt - 1
                            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                        Next
                    End If
                End If
            Next
            PSTable.AcceptChanges()

            IsatMAReflectionNew = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "IsatMAReflectionNew")

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCells, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Function

    ''' <summary>
    ''' ListPriceの合計を取得
    ''' </summary>
    ''' <param name="isatData"></param>
    ''' <param name="strGroupNo"></param>
    ''' <param name="blnMesFlg"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CalcListPrice(ByVal isatData As IsatTable,
                                   ByVal strGroupNo As String,
                                   Optional ByVal intMesFlg As Integer = CD_MESFLG_NON) As String

        Dim strFilter As String
        Dim lngListPrice As Long = 0

        CalcListPrice = ""

        Try
            'START 変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo
            strFilter = IsatTable.COLUMN_NAME_GROUP_NO & "=" & strGroupNo & " AND " &
                        IsatTable.COLUMN_NAME_PAY_METHOD & "<>'O'"
            'strFilter = IsatTable.COLUMN_NAME_GROUP_NO & "=" & strGroupNo
            'END   変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo
            Select Case intMesFlg
                Case CD_MESFLG_NO
                    strFilter = strFilter & " AND " & IsatTable.COLUMN_NAME_MES_FLG & "=''"
                Case CD_MESFLG_ON
                    strFilter = strFilter & " AND " & IsatTable.COLUMN_NAME_MES_FLG & "='M'"
            End Select
            For Each row As DataRow In isatData.Select(strFilter)
                lngListPrice = lngListPrice + row.Item(IsatTable.COLUMN_NAME_PRICE)
            Next

            CalcListPrice = lngListPrice.ToString

        Catch ex As Exception

        End Try

    End Function

    'START 変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo
    ''' <summary>
    ''' 項目０３の値を取得
    ''' </summary>
    ''' <param name="strPatternCd"></param>
    ''' <param name="pl"></param>
    ''' <param name="drIsat"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetItem03(ByVal strPatternCd As String, ByVal isatData As IsatTable, ByVal drIsat As DataRow) As String

        Dim strFilter As String
        Dim rows() As DataRow

        GetItem03 = ""

        Try
            Select Case strPatternCd
                Case "18", "19"
                    strFilter = IsatTable.COLUMN_NAME_FILE_NAME & "='" & drIsat.Item(IsatTable.COLUMN_NAME_FILE_NAME) & "' and " &
                                IsatTable.COLUMN_NAME_SERIAL & "='" & drIsat.Item(IsatTable.COLUMN_NAME_SERIAL) & "' and " &
                                IsatTable.COLUMN_NAME_PAY_METHOD & "<>'O'"
                    rows = isatData.Select(strFilter)
                    If rows.Length > 0 Then
                        GetItem03 = rows(0).Item(IsatTable.COLUMN_NAME_DESCRIPTION)
                    End If

                Case "21"
                    GetItem03 = drIsat.Item(IsatTable.COLUMN_NAME_DESCRIPTION_CISCO)
                Case Else
                    GetItem03 = drIsat.Item(IsatTable.COLUMN_NAME_DESCRIPTION)
            End Select

        Catch ex As Exception
            Throw ex

        End Try

    End Function
    'END   変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo

    ''' <summary>
    ''' 機能：構成＋MESのListPrice
    ''' </summary>
    ''' <param name="CiscoTable"></param>
    ''' <param name="strGroupNo"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CalcListPrice(ByVal CiscoTable As CiscoMATable, ByVal strGroupNo As String)

        Dim lngListPrice As Long = 0

        CalcListPrice = ""

        Try
            For Each row As DataRow In CiscoTable.Select("Cell_GroupNo='" & strGroupNo & "'")
                lngListPrice = lngListPrice + Long.Parse(row.Item("Cell_ListPrice"))
            Next

            CalcListPrice = lngListPrice.ToString

        Catch ex As Exception
            Throw ex
        End Try

    End Function

    ''' <summary>
    ''' 機能：支払方法判定
    ''' </summary>
    ''' <param name="rowsPs"></param>
    ''' <param name="strPayMethodPs"></param>
    ''' <param name="strPayMethodIsat"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckPayMetod(ByVal rowsPs() As DataRow,
                                   ByVal strPayMethodPs As String,
                                   ByVal strPayMethodIsat As String) As Boolean

        Dim rowPs As DataRow
        Dim blnAnnual As Boolean = False
        Dim MonthlyFee As Boolean = False

        CheckPayMetod = False

        Try
            If (strPayMethodPs = "月額" And strPayMethodIsat = "月額") Or
                (strPayMethodPs = "年額" And strPayMethodIsat = "年額") Or
                (strPayMethodPs = "月額" And strPayMethodIsat = "年額") Then

                '見積が年額の場合、Paymentが年額のみか判定する
                '※月額がある場合、反映対象外とする
                If strPayMethodIsat = "年額" Then
                    For Each rowPs In rowsPs
                        If ExcelWrite.changeDBNullToString(rowPs.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD)) = "年額" Then
                            blnAnnual = True
                        Else
                            MonthlyFee = True
                        End If
                    Next
                    If blnAnnual = True And MonthlyFee = True Then
                        Exit Function
                    End If
                End If
                'START 変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo
            ElseIf strPayMethodIsat = "一括" Then
                'END   変更管理#39（No.1544&1548 ISAT見積ﾌｧｲﾙ)　2017/04 sugo
            Else
                Exit Function
            End If


            CheckPayMetod = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "CheckPayMetod")

        End Try

    End Function

#End Region

#End Region

End Class
