﻿Public Class CommonVariable
#Region "メンバ変数"
    Private Shared _authority As String         '権限
    Private Shared _userID As String            'ユーザID
    Private Shared _userPw As String            'PW
    Private Shared _cpno As String              'CPNO
    Private Shared _contractNo As Integer       '契約順番
    Private Shared _customerName As String      'お客様名
    Private Shared _contractNoName As String    '契約順番名
    Private Shared _paLevel As String           'PALevel
    Private Shared _anniversary As String       'アニバーサリー
    Private Shared _contractstart As Date       '契約開始年月日
    Private Shared _contractend As Date         '契約終了年月日
    Private Shared _paymentstart As Date        'Payment開始年月日
    Private Shared _osVersion As String         'OSのバージョン
    Private Shared _obamatitle As String        'Clientタイトル
    Private Shared _paymentPW As String         'PaymentのPW 　　　　※シート/ブックの保護解除
    Private Shared _summaryPW As String         '価格承認サマリのPW　※シート/ブックの保護解除
    Private Shared _businessPW As String        'BusinessCaseサマリ　※シート/ブックの保護解除
    Private Shared _paymentperiod As Integer    'Payment展開期間
    Private Shared _mdbPW As String             'MDBのPW（共通）
#End Region

#Region "プロパティ"
    ''' <summary>
    ''' OSのバージョン
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Property OSVERSION() As String
        Set(ByVal value As String)
            _osVersion = value
        End Set
        Get
            Return _osVersion
        End Get
    End Property

    ''' <summary>
    ''' 権限
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Property AUTHORITY() As String
        Set(ByVal value As String)
            _authority = value
        End Set
        Get
            Return _authority
        End Get
    End Property

    ''' <summary>
    ''' ユーザID
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Property USERID() As String
        Set(ByVal value As String)
            _userID = value
        End Set
        Get
            Return _userID
        End Get
    End Property

    ''' <summary>
    ''' PW
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Property USERPW() As String
        Set(ByVal value As String)
            _userPw = value
        End Set
        Get
            Return _userPw
        End Get
    End Property

    ''' <summary>
    ''' CPNO
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Property CPNO() As String
        Set(ByVal value As String)
            _cpno = value
        End Set
        Get
            Return _cpno
        End Get
    End Property

    ''' <summary>
    ''' 契約順番
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Property CONTRACTNO() As Integer
        Set(ByVal value As Integer)
            _contractNo = value
        End Set
        Get
            Return _contractNo
        End Get
    End Property

    ''' <summary>
    ''' お客様名
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Property CUSTOMERNAME() As String
        Set(ByVal value As String)
            _customerName = value
        End Set
        Get
            Return _customerName
        End Get
    End Property

    ''' <summary>
    ''' 契約順番名
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Property CONTRACTNONAME() As String
        Set(ByVal value As String)
            _contractNoName = value
        End Set
        Get
            Return _contractNoName
        End Get
    End Property

    ''' <summary>
    ''' PALevel
    ''' </summary>
    ''' <value>PALevel</value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Property PALEVEL() As String
        Set(ByVal value As String)
            _paLevel = value
        End Set
        Get
            Return _paLevel
        End Get
    End Property

    ''' <summary>
    ''' アニバーサリー
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Property ANNIVERSARY() As String
        Set(ByVal value As String)
            _anniversary = value
        End Set
        Get
            Return _anniversary
        End Get
    End Property

    ''' <summary>
    ''' 契約開始年月
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Property ContractStart() As Date
        Set(ByVal value As Date)
            _contractstart = value
        End Set
        Get
            Return _contractstart
        End Get
    End Property

    ''' <summary>
    ''' 契約終了年月
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Property ContractEnd() As Date
        Set(ByVal value As Date)
            _contractend = value
        End Set
        Get
            Return _contractend
        End Get
    End Property

    ''' <summary>
    ''' Payment開始
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Property PaymentStart() As Date
        Set(ByVal value As Date)
            _paymentstart = value
        End Set
        Get
            Return _paymentstart
        End Get
    End Property

    ''' <summary>
    ''' Clientタイトル
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Property OBAMATITLE() As String
        Set(ByVal value As String)
            _obamatitle = value
        End Set
        Get
            Return _obamatitle
        End Get
    End Property

    ''' <summary>
    ''' PaymentのPW
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Property PaymentPW() As String
        Set(ByVal value As String)
            _paymentPW = value
        End Set
        Get
            Return _paymentPW
        End Get
    End Property

    ''' <summary>
    ''' 価格承認サマリのPW
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Property SummaryPW() As String
        Set(ByVal value As String)
            _summaryPW = value
        End Set
        Get
            Return _summaryPW
        End Get
    End Property

    ''' <Business>
    ''' BusinessCaseSummaryのPW
    ''' </Business>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Property BusinessPW() As String
        Set(ByVal value As String)
            _businessPW = value
        End Set
        Get
            Return _businessPW
        End Get
    End Property

    ''' <Business>
    ''' Payment展開期間
    ''' </Business>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Property PaymentPeriod() As Integer
        Set(ByVal value As Integer)
            _paymentperiod = value
        End Set
        Get
            Return _paymentperiod
        End Get
    End Property

    Public Shared Property MdbPW() As String
        Set(ByVal value As String)
            _mdbPW = value
        End Set
        Get
            Return _mdbPW
        End Get
    End Property

#End Region

End Class
