﻿Imports System.Text
Imports System.IO
Imports System.Reflection
Imports System.Data.OleDb

Imports MUSE.WinUI.CommonVariable
Imports MUSE.Utility
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.SharedStructure
Imports MUSE.Utility.UserDataSet
Imports MUSE.Utility.UserDataTable.Master
Imports MUSE.Utility.UserDataTable.Transaction
Imports MUSE.Utility.UserDataTable.Work
Imports MUSE.Utility.UserMessageBox
Imports MUSE.Utility.UserException
Imports MUSE.Utility.OioBamaCommmon
Imports MUSE.Utility.XmlClass.Parameter
Imports MUSE.Utility.XmlClass.SystemInfo
Imports MUSE.Controller

Imports Microsoft.Office.Interop
Imports System.Net
Imports MUSE.Utility.XmlClass.SheetFoumulate
Imports MUSE.Utility.SharedClass.ExcelWrite

Public Class Frm_NewImportExport

#Region "定数"
    ''出力のダイアルログ画面
    Private EXPORTDIALOG_FILTER_XLS As String = "ﾍﾟｲﾒﾝﾄｼｰﾄ ﾌｧｲﾙ (*.xlsm)|*.xlsm"
    Private EXPORTDIALOG_DEFULT_PATH As String = "../Excel/"

    ''処理中ダイアログ表示用
    Private Const STR_CREATING_IN As String = "インポート中・・「Ctl+Cﾎﾞﾀﾝ」を押さないでください。"
    Private Const STR_CREATING_EX As String = "エクスポート中・・"
#End Region

#Region "変数"
    Private _CPNO As String = ""
    Private _CONTRACT As String = ""
    Private _MODIFY As String = ""
    Private OioBamaUrl As String
#End Region

#Region "プロパティ"
    Public Property prCPNO As String
        Get
            Return _CPNO
        End Get
        Set(ByVal value As String)
            _CPNO = value
        End Set
    End Property

    Public Property prCONTRACT As String
        Get
            Return _CONTRACT
        End Get
        Set(ByVal value As String)
            _CONTRACT = value
        End Set
    End Property
    Public Property prMODIFY As String
        Get
            Return _MODIFY
        End Get
        Set(ByVal value As String)
            _MODIFY = value
        End Set
    End Property

#End Region

#Region "コンストラクタ"
    ''' <summary>
    ''' 機　能：コンスラクタ
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub New(ByVal CPNO As String, _
                   ByVal MODIFY As String)

        ' この呼び出しはデザイナーで必要です。
        InitializeComponent()

        Me.prCPNO = CPNO
        Me.prMODIFY = MODIFY

        ' InitializeComponent() 呼び出しの後で初期化を追加します。

    End Sub
#End Region

#Region "イベントハンドラ"

    ''' <summary>
    ''' 機　能：フォームロードイベント
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Frm_ImportExport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Me.Text = CommonVariable.OBAMATITLE

        'CUST_NAME , CPNO 
        Dim oioCnt As New MUSE.Controller.OioControl

        System.Environment.CurrentDirectory = Application.StartupPath

        Me.BtnExportGo.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.BtnExportGo.Name)
        Me.btnDirectImport.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.btnDirectImport.Name)
        Me.btnImportCsv.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.btnImportCsv.Name)
        Me.btnImportCsvMdb.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.btnImportCsvMdb.Name)
        Me.btnExPayment.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.btnExPayment.Name)
        Me.BtnDispExplorer.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.BtnDispExplorer.Name)
        Me.BtnRefresh.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.BtnRefresh.Name)

        Dim cOleDbAcc As New OleDbAcc.OleDbCpnoBpt
        Dim dt As DataTable
        dt = cOleDbAcc.getCpno(_CPNO)
        If dt.Rows.Count = 0 Then
            MsgBox("存在しないCPNOのファイルが選択されました。", MsgBoxStyle.Critical, Me.Name)
            dt = Nothing
            Exit Sub
        Else
            Me.txtCpno.Text = _CPNO
            Me.txtModifyNo.Text = _MODIFY.PadLeft(3, "0c")
            txtCpnoName.Text = dt.Rows(0).Item(1).ToString & "(" & dt.Rows(0).Item(0).ToString & ")"
            txtCustomerName.Text = dt.Rows(0).Item(0).ToString

        End If

        'OIO-BAMAｻｰﾊﾞｰのURLをLocalConnectionInfo.xmlから取得
        Dim mmc As New MasterMdbControl
        OioBamaUrl = mmc.GetMasterMbdPath.OioBama_Url & "index.jsp"
        '画面に設定
        lnkURL.Text = OioBamaUrl
        txtContract.Text = CommonVariable.CONTRACTNO.ToString.PadLeft(3, "0c")

        dt = Nothing
        '更新日時の初期化
        lblPsExUpdate.Text = ""
        lblPsInUpdate.Text = ""

        ''*******************************
        ''** 各ﾌｧｲﾙを初期表示する **
        ''*******************************
        ''①Export画面のPaymentSheet
        ''ファイル名の取得
        Dim fileNM As String
        Dim fileManage As New OioFileManage
        fileNM = fileManage.GetLocalCPNOFolder(Me.txtCpno.Text, Me.txtContract.Text)
        fileNM = fileNM & fileManage.GetPaymentLineExcelFileNm(Me.txtCpno.Text, Me.txtContract.Text)

        ''個別PSの存在チェック
        Dim ofm As New OioFileManage
        If File.Exists(fileNM) = True Then
            txtExPayment.Text = fileNM
            '個別PSの更新日時を取得
            Dim PSO As Object
            PSO = CreateObject("Scripting.FileSystemObject")
            lblPsExUpdate.Text = PSO.GetFile(fileNM).DateLastModified
            PSO = Nothing
        End If

        '1720 str
        'btnDirectImport.Text = "サーバ直接" & vbCrLf & "インポート"
        btnDirectImport.Text = "サーバ直接" & vbCrLf & "エクスポート"
        '1720 end

    End Sub

    ''' <summary>
    ''' 機　能：ログアウトボタンクリック
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub btnLogOut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogOut.Click
        Me.Close()
    End Sub

    ''' <summary>
    ''' 機　能：メニューへボタンクリック
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub btnReturn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReturn.Click
        Dim frm As New Frm_Menu()

        Me.Hide()

        frm.ShowDialog()
        Me.Close()
    End Sub

    ''' <summary>
    ''' 機　能：フォルダ表示ボタン
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub BtnDispExplorer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnDispExplorer.Click

        ''Explorer表示
        Dim ofm As New OioFileManage
        If ofm.DispExplorer(CommonConstant.FOLDERNAME_CSV2, CommonVariable.CPNO, CommonVariable.CONTRACTNO) = False Then
            MsgBox(FileReader.GetMessage("MSG_0208"), MsgBoxStyle.Exclamation, "")
        End If
    End Sub

    ''' <summary>
    ''' 機　能：リンククリック
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkURL.LinkClicked
        lnkURL.LinkVisited = True
        System.Diagnostics.Process.Start(OioBamaUrl)
    End Sub

    ''' <summary>
    ''' 機　能：Export画面_PaymentSheet参照ボタン
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub btnExPayment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExPayment.Click

        Dim dialog As OpenFileDialog = New OpenFileDialog
        dialog.Filter = EXPORTDIALOG_FILTER_XLS
        System.Environment.CurrentDirectory = Application.StartupPath

        Dim ReferencePath As String = System.IO.Path.GetFullPath(EXPORTDIALOG_DEFULT_PATH & "\" & _
                                                             Me.txtCpno.Text.PadLeft(8, "0c") & "_" & _
                                                             Convert.ToInt32(Me.txtContract.Text).ToString.PadLeft(3, "0c"))
        If Directory.Exists(ReferencePath) = False Then
            MsgBox(FileReader.GetMessage("MSG_0261"), MsgBoxStyle.Critical, Me.Name)
            lblPsExUpdate.Text = ""
            Exit Sub
        End If
        dialog.InitialDirectory = ReferencePath

        If dialog.ShowDialog() = DialogResult.OK Then

            Dim fileName As String = dialog.FileName
            txtExPayment.Text = fileName

            If CheckCPnoEx() = False Then
                MsgBox(FileReader.GetMessage("MSG_0446"), MsgBoxStyle.Critical, Me.Name)
                txtExPayment.Text = ""
                lblPsExUpdate.Text = ""
                Exit Sub
            End If

            ''個別PSのOPEN済みファイルチェック
            Dim ofm As New OioFileManage
            If ofm.ChkOpenedExcelFile(fileName) = True Then
                '個別PSの更新日時を取得
                Dim PSO As Object
                PSO = CreateObject("Scripting.FileSystemObject")
                lblPsExUpdate.Text = PSO.GetFile(fileName).DateLastModified
                PSO = Nothing

            Else
                Call MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0417"), Me.Text)
                txtExPayment.Text = ""
                Exit Sub
            End If
        End If

    End Sub

    Private Sub btnImportFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        ''Explorer表示
        Dim ofm As New OioFileManage
        If ofm.DispExplorer(CommonConstant.FOLDERNAME_CSV1, CommonVariable.CPNO, CommonVariable.CONTRACTNO) = False Then
            MsgBox(FileReader.GetMessage("MSG_0208"), MsgBoxStyle.Exclamation, "")
        End If

    End Sub

    ''' <summary>
    ''' ﾌｧｲﾙ名ﾘﾌﾚｯｼｭボタンクリック
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub BtnRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnRefresh.Click

        ''①Export画面のPaymentSheet
        ''ファイル名の取得
        Dim fileNM As String
        Dim fileManage As New OioFileManage
        lblPsExUpdate.Text = ""
        txtExPayment.Text = ""

        fileNM = fileManage.GetLocalCPNOFolder(Me.txtCpno.Text, Me.txtContract.Text)
        fileNM = fileNM & fileManage.GetPaymentLineExcelFileNm(Me.txtCpno.Text, Me.txtContract.Text)

        If TabImportExport.SelectedTab.Text = "エクスポート　EXCEL→CSV 変換" Then
            ''個別PSの存在チェック
            If File.Exists(fileNM) = True Then
                Dim ofm As New OioFileManage
                If ofm.ChkOpenedExcelFile(fileNM) = True Then
                    txtExPayment.Text = fileNM

                    '個別PSの更新日時を取得
                    Dim PSO As Object
                    PSO = CreateObject("Scripting.FileSystemObject")
                    lblPsExUpdate.Text = PSO.GetFile(fileNM).DateLastModified
                    PSO = Nothing
                Else
                    Call MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0417"), Me.Text)
                    'ｴﾗｰが発生した場合はﾒﾆｭｰ画面に戻る
                    Dim frm As New Frm_Menu()
                    Me.Hide()
                    frm.ShowDialog()
                    Me.Close()
                End If

            Else
                Call MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0326"), Me.Text)
                Exit Sub
            End If
        End If

    End Sub

    ''' <summary>
    ''' 機能：タブ切り替えによる取込対象有無の選択表示
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub TabControl1_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles TabImportExport.SelectedIndexChanged

        Select Case Me.TabImportExport.SelectedIndex

            Case 0 'Export画面
                Me.BtnRefresh.Visible = True

            Case 1 'Import画面
                Me.BtnRefresh.Visible = False
        End Select

    End Sub

#End Region

#Region "Importボタンの処理"
    ''' <summary>
    ''' 機能：各ｲﾝﾎﾟｰﾄﾎﾞﾀﾝ処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub BtnImport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnImportCsv.Click,
                                                                                                    btnImportMdb.Click,
                                                                                                    btnImportCsvMdb.Click
        Dim frmWait As New Frm_WaitDialog
        Dim OUTERR As New OutputErrorList
        Dim blnRet As Boolean
        Dim alPsCreating As New ArrayList
        Dim alPsCreated As New ArrayList
        Dim alPsdCreating As New ArrayList
        Dim alPsdCreated As New ArrayList
        Dim alPsCreatingMdb As New ArrayList                        '作成中PaymentのMDB
        Dim alPsdCreatingMdb As New ArrayList                       '作成中詳細のMDB
        Dim strExcelYear As String
        Dim usedFilePath As ImportCsv.usedFilePath
        Dim importCount As ImportCsv.ImportCount                      ''取込成功件数
        Dim importErrCount As ImportCsv.ImportErrCount                ''取込失敗件数
        Dim strCreateTime = Now.ToString("yyyyMMdd_HHmmss")
        Dim dtStart As Date = Now
        Dim strMsg As String
        Dim ic As New ImportCsv
        Dim strErrMsg As String
        Dim strDownloadCsvPath As String                                'CSVﾀﾞｳﾝﾛｰﾄﾞﾊﾟｽ
        Dim ofm As New OioFileManage
        Dim intImportCd As Integer
        Dim blnImportMDB As Boolean
        Dim strContractNo As String = ""
        Dim strLockFlag As String = ""

        Try
            '==========================================
            '初期化
            '==========================================
            OUTERR.CpNo = Me.txtCpno.Text
            OUTERR.ContractNo = Me.txtContract.Text
            Select Case sender.name
                Case "btnImportCsv"
                    strMsg = "Import(作成中のみ)"
                    blnImportMDB = False
                    intImportCd = ImportCsv.CD_IMPORT_CSV
                    strContractNo = CommonVariable.CONTRACTNO.ToString
                Case "btnImportMdb"
                    strMsg = "Import(契約済のみ)"
                    blnImportMDB = True
                    intImportCd = ImportCsv.CD_IMPORT_MDB
                    strLockFlag = "C"
                Case "btnImportCsvMdb"
                    strMsg = "Import(作成中＋契約済)"
                    blnImportMDB = False
                    intImportCd = ImportCsv.CD_IMPORT_CSVMDB
            End Select
            OUTERR.OutImportErrorList("START", strMsg, , , , True)
            Call SetInitWaitDialog(frmWait, "")

            '==========================================
            'MasterMDB存在チェック
            '==========================================
            If ofm.CheckExistsMdb(OioFileManage.enmMdbType.Master, CommonVariable.MdbPW, strMsg) = False Then
                Call CloseWaitDialog(frmWait)
                OUTERR.OutImportErrorList("END", "Import")
                Call MuseMessageBox.ShowError(strMsg, Me.Text)
                Exit Sub
            End If

            '==========================================
            'Masterバージョンチェック
            '==========================================
            If ofm.CheckMdbVersion(CommonVariable.MdbPW,
                                   OioFileManage.enmMdbType.Master,
                                   strErrMsg,
                                   CommonVariable.CPNO) = False Then
                Call CloseWaitDialog(frmWait)
                OUTERR.OutImportErrorList("END", "Import")
                Call MuseMessageBox.ShowError(strErrMsg, Me.Text)
                Return
            End If

            '==========================================
            'サーバーからCSVデータ取得
            '==========================================
            frmWait.ProgressValue = 1
            Call SetMsgWaitDialog(frmWait, FileReader.GetMessage("MSG_0461"))
            Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0430"))
            ''Csv取得
            Dim filePath As ImportCsv.ServerCsvPath
            strDownloadCsvPath = ofm.GetLocalCsv1Folder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            blnRet = ic.GetServerCsv(blnImportMDB, strContractNo, strLockFlag, strDownloadCsvPath, filePath, strErrMsg)
            If blnRet = False Then
                Call CloseWaitDialog(frmWait)
                OUTERR.OutImportErrorList("END", "Import")

                MsgBox(strErrMsg, MsgBoxStyle.Critical, Me.Text)
                Exit Sub
            End If

            Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0431"))

            '==========================================
            'テンプレファイル更新
            '==========================================
            frmWait.ProgressValue = 2
            If intImportCd <> ImportCsv.CD_IMPORT_MDB Then
                Call SetMsgWaitDialog(frmWait, FileReader.GetMessage("MSG_0460"))
                Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0468"))
                If ofm.CopyGSATmpFile(OioFileManage.enmTmpFileType.Payment, strErrMsg) = False Then
                    Call CloseWaitDialog(frmWait)
                    OUTERR.OutImportErrorList(strErrMsg, "Import")
                    Call MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0392"), Me.Text)
                    Exit Sub
                End If
                Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0469"))
            End If

            '==========================================
            'データを配列に保存（Refresh、Validation以外）
            '==========================================
            frmWait.ProgressValue = 3
            Call SetMsgWaitDialog(frmWait, FileReader.GetMessage("MSG_0462"))
            Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0463"))
            blnRet = ic.GetCsvData(intImportCd,
                                   filePath,
                                   CommonVariable.PaymentPeriod,
                                   alPsCreating,
                                   alPsCreatingMdb,
                                   alPsCreated,
                                   alPsdCreating,
                                   alPsdCreatingMdb,
                                   alPsdCreated,
                                   importCount,
                                   importErrCount,
                                   OUTERR,
                                   True,
                                   frmWait)
            If blnRet = False Then
                Call CloseWaitDialog(frmWait)
                Call MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0392"), Me.Text)
                Exit Sub
            End If
            Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0464"))

            '==========================================
            'TempMDBに保存
            '==========================================
            strExcelYear = CommonVariable.PaymentStart.ToString("yyyy")
            If intImportCd <> ImportCsv.CD_IMPORT_CSV Then
                frmWait.ProgressValue = 4
                SetMsgWaitDialog(frmWait, FileReader.GetMessage("MSG_0335"))
                Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0336"))
                '締結済みMDB保存
                blnRet = ic.ImportDb(alPsCreated,
                                     alPsdCreated,
                                     strExcelYear,
                                     importCount,
                                     OUTERR,
                                     True,
                                     False,
                                     frmWait)
                If blnRet = False Then
                    Call CloseWaitDialog(frmWait)
                    MsgBox(FileReader.GetMessage("MSG_0338"), vbCritical)
                    Exit Sub
                End If
                Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0337"))

                '作成中MDB保存
                frmWait.ProgressValue = 5
                SetMsgWaitDialog(frmWait, FileReader.GetMessage("MSG_0335"))
                Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0336"))
                blnRet = ic.ImportDb(alPsCreatingMdb,
                                     alPsdCreatingMdb,
                                     strExcelYear,
                                     importCount,
                                     OUTERR,
                                     True,
                                     True,
                                     frmWait)
                If blnRet = False Then
                    Call CloseWaitDialog(frmWait)
                    MsgBox(FileReader.GetMessage("MSG_0338"), vbCritical)
                    Exit Sub
                End If

                blnRet = ofm.CheckMdbCount(CommonVariable.MdbPW,
                                           CommonVariable.CPNO,
                                           True,
                                           True,
                                           importCount.MDBCount,
                                           importCount.MDBDetailCount,
                                           importCount.CreatingMdbCount,
                                           importCount.CreatingMdbDetailCount)
                If blnRet = False Then
                    Call CloseWaitDialog(frmWait)
                    Exit Sub
                End If

                Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0337"))
            End If

            '==========================================
            'Excel出力
            '==========================================
            frmWait.ProgressValue = 6
            If intImportCd <> ImportCsv.CD_IMPORT_MDB Then
                SetMsgWaitDialog(frmWait, FileReader.GetMessage("MSG_0465"))
                Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0466"))
                blnRet = OutputExcel(filePath,
                                     alPsCreating,
                                     alPsdCreating,
                                     strExcelYear,
                                     strCreateTime,
                                     usedFilePath,
                                     importCount,
                                     importErrCount,
                                     frmWait,
                                     OUTERR)
                If blnRet = False Then
                    Call CloseWaitDialog(frmWait)
                    Call MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0392"), Me.Text)
                    Exit Sub
                End If

                'Paymentの出力件数判定
                blnRet = CheckPaymentOutputCount(usedFilePath.PaymentPath, importCount)
                If blnRet = False Then
                    Call CloseWaitDialog(frmWait)
                    Exit Sub
                End If

                Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0467"))
            End If

            '==========================================
            '終了処理
            '==========================================
            frmWait.ProgressValue = 7
            Call CloseWaitDialog(frmWait)
            OUTERR.OutImportErrorList("処理時間：" & (Now - dtStart).ToString, "Import")
            OUTERR.OutImportErrorList("END", "Import")

            '画面表示
            Me.txtInPaymentSheet.Text = filePath.PSCsv
            Me.lblPsInUpdate.Text = filePath.PSUpdTime

            '完了メッセージ
            Call CompleteImportMessage(sender.name, importCount, importErrCount, usedFilePath)

        Catch ex As Exception
            Call CloseWaitDialog(frmWait)
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical)

        End Try

    End Sub

#End Region

#Region "Exportボタンの処理"

    ''' <summary>
    ''' Export処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub BtnExportGo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnExportGo.Click,
                                                                                                      btnDirectImport.Click

        Dim blnRet As Boolean

        Try
            Me.Enabled = False
            Me.Refresh()

            '''' 処理：エクスポートメイン処理
            blnRet = ExportMain(sender.name)
            Me.Enabled = True
            If blnRet = False Then
                Exit Sub
            End If

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "")

        End Try

    End Sub
#End Region

#Region "プライベートメソッド"
    ''' <summary>
    ''' エクスポートメイン処理
    ''' </summary>
    ''' <param name="strButtonName">ボタン名</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ExportMain(ByVal strButtonName As String) As Boolean

        Dim rtnPaymentCsvCount As Integer
        Dim rtnKobetuSyousaiCsvCount As Integer
        Dim msgStr As String = ""
        Dim strPsPath As String = ""
        Dim strPsName As String = ""
        Dim strDitailPath As String = ""
        Dim strDitailName As String = ""
        Dim OUTERR As New OutputErrorList           'エラーログ定義
        Dim waitDialog As New Frm_WaitDialog        '処理中ダイアログ定義
        Dim OutCsv As OutputCsv = New OutputCsv
        Dim strConstractNo As String = 0
        Dim blnRet As Boolean
        Dim ofm As New OioFileManage

        ExportMain = False

        Try
            rtnPaymentCsvCount = 0
            rtnKobetuSyousaiCsvCount = 0

            OUTERR.CpNo = Me.txtCpno.Text
            OUTERR.ContractNo = Me.txtContract.Text
            OUTERR.OutExportErrorList("START", "Export", , , True)

            '処理中ダイアログ表示
            Call SetExportWaitDialogInitDate(waitDialog)
            waitDialog.Show()
            waitDialog.Refresh()

            ''画面の入力値チェック
            waitDialog.lbl_Message.Text = "画面入力チェック"
            waitDialog.Activate()
            waitDialog.Refresh()
            If Trim(txtExPayment.Text) = "" Then
                Call MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0447"), Me.Text)
                Exit Function
            End If

            'MDB存在チェック
            waitDialog.lbl_Message.Text = "MasterMDB存在チェック"
            waitDialog.Activate()
            waitDialog.Refresh()
            Dim strErrMsg As String
            If ofm.CheckExistsMdb(OioFileManage.enmMdbType.Master, CommonVariable.MdbPW, strErrMsg) = False Then
                Call MuseMessageBox.ShowError(strErrMsg, Me.Text)
                Exit Function
            End If

            ''Excelが書込可能な状態か判定
            waitDialog.lbl_Message.Text = "Payment Openチェック"
            waitDialog.Activate()
            waitDialog.Refresh()
            If ofm.ChkOpenedExcelFile(txtExPayment.Text) = False Then
                Call MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0417"), Me.Text)
                Exit Function
            End If

            ''Version管理機能強化 
            waitDialog.lbl_Message.Text = "Payment Versionチェック"
            waitDialog.Activate()
            waitDialog.Refresh()
            Dim msg As String
            If ofm.ChkFileVer(Me.txtExPayment.Text, msg) = False Then
                Call MuseMessageBox.ShowError(msg, Me.Text)
                Exit Function
            End If

            ''Errorシートの更新
            waitDialog.lbl_Message.Text = "Payment Errorシート更新"
            waitDialog.Activate()
            waitDialog.Refresh()
            Dim strRetMsg As String = ""
            If ExcelWrite.KickVBASuffixUpAct(ExcelWrite.VBActNMList.Export, Me.txtExPayment.Text, CommonVariable.USERID, CommonVariable.USERPW, True, strRetMsg) = False Then
                Exit Function
            End If
            Select Case strRetMsg
                Case "Client未導入"
                    If MsgBox(FileReader.GetMessage("MSG_0424"), MsgBoxStyle.Information + MsgBoxStyle.YesNo) = MsgBoxResult.No Then
                        Exit Function
                    End If
                Case "ｻｰﾊﾞｰ接続無し"
                    If MsgBox(FileReader.GetMessage("MSG_0425"), MsgBoxStyle.Information + MsgBoxStyle.YesNo) = MsgBoxResult.No Then
                        Exit Function
                    End If
                Case "ｴﾗｰ1", "ｴﾗｰ2"
                    MsgBox(FileReader.GetMessage("MSG_0426"), MsgBoxStyle.Exclamation)
                    Exit Function
            End Select

            ''作成日時のセット
            Dim createTime As String
            createTime = Now.ToString("yyyyMMdd_HHmmss")

            '契約順番
            strConstractNo = Me.txtModifyNo.Text.PadLeft(3, "0c")

            ''========================================================
            ''              　以下、個別ＰＳの処理
            ''========================================================
            ''個別ＰＳの処理を開始しました。
            OutLogExportStrMsg(OUTERR, FileReader.GetMessage("MSG_0283"))
            waitDialog.lbl_Message.Text = "Paymentｼｰﾄ出力"
            waitDialog.Activate()
            waitDialog.Refresh()

            'Req.1710：エクスポート機能変更 2018/12 Str
            ''PaymentSheetCsv出力
            'rtnPaymentCsvCount = OutCsv.WriteCsv(Me.txtExPayment.Text, _
            '                                     CommonVariable.CUSTOMERNAME, _
            '                                     Me.txtCpno.Text, _
            '                                     strConstractNo, _
            '                                     strPsPath, _
            '                                     strPsName, _
            '                                     createTime)
            rtnPaymentCsvCount = OutCsv.WriteCsv2(Me.txtExPayment.Text, _
                                                  CommonVariable.CUSTOMERNAME, _
                                                  Me.txtCpno.Text, _
                                                  strConstractNo, _
                                                  strPsPath, _
                                                  strPsName, _
                                                  createTime,
                                                  strErrMsg)

            If strErrMsg <> "" Then
                Call MuseMessageBox.ShowError(strErrMsg, Me.Text)
                Exit Function
            End If
            'Req.1710：エクスポート機能変更 2018/12 End

            ''個別ＰＳの処理を終了しました。
            OutLogExportEndMsg(OUTERR, FileReader.GetMessage("MSG_0284"))

            ''個別PSの完了メッセージを取得
            msgStr = GetExitPSMsg(rtnPaymentCsvCount, strPsPath, strPsName)
            If rtnPaymentCsvCount = -1 Then
                ''エラーが発生した場合
                MsgBox(msgStr, MsgBoxStyle.Exclamation, Me.Name)
                Exit Function
            End If

            ''========================================================
            ''              　以下、個別詳細の処理
            ''========================================================
            ''個別詳細ﾌｧｲﾙﾀﾞｲｱﾙﾛｸﾞの表示
            waitDialog.lbl_Message.Text = FileReader.GetMessage("MSG_0310")
            waitDialog.Activate()
            waitDialog.Refresh()

            ''個別詳細の処理を開始しました。
            OutLogExportStrMsg(OUTERR, FileReader.GetMessage("MSG_0285"))

            ''個別詳細Csv出力
            rtnKobetuSyousaiCsvCount = OutCsv.WriteKobetusyosaiCsv(Me.txtExPayment.Text, _
                                                                   Me.txtCpno.Text, _
                                                                   strConstractNo, _
                                                                   strDitailPath, _
                                                                   strDitailName, _
                                                                   createTime)

            ''個別詳細の処理を終了しました。
            OutLogExportEndMsg(OUTERR, FileReader.GetMessage("MSG_0286"))

            '直接インポートの場合
            If strButtonName = "btnDirectImport" Then
                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                'インポート種類(Payment)
                Dim strImpotMethodPs As String
                If rbPsI.Checked = True Then
                    strImpotMethodPs = "I"
                ElseIf rbPsP.Checked = True Then
                    strImpotMethodPs = "P"
                ElseIf rbPsS.Checked = True Then
                    strImpotMethodPs = "S"
                ElseIf rbPsK.Checked = True Then
                    strImpotMethodPs = "K"
                Else
                    strImpotMethodPs = ""
                End If
                'インポート種類(詳細)
                Dim strImpotMethodPsd As String
                If rbPsdF.Checked = True Then
                    strImpotMethodPsd = "F"
                ElseIf rbPsdS.Checked = True Then
                    strImpotMethodPsd = "S"
                Else
                    strImpotMethodPsd = ""
                End If
                Dim sc As New ServerCsv
                blnRet = sc.DirectServerCsvImport(strPsPath & "\" & strPsName,
                                                  strDitailPath & "\" & strDitailName,
                                                  strImpotMethodPs,
                                                  strImpotMethodPsd,
                                                  waitDialog,
                                                  OUTERR)
                'blnRet = DirectServerCsvImport(strPsPath & "\" & strPsName,
                '                               strDitailPath & "\" & strDitailName,
                '                               waitDialog,
                '                               OUTERR)
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                If blnRet = False Then
                    Exit Function
                End If

                Me.txtExPayment.Text = ""
                Me.lblPsExUpdate.Text = ""
                MsgBox(FileReader.GetMessage("MSG_0499"), vbInformation, Me.Name)
            Else
                ''完了メッセージの作成
                msgStr = GetExitDetailMsg(msgStr, rtnKobetuSyousaiCsvCount, strDitailPath, strDitailName)
                If rtnKobetuSyousaiCsvCount = -1 Then
                    MsgBox(msgStr, MsgBoxStyle.Exclamation, Me.Name)
                    Exit Function
                End If

                '画面の初期化
                If msgStr <> "" Then
                    MsgBox(msgStr, MsgBoxStyle.Information, Me.Name)
                    Me.txtExPayment.Text = ""
                    Me.lblPsExUpdate.Text = ""
                End If
            End If

            OUTERR.OutExportErrorList("END", "Export", , , False)

            ExportMain = True

        Finally
            waitDialog.Close()
        End Try

    End Function

    'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
    '※共通化のためServerCsv.vbに移動
    ' ''' <summary>
    ' ''' サーバー直接インポート
    ' ''' </summary>
    ' ''' <param name="strPsFileName"></param>
    ' ''' <param name="strPsdFileName"></param>
    ' ''' <param name="waitDialog"></param>
    ' ''' <param name="outErr"></param>
    ' ''' <returns></returns>
    ' ''' <remarks></remarks>
    'Private Function DirectServerCsvImport(ByVal strPsFileName As String,
    '                                       ByVal strPsdFileName As String,
    '                                       ByRef waitDialog As Frm_WaitDialog,
    '                                       ByRef outErr As OutputErrorList) As Boolean

    '    Dim strUrl As String
    '    Dim req As System.Net.HttpWebRequest
    '    Dim strId As String = CommonVariable.USERID
    '    Dim strPass As String = CommonVariable.USERPW
    '    Dim strSendMsg As String = ""
    '    Dim strBoundary As String
    '    Dim strFileNamePs As String
    '    Dim strFileNamePsd As String
    '    Dim strImpotMethod As String
    '    Dim cc As CookieContainer = New CookieContainer()       'クッキー設定
    '    Dim sr As StreamReader
    '    Dim strErrMsg As String
    '    Dim strBaseUrl As String

    '    Const STR_LINE As String = "-----------------------------"

    '    Debug.Print(Now.ToString("yyyyy/MM/dd HH:mm:ss") & ":開始")
    '    Dim dtStart As Date = Now

    '    DirectServerCsvImport = False

    '    Try
    '        '=========================================================
    '        'ログイン
    '        '=========================================================
    '        waitDialog.lbl_Message.Text = "サーバーログイン"
    '        waitDialog.Activate()
    '        waitDialog.Refresh()
    '        outErr.OutExportErrorList("サーバーログイン", "Export", , , False)

    '        Dim mmc As New MasterMdbControl
    '        strBaseUrl = mmc.GetMasterMbdPath.OioBama_Url
    '        strUrl = strBaseUrl & "login.wss"
    '        Dim wreqLogin As System.Net.HttpWebRequest = CType(System.Net.WebRequest.Create(strUrl), HttpWebRequest)
    '        wreqLogin.CookieContainer = cc

    '        '認証の設定
    '        wreqLogin.Credentials = New NetworkCredential(strId, strPass)

    '        'HttpWebResponseの取得
    '        Dim wresLogin As HttpWebResponse = CType(wreqLogin.GetResponse(), HttpWebResponse)
    '        wresLogin.Close()

    '        '=========================================================
    '        '送信メッセージ
    '        '=========================================================
    '        waitDialog.lbl_Message.Text = "送信メッセージ作成"
    '        waitDialog.Activate()
    '        waitDialog.Refresh()
    '        outErr.OutExportErrorList("送信メッセージ作成", "Export", , , False)

    '        'ヘッダー
    '        strUrl = strBaseUrl & "import.wss"
    '        req = CType(System.Net.WebRequest.Create(strUrl), HttpWebRequest)
    '        'req.ContentType = "text/xml; charset=utf-8"
    '        req.Method = "POST"
    '        req.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
    '        req.Referer = strBaseUrl & "menu.wss?funcId=I000"
    '        req.Headers.Add("Accept-Encoding", "gzip,deflate")
    '        req.KeepAlive = True
    '        req.ServicePoint.Expect100Continue = False
    '        req.CookieContainer = cc
    '        'ContentTypeを設定
    '        strBoundary = System.Environment.TickCount.ToString()
    '        req.ContentType = "multipart/form-data; boundary=---------------------------" & strBoundary

    '        'タイムアウト時間設定（ミリ秒）
    '        req.Timeout = 600000

    '        '---------------------------------------------------------
    '        'Payment
    '        '---------------------------------------------------------
    '        'ファイルのデータ
    '        strFileNamePs = Path.GetFileName(strPsFileName)
    '        strSendMsg = strSendMsg & STR_LINE & strBoundary & vbCrLf
    '        strSendMsg = strSendMsg & "Content-Disposition: form-data; name=""csvPaymentLine""; filename=""" & strFileNamePs & """" & vbCrLf
    '        If strFileNamePs = "" Then
    '            strSendMsg = strSendMsg & "Content-Type: application/octet-stream" & vbCrLf
    '            strSendMsg = strSendMsg & vbCrLf
    '        Else
    '            strSendMsg = strSendMsg & "Content-Type: application/csv" & vbCrLf
    '            strSendMsg = strSendMsg & vbCrLf
    '            sr = New StreamReader(strPsFileName, Encoding.GetEncoding("shift-jis"))
    '            strSendMsg = strSendMsg & sr.ReadToEnd
    '            sr.Close()
    '        End If

    '        'インポート種類
    '        If rbPsI.Checked = True Then
    '            strImpotMethod = "I"
    '        ElseIf rbPsP.Checked = True Then
    '            strImpotMethod = "P"
    '        ElseIf rbPsS.Checked = True Then
    '            strImpotMethod = "S"
    '        ElseIf rbPsK.Checked = True Then
    '            strImpotMethod = "K"
    '        Else
    '            strImpotMethod = ""
    '        End If
    '        If strImpotMethod <> "" Then
    '            strSendMsg = strSendMsg & STR_LINE & strBoundary & vbCrLf
    '            strSendMsg = strSendMsg & "Content-Disposition: form-data; name=""importMethod""" & vbCrLf
    '            strSendMsg = strSendMsg & vbCrLf
    '            strSendMsg = strSendMsg & strImpotMethod & vbCrLf
    '        End If

    '        '何かのフラグ
    '        strSendMsg = strSendMsg & STR_LINE & strBoundary & vbCrLf
    '        strSendMsg = strSendMsg & "Content-Disposition: form-data; name=""customerFlag""" & vbCrLf
    '        strSendMsg = strSendMsg & vbCrLf
    '        strSendMsg = strSendMsg & "M" & vbCrLf

    '        '---------------------------------------------------------
    '        '詳細
    '        '---------------------------------------------------------
    '        'ファイルのデータ
    '        strFileNamePsd = IO.Path.GetFileName(strPsdFileName)
    '        strSendMsg = strSendMsg & STR_LINE & strBoundary & vbCrLf
    '        strSendMsg = strSendMsg & "Content-Disposition: form-data; name=""csvFeature""; filename=""" & strFileNamePsd & """" & vbCrLf
    '        If strFileNamePsd = "" Then
    '            strSendMsg = strSendMsg & "Content-Type: application/octet-stream" & vbCrLf
    '            strSendMsg = strSendMsg & vbCrLf
    '        Else
    '            strSendMsg = strSendMsg & "Content-Type: application/csv" & vbCrLf
    '            strSendMsg = strSendMsg & vbCrLf
    '            sr = New StreamReader(strPsdFileName, Encoding.GetEncoding("shift-jis"))
    '            strSendMsg = strSendMsg & sr.ReadToEnd
    '            sr.Close()
    '        End If

    '        'インポート種類
    '        If rbPsdF.Checked = True Then
    '            strImpotMethod = "F"
    '        ElseIf rbPsdS.Checked = True Then
    '            strImpotMethod = "S"
    '        Else
    '            strImpotMethod = ""
    '        End If
    '        If strImpotMethod <> "" Then
    '            strSendMsg = strSendMsg & STR_LINE & strBoundary & vbCrLf
    '            strSendMsg = strSendMsg & "Content-Disposition: form-data; name=""importDetail""" & vbCrLf
    '            strSendMsg = strSendMsg & vbCrLf
    '            strSendMsg = strSendMsg & strImpotMethod & vbCrLf
    '        End If

    '        '何か
    '        strSendMsg = strSendMsg & STR_LINE & strBoundary & vbCrLf
    '        strSendMsg = strSendMsg & "Content-Disposition: form-data; name=""import""" & vbCrLf
    '        strSendMsg = strSendMsg & vbCrLf
    '        strSendMsg = strSendMsg & "インポート" & vbCrLf
    '        strSendMsg = strSendMsg & STR_LINE & strBoundary & "--" & vbCrLf

    '        waitDialog.lbl_Message.Text = "CSV送信中"
    '        waitDialog.Activate()
    '        waitDialog.Refresh()
    '        outErr.OutExportErrorList("CSV送信中", "Export", , , False)

    '        req.ContentLength = Encoding.Default.GetBytes(strSendMsg).Length
    '        'バイト型配列に変換
    '        Dim postDataBytes As Byte() = Encoding.Default.GetBytes(strSendMsg)
    '        'データをPOST送信するためのStreamを取得
    '        Dim reqStream As Stream = req.GetRequestStream()
    '        '送信するデータを書き込む
    '        reqStream.Write(postDataBytes, 0, postDataBytes.Length)
    '        reqStream.Close()

    '        '=========================================================
    '        '受信メッセージ
    '        '=========================================================
    '        waitDialog.lbl_Message.Text = "サーバーから応答待ち中"
    '        waitDialog.Activate()
    '        waitDialog.Refresh()
    '        outErr.OutExportErrorList("サーバーから応答待ち中", "Export", , , False)

    '        'サーバーからの応答を受信するためのWebResponseを取得
    '        Dim res As System.Net.WebResponse = req.GetResponse()
    '        '応答データを受信するためのStreamを取得
    '        Dim resStream As System.IO.Stream = res.GetResponseStream()
    '        sr = New System.IO.StreamReader(resStream, System.Text.Encoding.UTF8)
    '        Dim strRecieveMsg As String
    '        strRecieveMsg = sr.ReadToEnd
    '        sr.Close()

    '        Debug.Print(Now.ToString("yyyyy/MM/dd HH:mm:ss") & ":受信完了")
    '        Debug.Print(strRecieveMsg)
    '        outErr.OutExportErrorList("サーバーから応答 解析中", "Export", , , False)

    '        Dim intPos As Integer
    '        intPos = strRecieveMsg.IndexOf("<p class=""ibm-ind-error"">")
    '        If intPos >= 0 Then
    '            strErrMsg = strRecieveMsg.Substring(intPos + ("<p class=""ibm-ind-error"">").Length)
    '            strErrMsg = strErrMsg.Substring(0, (strErrMsg.IndexOf("</p>")))
    '            MsgBox(strErrMsg, MsgBoxStyle.Critical, "Error")
    '            Exit Function
    '        Else
    '            intPos = strRecieveMsg.IndexOf("<p class=""ibm-ind-information"">")
    '            If intPos >= 0 Then
    '                strErrMsg = strRecieveMsg.Substring(intPos + ("<p class=""ibm-ind-information"">").Length)
    '                strErrMsg = strErrMsg.Substring(0, (strErrMsg.IndexOf("</p>")))
    '                intPos = strErrMsg.IndexOf("<br />")
    '                If intPos >= 0 Then
    '                    strErrMsg = strErrMsg.Substring(0, intPos) & vbCrLf & strErrMsg.Substring(intPos + ("<br />").Length)
    '                End If
    '            End If
    '        End If

    '        DirectServerCsvImport = True

    '    Catch ex As Exception
    '        Dim strExMsg As String = ex.Message.ToString
    '        If strExMsg = "リモート サーバーがエラーを返しました: (503) サーバーを使用できません" Then
    '            Debug.Print(Now.ToString("yyyyy/MM/dd HH:mm:ss") & ":「" & strExMsg & "」発生")
    '            outErr.OutExportErrorList("「" & strExMsg & "」発生", "Export", , , False)

    '            '応答はエラーだがサーバーでは処理が続行している可能性があるため
    '            'T_CUSTOMERのP_STATUS、D_STATUSを検索して判断する
    '            Dim blnRet As Boolean
    '            blnRet = checkValidationStatus(outErr)
    '            If blnRet = False Then
    '                Exit Function
    '            End If
    '            DirectServerCsvImport = True
    '        Else
    '            Debug.Print(Now.ToString("yyyyy/MM/dd HH:mm:ss") & ":Error")
    '            outErr.OutExportErrorList(ex.Message.ToString, "Export", , , False)
    '            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "Error")
    '        End If
    '    End Try

    'End Function

    ' ''' <summary>
    ' ''' Validation Status チェック処理
    ' ''' </summary>
    ' ''' <param name="outErr"></param>
    ' ''' <returns></returns>
    ' ''' <remarks></remarks>
    'Private Function checkValidationStatus(ByRef outErr As OutputErrorList) As Boolean

    '    Dim wc As New WebDb.WebDbCommon
    '    Dim blnRet As Boolean
    '    Dim strMsg As String
    '    Dim dt As New M_CONTRACT_BASETable
    '    Dim oc As New OioControl
    '    Dim dtTerm As DataTable
    '    Dim dtInterval As DataTable
    '    Dim intTerm As Integer = 0
    '    Dim intInterval As Integer = 0
    '    Dim intCnt As Integer
    '    Dim strPStatus As String
    '    Dim strDStatus As String
    '    Dim blnCheck As Boolean = False     'Validation正常:True、Validation異常:False

    '    checkValidationStatus = False
    '    blnCheck = False

    '    Try
    '        'Validationtチェック期間（秒）を取得
    '        dtTerm = oc.GetCodeData("checkValdationTerm", CommonVariable.MdbPW)
    '        If dtTerm.Rows.Count > 0 Then
    '            intTerm = Integer.Parse(dtTerm.Rows(0).Item("ItemValue"))
    '        End If
    '        'Validationtチェック間隔（秒）を取得
    '        dtInterval = oc.GetCodeData("checkValdationInterval", CommonVariable.MdbPW)
    '        If dtInterval.Rows.Count > 0 Then
    '            intInterval = Integer.Parse(dtInterval.Rows(0).Item("ItemValue"))
    '        End If

    '        outErr.OutExportErrorList("チェック期間：" & intTerm.ToString & "秒", "Export", , , False)
    '        outErr.OutExportErrorList("チェック間隔：" & intInterval.ToString & "秒", "Export", , , False)

    '        '
    '        For intCnt = 1 To (intTerm / intInterval)
    '            'sleep
    '            System.Threading.Thread.Sleep(intInterval * 1000)

    '            Debug.Print(Now.ToString("yyyyy/MM/dd HH:mm:ss") & ":チェック　" & intCnt.ToString & "回目")
    '            outErr.OutExportErrorList("チェック　" & intCnt.ToString & "回目", "Export", , , False)

    '            '契約基本情報取得
    '            wc.IntraId = CommonVariable.USERID
    '            wc.IntraPass = CommonVariable.USERPW
    '            blnRet = wc.GetContractBaseData(CommonVariable.CPNO, dt, strMsg)
    '            If blnRet = False Then
    '                MsgBox(strMsg, vbCritical, "checkValidationStatus")
    '                Exit Function
    '            End If

    '            'P_STATUS、D_STATUS判定
    '            strPStatus = dt.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_P_STATUS)
    '            strDStatus = dt.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_D_STATUS)

    '            'Paymentまたは詳細がエラーの場合、エラーで返す
    '            If strPStatus = "E" Or strDStatus = "E" Then
    '                outErr.OutExportErrorList(FileReader.GetMessage("MSG_0497"), "Export", , , False)
    '                MsgBox(FileReader.GetMessage("MSG_0497"), vbCritical, "checkValidationStatus")
    '                Exit Function
    '            End If
    '            'Payment、詳細が共にValidation済みの場合、正常終了
    '            If strPStatus = "C" And strDStatus = "C" Then
    '                blnCheck = True
    '                Exit For
    '            End If
    '        Next

    '        'チェック期間中にValidationが終了しなかった場合、異常終了
    '        If blnCheck = False Then
    '            outErr.OutExportErrorList(FileReader.GetMessage("MSG_0498"), "Export", , , False)
    '            MsgBox(FileReader.GetMessage("MSG_0498"), vbCritical, "checkValidationStatus")
    '            Exit Function
    '        End If

    '        checkValidationStatus = True

    '    Catch ex As Exception
    '        outErr.OutExportErrorList(ex.Message.ToString, "Export", , , False)
    '        MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "checkValidationStatus")
    '    End Try

    'End Function
    'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

    Private Function CheckCPnoEx() As Boolean
        Dim strCrrCpno As String = ""
        Dim strTemp() As String

        strCrrCpno = txtCpno.Text

        Try
            If Me.txtExPayment.Text.Trim.Length > 0 Then
                Dim strPaymentSheet As String
                strTemp = Me.txtExPayment.Text.Split("\")
                strPaymentSheet = strTemp(strTemp.Length - 1).Substring(0, 6)
                If strCrrCpno.Length = 0 Then
                    strCrrCpno = strPaymentSheet
                End If
                If strCrrCpno.PadLeft(6, "0c").Equals(strPaymentSheet) Then
                    strCrrCpno = strPaymentSheet
                Else
                    Return False
                End If
            End If
            Return True
        Catch ex As Exception
            MsgBox("ファイルの取得に失敗しました。もう一度確認してください。", MsgBoxStyle.Critical, Me.Name)
            Return False
        End Try

    End Function

    ''' <summary>
    ''' 機能：インポート完了メッセージ表示
    ''' </summary>
    ''' <param name="strButtonName"></param>
    ''' <param name="importCount"></param>
    ''' <param name="importErrCount"></param>
    ''' <param name="usedFilePath"></param>
    ''' <remarks></remarks>
    Private Sub CompleteImportMessage(ByVal strButtonName As String,
                                      ByVal importCount As ImportCsv.ImportCount,
                                      ByVal importErrCount As ImportCsv.ImportErrCount,
                                      ByVal usedFilePath As ImportCsv.usedFilePath)

        Dim MsgStr As String
        Dim strMsgCd As String
        Dim intBoxStyle As Integer

        Try
            If (strButtonName = Me.btnImportCsv.Name And
                importErrCount.PSCount = 0 And
                importErrCount.PSValidationlogCount = 0 And
                importErrCount.PSReferenceCount = 0 And
                importErrCount.DetailCount = 0 And
                importErrCount.DetailValidationlogCount = 0 And
                importErrCount.DetailReferenceCount = 0) Then
                '---------------------------------------------------
                'CSV正常
                '---------------------------------------------------
                'Paymentの処理	
                If importCount.PSCount <> -1 Then
                    MsgStr = MsgStr & "Paymentファイル" & vbCrLf _
                                    & "  ファイル名:" & Path.GetFileName(usedFilePath.PaymentPath) & vbCrLf _
                                    & "  件数      :" & importCount.PSCount.ToString("###,###,###,##0") & "件" & vbCrLf
                End If

                If importCount.PSValidationlogCount <> -1 Then
                    MsgStr = MsgStr & "PaymentValidationLogファイル" & vbCrLf _
                                    & "  ファイル名:" & Path.GetFileName(usedFilePath.PaymentValidationlogPath) & vbCrLf _
                                    & "  件数      :" & importCount.PSValidationlogCount.ToString("###,###,###,##0") & "件" & vbCrLf
                End If

                If importCount.PSReferenceCount <> -1 Then
                    MsgStr = MsgStr & "PaymentRefreshLogファイル" & vbCrLf _
                                    & "  ファイル名:" & Path.GetFileName(usedFilePath.PaymentReferencePath) & vbCrLf _
                                    & "  件数      :" & importCount.PSReferenceCount.ToString("###,###,###,##0") & "件" & vbCrLf
                End If

                '個別詳細の処理	
                If importCount.DetailCount <> -1 Then
                    MsgStr = MsgStr & "個別詳細ファイル" & vbCrLf _
                                    & "  ファイル名:" & Path.GetFileName(usedFilePath.PaymentDetailPath) & vbCrLf _
                                    & "  件数      :" & importCount.DetailCount.ToString("###,###,###,##0") & "件" & vbCrLf
                End If

                If importCount.DetailValidationlogCount <> -1 Then
                    MsgStr = MsgStr & "個別詳細ValidationLogファイル" & vbCrLf _
                                    & "  ファイル名:" & Path.GetFileName(usedFilePath.PaymentDetailValidationlogPath) & vbCrLf _
                                    & "  件数      :" & importCount.DetailValidationlogCount.ToString("###,###,###,##0") & "件" & vbCrLf
                End If

                If importCount.DetailReferenceCount <> -1 Then
                    MsgStr = MsgStr & "個別詳細RefreshLogファイル" & vbCrLf _
                                        & "  ファイル名:" & Path.GetFileName(usedFilePath.PaymentDetailReferencePath) & vbCrLf _
                                        & "  件数      :" & importCount.DetailReferenceCount.ToString("###,###,###,##0") & "件"
                End If

                intBoxStyle = MsgBoxStyle.Information

            ElseIf (strButtonName = Me.btnImportMdb.Name And
                importErrCount.MDBCount = 0 And
                importErrCount.MDBDetailCount = 0 And
                importErrCount.CreatingMdbCount = 0 And
                importErrCount.CreatingMdbDetailCount = 0) Then
                '---------------------------------------------------
                'MDB正常
                '---------------------------------------------------
                '締結済MDBの処理	
                If importCount.MDBCount <> -1 Then
                    MsgStr = MsgStr & "契約済みMDBPaymentデータ" & vbCrLf _
                                    & "  件数      :" & importCount.MDBCount.ToString("###,###,###,##0") & "件" & vbCrLf
                End If
                '締結済個別詳細の処理	
                If importCount.MDBDetailCount <> -1 Then
                    MsgStr = MsgStr & "契約済みMDB詳細データ" & vbCrLf _
                                    & "  件数      :" & importCount.MDBDetailCount.ToString("###,###,###,##0") & "件" & vbCrLf

                End If
                '作成中MDBの処理	
                If importCount.CreatingMdbCount <> -1 Then
                    MsgStr = MsgStr & "作成中MDBPaymentデータ" & vbCrLf _
                                    & "  件数      :" & importCount.CreatingMdbCount.ToString("###,###,###,##0") & "件" & vbCrLf
                End If
                '作成中MDB個別詳細の処理	
                If importCount.CreatingMdbDetailCount <> -1 Then
                    MsgStr = MsgStr & "作成中MDB詳細データ" & vbCrLf _
                                    & "  件数      :" & importCount.CreatingMdbDetailCount.ToString("###,###,###,##0") & "件" & vbCrLf

                End If

                intBoxStyle = MsgBoxStyle.Information

            ElseIf (strButtonName = Me.btnImportCsvMdb.Name And
                importErrCount.MDBCount = 0 And
                importErrCount.MDBDetailCount = 0 And
                importErrCount.CreatingMdbCount = 0 And
                importErrCount.CreatingMdbDetailCount = 0 And
                importErrCount.PSCount = 0 And
                importErrCount.PSValidationlogCount = 0 And
                importErrCount.PSReferenceCount = 0 And
                importErrCount.DetailCount = 0 And
                importErrCount.DetailValidationlogCount = 0 And
                importErrCount.DetailReferenceCount = 0) Then
                '---------------------------------------------------
                'MDB CSV正常
                '---------------------------------------------------
                'Paymentの処理	
                If importCount.PSCount <> -1 Then
                    MsgStr = MsgStr & "Paymentファイル" & vbCrLf _
                                    & "  ファイル名:" & Path.GetFileName(usedFilePath.PaymentPath) & vbCrLf _
                                    & "  件数      :" & importCount.PSCount.ToString("###,###,###,##0") & "件" & vbCrLf
                End If

                If importCount.MDBCount <> -1 Then
                    MsgStr = MsgStr & "契約済みMDBPaymentデータ" & vbCrLf _
                                    & "  件数      :" & importCount.MDBCount.ToString("###,###,###,##0") & "件" & vbCrLf
                End If

                If importCount.CreatingMdbCount <> -1 Then
                    MsgStr = MsgStr & "作成中MDBPaymentデータ" & vbCrLf _
                                    & "  件数      :" & importCount.CreatingMdbCount.ToString("###,###,###,##0") & "件" & vbCrLf
                End If

                If importCount.PSValidationlogCount <> -1 Then
                    MsgStr = MsgStr & "PaymentValidationLogファイル" & vbCrLf _
                                    & "  ファイル名:" & Path.GetFileName(usedFilePath.PaymentValidationlogPath) & vbCrLf _
                                    & "  件数      :" & importCount.PSValidationlogCount.ToString("###,###,###,##0") & "件" & vbCrLf
                End If

                If importCount.PSReferenceCount <> -1 Then
                    MsgStr = MsgStr & "PaymentRefreshLogファイル" & vbCrLf _
                                        & "  ファイル名:" & Path.GetFileName(usedFilePath.PaymentReferencePath) & vbCrLf _
                                        & "  件数      :" & importCount.PSReferenceCount.ToString("###,###,###,##0") & "件" & vbCrLf
                End If

                '個別詳細の処理	
                If importCount.MDBDetailCount <> -1 Then
                    MsgStr = MsgStr & "契約済みMDB詳細データ" & vbCrLf _
                                    & "  件数      :" & importCount.MDBDetailCount.ToString("###,###,###,##0") & "件" & vbCrLf
                End If

                '作成中MDB個別詳細の処理	
                If importCount.CreatingMdbDetailCount <> -1 Then
                    MsgStr = MsgStr & "作成中MDB詳細データ" & vbCrLf _
                                    & "  件数      :" & importCount.CreatingMdbDetailCount.ToString("###,###,###,##0") & "件" & vbCrLf

                End If

                If importCount.DetailCount <> -1 Then
                    MsgStr = MsgStr & "個別詳細ファイル" & vbCrLf _
                                    & "  ファイル名:" & Path.GetFileName(usedFilePath.PaymentDetailPath) & vbCrLf _
                                    & "  件数      :" & importCount.DetailCount.ToString("###,###,###,##0") & "件" & vbCrLf
                End If

                If importCount.DetailValidationlogCount <> -1 Then
                    MsgStr = MsgStr & "個別詳細ValidationLogファイル" & vbCrLf _
                                    & "  ファイル名:" & Path.GetFileName(usedFilePath.PaymentDetailValidationlogPath) & vbCrLf _
                                    & "  件数      :" & importCount.DetailValidationlogCount.ToString("###,###,###,##0") & "件" & vbCrLf
                End If

                If importCount.DetailReferenceCount <> -1 Then
                    MsgStr = MsgStr & "個別詳細RefreshLogファイル" & vbCrLf _
                                        & "  ファイル名:" & Path.GetFileName(usedFilePath.PaymentDetailReferencePath) & vbCrLf _
                                        & "  件数      :" & importCount.DetailReferenceCount.ToString("###,###,###,##0") & "件"
                End If

                intBoxStyle = MsgBoxStyle.Information

            Else
                '---------------------------------------------------
                'エラーのファイルを表示
                '---------------------------------------------------
                MsgStr = MsgStr & "■以下のファイルに、取込みできないデータが存在します。" & vbCrLf
                MsgStr = MsgStr & "  ImportErrorLogﾌｧｲﾙを確認してください。" & vbCrLf & vbCrLf

                If importErrCount.MDBCount = -1 Then
                    MsgStr = MsgStr & "  契約締結済みMDBPaymentデータ" & vbCrLf
                End If

                If importErrCount.PSCount > 0 Then
                    MsgStr = MsgStr & "  Paymentファイル" & vbCrLf
                End If

                If importErrCount.PSValidationlogCount > 0 Then
                    MsgStr = MsgStr & "  PaymentValidationLogファイル" & vbCrLf
                End If

                If importErrCount.PSReferenceCount > 0 Then
                    MsgStr = MsgStr & "  PaymentRefreshLogファイル" & vbCrLf
                End If

                If importErrCount.MDBDetailCount = -1 Then
                    MsgStr = MsgStr & "  契約締結済みMDB詳細情報データ" & vbCrLf
                End If

                If importErrCount.DetailCount > 0 Then
                    MsgStr = MsgStr & "  個別詳細ファイル" & vbCrLf
                End If

                If importErrCount.DetailValidationlogCount > 0 Then
                    MsgStr = MsgStr & "  個別詳細ValidationLogファイル" & vbCrLf
                End If

                If importErrCount.DetailReferenceCount > 0 Then
                    MsgStr = MsgStr & "  個別詳細RefreshLogファイル" & vbCrLf
                End If

                intBoxStyle = MsgBoxStyle.Critical

            End If

            'メッセージ表示
            MsgBox(MsgStr, intBoxStyle, Me.Text)

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "CompleteMessage")
        End Try

    End Sub

    ''' <summary>
    ''' 機　能：ファイルの処理開始/終了メッセージを表示
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub OutImpTitleErrLog(ByRef OutErr As OutputErrorList, _
                                  ByVal Msg As String)

        OutErr.OutImportErrorList("=========================================", "Import")
        OutErr.OutImportErrorList(Msg, "Import")
        OutErr.OutImportErrorList("=========================================", "Import")

    End Sub


    ''' <summary>
    ''' 機　能：処理中ﾀﾞｲｱﾙﾛｸﾞの初期設定
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetInitWaitDialog(ByRef waitDialog As Frm_WaitDialog, _
                                  ByVal startMsg As String)

        waitDialog.Text = STR_CREATING_IN
        waitDialog.lbl_Message.Text = startMsg
        waitDialog.Pic_Excel.Visible = True
        waitDialog.ProgressMin = 0
        waitDialog.ProgressMax = 7
        waitDialog.ProgressStep = 1
        waitDialog.ProgressValue = 0
        waitDialog.Show()
        waitDialog.Refresh()

    End Sub


    ''' <summary>
    ''' 機　能：処理中ﾀﾞｲｱﾙﾛｸﾞのメッセージ変更
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetMsgWaitDialog(ByRef waitDialog As Frm_WaitDialog, _
                                 ByVal setMsg As String)

        waitDialog.lbl_Message.Text = setMsg
        waitDialog.Show()
        waitDialog.Refresh()

    End Sub

    ''' <summary>
    ''' 機　能：処理中ﾀﾞｲｱﾙﾛｸﾞのClose
    ''' 説　明：※処理中の画面制御が増えたときのため(マウスポインタの砂時計等)、一応関数化する。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub CloseWaitDialog(ByRef waitDialog As Frm_WaitDialog)

        waitDialog.Close()

    End Sub


    ''' <summary>
    ''' 機　能：処理中ﾀﾞｲｱﾙﾛｸﾞの初期値をセット
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetExportWaitDialogInitDate(ByRef waitDialog As Frm_WaitDialog)

        waitDialog.Text = STR_CREATING_EX
        waitDialog.lbl_Message.Text = FileReader.GetMessage("MSG_0307")
        waitDialog.Pic_Excel.Visible = True
        waitDialog.ProgressMin = 0
        waitDialog.ProgressMax = 7
        waitDialog.ProgressStep = 1
        waitDialog.ProgressValue = 0

    End Sub


    ''' <summary>
    ''' 機　能：処理の開始メッセージを表示
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub OutLogExportStrMsg(ByVal OUTERR As OutputErrorList, _
                                   ByVal msg As String)

        OUTERR.OutExportErrorList("=========================================", "Export", , , False)
        OUTERR.OutExportErrorList(msg, "Export", , , False)
        OUTERR.OutExportErrorList("=========================================", "Export", , , False)

    End Sub

    ''' <summary>
    ''' 機　能：処理の終了メッセージを表示
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub OutLogExportEndMsg(ByVal OUTERR As OutputErrorList, _
                                   ByVal msg As String)

        OUTERR.OutExportErrorList("=========================================", "Export", , , False)
        OUTERR.OutExportErrorList(msg, "Export", , , False)
        OUTERR.OutExportErrorList("=========================================", "Export", , , False)

    End Sub

    ''' <summary>
    ''' 機　能：個別PSCSVExport完了メッセージを取得
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetExitPSMsg(ByVal rtnPaymentCsvCount As Integer, _
         ByVal strPsPath As String, _
         ByVal strPsName As String) As String

        ''初期化
        GetExitPSMsg = ""

        Dim rtnMsg As String
        If rtnPaymentCsvCount <> -1 Then
            rtnMsg = "PaymentSheetCsvファイルの出力が終了しました。" & vbCrLf _
                     & strPsPath & "に" & strPsName & "を出力しました。" & vbCrLf _
                     & rtnPaymentCsvCount & "行データを出力しました。" & vbCrLf
        Else
            rtnMsg = FileReader.GetMessage("MSG_0255")
        End If

        Return rtnMsg

    End Function


    ''' <summary>
    ''' 機　能：個別詳細CSVExport完了メッセージを取得
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetExitDetailMsg(ByVal msgStr As String, _
                                      ByVal rtnKobetuSyousaiCsvCount As Integer, _
                                      ByVal strDitailPath As String, _
                                      ByVal strDitailName As String) As String

        ''初期化
        GetExitDetailMsg = ""

        Dim rtnMsg As String
        If rtnKobetuSyousaiCsvCount <> -1 Then
            If msgStr <> "" Then
                rtnMsg = msgStr & vbCrLf
            End If
            rtnMsg = rtnMsg & "個別詳細Csvファイルの出力が終了しました。" & vbCrLf _
                     & strDitailPath & "に" & strDitailName & "を出力しました。" & vbCrLf _
                     & rtnKobetuSyousaiCsvCount & "行データを出力しました。" & vbCrLf
        Else
            rtnMsg = FileReader.GetMessage("MSG_0255")
        End If

        Return rtnMsg

    End Function

    ''' <summary>
    '''概    要：csv出力先のフォルダ位置を取得する。
    '''説    明：csvフォルダより、該当するフォルダのパスを取得
    ''' 　　　　：引数で受け取ったCPNOと契約順番をkeyにパスを取得する。
    ''' </summary>
    ''' <param name="CPNO">作成するフォルダ名に使用</param>
    ''' <param name="CONTRACT_NO">変更後契約順番の取得に使用</param>
    ''' <remarks></remarks>
    Private Function GetLocalCPNOcsvFolder(ByVal CPNO As String, _
                                       ByVal CONTRACT_NO As Integer) As String

        GetLocalCPNOcsvFolder = ""

        Try
            Dim BaseExcelOutputPath As String = FileManager.GetLocalFolderPath(CommonConstant.FOLDERNAME_CSV1)
            Dim LocalCPNO As String
            Dim LocalCONTRACT_NO As String

            '’CPNO,CONTRACT_NOは左0埋
            LocalCPNO = CPNO.Trim.PadLeft(8, "0")
            '' 契約順番は左0埋め
            LocalCONTRACT_NO = CStr(CONTRACT_NO).PadLeft(3, "0")

            ''フォルダの存在チェック
            If File.Exists(BaseExcelOutputPath & LocalCPNO & "_" & LocalCONTRACT_NO) Then
                Exit Function
            End If

            ''フォルダ位置取得
            GetLocalCPNOcsvFolder = BaseExcelOutputPath & LocalCPNO & "_" & LocalCONTRACT_NO & "\"

        Catch ex As Exception
            Throw ex
        End Try
    End Function

    ''' <summary>
    ''' 機能：ｴﾗｰ時、各ﾌｧｲﾙ削除
    ''' </summary>
    ''' <param name="ufp"></param>
    ''' <remarks></remarks>
    Private Sub ErrorFileDelete(ByVal ufp As ImportCsv.usedFilePath)

        If Not ufp.PaymentPath Is Nothing Then
            File.Delete(ufp.PaymentPath)
        End If
        If Not ufp.PaymentValidationlogPath Is Nothing Then
            File.Delete(ufp.PaymentValidationlogPath)
        End If
        If Not ufp.PaymentReferencePath Is Nothing Then
            File.Delete(ufp.PaymentReferencePath)
        End If
        If Not ufp.PaymentDetailPath Is Nothing Then
            File.Delete(ufp.PaymentDetailPath)
        End If
        If Not ufp.PaymentDetailValidationlogPath Is Nothing Then
            File.Delete(ufp.PaymentDetailValidationlogPath)
        End If
        If Not ufp.PaymentDetailReferencePath Is Nothing Then
            File.Delete(ufp.PaymentDetailReferencePath)
        End If

    End Sub

    ''' <summary>
    ''' 機能：Excel出力
    ''' </summary>
    ''' <param name="filePath"></param>
    ''' <param name="alPsCreating"></param>
    ''' <param name="alPsdCreating"></param>
    ''' <param name="strExcelYear"></param>
    ''' <param name="strCreatTime"></param>
    ''' <param name="summaryRowList"></param>
    ''' <param name="SummaryFomula"></param>
    ''' <param name="usedFilePath"></param>
    ''' <param name="importCount"></param>
    ''' <param name="ImportErrCount"></param>
    ''' <param name="waitDialog"></param>
    ''' <param name="OUTERR"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function OutputExcel(ByVal filePath As ImportCsv.ServerCsvPath,
                                 ByVal alPsCreating As ArrayList,
                                 ByVal alPsdCreating As ArrayList,
                                 ByVal strExcelYear As String,
                                 ByVal strCreatTime As String,
                                 ByRef usedFilePath As ImportCsv.usedFilePath,
                                 ByRef importCount As ImportCsv.ImportCount,
                                 ByRef ImportErrCount As ImportCsv.ImportErrCount,
                                 ByRef waitDialog As Frm_WaitDialog,
                                 ByRef OUTERR As OutputErrorList) As Boolean

        Dim oe As OutputExcel = New OutputExcel
        Dim xlApp As Excel.Application
        Dim xlBook As Excel.Workbook
        Dim OutPutFilePath As String
        Dim OutPutFileName As String
        Dim xlSheet As Excel.Worksheet
        Dim xlRange As Excel.Range
        Dim ofm As New OioFileManage
        Dim strCsvFileNamePs As String
        Dim strCsvFileNamePsd As String
        Dim strCsvPaht As String
        Dim strCreateDate As String
        Dim xlBooks As Excel.Workbooks
        Dim xlSheets As Excel.Sheets = Nothing

        OutputExcel = False

        Try
            ''フォーマットExcelファイルの存在チェック
            If oe.CheckTempleteFile(oe.eTemplatePtn.PaymentSheet, OUTERR) = False Then
                Exit Function
            End If

            ''フォーマットExcelファイルのコピー
            If oe.CopyTemplateExcelFile(oe.eTemplatePtn.PaymentSheet, "", OutPutFilePath, OutPutFileName, OUTERR, strCreatTime) = False Then
                Exit Function
            End If

            usedFilePath.PaymentPath = OutPutFilePath
            usedFilePath.PaymentName = OutPutFileName
            usedFilePath.PaymentDetailPath = OutPutFilePath
            usedFilePath.PaymentDetailName = OutPutFileName

            '==========================================
            'Eexcelオブジェクト初期化
            '==========================================
            xlApp = New Excel.Application
            Dim OutPSExcel As String = ""
            xlApp.EnableEvents = False
            xlBooks = xlApp.Workbooks
            xlBook = xlBooks.Open(OutPutFilePath)
            xlApp.EnableEvents = True
            xlApp.Calculation = Excel.XlCalculation.xlCalculationManual

            '=====================================================
            'Excelオブジェクトの設定			
            '=====================================================
            'Sheetのセット
            xlSheets = xlBook.Sheets
            xlSheet = xlSheets.Item(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)
            'Excel開始年のセット
            xlRange = xlSheet.Cells(4, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1)
            xlRange.Value = strExcelYear
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            '==========================================
            'Payment
            '==========================================
            strCsvPaht = Path.GetFullPath("../log/")
            strCreateDate = Now.ToString("_yyyyMMdd_HHmmss")
            If alPsCreating.Count > 0 Then
                '中間ファイル作成
                strCsvFileNamePs = strCsvPaht & "WorkCsv_PS" & strCreateDate & ".csv"
                Call oe.arDataToCsv(alPsCreating, strCsvFileNamePs)

                'ダイアログ表示＆ログ出力
                Call SetMsgWaitDialog(waitDialog, FileReader.GetMessage("MSG_0307"))
                Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0289"))

                xlSheet = xlSheets.Item(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)
                importCount.PSCount = oe.OutputExcelPs(strCsvFileNamePs,
                                                       alPsCreating.Count,
                                                       CommonVariable.PaymentPeriod,
                                                       xlSheet,
                                                       OUTERR)
                ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
                If importCount.PSCount = -1 Then
                    MsgBox(FileReader.GetMessage("MSG_0313"), vbCritical)
                End If

                'ログ出力
                Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0290"))
            End If

            'Payment展開期間分列削除(Paymentｼｰﾄ)
            xlSheet = xlSheets.Item(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)
            Call ExcelWrite.CreatePaymentPeriod(xlSheet,
                                                chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1),
                                                CommonVariable.PaymentPeriod)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            'Payment展開期間分列削除(Dummyｼｰﾄ)
            xlSheet = xlSheets.Item(ExcelWrite.EXCEL_PAYMENTLINEDATE_DUMMYSHEET)
            Call ExcelWrite.CreatePaymentPeriod(xlSheet,
                                                chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1),
                                                CommonVariable.PaymentPeriod)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            '==========================================
            '詳細
            '==========================================
            If alPsdCreating.Count > 0 Then
                '中間ファイル作成
                strCsvFileNamePsd = strCsvPaht & "WorkCsv_PSD" & strCreateDate & ".csv"
                Call oe.arDataToCsv(alPsdCreating, strCsvFileNamePsd)

                'ダイアログ表示＆ログ出力
                Call SetMsgWaitDialog(waitDialog, FileReader.GetMessage("MSG_0307"))
                Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0295"))

                xlSheet = xlSheets.Item(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)
                importCount.DetailCount = oe.OutputExcelPsd(strCsvFileNamePsd,
                                                             alPsdCreating.Count,
                                                             xlSheet,
                                                             OUTERR)
                ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

                'ログ出力
                Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0296"))
            End If

            '※VBActNMListに統合
            ExcelWrite.KickVBASuffixUpAct(xlApp, xlBook, VBActNMList.Import, CommonVariable.USERID, CommonVariable.USERPW)

            ''プロパティにファイル名を記載 str
            'Dim obj As Object
            'Dim fso As Object

            'fso = CreateObject("Scripting.FileSystemObject")
            'obj = GetObject(xlBook.Path & "\" & xlBook.Name)

            'obj.BuiltinDocumentProperties("Category") = xlBook.Name
            'obj.save()

            'obj = Nothing
            'fso = Nothing

            Dim properties As Object
            properties = xlBook.BuiltinDocumentProperties
            properties.Item("Category").value = xlBook.Name
            xlBook.Save()

            properties = Nothing
            ''プロパティにファイル名を記載 end

            ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.Calculation = Excel.XlCalculation.xlCalculationAutomatic
            xlBook.Close(False)
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlBooks, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.Quit()
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            '==========================================
            'Payment Refresh
            '==========================================
            'ダイアログ表示＆ログ出力
            Call SetMsgWaitDialog(waitDialog, FileReader.GetMessage("MSG_0309"))
            Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0293"))

            'PaymentsheetRefresh(EXCEL)作成処理
            importCount.PSReferenceCount = oe.OptputExcelFromCsvValRef(oe.eTemplatePtn.PaymentSheetReference,
                                                                       filePath.PSRefCsv, _
                                                                       Me.txtCpno.Text, _
                                                                       strCsvPaht,
                                                                       3,
                                                                       "A4",
                                                                       OUTERR, _
                                                                       usedFilePath.PaymentReferencePath, _
                                                                       usedFilePath.PaymentReferenceName, _
                                                                       ImportErrCount.PSReferenceCount)

            If importCount.PSReferenceCount = -2 Then
                Call ErrorFileDelete(usedFilePath)
                Call CloseWaitDialog(waitDialog)
                Exit Function
            End If

            'ログ出力
            Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0294"))

            '==========================================
            'Payment Validation
            '==========================================
            'ダイアログ表示＆ログ出力
            Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0291"))
            Call SetMsgWaitDialog(waitDialog, FileReader.GetMessage("MSG_0308"))

            'PaymentsheetValidation(EXCEL)作成処理
            importCount.PSValidationlogCount = oe.OptputExcelFromCsvValRef(oe.eTemplatePtn.PaymentSheetValidation,
                                                                           filePath.PSValCsv, _
                                                                           Me.txtCpno.Text, _
                                                                           strCsvPaht,
                                                                           3,
                                                                           "A4",
                                                                           OUTERR, _
                                                                           usedFilePath.PaymentValidationlogPath, _
                                                                           usedFilePath.PaymentValidationlogName, _
                                                                           ImportErrCount.PSValidationlogCount)

            '異常終了　
            If importCount.PSValidationlogCount = -1 Then
                Call CloseWaitDialog(waitDialog)
                MsgBox(FileReader.GetMessage("MSG_0314"), vbCritical)
                Exit Function
            ElseIf importCount.PSValidationlogCount = -2 Then
                Call ErrorFileDelete(usedFilePath)
                Call CloseWaitDialog(waitDialog)
                Exit Function
            End If

            ''ログ出力
            Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0292"))

            '==========================================
            '詳細 Refresh
            '==========================================
            'ダイアログ表示＆ログ出力
            Call SetMsgWaitDialog(waitDialog, FileReader.GetMessage("MSG_0312"))
            Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0299"))

            'PaymentDetailRefresh(EXCEL)作成処理
            importCount.DetailReferenceCount = oe.OptputExcelFromCsvValRef(oe.eTemplatePtn.DetailReference,
                                                                           filePath.DetailRefCsv, _
                                                                           Me.txtCpno.Text, _
                                                                           strCsvPaht,
                                                                           3,
                                                                           "A4",
                                                                           OUTERR, _
                                                                           usedFilePath.PaymentDetailReferencePath, _
                                                                           usedFilePath.PaymentDetailReferenceName, _
                                                                           ImportErrCount.DetailReferenceCount)
            If importCount.DetailReferenceCount = -2 Then
                Call ErrorFileDelete(usedFilePath)
                Call CloseWaitDialog(waitDialog)
                Exit Function
            End If

            'ログ出力
            Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0300"))

            '==========================================
            '詳細 Validation
            '==========================================
            'ダイアログ表示＆ログ出力
            Call SetMsgWaitDialog(waitDialog, FileReader.GetMessage("MSG_0311"))
            Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0297"))

            '詳細Validation(EXCEL)作成処理
            importCount.DetailValidationlogCount = oe.OptputExcelFromCsvValRef(oe.eTemplatePtn.DetailValidation,
                                                                               filePath.DetailValCsv, _
                                                                               Me.txtCpno.Text, _
                                                                               strCsvPaht,
                                                                               3,
                                                                               "A4",
                                                                               OUTERR, _
                                                                               usedFilePath.PaymentDetailValidationlogPath, _
                                                                               usedFilePath.PaymentDetailValidationlogName, _
                                                                               ImportErrCount.DetailValidationlogCount)

            '異常終了
            If importCount.DetailValidationlogCount = -1 Then
                Call CloseWaitDialog(waitDialog)
                MsgBox(FileReader.GetMessage("MSG_0316"), vbCritical)
                Exit Function
            ElseIf importCount.DetailValidationlogCount = -2 Then
                Call ErrorFileDelete(usedFilePath)
                Call CloseWaitDialog(waitDialog)
                Exit Function
            End If

            'ログ出力
            Call OutImpTitleErrLog(OUTERR, FileReader.GetMessage("MSG_0298"))

            OutputExcel = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical)

        Finally
            'ﾜｰｸﾌｧｲﾙ削除
            Call ofm.DeleteWorkFile(strCsvPaht)

            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)

            'ブックの解放
            If IsNothing(xlBook) = False Then
                xlBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlBooks, ExcelObjRelease.OBJECT_NOTHING)

            'Appの解放
            If IsNothing(xlApp) = False Then
                xlApp.EnableEvents = True
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            'ガベージコレクトの起動
            GC.Collect()
        End Try

    End Function

    ''' <summary>
    ''' 機能：Paymentの出力件数判定
    '''       該当するデータ件数と出力件数をチェックする
    ''' </summary>
    ''' <param name="strFileName"></param>
    ''' <param name="importCount"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckPaymentOutputCount(ByVal strFileName As String, ByVal importCount As ImportCsv.ImportCount) As Boolean

        Dim xlApp As Excel.Application
        Dim xlBooks As Excel.Workbooks
        Dim xlBook As Excel.Workbook
        Dim xlSheets As Excel.Sheets
        Dim xlSheet As Excel.Worksheet
        Dim intRow As Integer

        CheckPaymentOutputCount = False

        Try
            xlApp = New Excel.Application
            xlApp.EnableEvents = False
            xlApp.DisplayAlerts = False
            xlApp.ScreenUpdating = False
            xlBooks = xlApp.Workbooks
            xlBook = xlBooks.Open(strFileName)
            xlApp.Calculation = Excel.XlCalculation.xlCalculationManual
            xlSheets = xlBook.Sheets

            'Payment
            xlSheet = xlSheets.Item(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)
            intRow = ExcelWrite.GetLastRow(xlSheet, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)
            If importCount.PSCount <> (intRow - EXCEL_PAYMENTLINEDATE_OUTROW + 1) Then
                MsgBox(FileReader.GetMessage("MSG_0521"), vbCritical, "")
                Exit Function
            End If
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            '詳細
            xlSheet = xlSheets.Item(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)
            intRow = ExcelWrite.GetLastRow(xlSheet, ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT)
            If importCount.DetailCount <> (intRow - EXCEL_DETAILLINEDATE_OUTROW + 1) Then
                MsgBox(FileReader.GetMessage("MSG_0521"), vbCritical, "")
                Exit Function
            End If
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            CheckPaymentOutputCount = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "CheckPaymentOutputCount")

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBook) = False Then
                xlApp.Calculation = Excel.XlCalculation.xlCalculationAutomatic
                xlBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlBooks, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.ScreenUpdating = True
            xlApp.DisplayAlerts = True
            xlApp.EnableEvents = True
            If IsNothing(xlApp) = False Then
                xlApp.EnableEvents = True
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try

    End Function

#End Region

    Private Sub GroupBox2_Enter(sender As System.Object, e As System.EventArgs) Handles GroupBox2.Enter

    End Sub
End Class