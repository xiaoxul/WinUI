﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frm_DataCorrection
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dgvConfig = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column7 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.txtQuoteNo = New System.Windows.Forms.TextBox()
        Me.lblQuoteNo = New System.Windows.Forms.Label()
        Me.btnReflection = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnChkAll = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnOK = New MUSE.UserControl.UCnt_Btn0001()
        Me.upalTitle = New MUSE.UserControl.UCnt_Pal0001()
        Me.btnCancel = New MUSE.UserControl.UCnt_Btn0001()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.dgvConfig, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvConfig
        '
        Me.dgvConfig.AllowUserToAddRows = False
        Me.dgvConfig.AllowUserToResizeRows = False
        Me.dgvConfig.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvConfig.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4, Me.Column5, Me.Column6, Me.Column7, Me.Column8})
        Me.dgvConfig.Location = New System.Drawing.Point(16, 101)
        Me.dgvConfig.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dgvConfig.Name = "dgvConfig"
        Me.dgvConfig.RowHeadersVisible = False
        Me.dgvConfig.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.dgvConfig.RowTemplate.Height = 21
        Me.dgvConfig.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.dgvConfig.Size = New System.Drawing.Size(1167, 428)
        Me.dgvConfig.TabIndex = 35
        '
        'Column1
        '
        Me.Column1.HeaderText = ""
        Me.Column1.Name = "Column1"
        Me.Column1.Width = 20
        '
        'Column2
        '
        Me.Column2.HeaderText = "ファイル名"
        Me.Column2.Name = "Column2"
        '
        'Column3
        '
        Me.Column3.FillWeight = 70.0!
        Me.Column3.HeaderText = "製品番号"
        Me.Column3.Name = "Column3"
        '
        'Column4
        '
        Me.Column4.HeaderText = "製品名"
        Me.Column4.Name = "Column4"
        Me.Column4.Width = 200
        '
        'Column5
        '
        Me.Column5.HeaderText = "請求開始年月"
        Me.Column5.Name = "Column5"
        Me.Column5.Width = 120
        '
        'Column6
        '
        Me.Column6.HeaderText = "請求終了年月"
        Me.Column6.Name = "Column6"
        Me.Column6.Width = 120
        '
        'Column7
        '
        Me.Column7.HeaderText = "支払方法"
        Me.Column7.Items.AddRange(New Object() {"", "月額", "年額", "一括"})
        Me.Column7.Name = "Column7"
        Me.Column7.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        '
        'Column8
        '
        Me.Column8.HeaderText = "ListPrice"
        Me.Column8.Name = "Column8"
        '
        'txtQuoteNo
        '
        Me.txtQuoteNo.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.txtQuoteNo.Location = New System.Drawing.Point(877, 68)
        Me.txtQuoteNo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtQuoteNo.MaxLength = 180
        Me.txtQuoteNo.Name = "txtQuoteNo"
        Me.txtQuoteNo.Size = New System.Drawing.Size(144, 22)
        Me.txtQuoteNo.TabIndex = 40
        '
        'lblQuoteNo
        '
        Me.lblQuoteNo.AutoSize = True
        Me.lblQuoteNo.Location = New System.Drawing.Point(799, 71)
        Me.lblQuoteNo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblQuoteNo.Name = "lblQuoteNo"
        Me.lblQuoteNo.Size = New System.Drawing.Size(67, 15)
        Me.lblQuoteNo.TabIndex = 41
        Me.lblQuoteNo.Text = "承認番号"
        '
        'btnReflection
        '
        Me.btnReflection.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnReflection.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnReflection.ForeColor = System.Drawing.Color.White
        Me.btnReflection.Location = New System.Drawing.Point(1040, 64)
        Me.btnReflection.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnReflection.Name = "btnReflection"
        Me.btnReflection.Size = New System.Drawing.Size(143, 30)
        Me.btnReflection.TabIndex = 39
        Me.btnReflection.Text = "反映"
        Me.btnReflection.UseVisualStyleBackColor = False
        '
        'btnChkAll
        '
        Me.btnChkAll.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnChkAll.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnChkAll.ForeColor = System.Drawing.Color.White
        Me.btnChkAll.Location = New System.Drawing.Point(16, 64)
        Me.btnChkAll.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnChkAll.Name = "btnChkAll"
        Me.btnChkAll.Size = New System.Drawing.Size(143, 30)
        Me.btnChkAll.TabIndex = 38
        Me.btnChkAll.Text = "全解除"
        Me.btnChkAll.UseVisualStyleBackColor = False
        '
        'btnOK
        '
        Me.btnOK.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnOK.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOK.ForeColor = System.Drawing.Color.White
        Me.btnOK.Location = New System.Drawing.Point(873, 536)
        Me.btnOK.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(149, 55)
        Me.btnOK.TabIndex = 36
        Me.btnOK.Text = "OK"
        Me.btnOK.UseVisualStyleBackColor = False
        '
        'upalTitle
        '
        Me.upalTitle.BackColor = System.Drawing.Color.Teal
        Me.upalTitle.BackColro2 = System.Drawing.Color.PaleTurquoise
        Me.upalTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.upalTitle.ForeColor = System.Drawing.Color.White
        Me.upalTitle.Location = New System.Drawing.Point(3, 1)
        Me.upalTitle.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.upalTitle.Name = "upalTitle"
        Me.upalTitle.Size = New System.Drawing.Size(1193, 55)
        Me.upalTitle.TabIndex = 34
        Me.upalTitle.TitleText = "OIO BAMA Client　データ補正"
        '
        'btnCancel
        '
        Me.btnCancel.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnCancel.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.ForeColor = System.Drawing.Color.White
        Me.btnCancel.Location = New System.Drawing.Point(1033, 536)
        Me.btnCancel.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(149, 55)
        Me.btnCancel.TabIndex = 42
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.HeaderText = "ファイル名"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.FillWeight = 70.0!
        Me.DataGridViewTextBoxColumn2.HeaderText = "製品番号"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.HeaderText = "製品名"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Width = 200
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.HeaderText = "請求開始年月"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.Width = 120
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.HeaderText = "請求終了年月"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.Width = 120
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.HeaderText = "ListPrice"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        '
        'Frm_DataCorrection
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(1197, 604)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.lblQuoteNo)
        Me.Controls.Add(Me.txtQuoteNo)
        Me.Controls.Add(Me.btnReflection)
        Me.Controls.Add(Me.btnChkAll)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.dgvConfig)
        Me.Controls.Add(Me.upalTitle)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.MaximizeBox = False
        Me.Name = "Frm_DataCorrection"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "OIO BAMA Client"
        CType(Me.dgvConfig, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents upalTitle As MUSE.UserControl.UCnt_Pal0001
    Friend WithEvents dgvConfig As System.Windows.Forms.DataGridView
    Friend WithEvents btnOK As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column7 As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents Column8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents btnChkAll As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents btnReflection As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents txtQuoteNo As System.Windows.Forms.TextBox
    Friend WithEvents lblQuoteNo As System.Windows.Forms.Label
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents btnCancel As MUSE.UserControl.UCnt_Btn0001
End Class
