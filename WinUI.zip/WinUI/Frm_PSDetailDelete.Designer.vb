﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frm_PSDetailDelete
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtContract = New System.Windows.Forms.TextBox()
        Me.txtCpnoName = New System.Windows.Forms.TextBox()
        Me.txtCustomerName = New System.Windows.Forms.TextBox()
        Me.txtModifyNo = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblInPaymentSheet = New System.Windows.Forms.Label()
        Me.btnLogOut = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnReturn = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnDelPSDetailData = New MUSE.UserControl.UCnt_Btn0001()
        Me.UCnt_Pal00011 = New MUSE.UserControl.UCnt_Pal0001()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lsv_SelectDel = New System.Windows.Forms.ListView()
        Me.ファイル名 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.No = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.案件番号 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtContract
        '
        Me.txtContract.BackColor = System.Drawing.SystemColors.Control
        Me.txtContract.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtContract.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.txtContract.Location = New System.Drawing.Point(284, 45)
        Me.txtContract.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtContract.Name = "txtContract"
        Me.txtContract.ReadOnly = True
        Me.txtContract.Size = New System.Drawing.Size(109, 15)
        Me.txtContract.TabIndex = 72
        Me.txtContract.TabStop = False
        Me.txtContract.Visible = False
        '
        'txtCpnoName
        '
        Me.txtCpnoName.BackColor = System.Drawing.SystemColors.Control
        Me.txtCpnoName.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtCpnoName.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.txtCpnoName.Location = New System.Drawing.Point(160, 22)
        Me.txtCpnoName.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtCpnoName.Name = "txtCpnoName"
        Me.txtCpnoName.ReadOnly = True
        Me.txtCpnoName.Size = New System.Drawing.Size(325, 15)
        Me.txtCpnoName.TabIndex = 73
        Me.txtCpnoName.TabStop = False
        '
        'txtCustomerName
        '
        Me.txtCustomerName.Enabled = False
        Me.txtCustomerName.Location = New System.Drawing.Point(351, 115)
        Me.txtCustomerName.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtCustomerName.Name = "txtCustomerName"
        Me.txtCustomerName.Size = New System.Drawing.Size(63, 22)
        Me.txtCustomerName.TabIndex = 75
        Me.txtCustomerName.Visible = False
        '
        'txtModifyNo
        '
        Me.txtModifyNo.BackColor = System.Drawing.SystemColors.Control
        Me.txtModifyNo.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtModifyNo.Font = New System.Drawing.Font("MS UI Gothic", 9.0!)
        Me.txtModifyNo.Location = New System.Drawing.Point(160, 46)
        Me.txtModifyNo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtModifyNo.Name = "txtModifyNo"
        Me.txtModifyNo.ReadOnly = True
        Me.txtModifyNo.Size = New System.Drawing.Size(109, 15)
        Me.txtModifyNo.TabIndex = 76
        Me.txtModifyNo.TabStop = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtModifyNo)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.txtCpnoName)
        Me.GroupBox1.Controls.Add(Me.txtContract)
        Me.GroupBox1.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(21, 62)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Size = New System.Drawing.Size(827, 76)
        Me.GroupBox1.TabIndex = 79
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "契約情報"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label4.Location = New System.Drawing.Point(13, 26)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(130, 15)
        Me.Label4.TabIndex = 51
        Me.Label4.Text = "お客様名（CPNO）"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label6.Location = New System.Drawing.Point(13, 50)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(71, 15)
        Me.Label6.TabIndex = 53
        Me.Label6.Text = "契約順番"
        '
        'lblInPaymentSheet
        '
        Me.lblInPaymentSheet.AutoSize = True
        Me.lblInPaymentSheet.Location = New System.Drawing.Point(19, 156)
        Me.lblInPaymentSheet.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblInPaymentSheet.Name = "lblInPaymentSheet"
        Me.lblInPaymentSheet.Size = New System.Drawing.Size(101, 15)
        Me.lblInPaymentSheet.TabIndex = 74
        Me.lblInPaymentSheet.Text = "削除対象データ"
        '
        'btnLogOut
        '
        Me.btnLogOut.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnLogOut.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogOut.ForeColor = System.Drawing.Color.White
        Me.btnLogOut.Location = New System.Drawing.Point(37, 536)
        Me.btnLogOut.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnLogOut.Name = "btnLogOut"
        Me.btnLogOut.Size = New System.Drawing.Size(177, 55)
        Me.btnLogOut.TabIndex = 50
        Me.btnLogOut.Text = "ログアウト"
        Me.btnLogOut.UseVisualStyleBackColor = False
        '
        'btnReturn
        '
        Me.btnReturn.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnReturn.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReturn.ForeColor = System.Drawing.Color.White
        Me.btnReturn.Location = New System.Drawing.Point(237, 536)
        Me.btnReturn.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnReturn.Name = "btnReturn"
        Me.btnReturn.Size = New System.Drawing.Size(177, 55)
        Me.btnReturn.TabIndex = 40
        Me.btnReturn.Text = "構成取込へ"
        Me.btnReturn.UseVisualStyleBackColor = False
        '
        'btnDelPSDetailData
        '
        Me.btnDelPSDetailData.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnDelPSDetailData.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelPSDetailData.ForeColor = System.Drawing.Color.White
        Me.btnDelPSDetailData.Location = New System.Drawing.Point(627, 536)
        Me.btnDelPSDetailData.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnDelPSDetailData.Name = "btnDelPSDetailData"
        Me.btnDelPSDetailData.Size = New System.Drawing.Size(177, 55)
        Me.btnDelPSDetailData.TabIndex = 20
        Me.btnDelPSDetailData.Text = "取り消し"
        Me.btnDelPSDetailData.UseVisualStyleBackColor = False
        '
        'UCnt_Pal00011
        '
        Me.UCnt_Pal00011.BackColor = System.Drawing.Color.Teal
        Me.UCnt_Pal00011.BackColro2 = System.Drawing.Color.PaleTurquoise
        Me.UCnt_Pal00011.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UCnt_Pal00011.ForeColor = System.Drawing.Color.White
        Me.UCnt_Pal00011.Location = New System.Drawing.Point(0, 0)
        Me.UCnt_Pal00011.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.UCnt_Pal00011.Name = "UCnt_Pal00011"
        Me.UCnt_Pal00011.Size = New System.Drawing.Size(871, 55)
        Me.UCnt_Pal00011.TabIndex = 32
        Me.UCnt_Pal00011.TitleText = "OIO BAMA Client 構成情報取消し"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Red
        Me.Label3.Location = New System.Drawing.Point(19, 515)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(579, 15)
        Me.Label3.TabIndex = 80
        Me.Label3.Text = "※手作業で修正したデータは削除処理後、リカバリできません。削除前に確認してください。"
        '
        'lsv_SelectDel
        '
        Me.lsv_SelectDel.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ファイル名, Me.No, Me.案件番号})
        Me.lsv_SelectDel.Location = New System.Drawing.Point(21, 175)
        Me.lsv_SelectDel.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.lsv_SelectDel.Name = "lsv_SelectDel"
        Me.lsv_SelectDel.Size = New System.Drawing.Size(825, 335)
        Me.lsv_SelectDel.TabIndex = 10
        Me.lsv_SelectDel.UseCompatibleStateImageBehavior = False
        '
        'ファイル名
        '
        Me.ファイル名.Text = "ファイル名"
        Me.ファイル名.Width = 350
        '
        'No
        '
        Me.No.Text = "No"
        '
        '案件番号
        '
        Me.案件番号.Text = "案件番号"
        Me.案件番号.Width = 200
        '
        'Frm_PSDetailDelete
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(829, 578)
        Me.ControlBox = False
        Me.Controls.Add(Me.lsv_SelectDel)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnLogOut)
        Me.Controls.Add(Me.btnReturn)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.lblInPaymentSheet)
        Me.Controls.Add(Me.btnDelPSDetailData)
        Me.Controls.Add(Me.txtCustomerName)
        Me.Controls.Add(Me.UCnt_Pal00011)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.MaximizeBox = False
        Me.Name = "Frm_PSDetailDelete"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "OIO BAMA Client "
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents UCnt_Pal00011 As MUSE.UserControl.UCnt_Pal0001
    Friend WithEvents btnDelPSDetailData As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents txtContract As System.Windows.Forms.TextBox
    Friend WithEvents txtCpnoName As System.Windows.Forms.TextBox
    Friend WithEvents txtCustomerName As System.Windows.Forms.TextBox
    Friend WithEvents txtModifyNo As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents btnLogOut As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents btnReturn As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents lblInPaymentSheet As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lsv_SelectDel As System.Windows.Forms.ListView
    Friend WithEvents ファイル名 As System.Windows.Forms.ColumnHeader
    Friend WithEvents No As System.Windows.Forms.ColumnHeader
    Friend WithEvents 案件番号 As System.Windows.Forms.ColumnHeader
End Class
