﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frm_DataOutput
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Btn_OutKakakuSyouninNonLock = New MUSE.UserControl.UCnt_Btn0001()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Cmb_SumPaymentSheet = New System.Windows.Forms.ComboBox()
        Me.Btn_OutKakakuSyounin = New MUSE.UserControl.UCnt_Btn0001()
        Me.lbl_Contract = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.txb_ChangePage = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.txb_InputFile = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Btn_OutCOCPS = New MUSE.UserControl.UCnt_Btn0001()
        Me.txb_DispCpno = New System.Windows.Forms.TextBox()
        Me.txb_DispCustNm = New System.Windows.Forms.TextBox()
        Me.txb_DispKeiyakuZyunban = New System.Windows.Forms.TextBox()
        Me.txb_Contact_No_Name = New System.Windows.Forms.TextBox()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.Btn_OutSeikyu = New MUSE.UserControl.UCnt_Btn0001()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.Btn_OutProjctIOC = New MUSE.UserControl.UCnt_Btn0001()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.ChkValOut = New System.Windows.Forms.CheckBox()
        Me.ChkCostDel = New System.Windows.Forms.CheckBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Btn_OutConList = New MUSE.UserControl.UCnt_Btn0001()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.Btn_DelCheckList = New MUSE.UserControl.UCnt_Btn0001()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.DispExplorer1 = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnLogOut = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Rtn = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_InputFileDisp = New MUSE.UserControl.UCnt_Btn0001()
        Me.UCnt_Pal00011 = New MUSE.UserControl.UCnt_Pal0001()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Btn_Extension = New MUSE.UserControl.UCnt_Btn0001()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Btn_SerialCheckList = New MUSE.UserControl.UCnt_Btn0001()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Btn_OutKakakuSyouninNonLock)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Cmb_SumPaymentSheet)
        Me.GroupBox1.Controls.Add(Me.Btn_OutKakakuSyounin)
        Me.GroupBox1.Location = New System.Drawing.Point(32, 197)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(674, 56)
        Me.GroupBox1.TabIndex = 30
        Me.GroupBox1.TabStop = False
        '
        'Btn_OutKakakuSyouninNonLock
        '
        Me.Btn_OutKakakuSyouninNonLock.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Btn_OutKakakuSyouninNonLock.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_OutKakakuSyouninNonLock.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Btn_OutKakakuSyouninNonLock.ForeColor = System.Drawing.Color.White
        Me.Btn_OutKakakuSyouninNonLock.Location = New System.Drawing.Point(423, 20)
        Me.Btn_OutKakakuSyouninNonLock.Name = "Btn_OutKakakuSyouninNonLock"
        Me.Btn_OutKakakuSyouninNonLock.Size = New System.Drawing.Size(110, 30)
        Me.Btn_OutKakakuSyouninNonLock.TabIndex = 54
        Me.Btn_OutKakakuSyouninNonLock.Text = "作成"
        Me.Btn_OutKakakuSyouninNonLock.UseVisualStyleBackColor = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(11, 25)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(123, 12)
        Me.Label4.TabIndex = 53
        Me.Label4.Text = "価格承認サマリーファイル"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(191, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(97, 12)
        Me.Label1.TabIndex = 52
        Me.Label1.Text = "統合Payment出力"
        '
        'Cmb_SumPaymentSheet
        '
        Me.Cmb_SumPaymentSheet.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_SumPaymentSheet.FormattingEnabled = True
        Me.Cmb_SumPaymentSheet.Location = New System.Drawing.Point(188, 30)
        Me.Cmb_SumPaymentSheet.Name = "Cmb_SumPaymentSheet"
        Me.Cmb_SumPaymentSheet.Size = New System.Drawing.Size(111, 20)
        Me.Cmb_SumPaymentSheet.TabIndex = 31
        '
        'Btn_OutKakakuSyounin
        '
        Me.Btn_OutKakakuSyounin.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Btn_OutKakakuSyounin.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_OutKakakuSyounin.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Btn_OutKakakuSyounin.ForeColor = System.Drawing.Color.White
        Me.Btn_OutKakakuSyounin.Location = New System.Drawing.Point(549, 20)
        Me.Btn_OutKakakuSyounin.Name = "Btn_OutKakakuSyounin"
        Me.Btn_OutKakakuSyounin.Size = New System.Drawing.Size(110, 30)
        Me.Btn_OutKakakuSyounin.TabIndex = 31
        Me.Btn_OutKakakuSyounin.Text = "作成(LOCK済)"
        Me.Btn_OutKakakuSyounin.UseVisualStyleBackColor = False
        '
        'lbl_Contract
        '
        Me.lbl_Contract.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lbl_Contract.Location = New System.Drawing.Point(561, 110)
        Me.lbl_Contract.Name = "lbl_Contract"
        Me.lbl_Contract.Size = New System.Drawing.Size(155, 16)
        Me.lbl_Contract.TabIndex = 26
        Me.lbl_Contract.Text = "0"
        Me.lbl_Contract.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(392, 114)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(100, 12)
        Me.Label28.TabIndex = 295
        Me.Label28.Text = "契約済みﾃﾞｰﾀ件数"
        '
        'txb_ChangePage
        '
        Me.txb_ChangePage.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txb_ChangePage.BackColor = System.Drawing.Color.Yellow
        Me.txb_ChangePage.ImeMode = System.Windows.Forms.ImeMode.Alpha
        Me.txb_ChangePage.Location = New System.Drawing.Point(559, 128)
        Me.txb_ChangePage.Name = "txb_ChangePage"
        Me.txb_ChangePage.Size = New System.Drawing.Size(157, 19)
        Me.txb_ChangePage.TabIndex = 27
        Me.txb_ChangePage.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(392, 131)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(121, 12)
        Me.Label27.TabIndex = 296
        Me.Label27.Text = "統合Payment分割件数"
        '
        'txb_InputFile
        '
        Me.txb_InputFile.BackColor = System.Drawing.Color.Yellow
        Me.txb_InputFile.Location = New System.Drawing.Point(32, 174)
        Me.txb_InputFile.Name = "txb_InputFile"
        Me.txb_InputFile.ReadOnly = True
        Me.txb_InputFile.Size = New System.Drawing.Size(533, 19)
        Me.txb_InputFile.TabIndex = 10
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(31, 157)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(151, 12)
        Me.Label5.TabIndex = 51
        Me.Label5.Text = "Payment(作業用)ファイル指定"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Btn_OutCOCPS)
        Me.GroupBox2.Location = New System.Drawing.Point(32, 255)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(674, 36)
        Me.GroupBox2.TabIndex = 40
        Me.GroupBox2.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(10, 17)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(198, 12)
        Me.Label6.TabIndex = 54
        Me.Label6.Text = "統合Payment_Brand別集計ﾌｧｲﾙ(IOC)"
        '
        'Btn_OutCOCPS
        '
        Me.Btn_OutCOCPS.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Btn_OutCOCPS.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_OutCOCPS.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Btn_OutCOCPS.ForeColor = System.Drawing.Color.White
        Me.Btn_OutCOCPS.Location = New System.Drawing.Point(549, 8)
        Me.Btn_OutCOCPS.Name = "Btn_OutCOCPS"
        Me.Btn_OutCOCPS.Size = New System.Drawing.Size(110, 25)
        Me.Btn_OutCOCPS.TabIndex = 40
        Me.Btn_OutCOCPS.Text = "作成"
        Me.Btn_OutCOCPS.UseVisualStyleBackColor = False
        '
        'txb_DispCpno
        '
        Me.txb_DispCpno.BackColor = System.Drawing.SystemColors.Control
        Me.txb_DispCpno.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txb_DispCpno.Enabled = False
        Me.txb_DispCpno.Location = New System.Drawing.Point(94, 20)
        Me.txb_DispCpno.Name = "txb_DispCpno"
        Me.txb_DispCpno.Size = New System.Drawing.Size(255, 12)
        Me.txb_DispCpno.TabIndex = 74
        Me.txb_DispCpno.TabStop = False
        '
        'txb_DispCustNm
        '
        Me.txb_DispCustNm.BackColor = System.Drawing.SystemColors.Control
        Me.txb_DispCustNm.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txb_DispCustNm.Enabled = False
        Me.txb_DispCustNm.Location = New System.Drawing.Point(94, 38)
        Me.txb_DispCustNm.Name = "txb_DispCustNm"
        Me.txb_DispCustNm.Size = New System.Drawing.Size(255, 12)
        Me.txb_DispCustNm.TabIndex = 77
        Me.txb_DispCustNm.TabStop = False
        '
        'txb_DispKeiyakuZyunban
        '
        Me.txb_DispKeiyakuZyunban.BackColor = System.Drawing.SystemColors.Control
        Me.txb_DispKeiyakuZyunban.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txb_DispKeiyakuZyunban.Enabled = False
        Me.txb_DispKeiyakuZyunban.Location = New System.Drawing.Point(94, 56)
        Me.txb_DispKeiyakuZyunban.Name = "txb_DispKeiyakuZyunban"
        Me.txb_DispKeiyakuZyunban.Size = New System.Drawing.Size(255, 12)
        Me.txb_DispKeiyakuZyunban.TabIndex = 79
        Me.txb_DispKeiyakuZyunban.TabStop = False
        '
        'txb_Contact_No_Name
        '
        Me.txb_Contact_No_Name.BackColor = System.Drawing.SystemColors.Control
        Me.txb_Contact_No_Name.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txb_Contact_No_Name.Enabled = False
        Me.txb_Contact_No_Name.Location = New System.Drawing.Point(94, 72)
        Me.txb_Contact_No_Name.Name = "txb_Contact_No_Name"
        Me.txb_Contact_No_Name.Size = New System.Drawing.Size(255, 12)
        Me.txb_Contact_No_Name.TabIndex = 113
        Me.txb_Contact_No_Name.TabStop = False
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.Label26)
        Me.GroupBox9.Controls.Add(Me.Label22)
        Me.GroupBox9.Controls.Add(Me.Label23)
        Me.GroupBox9.Controls.Add(Me.txb_Contact_No_Name)
        Me.GroupBox9.Controls.Add(Me.Label24)
        Me.GroupBox9.Controls.Add(Me.txb_DispCpno)
        Me.GroupBox9.Controls.Add(Me.txb_DispKeiyakuZyunban)
        Me.GroupBox9.Controls.Add(Me.txb_DispCustNm)
        Me.GroupBox9.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.GroupBox9.Location = New System.Drawing.Point(32, 51)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(355, 96)
        Me.GroupBox9.TabIndex = 264
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "契約情報"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label26.Location = New System.Drawing.Point(10, 20)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(40, 12)
        Me.Label26.TabIndex = 55
        Me.Label26.Text = "CPNO"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label22.Location = New System.Drawing.Point(10, 72)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(70, 12)
        Me.Label22.TabIndex = 53
        Me.Label22.Text = "契約順番名"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label23.Location = New System.Drawing.Point(10, 38)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(55, 12)
        Me.Label23.TabIndex = 51
        Me.Label23.Text = "お客様名"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label24.Location = New System.Drawing.Point(10, 56)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(57, 12)
        Me.Label24.TabIndex = 53
        Me.Label24.Text = "契約順番"
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.Btn_OutSeikyu)
        Me.GroupBox10.Controls.Add(Me.Label21)
        Me.GroupBox10.Location = New System.Drawing.Point(32, 295)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(674, 36)
        Me.GroupBox10.TabIndex = 65
        Me.GroupBox10.TabStop = False
        '
        'Btn_OutSeikyu
        '
        Me.Btn_OutSeikyu.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Btn_OutSeikyu.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_OutSeikyu.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Btn_OutSeikyu.ForeColor = System.Drawing.Color.White
        Me.Btn_OutSeikyu.Location = New System.Drawing.Point(549, 8)
        Me.Btn_OutSeikyu.Name = "Btn_OutSeikyu"
        Me.Btn_OutSeikyu.Size = New System.Drawing.Size(110, 25)
        Me.Btn_OutSeikyu.TabIndex = 65
        Me.Btn_OutSeikyu.Text = "作成"
        Me.Btn_OutSeikyu.UseVisualStyleBackColor = False
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(10, 17)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(101, 12)
        Me.Label21.TabIndex = 4
        Me.Label21.Text = "請求品目管理資料"
        '
        'GroupBox11
        '
        Me.GroupBox11.Controls.Add(Me.Btn_OutProjctIOC)
        Me.GroupBox11.Controls.Add(Me.Label19)
        Me.GroupBox11.Location = New System.Drawing.Point(32, 335)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(674, 34)
        Me.GroupBox11.TabIndex = 70
        Me.GroupBox11.TabStop = False
        '
        'Btn_OutProjctIOC
        '
        Me.Btn_OutProjctIOC.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Btn_OutProjctIOC.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_OutProjctIOC.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Btn_OutProjctIOC.ForeColor = System.Drawing.Color.White
        Me.Btn_OutProjctIOC.Location = New System.Drawing.Point(549, 6)
        Me.Btn_OutProjctIOC.Name = "Btn_OutProjctIOC"
        Me.Btn_OutProjctIOC.Size = New System.Drawing.Size(110, 25)
        Me.Btn_OutProjctIOC.TabIndex = 65
        Me.Btn_OutProjctIOC.Text = "作成"
        Me.Btn_OutProjctIOC.UseVisualStyleBackColor = False
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(10, 17)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(108, 12)
        Me.Label19.TabIndex = 4
        Me.Label19.Text = "案件別IOC資料作成"
        '
        'ChkValOut
        '
        Me.ChkValOut.AutoSize = True
        Me.ChkValOut.Checked = True
        Me.ChkValOut.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ChkValOut.Location = New System.Drawing.Point(409, 94)
        Me.ChkValOut.Name = "ChkValOut"
        Me.ChkValOut.Size = New System.Drawing.Size(146, 16)
        Me.ChkValOut.TabIndex = 26
        Me.ChkValOut.Text = "計算式を使用せずに出力"
        Me.ChkValOut.UseVisualStyleBackColor = True
        '
        'ChkCostDel
        '
        Me.ChkCostDel.AutoSize = True
        Me.ChkCostDel.Location = New System.Drawing.Point(409, 76)
        Me.ChkCostDel.Name = "ChkCostDel"
        Me.ChkCostDel.Size = New System.Drawing.Size(208, 16)
        Me.ChkCostDel.TabIndex = 25
        Me.ChkCostDel.Text = "COST情報を削除した別ファイルを出力"
        Me.ChkCostDel.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Btn_OutConList)
        Me.GroupBox5.Controls.Add(Me.Label3)
        Me.GroupBox5.Location = New System.Drawing.Point(33, 375)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(674, 36)
        Me.GroupBox5.TabIndex = 72
        Me.GroupBox5.TabStop = False
        '
        'Btn_OutConList
        '
        Me.Btn_OutConList.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Btn_OutConList.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_OutConList.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Btn_OutConList.ForeColor = System.Drawing.Color.White
        Me.Btn_OutConList.Location = New System.Drawing.Point(549, 8)
        Me.Btn_OutConList.Name = "Btn_OutConList"
        Me.Btn_OutConList.Size = New System.Drawing.Size(110, 25)
        Me.Btn_OutConList.TabIndex = 65
        Me.Btn_OutConList.Text = "作成"
        Me.Btn_OutConList.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(10, 17)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(108, 12)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "契約履歴チェックリスト"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(393, 59)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(77, 12)
        Me.Label2.TabIndex = 297
        Me.Label2.Text = "出力内容指定"
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.Btn_DelCheckList)
        Me.GroupBox6.Controls.Add(Me.Label9)
        Me.GroupBox6.Location = New System.Drawing.Point(33, 415)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(674, 36)
        Me.GroupBox6.TabIndex = 299
        Me.GroupBox6.TabStop = False
        '
        'Btn_DelCheckList
        '
        Me.Btn_DelCheckList.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Btn_DelCheckList.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_DelCheckList.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Btn_DelCheckList.ForeColor = System.Drawing.Color.White
        Me.Btn_DelCheckList.Location = New System.Drawing.Point(549, 8)
        Me.Btn_DelCheckList.Name = "Btn_DelCheckList"
        Me.Btn_DelCheckList.Size = New System.Drawing.Size(110, 25)
        Me.Btn_DelCheckList.TabIndex = 65
        Me.Btn_DelCheckList.Text = "作成"
        Me.Btn_DelCheckList.UseVisualStyleBackColor = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(10, 17)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(148, 12)
        Me.Label9.TabIndex = 4
        Me.Label9.Text = "削除データ妥当性チェックリスト"
        '
        'DispExplorer1
        '
        Me.DispExplorer1.BackColor = System.Drawing.Color.RoyalBlue
        Me.DispExplorer1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DispExplorer1.ForeColor = System.Drawing.Color.White
        Me.DispExplorer1.Location = New System.Drawing.Point(572, 534)
        Me.DispExplorer1.Name = "DispExplorer1"
        Me.DispExplorer1.Size = New System.Drawing.Size(136, 44)
        Me.DispExplorer1.TabIndex = 75
        Me.DispExplorer1.Text = "ﾌｫﾙﾀﾞ表示"
        Me.DispExplorer1.UseVisualStyleBackColor = False
        '
        'btnLogOut
        '
        Me.btnLogOut.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnLogOut.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogOut.ForeColor = System.Drawing.Color.White
        Me.btnLogOut.Location = New System.Drawing.Point(32, 537)
        Me.btnLogOut.Name = "btnLogOut"
        Me.btnLogOut.Size = New System.Drawing.Size(133, 44)
        Me.btnLogOut.TabIndex = 263
        Me.btnLogOut.Text = "ログアウト"
        Me.btnLogOut.UseVisualStyleBackColor = False
        '
        'Btn_Rtn
        '
        Me.Btn_Rtn.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Rtn.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Rtn.ForeColor = System.Drawing.Color.White
        Me.Btn_Rtn.Location = New System.Drawing.Point(198, 537)
        Me.Btn_Rtn.Name = "Btn_Rtn"
        Me.Btn_Rtn.Size = New System.Drawing.Size(133, 44)
        Me.Btn_Rtn.TabIndex = 110
        Me.Btn_Rtn.Text = "メニューへ"
        Me.Btn_Rtn.UseVisualStyleBackColor = False
        '
        'Btn_InputFileDisp
        '
        Me.Btn_InputFileDisp.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_InputFileDisp.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Btn_InputFileDisp.ForeColor = System.Drawing.Color.White
        Me.Btn_InputFileDisp.Location = New System.Drawing.Point(582, 169)
        Me.Btn_InputFileDisp.Name = "Btn_InputFileDisp"
        Me.Btn_InputFileDisp.Size = New System.Drawing.Size(109, 29)
        Me.Btn_InputFileDisp.TabIndex = 20
        Me.Btn_InputFileDisp.Text = "参照"
        Me.Btn_InputFileDisp.UseVisualStyleBackColor = False
        '
        'UCnt_Pal00011
        '
        Me.UCnt_Pal00011.BackColor = System.Drawing.Color.Teal
        Me.UCnt_Pal00011.BackColro2 = System.Drawing.Color.PaleTurquoise
        Me.UCnt_Pal00011.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UCnt_Pal00011.ForeColor = System.Drawing.Color.White
        Me.UCnt_Pal00011.Location = New System.Drawing.Point(0, 1)
        Me.UCnt_Pal00011.Name = "UCnt_Pal00011"
        Me.UCnt_Pal00011.Size = New System.Drawing.Size(742, 44)
        Me.UCnt_Pal00011.TabIndex = 32
        Me.UCnt_Pal00011.TitleText = "OIO BAMA Client 集計及び台帳作成"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Btn_Extension)
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Location = New System.Drawing.Point(32, 455)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(674, 36)
        Me.GroupBox3.TabIndex = 300
        Me.GroupBox3.TabStop = False
        '
        'Btn_Extension
        '
        Me.Btn_Extension.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Btn_Extension.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Extension.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Btn_Extension.ForeColor = System.Drawing.Color.White
        Me.Btn_Extension.Location = New System.Drawing.Point(549, 8)
        Me.Btn_Extension.Name = "Btn_Extension"
        Me.Btn_Extension.Size = New System.Drawing.Size(110, 25)
        Me.Btn_Extension.TabIndex = 65
        Me.Btn_Extension.Text = "作成"
        Me.Btn_Extension.UseVisualStyleBackColor = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(10, 17)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(101, 12)
        Me.Label7.TabIndex = 4
        Me.Label7.Text = "延長契約候補ﾃﾞｰﾀ"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Btn_SerialCheckList)
        Me.GroupBox4.Controls.Add(Me.Label8)
        Me.GroupBox4.Location = New System.Drawing.Point(33, 495)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(674, 36)
        Me.GroupBox4.TabIndex = 301
        Me.GroupBox4.TabStop = False
        '
        'Btn_SerialCheckList
        '
        Me.Btn_SerialCheckList.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Btn_SerialCheckList.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_SerialCheckList.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Btn_SerialCheckList.ForeColor = System.Drawing.Color.White
        Me.Btn_SerialCheckList.Location = New System.Drawing.Point(549, 8)
        Me.Btn_SerialCheckList.Name = "Btn_SerialCheckList"
        Me.Btn_SerialCheckList.Size = New System.Drawing.Size(110, 25)
        Me.Btn_SerialCheckList.TabIndex = 65
        Me.Btn_SerialCheckList.Text = "作成"
        Me.Btn_SerialCheckList.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(10, 17)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(120, 12)
        Me.Label8.TabIndex = 4
        Me.Label8.Text = "シリアル重複チェックリスト"
        '
        'Frm_DataOutput
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(754, 596)
        Me.ControlBox = False
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.lbl_Contract)
        Me.Controls.Add(Me.DispExplorer1)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.txb_ChangePage)
        Me.Controls.Add(Me.ChkValOut)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.ChkCostDel)
        Me.Controls.Add(Me.GroupBox11)
        Me.Controls.Add(Me.GroupBox10)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox9)
        Me.Controls.Add(Me.btnLogOut)
        Me.Controls.Add(Me.Btn_Rtn)
        Me.Controls.Add(Me.Btn_InputFileDisp)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txb_InputFile)
        Me.Controls.Add(Me.UCnt_Pal00011)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "Frm_DataOutput"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "OIO BAMA Client"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        Me.GroupBox11.ResumeLayout(False)
        Me.GroupBox11.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents UCnt_Pal00011 As MUSE.UserControl.UCnt_Pal0001
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Btn_OutKakakuSyounin As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents txb_InputFile As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Btn_InputFileDisp As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Btn_OutCOCPS As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Rtn As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents txb_DispCpno As System.Windows.Forms.TextBox
    Friend WithEvents txb_DispCustNm As System.Windows.Forms.TextBox
    Friend WithEvents txb_DispKeiyakuZyunban As System.Windows.Forms.TextBox
    Friend WithEvents txb_Contact_No_Name As System.Windows.Forms.TextBox
    Friend WithEvents btnLogOut As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents Btn_OutSeikyu As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents DispExplorer1 As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents GroupBox11 As System.Windows.Forms.GroupBox
    Friend WithEvents Btn_OutProjctIOC As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents lbl_Contract As System.Windows.Forms.Label
    Friend WithEvents txb_ChangePage As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents ChkValOut As System.Windows.Forms.CheckBox
    Friend WithEvents ChkCostDel As System.Windows.Forms.CheckBox
    Friend WithEvents Cmb_SumPaymentSheet As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Btn_OutConList As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents Btn_DelCheckList As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Btn_OutKakakuSyouninNonLock As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Btn_Extension As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Btn_SerialCheckList As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Label8 As System.Windows.Forms.Label
End Class
