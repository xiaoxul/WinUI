﻿Imports System.IO
Imports System.Text
Imports Microsoft.Office.Interop
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.OioBamaCommmon
Imports MUSE.Utility
Imports System.Data.OleDb
Imports MUSE.Utility.UserDataTable.Master

''' <summary>
''' 機　能：WS1を作成
''' 説　明：PaymentLineSample.xlsからの移植
''' 　　　　サマリー出力はなし。そのまま移植しているため変数名等に全角を使用している
''' </summary>
''' <remarks></remarks>
Public Class CreateWS1

#Region "定数"
    Private Const WS1_変更Dummy行 As Integer = 3
    Private Const WS1_案件Dummy行 As Integer = 4
    Private Const WS1_表題列 As Integer = 2
    Private Const WS1_変更契約見出し As String = "2)変更契約情報"
    Private Const WS1_案件情報見出し As String = "3)案件情報"

    'START 変更管理#8（No.791 Office2013対応）　2014/11/26 sugo
    Private Const WS1_項目の位置_VERSION As String = "C1"
    'Private Const WS1_項目の位置_VERSION As String = "H1"
    'END   変更管理#8（No.791 Office2013対応）　2014/11/26 sugo
    Private Const WS1_項目の位置_CPNO As String = "B7"
    Private Const WS1_項目の位置_CPNAME As String = "C7"
    Private Const WS1_項目の位置_請求開始年月 As String = "F7"
    Private Const WS1_項目の位置_請求終了年月 As String = "G7"
    Private Const WS1_項目の位置_Excel開始年月 As String = "H7"
    'START 変更管理#8（No.791 Office2013対応）　2014/11/26 sugo
    Private Const WS1_項目の位置_Payment出力終了 As String = "I7"
    'Private Const WS1_項目の位置_アニバーサリーDate As String = "I7"

    'Private Const 項目の位置_リスト_契約開始年 As String = "AL2"
    'Private Const 項目の位置_リスト_契約開始月 As String = "AL3"
    'Private Const 項目の位置_リスト_契約終了年 As String = "AM2"
    'Private Const 項目の位置_リスト_契約終了月 As String = "AM3"
    'END   変更管理#8（No.791 Office2013対応）　2014/11/26 sugo

    Private Const SHEET_NAME_WS1 As String = ExcelWrite.EXCEL_PAYMENTLINEDATE_WS1

#End Region

#Region "構造体"
    Private Structure WS1出力用_契約基本情報
        Dim CPNO As String
        Dim お客様名 As String
        Dim 契約期間_開始年 As String
        Dim 契約期間_開始月 As String
        Dim 契約期間_終了年 As String
        Dim 契約期間_終了月 As String
        Dim 契約期間_EXCEL年月 As String
        'START 変更管理#8（No.791 Office2013対応）　2014/11/26 sugo
        Dim 契約期間_Payment出力終了 As String
        'Dim 統合処理の有無 As String
        'Dim PAアニバーサリーDate As String
        'END   変更管理#8（No.791 Office2013対応）　2014/11/26 sugo
    End Structure

    Private Structure WS1出力用_契約明細情報
        Dim 契約順番 As String
        Dim 契約順番名 As String
        'START 変更管理#8（No.791 Office2013対応）　2014/11/26 sugo
        Dim 提案開始 As String
        'Dim 部署名 As String
        'Dim PAアニバーサリーDate As String
        'Dim 提案開始 As String
        'Dim PALevel As String
        'Dim 価格承認依頼日 As String
        'Dim 契約締結日 As String
        'END   変更管理#8（No.791 Office2013対応）　2014/11/26 sugo
        Dim ステータス As String
    End Structure

    Private Structure WS1出力用_案件明細情報
        Dim 案件名 As String
        Dim 案件番号1 As String
        Dim 案件番号2 As String
        Dim 案件番号3 As String
        Dim 案件番号4 As String
    End Structure

#End Region

#Region "Public"
    ''' <summary>
    '''機　能：WS1シートを再作成
    ''' </summary>
    ''' <param name="xlBook"></param>
    ''' <param name="excelPW"></param>
    ''' <remarks></remarks>
    'START 変更管理#8（No.791 Office2013対応）　2014/12/01 sugo
    Public Sub WS1の作成(ByRef xlBook As Excel.Workbook,
                         ByVal intPaymentPeriod As Integer,
                         ByVal excelPW As String)
        'Public Sub WS1の作成(ByRef xlBook As Excel.Workbook, _
        '             ByVal excelPW As String)
        'END   変更管理#8（No.791 Office2013対応）　2014/12/01 sugo

        Dim xlSheets As Excel.Sheets = Nothing
        Dim xlSheet As Excel.Worksheet = Nothing
        Dim xlShape As Excel.Shape = Nothing

        Try
            xlSheet = xlBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_WS1)
            xlSheet.Unprotect(excelPW)

            ''WS1シートを削除
            Call WS1シートの削除(xlBook)

            ''WS1シート作成情報を取得
            Dim WS1出力用_契約基本情報 As WS1出力用_契約基本情報
            Dim WS1出力用_契約明細情報() As WS1出力用_契約明細情報
            Dim WS1の出力情報取得_案件明細情報() As WS1出力用_案件明細情報
            'START 変更管理#8（No.791 Office2013対応）　2014/12/01 sugo
            Call WS1出力用情報の取得(xlBook,
                                     intPaymentPeriod,
                                     WS1出力用_契約基本情報,
                                     WS1出力用_契約明細情報, _
                                     WS1の出力情報取得_案件明細情報)
            'Call WS1出力用情報の取得(xlBook,
            '                         WS1出力用_契約基本情報,
            '                         WS1出力用_契約明細情報, _
            '                         WS1の出力情報取得_案件明細情報)
            'END   変更管理#8（No.791 Office2013対応）　2014/12/01 sugo

            ''WS1シートの書込
            Call WS1シートの書込(xlBook, _
                                 WS1出力用_契約基本情報,
                                 WS1出力用_契約明細情報, _
                                 WS1の出力情報取得_案件明細情報)

            xlSheet = xlBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_WS1)

            ExcelObjRelease.ReleaseExcelObj(xlShape, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "WS1シートの再作成")

        End Try

    End Sub

#End Region

#Region "Private"
    ''' <summary>
    '''機　能：WS1を削除
    ''' </summary>
    ''' <param name="xlbook"></param>
    ''' <remarks></remarks>
    Private Sub WS1シートの削除(ByRef xlbook As Excel.Workbook)

        ''WS1シートの定義
        Dim WS1シート As Excel.Worksheet = Nothing
        Dim xlCell As Excel.Range = Nothing

        Try

            WS1シート = ワークシートの取得(xlbook, ExcelWrite.EXCEL_PAYMENTLINEDATE_WS1)

            ''見出しの文言をキーに削除範囲を特定
            Dim 変更契約情報の見出し行 As Integer
            Dim 案件情報の見出し行 As Integer

            変更契約情報の見出し行 = WS1の変更契約情報の位置を取得(WS1シート)
            案件情報の見出し行 = WS1の案件情報の位置を取得(WS1シート)

            Dim 変更契約_開始行 As Integer
            Dim 変更契約_終了行 As Integer
            Dim 案件情報_開始行 As Integer
            Dim 案件情報_終了行 As Integer

            変更契約_開始行 = 変更契約情報の見出し行 + 2
            変更契約_終了行 = 案件情報の見出し行 - 3

            ''明細行の削除
            If 変更契約_終了行 >= 変更契約_開始行 Then
                xlCell = WS1シート.Range(変更契約_開始行 & ":" & 変更契約_終了行)
                xlCell.Delete()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            End If

            ''削除行数分がずれるので再度案件情報の見出し位置を取得
            案件情報の見出し行 = WS1の案件情報の位置を取得(WS1シート)
            案件情報_開始行 = 案件情報の見出し行 + 2
            xlCell = WS1シート.Cells
            案件情報_終了行 = xlCell.SpecialCells(Excel.XlCellType.xlCellTypeLastCell).Row
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            ''明細行の削除
            If 案件情報_終了行 >= 案件情報_開始行 Then
                WS1シート.Rows(案件情報_開始行 & ":" & 案件情報_終了行).Delete()
            End If

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "WS1シートの削除")

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(WS1シート, ExcelObjRelease.OBJECT_NOTHING)

        End Try

    End Sub

    ''' <summary>
    '''機　能：WS1の書込
    '''説　明：WS1レイアウト修正対応
    ''' </summary>
    ''' <param name="xlbook"></param>
    ''' <param name="契約基本情報"></param>
    ''' <param name="契約明細情報"></param>
    ''' <param name="案件明細情報"></param>
    ''' <remarks></remarks>
    Private Sub WS1シートの書込(ByRef xlBook As Excel.Workbook, _
                                ByRef 契約基本情報 As WS1出力用_契約基本情報, _
                                ByRef 契約明細情報() As WS1出力用_契約明細情報, _
                                ByRef 案件明細情報() As WS1出力用_案件明細情報)

        Dim WS1シート As Excel.Worksheet = Nothing

        Try

            WS1シート = ワークシートの取得(xlBook, ExcelWrite.EXCEL_PAYMENTLINEDATE_WS1)

            ''契約基本情報の書込
            Call 契約基本情報の書込(WS1シート, 契約基本情報)

            ''契約基本明細情報の書込
            If UBound(契約明細情報) >= 1 Then
                Call 契約明細情報の書込(契約明細情報, WS1シート)
            End If

            ''案件情報の書込
            If UBound(案件明細情報) >= 1 Then
                Call 案件明細情報の書込(案件明細情報, WS1シート)
            End If

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "WS1シートの書込")

        Finally
            ExcelObjRelease.ReleaseExcelObj(WS1シート, ExcelObjRelease.OBJECT_NOTHING)

        End Try

    End Sub

    ''' <summary>
    '''機　能：WS1に契約基本情報を書き込む
    ''' </summary>
    ''' <param name="xlSheet"></param>
    ''' <param name="契約基本情報"></param>
    ''' <remarks></remarks>
    Private Sub 契約基本情報の書込(ByRef xlSheet As Excel.Worksheet,
                                    ByRef 契約基本情報 As WS1出力用_契約基本情報)

        Dim Excel開始年 As String
        Dim xlCell As Excel.Range = Nothing

        Try
            If 契約基本情報.契約期間_EXCEL年月 = "" Then
                Excel開始年 = ""
            Else
                Excel開始年 = Left(契約基本情報.契約期間_EXCEL年月, 4)
            End If

            '値の書き込み
            xlCell = xlSheet.Range(WS1_項目の位置_CPNO)
            xlCell.Value = 契約基本情報.CPNO
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            xlCell = xlSheet.Range(WS1_項目の位置_CPNAME)
            xlCell.Value = 契約基本情報.お客様名
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            xlCell = xlSheet.Range(WS1_項目の位置_請求開始年月)
            xlCell.Value = 契約基本情報.契約期間_開始年 & "/" & 契約基本情報.契約期間_開始月 & "/1"
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            xlCell = xlSheet.Range(WS1_項目の位置_請求終了年月)
            xlCell.Value = 契約基本情報.契約期間_終了年 & "/" & 契約基本情報.契約期間_終了月 & "/1"
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            xlCell = xlSheet.Range(WS1_項目の位置_Excel開始年月)
            xlCell.Value = Excel開始年
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            'START 変更管理#8（No.791 Office2013対応）　2014/11/26 sugo
            xlCell = xlSheet.Range(WS1_項目の位置_Payment出力終了)
            xlCell.Value = 契約基本情報.契約期間_Payment出力終了
            'xlCell = xlSheet.Range(WS1_項目の位置_アニバーサリーDate)
            'xlCell.Value = 契約基本情報.PAアニバーサリーDate
            'END   変更管理#8（No.791 Office2013対応）　2014/11/26 sugo
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "契約基本情報の書込")

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

        End Try

    End Sub

    'START 変更管理#8（No.791 Office2013対応）　2014/11/26 sugo
    ' ''' <summary>
    ' '''機　能：リストシートに契約開始/終了年月を書込
    ' ''' </summary>
    ' ''' <param name="xlSheet"></param>
    ' ''' <param name="契約基本情報"></param>
    ' ''' <remarks></remarks>
    'Private Sub リストシートの基本契約の書込(ByRef xlSheet As Excel.Worksheet, ByRef 契約基本情報 As WS1出力用_契約基本情報)

    '    Dim xlCell As Excel.Range = Nothing

    '    Try
    '        'ﾘｽﾄｼｰﾄの基本契約開始、終了をWS1更新のタイミングで上書き
    '        xlCell = xlSheet.Range(項目の位置_リスト_契約開始年)
    '        xlCell.Value = 契約基本情報.契約期間_開始年
    '        ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
    '        xlCell = xlSheet.Range(項目の位置_リスト_契約開始月)
    '        xlCell.Value = 契約基本情報.契約期間_開始月
    '        ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
    '        xlCell = xlSheet.Range(項目の位置_リスト_契約終了年)
    '        xlCell.Value = 契約基本情報.契約期間_終了年
    '        ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
    '        xlCell = xlSheet.Range(項目の位置_リスト_契約終了月)
    '        xlCell.Value = 契約基本情報.契約期間_終了月
    '        ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

    '    Catch ex As Exception
    '        MsgBox(ex.Message.ToString, vbCritical, "リストシートの基本契約の書込")

    '    Finally
    '        ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

    '    End Try

    'End Sub
    'END   変更管理#8（No.791 Office2013対応）　2014/11/26 sugo

    ''' <summary>
    ''' 機　能：WS1に契約明細情報を書き込む
    ''' </summary>
    ''' <param name="契約明細情報"></param>
    ''' <param name="出力先シート"></param>
    ''' <remarks></remarks>
    Private Sub 契約明細情報の書込(ByRef 契約明細情報() As WS1出力用_契約明細情報, _
                                  ByRef 出力先シート As Excel.Worksheet)

        ''値の書込用のデータ
        'START 変更管理#8（No.791 Office2013対応）　2014/12/01 sugo
        Dim 出力用のデータ(契約明細情報.Length - 1, 3) As Object
        'Dim 出力用のデータ(契約明細情報.Length - 1, 7) As Object
        'END   変更管理#8（No.791 Office2013対応）　2014/12/01 sugo
        Dim セルの情報_出力用セル As Excel.Range = Nothing

        Try
            For Index As Integer = 1 To UBound(契約明細情報)
                'START 変更管理#8（No.791 Office2013対応）　2014/12/01 sugo
                出力用のデータ(Index - 1, 0) = 契約明細情報(Index).契約順番
                出力用のデータ(Index - 1, 1) = 契約明細情報(Index).契約順番名
                出力用のデータ(Index - 1, 2) = 契約明細情報(Index).提案開始
                Select Case 契約明細情報(Index).ステータス
                    Case 0
                        出力用のデータ(Index - 1, 3) = "作成中"
                    Case 1
                        出力用のデータ(Index - 1, 3) = "契約済み"
                    Case 2
                        出力用のデータ(Index - 1, 3) = "廃案"
                    Case 3
                        出力用のデータ(Index - 1, 3) = "仮契約"
                End Select
                '出力用のデータ(Index - 1, 0) = 契約明細情報(Index).契約順番
                '出力用のデータ(Index - 1, 1) = 契約明細情報(Index).契約順番名
                ''START  ASCA対応(DSP0320-02)  sugo
                ''出力用のデータ(Index - 1, 2) = 契約明細情報(Index).部署名
                ''END    ASCA対応(DSP0320-02)  sugo
                '出力用のデータ(Index - 1, 3) = 契約明細情報(Index).PALevel
                '出力用のデータ(Index - 1, 4) = 契約明細情報(Index).提案開始
                '出力用のデータ(Index - 1, 5) = 契約明細情報(Index).価格承認依頼日
                '出力用のデータ(Index - 1, 6) = 契約明細情報(Index).契約締結日
                'Select Case 契約明細情報(Index).ステータス
                '    Case 0
                '        出力用のデータ(Index - 1, 7) = "作成中"
                '    Case 1
                '        出力用のデータ(Index - 1, 7) = "契約済み"
                '    Case 2
                '        出力用のデータ(Index - 1, 7) = "廃案"
                '    Case 3
                '        出力用のデータ(Index - 1, 7) = "仮契約"
                'End Select
                'END   変更管理#8（No.791 Office2013対応）　2014/12/01 sugo
            Next

            ''見出しの文言をキーに削除範囲を特定
            Dim 変更契約情報の見出し行 As Integer
            変更契約情報の見出し行 = WS1の変更契約情報の位置を取得(出力先シート)

            ''テンプレ行のコピペ
            出力先シート.Rows(WS1_変更Dummy行).Hidden = False
            Call 出力先シート.Rows(WS1_変更Dummy行).Copy()
            Call 出力先シート.Rows(変更契約情報の見出し行 + 2 & ":" & _
                                   変更契約情報の見出し行 + 2 + UBound(契約明細情報) - 1) _
                                        .Insert(Shift:=Excel.XlDirection.xlDown, _
                                                CopyOrigin:=Excel.XlInsertFormatOrigin.xlFormatFromLeftOrAbove)
            Call 出力先シート.Rows(変更契約情報の見出し行 + 2 & ":" & _
                                   変更契約情報の見出し行 + 2 + UBound(契約明細情報) - 1).PasteSpecial()
            出力先シート.Rows(WS1_変更Dummy行).Hidden = True


            ''値の出力
            'START 変更管理#8（No.791 Office2013対応）　2014/12/01 sugo
            セルの情報_出力用セル = 出力先シート.Range("B" & 変更契約情報の見出し行 + 2 & ":" & "E" & 変更契約情報の見出し行 + 2 + UBound(契約明細情報) - 1)
            'セルの情報_出力用セル = 出力先シート.Range("B" & 変更契約情報の見出し行 + 2 & ":" & "I" & 変更契約情報の見出し行 + 2 + UBound(契約明細情報) - 1)
            'END   変更管理#8（No.791 Office2013対応）　2014/12/01 sugo
            セルの情報_出力用セル.Value = 出力用のデータ

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "契約明細情報の書込")

        Finally
            ExcelObjRelease.ReleaseExcelObj(セルの情報_出力用セル, ExcelObjRelease.OBJECT_NOTHING)

        End Try

    End Sub

    ''' <summary>
    '''機　能：WS1に案件明細情報を書き込む
    ''' </summary>
    ''' <param name="案件明細情報"></param>
    ''' <param name="出力先シート"></param>
    ''' <remarks></remarks>
    Private Sub 案件明細情報の書込(ByRef 案件明細情報() As WS1出力用_案件明細情報, _
                                  ByRef 出力先シート As Excel.Worksheet)

        ''値の書込用のデータ
        'START 変更管理#8（No.791 Office2013対応）　2014/12/01 sugo
        Dim 出力用のデータ(案件明細情報.Length - 1, 2) As Object
        'Dim key As Integer
        'Dim 出力用のデータ(案件明細情報.Length - 1, 4) As Object
        'END   変更管理#8（No.791 Office2013対応）　2014/12/01 sugo
        Dim セルの情報_出力用セル As Excel.Range = Nothing

        Try
            'START 変更管理#8（No.791 Office2013対応）　2014/12/01 sugo
            'key = 0
            'END   変更管理#8（No.791 Office2013対応）　2014/12/01 sugo
            For Index As Integer = 1 To UBound(案件明細情報)

                'START 変更管理#8（No.791 Office2013対応）　2014/12/01 sugo
                'key = key + 1
                '出力用のデータ(Index - 1, 0) = key
                'END   変更管理#8（No.791 Office2013対応）　2014/12/01 sugo

                Dim 案件番号 As String
                案件番号 = 指定した桁数まで文字を埋める(案件明細情報(Index).案件番号1, 2, "0", False) & "." & _
                           指定した桁数まで文字を埋める(案件明細情報(Index).案件番号2, 2, "0", False) & "." & _
                           指定した桁数まで文字を埋める(案件明細情報(Index).案件番号3, 2, "0", False) & "." & _
                           指定した桁数まで文字を埋める(案件明細情報(Index).案件番号4, 2, "0", False)
                'START 変更管理#8（No.791 Office2013対応）　2014/12/01 sugo
                出力用のデータ(Index - 1, 0) = 案件番号
                出力用のデータ(Index - 1, 1) = 案件明細情報(Index).案件名
                '出力用のデータ(Index - 1, 1) = 案件番号
                '出力用のデータ(Index - 1, 2) = 案件明細情報(Index).案件名
                'END   変更管理#8（No.791 Office2013対応）　2014/12/01 sugo

            Next

            ''見出しの文言をキーに削除範囲を特定
            Dim 案件情報の見出し行 As Integer
            案件情報の見出し行 = WS1の案件情報の位置を取得(出力先シート)

            ''■WS1ﾚｲｱｳﾄ変更対応
            ''テンプレ行のコピペ
            出力先シート.Rows(WS1_案件Dummy行).Hidden = False
            Call 出力先シート.Rows(WS1_案件Dummy行).Copy()
            Call 出力先シート.Rows(案件情報の見出し行 + 2 & ":" & _
                                   案件情報の見出し行 + 2 + UBound(案件明細情報) - 1) _
                                        .Insert(Shift:=Excel.XlDirection.xlDown, _
                                                CopyOrigin:=Excel.XlInsertFormatOrigin.xlFormatFromLeftOrAbove)
            Call 出力先シート.Rows(案件情報の見出し行 + 2 & ":" & _
                                   案件情報の見出し行 + 2 + UBound(案件明細情報) - 1).PasteSpecial()
            出力先シート.Rows(WS1_案件Dummy行).Hidden = True

            ''値の出力

            '■WS1レイアウト修正対応
            'START 変更管理#8（No.791 Office2013対応）　2014/12/01 sugo
            セルの情報_出力用セル = 出力先シート.Range("B" & 案件情報の見出し行 + 2 & ":" & "C" & 案件情報の見出し行 + 2 + UBound(案件明細情報) - 1)
            'セルの情報_出力用セル = 出力先シート.Range("B" & 案件情報の見出し行 + 2 & ":" & "G" & 案件情報の見出し行 + 2 + UBound(案件明細情報) - 1)
            'END   変更管理#8（No.791 Office2013対応）　2014/12/01 sugo
            セルの情報_出力用セル.Value = 出力用のデータ

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "契約明細情報の書込")

        Finally
            ExcelObjRelease.ReleaseExcelObj(セルの情報_出力用セル, ExcelObjRelease.OBJECT_NOTHING)

        End Try

    End Sub

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="xlBook"></param>
    ''' <param name="WS1出力用_契約基本情報"></param>
    ''' <param name="WS1出力用_契約明細情報"></param>
    ''' <param name="WS1の出力情報取得_案件明細情報"></param>
    ''' <remarks></remarks>
    'START 変更管理#8（No.791 Office2013対応）　2014/12/01 sugo
    Private Sub WS1出力用情報の取得(ByVal xlBook As Excel.Workbook,
                                    ByVal intPaymentPeriod As Integer,
                                    ByRef WS1出力用_契約基本情報 As WS1出力用_契約基本情報,
                                    ByRef WS1出力用_契約明細情報() As WS1出力用_契約明細情報,
                                    ByRef WS1の出力情報取得_案件明細情報() As WS1出力用_案件明細情報)
        'Private Sub WS1出力用情報の取得(ByVal xlBook As Excel.Workbook, _
        '                       ByRef WS1出力用_契約基本情報 As WS1出力用_契約基本情報, _
        '                       ByRef WS1出力用_契約明細情報() As WS1出力用_契約明細情報, _
        '                       ByRef WS1の出力情報取得_案件明細情報() As WS1出力用_案件明細情報)
        'END   変更管理#8（No.791 Office2013対応）　2014/12/01 sugo

        Dim CPNO As String = CommonVariable.CPNO

        Try
            '---------------------------
            'WebServiceからデータを取得
            '---------------------------
            'START 変更管理#8（No.791 Office2013対応）　2014/12/01 sugo
            WS1出力用_契約基本情報 = WS1の出力情報取得_SELECT契約基本情報(CPNO, intPaymentPeriod)
            'WS1出力用_契約基本情報 = WS1の出力情報取得_SELECT契約基本情報(CPNO)
            'END   変更管理#8（No.791 Office2013対応）　2014/12/01 sugo

            WS1出力用_契約明細情報 = WS1の出力情報取得_SELECT契約明細情報(CPNO)

            WS1の出力情報取得_案件明細情報 = WS1の出力情報取得_SELECT案件明細情報(CPNO)

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "WS1出力用情報の取得")

        End Try

    End Sub

    ''' <summary>
    '''機　能：WS1の変更契約情報見出しの位置を取得する。
    ''' </summary>
    ''' <param name="WS1Sheet"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function WS1の変更契約情報の位置を取得(ByRef WS1Sheet As Excel.Worksheet) As Integer

        ''値の検索
        Dim findRange As Excel.Range = Nothing

        ''初期化
        WS1の変更契約情報の位置を取得 = -1

        Try
            findRange = WS1Sheet.Columns(WS1_表題列).Find(What:=WS1_変更契約見出し,
                                                            LookIn:=Excel.XlFindLookIn.xlFormulas,
                                                            After:=WS1Sheet.Cells(1, WS1_表題列),
                                                            lookAt:=Excel.XlLookAt.xlPart,
                                                            SearchOrder:=Excel.XlSearchOrder.xlByRows,
                                                            SearchDirection:=Excel.XlSearchDirection.xlNext,
                                                            MatchCase:=False,
                                                            MatchByte:=False,
                                                            SearchFormat:=False)

            ''値が取得できない場合、-1
            If findRange Is Nothing Then
                Exit Function
            Else
                WS1の変更契約情報の位置を取得 = findRange.Row
            End If

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "WS1の変更契約情報の位置を取得")

        Finally
            ExcelObjRelease.ReleaseExcelObj(findRange, ExcelObjRelease.OBJECT_NOTHING)

        End Try

    End Function

    ''' <summary>
    '''機　能：WS1の変更契約情報見出しの位置を取得する。
    '''説　明：※位置が取得できなかった場合、-1を返却する。
    ''' </summary>
    ''' <param name="WS1Sheet"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function WS1の案件情報の位置を取得(ByRef WS1Sheet As Excel.Worksheet) As Integer

        ''初期化
        WS1の案件情報の位置を取得 = -1

        ''値の検索
        Dim findRange As Excel.Range
        findRange = WS1Sheet.Columns(WS1_表題列).Find(What:=WS1_案件情報見出し,
                                                        LookIn:=Excel.XlFindLookIn.xlFormulas,
                                                        After:=WS1Sheet.Cells(1, WS1_表題列),
                                                        lookAt:=Excel.XlLookAt.xlPart,
                                                        SearchOrder:=Excel.XlSearchOrder.xlByRows,
                                                        SearchDirection:=Excel.XlSearchDirection.xlNext,
                                                        MatchCase:=False, MatchByte:=False,
                                                        SearchFormat:=False)

        ''値が取得できない場合、-1
        If findRange Is Nothing Then
            Exit Function
        Else
            WS1の案件情報の位置を取得 = findRange.Row
        End If

    End Function

    ''' <summary>
    '''機　能：WorkBookから、ｼｰﾄ名に合致するSheetを取得する。
    '''説　明：※Set 変数 = WorkSheets(ｼｰﾄ名)を使用すると、ｴﾗｰﾒｯｾｰｼﾞがわかりにくいため関数化
    ''' </summary>
    ''' <param name="xlBook"></param>
    ''' <param name="シート名"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ワークシートの取得(ByRef xlBook As Excel.Workbook, _
                                       ByVal シート名 As String) As Excel.Worksheet

        ''WorkBookに該当するｼｰﾄが存在するかﾁｪｯｸ
        Dim IsSheet As Boolean = False
        Dim TmpSheet As Excel.Worksheet

        Try
            For Each TmpSheet In xlBook.Worksheets
                If TmpSheet.Name = シート名 Then
                    IsSheet = True
                    Exit For
                End If
            Next

            ''ｼｰﾄが存在しなければ、ユーザ定義ｴﾗｰを返す。
            If IsSheet = True Then
                ワークシートの取得 = xlBook.Worksheets(シート名)
            Else
                MsgBox("ｼｰﾄが存在しません。", vbCritical, "ワークシートの取得")
            End If

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "ワークシートの取得")

        End Try


    End Function

    ''' <summary>
    '''機　能：指定された文字列を「空白」で埋める
    ''' </summary>
    ''' <param name="文字列"></param>
    ''' <param name="桁数"></param>
    ''' <param name="文字"></param>
    ''' <param name="右埋め"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function 指定した桁数まで文字を埋める(ByVal 文字列 As String, _
                                                  ByVal 桁数 As Integer, _
                                                  ByVal 文字 As String, _
                                                  ByVal 右埋め As Boolean) As String

        Dim 戻り値 As String
        Dim 埋める文字 As String = ""

        指定した桁数まで文字を埋める = ""

        Try
            ''指定した桁数よりも大きい文字列の場合、文字列をそのまま返す
            If Len(文字列) >= 桁数 Then
                指定した桁数まで文字を埋める = 文字列
                Exit Function
            End If

            For i As Integer = 1 To 桁数 - Len(文字列)
                埋める文字 = 埋める文字 & 文字
            Next

            ''右埋めか左埋めか判定する。
            If 右埋め = True Then
                戻り値 = 文字列 & 埋める文字
            Else
                戻り値 = 埋める文字 & 文字列
            End If

            指定した桁数まで文字を埋める = 戻り値

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "指定した桁数まで文字を埋める")

        End Try

    End Function

    ''' <summary>
    '''機　能：ファイル名からCPNO、契約順番、Suffixを取得
    ''' </summary>
    ''' <param name="xlBook"></param>
    ''' <param name="CPNO"></param>
    ''' <param name="契約順番"></param>
    ''' <param name="Suffix"></param>
    ''' <remarks></remarks>
    Private Sub ファイル名から契約基本情報を取得(ByVal xlBook As Excel.Workbook, _
                                                ByRef CPNO As String, _
                                                ByRef 契約順番 As Integer, _
                                                ByRef Suffix As Integer)

        ''ファイル名の取得
        Dim ファイル名 As String

        Try
            ファイル名 = xlBook.Name

            CPNO = Mid(ファイル名, Len("PaymentLine") + 1, 6)

            契約順番 = CInt(Mid(ファイル名, Len("PaymentLine") + _
                                            Len("CPNOxx") + _
                                            Len("NO") + 1, 3))

            Suffix = CInt(Mid(ファイル名, Len("PaymentLine") + _
                                          Len("CPNOxx") + _
                                          Len("NO") + _
                                          Len("con") + 1, 2))

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "指定した桁数まで文字を埋める")

        End Try

    End Sub

    ''' <summary>
    '''機　能：MDBより、WS1の出力用の契約基本情報を取得
    ''' </summary>
    ''' <param name="CPNO"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    'START 変更管理#8（No.791 Office2013対応）　2014/12/01 sugo
    Private Function WS1の出力情報取得_SELECT契約基本情報(ByVal CPNO As String, ByVal intPaymentPeriod As Integer) As WS1出力用_契約基本情報
        'Private Function WS1の出力情報取得_SELECT契約基本情報(ByVal CPNO As String) As WS1出力用_契約基本情報
        'END   変更管理#8（No.791 Office2013対応）　2014/12/01 sugo

        Dim wc As New WebDb.WebDbCommon
        Dim dt As New M_CONTRACT_BASETable
        Dim strMsg As String = ""
        Dim blnRet As Boolean

        Try
            '認証設定
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW

            '契約基本情報取得
            blnRet = wc.GetContractBaseData(CPNO, dt, strMsg)
            If blnRet = False Then
                MsgBox(strMsg, MsgBoxStyle.Critical, "WS1の出力情報取得_SELECT契約基本情報")
                Exit Function
            End If

            ''レコードが取得できているか判定
            Dim 戻り値 As WS1出力用_契約基本情報

            If dt.Rows.Count > 0 Then
                ''戻り値をセット
                戻り値.CPNO = MDBのNULL値を空白へ変換する(dt.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_CPNO))
                'START 変更管理#37 WS1のお客様名が正しくない 2017/01 ueda
                '戻り値.お客様名 = MDBのNULL値を空白へ変換する(dt.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_CPNO))
                戻り値.お客様名 = MDBのNULL値を空白へ変換する(dt.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_CUST_NAME))
                'END 変更管理#37 WS1のお客様名が正しくない 2017/01 ueda
                戻り値.契約期間_開始年 = MDBのNULL値を空白へ変換する(dt.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_START_YEAR))
                戻り値.契約期間_開始月 = MDBのNULL値を空白へ変換する(dt.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_START_MONTH))
                戻り値.契約期間_終了年 = MDBのNULL値を空白へ変換する(dt.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_END_YEAR))
                戻り値.契約期間_終了月 = MDBのNULL値を空白へ変換する(dt.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_END_MONTH))
                戻り値.契約期間_EXCEL年月 = MDBのNULL値を空白へ変換する(dt.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_EXCEL_START))

                'START 変更管理#8（No.791 Office2013対応）　2014/11/26 sugo
                戻り値.契約期間_Payment出力終了 = (Integer.Parse(戻り値.契約期間_EXCEL年月.Substring(0, 4)) + intPaymentPeriod - 1).ToString
                '戻り値.統合処理の有無 = MDBのNULL値を空白へ変換する(dt.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_UNIFICATION_PATERN))
                '戻り値.PAアニバーサリーDate = MDBのNULL値を空白へ変換する(dt.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_PA_ANV_DATE))
                'END   変更管理#8（No.791 Office2013対応）　2014/11/26 sugo
            End If

            ''値を戻す
            WS1の出力情報取得_SELECT契約基本情報 = 戻り値

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "WS1の出力情報取得_SELECT契約基本情報")

        End Try

    End Function

    ''' <summary>
    '''機　能：MDBより、WS1の出力用の契約明細情報を取得
    ''' </summary>
    ''' <param name="CPNO"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function WS1の出力情報取得_SELECT契約明細情報(ByVal CPNO As String) As WS1出力用_契約明細情報()

        Dim wc As New WebDb.WebDbCommon
        Dim dt As New M_CONTRACT_DETAILTable
        Dim strMsg As String = ""
        Dim blnRet As Boolean
        Dim strSort As String

        Try
            '認証設定
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW

            '契約詳細情報取得
            blnRet = wc.GetContractDetailData(CPNO, dt, strMsg)
            If blnRet = False Then
                MsgBox(strMsg, MsgBoxStyle.Critical, "WS1の出力情報取得_SELECT契約明細情報")
                Exit Function
            End If

            'ソート
            strSort = M_CONTRACT_DETAILTable.COLUMN_NAME_CPNO & ", " & M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_NO

            Dim 戻り値() As WS1出力用_契約明細情報
            ReDim 戻り値(0)
            Dim Index As Integer
            Index = 1
            Dim rows() As DataRow

            For Each row As DataRow In dt.Select(Nothing, strSort)
                ''戻り値をセット
                ReDim Preserve 戻り値(Index)
                戻り値(Index).契約順番 = MDBのNULL値を空白へ変換する(row(M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_NO))
                戻り値(Index).契約順番名 = MDBのNULL値を空白へ変換する(row(M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_NO_NAME))
                戻り値(Index).提案開始 = MDBのNULL値を空白へ変換する(row(M_CONTRACT_DETAILTable.COLUMN_NAME_PROPOSAL_DATE))
                戻り値(Index).ステータス = MDBのNULL値を空白へ変換する(row(M_CONTRACT_DETAILTable.COLUMN_NAME_STATUS))
                'START 変更管理#8（No.791 Office2013対応）　2014/11/26 sugo
                '戻り値(Index).PALevel = MDBのNULL値を空白へ変換する(row(M_CONTRACT_DETAILTable.COLUMN_NAME_PA_LEVEL))
                '戻り値(Index).価格承認依頼日 = MDBのNULL値を空白へ変換する(row(M_CONTRACT_DETAILTable.COLUMN_NAME_PRICE_REQUEST_DATE))
                '戻り値(Index).契約締結日 = MDBのNULL値を空白へ変換する(row(M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_DATE))
                'END   変更管理#8（No.791 Office2013対応）　2014/11/26 sugo
                Index = Index + 1
            Next

            ''値を戻す
            WS1の出力情報取得_SELECT契約明細情報 = 戻り値

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "WS1の出力情報取得_SELECT契約明細情報")

        End Try

    End Function

    ''' <summary>
    '''機　能：MDBより、WS1の出力用の案件明細情報を取得
    ''' </summary>
    ''' <param name="CPNO"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function WS1の出力情報取得_SELECT案件明細情報(ByVal CPNO As String) As WS1出力用_案件明細情報()

        Dim wc As New WebDb.WebDbCommon
        Dim dt As New M_PLANTable
        Dim strMsg As String = ""
        Dim blnRet As Boolean
        Dim strSort As String

        Try
            '認証設定
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW

            '案件情報取得
            blnRet = wc.GetPlanData(CPNO, dt, strMsg)
            If blnRet = False Then
                MsgBox(strMsg, MsgBoxStyle.Critical, "WS1の出力情報取得_SELECT案件明細情報")
                Exit Function
            End If

            'ソート
            strSort = M_PLANTable.COLUMN_NAME_LEVEL1 & ", " & _
                        M_PLANTable.COLUMN_NAME_LEVEL2 & ", " & _
                        M_PLANTable.COLUMN_NAME_LEVEL3 & ", " & _
                        M_PLANTable.COLUMN_NAME_LEVEL4

            Dim 戻り値() As WS1出力用_案件明細情報
            ReDim 戻り値(0)
            Dim Index As Integer
            Index = 1
            Dim rows() As DataRow

            For Each row As DataRow In dt.Select(Nothing, strSort)
                ''戻り値をセット
                ReDim Preserve 戻り値(Index)
                ''戻り値をセット
                戻り値(Index).案件名 = MDBのNULL値を空白へ変換する(row(M_PLANTable.COLUMN_NAME_PLAN_NAME))
                戻り値(Index).案件番号1 = MDBのNULL値を空白へ変換する(row(M_PLANTable.COLUMN_NAME_LEVEL1))
                戻り値(Index).案件番号2 = MDBのNULL値を空白へ変換する(row(M_PLANTable.COLUMN_NAME_LEVEL2))
                戻り値(Index).案件番号3 = MDBのNULL値を空白へ変換する(row(M_PLANTable.COLUMN_NAME_LEVEL3))
                戻り値(Index).案件番号4 = MDBのNULL値を空白へ変換する(row(M_PLANTable.COLUMN_NAME_LEVEL4))
                Index = Index + 1
            Next

            ''値を戻す
            WS1の出力情報取得_SELECT案件明細情報 = 戻り値

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "WS1の出力情報取得_SELECT契約明細情報")

        End Try

    End Function

    ''' <summary>
    '''機　能：指定された文字列を「"」で囲む
    ''' </summary>
    ''' <param name="文字列"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ダブルクォテーションで囲む(ByVal 文字列 As String) As String

        Dim 戻り値 As String = ""

        戻り値 = """" & 文字列 & """"

        ダブルクォテーションで囲む = 戻り値

    End Function

    ''' <summary>
    '''機　能：MDBのDBNullを空白へ変換する
    ''' </summary>
    ''' <param name="Value"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function MDBのNULL値を空白へ変換する(ByVal Value As Object) As String

        ''初期化
        MDBのNULL値を空白へ変換する = ""

        ''Nullなら、空白へ変換
        If IsDBNull(Value) Then
            MDBのNULL値を空白へ変換する = ""
        Else
            MDBのNULL値を空白へ変換する = Value
        End If

    End Function

    ''' <summary>
    '''機　能：Select句の項目を受け取り、Format関数を付与する。
    ''' </summary>
    ''' <param name="項目名"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Select句で日付フォーマット関数を付与(ByVal 項目名 As String) As String

        ''初期化
        Select句で日付フォーマット関数を付与 = ""

        Dim 戻り値 As String = ""

        戻り値 = 戻り値 & "Format("
        戻り値 = 戻り値 & 項目名
        戻り値 = 戻り値 & " , "
        戻り値 = 戻り値 & ダブルクォテーションで囲む("YYYY/MM/DD")
        戻り値 = 戻り値 & ")"

        Select句で日付フォーマット関数を付与 = 戻り値

    End Function

#End Region

End Class
