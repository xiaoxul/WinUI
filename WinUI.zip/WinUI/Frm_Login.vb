﻿Imports System.Text
Imports System.Data.OleDb
Imports MUSE.Utility
Imports MUSE.Utility.UserDataTable.Master
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.OioBamaCommmon
Imports MUSE.Utility.UserMessageBox
Imports MUSE.Controller
Imports System.IO
Imports MUSE.Utility.XmlClass.ConnectionInfo
Imports System.Xml
Imports MUSE.DataAccess.OleDb
Imports Microsoft.Office.Interop

''' <summary>
'''  クラス名：Frm_Login
'''　概    要：Frm_Loginクラス
'''　説    明：ログイン画面の処理
''' </summary>
''' <remarks></remarks>
Public Class frm_Login

#Region "イベントハンドラ"

    ''' <summary>
    ''' 機能：ログイン画面起動
    ''' 説明：ログイン画面を初期表示する
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub frm_Login_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        '''処理：  ２重起動チェックを行う。
        '''分岐：  ２重起動の場合、エラーメッセージを表示し自アプリケーションを終了する。
        '''メッセージ：   MSG_0008[既に起動されています。二重起動はできません。]
        If Diagnostics.Process.GetProcessesByName(Diagnostics.Process.GetCurrentProcess().ProcessName).Length > 1 Then
            MsgBox(FileReader.GetMessage("MSG_0008"), MsgBoxStyle.Critical)
            Me.Close()
            Exit Sub
        End If

        '''処理：  起動ドライブのチェックを行う。
        '''分岐：  Cドライブ以外から起動されている場合、エラーメッセージを表示し、自アプリケーションを終了する。
        '''メッセージ：   [Cドライブ以外で起動しないでください。]
        If (System.Reflection.Assembly.GetExecutingAssembly().Location.Substring(0, 1) <> "C") Then
            MsgBox("Cドライブ以外で起動しないでください。", MsgBoxStyle.Critical)
            Me.Close()
            Exit Sub
        End If

        '''処理：  パスワードの取得を行う。
        '''分岐：  Excelパスワード取得処理(SetExcelPW)がエラーの場合は、エラーメッセージを表示し、自アプリケーションを終了する。
        '''メッセージ：   MSG_0458[ExcelPWの取得が失敗しました。]
        Dim errMsg As String
        If SetExcelPW(errMsg) = False Then
            errMsg = FileReader.GetMessage("MSG_0458") + vbCrLf + _
                     errMsg
            MsgBox(errMsg, MsgBoxStyle.Critical)
            Me.Close()
            Exit Sub
        End If

        '''処理：  起動時のパスより、環境名を取得する。
        Dim dspMainFolderNm As String
        Dim tmpDspMainFolderNm As String
        tmpDspMainFolderNm = AppDomain.CurrentDomain.BaseDirectory

        '''分岐：  パス名に「OIOBAMA-Client\」が含まれていた場合
        '''処理：  環境名に「本番用」をセットする。
        If tmpDspMainFolderNm.IndexOf("OIOBAMA-Client\") <> -1 Then
            dspMainFolderNm = "本番用"
        End If

        '''分岐：  パス名に「検証用」が含まれていた場合
        '''処理：  環境名に「検証用」をセットする。
        If tmpDspMainFolderNm.IndexOf("検証用") <> -1 Then
            dspMainFolderNm = "検証用"
        End If

        '''分岐：  パス名に「デモ用」が含まれていた場合
        '''処理：  環境名に「デモ用」をセットする。
        If tmpDspMainFolderNm.IndexOf("デモ用") <> -1 Then
            dspMainFolderNm = "デモ用"
        End If

        '''分岐：  パス名に「production_environment」が含まれていた場合
        '''処理：  環境名に「本番用」をセットする。
        If tmpDspMainFolderNm.IndexOf("production_environment") <> -1 Then
            dspMainFolderNm = "本番用"
        End If

        '''分岐：  パス名に「test_environment」が含まれていた場合
        '''処理：  環境名に「テスト環境」をセットする。
        If tmpDspMainFolderNm.IndexOf("test_environment") <> -1 Then
            dspMainFolderNm = "テスト環境"
        End If

        '''分岐：  パス名に「development_environment」が含まれていた場合
        '''処理：  環境名に「開発環境」をセットする。
        If tmpDspMainFolderNm.IndexOf("development_environment") <> -1 Then
            dspMainFolderNm = "開発環境"
        End If

        '''分岐：  上記以外の場合
        '''処理：  環境名に「不明」をセットする。
        If dspMainFolderNm = "" Then
            dspMainFolderNm = "不明"
        End If

        '''処理：  上記で取得した環境名で、ユーザーコントロールタイトルの「@@@」を置換する。
        UCnt_Pal00011.TitleText = UCnt_Pal00011.TitleText.Replace("@@@", dspMainFolderNm)

        '''処理：  LocalConnectioninfo.xmlを読み込む。
        '''処理：  1.LocalConnectionInfo.xmlを読み込み、構造体にセットする。
        '''処理：  2.タイトル変数に、"OIO BAMA Client " + 環境名 + " Ver." + LocalConnectionInfoのバージョン名 + "  IBM Confidential"をセットする。
        '''処理：  3.自フォームのタイトルに3.の文字列をセットする。
        Dim fileName As New StringBuilder
        fileName.Append(FileManager.GetLocalFolderPath(CommonConstant.FOLDERNAME_XML))
        fileName.Append("LocalConnectionInfo.xml")
        'XmlSerializerオブジェクトの作成
        Dim serializer As New Serialization.XmlSerializer(GetType(LocalConnectionInfo))
        'ファイルを開く
        Dim fsXml As New FileStream(fileName.ToString(), FileMode.Open, FileAccess.Read)
        'XMLファイルから読み込み、逆シリアル化する
        Dim info As LocalConnectionInfo = CType(serializer.Deserialize(fsXml), LocalConnectionInfo)
        '閉じる
        fsXml.Close()

        CommonVariable.OBAMATITLE = "OIO BAMA Client " & dspMainFolderNm & " Ver." & info.Client_Ver & "  IBM Confidential"
        Me.Text = CommonVariable.OBAMATITLE

#If DEBUG Then
        rbMnt.Visible = True
        rbDsl.Visible = True
        rbDso.Visible = True
        rbRed.Visible = True
#Else
        rbMnt.Visible = False
        rbDsl.Visible = False
        rbDso.Visible = False
        rbRed.Visible = False
#End If

        ''OSのバージョンを取得する。
        ''※Windows7以外は全てWindowsXpの想定

        '''処理：  変数osに、OSシステム環境変数を取得する。
        '''分岐：  プラットフォームがWin32NTの場合、
        '''分岐：  OSのメジャーバージョンが6の場合、
        '''処理：  OSバージョン変数に"Windows7"をセットする。
        '''分岐：  OSのメジャーバージョンが6以外の場合、
        '''処理：  OSバージョン変数に"WindowsXP"をセットする。
        Dim os As System.OperatingSystem = System.Environment.OSVersion
        If os.Platform = System.PlatformID.Win32NT Then
            If os.Version.Major = 6 Then
                CommonVariable.OSVERSION = CommonConstant.OS_WINDOWS7
            Else
                CommonVariable.OSVERSION = CommonConstant.OS_WINDOWSXP
            End If
        End If
    End Sub


    ''' <summary>
    ''' 機能：契約情報登録ボタン押下時の処理
    ''' 説明：契約情報登録画面へ遷移する。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Btn_Login_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Login.Click

        Dim MUSERKenGen As String
        '''処理：  共通変数初期化処理(SetInitCommonVariable)を呼び出す。
        Call SetInitCommonVariable()

        '''処理：  画面入力項目チェック処理(ChkLoginBtn)を呼び出す。
        '''分岐：  チェック結果がFALSEの場合、処理を中断する。
        If ChkLoginBtn() = False Then
            Exit Sub
        End If

        '''処理：  ログイン情報突き合わせ処理(ChkLoginAutority)を呼び出す。
        '''分岐：  チェック結果がFALSEの場合、メッセージを表示して処理を中断する。
        Dim msg As String
        If ChkLoginAutority(Me.Btn_Login.Name, MUSERKenGen, msg) = False Then
            Call MuseMessageBox.ShowWarning(msg, Me.Text)
            Exit Sub
        End If

        '''処理：  自画面を非表示にする。
        Me.Hide()

        '''処理：  共通変数に、権限・ログインID・パスワードをセットする。
        '''処理：  メインメニューを表示する。
        CommonVariable.AUTHORITY = MUSERKenGen
        CommonVariable.USERID = Me.Txb_UserID.Text.Trim
        CommonVariable.USERPW = Me.Txb_Password.Text.Trim
        Dim frmMenu As New Frm_ContractInfo()
        Call frmMenu.ShowDialog()

        '''処理：  画面を初期化する。
        '''処理：  自画面のユーザーID・パスワードを初期化する。
        Me.Txb_UserID.Text = "@jp.ibm.com"
        Me.Txb_Password.Text = ""

        CommonVariable.AUTHORITY = MUSERKenGen

        '''処理：  自画面を再表示する。
        Me.Visible = True

    End Sub


    ''' <summary>
    ''' 機能：終了ボタン押下時の処理
    ''' 説明：Clientを終了する
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Btn_End_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_End.Click

        '''共通関数：    TempMDB削除処理(DeleteTempDb)を呼び出す。
        Call DeleteTempDb()

        '''処理：  自画面を閉じる。
        Me.Close()

    End Sub

    ''' <summary>
    ''' 機能：一括処理ボタン押下時の処理
    ''' 説明：一括処理画面へ遷移する
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnAsrAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAsrAll.Click

        Dim MUSERKenGen As String

        '''処理：  共通変数初期化処理(SetInitCommonVariable)を呼び出す。
        Call SetInitCommonVariable()

        '''処理：  画面入力項目チェック処理(ChkLoginBtn)を呼び出す。
        '''分岐：  チェック結果がFALSEの場合、処理を中断する。
        If ChkLoginBtn() = False Then
            Exit Sub
        End If

        '''処理：  権限チェック処理(ChkLoginAutority)を呼び出す。
        '''分岐：  チェック結果がFALSEの場合、メッセージを表示して処理を中断する。
        Dim msg As String
        If ChkLoginAutority(Me.btnAsrAll.Name, MUSERKenGen, msg) = False Then
            Call MuseMessageBox.ShowWarning(msg, Me.Text)
            Exit Sub
        End If

        '''処理：  自画面を非表示にする。
        Me.Hide()

        '''処理：  共通変数に、権限・ログインID・パスワードをセットする。
        CommonVariable.AUTHORITY = MUSERKenGen
        CommonVariable.USERID = Me.Txb_UserID.Text.Trim
        CommonVariable.USERPW = Me.Txb_Password.Text.Trim

        '''処理：  一括処理メニューを表示する。
        Dim frm As New Frm_AsrAll
        Call frm.ShowDialog()

        '''処理：  画面を初期化する。
        '''処理：  自画面のユーザーID・パスワードを初期化する。
        Me.Txb_UserID.Text = "@jp.ibm.com"
        Me.Txb_Password.Text = ""

        '''処理：  ユーザーIDにフォーカスをセットする。
        Me.Txb_UserID.Focus()

        '''処理：  自画面を再表示する。
        Me.Visible = True

    End Sub


    ''' <summary>
    ''' 機能：マスタメンテナンスボタンの処理
    ''' 説明：マスタメンテナンス画面へ遷移する
    ''' </summary>
    ''' <remarks>Boolean型：ChkLoginBtn</remarks>
    Private Sub btnMnt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMnt.Click

        '''処理：  画面入力項目チェック処理(ChkLoginBtn)を呼び出す。
        '''分岐：  チェック結果がFALSEの場合、処理を中断する。
        If ChkLoginBtn() = False Then
            Exit Sub
        End If

        'MasterMDB存在チェック
        Dim ofm As New OioFileManage
        Dim strErrMsg As String
        If ofm.CheckExistsMdb(OioFileManage.enmMdbType.Master, CommonVariable.MdbPW, strErrMsg) = False Then
            Call MuseMessageBox.ShowError(strErrMsg, Me.Text)
            Exit Sub
        End If

        Dim MUSERKenGen As String
        Dim msg As String
        '''処理：  権限チェック処理(ChkLoginAutority)を呼び出す。
        '''分岐：  チェック結果がFALSEの場合、メッセージを表示して処理を中断する。
        If ChkLoginAutority(Me.btnMnt.Name, MUSERKenGen, msg) = False Then
            Call MuseMessageBox.ShowWarning(msg, Me.Text)
            Exit Sub
        End If

        '''処理：  共通変数に、権限・ログインID・パスワードをセットする。
        '''処理：  マスタメンテメニューを表示する。
        CommonVariable.USERID = Me.Txb_UserID.Text.Trim
        CommonVariable.USERPW = Me.Txb_Password.Text.Trim

        '''処理：  フォームを初期化する。
        Dim rtnCd As String
        Dim frmMaster As New Frm_OioMasterUpdate(MUSERKenGen)
        frmMaster.ShowDialog()
        rtnCd = frmMaster.ReturnCd

        '''分岐：  マスタメンテ終了文字列が「ログアウト」の場合、フォーム初期化処理(initForm)を呼び出す。
        If rtnCd = frmMaster.Btn_LogOut.Name Then
            Call Me.initForm()
            Exit Sub
        End If

    End Sub

#End Region

#Region "プライベートメソッド"
    ''' <summary>
    ''' 機能：契約情報登録ボタン押下時の画面項目値チェック
    ''' 説明：契約情報登録ボタン押下時の画面項目値チェック
    ''' </summary>
    ''' <remarks>Boolean型：ChkLoginBtn</remarks>
    Private Function ChkLoginBtn() As Boolean

        ChkLoginBtn = False

        '''処理：  入力チェックを行う
        '''分岐：  LOGIN IDが空白の場合、エラーメッセージを表示し処理を中断する。
        '''メッセージ：   MSG_0200[ユーザーIDを入力してください。]
        If Trim(Me.Txb_UserID.Text) = "" Then
            MuseMessageBox.ShowWarning(FileReader.GetMessage("MSG_0200"), Me.Text)
            Exit Function
        End If

        '''分岐：  PASSWORDが空白の場合、エラーメッセージを表示し処理を中断する。
        '''メッセージ：   MSG_0201[パスワードを入力してください。]
        If Trim(Me.Txb_Password.Text) = "" Then
            MuseMessageBox.ShowWarning(FileReader.GetMessage("MSG_0201"), Me.Text)
            Exit Function
        End If

        '''処理：  チェック結果正常(TRUE)を返す。
        ChkLoginBtn = True

    End Function


    ''' <summary>
    ''' 概要：ログイン画面の初期化
    ''' 説明：ログイン画面の初期化を行う
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub initForm()

        '''処理：  自画面を初期化する。(ユーザーIDに"@jp.ibm.com"をセット)
        Me.Txb_UserID.Text = "@jp.ibm.com"
        Me.Txb_Password.Text = ""

        '''処理：  ユーザーIDのカーソルを初期化する。
        Me.Txb_UserID.Select()

    End Sub

    ''' <summary>
    ''' 概要：不要なファイルの削除
    ''' 説明：作成された一時DBを削除する。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub DeleteTempDb()

        Dim strPath As String
        Dim ofm As New OioFileManage
        Dim strFiles() As String
        Dim intCnt As Integer

        '''処理：  作成された一時DBを削除する。(ファイル名"Tmp*.accdb")
        strPath = ofm.GetLocalTempMDBFolder
        strFiles = Directory.GetFiles(strPath, "Tmp*.accdb")


        '''繰返し_開始：  該当名のDBファイル数（ループ）
        '''処理：  DBファイルを削除する。
        For intCnt = 0 To (strFiles.Length - 1)
            File.Delete(strFiles(intCnt))
        Next
        '''繰返し_終了：  該当名のDBファイル数（ループ）

    End Sub

    ''' <summary>
    ''' 概要：契約情報登録画面の初期値設定
    ''' 機能：契約情報登録画面の共通変数初期化
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetInitCommonVariable()

        '''処理：  各項目に初期値をセットする。
        CommonVariable.CPNO = String.Empty
        CommonVariable.CUSTOMERNAME = String.Empty
        CommonVariable.CONTRACTNO = 0
        CommonVariable.CONTRACTNONAME = String.Empty
        CommonVariable.ANNIVERSARY = String.Empty
        CommonVariable.PALEVEL = String.Empty

    End Sub

    ''' <summary>
    ''' 機能：ボタン押下時に権限をチェックする
    ''' 説明：契約情報画面/メンテナンス/一括ボタン押下時に使用。
    ''' </summary>
    ''' <remarks></remarks>
    Private Function ChkLoginAutority(ByVal btnNM As String, _
                                      ByRef autority As String, _
                                      ByRef errMsg As String) As Boolean

        ChkLoginAutority = False

        '''処理：  画面のユーザーID・パスワードで、Webサービスログイン処理(WebDbCommon.WebLogin)を呼び出す。
        '''ソース: WebDbCommon.vb
        '''クラス: WebDb
        '''関数:  WebLogin
        Dim Web As New Utility.WebDb.WebDbCommon
        Dim msg As String
        Dim brt As Boolean
        Web.IntraId = Me.Txb_UserID.Text
        Web.IntraPass = Me.Txb_Password.Text
        brt = Web.WebLogin(autority, msg)

        '''分岐：  Webログイン処理結果がFALSEで、権限が空白の場合、エラーメッセージを表示して処理を中断する。
        '''メッセージ：   MSG_0202[ユーザーIDまたはパスワードの入力が間違えています。]
        If brt = False And autority = "" Then
            errMsg = FileReader.GetMessage("MSG_0202")
            Exit Function
        End If

#If DEBUG Then
        If rbMnt.Checked = True Then
            autority = CommonConstant.AUTHORITY_MNT
        End If
        If rbDsl.Checked = True Then
            autority = CommonConstant.AUTHORITY_DSL
        End If
        If rbDso.Checked = True Then
            autority = CommonConstant.AUTHORITY_DSO
        End If
        If rbRed.Checked = True Then
            autority = CommonConstant.AUTHORITY_RED
        End If
#End If


        '''条件：  押下されたボタン名
        Select Case btnNM
            ''' ケース：    「契約情報登録」ボタンの時
            Case Btn_Login.Name
                ''' 条件：  権限
                Select Case autority
                    '''     ケース：    "DSO","RED"以外の場合、エラーメッセージを表示して処理を中断する。
                    '''     メッセージ：   MSG_0422[入力されたユーザ権限では機能を使用できません]
                    Case CommonConstant.AUTHORITY_DSO, _
                         CommonConstant.AUTHORITY_RED
                    Case Else
                        errMsg = FileReader.GetMessage("MSG_0422")
                        Exit Function
                End Select
                ''' ケース：    「マスタメンテ」ボタンの時
            Case btnMnt.Name
                ''' 条件：  権限
                Select Case autority
                    '''     ケース：    "DSO","RED","MNT"以外の場合、エラーメッセージを表示して処理を中断する。
                    '''     メッセージ：   MSG_0422[入力されたユーザ権限では機能を使用できません]
                    Case CommonConstant.AUTHORITY_DSO, _
                         CommonConstant.AUTHORITY_MNT, _
                         CommonConstant.AUTHORITY_RED
                    Case Else
                        errMsg = FileReader.GetMessage("MSG_0422")
                        Exit Function
                End Select
                ''' ケース： 「一括処理」ボタンの時
            Case btnAsrAll.Name
                ''' 条件：  権限
                Select Case autority
                    '''     ケース：    "DSO","RED"以外の場合、エラーメッセージを表示して処理を中断する。
                    '''     メッセージ：   MSG_0422[入力されたユーザ権限では機能を使用できません]
                    Case CommonConstant.AUTHORITY_DSO, _
                         CommonConstant.AUTHORITY_RED
                    Case Else
                        errMsg = FileReader.GetMessage("MSG_0422")
                        Exit Function
                End Select
        End Select

        '''処理：  チェック結果正常(TRUE)を返す。
        Return True

    End Function


    ''' <summary>
    ''' 機　能：Paymentファイル(Template)からExcelシート保護のPassword取得
    ''' 説　明：※Login時に一度だけ使用
    ''' </summary>
    ''' <param name="msg"></param>
    ''' <remarks></remarks>
    Private Function SetExcelPW(ByRef msg As String) As Boolean

        SetExcelPW = False

        Const MACRONM_PAYMENT As String = "GetPaymentPW"
        Const MACRONM_SUMMARY As String = "GetSummaryPW"
        Const MACRONM_BUSINESS As String = "GetBusinessPW"
        Const MACRONM_MDB As String = "GetMdbPW"

        Dim paymentPath As String
        Dim xlApp As New Excel.Application
        Dim xlBook As Excel.Workbook
        Dim mcrStr As String
        Try
            '''処理：  Templateパスと"PaymentLineSample.xlsm"より、ファイルパスを生成する。
            '''分岐：  ファイルが存在しない場合、エラーメッセージを表示して処理を中断する。
            '''メッセージ：   MSG_0457[Templateファイルが見つかりません。パス：ファイルパス名]
            paymentPath = FileManager.GetLocalFolderPath(CommonConstant.FOLDERNAME_TEMPLATE) + _
                          CommonConstant.FILENAME_XLS_PAYMENTSAMPLE
            If System.IO.File.Exists(paymentPath) = False Then
                msg = FileReader.GetMessage("MSG_0457").Replace("@", paymentPath)
                Exit Function
            End If

            '''処理：  Paymentファイルを開く。
            '''処理：  GetPaymentPWマクロを実行してパスワードを取得する。
            '''処理：  GetSummaryPWマクロを実行してパスワードを取得する。
            '''処理：  GetBusinessPWマクロを実行してパスワードを取得する。
            xlApp.EnableEvents = False
            xlApp.DisplayAlerts = False
            xlApp.Visible = False
            xlBook = xlApp.Workbooks.Open(paymentPath)

            mcrStr = xlBook.Name + "!" + MACRONM_PAYMENT
            CommonVariable.PaymentPW = xlApp.Run(mcrStr)

            mcrStr = xlBook.Name + "!" + MACRONM_SUMMARY
            CommonVariable.SummaryPW = xlApp.Run(mcrStr)

            mcrStr = xlBook.Name + "!" + MACRONM_BUSINESS
            CommonVariable.BusinessPW = xlApp.Run(mcrStr)

            mcrStr = xlBook.Name + "!" + MACRONM_MDB
            CommonVariable.MdbPW = xlApp.Run(mcrStr)

            '''処理：  取得処理正常(TRUE)を返す。
            SetExcelPW = True

        Catch ex As Exception
            '''例外処理：    エラーメッセージをセットして処理を中断する。
            msg = ex.Message
            Exit Function

        Finally
            '''共通終了処理：  Excelオブジェクトを初期化し、アプリケーションを開放する。
            If IsNothing(xlBook) = False Then
                xlBook.Close()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlApp) = False Then
                xlApp.EnableEvents = True
                xlApp.DisplayAlerts = True
                xlApp.Visible = True
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try

    End Function


#End Region

End Class