﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frm_NewPmoManage
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.txb_Contact_No_Name = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txb_DispCpno = New System.Windows.Forms.TextBox()
        Me.txb_DispKeiyakuZyunban = New System.Windows.Forms.TextBox()
        Me.txb_DispCustNm = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txb_InputFile = New System.Windows.Forms.TextBox()
        Me.gbSystem = New System.Windows.Forms.GroupBox()
        Me.btnSysReference = New MUSE.UserControl.UCnt_Btn0001()
        Me.lblMessage = New System.Windows.Forms.Label()
        Me.txtRefInputFile = New System.Windows.Forms.TextBox()
        Me.cbCost = New System.Windows.Forms.CheckBox()
        Me.cbTopacs = New System.Windows.Forms.CheckBox()
        Me.cbIgf = New System.Windows.Forms.CheckBox()
        Me.cbSlink = New System.Windows.Forms.CheckBox()
        Me.cbContractDoc = New System.Windows.Forms.CheckBox()
        Me.btnInput = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnOutput = New MUSE.UserControl.UCnt_Btn0001()
        Me.BtnDispExplorer1 = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnLogOut = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Rtn = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_InputFileDisp = New MUSE.UserControl.UCnt_Btn0001()
        Me.UCnt_Pal00011 = New MUSE.UserControl.UCnt_Pal0001()
        Me.cbPaymentSplit = New System.Windows.Forms.CheckBox()
        Me.cbIsatMa = New System.Windows.Forms.CheckBox()
        Me.cbElaFile = New System.Windows.Forms.CheckBox()
        Me.cbEpricer = New System.Windows.Forms.CheckBox()
        Me.GroupBox9.SuspendLayout()
        Me.gbSystem.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.Label26)
        Me.GroupBox9.Controls.Add(Me.Label22)
        Me.GroupBox9.Controls.Add(Me.Label23)
        Me.GroupBox9.Controls.Add(Me.txb_Contact_No_Name)
        Me.GroupBox9.Controls.Add(Me.Label24)
        Me.GroupBox9.Controls.Add(Me.txb_DispCpno)
        Me.GroupBox9.Controls.Add(Me.txb_DispKeiyakuZyunban)
        Me.GroupBox9.Controls.Add(Me.txb_DispCustNm)
        Me.GroupBox9.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.GroupBox9.Location = New System.Drawing.Point(16, 64)
        Me.GroupBox9.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox9.Size = New System.Drawing.Size(895, 74)
        Me.GroupBox9.TabIndex = 279
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "契約情報"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label26.Location = New System.Drawing.Point(13, 25)
        Me.Label26.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(51, 15)
        Me.Label26.TabIndex = 55
        Me.Label26.Text = "CPNO"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label22.Location = New System.Drawing.Point(376, 48)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(87, 15)
        Me.Label22.TabIndex = 53
        Me.Label22.Text = "契約順番名"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label23.Location = New System.Drawing.Point(376, 25)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(68, 15)
        Me.Label23.TabIndex = 51
        Me.Label23.Text = "お客様名"
        '
        'txb_Contact_No_Name
        '
        Me.txb_Contact_No_Name.BackColor = System.Drawing.SystemColors.Control
        Me.txb_Contact_No_Name.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txb_Contact_No_Name.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.txb_Contact_No_Name.Location = New System.Drawing.Point(488, 48)
        Me.txb_Contact_No_Name.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txb_Contact_No_Name.Name = "txb_Contact_No_Name"
        Me.txb_Contact_No_Name.Size = New System.Drawing.Size(340, 15)
        Me.txb_Contact_No_Name.TabIndex = 113
        Me.txb_Contact_No_Name.TabStop = False
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label24.Location = New System.Drawing.Point(13, 48)
        Me.Label24.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(71, 15)
        Me.Label24.TabIndex = 53
        Me.Label24.Text = "契約順番"
        '
        'txb_DispCpno
        '
        Me.txb_DispCpno.BackColor = System.Drawing.SystemColors.Control
        Me.txb_DispCpno.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txb_DispCpno.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.txb_DispCpno.Location = New System.Drawing.Point(125, 25)
        Me.txb_DispCpno.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txb_DispCpno.Name = "txb_DispCpno"
        Me.txb_DispCpno.Size = New System.Drawing.Size(216, 15)
        Me.txb_DispCpno.TabIndex = 74
        Me.txb_DispCpno.TabStop = False
        '
        'txb_DispKeiyakuZyunban
        '
        Me.txb_DispKeiyakuZyunban.BackColor = System.Drawing.SystemColors.Control
        Me.txb_DispKeiyakuZyunban.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txb_DispKeiyakuZyunban.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.txb_DispKeiyakuZyunban.Location = New System.Drawing.Point(125, 48)
        Me.txb_DispKeiyakuZyunban.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txb_DispKeiyakuZyunban.Name = "txb_DispKeiyakuZyunban"
        Me.txb_DispKeiyakuZyunban.Size = New System.Drawing.Size(216, 15)
        Me.txb_DispKeiyakuZyunban.TabIndex = 79
        Me.txb_DispKeiyakuZyunban.TabStop = False
        '
        'txb_DispCustNm
        '
        Me.txb_DispCustNm.BackColor = System.Drawing.SystemColors.Control
        Me.txb_DispCustNm.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txb_DispCustNm.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.txb_DispCustNm.Location = New System.Drawing.Point(488, 25)
        Me.txb_DispCustNm.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txb_DispCustNm.Name = "txb_DispCustNm"
        Me.txb_DispCustNm.Size = New System.Drawing.Size(340, 15)
        Me.txb_DispCustNm.TabIndex = 77
        Me.txb_DispCustNm.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(29, 148)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(189, 15)
        Me.Label5.TabIndex = 271
        Me.Label5.Text = "Payment(作業用)ファイル指定"
        '
        'txb_InputFile
        '
        Me.txb_InputFile.BackColor = System.Drawing.SystemColors.Control
        Me.txb_InputFile.Location = New System.Drawing.Point(32, 175)
        Me.txb_InputFile.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txb_InputFile.Name = "txb_InputFile"
        Me.txb_InputFile.ReadOnly = True
        Me.txb_InputFile.Size = New System.Drawing.Size(763, 22)
        Me.txb_InputFile.TabIndex = 0
        Me.txb_InputFile.TabStop = False
        '
        'gbSystem
        '
        Me.gbSystem.Controls.Add(Me.btnSysReference)
        Me.gbSystem.Controls.Add(Me.lblMessage)
        Me.gbSystem.Controls.Add(Me.txtRefInputFile)
        Me.gbSystem.Location = New System.Drawing.Point(16, 260)
        Me.gbSystem.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.gbSystem.Name = "gbSystem"
        Me.gbSystem.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.gbSystem.Size = New System.Drawing.Size(893, 91)
        Me.gbSystem.TabIndex = 9
        Me.gbSystem.TabStop = False
        Me.gbSystem.Text = "GroupBox6"
        '
        'btnSysReference
        '
        Me.btnSysReference.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnSysReference.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSysReference.ForeColor = System.Drawing.Color.White
        Me.btnSysReference.Location = New System.Drawing.Point(787, 40)
        Me.btnSysReference.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnSysReference.Name = "btnSysReference"
        Me.btnSysReference.Size = New System.Drawing.Size(99, 36)
        Me.btnSysReference.TabIndex = 12
        Me.btnSysReference.Text = "参照"
        Me.btnSysReference.UseVisualStyleBackColor = False
        '
        'lblMessage
        '
        Me.lblMessage.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblMessage.Location = New System.Drawing.Point(13, 21)
        Me.lblMessage.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblMessage.Name = "lblMessage"
        Me.lblMessage.Size = New System.Drawing.Size(569, 19)
        Me.lblMessage.TabIndex = 272
        Me.lblMessage.Text = "COST読込み　COST開示読込みファィル指定"
        '
        'txtRefInputFile
        '
        Me.txtRefInputFile.BackColor = System.Drawing.SystemColors.Control
        Me.txtRefInputFile.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.txtRefInputFile.Location = New System.Drawing.Point(15, 48)
        Me.txtRefInputFile.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtRefInputFile.Name = "txtRefInputFile"
        Me.txtRefInputFile.ReadOnly = True
        Me.txtRefInputFile.Size = New System.Drawing.Size(763, 22)
        Me.txtRefInputFile.TabIndex = 11
        Me.txtRefInputFile.TabStop = False
        '
        'cbCost
        '
        Me.cbCost.AutoSize = True
        Me.cbCost.Location = New System.Drawing.Point(31, 206)
        Me.cbCost.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cbCost.Name = "cbCost"
        Me.cbCost.Size = New System.Drawing.Size(98, 19)
        Me.cbCost.TabIndex = 280
        Me.cbCost.Text = "COST開示"
        Me.cbCost.UseVisualStyleBackColor = True
        '
        'cbTopacs
        '
        Me.cbTopacs.AutoSize = True
        Me.cbTopacs.Location = New System.Drawing.Point(239, 206)
        Me.cbTopacs.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cbTopacs.Name = "cbTopacs"
        Me.cbTopacs.Size = New System.Drawing.Size(116, 19)
        Me.cbTopacs.TabIndex = 281
        Me.cbTopacs.Text = "TOPACS申請"
        Me.cbTopacs.UseVisualStyleBackColor = True
        '
        'cbIgf
        '
        Me.cbIgf.AutoSize = True
        Me.cbIgf.Location = New System.Drawing.Point(143, 206)
        Me.cbIgf.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cbIgf.Name = "cbIgf"
        Me.cbIgf.Size = New System.Drawing.Size(81, 19)
        Me.cbIgf.TabIndex = 282
        Me.cbIgf.Text = "IGF集計"
        Me.cbIgf.UseVisualStyleBackColor = True
        '
        'cbSlink
        '
        Me.cbSlink.AutoSize = True
        Me.cbSlink.Location = New System.Drawing.Point(372, 206)
        Me.cbSlink.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cbSlink.Name = "cbSlink"
        Me.cbSlink.Size = New System.Drawing.Size(107, 19)
        Me.cbSlink.TabIndex = 283
        Me.cbSlink.Text = "S-LINK情報"
        Me.cbSlink.UseVisualStyleBackColor = True
        '
        'cbContractDoc
        '
        Me.cbContractDoc.AutoSize = True
        Me.cbContractDoc.Location = New System.Drawing.Point(492, 206)
        Me.cbContractDoc.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cbContractDoc.Name = "cbContractDoc"
        Me.cbContractDoc.Size = New System.Drawing.Size(164, 19)
        Me.cbContractDoc.TabIndex = 284
        Me.cbContractDoc.Text = "契約書別紙基本情報"
        Me.cbContractDoc.UseVisualStyleBackColor = True
        '
        'btnInput
        '
        Me.btnInput.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnInput.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnInput.ForeColor = System.Drawing.Color.White
        Me.btnInput.Location = New System.Drawing.Point(579, 359)
        Me.btnInput.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnInput.Name = "btnInput"
        Me.btnInput.Size = New System.Drawing.Size(152, 55)
        Me.btnInput.TabIndex = 16
        Me.btnInput.Text = "読込"
        Me.btnInput.UseVisualStyleBackColor = False
        '
        'btnOutput
        '
        Me.btnOutput.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnOutput.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOutput.ForeColor = System.Drawing.Color.White
        Me.btnOutput.Location = New System.Drawing.Point(419, 359)
        Me.btnOutput.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnOutput.Name = "btnOutput"
        Me.btnOutput.Size = New System.Drawing.Size(152, 55)
        Me.btnOutput.TabIndex = 15
        Me.btnOutput.Text = "作成"
        Me.btnOutput.UseVisualStyleBackColor = False
        '
        'BtnDispExplorer1
        '
        Me.BtnDispExplorer1.BackColor = System.Drawing.Color.RoyalBlue
        Me.BtnDispExplorer1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnDispExplorer1.ForeColor = System.Drawing.Color.White
        Me.BtnDispExplorer1.Location = New System.Drawing.Point(757, 359)
        Me.BtnDispExplorer1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BtnDispExplorer1.Name = "BtnDispExplorer1"
        Me.BtnDispExplorer1.Size = New System.Drawing.Size(152, 55)
        Me.BtnDispExplorer1.TabIndex = 17
        Me.BtnDispExplorer1.Text = "ﾌｫﾙﾀﾞ表示"
        Me.BtnDispExplorer1.UseVisualStyleBackColor = False
        '
        'btnLogOut
        '
        Me.btnLogOut.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnLogOut.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogOut.ForeColor = System.Drawing.Color.White
        Me.btnLogOut.Location = New System.Drawing.Point(17, 359)
        Me.btnLogOut.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnLogOut.Name = "btnLogOut"
        Me.btnLogOut.Size = New System.Drawing.Size(152, 55)
        Me.btnLogOut.TabIndex = 13
        Me.btnLogOut.Text = "ログアウト"
        Me.btnLogOut.UseVisualStyleBackColor = False
        '
        'Btn_Rtn
        '
        Me.Btn_Rtn.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Rtn.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Rtn.ForeColor = System.Drawing.Color.White
        Me.Btn_Rtn.Location = New System.Drawing.Point(177, 359)
        Me.Btn_Rtn.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Btn_Rtn.Name = "Btn_Rtn"
        Me.Btn_Rtn.Size = New System.Drawing.Size(152, 55)
        Me.Btn_Rtn.TabIndex = 14
        Me.Btn_Rtn.Text = "メニューへ"
        Me.Btn_Rtn.UseVisualStyleBackColor = False
        '
        'Btn_InputFileDisp
        '
        Me.Btn_InputFileDisp.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_InputFileDisp.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_InputFileDisp.ForeColor = System.Drawing.Color.White
        Me.Btn_InputFileDisp.Location = New System.Drawing.Point(805, 168)
        Me.Btn_InputFileDisp.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Btn_InputFileDisp.Name = "Btn_InputFileDisp"
        Me.Btn_InputFileDisp.Size = New System.Drawing.Size(99, 36)
        Me.Btn_InputFileDisp.TabIndex = 2
        Me.Btn_InputFileDisp.Text = "参照"
        Me.Btn_InputFileDisp.UseVisualStyleBackColor = False
        '
        'UCnt_Pal00011
        '
        Me.UCnt_Pal00011.BackColor = System.Drawing.Color.Teal
        Me.UCnt_Pal00011.BackColro2 = System.Drawing.Color.PaleTurquoise
        Me.UCnt_Pal00011.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UCnt_Pal00011.ForeColor = System.Drawing.Color.White
        Me.UCnt_Pal00011.Location = New System.Drawing.Point(1, 1)
        Me.UCnt_Pal00011.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.UCnt_Pal00011.Name = "UCnt_Pal00011"
        Me.UCnt_Pal00011.Size = New System.Drawing.Size(923, 55)
        Me.UCnt_Pal00011.TabIndex = 268
        Me.UCnt_Pal00011.TitleText = "OIO BAMA Client 連携ファイル管理"
        '
        'cbPaymentSplit
        '
        Me.cbPaymentSplit.AutoSize = True
        Me.cbPaymentSplit.Location = New System.Drawing.Point(697, 206)
        Me.cbPaymentSplit.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cbPaymentSplit.Name = "cbPaymentSplit"
        Me.cbPaymentSplit.Size = New System.Drawing.Size(114, 19)
        Me.cbPaymentSplit.TabIndex = 285
        Me.cbPaymentSplit.Text = "Payment分割"
        Me.cbPaymentSplit.UseVisualStyleBackColor = True
        '
        'cbIsatMa
        '
        Me.cbIsatMa.AutoSize = True
        Me.cbIsatMa.Location = New System.Drawing.Point(29, 232)
        Me.cbIsatMa.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cbIsatMa.Name = "cbIsatMa"
        Me.cbIsatMa.Size = New System.Drawing.Size(90, 19)
        Me.cbIsatMa.TabIndex = 286
        Me.cbIsatMa.Text = "ISAT見積"
        Me.cbIsatMa.UseVisualStyleBackColor = True
        '
        'cbElaFile
        '
        Me.cbElaFile.AutoSize = True
        Me.cbElaFile.Location = New System.Drawing.Point(143, 234)
        Me.cbElaFile.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cbElaFile.Name = "cbElaFile"
        Me.cbElaFile.Size = New System.Drawing.Size(88, 19)
        Me.cbElaFile.TabIndex = 287
        Me.cbElaFile.Text = "ELAﾌｧｲﾙ"
        Me.cbElaFile.UseVisualStyleBackColor = True
        '
        'cbEpricer
        '
        Me.cbEpricer.AutoSize = True
        Me.cbEpricer.Location = New System.Drawing.Point(239, 232)
        Me.cbEpricer.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cbEpricer.Name = "cbEpricer"
        Me.cbEpricer.Size = New System.Drawing.Size(113, 19)
        Me.cbEpricer.TabIndex = 288
        Me.cbEpricer.Text = "e-Pricer申請"
        Me.cbEpricer.UseVisualStyleBackColor = True
        '
        'Frm_NewPmoManage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(925, 444)
        Me.ControlBox = False
        Me.Controls.Add(Me.cbEpricer)
        Me.Controls.Add(Me.cbElaFile)
        Me.Controls.Add(Me.cbIsatMa)
        Me.Controls.Add(Me.cbPaymentSplit)
        Me.Controls.Add(Me.cbContractDoc)
        Me.Controls.Add(Me.cbSlink)
        Me.Controls.Add(Me.cbIgf)
        Me.Controls.Add(Me.cbTopacs)
        Me.Controls.Add(Me.cbCost)
        Me.Controls.Add(Me.btnInput)
        Me.Controls.Add(Me.btnOutput)
        Me.Controls.Add(Me.gbSystem)
        Me.Controls.Add(Me.BtnDispExplorer1)
        Me.Controls.Add(Me.GroupBox9)
        Me.Controls.Add(Me.btnLogOut)
        Me.Controls.Add(Me.Btn_Rtn)
        Me.Controls.Add(Me.Btn_InputFileDisp)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txb_InputFile)
        Me.Controls.Add(Me.UCnt_Pal00011)
        Me.Location = New System.Drawing.Point(435, 60)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.MaximizeBox = False
        Me.Name = "Frm_NewPmoManage"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "OIO BAMA Client"
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        Me.gbSystem.ResumeLayout(False)
        Me.gbSystem.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents txb_Contact_No_Name As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents txb_DispCpno As System.Windows.Forms.TextBox
    Friend WithEvents txb_DispKeiyakuZyunban As System.Windows.Forms.TextBox
    Friend WithEvents txb_DispCustNm As System.Windows.Forms.TextBox
    Friend WithEvents btnLogOut As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Rtn As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_InputFileDisp As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txb_InputFile As System.Windows.Forms.TextBox
    Friend WithEvents UCnt_Pal00011 As MUSE.UserControl.UCnt_Pal0001
    Friend WithEvents BtnDispExplorer1 As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents gbSystem As System.Windows.Forms.GroupBox
    Friend WithEvents btnSysReference As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents lblMessage As System.Windows.Forms.Label
    Friend WithEvents txtRefInputFile As System.Windows.Forms.TextBox
    Friend WithEvents btnOutput As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents btnInput As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents cbCost As System.Windows.Forms.CheckBox
    Friend WithEvents cbTopacs As System.Windows.Forms.CheckBox
    Friend WithEvents cbIgf As System.Windows.Forms.CheckBox
    Friend WithEvents cbSlink As System.Windows.Forms.CheckBox
    Friend WithEvents cbContractDoc As System.Windows.Forms.CheckBox
    Friend WithEvents cbPaymentSplit As System.Windows.Forms.CheckBox
    Friend WithEvents cbIsatMa As System.Windows.Forms.CheckBox
    Friend WithEvents cbElaFile As System.Windows.Forms.CheckBox
    Friend WithEvents cbEpricer As System.Windows.Forms.CheckBox
End Class
