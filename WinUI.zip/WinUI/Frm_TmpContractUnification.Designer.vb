﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frm_TmpContractUnification
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Cmb_TmpContract = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Txb_InputContract = New System.Windows.Forms.TextBox()
        Me.Trv_ContractInfo = New System.Windows.Forms.TreeView()
        Me.Lbl_TreeViewState = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Llb_UseInfo = New System.Windows.Forms.LinkLabel()
        Me.Grp_003 = New System.Windows.Forms.GroupBox()
        Me.Llb_TmpInfo = New System.Windows.Forms.LinkLabel()
        Me.Btn_ChkOff = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_ChkOn = New MUSE.UserControl.UCnt_Btn0001()
        Me.Grp_004 = New System.Windows.Forms.GroupBox()
        Me.Btn_ReSetContract = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_UnificationContract = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_DelContract = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_ChkContractDeff = New MUSE.UserControl.UCnt_Btn0001()
        Me.Grp_002 = New System.Windows.Forms.GroupBox()
        Me.ChkDispContract = New System.Windows.Forms.CheckBox()
        Me.Lbl_Unification = New System.Windows.Forms.Label()
        Me.Lbl_CpNo = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Grp_001 = New System.Windows.Forms.GroupBox()
        Me.Rdb_RefContract = New System.Windows.Forms.RadioButton()
        Me.Rdb_ChkContractDeff = New System.Windows.Forms.RadioButton()
        Me.Rdb_DelContract = New System.Windows.Forms.RadioButton()
        Me.Rdb_UnificationContract = New System.Windows.Forms.RadioButton()
        Me.Btn_RefFrm = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_DispFolder = New MUSE.UserControl.UCnt_Btn0001()
        Me.UCnt_Btn00013 = New MUSE.UserControl.UCnt_Btn0001()
        Me.BtnLogOut = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_RtnFrmContract = New MUSE.UserControl.UCnt_Btn0001()
        Me.UCnt_Pal00011 = New MUSE.UserControl.UCnt_Pal0001()
        Me.Grp_003.SuspendLayout()
        Me.Grp_004.SuspendLayout()
        Me.Grp_002.SuspendLayout()
        Me.Grp_001.SuspendLayout()
        Me.SuspendLayout()
        '
        'Cmb_TmpContract
        '
        Me.Cmb_TmpContract.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_TmpContract.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Cmb_TmpContract.FormattingEnabled = True
        Me.Cmb_TmpContract.Location = New System.Drawing.Point(143, 38)
        Me.Cmb_TmpContract.MaxLength = 3
        Me.Cmb_TmpContract.Name = "Cmb_TmpContract"
        Me.Cmb_TmpContract.Size = New System.Drawing.Size(110, 20)
        Me.Cmb_TmpContract.TabIndex = 30
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label2.Location = New System.Drawing.Point(26, 22)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(107, 12)
        Me.Label2.TabIndex = 30
        Me.Label2.Text = "仮契約No 直接入力"
        '
        'Txb_InputContract
        '
        Me.Txb_InputContract.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Txb_InputContract.Location = New System.Drawing.Point(28, 39)
        Me.Txb_InputContract.Name = "Txb_InputContract"
        Me.Txb_InputContract.Size = New System.Drawing.Size(284, 19)
        Me.Txb_InputContract.TabIndex = 40
        '
        'Trv_ContractInfo
        '
        Me.Trv_ContractInfo.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Trv_ContractInfo.Location = New System.Drawing.Point(28, 84)
        Me.Trv_ContractInfo.Name = "Trv_ContractInfo"
        Me.Trv_ContractInfo.Size = New System.Drawing.Size(372, 242)
        Me.Trv_ContractInfo.TabIndex = 90
        '
        'Lbl_TreeViewState
        '
        Me.Lbl_TreeViewState.AutoSize = True
        Me.Lbl_TreeViewState.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Lbl_TreeViewState.Location = New System.Drawing.Point(121, 68)
        Me.Lbl_TreeViewState.Name = "Lbl_TreeViewState"
        Me.Lbl_TreeViewState.Size = New System.Drawing.Size(117, 12)
        Me.Lbl_TreeViewState.TabIndex = 70
        Me.Lbl_TreeViewState.Text = "<<統合データ表示中>>"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label5.Location = New System.Drawing.Point(26, 68)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(65, 12)
        Me.Label5.TabIndex = 80
        Me.Label5.Text = "仮契約一覧"
        '
        'Llb_UseInfo
        '
        Me.Llb_UseInfo.AutoSize = True
        Me.Llb_UseInfo.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Llb_UseInfo.Location = New System.Drawing.Point(317, 19)
        Me.Llb_UseInfo.Name = "Llb_UseInfo"
        Me.Llb_UseInfo.Size = New System.Drawing.Size(99, 12)
        Me.Llb_UseInfo.TabIndex = 20
        Me.Llb_UseInfo.TabStop = True
        Me.Llb_UseInfo.Text = "※使用方法の説明"
        '
        'Grp_003
        '
        Me.Grp_003.Controls.Add(Me.Llb_TmpInfo)
        Me.Grp_003.Controls.Add(Me.Btn_ChkOff)
        Me.Grp_003.Controls.Add(Me.Btn_ChkOn)
        Me.Grp_003.Controls.Add(Me.Llb_UseInfo)
        Me.Grp_003.Controls.Add(Me.Label2)
        Me.Grp_003.Controls.Add(Me.Txb_InputContract)
        Me.Grp_003.Controls.Add(Me.Label5)
        Me.Grp_003.Controls.Add(Me.Trv_ContractInfo)
        Me.Grp_003.Controls.Add(Me.Lbl_TreeViewState)
        Me.Grp_003.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Grp_003.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Grp_003.Location = New System.Drawing.Point(35, 193)
        Me.Grp_003.Name = "Grp_003"
        Me.Grp_003.Size = New System.Drawing.Size(529, 339)
        Me.Grp_003.TabIndex = 20
        Me.Grp_003.TabStop = False
        Me.Grp_003.Text = "３) 統合または削除可能　仮契約一覧選択"
        '
        'Llb_TmpInfo
        '
        Me.Llb_TmpInfo.AutoSize = True
        Me.Llb_TmpInfo.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Llb_TmpInfo.Location = New System.Drawing.Point(317, 68)
        Me.Llb_TmpInfo.Name = "Llb_TmpInfo"
        Me.Llb_TmpInfo.Size = New System.Drawing.Size(99, 12)
        Me.Llb_TmpInfo.TabIndex = 85
        Me.Llb_TmpInfo.TabStop = True
        Me.Llb_TmpInfo.Text = "※仮契一覧の説明"
        '
        'Btn_ChkOff
        '
        Me.Btn_ChkOff.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Btn_ChkOff.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_ChkOff.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_ChkOff.ForeColor = System.Drawing.Color.White
        Me.Btn_ChkOff.Location = New System.Drawing.Point(403, 35)
        Me.Btn_ChkOff.Name = "Btn_ChkOff"
        Me.Btn_ChkOff.Size = New System.Drawing.Size(81, 25)
        Me.Btn_ChkOff.TabIndex = 60
        Me.Btn_ChkOff.Text = "▼チェックOFF"
        Me.Btn_ChkOff.UseVisualStyleBackColor = False
        '
        'Btn_ChkOn
        '
        Me.Btn_ChkOn.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Btn_ChkOn.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_ChkOn.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_ChkOn.ForeColor = System.Drawing.Color.White
        Me.Btn_ChkOn.Location = New System.Drawing.Point(318, 35)
        Me.Btn_ChkOn.Name = "Btn_ChkOn"
        Me.Btn_ChkOn.Size = New System.Drawing.Size(78, 25)
        Me.Btn_ChkOn.TabIndex = 50
        Me.Btn_ChkOn.Text = "▼チェックON"
        Me.Btn_ChkOn.UseVisualStyleBackColor = False
        '
        'Grp_004
        '
        Me.Grp_004.Controls.Add(Me.Btn_ReSetContract)
        Me.Grp_004.Controls.Add(Me.Btn_UnificationContract)
        Me.Grp_004.Controls.Add(Me.Btn_DelContract)
        Me.Grp_004.Controls.Add(Me.Btn_ChkContractDeff)
        Me.Grp_004.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Grp_004.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Grp_004.Location = New System.Drawing.Point(35, 520)
        Me.Grp_004.Name = "Grp_004"
        Me.Grp_004.Size = New System.Drawing.Size(530, 70)
        Me.Grp_004.TabIndex = 30
        Me.Grp_004.TabStop = False
        Me.Grp_004.Text = "４) 処理開始指示"
        '
        'Btn_ReSetContract
        '
        Me.Btn_ReSetContract.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Btn_ReSetContract.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_ReSetContract.Enabled = False
        Me.Btn_ReSetContract.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_ReSetContract.ForeColor = System.Drawing.Color.White
        Me.Btn_ReSetContract.Location = New System.Drawing.Point(402, 20)
        Me.Btn_ReSetContract.Name = "Btn_ReSetContract"
        Me.Btn_ReSetContract.Size = New System.Drawing.Size(110, 40)
        Me.Btn_ReSetContract.TabIndex = 30
        Me.Btn_ReSetContract.Text = "仮契約　　　　リセット"
        Me.Btn_ReSetContract.UseVisualStyleBackColor = False
        '
        'Btn_UnificationContract
        '
        Me.Btn_UnificationContract.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Btn_UnificationContract.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_UnificationContract.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_UnificationContract.ForeColor = System.Drawing.Color.White
        Me.Btn_UnificationContract.Location = New System.Drawing.Point(19, 20)
        Me.Btn_UnificationContract.Name = "Btn_UnificationContract"
        Me.Btn_UnificationContract.Size = New System.Drawing.Size(110, 40)
        Me.Btn_UnificationContract.TabIndex = 0
        Me.Btn_UnificationContract.Text = "仮契約　　　統合開始"
        Me.Btn_UnificationContract.UseVisualStyleBackColor = False
        '
        'Btn_DelContract
        '
        Me.Btn_DelContract.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Btn_DelContract.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_DelContract.Enabled = False
        Me.Btn_DelContract.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_DelContract.ForeColor = System.Drawing.Color.White
        Me.Btn_DelContract.Location = New System.Drawing.Point(146, 20)
        Me.Btn_DelContract.Name = "Btn_DelContract"
        Me.Btn_DelContract.Size = New System.Drawing.Size(110, 40)
        Me.Btn_DelContract.TabIndex = 10
        Me.Btn_DelContract.Text = "仮契約　　　削除開始"
        Me.Btn_DelContract.UseVisualStyleBackColor = False
        '
        'Btn_ChkContractDeff
        '
        Me.Btn_ChkContractDeff.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Btn_ChkContractDeff.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_ChkContractDeff.Enabled = False
        Me.Btn_ChkContractDeff.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_ChkContractDeff.ForeColor = System.Drawing.Color.White
        Me.Btn_ChkContractDeff.Location = New System.Drawing.Point(274, 20)
        Me.Btn_ChkContractDeff.Name = "Btn_ChkContractDeff"
        Me.Btn_ChkContractDeff.Size = New System.Drawing.Size(110, 40)
        Me.Btn_ChkContractDeff.TabIndex = 20
        Me.Btn_ChkContractDeff.Text = "統合正契約　　チェック開始"
        Me.Btn_ChkContractDeff.UseVisualStyleBackColor = False
        '
        'Grp_002
        '
        Me.Grp_002.Controls.Add(Me.ChkDispContract)
        Me.Grp_002.Controls.Add(Me.Lbl_Unification)
        Me.Grp_002.Controls.Add(Me.Lbl_CpNo)
        Me.Grp_002.Controls.Add(Me.Label1)
        Me.Grp_002.Controls.Add(Me.Cmb_TmpContract)
        Me.Grp_002.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Grp_002.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Grp_002.Location = New System.Drawing.Point(34, 122)
        Me.Grp_002.Name = "Grp_002"
        Me.Grp_002.Size = New System.Drawing.Size(530, 64)
        Me.Grp_002.TabIndex = 10
        Me.Grp_002.TabStop = False
        Me.Grp_002.Text = "２) 統合/削除/チェック　正契約No入力"
        '
        'ChkDispContract
        '
        Me.ChkDispContract.AutoSize = True
        Me.ChkDispContract.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.ChkDispContract.Location = New System.Drawing.Point(271, 17)
        Me.ChkDispContract.Name = "ChkDispContract"
        Me.ChkDispContract.Size = New System.Drawing.Size(183, 16)
        Me.ChkDispContract.TabIndex = 35
        Me.ChkDispContract.Text = "契約締結済み/廃案案件の表示"
        Me.ChkDispContract.UseVisualStyleBackColor = True
        '
        'Lbl_Unification
        '
        Me.Lbl_Unification.AutoSize = True
        Me.Lbl_Unification.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Lbl_Unification.Location = New System.Drawing.Point(27, 41)
        Me.Lbl_Unification.Name = "Lbl_Unification"
        Me.Lbl_Unification.Size = New System.Drawing.Size(103, 12)
        Me.Lbl_Unification.TabIndex = 20
        Me.Lbl_Unification.Text = "統合対象正契約No"
        Me.Lbl_Unification.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Lbl_CpNo
        '
        Me.Lbl_CpNo.AutoSize = True
        Me.Lbl_CpNo.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Lbl_CpNo.Location = New System.Drawing.Point(141, 21)
        Me.Lbl_CpNo.Name = "Lbl_CpNo"
        Me.Lbl_CpNo.Size = New System.Drawing.Size(75, 12)
        Me.Lbl_CpNo.TabIndex = 10
        Me.Lbl_CpNo.Text = "XXXXXXXXXX"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label1.Location = New System.Drawing.Point(26, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "作業中CPNO"
        '
        'Grp_001
        '
        Me.Grp_001.Controls.Add(Me.Rdb_RefContract)
        Me.Grp_001.Controls.Add(Me.Rdb_ChkContractDeff)
        Me.Grp_001.Controls.Add(Me.Rdb_DelContract)
        Me.Grp_001.Controls.Add(Me.Rdb_UnificationContract)
        Me.Grp_001.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Grp_001.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Grp_001.Location = New System.Drawing.Point(34, 51)
        Me.Grp_001.Name = "Grp_001"
        Me.Grp_001.Size = New System.Drawing.Size(530, 64)
        Me.Grp_001.TabIndex = 9
        Me.Grp_001.TabStop = False
        Me.Grp_001.Text = "１) 処理の選択"
        '
        'Rdb_RefContract
        '
        Me.Rdb_RefContract.AutoSize = True
        Me.Rdb_RefContract.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Rdb_RefContract.Location = New System.Drawing.Point(167, 40)
        Me.Rdb_RefContract.Name = "Rdb_RefContract"
        Me.Rdb_RefContract.Size = New System.Drawing.Size(115, 16)
        Me.Rdb_RefContract.TabIndex = 30
        Me.Rdb_RefContract.Text = "仮契約リセット処理"
        Me.Rdb_RefContract.UseVisualStyleBackColor = True
        '
        'Rdb_ChkContractDeff
        '
        Me.Rdb_ChkContractDeff.AutoSize = True
        Me.Rdb_ChkContractDeff.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Rdb_ChkContractDeff.Location = New System.Drawing.Point(167, 18)
        Me.Rdb_ChkContractDeff.Name = "Rdb_ChkContractDeff"
        Me.Rdb_ChkContractDeff.Size = New System.Drawing.Size(132, 16)
        Me.Rdb_ChkContractDeff.TabIndex = 20
        Me.Rdb_ChkContractDeff.Text = "統合正契約ﾁｪｯｸ処理"
        Me.Rdb_ChkContractDeff.UseVisualStyleBackColor = True
        '
        'Rdb_DelContract
        '
        Me.Rdb_DelContract.AutoSize = True
        Me.Rdb_DelContract.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Rdb_DelContract.Location = New System.Drawing.Point(29, 40)
        Me.Rdb_DelContract.Name = "Rdb_DelContract"
        Me.Rdb_DelContract.Size = New System.Drawing.Size(107, 16)
        Me.Rdb_DelContract.TabIndex = 10
        Me.Rdb_DelContract.Text = "仮契約削除処理"
        Me.Rdb_DelContract.UseVisualStyleBackColor = True
        '
        'Rdb_UnificationContract
        '
        Me.Rdb_UnificationContract.AutoSize = True
        Me.Rdb_UnificationContract.Checked = True
        Me.Rdb_UnificationContract.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Rdb_UnificationContract.Location = New System.Drawing.Point(29, 18)
        Me.Rdb_UnificationContract.Name = "Rdb_UnificationContract"
        Me.Rdb_UnificationContract.Size = New System.Drawing.Size(107, 16)
        Me.Rdb_UnificationContract.TabIndex = 0
        Me.Rdb_UnificationContract.TabStop = True
        Me.Rdb_UnificationContract.Text = "仮契約統合処理"
        Me.Rdb_UnificationContract.UseVisualStyleBackColor = True
        '
        'Btn_RefFrm
        '
        Me.Btn_RefFrm.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Btn_RefFrm.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_RefFrm.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_RefFrm.ForeColor = System.Drawing.Color.White
        Me.Btn_RefFrm.Location = New System.Drawing.Point(443, 598)
        Me.Btn_RefFrm.Name = "Btn_RefFrm"
        Me.Btn_RefFrm.Size = New System.Drawing.Size(121, 40)
        Me.Btn_RefFrm.TabIndex = 8
        Me.Btn_RefFrm.Text = "画面リフレッシュ"
        Me.Btn_RefFrm.UseVisualStyleBackColor = False
        '
        'Btn_DispFolder
        '
        Me.Btn_DispFolder.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Btn_DispFolder.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_DispFolder.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_DispFolder.ForeColor = System.Drawing.Color.White
        Me.Btn_DispFolder.Location = New System.Drawing.Point(317, 598)
        Me.Btn_DispFolder.Name = "Btn_DispFolder"
        Me.Btn_DispFolder.Size = New System.Drawing.Size(117, 40)
        Me.Btn_DispFolder.TabIndex = 7
        Me.Btn_DispFolder.Text = "フォルダ表示"
        Me.Btn_DispFolder.UseVisualStyleBackColor = False
        '
        'UCnt_Btn00013
        '
        Me.UCnt_Btn00013.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.UCnt_Btn00013.BackColor = System.Drawing.Color.RoyalBlue
        Me.UCnt_Btn00013.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UCnt_Btn00013.ForeColor = System.Drawing.Color.White
        Me.UCnt_Btn00013.Location = New System.Drawing.Point(416, 203)
        Me.UCnt_Btn00013.Name = "UCnt_Btn00013"
        Me.UCnt_Btn00013.Size = New System.Drawing.Size(81, 25)
        Me.UCnt_Btn00013.TabIndex = 278
        Me.UCnt_Btn00013.Text = "▼チェックOFF"
        Me.UCnt_Btn00013.UseVisualStyleBackColor = False
        '
        'BtnLogOut
        '
        Me.BtnLogOut.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.BtnLogOut.BackColor = System.Drawing.Color.RoyalBlue
        Me.BtnLogOut.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLogOut.ForeColor = System.Drawing.Color.White
        Me.BtnLogOut.Location = New System.Drawing.Point(35, 598)
        Me.BtnLogOut.Name = "BtnLogOut"
        Me.BtnLogOut.Size = New System.Drawing.Size(129, 40)
        Me.BtnLogOut.TabIndex = 5
        Me.BtnLogOut.Text = "ログアウト"
        Me.BtnLogOut.UseVisualStyleBackColor = False
        '
        'Btn_RtnFrmContract
        '
        Me.Btn_RtnFrmContract.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Btn_RtnFrmContract.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_RtnFrmContract.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_RtnFrmContract.ForeColor = System.Drawing.Color.White
        Me.Btn_RtnFrmContract.Location = New System.Drawing.Point(175, 598)
        Me.Btn_RtnFrmContract.Name = "Btn_RtnFrmContract"
        Me.Btn_RtnFrmContract.Size = New System.Drawing.Size(134, 40)
        Me.Btn_RtnFrmContract.TabIndex = 6
        Me.Btn_RtnFrmContract.Text = "契約登録画面へ"
        Me.Btn_RtnFrmContract.UseVisualStyleBackColor = False
        '
        'UCnt_Pal00011
        '
        Me.UCnt_Pal00011.BackColor = System.Drawing.Color.Teal
        Me.UCnt_Pal00011.BackColro2 = System.Drawing.Color.PaleTurquoise
        Me.UCnt_Pal00011.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UCnt_Pal00011.ForeColor = System.Drawing.Color.White
        Me.UCnt_Pal00011.Location = New System.Drawing.Point(1, 1)
        Me.UCnt_Pal00011.Name = "UCnt_Pal00011"
        Me.UCnt_Pal00011.Size = New System.Drawing.Size(613, 44)
        Me.UCnt_Pal00011.TabIndex = 0
        Me.UCnt_Pal00011.TitleText = "OIO BAMA Client 仮契約統合・削除・チェック"
        '
        'Frm_TmpContractUnification
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(623, 663)
        Me.ControlBox = False
        Me.Controls.Add(Me.Btn_RefFrm)
        Me.Controls.Add(Me.Btn_DispFolder)
        Me.Controls.Add(Me.Grp_001)
        Me.Controls.Add(Me.Grp_002)
        Me.Controls.Add(Me.Grp_004)
        Me.Controls.Add(Me.Grp_003)
        Me.Controls.Add(Me.UCnt_Btn00013)
        Me.Controls.Add(Me.BtnLogOut)
        Me.Controls.Add(Me.Btn_RtnFrmContract)
        Me.Controls.Add(Me.UCnt_Pal00011)
        Me.MaximizeBox = False
        Me.Name = "Frm_TmpContractUnification"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "OIO BAMA Client"
        Me.Grp_003.ResumeLayout(False)
        Me.Grp_003.PerformLayout()
        Me.Grp_004.ResumeLayout(False)
        Me.Grp_002.ResumeLayout(False)
        Me.Grp_002.PerformLayout()
        Me.Grp_001.ResumeLayout(False)
        Me.Grp_001.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents BtnLogOut As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_RtnFrmContract As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents UCnt_Pal00011 As MUSE.UserControl.UCnt_Pal0001
    Friend WithEvents Cmb_TmpContract As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Txb_InputContract As System.Windows.Forms.TextBox
    Friend WithEvents UCnt_Btn00013 As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Trv_ContractInfo As System.Windows.Forms.TreeView
    Friend WithEvents Lbl_TreeViewState As System.Windows.Forms.Label
    Friend WithEvents Btn_UnificationContract As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Btn_DelContract As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_ChkContractDeff As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Llb_UseInfo As System.Windows.Forms.LinkLabel
    Friend WithEvents Grp_003 As System.Windows.Forms.GroupBox
    Friend WithEvents Grp_004 As System.Windows.Forms.GroupBox
    Friend WithEvents Grp_002 As System.Windows.Forms.GroupBox
    Friend WithEvents Lbl_Unification As System.Windows.Forms.Label
    Friend WithEvents Lbl_CpNo As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Btn_ChkOff As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_ChkOn As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_ReSetContract As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Grp_001 As System.Windows.Forms.GroupBox
    Friend WithEvents Rdb_UnificationContract As System.Windows.Forms.RadioButton
    Friend WithEvents Rdb_RefContract As System.Windows.Forms.RadioButton
    Friend WithEvents Rdb_ChkContractDeff As System.Windows.Forms.RadioButton
    Friend WithEvents Rdb_DelContract As System.Windows.Forms.RadioButton
    Friend WithEvents Btn_DispFolder As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_RefFrm As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Llb_TmpInfo As System.Windows.Forms.LinkLabel
    Friend WithEvents ChkDispContract As System.Windows.Forms.CheckBox
End Class
