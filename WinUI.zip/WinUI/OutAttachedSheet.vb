﻿Imports Microsoft.Office.Interop
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility
Imports MUSE.Utility.SharedClass.ExcelWrite
Imports System.Text
Imports MUSE.Utility.OioBamaCommmon
Imports MUSE.Utility.UserDataTable.Master
Imports System.Data.OleDb

Public Class OutAttachedSheet
    Inherits OutExcelBase

#Region "定数"


    ''契約基本別紙のｼｰﾄ名
    Private Const SheetNM_Title As String = "サマリ"
    Private Const SheetNM_SW As String = "SW別紙"
    Private Const SheetNM_PA As String = "PA別紙"
    Private Const SheetNM_VLS As String = "VLS別紙"

    ''契約書別紙の作成シート名
    Private Const SheetNM_Del_SW As String = "SW 削除"
    Private Const SheetNM_ADD_SW As String = "SW 追加"
    Private Const SheetNM_Del_PALicence As String = "PA Licence削除"
    Private Const SheetNM_ADD_PALicence As String = "PA Licence追加"
    Private Const SheetNM_Del_PASSMontly As String = "PA S&S月割り削除"
    Private Const SheetNM_ADD_PASSMontly As String = "PA S&S月割り追加"
    Private Const SheetNM_Del_PASSFull As String = "PA S&S FULL削除"
    Private Const SheetNM_ADD_PASSFull As String = "PA S&S FULL追加"
    Private Const SheetNM_Del_PAMedia As String = "PA Media削除"
    Private Const SheetNM_ADD_PAMedia As String = "PA Media追加"
    Private Const SheetNM_Del_VLS As String = "VLS 削除"
    Private Const SheetNM_ADD_VLS As String = "VLS 追加"

    ''PAの種類
    Const Brand_PA_Media As String = "PA-Media"
    Const Brand_PA_License As String = "PA-License"
    Const Brand_PA_SS As String = "PA-S&S"
    Const Brand_PA_SS_Montry As String = "PA-S&S 月割り"
    Const Brand_PA_SS_Full As String = "PA-S&S FULL"

    ''PAの出力順
    Const PA_Sort_License As String = "0"
    Const PA_Sort_SS_Montry As String = "1"
    Const PA_Sort_SS_Full As String = "2"
    Const PA_Sort_Media As String = "3"
    Const PA_Sort_SS As String = "-"

#End Region

#Region "列挙体"

    ''                  以下、各シートに出力するカラム
    ''------------------------------------------------------------
    ''Title 基本情報
    Private Enum TitleBase_Column

        ''基本データ
        ContractNo = 1          ''契約順番
        ContractName            ''契約順番名
        ControlName             ''管理番号
        PaymentPath             ''Paymentﾌｧｲﾙﾊﾟｽ
        PaymentData             ''Paymentﾌｧｲﾙ日付
        BuyNo                   ''購買番号
        DspBuyNo                ''表示用_購買番号
        CreateDay               ''作成日時

    End Enum

    ''Title ﾌｧｲﾙ一覧
    Private Enum TitleFile_Column

        ''作成ファイル
        OutFileName             ''ファイル名
        SWOutCount              ''SW  出力件数
        SWInfoCount             ''SW  確認事項
        PAOutCount              ''PA  出力件数
        PAInfoCount             ''PA  出力件数
        VLSOutCount             ''VLS 出力件数
        VLSInfoCount            ''VLS 出力件数
        BuyNo                   ''購買番号
        DspBuyNo                ''表示用_購買番号

    End Enum

    ''SW
    Private Enum SW_Column
        ControlNo = 1           ''管理番号  
        DspControlNo            ''帳票表示用_管理番号
        ControlName             ''管理名称
        HWMTDL                  ''HWMTDL
        HWSerial                ''HWSerial
        Product                 ''Product
        Description             ''Description
        QTY                     ''QTY
        OfferStr                ''提供期間_開始日
        OfferEnd                ''提供期間_終了日
        PostScript              ''補足
        Confirmation            ''確認事項
        LineNo                  ''LineNo
        FileNM                  ''ファイル名
        FileNMSuffix            ''ファイル名サフィックス
        FileIntrSuffix          ''ファイル内サフィックス
        Item10                  ''取り込み元ﾃﾞｰﾀ
        Item14                  ''仮契約NO
        Listprice               ''Listprice
        ListpriceSum            ''Listprice合計
        DPerPrice               ''D%適用後
        DPerPriceSum            ''D%適用後合計
        IsDetail                ''PS情報 or 詳細情報
        PSExcelRow              ''PSのExcel行位置
        DetailExcelRow          ''詳細のExcel行位置

    End Enum

    ''PA
    Private Enum PA_Column
        ControlNo = 1           ''管理番号  
        DspControlNo            ''帳票表示用_管理番号  
        ControlName             ''管理名称
        Product                 ''Product
        Description             ''Description
        QTY                     ''QTY
        OfferStr                ''提供期間_開始日
        OfferEnd                ''提供期間_終了日
        Supplement              ''補足
        PAID                    ''PAサイトID
        Confirmation            ''確認事項
        LineNo                  ''LineNo
        Item10                  ''取り込み元ﾃﾞｰﾀ
        Item14                  ''仮契約NO
        Listprice               ''Listprice
        ListpriceSum            ''Listprice合計
        DPerPrice               ''D%適用後
        DPerPriceSum            ''D%適用後合計
        Brand                   ''Brand
        DspBrand                ''帳票出力用_Brand
        BrandSort               ''BrandのSort順
        ExcelRow                ''PS上のExcel行位置
    End Enum

    ''VLS
    Private Enum VLS_Column
        ControlNo = 1           ''管理番号  
        DspControlNo            ''帳票表示用_管理番号  
        ControlName             ''管理名称
        Product                 ''Product
        Description             ''Description
        QTY                     ''QTY
        OfferStr                ''提供期間_開始日
        OfferEnd                ''提供期間_終了日
        Supplement              ''補足
        InstYM                  ''導入月
        RateStr                 ''料金期間_開始日
        RateEnd                 ''料金期間_終了日
        Confirmation            ''確認事項
        LineNo                  ''LineNo
        Item10                  ''取り込み元ﾃﾞｰﾀ
        Item14                  ''仮契約NO
        Listprice               ''Listprice
        ListpriceSum            ''Listprice合計
        DPerPrice               ''D%適用後
        DPerPriceSum            ''D%適用後合計
        ExcelRow                ''PS上のExcel行位置
    End Enum

#End Region

#Region "構造体"
    Private Structure AttachedOutCount
        Dim SWCount As Integer          ''SW  出力件数
        Dim SWInfoCount As Integer      ''SW  確認事項
        Dim PACount As Integer          ''PA  出力件数
        Dim PAInfoCount As Integer      ''PA  出力件数
        Dim VLSCount As Integer         ''VLS 出力件数
        Dim VLSInfoCount As Integer     ''VLS 出力件数
    End Structure
#End Region

#Region "Overridesメソッド"

    Protected Overrides Function CretateDetailTable() As DataTable

        ''項目追加
        Dim rtnTable As DataTable
        rtnTable = MyBase.CretateDetailTable
        rtnTable.Columns.Add("ExcelRow")

        Return rtnTable

    End Function

    Protected Overrides Sub SetDetailInsertRow(ByVal rowIdx As Integer, _
                                               ByRef insRow As DataRow, _
                                               ByRef cellValue(,) As Object)

        ''項目追加
        Call MyBase.SetDetailInsertRow(rowIdx, insRow, cellValue)
        insRow.Item("ExcelRow") = rowIdx.ToString.PadLeft(10, "0")

    End Sub

    Protected Overrides Sub CopyTmpRow(ByVal outIdx As Integer,
                                       ByRef xlOutSheet As Excel.Worksheet, _
                                       ByRef rows() As DataRow, _
                                       ByVal OutMaxLine As Integer, _
                                       ByRef SheetLayout As LayoutInfo)

        ''SW別紙以外の場合、Baseの処理で終了
        MyBase.CopyTmpRow(outIdx, xlOutSheet, rows, OutMaxLine, SheetLayout)

        ''SW別紙の場合、PsData用のﾃﾝﾌﾟﾚｰﾄの貼り付けを行う。
        Const TmpRow As Integer = 3
        Const PasteStr As Integer = 7
        Dim xlCopyCell As Excel.Range
        Dim xlPasteCell As Excel.Range

        Try
            If xlOutSheet.Name = Me.SheetNM_Del_SW Or _
               xlOutSheet.Name = Me.SheetNM_ADD_SW Then
                xlCopyCell = xlOutSheet.Rows(TmpRow)
                xlCopyCell.Hidden = False
                Call xlCopyCell.Copy()
                Dim idx As Integer = 0
                For idx = 0 To rows.Length - 1
                    If rows(idx).Item("CellNM" & SW_Column.IsDetail) = "0" Then
                        xlPasteCell = xlOutSheet.Rows(PasteStr + idx)
                        Call xlPasteCell.PasteSpecial()
                    End If
                Next
                xlCopyCell.Hidden = True

            End If
        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCopyCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPasteCell, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try
    End Sub

    Protected Overridable Sub SetCellValue(ByVal outIdx As Integer,
                                           ByRef xlOutSheet As Excel.Worksheet, _
                                           ByRef rows() As DataRow, _
                                           ByVal OutMaxLine As Integer, _
                                           ByRef SheetLayout As LayoutInfo)

        MyBase.SetCellValue(outIdx, xlOutSheet, rows, OutMaxLine, SheetLayout)

    End Sub

    ''                      ※以下、継承元から追加処理
    ''-----------------------------------------------------------------------
    Protected Overrides Function CretatePSTable() As DataTable

        ''継承元の処理
        Dim rtnTable As DataTable
        rtnTable = MyBase.CretatePSTable

        ''追加分の処理
        rtnTable.Columns.Add("ExcelRow")                ''Excelの行の位置

        ''戻り値
        Return rtnTable

    End Function

    Protected Overrides Sub SetPSInsertRow(ByVal rowIdx As Integer, _
                                           ByRef insRow As DataRow, _
                                           ByRef cellValue(,) As Object)

        ''継承元の処理
        Call MyBase.SetPSInsertRow(rowIdx, insRow, cellValue)

        ''追加分の処理
        insRow.Item("ExcelRow") = rowIdx.ToString.PadLeft(10, "0")

    End Sub


    Protected Overrides Function isCellLayoutChang(ByVal sheetNM As String, _
                                                   ByRef layoutIdx As Integer, _
                                                   ByVal Idx As Integer,
                                                   ByVal IdxD As Integer,
                                                   ByRef rows() As DataRow,
                                                   ByRef SheetLayout As LayoutInfo) As Boolean
        ''初期化
        isCellLayoutChang = False
        layoutIdx = 0

        Select Case sheetNM
            Case "サマリ"
                ''最初の出力行は、全て黄色
                If Idx = 0 Then
                    isCellLayoutChang = True
                    layoutIdx = 0
                End If
        End Select


    End Function
#End Region

#Region "パブリックメソッド"

    ''' <summary>
    ''' 別紙作成ボタンの処理
    ''' </summary>
    ''' <param name="PSPath"></param>
    ''' <param name="strMsg"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function OutAttachedSheet(ByVal PSPath As String, ByRef strMsg As String) As Boolean

        Dim xlApp As Excel.Application
        Dim xlAttachedBook As Excel.Workbook
        Dim createTime As DateTime
        createTime = Now

        OutAttachedSheet = False

        Try

            ''Excelファイルのﾃﾞｰﾀ取得
            xlApp = Me.CreateApp
            Dim PSTable As DataTable
            Dim DetailTable As DataTable
            PSTable = Me.GetXlsPSData(xlApp, PSPath)
            DetailTable = Me.GetXlsDetailData(xlApp, PSPath)
            Call DelSLineDetailTBL(DetailTable)

            ''               以下、各シートの出力ﾃﾞｰﾀを取得
            ''----------------------------------------------------------------
            ''出力対象のﾃﾞｰﾀをｼｰﾄ毎に保持
            Dim TBL_SW As DataTable
            Dim TBL_PA As DataTable
            Dim TBL_VLS As DataTable
            Dim TBL_Title(1) As DataTable           ''(0):使用ファイルまでの情報   (1):作成ファイルの一覧情報
            ''SW
            TBL_SW = CreateTableSW(PSTable, DetailTable)

            ''PA
            TBL_PA = CreateTablePA(PSTable)

            ''VLS
            TBL_VLS = CreateTableVLS(PSTable)

            ''出力対象の購買番号を取得
            Dim buyNoList As ArrayList
            buyNoList = GetBuyList(TBL_SW, _
                                   TBL_PA, _
                                   TBL_VLS)

            ''出力するファイル名を取得
            Dim outAttachedFileNM As ArrayList
            outAttachedFileNM = Me.outAttachecFileList(createTime, _
                                                       buyNoList, _
                                                       CommonVariable.CPNO, _
                                                       CommonVariable.CONTRACTNO)
            ''Title
            TBL_Title = CreateTableTitle(buyNoList, _
                                         outAttachedFileNM, _
                                         PSPath, _
                                         TBL_SW, _
                                         TBL_PA, _
                                         TBL_VLS)

            ''出力対象ﾃﾞｰﾀが1件も存在しない場合、ｴﾗｰとする
            If buyNoList.Count = 0 Then
                strMsg = FileReader.GetMessage("MSG_0340")
                Exit Function
            End If

            ''         以下、購買番号毎にﾌｧｲﾙを作成して、ｼｰﾄにﾃﾞｰﾀを書き込む
            ''----------------------------------------------------------------
            Dim msg As String
            Dim idx As Integer
            For idx = 0 To buyNoList.Count - 1

                ''別紙BのBook作成
                Dim ofm As New OioFileManage
                Dim bookPath As String
                Call CopyTmpAttachedBook(createTime, outAttachedFileNM(idx), CommonVariable.CPNO, CommonVariable.CONTRACTNO)
                bookPath = ofm.GetLocalOutputCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO) & _
                           "契約書_[yyyymmddhhmm]".Replace("[yyyymmddhhmm]", createTime.ToString("yyyyMMddHHmm")) & "\" & _
                            outAttachedFileNM(idx)
                xlAttachedBook = Me.OpenWorkBook(xlApp, bookPath)

                ''SWシート
                Call CreateSheetSW(buyNoList(idx), xlAttachedBook, TBL_SW)

                ''PA
                Call CreateSheetPA(buyNoList(idx), xlAttachedBook, TBL_PA)

                ''VLS
                Call CreateSheetVLS(buyNoList(idx), xlAttachedBook, TBL_VLS)

                ''Title
                Call CreateSheetTitle(buyNoList(idx), xlAttachedBook, TBL_Title)

                ''BookのSave/Close
                Me.SaveWorkBook(xlApp, xlAttachedBook)
                Me.CloseWorkBook(xlApp, xlAttachedBook)
            Next
            OutAttachedSheet = True

        Catch ex As Exception
            strMsg = ex.Message.ToString & "(OutAttachedSheet)"

        Finally
            Me.CloseWorkBook(xlApp, xlAttachedBook)
            Me.QuitApp(xlApp)
            GC.Collect()

        End Try

    End Function

#End Region

#Region "プライベートメソッド"

#Region "共通の処理"

    ''' <summary>
    ''' 概  要：DataTable作成
    ''' 説  明：
    ''' </summary>
    ''' <param name="strIdx"></param>
    ''' <param name="endIdx"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CreateDataTable(ByVal strIdx As Integer, _
                                     ByVal endIdx As Integer) As DataTable

        ''初期化
        Dim rtnTable As New DataTable
        CreateDataTable = rtnTable

        ''Columnを追加
        For idx As Integer = strIdx To endIdx
            Call rtnTable.Columns.Add("CellNM" & idx, Type.GetType("System.String"))
        Next
        Return rtnTable

    End Function


    ''' <summary>
    '''概  要：サマリシートの出力件数を取得
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetOutPutCount(ByVal buyNo As String, _
                                    ByRef TBL_SW As DataTable, _
                                    ByRef TBL_PA As DataTable, _
                                    ByRef TBL_VLS As DataTable) As AttachedOutCount

        ''初期化
        Dim rtnValue As AttachedOutCount
        GetOutPutCount = rtnValue

        ''                  以下、SWの処理
        ''------------------------------------------------------
        ''SW  出力件数
        Dim SQL_GetSW As New StringBuilder
        SQL_GetSW.Append("CellNM" & SW_Column.ControlNo)
        SQL_GetSW.Append(CommonConstant.SQL_STR_EQUAL)
        SQL_GetSW.Append(StringEdit.EncloseSingleQuotation(buyNo))
        rtnValue.SWCount = TBL_SW.Select(SQL_GetSW.ToString).Length

        ''SW  確認件数
        SQL_GetSW.Length = 0
        SQL_GetSW.Append("CellNM" & SW_Column.ControlNo)
        SQL_GetSW.Append(CommonConstant.SQL_STR_EQUAL)
        SQL_GetSW.Append(StringEdit.EncloseSingleQuotation(buyNo))
        SQL_GetSW.Append(CommonConstant.SQL_STR_AND)
        SQL_GetSW.Append("CellNM" & SW_Column.Confirmation)
        SQL_GetSW.Append(CommonConstant.SQL_STR_NOT_EQUAL)
        SQL_GetSW.Append(StringEdit.EncloseSingleQuotation(""))
        rtnValue.SWInfoCount = TBL_SW.Select(SQL_GetSW.ToString).Length


        ''                  以下、PAの処理
        ''------------------------------------------------------
        ''PA  出力件数
        Dim SQL_GetPA As New StringBuilder
        SQL_GetPA.Length = 0
        SQL_GetPA.Append("CellNM" & PA_Column.ControlNo)
        SQL_GetPA.Append(CommonConstant.SQL_STR_EQUAL)
        SQL_GetPA.Append(StringEdit.EncloseSingleQuotation(buyNo))
        rtnValue.PACount = TBL_PA.Select(SQL_GetPA.ToString).Length

        ''PA  確認件数
        SQL_GetPA.Length = 0
        SQL_GetPA.Append("CellNM" & PA_Column.ControlNo)
        SQL_GetPA.Append(CommonConstant.SQL_STR_EQUAL)
        SQL_GetPA.Append(StringEdit.EncloseSingleQuotation(buyNo))
        SQL_GetPA.Append(CommonConstant.SQL_STR_AND)
        SQL_GetPA.Append("CellNM" & PA_Column.Confirmation)
        SQL_GetPA.Append(CommonConstant.SQL_STR_NOT_EQUAL)
        SQL_GetPA.Append(StringEdit.EncloseSingleQuotation(""))
        rtnValue.PAInfoCount = TBL_PA.Select(SQL_GetPA.ToString).Length


        ''                  以下、VLSの処理
        ''------------------------------------------------------
        ''VLS  出力件数
        Dim SQL_GetVLS As New StringBuilder
        SQL_GetVLS.Length = 0
        SQL_GetVLS.Append("CellNM" & VLS_Column.ControlNo)
        SQL_GetVLS.Append(CommonConstant.SQL_STR_EQUAL)
        SQL_GetVLS.Append(StringEdit.EncloseSingleQuotation(buyNo))
        rtnValue.VLSCount = TBL_VLS.Select(SQL_GetVLS.ToString).Length

        ''VLS  確認事項        
        SQL_GetVLS.Length = 0
        SQL_GetVLS.Append("CellNM" & VLS_Column.ControlNo)
        SQL_GetVLS.Append(CommonConstant.SQL_STR_EQUAL)
        SQL_GetVLS.Append(StringEdit.EncloseSingleQuotation(buyNo))
        SQL_GetVLS.Append(CommonConstant.SQL_STR_AND)
        SQL_GetVLS.Append("CellNM" & VLS_Column.Confirmation)
        SQL_GetVLS.Append(CommonConstant.SQL_STR_NOT_EQUAL)
        SQL_GetVLS.Append(StringEdit.EncloseSingleQuotation(""))
        rtnValue.VLSInfoCount = TBL_VLS.Select(SQL_GetVLS.ToString).Length

        ''戻り値
        Return rtnValue

    End Function


    ''' <summary>
    '''概  要：購買番号のリストを作成する。
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetBuyList(ByRef TBL_SW As DataTable, _
                                ByRef TBL_PA As DataTable, _
                                ByRef TBL_VLS As DataTable) As ArrayList

        ''初期化
        Dim rtnValue As New ArrayList

        ''各テーブルから重複しない購買情報を取得
        Dim tmpRow As DataRow

        ''SW
        For Each tmpRow In TBL_SW.Rows
            If rtnValue.IndexOf(tmpRow.Item("CellNM" & SW_Column.ControlNo)) = -1 Then
                Call rtnValue.Add(tmpRow.Item("CellNM" & SW_Column.ControlNo))
            End If
        Next

        ''PA
        For Each tmpRow In TBL_PA.Rows
            If rtnValue.IndexOf(tmpRow.Item("CellNM" & PA_Column.ControlNo)) = -1 Then
                Call rtnValue.Add(tmpRow.Item("CellNM" & PA_Column.ControlNo))
            End If
        Next

        ''VLS
        For Each tmpRow In TBL_VLS.Rows
            If rtnValue.IndexOf(tmpRow.Item("CellNM" & VLS_Column.ControlNo)) = -1 Then
                Call rtnValue.Add(ExcelWrite.changeDBNullToString(tmpRow.Item("CellNM" & VLS_Column.ControlNo)))
            End If
        Next

        ''昇順でソート
        Call rtnValue.Sort()

        Return rtnValue

    End Function

    ''' <summary>
    '''概  要：出力対象の別紙ファイルの名前を取得
    '''説  明：
    ''' </summary>
    ''' <param name="createTime"></param>
    ''' <param name="buyNoList"></param>
    ''' <param name="CPNO"></param>
    ''' <param name="Contract"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function outAttachecFileList(ByVal createTime As DateTime, _
                                         ByRef buyNoList As ArrayList, _
                                         ByVal CPNO As String, _
                                         ByVal Contract As Integer) As ArrayList

        ''初期化
        Dim rtnValue As New ArrayList
        outAttachecFileList = rtnValue

        ''購買番号から契約書別紙ファイル名を取得する。
        Dim ofm As New OioFileManage
        Dim buyNo As String
        For Each buyNo In buyNoList

            If buyNo.Trim = "" Then
                ''購買番号Nullなら、「番号NULL」の文言セット
                rtnValue.Add(ofm.GetAttachedFileNM(createTime, "購買番号 = [NULL]", CPNO, Contract))
            Else
                rtnValue.Add(ofm.GetAttachedFileNM(createTime, buyNo, CPNO, Contract))
            End If
        Next
        Return rtnValue

    End Function

    Private Sub CopyTmpAttachedBook(ByVal createTime As DateTime, _
                                    ByVal outAttachedFileNM As String, _
                                    ByVal CPNO As String, _
                                    ByVal contract As Integer)

        Const TmpFileNM As String = "JRI用契約書別紙Template.xlsm"
        Try

            Dim ofm As New OioFileManage

            ''出力先のフォルダ作成
            Dim outFolder As String
            outFolder = ofm.GetLocalOutputCPNOFolder(CPNO, contract) & _
                        "契約書_[yyyymmddhhmm]".Replace("[yyyymmddhhmm]", createTime.ToString("yyyyMMddHHmm"))
            Call System.IO.Directory.CreateDirectory(outFolder)

            ''Copy対象/出力先のPathを取得
            Dim copyAttachedPath As String
            Dim outAttachedPath As String
            copyAttachedPath = FileManager.GetLocalFolderPath(CommonConstant.FOLDERNAME_TEMPLATE) & _
                               TmpFileNM
            outAttachedPath = outFolder & "\" & _
                              outAttachedFileNM

            ''ファイルのCopy
            System.IO.File.Copy(copyAttachedPath, outAttachedPath)

        Catch ex As Exception
            Throw ex

        End Try

    End Sub

    ''' <summary>
    '''概  要：詳細データから、S行を削除する
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub DelSLineDetailTBL(ByRef DetailTable As DataTable)

        Dim delRows() As DataRow
        Dim filter As New StringBuilder
        Call filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.IDENTITY_FLAG)
        Call filter.Append(CommonConstant.SQL_STR_EQUAL)
        Call filter.Append(StringEdit.EncloseSingleQuotation("S"))
        delRows = DetailTable.Select(filter.ToString)

        Dim delRow As DataRow
        For Each delRow In delRows
            Call DetailTable.Rows.RemoveAt(DetailTable.Rows.IndexOf(delRow))
        Next

    End Sub

#End Region

#Region "サマリシートの処理"

    ''' <summary>
    ''' 概  要：サマリシート出力用のﾃｰﾌﾞﾙを作成する。
    ''' 説  明：※配列で、2つのTableを作成する。
    ''' </summary>
    ''' <param name="buyNoList"></param>
    ''' <param name="outAttachecFileList"></param>
    ''' <param name="PSPath"></param>
    ''' <param name="TBL_SW"></param>
    ''' <param name="TBL_PA"></param>
    ''' <param name="TBL_VLS"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CreateTableTitle(ByRef buyNoList As ArrayList, _
                                      ByRef outAttachecFileList As ArrayList, _
                                      ByVal PSPath As String, _
                                      ByRef TBL_SW As DataTable, _
                                      ByRef TBL_PA As DataTable, _
                                      ByRef TBL_VLS As DataTable) As DataTable()

        ''初期化
        Dim rtnValue(1) As DataTable
        rtnValue(0) = CreateDataTable(TitleBase_Column.ContractNo, TitleBase_Column.CreateDay)
        rtnValue(1) = CreateDataTable(TitleFile_Column.OutFileName, TitleFile_Column.DspBuyNo)

        Dim tmpDspBuyNo As String
        Dim insBaseRow As DataRow
        Dim insFileRow As DataRow
        For Idx As Integer = 0 To buyNoList.Count - 1

            ''                      以下、基本データセット
            ''---------------------------------------------------------------            
            insBaseRow = rtnValue(0).NewRow

            ''購買番号
            insBaseRow.Item("CellNM" & TitleBase_Column.BuyNo) = buyNoList(Idx)

            ''表示用_購買番号
            tmpDspBuyNo = buyNoList(Idx)
            If tmpDspBuyNo = "" Then
                tmpDspBuyNo = "購買番号NULL"
            End If
            insBaseRow.Item("CellNM" & TitleBase_Column.DspBuyNo) = tmpDspBuyNo

            ''作成日時
            insBaseRow.Item("CellNM" & TitleBase_Column.CreateDay) = Now.ToString("yyyy/MM/dd")

            ''契約順番
            insBaseRow.Item("CellNM" & TitleBase_Column.ContractNo) = CommonVariable.CONTRACTNO.ToString.PadLeft(3, "0")

            ''契約順番名
            insBaseRow.Item("CellNM" & TitleBase_Column.ContractName) = CommonVariable.CONTRACTNONAME

            ''管理番号
            insBaseRow.Item("CellNM" & TitleBase_Column.ControlName) = buyNoList(Idx)

            ''Paymentﾌｧｲﾙﾊﾟｽ
            insBaseRow.Item("CellNM" & TitleBase_Column.PaymentPath) = System.IO.Path.GetFileName(PSPath)

            ''Paymentﾌｧｲﾙ日付
            insBaseRow.Item("CellNM" & TitleBase_Column.PaymentData) = System.IO.File.GetLastWriteTime(PSPath).ToString("yyyy/MM/dd HH:mm:ss")

            ''行追加
            Call rtnValue(0).Rows.Add(insBaseRow)

            ''                      以下、作成ファイルセット
            ''---------------------------------------------------------------            
            insFileRow = rtnValue(1).NewRow

            Dim outCountInfo As AttachedOutCount
            outCountInfo = GetOutPutCount(buyNoList(Idx), _
                                          TBL_SW, _
                                          TBL_PA, _
                                          TBL_VLS)
            ''購買番号
            insFileRow.Item("CellNM" & TitleFile_Column.BuyNo) = buyNoList(Idx)

            ''表示用_購買番号
            insFileRow.Item("CellNM" & TitleFile_Column.DspBuyNo) = tmpDspBuyNo

            ''ファイル名
            insFileRow.Item("CellNM" & TitleFile_Column.OutFileName) = outAttachecFileList(Idx)

            ''SW  出力件数
            insFileRow.Item("CellNM" & TitleFile_Column.SWOutCount) = outCountInfo.SWCount

            ''SW  確認事項
            insFileRow.Item("CellNM" & TitleFile_Column.SWInfoCount) = outCountInfo.SWInfoCount

            ''PA  出力件数
            insFileRow.Item("CellNM" & TitleFile_Column.PAOutCount) = outCountInfo.PACount

            ''PA  出力件数
            insFileRow.Item("CellNM" & TitleFile_Column.PAInfoCount) = outCountInfo.PAInfoCount

            ''VLS 出力件数
            insFileRow.Item("CellNM" & TitleFile_Column.VLSOutCount) = outCountInfo.VLSCount

            ''VLS 出力件数
            insFileRow.Item("CellNM" & TitleFile_Column.VLSInfoCount) = outCountInfo.VLSInfoCount

            ''行追加
            Call rtnValue(1).Rows.Add(insFileRow)
        Next
        Return rtnValue

    End Function

    ''' <summary>
    ''' 概  要：サマリシートを作成する。
    ''' 説  明：
    ''' </summary>
    ''' <param name="buyNo"></param>
    ''' <param name="xlAttachedBook"></param>
    ''' <param name="TBL_Title"></param>
    ''' <remarks></remarks>
    Private Sub CreateSheetTitle(ByVal buyNo As String,
                                 ByRef xlAttachedBook As Excel.Workbook,
                                 ByRef TBL_Title() As DataTable)

        Dim xlTitleSheet As Excel.Worksheet
        Try
            ''出力対象ﾃﾞｰﾀを取得
            Dim rows(1) As Array
            Dim setBaseRows() As DataRow
            Dim setTitleRows_1() As DataRow
            Dim setTitleRows_2() As DataRow
            Dim setTitleRows_Sum() As DataRow
            Dim SQL_OutTiTleBaseDate As New StringBuilder
            Dim SQL_OutTiTleFileDate As New StringBuilder

            ''基本データの取得
            SQL_OutTiTleBaseDate.Append("CellNM" & TitleBase_Column.BuyNo)
            SQL_OutTiTleBaseDate.Append(CommonConstant.SQL_STR_EQUAL)
            SQL_OutTiTleBaseDate.Append(StringEdit.EncloseSingleQuotation(buyNo))
            setBaseRows = TBL_Title(0).Select(SQL_OutTiTleBaseDate.ToString)
            If setBaseRows.Length = 0 Then
                Exit Sub
            End If
            rows(0) = setBaseRows

            ''ﾌｧｲﾙ一覧ﾃﾞｰﾀの取得
            ''先頭行のセット
            SQL_OutTiTleFileDate.Append("CellNM" & TitleFile_Column.BuyNo)
            SQL_OutTiTleFileDate.Append(CommonConstant.SQL_STR_EQUAL)
            SQL_OutTiTleFileDate.Append(StringEdit.EncloseSingleQuotation(buyNo))
            setTitleRows_1 = TBL_Title(1).Select(SQL_OutTiTleFileDate.ToString)
            If setTitleRows_1.Length = 0 Then
                Exit Sub
            End If

            ''※明細行のセット
            SQL_OutTiTleFileDate.Length = 0
            SQL_OutTiTleFileDate.Append("CellNM" & TitleFile_Column.BuyNo)
            SQL_OutTiTleFileDate.Append(CommonConstant.SQL_STR_NOT_EQUAL)
            SQL_OutTiTleFileDate.Append(StringEdit.EncloseSingleQuotation(buyNo))
            setTitleRows_2 = TBL_Title(1).Select(SQL_OutTiTleFileDate.ToString)

            ''先頭行と明細行のﾏｰｼﾞ
            If UBound(setTitleRows_2) = -1 Then
                ReDim setTitleRows_Sum(UBound(setTitleRows_1))
            Else
                ReDim setTitleRows_Sum(UBound(setTitleRows_1) + UBound(setTitleRows_2) + 1)
            End If
            setTitleRows_Sum(0) = setTitleRows_1(0)
            For Idx As Integer = 0 To UBound(setTitleRows_2)
                setTitleRows_Sum(Idx + 1) = setTitleRows_2(Idx)
            Next
            rows(1) = setTitleRows_Sum

            ''ｼｰﾄをセット
            xlTitleSheet = Me.SetWorkSheet(xlAttachedBook, "サマリ")

            ''LayOut情報を取得する。
            Dim SheetTitleLayout As LayoutInfo
            SheetTitleLayout = GetLayoutInfoTitle()

            ''Sheetに情報を書き込む
            Call Me.OutRowDataToSheet(xlTitleSheet, rows, SheetTitleLayout)

            ''Sheetを閉じる
            Me.CloseWorkSheet(xlTitleSheet)

        Catch ex As Exception
            Throw ex

        Finally
            Me.CloseWorkSheet(xlTitleSheet)
            GC.Collect()

        End Try

    End Sub


    ''' <summary>
    '''概  要：サマリシートのレイアウトシート情報を出力
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetLayoutInfoTitle() As LayoutInfo

        ''初期化
        Dim rtnValue As LayoutInfo
        GetLayoutInfoTitle = rtnValue
        Dim OutBlockLayout(1) As OutBlockLayoutInfo
        OutBlockLayout = Me.GetDefaultBlockLayout(1)


        ''                      以下、基本情報のセット
        ''-----------------------------------------------------------------------
        ''Template行設定
        OutBlockLayout(0).isTmpRow = False

        ''Item値と、セットするExcelの位置
        Dim SetRef(5, 1) As String

        ''作成日
        SetRef(0, 0) = "N2"
        SetRef(0, 1) = "CellNM" & TitleBase_Column.CreateDay

        ''契約順番
        SetRef(1, 0) = "D4"
        SetRef(1, 1) = "CellNM" & TitleBase_Column.ContractNo

        ''契約順番名
        SetRef(2, 0) = "D5"
        SetRef(2, 1) = "CellNM" & TitleBase_Column.ContractName

        ''管理番号
        SetRef(3, 0) = "D6"
        SetRef(3, 1) = "CellNM" & TitleBase_Column.DspBuyNo

        ''Payment ファイル名          
        SetRef(4, 0) = "D10"
        SetRef(4, 1) = "CellNM" & TitleBase_Column.PaymentPath

        ''Payment 更新日時
        SetRef(5, 0) = "J10"
        SetRef(5, 1) = "CellNM" & TitleBase_Column.PaymentData

        ''値をセットする。
        OutBlockLayout(0).IsFreeFormat = True
        OutBlockLayout(0).IsChgRefColumn = True
        OutBlockLayout(0).SetChgRefColumn = SetRef

        ''                      以下、作成ファイル
        ''-----------------------------------------------------------------------
        ''Template行設定
        OutBlockLayout(1).isTmpRow = True
        OutBlockLayout(1).TmplateRow = "16"
        OutBlockLayout(1).TmpPasteStrIndex = 16

        ''Item値と、セットするExcelの位置
        OutBlockLayout(1).PasteArea = "B@Str:O@End"
        OutBlockLayout(1).PasteStrClomunsIdx = ExcelWrite.ChgExcelRowCharToNumber("B")
        OutBlockLayout(1).PasteEndClomunsIdx = ExcelWrite.ChgExcelRowCharToNumber("O")
        OutBlockLayout(1).PasteStrIndex = 16
        OutBlockLayout(1).IsChgRefColumn = True

        ''管理番号
        Dim SetFileRef(7, 1) As String
        SetFileRef(0, 0) = "B"
        SetFileRef(0, 1) = "CellNM" & TitleFile_Column.DspBuyNo

        ''ファイル名
        SetFileRef(1, 0) = "D"
        SetFileRef(1, 1) = "CellNM" & TitleFile_Column.OutFileName

        ''SW 出力件数
        SetFileRef(2, 0) = "J"
        SetFileRef(2, 1) = "CellNM" & TitleFile_Column.SWOutCount

        ''SW 確認事項
        SetFileRef(3, 0) = "K"
        SetFileRef(3, 1) = "CellNM" & TitleFile_Column.SWInfoCount

        ''PA 出力件数
        SetFileRef(4, 0) = "L"
        SetFileRef(4, 1) = "CellNM" & TitleFile_Column.PAOutCount

        ''PA 確認事項
        SetFileRef(5, 0) = "M"
        SetFileRef(5, 1) = "CellNM" & TitleFile_Column.PAInfoCount

        ''VLS 出力件数
        SetFileRef(6, 0) = "N"
        SetFileRef(6, 1) = "CellNM" & TitleFile_Column.VLSOutCount

        ''VLS 出力件数
        SetFileRef(7, 0) = "O"
        SetFileRef(7, 1) = "CellNM" & TitleFile_Column.VLSInfoCount

        ''値をセットする。
        OutBlockLayout(1).IsChgRefColumn = True
        OutBlockLayout(1).SetChgRefColumn = SetFileRef

        ''セルの書式
        OutBlockLayout(1).IsChgCellLayOut = False

        ''戻り値
        rtnValue.OutBlockLayout = OutBlockLayout
        Return rtnValue

    End Function

#End Region

#Region "VLSの処理"

    ''' <summary>
    '''概  要：VLS:出力対象ﾃﾞｰﾀの抽出
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateTableVLS(ByRef PSTable As DataTable) As DataTable

        ''初期化
        Dim rtnTable As New DataTable
        rtnTable = CreateDataTable(VLS_Column.ControlNo, VLS_Column.ExcelRow)
        CreateTableVLS = rtnTable

        Try
            ''PSテーブルから出力対象ﾃﾞｰﾀを取得
            Dim SQL_VLSOutput As String
            SQL_VLSOutput = GetSQL_VLSOutput()

            ''PSデータから、出力対象ﾃﾞｰﾀに変換する。
            Dim insRow As DataRow
            For Each tmpRow As DataRow In PSTable.Select(SQL_VLSOutput)
                insRow = rtnTable.NewRow
                Call SetVlsRow(insRow, tmpRow)
                Call rtnTable.Rows.Add(insRow)
            Next
            Return rtnTable

        Catch ex As Exception
            Throw ex

        End Try

    End Function

    ''' <summary>
    '''概  要：VLS:出力対象ﾃﾞｰﾀのSQL
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSQL_VLSOutput() As String

        ''(パターンCD = 12) Or (パターンCD = 25 And パターン名 = VLS 削除ﾃﾞｰﾀ)
        Dim rtnValue As New StringBuilder
        rtnValue.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        rtnValue.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        rtnValue.Append("CellNM" & ExcelPaymentLineColumn.PATTERN_CD)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNCD_TYPE_VLS))
        rtnValue.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
        rtnValue.Append(CommonConstant.SQL_STR_OR)
        rtnValue.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        rtnValue.Append("CellNM" & ExcelPaymentLineColumn.PATTERN_CD)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNCD_TYPE_DIRECTINPUT))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append("CellNM" & ExcelPaymentLineColumn.PATTERN)
        rtnValue.Append(CommonConstant.SQL_STR_LIKE)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_VLS & " 削除ﾃﾞｰﾀ*"))
        rtnValue.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
        rtnValue.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append("CellNM" & ExcelPaymentLineColumn.LOCK_FLAG)
        rtnValue.Append(CommonConstant.SQL_STR_NOT_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation("C"))

        Return rtnValue.ToString

    End Function


    ''' <summary>
    '''概  要：VLSの出力情報を作成
    '''説  明：※1行分のﾃﾞｰﾀ作成
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetVlsRow(ByRef insRow As DataRow, _
                          ByRef tmpRow As DataRow)

        ''                       以下、計算処理
        ''--------------------------------------------------------------------------
        Dim ControlNo As String
        Dim DspControlNo As String
        Dim ControlName As String
        Dim InstYM As String


        ''管理番号  ※規定桁数なければ、有るだけセット
        If ExcelWrite.changeDBNullToString(tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM15)).Length >= 13 Then
            ControlNo = ExcelWrite.changeDBNullToString(tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM15).SubString(0, 13))
        Else
            ControlNo = ExcelWrite.changeDBNullToString(tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM15))
        End If

        ''表示用_管理番号  ※空白なら、購買番号NULLをセット
        If ControlNo = "" Then
            DspControlNo = "購買番号NULL"
        Else
            DspControlNo = ControlNo
        End If

        ''管理名称
        If ExcelWrite.changeDBNullToString(tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM15)).Length >= 14 Then
            ControlName = tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM15).SubString(13, tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM15).Length - 13)
        Else
            ControlName = ""
        End If

        ''導入年月
        InstYM = ExcelWrite.changeDBNullToString(tmpRow.Item("CellNM" & ExcelPaymentLineColumn.INST_DATE))
        If IsDate(InstYM) = True Then
            ''ﾃﾞｰﾀが日付なら、処理なし
        Else
            InstYM = ""
        End If

        ''                       以下、各値をセット
        ''--------------------------------------------------------------------------
        ''管理番号  
        insRow.Item("CellNM" & VLS_Column.ControlNo) = ControlNo

        ''表示用_管理番号  
        insRow.Item("CellNM" & VLS_Column.DspControlNo) = DspControlNo

        ''管理名称
        insRow.Item("CellNM" & VLS_Column.ControlName) = ControlName

        ''Product
        insRow.Item("CellNM" & VLS_Column.Product) = tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM01)

        ''Description
        insRow.Item("CellNM" & VLS_Column.Description) = tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM03)

        ''QTY
        insRow.Item("CellNM" & VLS_Column.QTY) = tmpRow.Item("CellNM" & ExcelPaymentLineColumn.QTY)

        ''提供期間_開始日
        insRow.Item("CellNM" & VLS_Column.OfferStr) = "添付他社製プログラムの特則記載のとおり"

        ''提供期間_終了日
        insRow.Item("CellNM" & VLS_Column.OfferEnd) = "添付他社製プログラムの特則記載のとおり"

        ''補足
        insRow.Item("CellNM" & VLS_Column.Supplement) = ""

        ''導入月
        insRow.Item("CellNM" & VLS_Column.InstYM) = InstYM

        ''料金期間_開始日
        insRow.Item("CellNM" & VLS_Column.RateStr) = tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM11)

        ''料金期間_終了日
        insRow.Item("CellNM" & VLS_Column.RateEnd) = ""

        ''確認事項
        insRow.Item("CellNM" & VLS_Column.Confirmation) = GetVlsConfirmation(tmpRow)

        ''LineNo
        insRow.Item("CellNM" & VLS_Column.LineNo) = tmpRow.Item("CellNM" & ExcelPaymentLineColumn.LINE_NO)

        ''Excel計算式
        Const Formula_ListpriceSum As String = "=RC[-1]*RC[-13]"
        Const Formula_DPerPriceSum As String = "=RC[-1]*RC[-15]"

        ''取り込み元ﾃﾞｰﾀ
        insRow.Item("CellNM" & VLS_Column.Item10) = tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM10)

        ''仮契約NO
        insRow.Item("CellNM" & VLS_Column.Item14) = tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM14)

        ''Listprice
        insRow.Item("CellNM" & VLS_Column.Listprice) = tmpRow.Item("CellNM" & ExcelPaymentLineColumn.LIST_PRICE_REFLESH)

        ''Listprice合計
        insRow.Item("CellNM" & VLS_Column.ListpriceSum) = Formula_ListpriceSum

        ''D%適用後
        insRow.Item("CellNM" & VLS_Column.DPerPrice) = tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PRICE_UNIT_IOC)

        ''D%適用後合計
        insRow.Item("CellNM" & VLS_Column.DPerPriceSum) = Formula_DPerPriceSum

        ''Excel行位置
        insRow.Item("CellNM" & VLS_Column.ExcelRow) = tmpRow.Item("ExcelRow")

    End Sub


    ''' <summary>
    '''概  要：VLSのｴﾗｰ文言ｾｯﾄ
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetVlsConfirmation(ByRef tmpRow As DataRow) As String

        ''初期化 
        Dim rtnValue As String = ""
        GetVlsConfirmation = rtnValue

        ''ｴﾗｰﾒｯｾｰｼﾞ
        Const ErrMsg001 As String = "Productが空白です。"
        Const ErrMsg002 As String = "Descriptionが空白です。"
        Const ErrMsg003 As String = "QTYがありません。"
        Const ErrMsg004 As String = "ｻｰﾋﾞｽ開始が空白です。"

        Dim ErrList As New ArrayList

        ''                      以下、ｴﾗｰの判定
        ''-------------------------------------------------------------
        ''Productが空白です。
        If ExcelWrite.changeDBNullToString(tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01)) = "" Then
            Call ErrList.Add(ErrMsg001)
        End If

        ''Descriptionが空白です。
        If ExcelWrite.changeDBNullToString(tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03)) = "" Then
            Call ErrList.Add(ErrMsg002)
        End If

        ''QTYがありません。
        If ExcelWrite.changeDBNullToString(tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.QTY)) = "" Or _
           ExcelWrite.changeDBNullToString(tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.QTY)) = "0" Then
            Call ErrList.Add(ErrMsg003)
        End If

        ''ｻｰﾋﾞｽ開始が空白です。
        If ExcelWrite.changeDBNullToString(tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11)) = "" Then
            Call ErrList.Add(ErrMsg004)
        End If

        ''                  以下、ｴﾗｰ情報を改行で区切って出力
        ''-------------------------------------------------------------------
        If ErrList.Count = 0 Then
            Return ""
        Else
            ''最後の文字列後は改行不要
            For i As Integer = 0 To ErrList.Count - 1
                If i <> ErrList.Count - 1 Then
                    rtnValue = rtnValue & ErrList(i) & vbCrLf
                Else
                    rtnValue = rtnValue & ErrList(i)
                End If
            Next
            Return rtnValue
        End If

    End Function

    ''' <summary>
    '''概  要：VLSシートに値を書き込む
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub CreateSheetVLS(ByVal buyNo As String, _
                               ByRef xlAttachedBook As Excel.Workbook, _
                               ByRef TBL_VLS As DataTable)

        Dim xlVlsSheet As Excel.Worksheet
        Try
            ''出力対象ﾃﾞｰﾀを取得
            Dim rows(0) As Array
            Dim delRows() As DataRow
            Dim setRows() As DataRow
            delRows = GetDelVLSDate(TBL_VLS, buyNo)
            setRows = GetAddVLSDate(TBL_VLS, buyNo)

            ''LayOut情報を取得する。
            Dim SheetVLSLayout As LayoutInfo
            SheetVLSLayout = GetLayoutInfoVLS()

            ''                  ▼以下、ｼｰﾄの書込
            ''----------------------------------------------------
            ''[VLS削除]ｼｰﾄ
            If delRows.Length <> 0 Then

                ''ｼｰﾄをセット
                xlVlsSheet = CopyWorkSheet(xlAttachedBook, Me.SheetNM_Del_VLS)

                ''Sheetに情報を書き込む
                rows(0) = delRows
                Call Me.OutRowDataToSheet(xlVlsSheet, rows, SheetVLSLayout)

            End If

            ''[VLS追加]ｼｰﾄ
            If setRows.Length <> 0 Then

                ''ｼｰﾄをセット
                xlVlsSheet = CopyWorkSheet(xlAttachedBook, Me.SheetNM_ADD_VLS)

                ''Sheetに情報を書き込む
                rows(0) = setRows
                Call Me.OutRowDataToSheet(xlVlsSheet, rows, SheetVLSLayout)

            End If

            ''Sheetを閉じる
            Me.CloseWorkSheet(xlVlsSheet)

        Catch ex As Exception
            Throw ex

        Finally
            Me.CloseWorkSheet(xlVlsSheet)
            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    '''概  要：「VLS 削除」出力用のﾃﾞｰﾀを取得
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetDelVLSDate(ByRef TBL_VLS As DataTable, _
                                   ByVal buyNo As String) As DataRow()

        ''初期化
        Dim rtnValue() As DataRow
        GetDelVLSDate = rtnValue

        ''SQL実行
        Dim SQL_OutVLSDate As New StringBuilder
        SQL_OutVLSDate.Append("CellNM" & VLS_Column.ControlNo)
        SQL_OutVLSDate.Append(CommonConstant.SQL_STR_EQUAL)
        SQL_OutVLSDate.Append(StringEdit.EncloseSingleQuotation(buyNo))
        SQL_OutVLSDate.Append(CommonConstant.SQL_STR_AND)
        SQL_OutVLSDate.Append("CellNM" & VLS_Column.QTY)
        SQL_OutVLSDate.Append(CommonConstant.SQL_STR_LIKE)
        SQL_OutVLSDate.Append(StringEdit.EncloseSingleQuotation("-*"))
        rtnValue = TBL_VLS.Select(SQL_OutVLSDate.ToString, "CellNM" & VLS_Column.ExcelRow)

        Return rtnValue

    End Function


    ''' <summary>
    '''概  要：「VLS 追加」出力用のﾃﾞｰﾀを取得
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetAddVLSDate(ByRef TBL_VLS As DataTable, _
                                   ByVal buyNo As String) As DataRow()

        ''初期化
        Dim rtnValue() As DataRow
        GetAddVLSDate = rtnValue

        ''SQL実行
        Dim SQL_OutVLSDate As New StringBuilder
        SQL_OutVLSDate.Append("CellNM" & VLS_Column.ControlNo)
        SQL_OutVLSDate.Append(CommonConstant.SQL_STR_EQUAL)
        SQL_OutVLSDate.Append(StringEdit.EncloseSingleQuotation(buyNo))
        SQL_OutVLSDate.Append(CommonConstant.SQL_STR_AND)
        SQL_OutVLSDate.Append("CellNM" & VLS_Column.QTY)
        SQL_OutVLSDate.Append(CommonConstant.SQL_STR_NOT)
        SQL_OutVLSDate.Append(CommonConstant.SQL_STR_LIKE)
        SQL_OutVLSDate.Append(StringEdit.EncloseSingleQuotation("-*"))
        rtnValue = TBL_VLS.Select(SQL_OutVLSDate.ToString, "CellNM" & VLS_Column.ExcelRow)

        Return rtnValue

    End Function

    ''' <summary>
    '''概  要：VLSシートのレイアウトシート情報を出力
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetLayoutInfoVLS() As LayoutInfo

        ''初期化
        Dim rtnValue As LayoutInfo
        GetLayoutInfoVLS = rtnValue

        ''セットする値
        Dim OutBlockLayout(0) As OutBlockLayoutInfo
        OutBlockLayout = Me.GetDefaultBlockLayout(0)
        OutBlockLayout(0).isTmpRow = True
        OutBlockLayout(0).TmplateRow = "3"
        OutBlockLayout(0).TmpPasteStrIndex = 7
        OutBlockLayout(0).IsChgRefColumn = True
        OutBlockLayout(0).PasteStrIndex = 7

        ''          以下、各項目　⇒ row.Item(名称)の対応づけ
        ''-------------------------------------------------------------
        OutBlockLayout(0).PasteArea = "B@Str:X@End"
        OutBlockLayout(0).PasteStrClomunsIdx = ExcelWrite.ChgExcelRowCharToNumber("B")
        OutBlockLayout(0).PasteEndClomunsIdx = ExcelWrite.ChgExcelRowCharToNumber("X")

        Dim SetRef(18, 1) As String

        ''管理番号  
        SetRef(0, 0) = "B"
        SetRef(0, 1) = "CellNM" & VLS_Column.DspControlNo

        ''管理名称
        SetRef(1, 0) = "F"
        SetRef(1, 1) = "CellNM" & VLS_Column.ControlName

        ''Product
        SetRef(2, 0) = "G"
        SetRef(2, 1) = "CellNM" & VLS_Column.Product

        ''Description
        SetRef(3, 0) = "H"
        SetRef(3, 1) = "CellNM" & VLS_Column.Description

        ''QTY    
        SetRef(4, 0) = "I"
        SetRef(4, 1) = "CellNM" & VLS_Column.QTY

        ''提供期間_開始日
        SetRef(5, 0) = "J"
        SetRef(5, 1) = "CellNM" & VLS_Column.OfferStr

        ''提供期間_終了日
        SetRef(6, 0) = "K"
        SetRef(6, 1) = "CellNM" & VLS_Column.OfferEnd

        ''補足
        SetRef(7, 0) = "L"
        SetRef(7, 1) = "CellNM" & VLS_Column.Supplement

        ''導入月
        SetRef(8, 0) = "M"
        SetRef(8, 1) = "CellNM" & VLS_Column.InstYM

        ''料金期間_開始日
        SetRef(9, 0) = "N"
        SetRef(9, 1) = "CellNM" & VLS_Column.RateStr

        ''料金期間_終了日
        SetRef(10, 0) = "O"
        SetRef(10, 1) = "CellNM" & VLS_Column.RateEnd

        ''確認事項
        SetRef(11, 0) = "Q"
        SetRef(11, 1) = "CellNM" & VLS_Column.Confirmation

        ''確認事項
        SetRef(12, 0) = "R"
        SetRef(12, 1) = "CellNM" & VLS_Column.LineNo

        ''取り込み元ﾃﾞｰﾀ
        SetRef(13, 0) = "S"
        SetRef(13, 1) = "CellNM" & VLS_Column.Item10

        ''仮契約NO
        SetRef(14, 0) = "T"
        SetRef(14, 1) = "CellNM" & VLS_Column.Item14

        ''Listprice
        SetRef(15, 0) = "U"
        SetRef(15, 1) = "CellNM" & VLS_Column.Listprice

        ''Listprice合計
        SetRef(16, 0) = "V"
        SetRef(16, 1) = "CellNM" & VLS_Column.ListpriceSum

        ''D%適用後
        SetRef(17, 0) = "W"
        SetRef(17, 1) = "CellNM" & VLS_Column.DPerPrice

        ''D%適用後合計
        SetRef(18, 0) = "X"
        SetRef(18, 1) = "CellNM" & VLS_Column.DPerPriceSum


        OutBlockLayout(0).SetChgRefColumn = SetRef

        rtnValue.OutBlockLayout = OutBlockLayout

        ''戻り値
        Return rtnValue

    End Function

#End Region

#Region "PAの処理"

    ''' <summary>
    '''概  要：PA:出力対象ﾃﾞｰﾀの抽出
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateTablePA(ByRef PSTable As DataTable) As DataTable

        ''初期化
        Dim rtnTable As New DataTable
        rtnTable = CreateDataTable(PA_Column.ControlNo, PA_Column.ExcelRow)
        CreateTablePA = rtnTable

        Try
            ''PSテーブルから出力対象ﾃﾞｰﾀを取得
            Dim SQL_PAOutput As String
            SQL_PAOutput = GetSQL_PAOutput()

            ''PSデータから、出力対象ﾃﾞｰﾀに変換する。
            Dim insRow As DataRow
            For Each tmpRow As DataRow In PSTable.Select(SQL_PAOutput)
                insRow = rtnTable.NewRow
                Call SetPARow(insRow, tmpRow)
                Call rtnTable.Rows.Add(insRow)
            Next
            Return rtnTable

        Catch ex As Exception
            Throw ex

        End Try

    End Function


    ''' <summary>
    '''概  要：PA:出力対象ﾃﾞｰﾀのSQL
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSQL_PAOutput() As String

        ''(パターンCD = 12) Or (パターンCD = 25 And パターン名 = PA 削除ﾃﾞｰﾀ)
        Dim rtnValue As New StringBuilder
        rtnValue.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        rtnValue.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        rtnValue.Append("CellNM" & ExcelPaymentLineColumn.PATTERN_CD)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNCD_TYPE_PA))
        rtnValue.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
        rtnValue.Append(CommonConstant.SQL_STR_OR)
        rtnValue.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        rtnValue.Append("CellNM" & ExcelPaymentLineColumn.PATTERN_CD)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNCD_TYPE_DIRECTINPUT))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append("CellNM" & ExcelPaymentLineColumn.PATTERN)
        rtnValue.Append(CommonConstant.SQL_STR_LIKE)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_PA & " 削除ﾃﾞｰﾀ*"))
        rtnValue.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
        rtnValue.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append("CellNM" & ExcelPaymentLineColumn.LOCK_FLAG)
        rtnValue.Append(CommonConstant.SQL_STR_NOT_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation("C"))

        Return rtnValue.ToString

    End Function


    ''' <summary>
    '''概  要：PAの出力情報を作成
    '''説  明：※1行分のﾃﾞｰﾀ作成
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetPARow(ByRef insRow As DataRow, _
                         ByRef tmpRow As DataRow)

        ''                       以下、計算処理
        ''--------------------------------------------------------------------------
        Dim ControlNo As String
        Dim DspControlNo As String
        Dim ControlName As String
        Dim Brand As String
        Dim BrandSort As String
        Dim TmpServiceMonth As String
        Dim TmpAnniversary As String

        ''管理番号  ※規定桁数なければ、有るだけセット
        If ExcelWrite.changeDBNullToString(tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM15)).Length >= 13 Then
            ControlNo = ExcelWrite.changeDBNullToString(tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM15).SubString(0, 13))
        Else
            ControlNo = ExcelWrite.changeDBNullToString(tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM15))
        End If

        ''表示用_管理番号  ※空白なら、購買番号NULLをセット
        If ControlNo = "" Then
            DspControlNo = "購買番号NULL"
        Else
            DspControlNo = ControlNo
        End If

        ''管理名称
        If ExcelWrite.changeDBNullToString(tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM15)).Length >= 14 Then
            ControlName = tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM15).SubString(13, tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM15).Length - 13)
        Else
            ControlName = ""
        End If

        ''PAの分類分け
        ''※Brand = 空白の場合、Mediaとする。
        ''※Brand = S&Sで「ｻｰﾋﾞｽ提供月」と「ｱﾆﾊﾞｰｻﾘｰ」が同じなら、(FULL)1年分 / それ以外は（月割り）
        Brand = tmpRow.Item("CellNM" & ExcelPaymentLineColumn.BRAND)
        Select Case Brand.Trim
            Case ""
                Brand = Me.Brand_PA_Media
                BrandSort = Me.PA_Sort_Media

            Case Me.Brand_PA_SS
                If IsDate(tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM11)) = True Then
                    ''アニバーサリーと提供日の月を比較
                    If CStr(CDate(tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM11)).Month) = _
                       tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM05) Then
                        Brand = Me.Brand_PA_SS_Full
                        BrandSort = Me.PA_Sort_SS_Full
                    Else
                        Brand = Me.Brand_PA_SS_Montry
                        BrandSort = Me.PA_Sort_SS_Montry
                    End If
                Else
                    ''提供日が日付に変換できなければ、Fullとする。
                    Brand = Me.Brand_PA_SS_Full
                    BrandSort = Me.PA_Sort_SS_Full
                End If

            Case Me.Brand_PA_Media
                Brand = Me.Brand_PA_Media
                BrandSort = Me.PA_Sort_Media

            Case Me.Brand_PA_License
                Brand = Me.Brand_PA_License
                BrandSort = Me.PA_Sort_License
        End Select

        ''                       以下、各値をセット
        ''--------------------------------------------------------------------------
        ''管理番号  
        insRow.Item("CellNM" & PA_Column.ControlNo) = ControlNo

        ''表示用_管理番号  
        insRow.Item("CellNM" & PA_Column.DspControlNo) = DspControlNo

        ''管理名称
        insRow.Item("CellNM" & PA_Column.ControlName) = ControlName

        ''Product
        insRow.Item("CellNM" & PA_Column.Product) = tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM01)

        ''Description
        insRow.Item("CellNM" & PA_Column.Description) = tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM03)

        ''QTY
        insRow.Item("CellNM" & PA_Column.QTY) = tmpRow.Item("CellNM" & ExcelPaymentLineColumn.QTY)

        ''提供期間_開始日
        insRow.Item("CellNM" & PA_Column.OfferStr) = tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM11)

        ''提供期間_終了日
        insRow.Item("CellNM" & PA_Column.OfferEnd) = GetPAOfferEnd(Brand, tmpRow)

        ''補足
        insRow.Item("CellNM" & PA_Column.Supplement) = ""

        ''PAID
        insRow.Item("CellNM" & PA_Column.PAID) = tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM06)

        ''確認事項
        insRow.Item("CellNM" & PA_Column.Confirmation) = GetPAConfirmation(tmpRow)

        ''LineNo
        insRow.Item("CellNM" & PA_Column.LineNo) = tmpRow.Item("CellNM" & ExcelPaymentLineColumn.LINE_NO)

        ''Excel式
        Const Formula_ListpriceSum As String = "=RC[-1]*RC[-11]"
        Const Formula_DPerPriceSum As String = "=RC[-1]*RC[-13]"

        ''取り込み元ﾃﾞｰﾀ
        insRow.Item("CellNM" & PA_Column.Item10) = tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM10)

        ''仮契約NO
        insRow.Item("CellNM" & PA_Column.Item14) = tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM14)

        ''Listprice
        insRow.Item("CellNM" & PA_Column.Listprice) = tmpRow.Item("CellNM" & ExcelPaymentLineColumn.LIST_PRICE_REFLESH)

        ''Listprice合計
        insRow.Item("CellNM" & PA_Column.ListpriceSum) = Formula_ListpriceSum

        ''D%適用後
        insRow.Item("CellNM" & PA_Column.DPerPrice) = tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PRICE_UNIT_IOC)

        ''D%適用後合計
        insRow.Item("CellNM" & PA_Column.DPerPriceSum) = Formula_DPerPriceSum

        ''Brand
        insRow.Item("CellNM" & PA_Column.Brand) = tmpRow.Item("CellNM" & ExcelPaymentLineColumn.BRAND)

        ''帳票表示用_Brand
        insRow.Item("CellNM" & PA_Column.DspBrand) = Brand

        ''BrandSort
        insRow.Item("CellNM" & PA_Column.BrandSort) = BrandSort

        ''PaymentSheetのExcel行位置
        insRow.Item("CellNM" & PA_Column.ExcelRow) = tmpRow.Item("ExcelRow")

    End Sub


    ''' <summary>
    '''概  要：PAの提供終了日を取得
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetPAOfferEnd(ByVal Brand As String, _
                                   ByRef tmpRow As DataRow) As String

        ''初期化
        Dim rtnValue As String
        rtnValue = ""

        Select Case Brand
            Case Me.Brand_PA_Media
                rtnValue = ""

            Case Me.Brand_PA_License
                ''提供予定期間（開始日) + 12ヵ月後の末日
                rtnValue = "出荷日から12ヵ月後の末日"

            Case Me.Brand_PA_SS
                rtnValue = tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM12)

            Case Me.Brand_PA_SS_Montry
                rtnValue = tmpRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM12)

            Case Me.Brand_PA_SS_Full
                rtnValue = "一年間"

        End Select
        Return rtnValue

    End Function

    ''' <summary>
    '''概  要：PAのｴﾗｰ文言ｾｯﾄ
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetPAConfirmation(ByRef tmpRow As DataRow) As String

        ''初期化 
        Dim rtnValue As String = ""
        GetPAConfirmation = rtnValue

        ''ｴﾗｰﾒｯｾｰｼﾞ
        Const ErrMsg001 As String = "Brandが空白の為、Mediaとして出力しています。"
        Const ErrMsg002 As String = "Productが空白です。"
        Const ErrMsg003 As String = "Descriptionが空白です。"
        Const ErrMsg004 As String = "QTYがありません。"
        Const ErrMsg005 As String = "ｻｰﾋﾞｽ開始が空白です。"
        Const ErrMsg006 As String = "ｻｰﾋﾞｽ終了が空白です。"
        Const ErrMsg007 As String = "PAサイトIDが空白です。"

        Dim ErrList As New ArrayList


        ''                      以下、ｴﾗｰの判定
        ''-------------------------------------------------------------
        ''Brandが空白の為、Mediaとして出力しています。
        If tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND).Trim = "" Then
            Call ErrList.Add(ErrMsg001)
        End If

        ''Productが空白です。
        If tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01) = "" Then
            Call ErrList.Add(ErrMsg002)
        End If

        ''Descriptionが空白です。
        If tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03) = "" Then
            Call ErrList.Add(ErrMsg003)
        End If

        ''QTYがありません。
        If tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.QTY) = "" Or _
           tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.QTY) = "0" Then
            Call ErrList.Add(ErrMsg004)
        End If

        ''ｻｰﾋﾞｽ開始が空白です。
        If tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11) = "" Then
            Call ErrList.Add(ErrMsg005)
        End If

        ''ｻｰﾋﾞｽ終了が空白です。
        If tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12) = "" Then
            Call ErrList.Add(ErrMsg006)
        End If

        ''PAサイトIDが空白です。
        If tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM06) = "" Then
            Call ErrList.Add(ErrMsg007)
        End If

        ''                  以下、ｴﾗｰ情報を改行で区切って出力
        ''-------------------------------------------------------------------
        If ErrList.Count = 0 Then
            Return ""
        Else
            ''最後の文字列後は改行不要
            For i As Integer = 0 To ErrList.Count - 1
                If i <> ErrList.Count - 1 Then
                    rtnValue = rtnValue & ErrList(i) & vbCrLf
                Else
                    rtnValue = rtnValue & ErrList(i)
                End If
            Next
            Return rtnValue
        End If

    End Function

    ''' <summary>
    '''概  要：PAシートに値を書き込む
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub CreateSheetPA(ByVal buyNo As String, _
                              ByRef xlAttachedBook As Excel.Workbook, _
                              ByRef TBL_PA As DataTable)

        Dim xlPASheet As Excel.Worksheet
        Try

            ''出力対象ﾃﾞｰﾀを取得
            Dim SQL_OutPADate As New StringBuilder
            Dim dataSet(0) As Array
            Dim rows_DelLicense() As DataRow
            Dim rows_DelSS_Montry() As DataRow
            Dim rows_DelSS_Full() As DataRow
            Dim rows_DelMedia() As DataRow
            Dim rows_License() As DataRow
            Dim rows_SS_Montry() As DataRow
            Dim rows_SS_Full() As DataRow
            Dim rows_Media() As DataRow

            ''License
            rows_DelLicense = GetDelPA_License(TBL_PA, buyNo)
            rows_License = GetAddPA_License(TBL_PA, buyNo)

            ''S&S 月割り
            rows_DelSS_Montry = GetDelPA_SSMontly(TBL_PA, buyNo)
            rows_SS_Montry = GetAddPA_SSMontly(TBL_PA, buyNo)

            ''S&S FULL
            rows_DelSS_Full = GetDelPA_SSFull(TBL_PA, buyNo)
            rows_SS_Full = GetAddPA_SSFull(TBL_PA, buyNo)

            ''Media
            rows_DelMedia = GetDelPA_Media(TBL_PA, buyNo)
            rows_Media = GetAddPA_Media(TBL_PA, buyNo)

            ''LayOut情報を取得する。
            Dim SheetPALayout As LayoutInfo
            SheetPALayout = GetLayoutInfoPA(0)

            ''                  ▼以下、各ｼｰﾄ書込
            ''-----------------------------------------------------
            ''[PA Licence削除]ｼｰﾄ
            If rows_DelLicense.Length <> 0 Then

                ''ｼｰﾄをセット
                xlPASheet = CopyWorkSheet(xlAttachedBook, Me.SheetNM_Del_PALicence)

                ''Sheetに情報を書き込む
                dataSet(0) = rows_DelLicense
                Call Me.OutRowDataToSheet(xlPASheet, dataSet, SheetPALayout)

            End If

            ''[PA Licence追加]ｼｰﾄ
            If rows_License.Length <> 0 Then

                ''ｼｰﾄをセット
                xlPASheet = CopyWorkSheet(xlAttachedBook, Me.SheetNM_ADD_PALicence)

                ''Sheetに情報を書き込む
                dataSet(0) = rows_License
                Call Me.OutRowDataToSheet(xlPASheet, dataSet, SheetPALayout)

            End If

            ''[PA S&S月割り削除]ｼｰﾄ
            If rows_DelSS_Montry.Length <> 0 Then

                ''ｼｰﾄをセット
                xlPASheet = CopyWorkSheet(xlAttachedBook, Me.SheetNM_Del_PASSMontly)

                ''Sheetに情報を書き込む
                dataSet(0) = rows_DelSS_Montry
                Call Me.OutRowDataToSheet(xlPASheet, dataSet, SheetPALayout)

            End If

            ''[PA S&S月割り追加]ｼｰﾄ
            If rows_SS_Montry.Length <> 0 Then

                ''ｼｰﾄをセット
                xlPASheet = CopyWorkSheet(xlAttachedBook, Me.SheetNM_ADD_PASSMontly)

                ''Sheetに情報を書き込む
                dataSet(0) = rows_SS_Montry
                Call Me.OutRowDataToSheet(xlPASheet, dataSet, SheetPALayout)

            End If

            ''[PA S&S FULL削除]ｼｰﾄ
            If rows_DelSS_Full.Length <> 0 Then

                ''ｼｰﾄをセット
                xlPASheet = CopyWorkSheet(xlAttachedBook, Me.SheetNM_Del_PASSFull)

                ''Sheetに情報を書き込む
                dataSet(0) = rows_DelSS_Full
                Call Me.OutRowDataToSheet(xlPASheet, dataSet, SheetPALayout)

            End If

            ''[PA S&S FULL追加]ｼｰﾄ
            If rows_SS_Full.Length <> 0 Then

                ''ｼｰﾄをセット
                xlPASheet = CopyWorkSheet(xlAttachedBook, Me.SheetNM_ADD_PASSFull)

                ''Sheetに情報を書き込む
                dataSet(0) = rows_SS_Full
                Call Me.OutRowDataToSheet(xlPASheet, dataSet, SheetPALayout)

            End If

            ''[PA Media削除]ｼｰﾄ
            If rows_DelMedia.Length <> 0 Then

                ''ｼｰﾄをセット
                xlPASheet = CopyWorkSheet(xlAttachedBook, Me.SheetNM_Del_PAMedia)

                ''Sheetに情報を書き込む
                dataSet(0) = rows_DelMedia
                Call Me.OutRowDataToSheet(xlPASheet, dataSet, SheetPALayout)
            End If

            ''[PA Media追加]ｼｰﾄ
            If rows_Media.Length <> 0 Then

                ''ｼｰﾄをセット
                xlPASheet = CopyWorkSheet(xlAttachedBook, Me.SheetNM_ADD_PAMedia)

                ''Sheetに情報を書き込む
                dataSet(0) = rows_Media
                Call Me.OutRowDataToSheet(xlPASheet, dataSet, SheetPALayout)

            End If

            ''Sheetを閉じる
            Me.CloseWorkSheet(xlPASheet)

        Catch ex As Exception
            Throw ex

        Finally
            Me.CloseWorkSheet(xlPASheet)
            GC.Collect()

        End Try

    End Sub


    ''' <summary>
    '''概  要：[License 削除]出力用ﾃﾞｰﾀ取得
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetDelPA_License(ByRef TBL_PA As DataTable, _
                                      ByVal buyNo As String) As DataRow()

        ''初期化
        Dim rtnValue() As DataRow
        GetDelPA_License = rtnValue

        ''SQL実行
        Dim SQL_OutPADate As New StringBuilder
        SQL_OutPADate.Append("CellNM" & PA_Column.ControlNo)
        SQL_OutPADate.Append(CommonConstant.SQL_STR_EQUAL)
        SQL_OutPADate.Append(StringEdit.EncloseSingleQuotation(buyNo))
        SQL_OutPADate.Append(CommonConstant.SQL_STR_AND)
        SQL_OutPADate.Append("CellNM" & PA_Column.DspBrand)
        SQL_OutPADate.Append(CommonConstant.SQL_STR_EQUAL)
        SQL_OutPADate.Append(StringEdit.EncloseSingleQuotation(Me.Brand_PA_License))
        SQL_OutPADate.Append(CommonConstant.SQL_STR_AND)
        SQL_OutPADate.Append("CellNM" & PA_Column.QTY)
        SQL_OutPADate.Append(CommonConstant.SQL_STR_LIKE)
        SQL_OutPADate.Append(StringEdit.EncloseSingleQuotation("-*"))
        rtnValue = TBL_PA.Select(SQL_OutPADate.ToString, "CellNM" & PA_Column.ExcelRow)

        Return rtnValue

    End Function

    ''' <summary>
    '''概  要：[License 追加]出力用ﾃﾞｰﾀ取得
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetAddPA_License(ByRef TBL_PA As DataTable, _
                                      ByVal buyNo As String) As DataRow()

        ''初期化
        Dim rtnValue() As DataRow
        GetAddPA_License = rtnValue

        ''SQL実行
        Dim SQL_OutPADate As New StringBuilder
        SQL_OutPADate.Append("CellNM" & PA_Column.ControlNo)
        SQL_OutPADate.Append(CommonConstant.SQL_STR_EQUAL)
        SQL_OutPADate.Append(StringEdit.EncloseSingleQuotation(buyNo))
        SQL_OutPADate.Append(CommonConstant.SQL_STR_AND)
        SQL_OutPADate.Append("CellNM" & PA_Column.DspBrand)
        SQL_OutPADate.Append(CommonConstant.SQL_STR_EQUAL)
        SQL_OutPADate.Append(StringEdit.EncloseSingleQuotation(Me.Brand_PA_License))
        SQL_OutPADate.Append(CommonConstant.SQL_STR_AND)
        SQL_OutPADate.Append("CellNM" & PA_Column.QTY)
        SQL_OutPADate.Append(CommonConstant.SQL_STR_NOT)
        SQL_OutPADate.Append(CommonConstant.SQL_STR_LIKE)
        SQL_OutPADate.Append(StringEdit.EncloseSingleQuotation("-*"))
        rtnValue = TBL_PA.Select(SQL_OutPADate.ToString, "CellNM" & PA_Column.ExcelRow)

        Return rtnValue

    End Function

    ''' <summary>
    '''概  要：[S&S 月割り 削除]出力用ﾃﾞｰﾀ取得
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetDelPA_SSMontly(ByRef TBL_PA As DataTable, _
                                       ByVal buyNo As String) As DataRow()

        ''初期化
        Dim rtnValue() As DataRow
        GetDelPA_SSMontly = rtnValue

        ''SQL実行
        Dim SQL_OutPADate As New StringBuilder
        SQL_OutPADate.Append("CellNM" & PA_Column.ControlNo)
        SQL_OutPADate.Append(CommonConstant.SQL_STR_EQUAL)
        SQL_OutPADate.Append(StringEdit.EncloseSingleQuotation(buyNo))
        SQL_OutPADate.Append(CommonConstant.SQL_STR_AND)
        SQL_OutPADate.Append("CellNM" & PA_Column.DspBrand)
        SQL_OutPADate.Append(CommonConstant.SQL_STR_EQUAL)
        SQL_OutPADate.Append(StringEdit.EncloseSingleQuotation(Me.Brand_PA_SS_Montry))
        SQL_OutPADate.Append(CommonConstant.SQL_STR_AND)
        SQL_OutPADate.Append("CellNM" & PA_Column.QTY)
        SQL_OutPADate.Append(CommonConstant.SQL_STR_LIKE)
        SQL_OutPADate.Append(StringEdit.EncloseSingleQuotation("-*"))
        rtnValue = TBL_PA.Select(SQL_OutPADate.ToString, "CellNM" & PA_Column.ExcelRow)

        Return rtnValue

    End Function

    ''' <summary>
    '''概  要：[S&S 月割り 追加]出力用ﾃﾞｰﾀ取得
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetAddPA_SSMontly(ByRef TBL_PA As DataTable, _
                                       ByVal buyNo As String) As DataRow()

        ''初期化
        Dim rtnValue() As DataRow
        GetAddPA_SSMontly = rtnValue

        ''SQL実行
        Dim SQL_OutPADate As New StringBuilder
        SQL_OutPADate.Append("CellNM" & PA_Column.ControlNo)
        SQL_OutPADate.Append(CommonConstant.SQL_STR_EQUAL)
        SQL_OutPADate.Append(StringEdit.EncloseSingleQuotation(buyNo))
        SQL_OutPADate.Append(CommonConstant.SQL_STR_AND)
        SQL_OutPADate.Append("CellNM" & PA_Column.DspBrand)
        SQL_OutPADate.Append(CommonConstant.SQL_STR_EQUAL)
        SQL_OutPADate.Append(StringEdit.EncloseSingleQuotation(Me.Brand_PA_SS_Montry))
        SQL_OutPADate.Append(CommonConstant.SQL_STR_AND)
        SQL_OutPADate.Append("CellNM" & PA_Column.QTY)
        SQL_OutPADate.Append(CommonConstant.SQL_STR_NOT)
        SQL_OutPADate.Append(CommonConstant.SQL_STR_LIKE)
        SQL_OutPADate.Append(StringEdit.EncloseSingleQuotation("-*"))
        rtnValue = TBL_PA.Select(SQL_OutPADate.ToString, "CellNM" & PA_Column.ExcelRow)

        Return rtnValue

    End Function

    ''' <summary>
    '''概  要：[S&S FULL 削除]出力用ﾃﾞｰﾀ取得
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetDelPA_SSFull(ByRef TBL_PA As DataTable, _
                                     ByVal buyNo As String) As DataRow()

        ''初期化
        Dim rtnValue() As DataRow
        GetDelPA_SSFull = rtnValue

        ''SQL実行
        Dim SQL_OutPADate As New StringBuilder
        SQL_OutPADate.Append("CellNM" & PA_Column.ControlNo)
        SQL_OutPADate.Append(CommonConstant.SQL_STR_EQUAL)
        SQL_OutPADate.Append(StringEdit.EncloseSingleQuotation(buyNo))
        SQL_OutPADate.Append(CommonConstant.SQL_STR_AND)
        SQL_OutPADate.Append("CellNM" & PA_Column.DspBrand)
        SQL_OutPADate.Append(CommonConstant.SQL_STR_EQUAL)
        SQL_OutPADate.Append(StringEdit.EncloseSingleQuotation(Me.Brand_PA_SS_Full))
        SQL_OutPADate.Append(CommonConstant.SQL_STR_AND)
        SQL_OutPADate.Append("CellNM" & PA_Column.QTY)
        SQL_OutPADate.Append(CommonConstant.SQL_STR_LIKE)
        SQL_OutPADate.Append(StringEdit.EncloseSingleQuotation("-*"))
        rtnValue = TBL_PA.Select(SQL_OutPADate.ToString, "CellNM" & PA_Column.ExcelRow)

        Return rtnValue

    End Function

    ''' <summary>
    '''概  要：[S&S FULL 追加]出力用ﾃﾞｰﾀ取得
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetAddPA_SSFull(ByRef TBL_PA As DataTable, _
                                     ByVal buyNo As String) As DataRow()

        ''初期化
        Dim rtnValue() As DataRow
        GetAddPA_SSFull = rtnValue

        ''SQL実行
        Dim SQL_OutPADate As New StringBuilder
        SQL_OutPADate.Append("CellNM" & PA_Column.ControlNo)
        SQL_OutPADate.Append(CommonConstant.SQL_STR_EQUAL)
        SQL_OutPADate.Append(StringEdit.EncloseSingleQuotation(buyNo))
        SQL_OutPADate.Append(CommonConstant.SQL_STR_AND)
        SQL_OutPADate.Append("CellNM" & PA_Column.DspBrand)
        SQL_OutPADate.Append(CommonConstant.SQL_STR_EQUAL)
        SQL_OutPADate.Append(StringEdit.EncloseSingleQuotation(Me.Brand_PA_SS_Full))
        SQL_OutPADate.Append(CommonConstant.SQL_STR_AND)
        SQL_OutPADate.Append("CellNM" & PA_Column.QTY)
        SQL_OutPADate.Append(CommonConstant.SQL_STR_NOT)
        SQL_OutPADate.Append(CommonConstant.SQL_STR_LIKE)
        SQL_OutPADate.Append(StringEdit.EncloseSingleQuotation("-*"))
        rtnValue = TBL_PA.Select(SQL_OutPADate.ToString, "CellNM" & PA_Column.ExcelRow)

        Return rtnValue

    End Function

    ''' <summary>
    '''概  要：[Media 削除]出力用ﾃﾞｰﾀ取得
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetDelPA_Media(ByRef TBL_PA As DataTable, _
                                    ByVal buyNo As String) As DataRow()

        ''初期化
        Dim rtnValue() As DataRow
        GetDelPA_Media = rtnValue

        ''SQL実行
        Dim SQL_OutPADate As New StringBuilder
        SQL_OutPADate.Append("CellNM" & PA_Column.ControlNo)
        SQL_OutPADate.Append(CommonConstant.SQL_STR_EQUAL)
        SQL_OutPADate.Append(StringEdit.EncloseSingleQuotation(buyNo))
        SQL_OutPADate.Append(CommonConstant.SQL_STR_AND)
        SQL_OutPADate.Append("CellNM" & PA_Column.DspBrand)
        SQL_OutPADate.Append(CommonConstant.SQL_STR_EQUAL)
        SQL_OutPADate.Append(StringEdit.EncloseSingleQuotation(Me.Brand_PA_Media))
        SQL_OutPADate.Append(CommonConstant.SQL_STR_AND)
        SQL_OutPADate.Append("CellNM" & PA_Column.QTY)
        SQL_OutPADate.Append(CommonConstant.SQL_STR_LIKE)
        SQL_OutPADate.Append(StringEdit.EncloseSingleQuotation("-*"))
        rtnValue = TBL_PA.Select(SQL_OutPADate.ToString, "CellNM" & PA_Column.ExcelRow)

        Return rtnValue

    End Function

    ''' <summary>
    '''概  要：[Media 追加]出力用ﾃﾞｰﾀ取得
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetAddPA_Media(ByRef TBL_PA As DataTable, _
                                      ByVal buyNo As String) As DataRow()

        ''初期化
        Dim rtnValue() As DataRow
        GetAddPA_Media = rtnValue

        ''SQL実行
        Dim SQL_OutPADate As New StringBuilder
        SQL_OutPADate.Append("CellNM" & PA_Column.ControlNo)
        SQL_OutPADate.Append(CommonConstant.SQL_STR_EQUAL)
        SQL_OutPADate.Append(StringEdit.EncloseSingleQuotation(buyNo))
        SQL_OutPADate.Append(CommonConstant.SQL_STR_AND)
        SQL_OutPADate.Append("CellNM" & PA_Column.DspBrand)
        SQL_OutPADate.Append(CommonConstant.SQL_STR_EQUAL)
        SQL_OutPADate.Append(StringEdit.EncloseSingleQuotation(Me.Brand_PA_Media))
        SQL_OutPADate.Append(CommonConstant.SQL_STR_AND)
        SQL_OutPADate.Append("CellNM" & PA_Column.QTY)
        SQL_OutPADate.Append(CommonConstant.SQL_STR_NOT)
        SQL_OutPADate.Append(CommonConstant.SQL_STR_LIKE)
        SQL_OutPADate.Append(StringEdit.EncloseSingleQuotation("-*"))
        rtnValue = TBL_PA.Select(SQL_OutPADate.ToString, "CellNM" & PA_Column.ExcelRow)

        Return rtnValue

    End Function

    ''' <summary>
    '''概  要：PAシートのレイアウトシート情報を出力
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetLayoutInfoPA(ByVal idx As Integer) As LayoutInfo

        ''初期化
        Dim rtnValue As LayoutInfo
        GetLayoutInfoPA = rtnValue

        ''出力用レイアウト  
        ''※Licence/SS月割り/SSFULL/Media　全てレイアウト同じ

        ''シート全体の設定
        Dim SheetLayout As SheetLayoutInfo
        Dim OutBlockLayout(idx) As OutBlockLayoutInfo
        For i As Integer = 0 To idx

            ''配列拡張
            ReDim Preserve OutBlockLayout(i)

            ''テンプレ行の設定
            OutBlockLayout(i).isTitleRow = False          ''ﾃﾝﾌﾟﾚｰﾄ行：ﾃﾝﾌﾟﾚｰﾄ行を使用するかどうか？
            OutBlockLayout(i).isTmpRow = True             ''ﾃﾝﾌﾟﾚｰﾄ行：ﾃﾝﾌﾟﾚｰﾄ行を使用するかどうか？
            OutBlockLayout(i).TmplateRow = "3"            ''ﾃﾝﾌﾟﾚｰﾄ行：位置
            OutBlockLayout(i).TmpPasteStrIndex = 7        ''ﾃﾝﾌﾟﾚｰﾄ行：貼付開始位置

            ''項目の出力位置の調整
            OutBlockLayout(i).IsFreeFormat = False                                              ''値貼付：連続したデータの貼り付け or セルの位置を指定して貼付
            OutBlockLayout(i).PasteStrIndex = 7                                                 ''値貼付：出力開始位置
            OutBlockLayout(i).IsChgRefColumn = True                                             ''値貼付：出力対象ﾃﾞｰﾀと、出力列の位置関係を変更するかどうか？
            OutBlockLayout(i).PasteArea = "B@Str:V@End"                                         ''値貼付：貼付の範囲[A@Str:IT@End]
            OutBlockLayout(i).PasteStrClomunsIdx = ExcelWrite.ChgExcelRowCharToNumber("B")      ''値貼付：貼付の開始列
            OutBlockLayout(i).PasteEndClomunsIdx = ExcelWrite.ChgExcelRowCharToNumber("V")      ''値貼付：貼付の終了列

            ''値貼付：出力対象ﾃﾞｰﾀと、出力列の位置関係
            Dim setValue(16, 1) As String

            ''管理番号	
            setValue(0, 0) = "B"
            setValue(0, 1) = "CellNM" & PA_Column.DspControlNo

            ''管理名称	
            setValue(1, 0) = "F"
            setValue(1, 1) = "CellNM" & PA_Column.ControlName

            ''PA製品番号	
            setValue(2, 0) = "G"
            setValue(2, 1) = "CellNM" & PA_Column.Product

            ''Description	
            setValue(3, 0) = "H"
            setValue(3, 1) = "CellNM" & PA_Column.Description

            ''QTY	
            setValue(4, 0) = "I"
            setValue(4, 1) = "CellNM" & PA_Column.QTY

            ''提供期間_開始
            setValue(5, 0) = "J"
            setValue(5, 1) = "CellNM" & PA_Column.OfferStr

            ''提供期間_終了
            setValue(6, 0) = "K"
            setValue(6, 1) = "CellNM" & PA_Column.OfferEnd

            ''補足	
            setValue(7, 0) = "L"
            setValue(7, 1) = "CellNM" & PA_Column.Supplement

            ''PAID
            setValue(8, 0) = "N"
            setValue(8, 1) = "CellNM" & PA_Column.PAID

            ''確認事項	
            setValue(9, 0) = "O"
            setValue(9, 1) = "CellNM" & PA_Column.Confirmation

            ''LineNo
            setValue(10, 0) = "P"
            setValue(10, 1) = "CellNM" & PA_Column.LineNo

            ''取り込み元ﾃﾞｰﾀ
            setValue(11, 0) = "Q"
            setValue(11, 1) = "CellNM" & PA_Column.Item10

            ''仮契約NO
            setValue(12, 0) = "R"
            setValue(12, 1) = "CellNM" & PA_Column.Item14

            ''Listprice
            setValue(13, 0) = "S"
            setValue(13, 1) = "CellNM" & PA_Column.Listprice

            ''Listprice合計
            setValue(14, 0) = "T"
            setValue(14, 1) = "CellNM" & PA_Column.ListpriceSum

            ''D%適用後
            setValue(15, 0) = "U"
            setValue(15, 1) = "CellNM" & PA_Column.DPerPrice

            ''D%適用後合計
            setValue(16, 0) = "V"
            setValue(16, 1) = "CellNM" & PA_Column.DPerPriceSum

            OutBlockLayout(i).SetChgRefColumn = setValue
        Next

        ''値のセット
        rtnValue.SheetLayout = SheetLayout
        rtnValue.OutBlockLayout = OutBlockLayout

        ''戻り値
        Return rtnValue

    End Function


    ''' <summary>
    '''概  要：PAシートの段落に見出しをつける。
    '''説  明：※Licence / S&S Full/ S&S Montry / Medis 
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetPATitleValue(ByVal idx As Integer, _
                                ByVal titleValue As String, _
                                ByRef xlPASheet As Excel.Worksheet, _
                                ByRef dataSet As Array)

        Dim xlCell As Excel.Range
        Try
            Dim setIdx As Integer
            Dim tmpSetIdx As Integer        ''出力した行の数
            For i As Integer = 0 To idx - 1
                tmpSetIdx = tmpSetIdx + dataSet(i).Length
            Next
            setIdx = 10 + _
                     tmpSetIdx + _
                     ((idx) * 5)
            xlCell = xlPASheet.Range("B" & setIdx)
            xlCell.Value = titleValue

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try
    End Sub

#End Region

#Region "SWの処理"

    ''' <summary>
    '''概  要：SW出力対象ﾃﾞｰﾀの抽出
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateTableSW(ByRef PSTable As DataTable, _
                                   ByRef DetailTable As DataTable) As DataTable

        ''初期化
        Dim rtnTable As New DataTable
        rtnTable = CreateDataTable(SW_Column.ControlNo, SW_Column.DetailExcelRow)
        CreateTableSW = rtnTable

        Try
            ''SwmaTable取得
            Dim SwmaDataTbl As DataTable
            SwmaDataTbl = GetSwmaDataTable()

            ''CodeTable取得　※Serial対象外の製品に仮ｼﾘｱﾙﾁｪｯｸを発生させない。
            Dim CodeDataTbl As DataTable
            CodeDataTbl = GetCodeDataTable()

            ''PSテーブルから出力対象ﾃﾞｰﾀを取得
            Dim SQL_GetSW As String
            SQL_GetSW = GetSQL_PSSW_Output()

            ''PSデータから詳細ﾃﾞｰﾀを取得し、データに加える。
            Dim isQtyminusRow As Boolean
            Dim insPSRow As DataRow
            Dim insDetailRow As DataRow
            For Each PSRow As DataRow In PSTable.Select(SQL_GetSW)

                ''PSのﾃﾞｰﾀをセット
                isQtyminusRow = False
                insPSRow = rtnTable.NewRow
                Call SetPS_SWRow(isQtyminusRow, CodeDataTbl, SwmaDataTbl, insPSRow, PSRow, DetailTable)
                Call rtnTable.Rows.Add(insPSRow)

                ''Detailのﾃﾞｰﾀをセット
                SQL_GetSW = GetSQL_DetailSWOutput(PSRow)
                For Each DetailRow As DataRow In DetailTable.Select(SQL_GetSW)
                    insDetailRow = rtnTable.NewRow
                    Call SetDetail_SWRow(isQtyminusRow, insDetailRow, DetailRow, PSRow)
                    Call rtnTable.Rows.Add(insDetailRow)
                Next
            Next
            Return rtnTable

        Catch ex As Exception
            Throw ex

        End Try

    End Function


    ''' <summary>
    '''概  要：HWBrandSW AASの出力情報を作成
    '''説  明：※1行分のﾃﾞｰﾀ作成
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetPS_SWRow(ByRef isQtyminusRow As Boolean, _
                            ByRef codeTable As DataTable, _
                            ByRef swmaTable As DataTable, _
                            ByRef insRow As DataRow, _
                            ByRef PSRow As DataRow,
                            ByRef DetailTable As DataTable)


        ''                       以下、計算処理
        ''--------------------------------------------------------------------------
        Dim ControlNo As String
        Dim DspControlNo As String
        Dim ControlName As String

        ''管理番号  ※規定桁数なければ、有るだけセット
        If ExcelWrite.changeDBNullToString(PSRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM15)).Length >= 13 Then
            ControlNo = ExcelWrite.changeDBNullToString(PSRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM15).SubString(0, 13))
        Else
            ControlNo = ExcelWrite.changeDBNullToString(PSRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM15))
        End If

        ''表示用_管理番号  ※空白なら、購買番号NULLをセット
        If ControlNo = "" Then
            DspControlNo = "購買番号NULL"
        Else
            DspControlNo = ControlNo
        End If

        ''管理名称
        If ExcelWrite.changeDBNullToString(PSRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM15)).Length >= 14 Then
            ControlName = PSRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM15).SubString(13, PSRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM15).Length - 13)
        Else
            ControlName = ""
        End If


        ''                       以下、各値をセット
        ''--------------------------------------------------------------------------
        ''管理番号  
        insRow.Item("CellNM" & SW_Column.ControlNo) = ControlNo

        ''表示用_管理番号  
        insRow.Item("CellNM" & SW_Column.DspControlNo) = DspControlNo

        ''管理名称
        insRow.Item("CellNM" & SW_Column.ControlName) = ControlName

        ''HWMTDL
        insRow.Item("CellNM" & SW_Column.HWMTDL) = PSRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM04)

        ''HWSerial
        If PSRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM02).ToString.IndexOf("@") = 0 Then
            insRow.Item("CellNM" & SW_Column.HWSerial) = "発注中"
        Else
            insRow.Item("CellNM" & SW_Column.HWSerial) = PSRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM02)
        End If

        ''Product
        insRow.Item("CellNM" & SW_Column.Product) = PSRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM01)

        ''Description
        insRow.Item("CellNM" & SW_Column.Description) = PSRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM03)

        ''QTY　※数量が+ or - の判定も行う。
        insRow.Item("CellNM" & SW_Column.QTY) = PSRow.Item("CellNM" & ExcelPaymentLineColumn.QTY)
        If IsNumeric(PSRow.Item("CellNM" & ExcelPaymentLineColumn.QTY)) = True AndAlso _
           CInt(PSRow.Item("CellNM" & ExcelPaymentLineColumn.QTY)) < 0 Then
            isQtyminusRow = True
        Else
            isQtyminusRow = False
        End If

        ''提供期間_開始日
        insRow.Item("CellNM" & SW_Column.OfferStr) = PSRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM11)

        ''提供期間_終了日
        insRow.Item("CellNM" & SW_Column.OfferEnd) = GetSW_OfferEnd(swmaTable, PSRow)

        ''補足
        insRow.Item("CellNM" & SW_Column.PostScript) = ""

        ''確認事項
        insRow.Item("CellNM" & SW_Column.Confirmation) = GetPS_SWConfirmation(PSRow, DetailTable, codeTable, swmaTable)

        ''LineNo
        insRow.Item("CellNM" & SW_Column.LineNo) = PSRow.Item("CellNM" & ExcelPaymentLineColumn.LINE_NO)

        ''Excel式
        Const Formula_ListPriceSum As String = "=RC[-1]*RC[-13]"
        Const Formula_DPerPriceSum As String = "=RC[-1]*RC[-15]"

        ''ファイル名
        insRow.Item("CellNM" & SW_Column.FileNM) = PSRow.Item("CellNM" & ExcelPaymentLineColumn.FILE_NAME)

        ''ファイル名サフィックス
        insRow.Item("CellNM" & SW_Column.FileNMSuffix) = PSRow.Item("CellNM" & ExcelPaymentLineColumn.FILE_NAME_SUFFIX)

        ''ファイル内サフィックス
        insRow.Item("CellNM" & SW_Column.FileIntrSuffix) = PSRow.Item("CellNM" & ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR)

        ''取り込み元ﾃﾞｰﾀ
        insRow.Item("CellNM" & SW_Column.Item10) = PSRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM10)

        ''仮契約NO
        insRow.Item("CellNM" & SW_Column.Item14) = PSRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM14)

        ''Listprice
        insRow.Item("CellNM" & SW_Column.Listprice) = PSRow.Item("CellNM" & ExcelPaymentLineColumn.LIST_PRICE_REFLESH)

        ''Listprice合計
        insRow.Item("CellNM" & SW_Column.ListpriceSum) = Formula_ListPriceSum

        ''D%適用後(IOC単価)
        insRow.Item("CellNM" & SW_Column.DPerPrice) = PSRow.Item("CellNM" & ExcelPaymentLineColumn.PRICE_UNIT_IOC)

        ''D%適用後合計
        insRow.Item("CellNM" & SW_Column.DPerPriceSum) = Formula_DPerPriceSum

        ''PS情報 or 詳細情報
        insRow.Item("CellNM" & SW_Column.IsDetail) = "0"

        ''PSのExcel行位置
        insRow.Item("CellNM" & SW_Column.PSExcelRow) = PSRow.Item("ExcelRow")

        ''DetailのExcel行位置
        insRow.Item("CellNM" & SW_Column.DetailExcelRow) = ""

    End Sub

    ''' <summary>
    '''概  要：SW の出力情報を作成
    '''説  明：※1行分のﾃﾞｰﾀ作成
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetDetail_SWRow(ByVal isQtyminusRow As Boolean, _
                                ByRef insDetailRow As DataRow, _
                                ByRef DetailRow As DataRow, _
                                ByRef PSRow As DataRow)


        ''                       以下、計算処理
        ''--------------------------------------------------------------------------
        Dim ControlNo As String
        ''管理番号  ※規定桁数なければ、有るだけセット
        If ExcelWrite.changeDBNullToString(PSRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM15)).Length >= 13 Then
            ControlNo = ExcelWrite.changeDBNullToString(PSRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM15).SubString(0, 13))
        Else
            ControlNo = ExcelWrite.changeDBNullToString(PSRow.Item("CellNM" & ExcelPaymentLineColumn.PROD_ITEM15))
        End If

        ''                       以下、各値をセット
        ''--------------------------------------------------------------------------
        ''管理番号  
        insDetailRow.Item("CellNM" & SW_Column.ControlNo) = ControlNo

        ''表示用_管理番号  
        insDetailRow.Item("CellNM" & SW_Column.DspControlNo) = ""

        ''管理名称
        insDetailRow.Item("CellNM" & SW_Column.ControlName) = ""

        ''HWMTDL
        insDetailRow.Item("CellNM" & SW_Column.HWMTDL) = ""

        ''HWSerial
        insDetailRow.Item("CellNM" & SW_Column.HWSerial) = ""

        ''Product
        insDetailRow.Item("CellNM" & SW_Column.Product) = DetailRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.PROD_NO)

        ''Description
        insDetailRow.Item("CellNM" & SW_Column.Description) = DetailRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.PROD_NAME)

        ''QTY　※Paymentの数量が"-"の場合、詳細の数量も"-"にする。
        Dim Qty As String
        Dim tmpQty As Integer
        If isQtyminusRow = True And _
           IsNumeric(DetailRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.QTY_INTEGER)) = True Then
            tmpQty = CInt(DetailRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.QTY_INTEGER))
            Qty = tmpQty * -1
        Else
            Qty = DetailRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.QTY_INTEGER)
        End If
        insDetailRow.Item("CellNM" & SW_Column.QTY) = Qty

        ''提供期間_開始日
        insDetailRow.Item("CellNM" & SW_Column.OfferStr) = ""

        ''提供期間_終了日
        insDetailRow.Item("CellNM" & SW_Column.OfferEnd) = ""

        ''補足
        insDetailRow.Item("CellNM" & SW_Column.PostScript) = ""

        ''確認事項
        insDetailRow.Item("CellNM" & SW_Column.Confirmation) = GetDetailHWBrandSWAASConfirmation(DetailRow)

        ''Linno
        insDetailRow.Item("CellNM" & SW_Column.LineNo) = ""

        ''※詳細は明示的に空白をセットする。
        ''ファイル名
        insDetailRow.Item("CellNM" & SW_Column.FileNM) = ""

        ''ファイル名サフィックス
        insDetailRow.Item("CellNM" & SW_Column.FileNMSuffix) = ""

        ''ファイル内サフィックス
        insDetailRow.Item("CellNM" & SW_Column.FileIntrSuffix) = ""

        ''取り込み元ﾃﾞｰﾀ
        insDetailRow.Item("CellNM" & SW_Column.Item10) = ""

        ''仮契約NO
        insDetailRow.Item("CellNM" & SW_Column.Item14) = ""

        ''Listprice
        insDetailRow.Item("CellNM" & SW_Column.Listprice) = ""

        ''Listprice合計
        insDetailRow.Item("CellNM" & SW_Column.ListpriceSum) = ""

        ''D%適用後
        insDetailRow.Item("CellNM" & SW_Column.DPerPrice) = ""

        ''D%適用後合計
        insDetailRow.Item("CellNM" & SW_Column.DPerPriceSum) = ""

        ''PS情報 or 詳細情報
        insDetailRow.Item("CellNM" & SW_Column.IsDetail) = "1"

        ''PSのExcel行位置
        insDetailRow.Item("CellNM" & SW_Column.PSExcelRow) = PSRow.Item("ExcelRow")

        ''DetailのExcel行位置
        insDetailRow.Item("CellNM" & SW_Column.DetailExcelRow) = DetailRow.Item("ExcelRow")

    End Sub

    ''' <summary>
    '''概  要：SWMATableの値から、提供期間_終了年を取得
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSW_OfferEnd(ByRef SwmaDataTable As DataTable, _
                                    ByRef PSRow As DataRow) As String

        ''初期化
        Dim rtnValue = ""
        GetSW_OfferEnd = rtnValue

        ''machineType,modelを取得
        Dim tmpValue() As String
        Dim machineType As String
        Dim model As String
        tmpValue = Split(PSRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01), "-")
        If UBound(tmpValue) >= 1 Then
            machineType = tmpValue(0)
            model = tmpValue(1)
        Else
            machineType = tmpValue(0)
            model = ""
        End If

        ''SWMATable検索用のSQL  取得      
        Dim SQL_ExistsSWMA As New StringBuilder
        SQL_ExistsSWMA.Append(SwmaTable.COLUMN_NAME_MACHINETYPE)
        SQL_ExistsSWMA.Append(CommonConstant.SQL_STR_EQUAL)
        SQL_ExistsSWMA.Append(StringEdit.EncloseSingleQuotation(machineType))
        SQL_ExistsSWMA.Append(CommonConstant.SQL_STR_AND)
        SQL_ExistsSWMA.Append(SwmaTable.COLUMN_NAME_MODEL)
        SQL_ExistsSWMA.Append(CommonConstant.SQL_STR_EQUAL)
        SQL_ExistsSWMA.Append(StringEdit.EncloseSingleQuotation(model))

        ''区分に応じて、提供期間_終了を取得
        Dim pattenCD As String
        pattenCD = ExcelWrite.GetPatternCD(PSRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD), _
                                           PSRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN))
        Dim rows() As DataRow
        rows = SwmaDataTable.Select(SQL_ExistsSWMA.ToString)
        Select Case pattenCD
            Case CommonConstant.PATTERNCD_TYPE_HWBrandSW_AAS, _
                 CommonConstant.PATTERNCD_TYPE_SWBrandSW
                If rows.Length = 0 Then
                    rtnValue = ""
                Else
                    If ExcelWrite.changeDBNullToString(rows(0).Item(SwmaTable.COLUMN_NAME_SWMA_YEAR)) = "" Then
                        rtnValue = ""
                    Else
                        rtnValue = rows(0).Item(SwmaTable.COLUMN_NAME_SWMA_YEAR) & "年間"
                    End If
                End If

            Case CommonConstant.PATTERNCD_TYPE_HWBrandSWMA_AAS, _
                 CommonConstant.PATTERNCD_TYPE_SWBrandSWMA
                If rows.Length = 0 Then
                    rtnValue = "*年間"
                Else

                    If ExcelWrite.changeDBNullToString(rows(0).Item(SwmaTable.COLUMN_NAME_SWMA_YEAR)) = "" Then
                        rtnValue = ""
                    Else
                        rtnValue = rows(0).Item(SwmaTable.COLUMN_NAME_SWMA_YEAR) & "年間"
                    End If
                End If

            Case Else
                ''QCOS SWは空白セット
                rtnValue = ""

        End Select
        Return rtnValue

    End Function

    ''' <summary>
    '''概  要：SWの確認事項を取得する。
    '''説  明：※PS行のﾁｪｯｸ
    ''' </summary>
    ''' <remarks></remarks>    
    Private Function GetPS_SWConfirmation(ByRef tmpRow As DataRow, _
                                          ByRef DetailTable As DataTable, _
                                          ByRef codeDataTable As DataTable, _
                                          ByRef swmaDataTable As DataTable) As String

        ''初期化 
        Dim rtnValue As String = ""
        GetPS_SWConfirmation = rtnValue

        ''ｴﾗｰﾒｯｾｰｼﾞ
        Const ErrMsg001 As String = "詳細ﾃﾞｰﾀがありません。"
        Const ErrMsg002 As String = "HW製品番号が空白です。"
        Const ErrMsg003 As String = "HW SERIALが空白です。"
        Const ErrMsg004 As String = "Productが空白です。"
        Const ErrMsg005 As String = "Descriptionが空白です。"
        Const ErrMsg006 As String = "QTYがありません。"
        Const ErrMsg007 As String = "ｻｰﾋﾞｽ開始が空白です。"
        Const ErrMsg008 As String = "ｻｰﾋﾞｽ期間を設定してください。"
        Const ErrMsg009 As String = "削除ﾃﾞｰﾀのため、詳細ﾃﾞｰﾀがありません。"
        Const ErrMsg010 As String = "ｻｰﾋﾞｽ期間を設定してください。"

        Dim ErrList As New ArrayList

        ''                      以下、ｴﾗｰの判定
        ''-------------------------------------------------------------
        ''AAS製品かどうかの判定
        Dim isAAS As Boolean = False
        Dim patternCD As String
        patternCD = ExcelWrite.GetPatternCD(tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD), _
                                            tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN))
        Select Case patternCD
            Case CommonConstant.PATTERNCD_TYPE_HWBrandSW_AAS,
                 CommonConstant.PATTERNCD_TYPE_SWBrandSW,
                 CommonConstant.PATTERNCD_TYPE_HWBrandSWMA_AAS,
                 CommonConstant.PATTERNCD_TYPE_SWBrandSWMA

                isAAS = True
            Case Else
                isAAS = False
        End Select

        ''詳細ﾃﾞｰﾀがありません。
        If isAAS = True Then
            Dim SQL_GetDetail As New StringBuilder
            SQL_GetDetail.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT)
            SQL_GetDetail.Append(CommonConstant.SQL_STR_EQUAL)
            SQL_GetDetail.Append(StringEdit.EncloseSingleQuotation(tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT)))
            SQL_GetDetail.Append(CommonConstant.SQL_STR_AND)
            SQL_GetDetail.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME)
            SQL_GetDetail.Append(CommonConstant.SQL_STR_EQUAL)
            SQL_GetDetail.Append(StringEdit.EncloseSingleQuotation(tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME)))
            SQL_GetDetail.Append(CommonConstant.SQL_STR_AND)
            SQL_GetDetail.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX)
            SQL_GetDetail.Append(CommonConstant.SQL_STR_EQUAL)
            SQL_GetDetail.Append(StringEdit.EncloseSingleQuotation(tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX)))
            SQL_GetDetail.Append(CommonConstant.SQL_STR_AND)
            SQL_GetDetail.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR)
            SQL_GetDetail.Append(CommonConstant.SQL_STR_EQUAL)
            SQL_GetDetail.Append(StringEdit.EncloseSingleQuotation(tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR)))
            If DetailTable.Select(SQL_GetDetail.ToString).Length = 0 Then
                Call ErrList.Add(ErrMsg001)
            End If
        End If

        ''HW製品番号が空白です。
        If isAAS = True Then
            If tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM04) = "" Then
                Call ErrList.Add(ErrMsg002)
            End If
        End If

        ''HW SERIALが空白です。
        Dim isNotHWSerial As Boolean = False        ''仮ｼﾘｱﾙ採番対象外製品かどうか？
        Dim SQL_CodeTable As New StringBuilder
        SQL_CodeTable.Append(CodeTable.COLUMN_NAME_ITEMVALUE)
        SQL_CodeTable.Append(CommonConstant.SQL_STR_EQUAL)
        SQL_CodeTable.Append(StringEdit.EncloseSingleQuotation(tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM04)))
        If codeDataTable.Select(SQL_CodeTable.ToString).Length <> 0 Then
            isNotHWSerial = True
        End If
        If isAAS = True And isNotHWSerial = False Then
            If tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02) = "" Then
                Call ErrList.Add(ErrMsg003)
            End If
        End If

        ''Productが空白です。
        If tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01) = "" Then
            Call ErrList.Add(ErrMsg004)
        End If

        ''Descriptionが空白です。
        If tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03) = "" Then
            Call ErrList.Add(ErrMsg005)
        End If

        ''QTYがありません。
        If tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.QTY) = "0" Or
           tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.QTY) = "" Then
            Call ErrList.Add(ErrMsg006)
        End If

        ''ｻｰﾋﾞｽ開始が空白です。
        If tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11) = "" Then
            Call ErrList.Add(ErrMsg007)
        End If

        ''ｻｰﾋﾞｽ期間を設定してください。
        If patternCD = CommonConstant.PATTERNCD_TYPE_HWBrandSWMA_AAS Or _
           patternCD = CommonConstant.PATTERNCD_TYPE_SWBrandSWMA Then

            ''machineType,modelを取得
            Dim tmpValue() As String
            Dim machineType As String
            Dim model As String
            tmpValue = Split(tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01), "-")
            If UBound(tmpValue) >= 1 Then
                machineType = tmpValue(0)
                model = tmpValue(1)
            Else
                machineType = tmpValue(0)
                model = ""
            End If

            Dim SQL_SwmaTable As New StringBuilder
            SQL_SwmaTable.Append(SwmaTable.COLUMN_NAME_MACHINETYPE)
            SQL_SwmaTable.Append(CommonConstant.SQL_STR_EQUAL)
            SQL_SwmaTable.Append(StringEdit.EncloseSingleQuotation(machineType))
            SQL_SwmaTable.Append(CommonConstant.SQL_STR_AND)
            SQL_SwmaTable.Append(SwmaTable.COLUMN_NAME_MODEL)
            SQL_SwmaTable.Append(CommonConstant.SQL_STR_EQUAL)
            SQL_SwmaTable.Append(StringEdit.EncloseSingleQuotation(model))
            If swmaDataTable.Select(SQL_SwmaTable.ToString).Length = 0 Then
                Call ErrList.Add(ErrMsg010)
            End If
        End If


        ''                  以下、ｴﾗｰ情報を改行で区切って出力
        ''-------------------------------------------------------------------
        If ErrList.Count = 0 Then
            Return ""
        Else
            ''最後の文字列後は改行不要
            For i As Integer = 0 To ErrList.Count - 1
                If i <> ErrList.Count - 1 Then
                    rtnValue = rtnValue & ErrList(i) & vbCrLf
                Else
                    rtnValue = rtnValue & ErrList(i)
                End If
            Next
            Return rtnValue
        End If

    End Function

    ''' <summary>
    '''概  要：HWBrandSW AASのｴﾗｰ文言
    '''説  明：※詳細のｴﾗｰﾁｪｯｸ
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetDetailHWBrandSWAASConfirmation(ByRef TmpRow As DataRow) As String

        ''初期化
        Dim rtnValue As String
        rtnValue = ""
        GetDetailHWBrandSWAASConfirmation = rtnValue

        ''ｴﾗｰﾒｯｾｰｼﾞ
        Const ErrMsg001 As String = "Productが空白です。"
        Const ErrMsg002 As String = "Descriptionが空白です。"
        Const ErrMsg003 As String = "QTYがありません。"

        Dim ErrList As New ArrayList

        ''                      以下、ｴﾗｰの判定
        ''-------------------------------------------------------------
        ''Productが空白です。
        If TmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.PROD_NO) = "" Then
            Call ErrList.Add(ErrMsg001)
        End If

        ''Descriptionが空白です。
        If TmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.PROD_NAME) = "" Then
            Call ErrList.Add(ErrMsg002)
        End If

        ''QTYがありません。
        If TmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.QTY_INTEGER) = "" Or _
           TmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.QTY_INTEGER) = "0" Then
            Call ErrList.Add(ErrMsg003)
        End If

        ''                  以下、ｴﾗｰ情報を改行で区切って出力
        ''-------------------------------------------------------------------
        If ErrList.Count = 0 Then
            Return ""
        Else
            ''最後の文字列後は改行不要
            For i As Integer = 0 To ErrList.Count - 1
                If i <> ErrList.Count - 1 Then
                    rtnValue = rtnValue & ErrList(i) & vbCrLf
                Else
                    rtnValue = rtnValue & ErrList(i)
                End If
            Next
            Return rtnValue
        End If

    End Function

    ''' <summary>
    '''概  要：SWシートに値を書き込む
    '''説  明：※
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub CreateSheetSW(ByVal buyNo As String, _
                              ByRef xlAttachedBook As Excel.Workbook, _
                              ByRef TBL_SW As DataTable)

        Dim xlOutLine As Excel.Outline
        Dim xlSWSheet As Excel.Worksheet
        Try
            ''出力対象ﾃﾞｰﾀを取得
            Dim rows(0) As Array
            Dim setRows() As DataRow                ''追加分：SW出力用ﾃﾞｰﾀを格納
            Dim delRows() As DataRow                ''削除分：SW出力用ﾃﾞｰﾀを格納
            setRows = GetAddSWDate(TBL_SW, buyNo)
            delRows = GetDelSWDate(TBL_SW, buyNo)

            ''LayOut情報を取得する。
            Dim SheetSWLayout As LayoutInfo
            SheetSWLayout = GetLayoutInfoSW()

            ''「SW 削除ｼｰﾄ」の処理
            If delRows.Length <> 0 Then

                ''ｼｰﾄをセット
                xlSWSheet = CopyWorkSheet(xlAttachedBook, Me.SheetNM_Del_SW)

                ''Sheetに情報を書き込む
                rows(0) = delRows
                Call Me.OutRowDataToSheet(xlSWSheet, rows, SheetSWLayout)

                ''グループを閉じる。
                xlOutLine = xlSWSheet.Outline
                Call xlOutLine.ShowLevels(1, 0)

                ''Sheetを閉じる
                Me.CloseWorkSheet(xlSWSheet)

            End If

            ''「SW 追加ｼｰﾄ」の処理
            If setRows.Length <> 0 Then

                ''ｼｰﾄをセット
                xlSWSheet = CopyWorkSheet(xlAttachedBook, Me.SheetNM_ADD_SW)

                ''Sheetに情報を書き込む
                rows(0) = setRows
                Call Me.OutRowDataToSheet(xlSWSheet, rows, SheetSWLayout)

                ''グループを閉じる。
                xlOutLine = xlSWSheet.Outline
                Call xlOutLine.ShowLevels(1, 0)

                ''Sheetを閉じる
                Me.CloseWorkSheet(xlSWSheet)

            End If

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlOutLine, ExcelObjRelease.OBJECT_NOTHING)
            Me.CloseWorkSheet(xlSWSheet)
            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    '''概  要：「SW 追加」出力用のﾃﾞｰﾀを取得
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetAddSWDate(ByRef TBL_SW As DataTable, _
                                  ByVal buyNo As String) As DataRow()

        ''戻り値
        Dim rtnValue() As DataRow
        GetAddSWDate = rtnValue

        ''SQL実行
        Dim SQL_OutSWDate As New StringBuilder
        SQL_OutSWDate.Append("CellNM" & SW_Column.ControlNo)
        SQL_OutSWDate.Append(CommonConstant.SQL_STR_EQUAL)
        SQL_OutSWDate.Append(StringEdit.EncloseSingleQuotation(buyNo))
        SQL_OutSWDate.Append(CommonConstant.SQL_STR_AND)
        SQL_OutSWDate.Append("CellNM" & SW_Column.QTY)
        SQL_OutSWDate.Append(CommonConstant.SQL_STR_NOT)
        SQL_OutSWDate.Append(CommonConstant.SQL_STR_LIKE)
        SQL_OutSWDate.Append(StringEdit.EncloseSingleQuotation("-*"))
        rtnValue = TBL_SW.Select(SQL_OutSWDate.ToString, _
                                ("CellNM" & SW_Column.PSExcelRow) & " , " & _
                                ("CellNM" & SW_Column.IsDetail) & " , " & _
                                ("CellNM" & SW_Column.DetailExcelRow))
        Return rtnValue

    End Function


    ''' <summary>
    '''概  要：「SW 削除」出力用のﾃﾞｰﾀを取得
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetDelSWDate(ByRef TBL_SW As DataTable, _
                                  ByVal buyNo As String) As DataRow()

        ''戻り値
        Dim rtnValue() As DataRow
        GetDelSWDate = rtnValue

        ''SQL実行
        Dim SQL_OutSWDate As New StringBuilder
        SQL_OutSWDate.Append("CellNM" & SW_Column.ControlNo)
        SQL_OutSWDate.Append(CommonConstant.SQL_STR_EQUAL)
        SQL_OutSWDate.Append(StringEdit.EncloseSingleQuotation(buyNo))
        SQL_OutSWDate.Append(CommonConstant.SQL_STR_AND)
        SQL_OutSWDate.Append("CellNM" & SW_Column.QTY)
        SQL_OutSWDate.Append(CommonConstant.SQL_STR_LIKE)
        SQL_OutSWDate.Append(StringEdit.EncloseSingleQuotation("-*"))
        rtnValue = TBL_SW.Select(SQL_OutSWDate.ToString, _
                                ("CellNM" & SW_Column.PSExcelRow) & " , " & _
                                ("CellNM" & SW_Column.IsDetail) & " , " & _
                                ("CellNM" & SW_Column.DetailExcelRow))
        Return rtnValue

    End Function

    ''' <summary>
    '''概  要：SWシートのレイアウトシート情報を出力
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetLayoutInfoSW() As LayoutInfo

        ''初期化
        Dim rtnValue As LayoutInfo
        GetLayoutInfoSW = rtnValue

        ''セットする値
        Dim OutBlockLayout(0) As OutBlockLayoutInfo
        OutBlockLayout = Me.GetDefaultBlockLayout(0)

        ''ﾀｲﾄﾙ行設定
        OutBlockLayout(0).isTitleRow = False
        OutBlockLayout(0).TitleRow = 0
        OutBlockLayout(0).TitlePasteStrIndex = 0

        ''ﾃﾝﾌﾟﾚｰﾄ行の設定
        OutBlockLayout(0).isTmpRow = True
        OutBlockLayout(0).TmplateRow = "4"
        OutBlockLayout(0).TmpPasteStrIndex = 7

        ''項目の出力位置の調整
        OutBlockLayout(0).IsFreeFormat = False
        OutBlockLayout(0).PasteStrIndex = 7
        OutBlockLayout(0).IsChgRefColumn = True
        OutBlockLayout(0).PasteArea = "B@Str:Z@End"
        OutBlockLayout(0).PasteStrClomunsIdx = ExcelWrite.ChgExcelRowCharToNumber("B")
        OutBlockLayout(0).PasteEndClomunsIdx = ExcelWrite.ChgExcelRowCharToNumber("Z")

        Dim SetRef(20, 1) As String

        ''管理番号  
        SetRef(0, 0) = "B"
        SetRef(0, 1) = "CellNM" & SW_Column.DspControlNo

        ''管理名称
        SetRef(1, 0) = "F"
        SetRef(1, 1) = "CellNM" & SW_Column.ControlName

        ''HW MTDL
        SetRef(2, 0) = "G"
        SetRef(2, 1) = "CellNM" & SW_Column.HWMTDL

        ''HW SERIAL
        SetRef(3, 0) = "H"
        SetRef(3, 1) = "CellNM" & SW_Column.HWSerial

        ''Product
        SetRef(4, 0) = "I"
        SetRef(4, 1) = "CellNM" & SW_Column.Product

        ''Description
        SetRef(5, 0) = "J"
        SetRef(5, 1) = "CellNM" & SW_Column.Description

        ''QTY
        SetRef(6, 0) = "K"
        SetRef(6, 1) = "CellNM" & SW_Column.QTY

        ''提供期間_開始
        SetRef(7, 0) = "L"
        SetRef(7, 1) = "CellNM" & SW_Column.OfferStr

        ''提供期間_終了
        SetRef(8, 0) = "M"
        SetRef(8, 1) = "CellNM" & SW_Column.OfferEnd

        ''補足
        SetRef(9, 0) = "N"
        SetRef(9, 1) = "CellNM" & SW_Column.PostScript

        ''確認事項
        SetRef(10, 0) = "P"
        SetRef(10, 1) = "CellNM" & SW_Column.Confirmation

        ''Linno
        SetRef(11, 0) = "Q"
        SetRef(11, 1) = "CellNM" & SW_Column.LineNo

        ''ファイル名
        SetRef(12, 0) = "R"
        SetRef(12, 1) = "CellNM" & SW_Column.FileNM

        ''ファイル名サフィックス
        SetRef(13, 0) = "S"
        SetRef(13, 1) = "CellNM" & SW_Column.FileNMSuffix

        ''ファイル内サフィックス
        SetRef(14, 0) = "T"
        SetRef(14, 1) = "CellNM" & SW_Column.FileIntrSuffix

        ''取り込み元ﾃﾞｰﾀ
        SetRef(15, 0) = "U"
        SetRef(15, 1) = "CellNM" & SW_Column.Item10

        ''仮契約NO
        SetRef(16, 0) = "V"
        SetRef(16, 1) = "CellNM" & SW_Column.Item14

        ''Listprice
        SetRef(17, 0) = "W"
        SetRef(17, 1) = "CellNM" & SW_Column.Listprice

        ''Listprice合計
        SetRef(18, 0) = "X"
        SetRef(18, 1) = "CellNM" & SW_Column.ListpriceSum

        ''D%適用後
        SetRef(19, 0) = "Y"
        SetRef(19, 1) = "CellNM" & SW_Column.DPerPrice

        ''D%適用後合計
        SetRef(20, 0) = "Z"
        SetRef(20, 1) = "CellNM" & SW_Column.DPerPriceSum

        ''値のセット
        OutBlockLayout(0).SetChgRefColumn = SetRef
        rtnValue.OutBlockLayout = OutBlockLayout

        ''戻り値
        Return rtnValue

    End Function

    ''' <summary>
    '''概  要：HWBrandSW_AAS:出力対象ﾃﾞｰﾀのSQL
    '''説  明：※Payment情報の取得
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSQL_PSSW_Output() As String

        ''(パターンCD = 5) Or (パターンCD = 25 And パターン名 = HWBrandSW AAS 削除ﾃﾞｰﾀ)
        Dim rtnValue As New StringBuilder
        rtnValue.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        rtnValue.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        rtnValue.Append("CellNM" & ExcelPaymentLineColumn.PATTERN_CD)
        rtnValue.Append(CommonConstant.SQL_STR_IN)
        rtnValue.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        rtnValue.Append(CommonConstant.PATTERNCD_TYPE_HWBrandSW_AAS)
        rtnValue.Append(CommonConstant.STR_COMMA)
        rtnValue.Append(CommonConstant.PATTERNCD_TYPE_HWBrandSW_QCOS)
        rtnValue.Append(CommonConstant.STR_COMMA)
        rtnValue.Append(CommonConstant.PATTERNCD_TYPE_HWBrandSWMA_AAS)
        rtnValue.Append(CommonConstant.STR_COMMA)
        rtnValue.Append(CommonConstant.PATTERNCD_TYPE_HWBrandSWMA_QCOS)
        rtnValue.Append(CommonConstant.STR_COMMA)
        rtnValue.Append(CommonConstant.PATTERNCD_TYPE_SWBrandSW)
        rtnValue.Append(CommonConstant.STR_COMMA)
        rtnValue.Append(CommonConstant.PATTERNCD_TYPE_SWBrandSWMA)
        rtnValue.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
        rtnValue.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
        rtnValue.Append(CommonConstant.SQL_STR_OR)
        rtnValue.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        rtnValue.Append("CellNM" & ExcelPaymentLineColumn.PATTERN_CD)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNCD_TYPE_DIRECTINPUT))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        rtnValue.Append("CellNM" & ExcelPaymentLineColumn.PATTERN)
        rtnValue.Append(CommonConstant.SQL_STR_LIKE)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_HWBrandSW_AAS & " 削除ﾃﾞｰﾀ*"))
        rtnValue.Append(CommonConstant.SQL_STR_OR)
        rtnValue.Append("CellNM" & ExcelPaymentLineColumn.PATTERN)
        rtnValue.Append(CommonConstant.SQL_STR_LIKE)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_HWBrandSW_QCOS & " 削除ﾃﾞｰﾀ*"))
        rtnValue.Append(CommonConstant.SQL_STR_OR)
        rtnValue.Append("CellNM" & ExcelPaymentLineColumn.PATTERN)
        rtnValue.Append(CommonConstant.SQL_STR_LIKE)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_HWBrandSWMA_AAS & " 削除ﾃﾞｰﾀ*"))
        rtnValue.Append(CommonConstant.SQL_STR_OR)
        rtnValue.Append("CellNM" & ExcelPaymentLineColumn.PATTERN)
        rtnValue.Append(CommonConstant.SQL_STR_LIKE)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_HWBrandSWMA_QCOS & " 削除ﾃﾞｰﾀ*"))
        rtnValue.Append(CommonConstant.SQL_STR_OR)
        rtnValue.Append("CellNM" & ExcelPaymentLineColumn.PATTERN)
        rtnValue.Append(CommonConstant.SQL_STR_LIKE)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_SWBrandSW & " 削除ﾃﾞｰﾀ*"))
        rtnValue.Append(CommonConstant.SQL_STR_OR)
        rtnValue.Append("CellNM" & ExcelPaymentLineColumn.PATTERN)
        rtnValue.Append(CommonConstant.SQL_STR_LIKE)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_SWBrandSWMA & " 削除ﾃﾞｰﾀ*"))
        rtnValue.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
        rtnValue.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
        rtnValue.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append("CellNM" & ExcelPaymentLineColumn.LOCK_FLAG)
        rtnValue.Append(CommonConstant.SQL_STR_NOT_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation("C"))

        Return rtnValue.ToString

    End Function


    ''' <summary>
    '''概  要：HWBrandSW_AAS:出力対象ﾃﾞｰﾀのSQL
    '''説  明：※詳細情報の取得
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSQL_DetailSWOutput(ByRef TmpRow As DataRow) As String

        ''Paymentに紐づく値をセット ※契約順番/ファイル名/ファイル名サフィックス/ﾌｧｲﾙ内サフィックス
        Dim rtnValue As New StringBuilder
        rtnValue.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(TmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT)))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(TmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME)))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(TmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX)))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(TmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR)))

        Return rtnValue.ToString

    End Function


    ''' <summary>
    '''概  要：SWMAﾃｰﾌﾞﾙの取得
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSwmaDataTable() As DataTable

        Dim rtnTable As New DataTable
        Dim con As OleDbConnection
        Dim da As OleDbDataAdapter
        Try
            Dim SQL_SWMA As New StringBuilder

            ''Connection取得
            Dim mmc As New MasterMdbControl
            con = mmc.GetOleDBConnection(CommonVariable.MdbPW)

            ''SQL取得
            ''Select句
            SQL_SWMA.Append(CommonConstant.SQL_STR_SELECT)
            SQL_SWMA.Append(CommonConstant.SQL_STR_ASTERISK)

            ''From句
            SQL_SWMA.Append(CommonConstant.SQL_STR_FROM)
            SQL_SWMA.Append(SwmaTable.TABLE_NAME)

            ''Table取得
            da = New OleDbDataAdapter(SQL_SWMA.ToString(), con)
            Call da.Fill(rtnTable)

            ''戻り値
            Return rtnTable

        Catch ex As Exception
            Throw ex

        Finally
            If Not con Is Nothing Then
                If con.State = ConnectionState.Open Then
                    Call con.Close()
                End If
            End If
            GC.Collect()

        End Try
    End Function


    ''' <summary>
    '''概  要：Codeﾃｰﾌﾞﾙの取得
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetCodeDataTable() As DataTable

        Dim rtnTable As New DataTable
        Dim con As OleDbConnection
        Dim da As OleDbDataAdapter
        Try
            Dim SQL_CODE As New StringBuilder

            ''Connection取得
            Dim mmc As New MasterMdbControl
            con = mmc.GetOleDBConnection(CommonVariable.MdbPW)

            ''SQL取得
            ''Select句
            SQL_CODE.Append(CommonConstant.SQL_STR_SELECT)
            SQL_CODE.Append(CommonConstant.SQL_STR_ASTERISK)

            ''From句
            SQL_CODE.Append(CommonConstant.SQL_STR_FROM)
            SQL_CODE.Append(CodeTable.TABLE_NAME)

            ''Where句
            SQL_CODE.Append(CommonConstant.SQL_STR_WHERE)
            SQL_CODE.Append(CodeTable.COLUMN_NAME_CLASSCODE)
            SQL_CODE.Append(CommonConstant.SQL_STR_EQUAL)
            SQL_CODE.Append(StringEdit.EncloseSingleQuotation("NotSerialHW"))

            ''Table取得
            da = New OleDbDataAdapter(SQL_CODE.ToString(), con)
            Call da.Fill(rtnTable)

            ''戻り値
            Return rtnTable

        Catch ex As Exception
            Throw ex

        Finally
            If Not con Is Nothing Then
                If con.State = ConnectionState.Open Then
                    Call con.Close()
                End If
            End If
            GC.Collect()

        End Try

    End Function

    ''' <summary>
    '''概  要：ﾃﾝﾌﾟﾚｼｰﾄをｺﾋﾟﾍﾟする。
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CopyWorkSheet(ByRef xlAttachedBook As Excel.Workbook, _
                                   ByVal sheetNM As String) As Excel.Worksheet

        Dim xlCopySheet As Excel.Worksheet   ''Copy対象のﾃﾝﾌﾟﾚｼｰﾄ名
        Dim xlPasteSheet As Excel.Worksheet  ''Copyの位置 - 「SW別紙」固定 
        Try
            Select Case sheetNM
                Case SheetNM_Del_SW, _
                     SheetNM_ADD_SW
                    xlCopySheet = SetWorkSheet(xlAttachedBook, "SW別紙")
                    xlCopySheet.Visible = True
                    xlPasteSheet = SetWorkSheet(xlAttachedBook, "SW別紙")
                    xlPasteSheet.Visible = True

                Case SheetNM_Del_PALicence, _
                     SheetNM_ADD_PALicence, _
                     SheetNM_Del_PASSMontly, _
                     SheetNM_ADD_PASSMontly, _
                     SheetNM_Del_PASSFull, _
                     SheetNM_ADD_PASSFull, _
                     SheetNM_Del_PAMedia, _
                     SheetNM_ADD_PAMedia
                    xlCopySheet = SetWorkSheet(xlAttachedBook, "PA別紙")
                    xlCopySheet.Visible = True
                    xlPasteSheet = SetWorkSheet(xlAttachedBook, "SW別紙")
                    xlPasteSheet.Visible = True

                Case SheetNM_Del_VLS, _
                     SheetNM_ADD_VLS
                    xlCopySheet = SetWorkSheet(xlAttachedBook, "VLS別紙")
                    xlCopySheet.Visible = True
                    xlPasteSheet = SetWorkSheet(xlAttachedBook, "SW別紙")
                    xlPasteSheet.Visible = True
            End Select

            ''ｼｰﾄのｺﾋﾟｰ
            Call xlCopySheet.Copy(Before:=xlPasteSheet)
            xlCopySheet.Visible = False
            xlPasteSheet.Visible = False

            ''シートのセット
            xlCopySheet = SetWorkSheet(xlAttachedBook, xlCopySheet.Name & " (2)")
            xlCopySheet.Name = sheetNM

            Return xlCopySheet

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlPasteSheet, ExcelObjRelease.OBJECT_NOTHING)

        End Try

    End Function

#End Region

#End Region

End Class