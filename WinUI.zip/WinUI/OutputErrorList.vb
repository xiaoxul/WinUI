﻿Imports System.IO
Imports System.Text
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility

''' <summary>
''' エラーリスト 
''' 
''' </summary>
''' <remarks></remarks>
Public Class OutputErrorList

#Region "変数"
    Private _CpNo As String
    Private _ContractNo As String
    Private Const OUTPUTERROR_PATH As String = "../log/"
    Private Const ENCODE_SHIFT_JIS As String = "shift-jis"
#End Region

#Region "プロパティ"
    Public Property CpNo As String
        Get
            Return _CpNo
        End Get
        Set(ByVal value As String)
            _CpNo = value
        End Set
    End Property
    Public Property ContractNo As String
        Get
            Return _ContractNo
        End Get
        Set(ByVal value As String)
            _ContractNo = value
        End Set
    End Property
#End Region

#Region "パブリックメソッド"
    Public Sub OutputErrorList(ByVal strErrorMsg As String, ByVal strJob As String, Optional ByVal strRow As String = "", Optional ByVal strCol As String = "", Optional ByVal delFlg As Boolean = False)
        Dim strOutFileName As String = ""
        Dim strOutputPath As String = ""
        Dim strOutputName As String = ""
        Dim logWriter As StreamWriter = Nothing
        System.Environment.CurrentDirectory = Application.StartupPath
        strOutFileName = "ImportExportError" & "_" & Me.CpNo & Me.ContractNo & ".log"
        strOutputPath = System.IO.Path.GetFullPath(OUTPUTERROR_PATH)

        If Directory.Exists(strOutputPath) = False Then
            Directory.CreateDirectory(strOutputPath)
        End If
        strOutputName = strOutputPath & strOutFileName
        If System.IO.File.Exists(strOutputName) Then
            '"ファイルは存在します"

        Else
            '"ファイルは存在しません"
            ' 戻り値を格納する変数を宣言する
            Dim hStream As System.IO.FileStream

            ' hStream が破棄されることを保証するために Try ～ Finally を使用する
            Try
                ' hStream が閉じられることを保証するために Try ～ Finally を使用する
                Try
                    ' 指定したパスのファイルを作成する
                    hStream = System.IO.File.Create(strOutputName)
                Finally
                    ' 作成時に返される FileStream を利用して閉じる
                    If Not hStream Is Nothing Then
                        hStream.Close()
                    End If
                End Try
            Finally
                ' hStream を破棄する
                If Not hStream Is Nothing Then
                    Dim cDisposable As System.IDisposable = hStream
                    cDisposable.Dispose()
                End If
            End Try

        End If
        If delFlg Then
            logWriter = New StreamWriter(strOutputName, False, Encoding.GetEncoding(ENCODE_SHIFT_JIS))
        Else
            logWriter = New StreamWriter(strOutputName, True, Encoding.GetEncoding(ENCODE_SHIFT_JIS))
        End If

        Dim strErrMsg As String = ""
        strErrMsg = Now.ToString("HH:mm:ss") & "," & strJob & "," & strErrorMsg

        If Not strRow.Equals(String.Empty) Then
            strErrMsg = strErrMsg & ",行:" & strRow
        End If

        If Not strCol.Equals(String.Empty) Then
            strErrMsg = strErrMsg & ",列:" & strCol
        End If

        logWriter.WriteLine(strErrMsg)

        ''ファイルオブジェクトの解放
        If IsNothing(logWriter) = False Then
            logWriter.Close()
        End If

    End Sub

    Public Sub OutExportErrorList(ByVal strErrorMsg As String, ByVal strJob As String, Optional ByVal strRow As String = "", Optional ByVal strCol As String = "", Optional ByVal delFlg As Boolean = False)
        Dim strOutFileName As String = ""
        Dim strOutputPath As String = ""
        Dim strOutputName As String = ""
        Dim logWriter As StreamWriter = Nothing
        System.Environment.CurrentDirectory = Application.StartupPath
        strOutFileName = "ExportError" & "_" & Me.CpNo & Me.ContractNo & ".log"
        strOutputPath = System.IO.Path.GetFullPath(OUTPUTERROR_PATH)

        If Directory.Exists(strOutputPath) = False Then
            Directory.CreateDirectory(strOutputPath)
        End If
        strOutputName = strOutputPath & strOutFileName
        If System.IO.File.Exists(strOutputName) Then
            '"ファイルは存在します"

        Else
            '"ファイルは存在しません"
            ' 戻り値を格納する変数を宣言する
            Dim hStream As System.IO.FileStream

            ' hStream が破棄されることを保証するために Try ～ Finally を使用する
            Try
                ' hStream が閉じられることを保証するために Try ～ Finally を使用する
                Try
                    ' 指定したパスのファイルを作成する
                    hStream = System.IO.File.Create(strOutputName)
                Finally
                    ' 作成時に返される FileStream を利用して閉じる
                    If Not hStream Is Nothing Then
                        hStream.Close()
                    End If
                End Try
            Finally
                ' hStream を破棄する
                If Not hStream Is Nothing Then
                    Dim cDisposable As System.IDisposable = hStream
                    cDisposable.Dispose()
                End If
            End Try

        End If
        If delFlg Then
            logWriter = New StreamWriter(strOutputName, False, Encoding.GetEncoding(ENCODE_SHIFT_JIS))
        Else
            logWriter = New StreamWriter(strOutputName, True, Encoding.GetEncoding(ENCODE_SHIFT_JIS))
        End If

        Dim strErrMsg As String = ""
        strErrMsg = Now.ToString("HH:mm:ss") & "," & strJob & "," & strErrorMsg

        If Not strRow.Equals(String.Empty) Then
            strErrMsg = strErrMsg & ",行:" & strRow
        End If

        If Not strCol.Equals(String.Empty) Then
            strErrMsg = strErrMsg & ",列:" & strCol
        End If

        logWriter.WriteLine(strErrMsg)

        ''ファイルオブジェクトの解放
        If IsNothing(logWriter) = False Then
            logWriter.Close()
        End If

    End Sub


    '--------------------------------------------------------
    '概    要  ：Imoprt処理のエラーログを出力する。
    '説    明  ：
    '--------------------------------------------------------
    Public Sub OutImportErrorList(ByVal errorMsg As String,
                                  ByVal job As String,
                                  Optional ByVal Linno As String = "",
                                  Optional ByVal Row As String = "",
                                  Optional ByVal Col As String = "",
                                  Optional ByVal delFlg As Boolean = False)

        Dim outFileName As String = ""
        Dim outputDir As String = ""
        Dim outputPath As String = ""
        Dim logWriter As StreamWriter = Nothing

        ''ファイルの出力先を取得
        System.Environment.CurrentDirectory = Application.StartupPath
        outFileName = "ImportError" & "_" & Me.CpNo & Me.ContractNo & ".log"
        outputDir = System.IO.Path.GetFullPath(OUTPUTERROR_PATH)
        outputPath = outputDir & outFileName

        ''出力先のフォルダがなければ作成
        If Directory.Exists(outputDir) = False Then
            Directory.CreateDirectory(outputDir)
        End If

        If System.IO.File.Exists(outputPath) Then
            'Logファイルが存在する。
        Else
            'Logファイルが存在しない。

            ' 戻り値を格納する変数を宣言する
            Dim hStream As System.IO.FileStream

            ' hStream が破棄されることを保証するために Try ～ Finally を使用する
            Try
                ' hStream が閉じられることを保証するために Try ～ Finally を使用する
                Try
                    ' 指定したパスのファイルを作成する
                    hStream = System.IO.File.Create(outputPath)
                Finally
                    ' 作成時に返される FileStream を利用して閉じる
                    If Not hStream Is Nothing Then
                        hStream.Close()
                    End If
                End Try
            Finally
                ' hStream を破棄する
                If Not hStream Is Nothing Then
                    Dim cDisposable As System.IDisposable = hStream
                    cDisposable.Dispose()
                End If
            End Try
        End If

        ''Logﾌｧｲﾙを上書き or 追記か判定
        If delFlg Then
            logWriter = New StreamWriter(outputPath, False, Encoding.GetEncoding(ENCODE_SHIFT_JIS))
        Else
            logWriter = New StreamWriter(outputPath, True, Encoding.GetEncoding(ENCODE_SHIFT_JIS))
        End If

        ''メッセージ内容の作成
        Dim strErrMsg As String = ""
        strErrMsg = Now.ToString("HH:mm:ss") & "," & job & "," & errorMsg

        If Not Linno.Equals(String.Empty) Then
            strErrMsg = strErrMsg & "行番号:" & Linno
        End If

        If Not Row.Equals(String.Empty) Then
            strErrMsg = strErrMsg & ",行:" & Row
        End If

        If Not Col.Equals(String.Empty) Then
            strErrMsg = strErrMsg & ",列:" & Col
        End If

        ''メッセージの書込
        logWriter.WriteLine(strErrMsg)

        ''ファイルオブジェクトの解放
        If IsNothing(logWriter) = False Then
            logWriter.Close()
        End If

    End Sub

    '--------------------------------------------------------
    '概    要  ：Imoprt処理のエラーログ(個別詳細)を出力する。
    '説    明  ：
    '--------------------------------------------------------
    Public Sub OutImportErrorListDetail(ByVal errorMsg As String,
                                        ByVal job As String,
                                        Optional ByVal fileNm As String = "",
                                        Optional ByVal fileNmSuffix As String = "",
                                        Optional ByVal fileIntrSuffix As String = "",
                                        Optional ByVal seq As String = "",
                                        Optional ByVal delFlg As Boolean = False)

        Dim outFileName As String = ""
        Dim outputDir As String = ""
        Dim outputPath As String = ""
        Dim logWriter As StreamWriter = Nothing

        ''ファイルの出力先を取得
        System.Environment.CurrentDirectory = Application.StartupPath
        outFileName = "ImportError" & "_" & Me.CpNo & Me.ContractNo & ".log"
        outputDir = System.IO.Path.GetFullPath(OUTPUTERROR_PATH)
        outputPath = outputDir & outFileName

        ''出力先のフォルダがなければ作成
        If Directory.Exists(outputDir) = False Then
            Directory.CreateDirectory(outputDir)
        End If

        If System.IO.File.Exists(outputPath) Then
            'Logファイルが存在する。
        Else
            'Logファイルが存在しない。

            ' 戻り値を格納する変数を宣言する
            Dim hStream As System.IO.FileStream

            ' hStream が破棄されることを保証するために Try ～ Finally を使用する
            Try
                ' hStream が閉じられることを保証するために Try ～ Finally を使用する
                Try
                    ' 指定したパスのファイルを作成する
                    hStream = System.IO.File.Create(outputPath)
                Finally
                    ' 作成時に返される FileStream を利用して閉じる
                    If Not hStream Is Nothing Then
                        hStream.Close()
                    End If
                End Try
            Finally
                ' hStream を破棄する
                If Not hStream Is Nothing Then
                    Dim cDisposable As System.IDisposable = hStream
                    cDisposable.Dispose()
                End If
            End Try
        End If

        ''Logﾌｧｲﾙを上書き or 追記か判定
        If delFlg Then
            logWriter = New StreamWriter(outputPath, False, Encoding.GetEncoding(ENCODE_SHIFT_JIS))
        Else
            logWriter = New StreamWriter(outputPath, True, Encoding.GetEncoding(ENCODE_SHIFT_JIS))
        End If

        ''メッセージ内容の作成
        Dim strErrMsg As String = ""
        strErrMsg = Now.ToString("HH:mm:ss") & "," & job & "," & errorMsg

        ''メッセージの内容
        If Not fileNm.Equals(String.Empty) Then
            strErrMsg = strErrMsg & "ﾌｧｲﾙ名:" & fileNm
        End If

        If Not fileNmSuffix.Equals(String.Empty) Then
            strErrMsg = strErrMsg & ",ﾌｧｲﾙ名ｻﾌｨｯｸｽ:" & fileNmSuffix
        End If

        If Not fileIntrSuffix.Equals(String.Empty) Then
            strErrMsg = strErrMsg & ",ﾌｧｲﾙ内ｻﾌｨｯｸｽ:" & fileIntrSuffix
        End If

        If Not seq.Equals(String.Empty) Then
            strErrMsg = strErrMsg & ",SEQ:" & seq
        End If

        ''メッセージの書込
        logWriter.WriteLine(strErrMsg)

        ''ファイルオブジェクトの解放
        If IsNothing(logWriter) = False Then
            logWriter.Close()
        End If

    End Sub

    Public Sub OutputErrorList2(ByVal strErrorMsg As String, ByVal strJob As String, Optional ByVal strRow As String = "", Optional ByVal strCol As String = "", Optional ByVal delFlg As Boolean = False)
        Dim strOutFileName As String = ""
        Dim strOutputPath As String = ""
        Dim strOutputName As String = ""
        Dim logWriter As StreamWriter = Nothing
        System.Environment.CurrentDirectory = Application.StartupPath
        strOutFileName = "BPMakeExchange" & "_" & Me.CpNo & Me.ContractNo & ".log"
        strOutputPath = System.IO.Path.GetFullPath(OUTPUTERROR_PATH)

        If Directory.Exists(strOutputPath) = False Then
            Directory.CreateDirectory(strOutputPath)
        End If
        strOutputName = strOutputPath & strOutFileName
        If System.IO.File.Exists(strOutputName) Then
            '"ファイルは存在します"

        Else
            '"ファイルは存在しません"
            ' 戻り値を格納する変数を宣言する
            Dim hStream As System.IO.FileStream

            ' hStream が破棄されることを保証するために Try ～ Finally を使用する
            Try
                ' hStream が閉じられることを保証するために Try ～ Finally を使用する
                Try
                    ' 指定したパスのファイルを作成する
                    hStream = System.IO.File.Create(strOutputName)
                Finally
                    ' 作成時に返される FileStream を利用して閉じる
                    If Not hStream Is Nothing Then
                        hStream.Close()
                    End If
                End Try
            Finally
                ' hStream を破棄する
                If Not hStream Is Nothing Then
                    Dim cDisposable As System.IDisposable = hStream
                    cDisposable.Dispose()
                End If
            End Try

        End If
        If delFlg Then
            logWriter = New StreamWriter(strOutputName, False, Encoding.GetEncoding(ENCODE_SHIFT_JIS))
        Else
            logWriter = New StreamWriter(strOutputName, True, Encoding.GetEncoding(ENCODE_SHIFT_JIS))
        End If

        Dim strErrMsg As String = ""
        strErrMsg = Now.ToString("HH:mm:ss") & "," & strJob & "," & strErrorMsg

        If Not strRow.Equals(String.Empty) Then
            strErrMsg = strErrMsg & ",行:" & strRow
        End If

        If Not strCol.Equals(String.Empty) Then
            strErrMsg = strErrMsg & ",列:" & strCol
        End If

        logWriter.WriteLine(strErrMsg)

        ''ファイルオブジェクトの解放
        If IsNothing(logWriter) = False Then
            logWriter.Close()
        End If

    End Sub

#End Region

End Class
