﻿Imports System.IO
Imports System.Text
Imports Microsoft.Office.Interop
Imports System.Data.OleDb
Imports MUSE.Utility
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.OioBamaCommmon
Imports MUSE.Utility.UserMessageBox
Imports MUSE.WinUI.OioBamaCommmon
Imports MUSE.Utility.UserDataTable.Master
Imports MUSE.DataAccess.OleDb

Public Class Frm_TmpContractUnification

#Region "構造体"
    ''TreeView表示用のﾃﾞｰﾀ
    Public Structure Trv_ContractInfo_Date
        Dim DispName As String              ''Nodeの表示名
        Dim ContractNo As String            ''契約順番
        Dim Checked As Integer              ''ﾁｪｯｸ済みかどうか                    0:ﾁｪｯｸ済み 1:未ﾁｪｯｸ　2：一部未ﾁｪｯｸ(子供のNodeが存在するときのみ)
        Dim SummaryF As Boolean             ''集計用のNodeかどうか?             　True：集計用Node　False:通常のNode 
        Dim ChildF As Boolean               ''集計用のNodeに紐づくﾃﾞｰﾀかどうか?   True：集計用Nodeに紐づくNode　False:集計用Nodeと関連なし  
        Dim FileExist As Boolean            ''仮契約ﾌｧｲﾙが存在するかどうか？
        Dim FilePath As String              ''仮契約Paymentﾌｧｲﾙのﾊﾟｽ              ※ﾌｧｲﾙがなければ空白ｾｯﾄ
    End Structure

    ''仮契約統合時の貼付範囲のｾｯﾄに使用
    Public Structure PasteArea
        Dim Str_PastePS As Integer                           ''開始位置：Payment
        Dim End_PastePS As Integer                           ''終了位置：Payment
        Dim Area_PastePS As String                           ''貼付範囲：Payment
        Dim Str_PasteDetail As Integer                       ''開始位置：Detail
        Dim End_PasteDetail As Integer                       ''終了位置：Detail
        Dim Area_PasteDetail As String                       ''貼付範囲：Detail
    End Structure

    ''仮契約統合時の貼付範囲のｾｯﾄに使用
    Public Structure UPD_M_CONTRACT_TEMP
        Dim TmpContract As Integer                 ''仮契約番号         
        Dim InPsFileName As String                 ''統合元 PSﾌｧｲﾙ名
        Dim UnifiPSCount As Integer                ''統合件数：PSﾌｧｲﾙ         
        Dim UnifiDetailCount As Integer            ''統合件数：詳細ﾌｧｲﾙ                 
        Dim UnMatchPSCount As Integer              ''Unmatch ：PSﾌｧｲﾙ         
        Dim UnMatchDetailCount As Integer          ''Unmatch ：詳細ﾌｧｲﾙ
    End Structure

    ''Unmatchのサマリｼｰﾄ作成に使用
    Public Structure OutUnmatchSumSheet
        Dim contract As String                      ''契約No                       
        Dim in_PS_Filename As String                ''ファイル名
        Dim update_Date As String                   ''更新日時
        Dim sum_Count As Integer                    ''総行数
        Dim match_Count As Integer                  ''一致件数
        Dim cononly_Unmatchcount As String          ''正契約のみ行数
        Dim tmponly_Unmatchcount As Integer         ''仮契約のみ行数
        Dim keyok_Allcount As Integer               ''Key一致　行数
        Dim keyok_Unmatchcount As Integer           ''Key一致　項目数
    End Structure

#End Region

#Region "列挙体"
    ''Logに書込のフォーマット　
    ''※XXXXXXXは、引数で渡した文言を出力
    Private Enum OutLogKB
        ''タイトル_Str
        OutStr = 1            ''処理_STR
        ActStr                ''仮契約の統合処理を開始します。
        DelStr                ''仮契約の削除処理を開始します。
        UnMStr                ''UnMatchリスト作成処理を開始します。
        ReSetStr              ''仮契約リセット処理を開始します。

        ''サブタイトル
        Titel_Pt1             ''▼正契約情報ファイルの読込処理
        Titel_Pt2             ''▼仮情報ファイルの読込処理
        Titel_Pt3             ''▼正契約情報と仮契約情報をマージ処理
        Titel_Pt4             ''▼Excelﾌｧｲﾙにﾃﾞｰﾀを書込処理
        Titel_Pt5             ''▼MDBの更新処理
        Titel_Pt6             ''▼削除対象ﾃﾞｰﾀの検索処理
        Titel_Pt7             ''▼Excelファイルの削除処理
        Titel_Pt8             ''▼Unmatch情報検索処理

        ''エラーメッセージ
        Normal_Pt1            ''◆完了:XXXXXXXXXX
        Normal_Pt2            ''◆エラー：XXXXXXXXXX
        Normal_Pt3            ''　⇒「XXXXXXXXXXXXX」　　　　※エラー内容
        Normal_Pt4            ''◆　　　⇒仮契約No：
        Normal_Pt5            ''◆以下、XXXXXXXXXXXXの処理
        Normal_Pt6            ''空行

        ''タイトル_End
        ActEnd                ''仮契約の統合処理を終了します。
        DelEnd                ''仮契約の削除処理を終了します。
        UnMEnd                ''UnMatchリスト作成処理を終了します。
        ReSetEnd              ''仮契約リセット処理を終了します。
        OutEnd                ''処理_END
    End Enum

#End Region

#Region "定数"
    ''仮契約一覧の状態表示ラベル
    Private Const Lbl_TreeViewState_UnifiBtnClick As String = "<<統合対象データ表示中>>"
    Private Const Lbl_TreeViewState_DelBtnClick As String = "<<削除対象データ表示中>>"
    Private Const Lbl_TreeViewState_DeffBtnClick As String = "<<Unmatリスト対象データ表示中>>"
    Private Const Lbl_TreeViewState_RefBtnClick As String = "<<ﾘﾌﾚｯｼｭ対象データ表示中>>"

    ''処理選択
    Private Const ActKB_UnificationContract As Integer = 1                           ''仮契約統合開始
    Private Const ActKB_DelContract As Integer = 2                                   ''仮契約削除開始
    Private Const ActKB_ChkContractDeff As Integer = 3                               ''統合正契約チェック開始
    Private Const ActKB_RefContract As Integer = 4                                   ''仮契約リフレッシュ
    Private Const ActKB_DelContract_At As Integer = 5                                ''仮契約削除開始　[@]選択時の処理

    ''仮契約No直接入力の入力区分
    Private Const InputContractKB_Blank As Integer = 1          ''空白入力
    Private Const InputContractKB_Hyhen As Integer = 2          ''[-]入力
    Private Const InputContractKB_Asterisk As Integer = 3       ''[*]入力
    Private Const InputContractKB_Number As Integer = 4         ''数値入力
    Private Const InputContractKB_At As Integer = 5             ''[@]入力

    ''ﾂﾘｰﾋﾞｭｰの選択状態
    Private Const TrvChecked_ON As Integer = 0
    Private Const TrvChecked_OFF As Integer = 1
    Private Const TrvChecked_OTH As Integer = 2

    ''仮契約統合ﾎﾞﾀﾝ押下前のｴﾗｰ区分
    Private Const ErrKB_Alr As String = "警告"
    Private Const ErrKB_Err As String = "ｴﾗｰ"
    Private Const ErrKB_Info As String = "確認"

    ''Payment開始/終了位置
    Private Const Excel_PaymentStrRow As Integer = 6
    Private Const Excel_PaymentEndRow As Integer = 65536

    ''                  ▼MergeTableの追加項目関係
    ''------------------------------------------------------------------
    Private Const MergeTableColumn_ContractKB As String = "ContractKB"            ''MergeTableｾｯﾄ項目：0,正契約ﾌｧｲﾙ 1,仮契約ﾌｧｲﾙ
    Private Const MergeTableColumn_TmpContract As String = "TmpContract"          ''MergeTableｾｯﾄ項目：仮契約番号     ※正契約ﾌｧｲﾙ⇒統合元の仮契約No　仮契約⇒自分の仮契約No
    Private Const MergeTableColumn_ExcelLine As String = "ExcelLine"              ''MergeTableｾｯﾄ項目：元ﾌｧｲﾙのExcleの行位置
    Private Const MergeTableColumn_DelInsert As String = "DelInsert"              ''MergeTableｾｯﾄ項目：0,行削除ﾃﾞｰﾀ 1,行追加ﾃﾞｰﾀ　
    Private Const MergeTableColumn_FileContract As String = "FileContract"        ''MergeTableｾｯﾄ項目：ファイルの契約順番
    Private Const MergeTableColumn_SortContract As String = "SortContract"        ''MergeTableｾｯﾄ項目：Sort用のKey 
    Private Const MergeTableColumn_SortLineNo As String = "SortLineNo"            ''MergeTableｾｯﾄ項目：Sort用のKey
    Private Const MergeTableColumn_ChildCount As String = "ChildCount"            ''MergeTableｾｯﾄ項目：S行の子行が何行存在するか？

    ''MergeTableの追加項目値
    Private Const InputFileKB_Contract As String = "正契約ﾌｧｲﾙ"
    Private Const InputFileKB_TmpContract As String = "仮契約ﾌｧｲﾙ"
    Private Const DelInsert_Insert As String = "Insert"
    Private Const DelInsert_Delete As String = "Delete"
    Private Const DelInsert_None As String = "None"
    Private Const FileName_TmpConstract As String = "_仮契約No:"

    ''                  ▼UnmatchTableの追加項目関係
    ''------------------------------------------------------------------
    Private Const UnmatchTableColumn_UnmatchKB As String = "UnmatchKB"            ''UnmatchTableｾｯﾄ項目：Unmatchの種類       ："正契約"、"Key一致"、"仮契約"
    Private Const UnmatchTableColumn_UnmatchSort As String = "UnmatchSort"        ''UnmatchTableｾｯﾄ項目：Unmatchﾘｽﾄのソート順：0[正契約]、1[Key一致]、2[仮契約]
    Private Const UnmatchTableColumn_UnmatchCount As String = "UnmatchCount"      ''UnmatchTableｾｯﾄ項目：Unmatch項目件数
    Private Const UnmatchTableColumn_IsUnmatchChk As String = "IsUnmatchChk"      ''UnmatchTableｾｯﾄ項目：比較処理済のレコードかどうか?
    Private Const UnmatchTableColumn_UnmatchFileNM As String = "UnmatchFileNM"    ''UnmatchTableｾｯﾄ項目：比較処理済のレコードかどうか?

    ''Unmatchの区分
    Private Const UnmatchKB_KeyOK As String = "Key一致"                          ''Key一致
    Private Const UnmatchKB_KeyNG As String = "Key不一致"                        ''Key不一致
    Private Const UnmatchKB_ConOnly As String = "正契約"                         ''正契約のみ
    Private Const UnmatchKB_TmpOnly As String = "仮契約"                         ''仮契約のみ

    ''Unmatch区分に応じたSort順
    Private Const UnmatchSort_KeyOK As Integer = 0                               ''Key一致
    Private Const UnmatchSort_TmpOnly As Integer = 1                             ''正契約のみ
    Private Const UnmatchSort_ConOnly As Integer = 2                             ''仮契約のみ

    ''IsUnmatchChkの値
    Private Const IsUnmatchChk_ON As String = "Chk_ON"                           ''ﾁｪｯｸ済みかどうか？　※空白の場合、未チェック

    ''Key一致時に、Unmatchの項目の判定に使用
    Private Const UnmatchChar As String = "@@Unmatch@@"                          ''Key一致の場合、どの項目がUnmatchかの判定に使用する。

    ''                  ▼Unmatchリストの追加項目関係
    ''------------------------------------------------------------------
    Private Const SumUnmatchTableColumn_CONTRACT_NO As String = "CONTRACT_NO"                                  ''契約No
    Private Const SumUnmatchTableColumn_IN_PS_FILENAME As String = "IN_PS_FILENAME"                            ''ファイル名
    Private Const SumUnmatchTableColumn_UPDATE_DATE As String = "UPDATE_DATE"                                  ''更新日時
    Private Const SumUnmatchTableColumn_SUM_COUNT As String = "SUM_COUNT"                                      ''総行数
    Private Const SumUnmatchTableColumn_MATCH_COUNT As String = "MATCH_COUNT"                                  ''一致行数
    Private Const SumUnmatchTableColumn_CONONLY_UNMATCHCOUNT As String = "CONONLY_UNMATCHCOUNT"                ''正契約のみ行数
    Private Const SumUnmatchTableColumn_TMPONLY_UNMATCHCOUNT As String = "TMPONLY_UNMATCHCOUNT"                ''仮契約のみ行数
    Private Const SumUnmatchTableColumn_KEYOK_ALLCOUNT As String = "KEYOK_ALLCOUNT"                            ''Key一致 行数
    Private Const SumUnmatchTableColumn_KEYOK_UNMATCHCOUNT As String = "KEYOK_UNMATCHCOUNT"                    ''Key一致 項目数

#End Region

#Region "パブリック変数"
    Public Rtn_ContractFrmBtn As Boolean           ''画面終了時に押下したﾎﾞﾀﾝ:契約登録画面へ
    Public Rtn_LogOutBtn As Boolean                ''画面終了時に押下したﾎﾞﾀﾝ:ログアウトﾎﾞﾀﾝ
#End Region

#Region "プライベート変数"
    Private TBL_M_CONTRACT_BASE As M_CONTRACT_BASETable
    Private TBL_M_CONTRACT_DETAIL As M_CONTRACT_DETAILTable
    Private TBL_M_CONTRACT_TEMP As M_CONTRACT_TEMP

    ''ﾂﾘｰﾋﾞｭｰの展開処理かどうか
    Private isExpand As Boolean
    Private SelContractNo As String             '選択されている正契約順番
#End Region

#Region "コンストラクタ"

    Sub New(ByVal KickForm As String)

        SelContractNo = CommonVariable.CONTRACTNO.ToString("000")

        ''必要なMdbの値をﾛｰｶﾙ変数にｾｯﾄ
        Call GetMdbInfomatino(Me.TBL_M_CONTRACT_BASE, Me.TBL_M_CONTRACT_DETAIL, Me.TBL_M_CONTRACT_TEMP)

        ' この呼び出しはデザイナーで必要です。
        InitializeComponent()

        ''ﾎﾞﾀﾝの名前を変更
        Select Case KickForm
            Case "Menu"
                Me.Btn_RtnFrmContract.Text = "メニューへ"

            Case "Contract"
                Me.Btn_RtnFrmContract.Text = "契約登録画面へ"

        End Select
    End Sub

#End Region

#Region "イベントハンドラ"

    ''' <summary>
    ''' 機能：画面のロード処理
    ''' 説明：※必要なMDBの値は、Load時にMDBからﾛｰｶﾙ変数に保持しておく
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Frm_TmpContractUnification_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Try
            Me.Text = CommonVariable.OBAMATITLE

            ''作業中CPNOに値をセットする
            Me.Lbl_CpNo.Text = CommonVariable.CPNO

            ''ﾗｼﾞｵﾎﾞﾀﾝの選択処理で画面を初期化する。
            Call Me.RdbButtonCheckedChanged(sender, e)

        Catch ex As Exception
            MsgBox(ex.Message, vbCritical, Me.Text)

        End Try

    End Sub

    ''' <summary>
    ''' 機能：ﾗｼﾞｵﾎﾞﾀﾝの変更
    ''' 説明：※「1)処理の選択ｸﾞﾙｰﾌﾟﾎﾞｯｸｽ」内の全てのﾗｼﾞｵﾎﾞｯｸｽのChangeｲﾍﾞﾝﾄを処理する。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub RdbButtonCheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Rdb_UnificationContract.CheckedChanged, _
                                                                                                            Rdb_DelContract.CheckedChanged, _
                                                                                                            Rdb_ChkContractDeff.CheckedChanged, _
                                                                                                            Rdb_RefContract.CheckedChanged

        Try
            ''Checkしたﾗｼﾞｵﾎﾞﾀﾝに応じて画面を初期化する。
            Dim ActKB As Integer
            If Rdb_UnificationContract.Checked Then
                ActKB = Me.ActKB_UnificationContract
            ElseIf Rdb_DelContract.Checked Then
                ActKB = Me.ActKB_DelContract
            ElseIf Rdb_ChkContractDeff.Checked Then
                ActKB = Me.ActKB_ChkContractDeff
            ElseIf Rdb_RefContract.Checked Then
                ActKB = Me.ActKB_RefContract
            End If
            Call InitForm_Rdbutton(ActKB)

        Catch ex As Exception
            Call MsgBox(Prompt:=ex.Message, _
                        Buttons:=MsgBoxStyle.Critical, _
                        Title:=Me.Text)

        End Try

    End Sub


    ''' <summary>
    ''' 機能：契約締結済み/廃案案件の表示の変更
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub ChkDispContract_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChkDispContract.CheckedChanged

        Try
            ''Checkしたﾗｼﾞｵﾎﾞﾀﾝに応じて画面を初期化する。
            Dim ActKB As Integer
            If Rdb_UnificationContract.Checked Then
                ActKB = Me.ActKB_UnificationContract
            ElseIf Rdb_DelContract.Checked Then
                ActKB = Me.ActKB_DelContract
            ElseIf Rdb_ChkContractDeff.Checked Then
                ActKB = Me.ActKB_ChkContractDeff
            ElseIf Rdb_RefContract.Checked Then
                ActKB = Me.ActKB_RefContract
            End If
            Call InitForm_Rdbutton(ActKB)

        Catch ex As Exception
            Call MsgBox(Prompt:=ex.Message, _
                        Buttons:=MsgBoxStyle.Critical, _
                        Title:=Me.Text)

        End Try

    End Sub


    ''' <summary>
    ''' 機能：統合対象正契約Noの変更
    ''' 説明：※ﾂﾘｰﾋﾞｭｰのﾌｧｲﾙ更新日をUpdateする。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Cmb_TmpContract_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_TmpContract.SelectedIndexChanged

        Try

            ''Checkしたﾗｼﾞｵﾎﾞﾀﾝに応じてﾂﾘｰﾋﾞｭｰを更新
            ''※統合の場合、ファイル名の有無の表示を切り替える。
            ''※それ以外の場合、正契約によって削除/ﾁｪｯｸ対象が切り替わるので値を初期化する。
            Dim ActKB As Integer
            If Rdb_UnificationContract.Checked Then
                ActKB = Me.ActKB_UnificationContract
            ElseIf Rdb_DelContract.Checked Then
                ActKB = Me.ActKB_DelContract
            ElseIf Rdb_ChkContractDeff.Checked Then
                ActKB = Me.ActKB_ChkContractDeff
            ElseIf Rdb_RefContract.Checked Then
                ActKB = Me.ActKB_RefContract
            End If

            SelContractNo = Me.Cmb_TmpContract.Text

            Select Case ActKB
                Case Me.ActKB_UnificationContract
                    ''ﾂﾘｰﾋﾞｭｰの情報を更新する。
                    Call Me.UpdDispName_Trv_ContractInfo()

                Case Else
                    ''ﾂﾘｰﾋﾞｭｰを再作成する。
                    Call Init_Trv_ContractInfo(ActKB, _
                                               Me.TBL_M_CONTRACT_DETAIL, _
                                               Me.TBL_M_CONTRACT_TEMP)
            End Select

        Catch ex As Exception
            Call MsgBox(Prompt:=ex.Message, _
                        Buttons:=MsgBoxStyle.Critical, _
                        Title:=Me.Text)

        End Try
    End Sub


    ''' <summary>
    ''' 機能：仮契約No 直接入力　入力ﾁｪｯｸ
    ''' 説明：※特定の文字列以外入力不可にする。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Txb_InputContract_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txb_InputContract.KeyPress

        ''入力許可されている文字コードかどうか判定する。
        ''※[0-9]、[,]、[*]、[-]、[BackSpace]、[Delete]、[矢印]
        If Me.Chk_Txb_InputContract_KeyPress(e) = True Then
            e.Handled = False
        Else
            e.Handled = True
        End If

    End Sub

    ''' <summary>
    ''' 機能：仮契約No 直接入力　入力ﾁｪｯｸ
    ''' 説明：※特定の文字列以外入力不可にする。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Txb_InputContract_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles Txb_InputContract.Leave

        Try
            Dim ErrMsg As String
            ErrMsg = ChkInputTextTxb_InputContract()
            If ErrMsg <> "" Then
                Call MsgBox(Prompt:=ErrMsg, _
                            Buttons:=MsgBoxStyle.Critical, _
                            Title:=Me.Text)
                Me.Txb_InputContract.Select()
            End If

        Catch ex As Exception
            Call MsgBox(Prompt:=ex.Message, _
                        Buttons:=MsgBoxStyle.Critical, _
                        Title:=Me.Text)
        End Try

    End Sub

    ''' <summary>
    ''' 機能：※使用方法の説明ﾎﾞﾀﾝの処理
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Llb_UseInfo_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles Llb_UseInfo.LinkClicked

        Dim msg As String
        msg = GetMsg_Llb_UseInfo_LinkClicked()
        Call MsgBox(Prompt:=msg,
                    Buttons:=MsgBoxStyle.Information,
                    Title:=Me.Text)

    End Sub


    ''' <summary>
    ''' 機能：ﾂﾘｰﾋﾞｭｰのｸﾘｯｸ
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Trv_ContractInfo_NodeMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeNodeMouseClickEventArgs) Handles Trv_ContractInfo.NodeMouseClick

        Try

            ''展開処理以外か判定
            If Me.isExpand = True Then
                Me.isExpand = False

            Else
                'Nodeをセット
                Dim curNode As TreeNode
                curNode = e.Node

                'ﾂﾘ-ﾋﾞｭｰのNode変更
                Call Me.UpdTrv_Trv_ContractInfo_AfterCheck(curNode)

            End If

        Catch ex As Exception
            Call MsgBox(Prompt:=ex.Message, _
                        Buttons:=MsgBoxStyle.Critical, _
                        Title:=Me.Text)

        End Try

    End Sub


    ''' <summary>
    ''' 機能：ﾂﾘｰﾋﾞｭｰの展開
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Trv_ContractInfo_Expand(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewCancelEventArgs) Handles Trv_ContractInfo.BeforeCollapse, _
                                                                                                                                 Trv_ContractInfo.BeforeExpand

        Me.isExpand = True

    End Sub


    ''' <summary>
    ''' 機能：ﾁｪｯｸOnﾎﾞﾀﾝの処理
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Btn_ChkOn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_ChkOn.Click

        Try

            Call Me.ChgTrv_ContractInfo_Btn_ChkOnOff(Me.TrvChecked_ON)

        Catch ex As Exception

            Call MsgBox(Prompt:=ex.Message, _
                        Buttons:=MsgBoxStyle.Critical, _
                        Title:=Me.Text)
        End Try

    End Sub

    ''' <summary>
    ''' 機能：ﾁｪｯｸOffﾎﾞﾀﾝの処理
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Btn_ChkOff_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_ChkOff.Click

        Call Me.ChgTrv_ContractInfo_Btn_ChkOnOff(Me.TrvChecked_OFF)

    End Sub


    ''' <summary>
    ''' 機能：一覧更新ボタンの処理
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Btn_UpdTrv_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Try

            ''必要なMdbの値をﾛｰｶﾙ変数にｾｯﾄ
            Call GetMdbInfomatino(Me.TBL_M_CONTRACT_BASE, Me.TBL_M_CONTRACT_DETAIL, Me.TBL_M_CONTRACT_TEMP)

            ''ﾂﾘｰﾋﾞｭｰを更新する。
            Call UpdDispName_Trv_ContractInfo()

        Catch ex As Exception
            MsgBox(ex.Message, vbCritical, Me.Text)

        End Try

    End Sub


    ''' <summary>
    ''' 機能：※仮契約一覧の説明の処理
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Llb_TmpInfo_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles Llb_TmpInfo.LinkClicked

        Dim msg As String
        msg = GetMsg_Llb_TmpInfo_LinkClicked()
        Call MsgBox(Prompt:=msg,
                    Buttons:=MsgBoxStyle.Information,
                    Title:=Me.Text)

    End Sub


    ''' <summary>
    ''' 機能：仮契約統合ボタンの処理
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Btn_UnificationContract_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Btn_UnificationContract.Click

        Try
            '契約締結済み/廃案案件
            Dim blnRet As Boolean
            blnRet = CheckStatus()
            If blnRet = False Then
                Exit Sub
            End If

            '契約順番セット
            CommonVariable.CONTRACTNO = Integer.Parse(Cmb_TmpContract.Text)

            '仮契約統合ボタンの処理
            Call Main_Btn_UnificationContract()

        Catch ex As Exception
            Call MsgBox(Prompt:=ex.Message, _
                        Buttons:=MsgBoxStyle.Critical, _
                        Title:=Me.Text)
        End Try

    End Sub

    ''' <summary>
    ''' 機能：仮契約削除ボタンの処理
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Btn_DelContract_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_DelContract.Click

        Try
            '契約締結済み/廃案案件
            Dim blnRet As Boolean
            blnRet = CheckStatus()
            If blnRet = False Then
                Exit Sub
            End If

            '仮契約削除ボタンの処理
            Call Main_Btn_DelContract()

        Catch ex As Exception
            Call MsgBox(Prompt:=ex.Message, _
                        Buttons:=MsgBoxStyle.Critical, _
                        Title:=Me.Text)
        End Try

    End Sub

    ''' <summary>
    ''' 機能：統合正契約チェックボタンの処理
    ''' 説明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Btn_ChkContractDeff_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_ChkContractDeff.Click

        Try
            '契約締結済み/廃案案件
            Dim blnRet As Boolean
            blnRet = CheckStatus()
            If blnRet = False Then
                Exit Sub
            End If

            '統合正契約チェックボタンの処理
            Call Main_Btn_ChkContractDeff()

        Catch ex As Exception
            Call MsgBox(Prompt:=ex.Message, _
                        Buttons:=MsgBoxStyle.Critical, _
                        Title:=Me.Text)
        End Try

    End Sub

    ''' <summary>
    '''概  要：ﾘﾌﾚｯｼｭﾎﾞﾀﾝの処理
    '''説  明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Btn_ReSetContract_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_ReSetContract.Click

        Try

            ''画面でチェックしたデータが１件もなければ、警告する。
            Dim isChecked As Boolean = False
            Dim contractItem As Trv_ContractInfo_Date
            Dim contractList As ArrayList
            contractList = Me.GetAListtDate_NotPrentTrv_ContractInfo
            For Each contractItem In contractList
                If contractItem.Checked = Me.TrvChecked_ON Then
                    isChecked = True
                End If
            Next
            If isChecked = False Then
                Call MsgBox(Prompt:=FileReader.GetMessage("MSG_0368"), _
                            Buttons:=MsgBoxStyle.Exclamation, _
                            Title:=Me.Text)
                Exit Sub
            End If

            ''確認ﾒｯｾｰｼﾞを取得
            Dim result As Integer
            Dim msg As String
            Dim msgIcon As MessageBoxIcon
            Dim msgButton As MessageBoxButtons
            Call GetMessageReSetContract(msg, msgIcon, msgButton)

            ''画面の入力値をセット
            Dim IsContractEnd As Boolean = False            ''処理後、契約締結済にするかどうか？
            Dim isTmpContractCmbAst As Boolean = False      ''画面の正契約が[*]かどうか？
            Dim isSuffixZero As Boolean = False             ''Suffixを初期化するかどうか?
            If Me.Cmb_TmpContract.Text = "*" Then
                isTmpContractCmbAst = True
            End If

            ''ﾒｯｾｰｼﾞﾎﾞｯｸｽで押下したボタンに応じて、処理を変更する。
            result = MessageBox.Show(msg, Me.Text, msgButton, msgIcon)
            Select Case result
                Case Windows.Forms.DialogResult.Yes

                    ''正契約[*]の場合、[契約締結済み/Suffix = 初期化]
                    If isTmpContractCmbAst = True Then
                        IsContractEnd = False
                    Else
                        IsContractEnd = True
                    End If
                    Call Main_Btn_ReSetContract(IsContractEnd, isTmpContractCmbAst)

                Case Windows.Forms.DialogResult.No
                    IsContractEnd = False
                    If isTmpContractCmbAst = True Then
                        Exit Sub
                    End If
                    Call Main_Btn_ReSetContract(IsContractEnd, isTmpContractCmbAst)

                Case Windows.Forms.DialogResult.Cancel
                    Exit Sub

            End Select

            ''MDBの値を取得して画面をリフレッシュ
            Call GetMdbInfomatino(Me.TBL_M_CONTRACT_BASE, Me.TBL_M_CONTRACT_DETAIL, Me.TBL_M_CONTRACT_TEMP)
            Call InitForm_Rdbutton(Me.ActKB_RefContract)

            ''処理の完了ﾒｯｾｰｼﾞ
            Call MsgBox(Prompt:=FileReader.GetMessage("MSG_0384"), _
                        Buttons:=MsgBoxStyle.Information, _
                        Title:=Me.Text)

        Catch ex As Exception
            Call MsgBox(Prompt:=ex.Message, _
                        Buttons:=MsgBoxStyle.Critical, _
                        Title:=Me.Text)
        End Try

    End Sub

    ''' <summary>
    ''' 機能：フォルダ表示
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Btn_DispFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_DispFolder.Click

        ''正契約の入力ﾁｪｯｸ
        Dim AlrMsg_001 As String = FileReader.GetMessage("MSG_0367")            ''画面_統合正契約Noが未入力
        If Me.Cmb_TmpContract.Text = "" Or Me.Cmb_TmpContract.Text = "*" Then
            MsgBox(AlrMsg_001, MsgBoxStyle.Critical, "")
            Exit Sub
        End If

        ''統合反映作成フォルダの存在ﾁｪｯｸし、なければフォルダを作成する。
        Dim ofm As New OioFileManage
        Dim chkFolder As String
        chkFolder = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CInt(Me.Cmb_TmpContract.Text)) & "\" & "統合用仮契約"
        If Directory.Exists(chkFolder) = False Then
            Call Directory.CreateDirectory(chkFolder)
        End If

        ''Explorer表示
        If ofm.DispExplorer(CommonConstant.FOLDERNAME_EXCEL, CommonVariable.CPNO, CInt(Me.Cmb_TmpContract.Text)) = False Then
            MsgBox(FileReader.GetMessage("MSG_0208"), MsgBoxStyle.Exclamation, "")
        End If
    End Sub


    ''' <summary>
    ''' 機能：画面のﾘﾌﾚｯｼｭ
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Btn_RefFrm_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_RefFrm.Click

        If MessageBox.Show(FileReader.GetMessage("MSG_0373"), Me.Text, MessageBoxButtons.OKCancel, MessageBoxIcon.Information) = Windows.Forms.DialogResult.OK Then

            ''画面初期化処理
            ''MDBの再LOAD
            Call GetMdbInfomatino(Me.TBL_M_CONTRACT_BASE, Me.TBL_M_CONTRACT_DETAIL, Me.TBL_M_CONTRACT_TEMP)

            ''テキストボックスの初期化
            Txb_InputContract.Text = ""

            ''仮契約一覧の更新
            Me.UpdDispName_Trv_ContractInfo()

        End If

    End Sub


    ''' <summary>
    ''' 機能：ﾛｸﾞｱｳﾄﾎﾞﾀﾝ
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub BtnLogOut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnLogOut.Click
        Me.Rtn_LogOutBtn = True
        Call Me.Close()
    End Sub


    ''' <summary>
    ''' 機能：ﾛｸﾞｱｳﾄﾎﾞﾀﾝ
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Btn_RtnFrmContract_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_RtnFrmContract.Click
        Me.Rtn_ContractFrmBtn = True
        Call Me.Close()
    End Sub

#End Region

#Region "パブリックメソッド"


#End Region

#Region "プライベートメソッド"

#Region "SQL関係"

    ''' <summary>
    ''' 機能：CPNOをKeyに契約情報を取得する。
    ''' 説明：※必要なMDBの値は、Load時にMDBからﾛｰｶﾙ変数に保持しておく
    ''' </summary>
    ''' <param name="TBL_M_CONTRACT_BASE"></param>
    ''' <param name="TBL_M_CONTRACT_DETAIL"></param>
    ''' <param name="TBL_M_CONTRACT_TEMP"></param>
    ''' <remarks></remarks>
    Private Sub GetMdbInfomatino(ByRef TBL_M_CONTRACT_BASE As M_CONTRACT_BASETable, _
                                 ByRef TBL_M_CONTRACT_DETAIL As M_CONTRACT_DETAILTable, _
                                 ByRef TBL_M_CONTRACT_TEMP As M_CONTRACT_TEMP)

        Dim wc As New WebDb.WebDbCommon
        Dim strMsg As String = ""
        Dim blnRet As Boolean


        Try
            ''初期化
            TBL_M_CONTRACT_BASE = New M_CONTRACT_BASETable
            TBL_M_CONTRACT_DETAIL = New M_CONTRACT_DETAILTable
            TBL_M_CONTRACT_TEMP = New M_CONTRACT_TEMP

            '認証設定
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW

            '契約基本情報取得
            blnRet = wc.GetContractBaseData(CommonVariable.CPNO, TBL_M_CONTRACT_BASE, strMsg)
            If blnRet = False Then
                Throw New Exception(strMsg)
                Exit Sub
            End If

            '契約詳細情報取得
            blnRet = wc.GetContractDetailData(CommonVariable.CPNO, TBL_M_CONTRACT_DETAIL, strMsg)
            If blnRet = False Then
                Throw New Exception(strMsg)
                Exit Sub
            End If

            '仮契約情報取得
            blnRet = wc.GetContractTempData(CommonVariable.CPNO, TBL_M_CONTRACT_TEMP, strMsg)
            If blnRet = False Then
                Throw New Exception(strMsg)
                Exit Sub
            End If

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' 機能：ｺﾝﾎﾞﾎﾞｯｸｽ：統合対象正契約Noへｾｯﾄするﾃﾞｰﾀを抽出用SQL　
    ''' 説明：
    ''' </summary>
    ''' <param name="IsChkDispContract"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetSql_SelectCmb_TmpContract_1(ByVal IsChkDispContract As Boolean) As String

        ''初期化
        GetSql_SelectCmb_TmpContract_1 = ""

        ''Select句   ※DataTableのSelectなので不要
        ''Where句
        Dim rtnSQL As New StringBuilder
        rtnSQL.Append(M_CONTRACT_DETAILTable.COLUMN_NAME_STATUS)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation("0"))

        ''画面_契約締結済み/廃案案件の表示がOnになっていれば、締結済/廃案も出力する。
        If IsChkDispContract = True Then
            rtnSQL.Append(CommonConstant.SQL_STR_OR)

            ''ステータス:契約済み/廃案
            rtnSQL.Append(M_CONTRACT_DETAILTable.COLUMN_NAME_STATUS)
            rtnSQL.Append(CommonConstant.SQL_STR_IN)
            rtnSQL.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            rtnSQL.Append(StringEdit.EncloseSingleQuotation("1"))
            rtnSQL.Append(CommonConstant.STR_COMMA)
            rtnSQL.Append(StringEdit.EncloseSingleQuotation("2"))
            rtnSQL.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

        End If
        Return rtnSQL.ToString()

    End Function


    ''' <summary>
    ''' 機能：ｺﾝﾎﾞﾎﾞｯｸｽ：統合対象正契約Noへｾｯﾄするﾃﾞｰﾀを抽出用SQL　
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_SelectCmb_TmpContract_2() As String

        ''初期化
        GetSql_SelectCmb_TmpContract_2 = ""

        ''Select句   ※DataTableのSelectなので不要
        ''Where句
        Dim rtnSQL As New StringBuilder
        rtnSQL.Append(M_CONTRACT_TEMP.COLUMN_NAME_STATUS)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation("1"))

        Return rtnSQL.ToString()

    End Function


    ''' <summary>
    ''' 機能：ｺﾝﾎﾞﾎﾞｯｸｽ：統合対象正契約Noへｾｯﾄするﾃﾞｰﾀを抽出用SQL　
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_SelectCmb_TmpContract_3() As String

        ''初期化
        GetSql_SelectCmb_TmpContract_3 = ""

        ''Select句   ※DataTableのSelectなので不要
        ''Where句
        Dim rtnSQL As New StringBuilder
        rtnSQL.Append(M_CONTRACT_TEMP.COLUMN_NAME_STATUS)
        rtnSQL.Append(CommonConstant.SQL_STR_IN)
        rtnSQL.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation("1"))
        rtnSQL.Append(CommonConstant.STR_COMMA)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation("2"))
        rtnSQL.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

        Return rtnSQL.ToString()

    End Function

    ''' <summary>
    ''' 機能：ﾂﾘｰﾋﾞｭｰ初期化時の抽出ﾃﾞｰﾀを取得
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSelect_InitDate_Trv_ContractInfo_1(ByVal isDetail As Boolean, _
                                                           ByVal isDispContractCheck As Boolean) As String

        ''初期化
        GetSelect_InitDate_Trv_ContractInfo_1 = ""

        Dim rtnSQL As New StringBuilder
        If isDetail = True Then

            ''契約詳細データから仮契約取得
            ''Where句
            rtnSQL.Append(M_CONTRACT_DETAILTable.COLUMN_NAME_STATUS)
            rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
            rtnSQL.Append(StringEdit.EncloseSingleQuotation("3"))
            If isDispContractCheck = True Then
                rtnSQL.Append(CommonConstant.SQL_STR_OR)
                rtnSQL.Append(CommonConstant.STR_LEFT_PARENTHESIS)

                ''ステータス:契約済み/廃案
                rtnSQL.Append(M_CONTRACT_DETAILTable.COLUMN_NAME_STATUS)
                rtnSQL.Append(CommonConstant.SQL_STR_IN)
                rtnSQL.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                rtnSQL.Append(StringEdit.EncloseSingleQuotation("1"))
                rtnSQL.Append(CommonConstant.STR_COMMA)
                rtnSQL.Append(StringEdit.EncloseSingleQuotation("2"))
                rtnSQL.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                rtnSQL.Append(CommonConstant.SQL_STR_AND)

                ''仮契約:800 - 990
                rtnSQL.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                rtnSQL.Append(M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_NO)
                rtnSQL.Append(" >= ")
                rtnSQL.Append(StringEdit.EncloseSingleQuotation("800"))
                rtnSQL.Append(CommonConstant.SQL_STR_AND)
                rtnSQL.Append(M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_NO)
                rtnSQL.Append(" <= ")
                rtnSQL.Append(StringEdit.EncloseSingleQuotation("990"))
                rtnSQL.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                rtnSQL.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
            End If
        Else

            ''仮契約データから統合済仮契約取得
            rtnSQL.Append(M_CONTRACT_TEMP.COLUMN_NAME_STATUS)
            rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
            rtnSQL.Append(StringEdit.EncloseSingleQuotation("1"))
            rtnSQL.Append(CommonConstant.SQL_STR_AND)
            rtnSQL.Append(M_CONTRACT_TEMP.COLUMN_NAME_OUT_CONTRACT_NO)
            rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
            rtnSQL.Append(StringEdit.EncloseSingleQuotation(Me.Cmb_TmpContract.Text))

        End If
        Return rtnSQL.ToString()

    End Function


    ''' <summary>
    ''' 機能：ﾂﾘｰﾋﾞｭｰ初期化時の抽出ﾃﾞｰﾀを取得
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSelect_InitDate_Trv_ContractInfo_2(ByVal isAsterisk As Boolean) As String

        ''初期化
        GetSelect_InitDate_Trv_ContractInfo_2 = ""

        Dim rtnSQL As New StringBuilder
        ''仮契約データから統合済仮契約取得
        rtnSQL.Append(M_CONTRACT_TEMP.COLUMN_NAME_STATUS)
        rtnSQL.Append(CommonConstant.SQL_STR_IN)
        rtnSQL.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation("1"))
        rtnSQL.Append(CommonConstant.STR_COMMA)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation("2"))
        rtnSQL.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

        ''[*]なら、全件表示
        If isAsterisk = False Then
            rtnSQL.Append(CommonConstant.SQL_STR_AND)
            rtnSQL.Append(M_CONTRACT_TEMP.COLUMN_NAME_OUT_CONTRACT_NO)
            rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
            rtnSQL.Append(StringEdit.EncloseSingleQuotation(Me.Cmb_TmpContract.Text))
        End If
        Return rtnSQL.ToString()

    End Function


    ''' <summary>
    ''' 機能：ﾂﾘｰﾋﾞｭｰ初期化時の抽出ﾃﾞｰﾀを取得
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSelect_InitDate_Trv_ContractInfo_3(ByVal isDispContractCheck As Boolean) As String

        ''初期化
        GetSelect_InitDate_Trv_ContractInfo_3 = ""


        ''契約詳細データから正契約取得
        ''Where句
        Dim rtnSQL As New StringBuilder
        rtnSQL.Append(M_CONTRACT_DETAILTable.COLUMN_NAME_STATUS)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation("0"))

        ''画面で締結済/廃案表示の場合、表示させる。
        If isDispContractCheck = True Then
            rtnSQL.Append(CommonConstant.SQL_STR_OR)
            rtnSQL.Append(M_CONTRACT_DETAILTable.COLUMN_NAME_STATUS)
            rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
            rtnSQL.Append(StringEdit.EncloseSingleQuotation("1"))
            rtnSQL.Append(CommonConstant.SQL_STR_OR)
            rtnSQL.Append(M_CONTRACT_DETAILTable.COLUMN_NAME_STATUS)
            rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
            rtnSQL.Append(StringEdit.EncloseSingleQuotation("2"))
        End If
        Return rtnSQL.ToString()

    End Function

    ''' <summary>
    ''' 機能：統合済みの正契約の存在ﾁｪｯｸを行う。
    ''' 説明：※仮契約統合前ﾁｪｯｸで使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Function Get_Sql_ExistsUniContractNo(ByVal CmbValue As String) As String

        ''初期化
        Get_Sql_ExistsUniContractNo = ""

        ''SQL取得
        Dim rtnValue As New StringBuilder
        rtnValue.Append(M_CONTRACT_TEMP.COLUMN_NAME_OUT_CONTRACT_NO)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(CmbValue))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(M_CONTRACT_TEMP.COLUMN_NAME_STATUS)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation("1"))

        ''戻り値
        Return rtnValue.ToString

    End Function


    ''' <summary>
    ''' 機能：統合済みの仮契約の存在ﾁｪｯｸを行う。
    ''' 説明：※仮契約統合前ﾁｪｯｸで使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Function Get_Sql_ExistsUniTmpConstractNo(ByVal cmbValue As String, _
                                                     ByVal In_Contract_No As String) As String

        ''初期化
        Get_Sql_ExistsUniTmpConstractNo = ""

        ''SQLｾｯﾄ
        Dim rtnValue As New StringBuilder
        rtnValue.Append(M_CONTRACT_TEMP.COLUMN_NAME_OUT_CONTRACT_NO)
        rtnValue.Append(CommonConstant.SQL_STR_NOT_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(cmbValue))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(M_CONTRACT_TEMP.COLUMN_NAME_IN_CONTRACT_NO)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(In_Contract_No))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(M_CONTRACT_TEMP.COLUMN_NAME_STATUS)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation("1"))

        ''戻り値
        Return rtnValue.ToString

    End Function


    ''' <summary>
    ''' 機能：削除対象になった正契約情報を取得する。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_DelMergePaymentTable() As String

        ''初期化
        GetSql_DelMergePaymentTable = ""

        ''Where句
        Dim rtnSQL As New StringBuilder
        rtnSQL.Append(Me.MergeTableColumn_DelInsert)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(Me.DelInsert_Delete))

        Return rtnSQL.ToString()

    End Function


    ''' <summary>
    ''' 機能：削除対象になる詳細ﾃﾞｰﾀを取得
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_DelMergeDetailTable(ByVal Key_CONTRACTKB As String, _
                                                ByVal Key_FILE_NAME As String, _
                                                ByVal Key_FILE_NAME_SUFFIX As String, _
                                                ByVal Key_FILE_NAME_SUFFIX_INTR As String) As String

        ''初期化
        GetSql_DelMergeDetailTable = ""

        ''Where句
        Dim rtnSQL As New StringBuilder
        rtnSQL.Append(MergeTableColumn_ContractKB)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(Key_CONTRACTKB))
        rtnSQL.Append(CommonConstant.SQL_STR_AND)
        rtnSQL.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(Key_FILE_NAME))
        rtnSQL.Append(CommonConstant.SQL_STR_AND)
        rtnSQL.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(Key_FILE_NAME_SUFFIX))
        rtnSQL.Append(CommonConstant.SQL_STR_AND)
        rtnSQL.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(Key_FILE_NAME_SUFFIX_INTR))

        Return rtnSQL.ToString()

    End Function


    ''' <summary>
    ''' 機能：削除対象の仮契約ﾃﾞｰﾀを取得
    ''' 説明：※GetArrayInExcelDelPaymentDataで使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Function Get_Sql_DeleteMergePaymentTable() As String

        ''初期化
        Get_Sql_DeleteMergePaymentTable = ""

        ''SQL取得
        Dim rtnValue As New StringBuilder
        rtnValue.Append(MergeTableColumn_DelInsert)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(Me.DelInsert_Delete))

        ''戻り値
        Return rtnValue.ToString

    End Function


    ''' <summary>
    ''' 機能：削除対象の仮契約ﾃﾞｰﾀを取得
    ''' 説明：※GetArrayInExcelDelPaymentDataで使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Function Get_Sql_DeleteMergeDetailTable() As String

        ''初期化
        Get_Sql_DeleteMergeDetailTable = ""

        ''SQL取得
        Dim rtnValue As New StringBuilder
        rtnValue.Append(MergeTableColumn_DelInsert)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(Me.DelInsert_Delete))

        ''戻り値
        Return rtnValue.ToString

    End Function


    ''' <summary>
    ''' 機能：
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_GetContractOutPaymentData() As String

        ''初期化
        GetSql_GetContractOutPaymentData = ""

        ''SQLｾｯﾄ
        Dim rtnSQL As New StringBuilder
        rtnSQL.Append(MergeTableColumn_DelInsert)
        rtnSQL.Append(CommonConstant.SQL_STR_NOT_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(Me.DelInsert_Delete))
        rtnSQL.Append(CommonConstant.SQL_STR_AND)
        rtnSQL.Append(MergeTableColumn_ContractKB)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(Me.InputFileKB_TmpContract))

        Return rtnSQL.ToString()

    End Function


    ''' <summary>
    ''' 機能：
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_GetContractOutDetailData() As String

        ''初期化
        GetSql_GetContractOutDetailData = ""

        ''SQLｾｯﾄ
        Dim rtnSQL As New StringBuilder
        rtnSQL.Append(MergeTableColumn_DelInsert)
        rtnSQL.Append(CommonConstant.SQL_STR_NOT_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(Me.DelInsert_Delete))
        rtnSQL.Append(CommonConstant.SQL_STR_AND)
        rtnSQL.Append(MergeTableColumn_ContractKB)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(Me.InputFileKB_TmpContract))

        Return rtnSQL.ToString()

    End Function


    ''' <summary>
    ''' 機能：正契約で、「削除対象」以外のPaymentﾃﾞｰﾀを取得
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_GetPaymentXlsPasteArea_1() As String

        ''初期化
        GetSql_GetPaymentXlsPasteArea_1 = ""

        ''SQLｾｯﾄ
        Dim rtnSQL As New StringBuilder
        rtnSQL.Append(MergeTableColumn_DelInsert)
        rtnSQL.Append(CommonConstant.SQL_STR_NOT_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(Me.DelInsert_Delete))
        rtnSQL.Append(CommonConstant.SQL_STR_AND)
        rtnSQL.Append(MergeTableColumn_ContractKB)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(Me.InputFileKB_Contract))

        Return rtnSQL.ToString()

    End Function


    ''' <summary>
    ''' 機能：正契約で、「削除対象」以外の詳細ﾃﾞｰﾀを取得
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_GetDetailXlsPasteArea_1() As String

        ''初期化
        GetSql_GetDetailXlsPasteArea_1 = ""

        ''SQLｾｯﾄ
        Dim rtnSQL As New StringBuilder
        rtnSQL.Append(MergeTableColumn_DelInsert)
        rtnSQL.Append(CommonConstant.SQL_STR_NOT_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(Me.DelInsert_Delete))
        rtnSQL.Append(CommonConstant.SQL_STR_AND)
        rtnSQL.Append(MergeTableColumn_ContractKB)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(Me.InputFileKB_Contract))

        Return rtnSQL.ToString()

    End Function


    ''' <summary>
    ''' 機能：仮契約で、「削除対象」以外のPaymentﾃﾞｰﾀを取得
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_GetPaymentXlsPasteArea_2() As String

        ''初期化
        GetSql_GetPaymentXlsPasteArea_2 = ""

        ''SQLｾｯﾄ
        Dim rtnSQL As New StringBuilder
        rtnSQL.Append(MergeTableColumn_DelInsert)
        rtnSQL.Append(CommonConstant.SQL_STR_NOT_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(Me.DelInsert_Delete))
        rtnSQL.Append(CommonConstant.SQL_STR_AND)
        rtnSQL.Append(MergeTableColumn_ContractKB)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(Me.InputFileKB_TmpContract))

        Return rtnSQL.ToString()

    End Function


    ''' <summary>
    ''' 機能：仮契約で、「削除対象」以外の詳細ﾃﾞｰﾀを取得
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_GetDetailXlsPasteArea_2() As String

        ''初期化
        GetSql_GetDetailXlsPasteArea_2 = ""

        ''SQLｾｯﾄ
        Dim rtnSQL As New StringBuilder
        rtnSQL.Append(MergeTableColumn_DelInsert)
        rtnSQL.Append(CommonConstant.SQL_STR_NOT_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(Me.DelInsert_Delete))
        rtnSQL.Append(CommonConstant.SQL_STR_AND)
        rtnSQL.Append(MergeTableColumn_ContractKB)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(Me.InputFileKB_TmpContract))
        Return rtnSQL.ToString()

    End Function

    ''' <summary>
    ''' 機能：更新Flg = U、有効/無効Flg =Cのデータ取得用SQL
    ''' 説明：※締結済データのLinnoの重複チェックに使用
    ''' 　　　※EXCELにて使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_DistinctContractDelMacroDate() As String

        ''初期化
        GetSql_DistinctContractDelMacroDate = ""

        ''SQLｾｯﾄ
        Dim rtnSQL As New StringBuilder
        rtnSQL.Append(MergeTableColumn_DelInsert)
        rtnSQL.Append(CommonConstant.SQL_STR_NOT_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(Me.DelInsert_Delete))
        rtnSQL.Append(CommonConstant.SQL_STR_AND)
        rtnSQL.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation("U"))
        rtnSQL.Append(CommonConstant.SQL_STR_AND)
        rtnSQL.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation("C"))
        Return rtnSQL.ToString()

    End Function


    ''' <summary>
    ''' 機能：統合元仮契約有りのﾃﾞｰﾀを取得　
    ''' 説明：※ファイル名で判定
    ''' 　　　※EXCELにて使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_SelPaymentDate_UnmatchTable_1() As String

        ''初期化
        GetSql_SelPaymentDate_UnmatchTable_1 = ""

        ''SQL取得
        Dim rtnValue As New StringBuilder
        rtnValue.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME)
        rtnValue.Append(CommonConstant.SQL_STR_LIKE)
        rtnValue.Append(StringEdit.EncloseSingleQuotation("*_仮契約No:*"))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG)
        rtnValue.Append(CommonConstant.SQL_STR_NOT_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation("C"))

        ''戻り値
        Return rtnValue.ToString

    End Function


    ''' <summary>
    ''' 機能：正契約と一致するﾃﾞｰﾀを検索する。
    ''' 説明：※仮契約_Linno = 正契約_項目14 で判定する。
    ''' 　　　※EXCELにて使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_SelPaymentDate_UnmatchTable_2(ByRef row As DataRow) As String

        ''初期化
        GetSql_SelPaymentDate_UnmatchTable_2 = ""

        ''SQL取得
        Dim rtnValue As New StringBuilder
        rtnValue.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM14)))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(UnmatchTableColumn_IsUnmatchChk)
        rtnValue.Append(" IS NULL")

        ''戻り値
        Return rtnValue.ToString

    End Function

    ''' <summary>
    ''' 機能：ﾁｪｯｸ済みの仮契約かどうか？
    ''' 説明：
    ''' 　　　※EXCELにて使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_SelPaymentDate_UnmatchTable_3() As String

        ''初期化
        GetSql_SelPaymentDate_UnmatchTable_3 = ""

        ''SQL取得
        Dim rtnValue As New StringBuilder
        rtnValue.Append(UnmatchTableColumn_IsUnmatchChk)
        rtnValue.Append(" IS NULL")
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG)
        rtnValue.Append(CommonConstant.SQL_STR_NOT_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation("C"))

        ''戻り値
        Return rtnValue.ToString

    End Function


    ''' <summary>
    ''' 機能：統合元仮契約有りのﾃﾞｰﾀを取得　
    ''' 説明：※ファイル名で判定
    ''' 　　　※EXCELにて使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_SelDetailDate_UnmatchTable_1() As String

        ''初期化
        GetSql_SelDetailDate_UnmatchTable_1 = ""

        ''SQL取得
        Dim rtnValue As New StringBuilder
        rtnValue.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME)
        rtnValue.Append(CommonConstant.SQL_STR_LIKE)
        rtnValue.Append(StringEdit.EncloseSingleQuotation("*_仮契約No:*"))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG)
        rtnValue.Append(CommonConstant.SQL_STR_NOT_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation("C"))

        ''戻り値
        Return rtnValue.ToString

    End Function


    ''' <summary>
    ''' 機能：正契約と一致するﾃﾞｰﾀを検索する。
    ''' 説明：※ﾌｧｲﾙ名/ﾌｧｲﾙ名Suffix/ﾌｧｲﾙ内Suffix
    ''' 　　　※EXCELにて使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_SelDetailDate_UnmatchTable_2(ByRef row As DataRow) As String

        ''初期化
        GetSql_SelDetailDate_UnmatchTable_2 = ""

        ''SQL取得
        Dim rtnValue As New StringBuilder
        rtnValue.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME)))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX)))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR)))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.SEQ)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.SEQ)))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(UnmatchTableColumn_UnmatchKB)
        rtnValue.Append(" IS NULL")

        ''戻り値
        Return rtnValue.ToString

    End Function


    ''' <summary>
    ''' 機能：正契約と一致するﾃﾞｰﾀを検索する。
    ''' 説明：※ﾌｧｲﾙ名/ﾌｧｲﾙ名Suffix/ﾌｧｲﾙ内Suffix
    ''' 　　　※EXCELにて使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_SelDetailDate_UnmatchTable_2_2(ByRef row As DataRow) As String

        ''初期化
        GetSql_SelDetailDate_UnmatchTable_2_2 = ""

        ''SQL取得
        Dim rtnValue As New StringBuilder
        rtnValue.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME)))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX)))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR)))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.SEQ)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.SEQ)))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(UnmatchTableColumn_UnmatchKB)
        rtnValue.Append(" IS NULL")


        ''戻り値
        Return rtnValue.ToString

    End Function


    ''' <summary>
    ''' 機能：ﾁｪｯｸ済みの仮契約かどうか？
    ''' 説明：
    ''' 　　　※EXCELにて使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_SelDetailDate_UnmatchTable_3() As String

        ''初期化
        GetSql_SelDetailDate_UnmatchTable_3 = ""

        ''SQL取得
        Dim rtnValue As New StringBuilder
        rtnValue.Append(UnmatchTableColumn_IsUnmatchChk)
        rtnValue.Append(" IS NULL")
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG)
        rtnValue.Append(CommonConstant.SQL_STR_NOT_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation("C"))

        ''戻り値
        Return rtnValue.ToString

    End Function


    ''' <summary>
    ''' 機能：総行数
    ''' 説明：※Umnatchﾘｽﾄのｻﾏﾘｰｼｰﾄの出力件数を取得
    ''' 　　　※EXCELにて使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_SelUnmTbl_SumCount() As String

        ''初期化
        GetSql_SelUnmTbl_SumCount = ""

        ''Where句 
        Dim rtnSQL As New StringBuilder
        rtnSQL.Append(UnmatchTableColumn_UnmatchKB)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(UnmatchKB_KeyOK))
        rtnSQL.Append(CommonConstant.SQL_STR_OR)
        rtnSQL.Append(UnmatchTableColumn_UnmatchKB)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(UnmatchKB_KeyNG))
        rtnSQL.Append(CommonConstant.SQL_STR_OR)
        rtnSQL.Append(UnmatchTableColumn_UnmatchKB)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(UnmatchKB_ConOnly))
        rtnSQL.Append(CommonConstant.SQL_STR_OR)
        rtnSQL.Append(UnmatchTableColumn_UnmatchKB)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(UnmatchKB_TmpOnly))

        Return rtnSQL.ToString

    End Function


    ''' <summary>
    ''' 機能：一致行数
    ''' 説明：※Umnatchﾘｽﾄのｻﾏﾘｰｼｰﾄの出力件数を取得
    ''' 　　　※EXCELにて使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_SelUnmTbl_MatchCount() As String

        ''初期化
        GetSql_SelUnmTbl_MatchCount = ""

        ''Where句　　
        Dim rtnSQL As New StringBuilder
        rtnSQL.Append(UnmatchTableColumn_UnmatchKB)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(UnmatchKB_KeyOK))

        Return rtnSQL.ToString

    End Function


    ''' <summary>
    ''' 機能：Key一致　行数
    ''' 説明：※Umnatchﾘｽﾄのｻﾏﾘｰｼｰﾄの出力件数を取得
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_SelUnmTbl_KeyOK() As String

        ''初期化
        GetSql_SelUnmTbl_KeyOK = ""

        ''Where句
        Dim rtnSQL As New StringBuilder
        rtnSQL.Append(UnmatchTableColumn_UnmatchKB)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(UnmatchKB_KeyNG))

        Return rtnSQL.ToString

    End Function


    ''' <summary>
    ''' 機能：正契約のみ
    ''' 説明：※Umnatchﾘｽﾄのｻﾏﾘｰｼｰﾄの出力件数を取得
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_SelUnmTbl_ConOnly() As String

        ''初期化
        GetSql_SelUnmTbl_ConOnly = ""

        ''Where句
        Dim rtnSQL As New StringBuilder
        rtnSQL.Append(UnmatchTableColumn_UnmatchKB)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(UnmatchKB_ConOnly))

        Return rtnSQL.ToString

    End Function


    ''' <summary>
    ''' 機能：仮契約のみ
    ''' 説明：※Umnatchﾘｽﾄのｻﾏﾘｰｼｰﾄの出力件数を取得
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_SelDUnmTbl_ConOnly() As String

        ''初期化
        GetSql_SelDUnmTbl_ConOnly = ""

        ''Where句
        Dim rtnSQL As New StringBuilder
        rtnSQL.Append(UnmatchTableColumn_UnmatchKB)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(UnmatchKB_ConOnly))

        Return rtnSQL.ToString

    End Function


    ''' <summary>
    ''' 機能：仮契約のみ
    ''' 説明：※Umnatchﾘｽﾄのｻﾏﾘｰｼｰﾄの出力件数を取得
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_SelUnmTbl_TmpOnly() As String

        ''初期化
        GetSql_SelUnmTbl_TmpOnly = ""

        ''Where句
        Dim rtnSQL As New StringBuilder
        rtnSQL.Append(UnmatchTableColumn_UnmatchKB)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(UnmatchKB_TmpOnly))

        Return rtnSQL.ToString

    End Function


    ''' <summary>
    ''' 機能：更新日時
    ''' 説明：※Umnatchﾘｽﾄのｻﾏﾘｰｼｰﾄの出力件数を取得
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_SelUnmTbl_UpdDate(ByVal Cpno As String, _
                                              ByVal OutContract As Integer, _
                                              ByVal InContract As Integer) As String

        ''初期化
        GetSql_SelUnmTbl_UpdDate = ""

        ''Where句
        Dim rtnSQL As New StringBuilder
        rtnSQL.Append(M_CONTRACT_TEMP.COLUMN_NAME_CPNO)
        rtnSQL.Append(CommonConstant.STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(Cpno))
        rtnSQL.Append(CommonConstant.SQL_STR_AND)
        rtnSQL.Append(M_CONTRACT_TEMP.COLUMN_NAME_OUT_CONTRACT_NO)
        rtnSQL.Append(CommonConstant.STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(OutContract.ToString.PadLeft(3, "0")))
        rtnSQL.Append(CommonConstant.SQL_STR_AND)
        rtnSQL.Append(M_CONTRACT_TEMP.COLUMN_NAME_IN_CONTRACT_NO)
        rtnSQL.Append(CommonConstant.STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(InContract.ToString.PadLeft(3, "0")))

        Return rtnSQL.ToString

    End Function


    ''' <summary>
    ''' 機能：更新日時
    ''' 説明：※Umnatchﾘｽﾄのｻﾏﾘｰｼｰﾄの出力件数を取得
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_SelPSUnmTbl_UpdDate(ByVal Cpno As String, _
                                                ByVal OutContract As Integer) As String

        ''初期化
        GetSql_SelPSUnmTbl_UpdDate = ""

        ''Where句
        Dim rtnSQL As New StringBuilder
        rtnSQL.Append(M_CONTRACT_TEMP.COLUMN_NAME_CPNO)
        rtnSQL.Append(CommonConstant.STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(Cpno))
        rtnSQL.Append(CommonConstant.SQL_STR_AND)
        rtnSQL.Append(M_CONTRACT_TEMP.COLUMN_NAME_OUT_CONTRACT_NO)
        rtnSQL.Append(CommonConstant.STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(OutContract.ToString.PadLeft(3, "0")))

        Return rtnSQL.ToString

    End Function



    ''' <summary>
    ''' 機能：総行数
    ''' 説明：※Umnatchﾘｽﾄのｻﾏﾘｰｼｰﾄの出力件数を取得
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_SelDUnmTbl_SumCount() As String

        ''初期化
        GetSql_SelDUnmTbl_SumCount = ""

        ''Where句 
        Dim rtnSQL As New StringBuilder
        rtnSQL.Append(UnmatchTableColumn_UnmatchKB)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(UnmatchKB_KeyOK))
        rtnSQL.Append(CommonConstant.SQL_STR_OR)
        rtnSQL.Append(UnmatchTableColumn_UnmatchKB)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(UnmatchKB_KeyNG))
        rtnSQL.Append(CommonConstant.SQL_STR_OR)
        rtnSQL.Append(UnmatchTableColumn_UnmatchKB)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(UnmatchKB_ConOnly))
        rtnSQL.Append(CommonConstant.SQL_STR_OR)
        rtnSQL.Append(UnmatchTableColumn_UnmatchKB)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(UnmatchKB_TmpOnly))

        Return rtnSQL.ToString

    End Function


    ''' <summary>
    ''' 機能：一致行数
    ''' 説明：※Umnatchﾘｽﾄのｻﾏﾘｰｼｰﾄの出力件数を取得
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_SelDUnmTbl_MatchCount() As String

        ''初期化
        GetSql_SelDUnmTbl_MatchCount = ""

        ''Where句　　※全行数の出力なので、Where句不要
        Dim rtnSQL As New StringBuilder
        rtnSQL.Append(UnmatchTableColumn_UnmatchKB)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(UnmatchKB_KeyOK))

        Return rtnSQL.ToString

    End Function


    ''' <summary>
    ''' 機能：仮契約のみ
    ''' 説明：※Umnatchﾘｽﾄのｻﾏﾘｰｼｰﾄの出力件数を取得
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_SelDUnmTbl_TmpOnly() As String

        ''初期化
        GetSql_SelDUnmTbl_TmpOnly = ""

        ''Where句
        Dim rtnSQL As New StringBuilder
        rtnSQL.Append(UnmatchTableColumn_UnmatchKB)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(UnmatchKB_TmpOnly))

        Return rtnSQL.ToString

    End Function


    ''' <summary>
    ''' 機能：Key一致　行数
    ''' 説明：※Umnatchﾘｽﾄのｻﾏﾘｰｼｰﾄの出力件数を取得
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_SelDUnmTbl_KeyOK() As String

        ''初期化
        GetSql_SelDUnmTbl_KeyOK = ""

        ''Where句
        Dim rtnSQL As New StringBuilder
        rtnSQL.Append(UnmatchTableColumn_UnmatchKB)
        rtnSQL.Append(CommonConstant.SQL_STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(UnmatchKB_KeyNG))

        Return rtnSQL.ToString

    End Function


    ''' <summary>
    ''' 機能：更新日時
    ''' 説明：※Umnatchﾘｽﾄのｻﾏﾘｰｼｰﾄの出力件数を取得
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_SelDUnmTbl_UpdDate(ByVal Cpno As String, _
                                               ByVal OutContract As Integer, _
                                               ByVal InContract As Integer) As String

        ''初期化
        GetSql_SelDUnmTbl_UpdDate = ""

        ''Where句
        Dim rtnSQL As New StringBuilder
        rtnSQL.Append(M_CONTRACT_TEMP.COLUMN_NAME_CPNO)
        rtnSQL.Append(CommonConstant.STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(Cpno))
        rtnSQL.Append(CommonConstant.SQL_STR_AND)
        rtnSQL.Append(M_CONTRACT_TEMP.COLUMN_NAME_OUT_CONTRACT_NO)
        rtnSQL.Append(CommonConstant.STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(OutContract.ToString.PadLeft(3, "0")))
        rtnSQL.Append(CommonConstant.SQL_STR_AND)
        rtnSQL.Append(M_CONTRACT_TEMP.COLUMN_NAME_IN_CONTRACT_NO)
        rtnSQL.Append(CommonConstant.STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(InContract.ToString.PadLeft(3, "0")))

        Return rtnSQL.ToString

    End Function


    ''' <summary>
    ''' 機能：更新日時
    ''' 説明：※Umnatchﾘｽﾄのｻﾏﾘｰｼｰﾄの出力件数を取得
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_SelDPSUnmTbl_UpdDate(ByVal Cpno As String, _
                                                 ByVal OutContract As Integer) As String

        ''初期化
        GetSql_SelDPSUnmTbl_UpdDate = ""

        ''Where句
        Dim rtnSQL As New StringBuilder
        rtnSQL.Append(M_CONTRACT_TEMP.COLUMN_NAME_CPNO)
        rtnSQL.Append(CommonConstant.STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(Cpno))
        rtnSQL.Append(CommonConstant.SQL_STR_AND)
        rtnSQL.Append(M_CONTRACT_TEMP.COLUMN_NAME_OUT_CONTRACT_NO)
        rtnSQL.Append(CommonConstant.STR_EQUAL)
        rtnSQL.Append(StringEdit.EncloseSingleQuotation(OutContract.ToString.PadLeft(3, "0")))


        Return rtnSQL.ToString

    End Function

#End Region

#Region "画面の制御"

    ''' <summary>
    ''' 機能：ﾗｼﾞｵﾎﾞﾀﾝの値に応じて画面を初期化する。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InitForm_Rdbutton(ByVal ActKB As Integer)

        Try

            Select Case ActKB
                Case Me.ActKB_UnificationContract

                    ''有効/無効の設定
                    Me.Cmb_TmpContract.Enabled = True                                ''統合対象正契約No
                    Me.Grp_003.Enabled = True                                        ''3)統合または削除可能　仮契約一覧選択
                    Me.Btn_UnificationContract.Enabled = True                        ''仮契約統合開始
                    Me.Btn_DelContract.Enabled = False                               ''仮契約削除開始
                    Me.Btn_ChkContractDeff.Enabled = False                           ''統合正契約チェック開始
                    Me.Btn_ReSetContract.Enabled = False                             ''仮契約リフレッシュ

                    ''ラベルの名称変更
                    Me.Lbl_Unification.Text = "統合正契約No"                         ''統合正契約No
                    Me.Lbl_TreeViewState.Text = Lbl_TreeViewState_UnifiBtnClick      ''仮契約一覧の状態表示

                    ''ｺﾝﾎﾞﾎﾞｯｸｽの初期化
                    Call Me.Init_Cmb_TmpContract(Me.ActKB_UnificationContract, _
                                                 Me.TBL_M_CONTRACT_DETAIL, _
                                                 Me.TBL_M_CONTRACT_TEMP,
                                                 Me.ChkDispContract.Checked)             ''統合正契約No

                    ''ﾂﾘｰﾋﾞｭｰ初期化
                    Call Init_Trv_ContractInfo(ActKB, _
                                               Me.TBL_M_CONTRACT_DETAIL, _
                                               Me.TBL_M_CONTRACT_TEMP)

                Case Me.ActKB_DelContract

                    ''有効/無効の設定
                    Me.Cmb_TmpContract.Enabled = True                                ''統合対象正契約No
                    Me.Grp_003.Enabled = True                                        ''3)統合または削除可能　仮契約一覧選択
                    Me.Btn_UnificationContract.Enabled = False                       ''仮契約統合開始
                    Me.Btn_DelContract.Enabled = True                                ''仮契約削除開始
                    Me.Btn_ChkContractDeff.Enabled = False                           ''統合正契約チェック開始
                    Me.Btn_ReSetContract.Enabled = False                               ''仮契約リフレッシュ

                    ''ラベルの名称変更
                    Me.Lbl_Unification.Text = "削除対象正契約No"                     ''統合正契約No
                    Me.Lbl_TreeViewState.Text = Lbl_TreeViewState_DelBtnClick        ''仮契約一覧の状態表示


                    ''ｺﾝﾎﾞﾎﾞｯｸｽの初期化
                    Call Me.Init_Cmb_TmpContract(Me.ActKB_DelContract, _
                                                 Me.TBL_M_CONTRACT_DETAIL, _
                                                 Me.TBL_M_CONTRACT_TEMP,
                                                 Me.ChkDispContract.Checked)             ''統合正契約No

                    ''ﾂﾘｰﾋﾞｭｰ初期化
                    Call Init_Trv_ContractInfo(ActKB, _
                                               Me.TBL_M_CONTRACT_DETAIL, _
                                               Me.TBL_M_CONTRACT_TEMP)

                Case Me.ActKB_ChkContractDeff

                    ''有効/無効の設定
                    Me.Cmb_TmpContract.Enabled = True                                ''統合対象正契約No
                    Me.Grp_003.Enabled = True                                        ''3)統合または削除可能　仮契約一覧選択
                    Me.Btn_UnificationContract.Enabled = False                       ''仮契約統合開始
                    Me.Btn_DelContract.Enabled = False                               ''仮契約削除開始
                    Me.Btn_ChkContractDeff.Enabled = True                            ''統合正契約チェック開始
                    Me.Btn_ReSetContract.Enabled = False                               ''仮契約リフレッシュ

                    ''ラベルの名称変更
                    Me.Lbl_Unification.Text = "ﾁｪｯｸ対象正契約No"                     ''統合正契約No
                    Me.Lbl_TreeViewState.Text = Lbl_TreeViewState_DeffBtnClick       ''仮契約一覧の状態表示

                    ''ｺﾝﾎﾞﾎﾞｯｸｽの初期化
                    Call Me.Init_Cmb_TmpContract(Me.ActKB_ChkContractDeff, _
                                                 Me.TBL_M_CONTRACT_DETAIL, _
                                                 Me.TBL_M_CONTRACT_TEMP,
                                                 Me.ChkDispContract.Checked)             ''統合正契約No

                    ''ﾂﾘｰﾋﾞｭｰ初期化
                    Call Init_Trv_ContractInfo(ActKB, _
                                               Me.TBL_M_CONTRACT_DETAIL, _
                                               Me.TBL_M_CONTRACT_TEMP)
                Case Me.ActKB_RefContract

                    ''有効/無効の設定
                    Me.Cmb_TmpContract.Enabled = True                                ''統合対象正契約No
                    Me.Grp_003.Enabled = True                                        ''3)統合または削除可能　仮契約一覧選択
                    Me.Btn_UnificationContract.Enabled = False                       ''仮契約統合開始
                    Me.Btn_DelContract.Enabled = False                               ''仮契約削除開始
                    Me.Btn_ChkContractDeff.Enabled = False                           ''統合正契約チェック開始
                    Me.Btn_ReSetContract.Enabled = True                                ''仮契約リフレッシュ

                    ''ｺﾝﾎﾞﾎﾞｯｸｽの初期化
                    Call Me.Init_Cmb_TmpContract(ActKB, _
                                                 Me.TBL_M_CONTRACT_DETAIL, _
                                                 Me.TBL_M_CONTRACT_TEMP,
                                                 Me.ChkDispContract.Checked)             ''統合正契約No

                    ''ラベルの名称変更
                    Me.Lbl_Unification.Text = Me.Lbl_Unification.Text                ''統合正契約No
                    Me.Lbl_TreeViewState.Text = Lbl_TreeViewState_RefBtnClick        ''仮契約一覧の状態表示

                    ''ﾂﾘｰﾋﾞｭｰ初期化
                    Call Init_Trv_ContractInfo(ActKB, _
                                               Me.TBL_M_CONTRACT_DETAIL, _
                                               Me.TBL_M_CONTRACT_TEMP)

            End Select

        Catch ex As Exception
            Throw ex

        End Try

    End Sub


    ''' <summary>
    ''' 機能：統合対象正契約Noの初期化
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Init_Cmb_TmpContract(ByVal ActKB As Integer, _
                                     ByRef TBL_M_CONTRACT_DETAIL As M_CONTRACT_DETAILTable, _
                                     ByRef TBL_M_CONTRACT_TEMP As M_CONTRACT_TEMP, _
                                     ByVal IsChkDispContract As Boolean)

        Try

            ''変数の宣言
            Dim IdxCmbItems As Integer                    ''ｺﾝﾎﾞﾎﾞｯｸｽに追加するMax数
            Dim Sql_SelectCmb_TmpContract As String       ''SQL：ｺﾝﾎﾞﾎﾞｯｸｽ追加ﾃﾞｰﾀの絞込
            Dim tmpRows_1() As DataRow                    ''一時変数：ｺﾝﾎﾞﾎﾞｯｸｽ追加ﾃﾞｰﾀ格納
            Dim tmpRows_2() As DataRow                    ''一時変数：ｺﾝﾎﾞﾎﾞｯｸｽ追加ﾃﾞｰﾀ格納
            Dim rows() As DataRow                         ''ｺﾝﾎﾞﾎﾞｯｸｽ追加ﾃﾞｰﾀ格納
            Dim ItemNM As String

            ''ｺﾝﾎﾞﾎﾞｯｸｽ初期化
            Call Me.Cmb_TmpContract.Items.Clear()

            ''処理区分に応じて、ﾃﾞｰﾀの抽出元を変更する。
            Select Case ActKB
                Case Me.ActKB_UnificationContract

                    Sql_SelectCmb_TmpContract = GetSql_SelectCmb_TmpContract_1(IsChkDispContract)
                    rows = TBL_M_CONTRACT_DETAIL.Select(Sql_SelectCmb_TmpContract, TBL_M_CONTRACT_DETAIL.COLUMN_NAME_CONTRACT_NO)
                    ItemNM = M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_NO

                Case Me.ActKB_DelContract, _
                     Me.ActKB_ChkContractDeff

                    Sql_SelectCmb_TmpContract = GetSql_SelectCmb_TmpContract_1(IsChkDispContract)
                    tmpRows_1 = TBL_M_CONTRACT_DETAIL.Select(Sql_SelectCmb_TmpContract, TBL_M_CONTRACT_DETAIL.COLUMN_NAME_CONTRACT_NO)

                    Sql_SelectCmb_TmpContract = GetSql_SelectCmb_TmpContract_2()
                    tmpRows_2 = TBL_M_CONTRACT_TEMP.Select(Sql_SelectCmb_TmpContract, M_CONTRACT_TEMP.COLUMN_NAME_OUT_CONTRACT_NO)

                    rows = Me.GetExistsDetailRows(tmpRows_1, tmpRows_2)
                    ItemNM = M_CONTRACT_TEMP.COLUMN_NAME_OUT_CONTRACT_NO

                Case Me.ActKB_RefContract

                    Sql_SelectCmb_TmpContract = GetSql_SelectCmb_TmpContract_1(IsChkDispContract)
                    tmpRows_1 = TBL_M_CONTRACT_DETAIL.Select(Sql_SelectCmb_TmpContract, TBL_M_CONTRACT_DETAIL.COLUMN_NAME_CONTRACT_NO)

                    Sql_SelectCmb_TmpContract = GetSql_SelectCmb_TmpContract_3()
                    tmpRows_2 = TBL_M_CONTRACT_TEMP.Select(Sql_SelectCmb_TmpContract, M_CONTRACT_TEMP.COLUMN_NAME_OUT_CONTRACT_NO)

                    rows = Me.GetExistsDetailRows(tmpRows_1, tmpRows_2)
                    ItemNM = M_CONTRACT_TEMP.COLUMN_NAME_OUT_CONTRACT_NO

            End Select
            IdxCmbItems = rows.Length

            ''ｺﾝﾎﾞﾎﾞｯｸｽに値をｾｯﾄ
            Dim combBoxItems As New ArrayList             ''ｺﾝﾎﾞﾎﾞｯｸｽに追加する文言           
            For Each row As DataRow In rows
                If combBoxItems.IndexOf(row.Item(ItemNM).ToString.PadLeft(3, "0")) = -1 Then
                    Call combBoxItems.Add((row.Item(ItemNM).ToString.PadLeft(3, "0")))
                End If
            Next
            Call combBoxItems.Sort()

            ''仮契約ﾘﾌﾚｯｼｭの場合、[*]を追加
            If ActKB = Me.ActKB_RefContract Then
                Call combBoxItems.Insert(0, "*")
            End If

            Me.Cmb_TmpContract.Items.AddRange(combBoxItems.ToArray(GetType(Object)))
            If combBoxItems.Count <> 0 Then
                If IsNumeric(SelContractNo) = True Then
                    '仮契約順番の場合、初期値
                    If Integer.Parse(SelContractNo) >= 800 And Integer.Parse(SelContractNo) <= 989 Then
                        SelContractNo = Me.Cmb_TmpContract.Items(0)
                    Else
                        If Me.Cmb_TmpContract.Items.IndexOf(SelContractNo) = -1 Then
                            SelContractNo = Me.Cmb_TmpContract.Items(0)
                        End If
                    End If
                Else
                    If Me.Cmb_TmpContract.Items.IndexOf(SelContractNo) = -1 Then
                        SelContractNo = Me.Cmb_TmpContract.Items(0)
                    End If
                End If
                Me.Cmb_TmpContract.Text = SelContractNo
            End If

        Catch ex As Exception
            Throw ex

        End Try

    End Sub


    ''' <summary>
    ''' 機能：※使用方法の説明ﾎﾞﾀﾝ押下時のﾒｯｾｰｼﾞを取得
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetMsg_Llb_UseInfo_LinkClicked() As String

        ''初期化
        GetMsg_Llb_UseInfo_LinkClicked = ""

        Dim rtnValue As String
        rtnValue = "「仮契約一覧」の選択方法について" & vbCrLf & _
                   "" & vbCrLf & _
                   "　①「仮契約No 直接入力」で選択" & vbCrLf & _
                   "    ⇒ﾎﾞﾀﾝの説明" & vbCrLf & _
                   "    　・「ﾁｪｯｸ済」を押すと、ﾃｷｽﾄﾎﾞｯｸｽで入力した仮契約をﾁｪｯｸ" & vbCrLf & _
                   "    　・「未ﾁｪｯｸ」を押すと、ﾃｷｽﾄﾎﾞｯｸｽで入力した仮契約のﾁｪｯｸを外す" & vbCrLf & _
                   "" & vbCrLf & _
                   "    ⇒ﾃｷｽﾄの入力方法" & vbCrLf & _
                   "    　・「*」入力で、すべて選択" & vbCrLf & _
                   "    　・「800-810」を入力すると、800-810まで範囲選択" & vbCrLf & _
                   "    　・「,」で区切ると、複数の範囲の選択が可能 " & vbCrLf & _
                   "    　　※例） 800-810,815-820,825-835" & vbCrLf & _
                   "" & vbCrLf & _
                   "　②「マウスクリック」で選択" & vbCrLf & _
                   "    ・ｸﾞﾙｰﾌﾟの親番号(800-810等)をチェックすると、子番号が全てチェック" & vbCrLf & _
                   "    ・ｸﾞﾙｰﾌﾟの親番号(800-810等)をチェックを外すと、子番号が全てチェックを外す"

        Return rtnValue

    End Function


    ''' <summary>
    ''' 機能：※仮契一覧の説明ﾎﾞﾀﾝ押下時のﾒｯｾｰｼﾞを取得
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetMsg_Llb_TmpInfo_LinkClicked() As String

        ''初期化
        GetMsg_Llb_TmpInfo_LinkClicked = ""

        ''ﾗｼﾞｵﾎﾞﾀﾝに応じてﾒｯｾｰｼﾞを変更
        Dim rtnValue As String
        If Rdb_UnificationContract.Checked Then
            rtnValue = "仮契約統合処理" & vbCrLf & _
                       "　<<表示対象データ>>" & vbCrLf & _
                       "　　・契約情報登録画面で、「仮契約」で登録したﾃﾞｰﾀ" & vbCrLf & _
                       "" & vbCrLf & _
                       "  <<必要な事前作業>>" & vbCrLf & _
                       "　　・データの登録　　：契約情報登録画面で、統合先の「正契約」を登録" & vbCrLf & _
                       "　　・データの登録　　：契約情報登録画面で、統合元の「仮契約」を登録" & vbCrLf & _
                       "　　・ファイルのセット：「EXCEL」フォルダに正契約の最新のPS/詳細ファイルが存在する" & vbCrLf & _
                       "　　・ファイルのセット：「統合用仮契約」フォルダに仮契約ファイルをセット"

        ElseIf Rdb_DelContract.Checked Then
            rtnValue = "仮契約削除処理" & vbCrLf & _
                       "　<<表示対象データ>>" & vbCrLf & _
                       "　　・JRI画面で「仮契約統合」した、仮契約ﾃﾞｰﾀ" & vbCrLf & _
                       "　　・JRI画面で「仮契約削除」していない、仮契約ﾃﾞｰﾀ" & vbCrLf & _
                       "" & vbCrLf & _
                       "　<<必要な事前作業>>" & vbCrLf & _
                       "　　・データの登録　：JRI画面で「仮契約統合」を実行" & vbCrLf & _
                       "　　・ファイルのセット：「EXCEL」フォルダに正契約の最新のPS/詳細ファイルが存在する" & vbCrLf & _
                       "　　　※補足：「統合用仮契約」フォルダに仮契約ファイルは不要"

        ElseIf Rdb_ChkContractDeff.Checked Then
            rtnValue = "仮契約正契約ﾁｪｯｸ処理" & vbCrLf & _
                       "　<<表示対象データ>>" & vbCrLf & _
                       "　　・JRI画面で「仮契約統合」した、仮契約ﾃﾞｰﾀ" & vbCrLf & _
                       "　　・JRI画面で「仮契約削除」していない、仮契約ﾃﾞｰﾀ" & vbCrLf & _
                       "" & vbCrLf & _
                       "　<<必要な事前作業>>" & vbCrLf & _
                       "　　・データの登録　：JRI画面で「仮契約統合」を実行" & vbCrLf & _
                       "　　・ファイルのセット：「EXCEL」フォルダに正契約の最新のPS/詳細ファイルが存在する" & vbCrLf & _
                       "　　・ファイルのセット：「統合用仮契約」フォルダに仮契約ファイルをセット"

        ElseIf Rdb_RefContract.Checked Then
            rtnValue = "仮契約ﾘｾｯﾄ処理" & vbCrLf & _
                       "　<<表示対象データ>>" & vbCrLf & _
                       "　　・JRI画面で「仮契約統合」した、仮契約ﾃﾞｰﾀ" & vbCrLf & _
                       "　　　※補足：JRI画面で「仮契約削除」したﾃﾞｰﾀも表示" & vbCrLf & _
                       "" & vbCrLf & _
                       "　<<必要な事前作業>>" & vbCrLf & _
                       "　　・データの登録　：JRI画面で「仮契約統合」を実行" & vbCrLf & _
                       "　　・ファイルのセット：「統合用仮契約」フォルダに仮契約ファイルをセット" & vbCrLf & _
                       "　　　※補足：仮契約ファイルのバックアップを作成するのに使用" & vbCrLf & _
                       "　　　　　　　仮契約ファイルが存在しなくても、処理は正常に行う。"

        End If
        Return rtnValue

    End Function


    ''' <summary>
    '''概  要：仮契約テーブル情報と契約詳細情報の付き合わせを行う。
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>    
    Private Function GetExistsDetailRows(ByRef detailRows() As DataRow, _
                                         ByRef tmpRows() As DataRow) As DataRow()

        ''初期化
        Dim rtnRows() As DataRow
        GetExistsDetailRows = rtnRows

        ''仮契約テーブルのﾙｰﾌﾟ
        Dim isDetailExists As Boolean
        Dim TmpArrayList As New ArrayList
        For Each tmpRow As DataRow In tmpRows

            isDetailExists = False
            For Each detailRow As DataRow In detailRows
                If tmpRow.Item(M_CONTRACT_TEMP.COLUMN_NAME_OUT_CONTRACT_NO).ToString.PadLeft(3, "0") = _
                   detailRow.Item(M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_NO).ToString.PadLeft(3, "0") Then
                    isDetailExists = True
                    Exit For
                End If
            Next

            If isDetailExists = True  Then
                Call TmpArrayList.Add(tmpRow)
            End If
        Next

        ''TmpArrayListの値を配列に入れ替える。
        Dim DammyTable As New DataTable
        If TmpArrayList.Count <> 0 Then
            ReDim rtnRows(TmpArrayList.Count - 1)
            For idx As Integer = 0 To TmpArrayList.Count - 1
                rtnRows(idx) = TmpArrayList(idx)
            Next
            Return rtnRows
        Else
            Return DammyTable.Select("")
        End If

    End Function

#End Region

#Region "ﾂﾘｰﾋﾞｭｰ関係の処理"

    ''' <summary>
    ''' 機能：ﾂﾘｰﾋﾞｭｰの初期化
    ''' 説明：※ﾗｼﾞｵﾎﾞﾀﾝに応じて値を変更
    ''' </summary>
    ''' <param name="ActKB"></param>
    ''' <param name="TBL_M_CONTRACT_DETAIL"></param>
    ''' <param name="TBL_M_CONTRACT_TEMP"></param>
    ''' <remarks></remarks>
    Private Sub Init_Trv_ContractInfo(ByVal ActKB As Integer, _
                                      ByRef TBL_M_CONTRACT_DETAIL As M_CONTRACT_DETAILTable, _
                                      ByRef TBL_M_CONTRACT_TEMP As M_CONTRACT_TEMP)

        Try
            ''ﾂﾘｰﾋﾞｭｰ初期化
            Call Me.Trv_ContractInfo.Nodes.Clear()

            ''ﾂﾘｰﾋﾞｭｰのﾁｪｯｸｲﾒｰｼﾞをｾｯﾄ
            Dim imgList As New ImageList        ''ｲﾒｰｼﾞﾌｧｲﾙﾘｽﾄ
            Dim imgSize As New Size             ''ﾁｪｯｸﾎﾞｯｸｽｻｲｽﾞ

            ''ﾁｪｯｸｱｲｺﾝのｲﾒｰｼﾞ
            imgList.Images.Add(My.Resources.ﾂﾘｰﾋﾞｭｰ_有状態)
            imgList.Images.Add(My.Resources.ﾂﾘｰﾋﾞｭｰ_無状態)
            imgList.Images.Add(My.Resources.ﾂﾘｰﾋﾞｭｰ_中間状態)

            ''ﾁｪｯｸｱｲｺﾝｾｯﾄ
            Me.Trv_ContractInfo.StateImageList = imgList

            ''ﾂﾘｰﾋﾞｭｰ出力用ﾃﾞｰﾀ取得
            Dim SetNodesList() As Trv_ContractInfo_Date
            Call Me.GetInitDate_Trv_ContractInfo(ActKB, _
                                                 SetNodesList, _
                                                 Me.TBL_M_CONTRACT_DETAIL, _
                                                 Me.TBL_M_CONTRACT_TEMP)

            ''ﾂﾘｰﾋﾞｭｰにﾃﾞｰﾀをｾｯﾄ
            Call SetTrv_ContractInfoNodes(SetNodesList)

        Catch ex As Exception
            Throw ex

        End Try

    End Sub

    ''' <summary>
    ''' 機能：ﾂﾘｰﾋﾞｭｰ出力用ﾃﾞｰﾀ取得
    ''' 説明：※統合仮契約表示ﾎﾞﾀﾝの処理にて使用
    ''' </summary>
    ''' <param name="ActKB"></param>
    ''' <param name="SetNodesList"></param>
    ''' <param name="TBL_M_CONTRACT_DETAIL"></param>
    ''' <param name="TBL_M_CONTRACT_TEMP"></param>
    ''' <remarks></remarks>
    Private Sub GetInitDate_Trv_ContractInfo(ByVal ActKB As Integer, _
                                             ByRef SetNodesList() As Trv_ContractInfo_Date, _
                                             ByRef TBL_M_CONTRACT_DETAIL As M_CONTRACT_DETAILTable, _
                                             ByRef TBL_M_CONTRACT_TEMP As M_CONTRACT_TEMP)

        Try
            ''初期化
            SetNodesList = Nothing

            ''契約詳細情報Tableから対象ﾃﾞｰﾀを取得
            Dim rows() As DataRow
            Dim tmpRows1() As DataRow
            Dim tmpRows2() As DataRow
            Dim Select_InitDate_Trv_ContractInfo_1 As String
            Dim Select_InitDate_Trv_ContractInfo_2 As String
            Dim Select_InitDate_Trv_ContractInfo_3 As String
            Dim Select_InitDate_Trv_ContractInfo_4 As String
            Select_InitDate_Trv_ContractInfo_1 = GetSelect_InitDate_Trv_ContractInfo_1(True, Me.ChkDispContract.Checked)
            Select_InitDate_Trv_ContractInfo_2 = GetSelect_InitDate_Trv_ContractInfo_1(False, Me.ChkDispContract.Checked)
            Select_InitDate_Trv_ContractInfo_4 = GetSelect_InitDate_Trv_ContractInfo_3(Me.ChkDispContract.Checked)
            If Me.Cmb_TmpContract.Text = "*" Then
                Select_InitDate_Trv_ContractInfo_3 = GetSelect_InitDate_Trv_ContractInfo_2(True)
            Else
                Select_InitDate_Trv_ContractInfo_3 = GetSelect_InitDate_Trv_ContractInfo_2(False)
            End If
            Select Case ActKB
                Case ActKB_UnificationContract, _
                     ActKB_DelContract_At
                    tmpRows1 = TBL_M_CONTRACT_DETAIL.Select(Select_InitDate_Trv_ContractInfo_1, M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_NO)
                    rows = tmpRows1

                Case ActKB_DelContract,
                     ActKB_ChkContractDeff
                    tmpRows1 = TBL_M_CONTRACT_DETAIL.Select(Select_InitDate_Trv_ContractInfo_4, M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_NO)
                    tmpRows2 = TBL_M_CONTRACT_TEMP.Select(Select_InitDate_Trv_ContractInfo_2, M_CONTRACT_TEMP.COLUMN_NAME_IN_CONTRACT_NO)
                    rows = Me.GetExistsDetailRows(tmpRows1, tmpRows2)

                Case ActKB_RefContract
                    tmpRows1 = TBL_M_CONTRACT_DETAIL.Select(Select_InitDate_Trv_ContractInfo_4, M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_NO)
                    tmpRows2 = TBL_M_CONTRACT_TEMP.Select(Select_InitDate_Trv_ContractInfo_3, M_CONTRACT_TEMP.COLUMN_NAME_IN_CONTRACT_NO)
                    rows = Me.GetExistsDetailRows(tmpRows1, tmpRows2)
                    ''[*]の場合、重複した仮契約を削除する。
                    If Me.Cmb_TmpContract.Text = "*" Then
                        Call Me.DelDistinctRows(rows)
                    End If
            End Select

            ''契約詳細情報をNodes出力用ﾃﾞｰﾀに加工する。        
            SetNodesList = GetNodeDate_Trv_ContractInfo(ActKB, rows)

            ''ﾂﾘｰﾋﾞｭｰ出力用ﾃﾞｰﾀから、連番を集約する親Nodeを追加する。
            Dim AddSumarryNodesList() As Trv_ContractInfo_Date
            AddSumarryNodesList = AddSumarryNodesDate(ActKB, SetNodesList)
            SetNodesList = AddSumarryNodesList

        Catch ex As Exception
            Throw ex

        End Try

    End Sub

    ''' <summary>
    ''' 機能：契約情報ﾃﾞｰﾀより、ﾂﾘｰﾋﾞｭｰ出力用ﾃﾞｰﾀ取得
    ''' 説明：
    ''' </summary>
    ''' <param name="ActKB"></param>
    ''' <param name="Rows"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetNodeDate_Trv_ContractInfo(ByVal ActKB As Integer, _
                                                  ByRef Rows() As DataRow) As Trv_ContractInfo_Date()

        Dim rtnList As New ArrayList            ''戻り値
        Dim row As DataRow
        Dim setValue As Trv_ContractInfo_Date
        Dim isFileExist As Boolean              ''ﾌｧｲﾙが存在するかどうか?
        Dim filePath As String                  ''Paymentﾌｧｲﾙのﾊﾟｽ
        Dim fileDPath As String                 ''詳細ﾌｧｲﾙのﾊﾟｽ
        For Each row In Rows

            ''[@]の場合、「仮契約削除処理」でも、「仮契約統合処理」と同じ仮契約表示
            Select Case ActKB
                Case ActKB_UnificationContract, _
                     ActKB_DelContract_At

                    ''値のセット
                    setValue.DispName = GetDispName_Trv_ContractInfo(Me.Cmb_TmpContract.SelectedItem, _
                                                                     row.Item(M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_NO), _
                                                                     isFileExist, _
                                                                     filePath)
                    setValue.FilePath = filePath
                    setValue.FileExist = isFileExist
                    setValue.ContractNo = row.Item(M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_NO).ToString.PadLeft(3, "0")
                    setValue.Checked = Me.TrvChecked_OFF
                    setValue.SummaryF = False
                    setValue.ChildF = False

                Case ActKB_DelContract, _
                    ActKB_ChkContractDeff, _
                    ActKB_RefContract



                    ''値のセット
                    If ActKB <> Me.ActKB_RefContract Then

                        setValue.DispName = GetDispName_Trv_ContractInfo(Me.Cmb_TmpContract.Text, _
                                                                         row.Item(M_CONTRACT_TEMP.COLUMN_NAME_IN_CONTRACT_NO), _
                                                                         isFileExist, _
                                                                         filePath)

                    Else
                        setValue.DispName = GetDispName_Trv_ContractInfo(row.Item(M_CONTRACT_TEMP.COLUMN_NAME_OUT_CONTRACT_NO), _
                                                                         row.Item(M_CONTRACT_TEMP.COLUMN_NAME_IN_CONTRACT_NO), _
                                                                         Me.TBL_M_CONTRACT_TEMP)
                    End If
                    setValue.FilePath = filePath
                    setValue.FileExist = isFileExist
                    setValue.ContractNo = row.Item(M_CONTRACT_TEMP.COLUMN_NAME_IN_CONTRACT_NO).ToString.PadLeft(3, "0")
                    setValue.Checked = Me.TrvChecked_OFF
                    setValue.SummaryF = False
                    setValue.ChildF = False

                Case Else
                    ''上記以外はセットされない

            End Select
            rtnList.Add(setValue)
        Next
        Return rtnList.ToArray(GetType(Trv_ContractInfo_Date))

    End Function

    ''' <summary>
    ''' 機能：契約情報ﾃﾞｰﾀより、ﾂﾘｰﾋﾞｭｰ出力用ﾃﾞｰﾀ取得
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetDispName_Trv_ContractInfo(ByVal ContractNo As String, _
                                                  ByVal TmpContractNo As String, _
                                                  ByRef TBL_M_CONTRACT_TEMP As DataTable) As String

        Const DispMsg As String = "※別の正契約順番で重複登録されています。"              ''仮契約が重複登録時のﾒｯｾｰｼﾞ
        Const DispSpace As Integer = 20

        ''初期化
        GetDispName_Trv_ContractInfo = ""

        ''TBL_M_CONTRACT_TEMPより、重複登録した値を検索
        Dim SQL As New StringBuilder
        SQL.Append(M_CONTRACT_TEMP.COLUMN_NAME_STATUS)
        SQL.Append(CommonConstant.SQL_STR_IN)
        SQL.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        SQL.Append(StringEdit.EncloseSingleQuotation("1"))
        SQL.Append(CommonConstant.STR_COMMA)
        SQL.Append(StringEdit.EncloseSingleQuotation("2"))
        SQL.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
        SQL.Append(CommonConstant.SQL_STR_AND)
        SQL.Append(M_CONTRACT_TEMP.COLUMN_NAME_OUT_CONTRACT_NO)
        SQL.Append(CommonConstant.SQL_STR_NOT_EQUAL)
        SQL.Append(StringEdit.EncloseSingleQuotation(ContractNo))
        SQL.Append(CommonConstant.SQL_STR_AND)
        SQL.Append(M_CONTRACT_TEMP.COLUMN_NAME_IN_CONTRACT_NO)
        SQL.Append(CommonConstant.SQL_STR_EQUAL)
        SQL.Append(StringEdit.EncloseSingleQuotation(TmpContractNo))

        ''重複ﾒｯｾｰｼﾞがあれば表示する。
        Dim rtnDispName As String
        If TBL_M_CONTRACT_TEMP.Select(SQL.ToString).Length = 0 Then
            rtnDispName = TmpContractNo
        Else
            rtnDispName = TmpContractNo & Space(DispSpace - TmpContractNo.Length) & DispMsg
        End If
        GetDispName_Trv_ContractInfo = rtnDispName

    End Function

    ''' <summary>
    ''' 機能：契約情報ﾃﾞｰﾀより、ﾂﾘｰﾋﾞｭｰ出力用ﾃﾞｰﾀ取得
    ''' 説明：
    ''' </summary>
    ''' <param name="cmbValue"></param>
    ''' <param name="TmpContractNo"></param>
    ''' <param name="isFileExist"></param>
    ''' <param name="filePath"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetDispName_Trv_ContractInfo(ByVal cmbValue As String,
                                                  ByVal TmpContractNo As String, _
                                                  ByRef isFileExist As Boolean, _
                                                  ByRef filePath As String) As String
        Const DispMsg As String = "※個別PSﾌｧｲﾙが存在しません。"              ''ﾌｧｲﾙが存在しないときのﾒｯｾｰｼﾞ
        Const DispSpace As Integer = 20

        ''削除/リセット処理はファイルが不要なため、更新日時/ファイルの存在有無は不要
        If Me.Rdb_DelContract.Checked = True Or _
           Me.Rdb_RefContract.Checked = True Then
            GetDispName_Trv_ContractInfo = TmpContractNo
            Exit Function
        End If

        ''初期化
        GetDispName_Trv_ContractInfo = ""
        isFileExist = True

        ''Payment/詳細のファイル名を取得
        Dim ofm As New OioFileManage
        Dim PaymentPath As String
        PaymentPath = ofm.GetTmpLocalCPNOFolder(CommonVariable.CPNO, CInt(cmbValue)) & _
                      ofm.GetTmpPaymentLineExcelFileNM(CommonVariable.CPNO, CInt(cmbValue), CInt(TmpContractNo))

        ''ﾌｧｲﾙの存在ﾁｪｯｸ
        Dim chkTime As String
        Dim rtnDispName As String

        If File.Exists(PaymentPath) = False Then

            ''ﾌｧｲﾙが存在しなけば、「ﾌｧｲﾙが存在しません」を表示
            rtnDispName = TmpContractNo & Space(DispSpace - TmpContractNo.Length) & DispMsg
            isFileExist = False
            filePath = ""

        Else

            ''ﾌｧｲﾙが存在すれば、更新日を表示
            chkTime = "-更新日："
            chkTime = chkTime & _
                     File.GetLastWriteTime(PaymentPath).Year & "/" & _
                      File.GetLastWriteTime(PaymentPath).Month & "/" & _
                      File.GetLastWriteTime(PaymentPath).Day
            rtnDispName = TmpContractNo & Space(DispSpace - TmpContractNo.Length) & chkTime
            isFileExist = True
            filePath = PaymentPath
        End If

        GetDispName_Trv_ContractInfo = rtnDispName

    End Function

    ''' <summary>
    ''' 機能：ﾂﾘｰﾋﾞｭｰ出力用ﾃﾞｰﾀから、連番を集約する親Nodeを追加する。
    ''' 説明：※引数：SetNodesListは契約順番順にSortされている必要有
    ''' </summary>
    ''' <param name="ActKB"></param>
    ''' <param name="SetNodesList"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function AddSumarryNodesDate(ByVal ActKB As String, _
                                         ByRef SetNodesList() As Trv_ContractInfo_Date) As Trv_ContractInfo_Date()

        ''設定値　※削除/リセット処理はファイルが不要なため、ファイルの存在有無は不要
        Dim DispMsg As String = "※個別PSﾌｧｲﾙが存在しません。"                         ''ﾌｧｲﾙが存在しないときのﾒｯｾｰｼﾞ
        Select Case ActKB
            Case ActKB_DelContract,
                 ActKB_DelContract_At
                DispMsg = ""
            Case ActKB_RefContract
                DispMsg = "※別の正契約順番で重複登録されています。"
        End Select

        ''初期化
        AddSumarryNodesDate = Nothing

        ''変数宣言
        Dim rtnDate As New ArrayList                    ''戻り値
        Try

            ''SetNodesListをﾙｰﾌﾟして連番を見つける。
            Dim Idx As Integer                              ''ﾙｰﾌﾟｶｳﾝﾀ
            Dim IdxD As Integer                             ''ﾙｰﾌﾟｶｳﾝﾀ：連番検索用
            Dim isSerial As Boolean                         ''連番かどうか？
            Dim isFileExist As Boolean                      ''連番にﾌｧｲﾙが存在するかどうか？
            Dim setDispName As String                       ''ﾂﾘｰﾋﾞｭｰに表示する文言
            Dim tmpAddSerialIdx As Integer                  ''親Node情報追加するIdxの検索に使用
            Dim tmpAddSummary As Trv_ContractInfo_Date      ''一時ﾃﾞｰﾀ：親Node情報追加用
            For Idx = 0 To UBound(SetNodesList)

                ''連番チェック：最後の番号は連番のﾁｪｯｸ処理不要
                If Idx = UBound(SetNodesList) Then

                    isSerial = False

                Else
                    ''次の番号を検索して連番かどうか判断する。
                    If CInt(SetNodesList(Idx).ContractNo) + 1 = _
                       CInt(SetNodesList(Idx + 1).ContractNo) Then
                        isSerial = True

                    Else
                        isSerial = False

                    End If
                End If

                ''連番の場合親Node追加し、連番の最後までIdxをｲﾝｸﾘﾒﾝﾄ
                If isSerial = True Then

                    ''初期化：子Nodeのﾌｧｲﾙ存在ﾁｪｯｸ　
                    isFileExist = True

                    ''連番最終位置を検索し、連番ﾃﾞｰﾀのChildFをTrueにする。
                    For IdxD = Idx To UBound(SetNodesList)

                        ''通常のNode情報を追加
                        SetNodesList(IdxD).SummaryF = False
                        SetNodesList(IdxD).ChildF = True
                        If DispMsg <> "" And _
                           SetNodesList(IdxD).DispName.ToString.Length > 10 Then
                            SetNodesList(IdxD).DispName = SetNodesList(IdxD).DispName.Substring(0, 3) & _
                                                          SetNodesList(IdxD).DispName.Substring(8, SetNodesList(IdxD).DispName.Length - 8)
                        End If
                        Call rtnDate.Add(SetNodesList(IdxD))

                        ''子Nodeのﾌｧｲﾙ/重複仮契約が存在しなければFlgを立てる。
                        If ActKB = Me.ActKB_RefContract Then
                            If SetNodesList(IdxD).DispName.IndexOf("※別の正契約順番で重複登録されています。") <> -1 Then
                                isFileExist = False
                            End If
                        Else
                            If SetNodesList(IdxD).FileExist = False Then
                                isFileExist = False
                            End If
                        End If

                        ''最終行の場合、処理終了
                        If IdxD = UBound(SetNodesList) Then
                            Exit For
                        End If

                        ''連番でなくなった時点で処理終了
                        If CInt(SetNodesList(IdxD).ContractNo) + 1 <> _
                           CInt(SetNodesList(IdxD + 1).ContractNo) Then
                            Exit For
                        End If
                    Next

                    ''親情報セット
                    tmpAddSummary.DispName = SetNodesList(Idx).ContractNo & _
                                             " - " & _
                                             SetNodesList(IdxD).ContractNo
                    If isFileExist = False Then
                        tmpAddSummary.DispName = tmpAddSummary.DispName & _
                                                 Space(20 - tmpAddSummary.DispName.Length - 2) & _
                                                 DispMsg

                    End If
                    tmpAddSummary.FileExist = SetNodesList(Idx).FileExist
                    tmpAddSummary.ContractNo = SetNodesList(Idx).ContractNo         ''最小の契約順番をｾｯﾄ
                    tmpAddSummary.Checked = Me.TrvChecked_OFF
                    tmpAddSummary.SummaryF = True
                    tmpAddSummary.ChildF = False

                    ''追加する位置を検索し、追加する。
                    tmpAddSerialIdx = rtnDate.IndexOf(SetNodesList(Idx))
                    rtnDate.Insert(tmpAddSerialIdx, tmpAddSummary)

                    Idx = IdxD

                Else
                    ''連番でなければ戻り値にそのままの値をセット
                    SetNodesList(Idx).SummaryF = False
                    SetNodesList(Idx).ChildF = False

                    Call rtnDate.Add(SetNodesList(Idx))

                End If

            Next
            Return rtnDate.ToArray(GetType(Trv_ContractInfo_Date))

        Catch ex As Exception
            Throw ex

        End Try

    End Function

    ''' <summary>
    ''' 機能：ﾂﾘｰﾋﾞｭｰ出力用ﾃﾞｰﾀをﾂﾘｰﾋﾞｭｰに表示
    ''' 説明：※出力用ﾃﾞｰﾀは、親ﾃﾞｰﾀ - 子ﾃﾞｰﾀ　の順にｿｰﾄされたﾃﾞｰﾀが前提
    ''' </summary>
    ''' <param name="AddSumarryNodesList"></param>
    ''' <remarks></remarks>
    Private Sub SetTrv_ContractInfoNodes(ByRef AddSumarryNodesList() As Trv_ContractInfo_Date)

        Try
            Dim Idx As Integer                          ''index:ﾒｲﾝﾙｰﾌﾟ
            Dim IdxD As Integer                         ''index:子Nodesﾙｰﾌﾟ
            Dim SetNodes As New ArrayList               ''TreeViewへ出力用のNodeList情報
            Dim SetNode As TreeNode                     ''
            Dim SetChildNode As TreeNode                ''
            For Idx = 0 To UBound(AddSumarryNodesList)

                ''親のNodesなら、子Nodesも追加する
                If AddSumarryNodesList(Idx).SummaryF = True Then

                    ''親情報追加
                    SetNode = New TreeNode
                    SetNode.Text = AddSumarryNodesList(Idx).DispName
                    SetNode.StateImageIndex = Me.TrvChecked_OFF
                    SetNode.Tag = AddSumarryNodesList(Idx)

                    For IdxD = Idx + 1 To UBound(AddSumarryNodesList)

                        ''子の情報がなくなったら終了
                        If AddSumarryNodesList(IdxD).ChildF = False Then
                            Exit For
                        End If

                        ''子情報追加
                        SetChildNode = New TreeNode
                        SetChildNode.Text = AddSumarryNodesList(IdxD).DispName
                        SetChildNode.StateImageIndex = Me.TrvChecked_OFF
                        SetChildNode.Tag = AddSumarryNodesList(IdxD)
                        SetNode.Nodes.Add(SetChildNode)

                    Next
                    Idx = IdxD - 1              ''子Node分、Idxをｶｳﾝﾄｱｯﾌﾟする。
                    Call SetNodes.Add(SetNode)  ''1親多子の情報をｾｯﾄ

                Else
                    ''Node追加
                    SetNode = New TreeNode
                    SetNode.Text = AddSumarryNodesList(Idx).DispName
                    SetNode.StateImageIndex = Me.TrvChecked_OFF
                    SetNode.Tag = AddSumarryNodesList(Idx)
                    Call SetNodes.Add(SetNode)

                End If
            Next

            ''TreeViewにﾃﾞｰﾀ貼り付け
            Me.Trv_ContractInfo.Nodes.AddRange(SetNodes.ToArray(GetType(TreeNode)))

        Catch ex As Exception
            Throw ex

        End Try

    End Sub

    ''' <summary>
    ''' 機能：Trv_ContractInfoの表示情報(ﾌｧｲﾙ更新日)をUpdateする。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub UpdDispName_Trv_ContractInfo()

        Try
            ''ﾂﾘｰﾋﾞｭｰから設定情報を取得
            Dim SetNodesList() As Trv_ContractInfo_Date
            SetNodesList = Me.GetArrayDate_Trv_ContractInfo

            ''表示名を変更する。
            Call Me.UpdDispName_SetNodesList(SetNodesList)

            ''変更した表示名をﾂﾘｰﾋﾞｭｰに反映する。
            Call Me.ChgDispName_Trv_ContractInfo(SetNodesList)

        Catch ex As Exception
            Throw ex

        End Try

    End Sub


    ''' <summary>
    ''' 機能：Trv_ContractInfoから配列情報を取得
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetArrayDate_Trv_ContractInfo() As Trv_ContractInfo_Date()

        ''初期化
        GetArrayDate_Trv_ContractInfo = Nothing

        Try
            Dim rtnValue As New ArrayList
            Dim NodeDate As TreeNode
            Dim NodeChildDate As TreeNode
            For Each NodeDate In Me.Trv_ContractInfo.Nodes

                ''ﾂﾘｰﾋﾞｭｰから構成情報を取得　
                ''※ﾂﾘｰﾋﾞｭｰｾｯﾄ時にTagにTrv_ContractInfo_Date情報をｾｯﾄ
                Call rtnValue.Add(NodeDate.Tag)

                ''親Nodeなら、子Nodeの情報を取得
                If NodeDate.Tag.SummaryF = True Then
                    For Each NodeChildDate In NodeDate.Nodes
                        Call rtnValue.Add(NodeChildDate.Tag)
                    Next
                End If
            Next
            Return rtnValue.ToArray(GetType(Trv_ContractInfo_Date))

        Catch ex As Exception
            Throw ex

        End Try

    End Function


    ''' <summary>
    ''' 機能：Trv_ContractInfoから配列情報を取得
    ''' 説明：※親情報なし
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetAListtDate_NotPrentTrv_ContractInfo() As ArrayList

        ''戻り値
        Try
            Dim rtnValue As New ArrayList
            Dim NodeDate As TreeNode
            Dim NodeChildDate As TreeNode
            For Each NodeDate In Me.Trv_ContractInfo.Nodes

                ''ﾂﾘｰﾋﾞｭｰから構成情報を取得　
                ''※ﾂﾘｰﾋﾞｭｰｾｯﾄ時にTagにTrv_ContractInfo_Date情報をｾｯﾄ
                If NodeDate.Tag.SummaryF = False Then
                    Call rtnValue.Add(NodeDate.Tag)
                End If

                ''親Nodeなら、子Nodeの情報を取得
                If NodeDate.Tag.SummaryF = True Then
                    For Each NodeChildDate In NodeDate.Nodes
                        Call rtnValue.Add(NodeChildDate.Tag)
                    Next
                End If
            Next
            Return rtnValue

        Catch ex As Exception
            Throw ex

        End Try

    End Function


    ''' <summary>
    ''' 機能：Trv_ContractInfoの配列情報から、Check Offのﾃﾞｰﾀを削除する。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function DelAListtDate_NotChecked(ByRef contractList As ArrayList)

        Try
            ''初期化
            DelAListtDate_NotChecked = New ArrayList
            Dim rtnArray As ArrayList
            rtnArray = contractList.Clone                       ''ArrayList コピー
            If rtnArray.Count = 0 Then
                Exit Function
            End If

            ''Check Offになっているﾃﾞｰﾀを削除する。       
            Dim count As Integer
            count = rtnArray.Count - 1
            For Idx As Integer = count To 0 Step -1
                If rtnArray(Idx).Checked = Me.TrvChecked_OFF Then
                    Call rtnArray.RemoveAt(Idx)
                End If
            Next
            Return rtnArray

        Catch ex As Exception
            Throw ex

        End Try

    End Function

    ''' <summary>
    ''' 機能：ﾂﾘｰﾋﾞｭｰ配列からﾌｧｲﾙの存在しない仮契約を削除する。
    ''' 説明：※親情報なし
    ''' </summary>
    ''' <remarks></remarks>
    Private Function DelFileNotExists_NotPrentTrv_ContractInfo(ByRef contractList As ArrayList) As ArrayList

        ''初期化
        DelFileNotExists_NotPrentTrv_ContractInfo = Nothing

        ''rtnValueに新規ArrayList作成
        Dim rtnValue As ArrayList
        rtnValue = contractList.Clone()

        ''ﾌｧｲﾙの存在しない仮契約/未ﾁｪｯｸの仮契約を削除する。
        If rtnValue.Count > 0 Then
            Dim idx As Integer
            For idx = rtnValue.Count - 1 To 0 Step -1
                If rtnValue(idx).FileExist = False Then
                    rtnValue.RemoveAt(idx)
                    Continue For
                End If
                If rtnValue(idx).checked = Me.TrvChecked_OFF Then
                    rtnValue.RemoveAt(idx)
                    Continue For
                End If

            Next
        End If
        Return rtnValue

    End Function

    ''' <summary>
    ''' 機能：Trv_ContractInfo配列のDispNameを変更する。
    ''' 説明：
    ''' </summary>
    ''' <param name="SetNodesList"></param>
    ''' <remarks></remarks>
    Private Sub UpdDispName_SetNodesList(ByRef SetNodesList() As Trv_ContractInfo_Date)


        ''設定値　※削除/リセット処理はファイルが不要なため、ファイルの存在有無は不要
        Dim DispMsg As String = "※個別PSﾌｧｲﾙが存在しません。"              ''ﾌｧｲﾙが存在しないときのﾒｯｾｰｼﾞ

        If Rdb_DelContract.Checked = True Or _
           Rdb_RefContract.Checked = True Then
            DispMsg = ""
        End If
        If Rdb_RefContract.Checked = True Then
            DispMsg = "※別の正契約順番で重複登録されています。"
        End If

        Try

            ''配列をループし、DispNameをUpdate
            Dim Idx As Integer                          ''ﾙｰﾌﾟｶｳﾝﾀ
            Dim IdxD As Integer                         ''子Nodeﾙｰﾌﾟｶｳﾝﾀ
            Dim isPFileExist As Boolean                 ''親Nodeのﾌｧｲﾙが存在するかどうか?
            Dim isCFileExist As Boolean                 ''子Nodeﾌｧｲﾙが存在するかどうか?
            Dim filePath As String
            For Idx = 0 To UBound(SetNodesList)

                ''親Nodeの場合、子Nodeの情報を全てUpdateし、親情報を更新する。
                If SetNodesList(Idx).SummaryF = True Then

                    ''初期化
                    isPFileExist = True

                    ''子Nodeループ
                    For IdxD = Idx + 1 To UBound(SetNodesList)

                        ''                  以下、子Node情報を更新
                        ''------------------------------------------------
                        ''値のセット 
                        If Rdb_RefContract.Checked <> True Then
                            SetNodesList(IdxD).DispName = GetDispName_Trv_ContractInfo(Me.Cmb_TmpContract.SelectedItem, _
                                                                                       SetNodesList(IdxD).ContractNo, _
                                                                                       isCFileExist,
                                                                                       filePath)
                            ''文字の表示の長さを調整する。
                            If SetNodesList(IdxD).DispName.Length > 10 Then
                                SetNodesList(IdxD).DispName = SetNodesList(IdxD).DispName.Substring(0, 3) & _
                                                             SetNodesList(IdxD).DispName.Substring(8, SetNodesList(IdxD).DispName.Length - 8)
                            End If
                        End If

                        SetNodesList(IdxD).FilePath = filePath
                        SetNodesList(IdxD).FileExist = isCFileExist

                        ''子Node1件でも親がいない場合、親Nodeのﾌｧｲﾙなしの扱いになる。
                        If isCFileExist = False Then
                            isPFileExist = False
                        End If

                        ''子Nodeのﾌｧｲﾙが存在しなければFlgを立てる。
                        If SetNodesList(IdxD).FileExist = False Then
                            isCFileExist = False
                        End If

                        ''最終行の場合、処理終了
                        If IdxD = UBound(SetNodesList) Then
                            Exit For
                        End If

                        ''次の情報が子Nodeでなければ処理終了
                        If SetNodesList(IdxD + 1).ChildF = False Then
                            Exit For
                        End If

                    Next

                    ''親Node情報更新
                    If isPFileExist = True Then

                        SetNodesList(Idx).DispName = SetNodesList(Idx + 1).ContractNo & _
                                                     " - " & _
                                                     SetNodesList(IdxD).ContractNo
                        SetNodesList(Idx).FileExist = True

                    Else
                        SetNodesList(Idx).FileExist = False

                    End If
                    Idx = IdxD

                Else

                    ''                  以下、子Node情報を更新
                    ''------------------------------------------------
                    ''値のセット
                    If Rdb_RefContract.Checked <> True Then

                        SetNodesList(Idx).DispName = GetDispName_Trv_ContractInfo(Me.Cmb_TmpContract.SelectedItem, _
                                                                                  SetNodesList(Idx).ContractNo, _
                                                                                  isCFileExist, _
                                                                                  filePath)
                    End If
                    SetNodesList(Idx).FilePath = filePath
                    SetNodesList(Idx).FileExist = isCFileExist

                End If
            Next

        Catch ex As Exception
            Throw ex

        End Try

    End Sub

    ''' <summary>
    ''' 機能：Trv_ContractInfoの表示名情報を変更する。
    ''' 説明：
    ''' </summary>
    ''' <param name="SetNodesList"></param>
    ''' <remarks></remarks>
    Private Sub ChgDispName_Trv_ContractInfo(ByRef SetNodesList() As Trv_ContractInfo_Date)

        Dim Idx As Integer
        Dim NodeDate As TreeNode
        Dim NodeChildDate As TreeNode
        Idx = -1
        Call Me.Trv_ContractInfo.BeginUpdate()
        Try
            For Each NodeDate In Me.Trv_ContractInfo.Nodes

                ''ﾙｰﾌﾟｶｳﾝﾀ更新
                Idx = Idx + 1

                ''ﾂﾘｰﾋﾞｭｰの親情報を変更　
                NodeDate.Text = SetNodesList(Idx).DispName
                NodeDate.Tag = SetNodesList(Idx)

                ''親Nodeなら、子Nodeの情報を取得
                If NodeDate.Tag.SummaryF = True Then
                    For Each NodeChildDate In NodeDate.Nodes

                        ''ﾙｰﾌﾟｶｳﾝﾀ更新
                        Idx = Idx + 1

                        ''ﾂﾘｰﾋﾞｭｰの子情報を変更　
                        NodeChildDate.Text = SetNodesList(Idx).DispName
                        NodeChildDate.Tag = SetNodesList(Idx)
                    Next
                End If
            Next

        Catch ex As Exception
            Throw ex

        Finally
            Call Me.Trv_ContractInfo.EndUpdate()

        End Try

    End Sub

    ''' <summary>
    ''' 機能：Trv_ContractInfoのﾁｪｯｸ情報を変更する。
    ''' 説明：
    ''' </summary>
    ''' <param name="SetNodesList"></param>
    ''' <remarks></remarks>
    Private Sub UpdChecked_Trv_ContractInfo(ByRef SetNodesList() As Trv_ContractInfo_Date)

        Dim Idx As Integer
        Dim NodeDate As TreeNode
        Dim NodeChildDate As TreeNode
        Idx = -1
        Call Me.Trv_ContractInfo.BeginUpdate()
        For Each NodeDate In Me.Trv_ContractInfo.Nodes

            ''ﾙｰﾌﾟｶｳﾝﾀ更新
            Idx = Idx + 1

            ''ﾂﾘｰﾋﾞｭｰの親情報を変更　
            Select Case SetNodesList(Idx).Checked
                Case Me.TrvChecked_ON
                    NodeDate.StateImageIndex = Me.TrvChecked_ON
                Case Me.TrvChecked_OFF
                    NodeDate.StateImageIndex = Me.TrvChecked_OFF
                Case Me.TrvChecked_OTH
                    NodeDate.StateImageIndex = Me.TrvChecked_OTH
            End Select
            NodeDate.Tag = SetNodesList(Idx)

            ''親Nodeなら、子Nodeの情報を取得
            If NodeDate.Tag.SummaryF = True Then
                For Each NodeChildDate In NodeDate.Nodes

                    ''ﾙｰﾌﾟｶｳﾝﾀ更新
                    Idx = Idx + 1

                    ''ﾂﾘｰﾋﾞｭｰの子情報を変更　
                    Select Case SetNodesList(Idx).Checked
                        Case Me.TrvChecked_ON
                            NodeChildDate.StateImageIndex = Me.TrvChecked_ON
                        Case Me.TrvChecked_OFF
                            NodeChildDate.StateImageIndex = Me.TrvChecked_OFF
                        Case Me.TrvChecked_OTH
                            NodeChildDate.StateImageIndex = Me.TrvChecked_OTH
                    End Select
                    NodeChildDate.Tag = SetNodesList(Idx)

                Next
            End If
        Next
        Call Me.Trv_ContractInfo.EndUpdate()
    End Sub

    ''' <summary>
    ''' 機能：ﾁｪｯｸﾎﾞｯｸｽの値変更時、親Nodeの場合、子Nodeの値も連動して変更する。
    ''' 説明：
    ''' </summary>
    ''' <param name="curNode"></param>
    ''' <remarks></remarks>
    Private Sub UpdTrv_Trv_ContractInfo_AfterCheck(ByRef curNode As TreeNode)

        Try

            ''親Node or 子Nodeの判定
            Dim selectChk As Integer            ''ｸﾘｯｸ前のﾁｪｯｸﾎﾞｯｸｽの状態
            Dim afterChk As Integer             ''ｸﾘｯｸ後のﾁｪｯｸﾎﾞｯｸｽの状態
            Dim childNode As TreeNode
            Dim setValue As Trv_ContractInfo_Date
            setValue = curNode.Tag
            If setValue.SummaryF = True Then

                ''        親Node+子Nodeの処理
                ''----------------------------------
                ''親Node更新
                selectChk = setValue.Checked
                Select Case selectChk
                    Case Me.TrvChecked_ON,
                         Me.TrvChecked_OTH

                        afterChk = Me.TrvChecked_OFF

                    Case Me.TrvChecked_OFF

                        afterChk = Me.TrvChecked_ON

                End Select
                setValue.Checked = afterChk
                curNode.StateImageIndex = afterChk
                curNode.Tag = setValue

                ''子Node更新
                For Each childNode In curNode.Nodes
                    setValue = childNode.Tag
                    setValue.Checked = afterChk
                    childNode.StateImageIndex = afterChk
                    childNode.Tag = setValue
                Next
            Else

                ''        子Nodeのみの処理
                ''----------------------------------
                ''子Node更新
                selectChk = setValue.Checked
                Select Case selectChk
                    Case Me.TrvChecked_ON,
                         Me.TrvChecked_OTH

                        afterChk = Me.TrvChecked_OFF

                    Case Me.TrvChecked_OFF

                        afterChk = Me.TrvChecked_ON

                End Select
                setValue.Checked = afterChk
                curNode.StateImageIndex = afterChk
                curNode.Tag = setValue


                ''親Nodeが存在する場合、子Nodeの値に応じて親のCheckを変える。
                Dim parentNode As TreeNode
                Dim isAllChked As Boolean           ''全て選択
                Dim isPartChked As Boolean          ''一部選択
                Dim isNothingChked As Boolean       ''選択なし
                If setValue.ChildF = True Then

                    ''初期化
                    isAllChked = True
                    isPartChked = True
                    isNothingChked = True

                    ''親Node取得
                    parentNode = curNode.Parent

                    ''親Nodeに紐づく子Nodeの値を全て調べる。
                    For Each childNode In parentNode.Nodes

                        ''1つでもNGがあれば「全て選択」以外
                        If childNode.Tag.Checked = Me.TrvChecked_OFF Then
                            isAllChked = False
                        End If

                        ''1つでもOKがあれば「選択無し」以外
                        If childNode.Tag.Checked = Me.TrvChecked_ON Then
                            isNothingChked = False
                        End If

                    Next

                    ''「全て選択」or 「選択無し」の場合、一部選択なし
                    If isAllChked = True Or _
                       isNothingChked = True Then
                        isPartChked = False
                    End If

                    ''フラグに応じて処理変更                   
                    If isAllChked = True Then
                        afterChk = Me.TrvChecked_ON

                    ElseIf isNothingChked = True Then
                        afterChk = Me.TrvChecked_OFF

                    ElseIf isPartChked = True Then
                        afterChk = Me.TrvChecked_OTH

                    End If

                    ''親情報ｾｯﾄ
                    setValue = parentNode.Tag
                    setValue.Checked = afterChk
                    parentNode.StateImageIndex = afterChk
                    parentNode.Tag = setValue

                End If

            End If

        Catch ex As Exception
            Throw ex

        End Try

    End Sub

#End Region

#Region "仮契約No 直接入力関係の処理"

    ''' <summary>
    ''' 機能：仮契約No 直接入力　の入力ﾁｪｯｸ
    ''' 説明：※入力された文字が許可された文字か判定する。
    ''' </summary>
    ''' <remarks></remarks>
    Private Function Chk_Txb_InputContract_KeyPress(ByVal e As System.Windows.Forms.KeyPressEventArgs) As Boolean

        ''初期化
        Chk_Txb_InputContract_KeyPress = False

        ''KeyCodeより、入力許可するCodeかどうか判定する。
        Dim rtnChk As Boolean
        rtnChk = False

        ''0～9の入力値はOK
        If e.KeyChar >= "0"c And _
            e.KeyChar <= "9"c Then
            rtnChk = True
        End If

        ''矢印Key、BackSpace、Deleteﾎﾞﾀﾝ、Enter、Tabは入力許可
        Select Case e.KeyChar
            Case Chr(Keys.Back), _
                 Chr(Keys.Left), _
                 Chr(Keys.Right), _
                 Chr(Keys.Delete), _
                 Chr(Keys.Tab)
                rtnChk = True

        End Select

        ''「,」,「*」,「-」は入力許可
        Select Case e.KeyChar
            Case ","c, _
                 "*"c, _
                 "-"
                rtnChk = True
        End Select

        ''例外処理：削除処理の場合のみ「@」入力許可
        If Me.Rdb_DelContract.Checked = True And _
           e.KeyChar = "@" Then
            rtnChk = True
        End If

        ''戻り値
        Chk_Txb_InputContract_KeyPress = rtnChk

    End Function


    ''' <summary>
    ''' 機能：Txb_InputContractの入力ﾁｪｯｸを行う。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function ChkInputTextTxb_InputContract() As String

        ''定数 ※各入力ﾁｪｯｸに仕様
        Const ChkType_OK As Integer = 1         ''ﾁｪｯｸOKのため、後続のﾁｪｯｸ不要
        Const ChkType_NG As Integer = 2         ''ﾁｪｯｸNGのため、ﾒｯｾｰｼﾞをｾｯﾄして後続のﾁｪｯｸ不要
        Const ChkType_Next As Integer = 3       ''対象の形式外のため、次のチェックへ

        Try
            ''初期化
            Dim rtnErrMsg As String
            ChkInputTextTxb_InputContract = ""

            ''未入力の場合、処理終了
            If Txb_InputContract.Text.Trim = "" Then
                Exit Function
            End If

            ''文字を","毎に配列に分ける
            Dim InputList() As String
            InputList = Split(Txb_InputContract.Text, ",")

            ''入力値のﾁｪｯｸ
            Dim Idx As Integer
            Dim chkValue As String
            Dim tmpList() As String
            For Idx = 0 To UBound(InputList)

                chkValue = InputList(Idx)

                ''空白ﾁｪｯｸ　※空白は入力OK
                If Trim(chkValue) = "" Then
                    Continue For
                End If

                ''"@"のﾁｪｯｸ
                If chkValue.Trim = "@" Then
                    Continue For
                End If

                ''"*"のﾁｪｯｸ
                Select Case ChkAsterisk_Txb_InputContract(chkValue)
                    Case ChkType_OK
                        Continue For

                    Case ChkType_NG
                        rtnErrMsg = FileReader.GetMessage("MSG_0364")
                        Return (rtnErrMsg)

                    Case ChkType_Next
                        ''処理なし                    
                End Select

                ''"-"のﾁｪｯｸ
                Select Case ChkHyphen_Txb_InputContract(chkValue)
                    Case ChkType_OK
                        Continue For

                    Case ChkType_NG
                        rtnErrMsg = FileReader.GetMessage("MSG_0365")
                        Return (rtnErrMsg)

                    Case ChkType_Next
                        ''処理なし                    
                End Select

                ''数値のﾁｪｯｸ
                Select Case ChkNumber_Txb_InputContract(chkValue)
                    Case ChkType_OK
                        Continue For

                    Case ChkType_NG
                        rtnErrMsg = FileReader.GetMessage("MSG_0366")
                        Return (rtnErrMsg)

                    Case ChkType_Next
                        ''処理なし  ※数値ﾁｪｯｸはOK or NGのみしか返さない。                  
                End Select
            Next

        Catch ex As Exception
            Throw ex

        End Try

    End Function


    ''' <summary>
    ''' 機能：Txb_InputContractの入力ﾁｪｯｸを行う。
    ''' 説明：※[*]のﾁｪｯｸ
    ''' </summary>
    ''' <remarks></remarks>
    Private Function ChkAsterisk_Txb_InputContract(ByVal chkValue As String) As Integer

        ''定数 ※各入力ﾁｪｯｸに仕様
        Const ChkType_OK As Integer = 1         ''ﾁｪｯｸOKのため、後続のﾁｪｯｸ不要
        Const ChkType_NG As Integer = 2         ''ﾁｪｯｸNGのため、ﾒｯｾｰｼﾞをｾｯﾄして後続のﾁｪｯｸ不要
        Const ChkType_Next As Integer = 3       ''対象の形式外のため、次のチェックへ

        ''初期化
        ChkAsterisk_Txb_InputContract = ChkType_Next

        ''入力値が[*]なら、ﾁｪｯｸ処理終了
        If chkValue.Trim = "*" Then
            Return (ChkType_OK)
        End If

        ''入力値に[*]が含まれていて、不正な値が入力されていたらNGとする。
        If chkValue.IndexOf("*") <> -1 And _
           chkValue.Trim <> "*" Then

            Return (ChkType_NG)
        End If

        ''入力値に[*]がなければ、次のﾁｪｯｸを行う
        If chkValue.IndexOf("*") = -1 Then
            Return (ChkType_Next)
        End If

    End Function


    ''' <summary>
    ''' 機能：Txb_InputContractの入力ﾁｪｯｸを行う。
    ''' 説明：※[-]のﾁｪｯｸ
    ''' </summary>
    ''' <remarks></remarks>
    Private Function ChkHyphen_Txb_InputContract(ByVal chkValue As String) As Integer


        ''定数 ※各入力ﾁｪｯｸに仕様
        Const ChkType_OK As Integer = 1         ''ﾁｪｯｸOKのため、後続のﾁｪｯｸ不要
        Const ChkType_NG As Integer = 2         ''ﾁｪｯｸNGのため、ﾒｯｾｰｼﾞをｾｯﾄして後続のﾁｪｯｸ不要
        Const ChkType_Next As Integer = 3       ''対象の形式外のため、次のチェックへ

        ''初期化
        ChkHyphen_Txb_InputContract = ChkType_Next

        ''                          以下、ﾁｪｯｸOKか判定
        ''--------------------------------------------------------------------
        Dim isChkOk As Boolean         ''ﾁｪｯｸOKかどうか？
        isChkOk = True

        ''[-]有りかどうか？
        Dim IdxHyphen As Integer       ''[-]の文字の位置
        IdxHyphen = chkValue.IndexOf("-")
        If IdxHyphen = -1 Then
            isChkOk = False
        End If

        ''[-]の前後に文字が存在するか？
        If IdxHyphen = 0 Or _
           IdxHyphen = chkValue.Length Then
            isChkOk = False
        End If

        ''[-]の前後に文字が正しい値かどうか？
        Dim strValue As String         ''[-]の前の値
        Dim endValue As String         ''[-]の後の値
        If isChkOk = True Then

            strValue = chkValue.Substring(0, IdxHyphen)
            endValue = chkValue.Substring(IdxHyphen + 1, chkValue.Length - (IdxHyphen + 1))

            ''数値が入力されているか判定
            If IsNumeric(strValue) = False Or _
               IsNumeric(endValue) = False Then
                isChkOk = False
            End If

            ''数字の大小ﾁｪｯｸを行う。
            If isChkOk = True AndAlso _
                CInt(strValue) > CInt(endValue) Then
                isChkOk = False
            End If
        End If
        If isChkOk = True Then
            Return ChkType_OK
        End If

        ''                          以下、ﾁｪｯｸ対象外か判定
        ''--------------------------------------------------------------------
        Dim isChkNext As Boolean         ''ﾁｪｯｸNGかどうか？
        isChkNext = False

        ''[-]を含まない場合、ﾁｪｯｸ対象外
        If IdxHyphen = -1 Then
            isChkNext = True
        End If
        If isChkNext = True Then
            Return ChkType_Next
        End If

        ''                          以下、ﾁｪｯｸNGか判定
        ''--------------------------------------------------------------------
        ''OKでも対象外でもなければ自動的にNGを設定
        Return ChkType_NG

    End Function


    ''' <summary>
    ''' 機能：Txb_InputContractの入力ﾁｪｯｸを行う。
    ''' 説明：※数字のﾁｪｯｸ
    ''' </summary>
    ''' <remarks></remarks>
    Private Function ChkNumber_Txb_InputContract(ByVal chkValue As String) As Integer

        ''定数 ※各入力ﾁｪｯｸに仕様
        Const ChkType_OK As Integer = 1         ''ﾁｪｯｸOKのため、後続のﾁｪｯｸ不要
        Const ChkType_NG As Integer = 2         ''ﾁｪｯｸNGのため、ﾒｯｾｰｼﾞをｾｯﾄして後続のﾁｪｯｸ不要
        Const ChkType_Next As Integer = 3       ''対象の形式外のため、次のチェックへ

        ''初期化
        ChkNumber_Txb_InputContract = ChkType_NG

        ''入力値が[*]なら、ﾁｪｯｸ処理終了
        If IsNumeric(chkValue) = True Then
            Return ChkType_OK
        Else
            Return ChkType_NG
        End If

    End Function

    ''' <summary>
    ''' 機能：ﾁｪｯｸOn/Offﾎﾞﾀﾝｸﾘｯｸ時、直接入力の値をﾂﾘｰﾋﾞｭｰへ反映する。
    ''' 説明：
    ''' </summary>
    ''' <param name="ChkOnOff"></param>
    ''' <remarks></remarks>
    Private Sub ChgTrv_ContractInfo_Btn_ChkOnOff(ByVal ChkOnOff As Integer)

        Try
            ''仮契約No直接入力　の入力ﾁｪｯｸ
            Dim ErrMsg As String
            ErrMsg = ChkInputTextTxb_InputContract()
            If ErrMsg <> "" Then
                Call MsgBox(Prompt:=ErrMsg, _
                            Buttons:=MsgBoxStyle.Critical, _
                            Title:=Me.Text)
                Me.Txb_InputContract.Select()
                Exit Sub
            End If

            ''ﾂﾘｰﾋﾞｭｰの値を配列で取得
            Dim setValue() As Trv_ContractInfo_Date
            setValue = Me.GetArrayDate_Trv_ContractInfo

            ''[,]で分割した文字列を、ﾂﾘｰﾋﾞｭｰに反映する。
            Dim splitValue() As String
            Dim tmpValue As String
            Dim InputContractKB As Integer      ''文字列の種別　：空白/[*]/[-]/数値
            splitValue = Split(Me.Txb_InputContract.Text, ",")
            For Each tmpValue In splitValue

                ''文字列の種類を取得
                InputContractKB = GetActKB_Txb_InputContract(tmpValue)

                ''ﾂﾘｰﾋﾞｭｰ出力用配列をUpdate
                Call Me.SetCheckOn_Btn_ChkOn(InputContractKB, _
                                             ChkOnOff, _
                                             tmpValue, _
                                             setValue)

            Next

            ''ﾂﾘｰﾋﾞｭｰへ反映
            Call Me.UpdChecked_Trv_ContractInfo(setValue)

        Catch ex As Exception
            Throw ex

        End Try
    End Sub


    ''' <summary>
    ''' 機能：Txb_InputContractの入力値の処理区分を取得
    ''' 説明：※空白/[-]/[*]/数値
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetActKB_Txb_InputContract(ByVal chkValue As String) As Integer


        ''初期化
        GetActKB_Txb_InputContract = InputContractKB_Blank

        ''空白のﾁｪｯｸ
        If chkValue.Trim = "" Then
            Return Me.InputContractKB_Blank
        End If

        ''[-]のﾁｪｯｸ
        If chkValue.IndexOf("-") <> -1 Then
            Return Me.InputContractKB_Hyhen
        End If

        ''[*]のﾁｪｯｸ
        If chkValue.IndexOf("*") <> -1 Then
            Return Me.InputContractKB_Asterisk
        End If

        ''数値のﾁｪｯｸ
        If IsNumeric(chkValue) = True Then
            Return Me.InputContractKB_Number
        End If

    End Function


    ''' <summary>
    ''' 機能：Txb_InputContractの入力値をﾂﾘｰﾋﾞｭｰ出力配列にｾｯﾄ
    ''' 説明：※空白/[-]/[*]/数値
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetCheckOn_Btn_ChkOn(ByVal ActKB As String, _
                                     ByVal ChkOnOff As Integer, _
                                     ByVal Value As String, _
                                     ByRef SetValue() As Trv_ContractInfo_Date)

        ''定数
        Const InputContractKB_Blank As Integer = 1          ''空白入力
        Const InputContractKB_Hyhen As Integer = 2          ''[-]入力
        Const InputContractKB_Asterisk As Integer = 3       ''[*]入力
        Const InputContractKB_Number As Integer = 4         ''数値入力

        Select Case ActKB

            Case InputContractKB_Blank

                ''                  空白の処理
                ''-----------------------------------------------
                ''※処理なし

            Case InputContractKB_Hyhen

                ''                  [-]の処理
                ''-----------------------------------------------
                Dim Idx As Integer              ''ﾙｰﾌﾟｶｳﾝﾀ
                Dim IdxD As Integer             ''ﾙｰﾌﾟｶｳﾝﾀ　子Nodeﾙｰﾌﾟ用
                Dim strIdx As Integer           ''開始位置
                Dim endIdx As Integer           ''終了位置
                Dim hyhenIdx As Integer         ''[-]位置
                hyhenIdx = Value.IndexOf("-")
                strIdx = Value.Substring(0, hyhenIdx)
                endIdx = Value.Substring(hyhenIdx + 1, Value.Length - (hyhenIdx + 1))

                ''該当する契約順番の場合ChkFlgを立てる。
                For Idx = 0 To UBound(SetValue)

                    If SetValue(Idx).SummaryF = True Then

                        ''親Nodeの場合、子Nodeの値に応じてﾁｪｯｸON/OFF切り替え
                        Dim isNodeOn As Boolean     ''全ての子NodeがOn
                        Dim isNodeOff As Boolean    ''全ての子NodeがOff
                        Dim isNodeOth As Boolean    ''一部の子NodeがOn
                        isNodeOn = True
                        isNodeOff = True
                        isNodeOth = True

                        ''子Nodeの更新
                        For IdxD = Idx + 1 To UBound(SetValue)

                            ''ﾁｪｯｸOn/Off切り替え
                            If CInt(SetValue(IdxD).ContractNo) >= CInt(strIdx) And
                               CInt(SetValue(IdxD).ContractNo) <= CInt(endIdx) Then
                                SetValue(IdxD).Checked = ChkOnOff
                            End If

                            ''子Nodeの値に１件Onでもあれば、「全てOff」= False
                            If SetValue(IdxD).Checked = Me.TrvChecked_ON Then
                                isNodeOff = False
                            End If

                            ''子Nodeの値に１件Offでもあれば、「全てOn」= False
                            If SetValue(IdxD).Checked = Me.TrvChecked_OFF Then
                                isNodeOn = False
                            End If

                            ''次のNodeが子Nodeでない場合、ﾙｰﾌﾟ終了
                            If IdxD <> UBound(SetValue) AndAlso _
                                SetValue(IdxD + 1).ChildF = False Then
                                Exit For
                            End If
                        Next

                        ''「全てOn」or「全てOff」=Trueなら、「一部On」はなし。
                        If isNodeOn = True Or _
                           isNodeOff = True Then
                            isNodeOth = False
                        End If

                        ''親Nodeの更新
                        If isNodeOn = True Then
                            SetValue(Idx).Checked = Me.TrvChecked_ON
                        ElseIf isNodeOff = True Then
                            SetValue(Idx).Checked = Me.TrvChecked_OFF
                        ElseIf isNodeOth = True Then
                            SetValue(Idx).Checked = Me.TrvChecked_OTH
                        End If
                        Idx = IdxD

                    Else

                        ''            親Node無しの処理
                        ''------------------------------------------
                        If CInt(SetValue(Idx).ContractNo) >= CInt(strIdx) And
                           CInt(SetValue(Idx).ContractNo) <= CInt(endIdx) Then

                            SetValue(Idx).Checked = ChkOnOff

                        End If
                    End If
                Next

            Case InputContractKB_Asterisk

                ''                  [*]の処理
                ''-----------------------------------------------
                Dim Idx As Integer              ''ﾙｰﾌﾟｶｳﾝﾀ
                For Idx = 0 To UBound(SetValue)
                    SetValue(Idx).Checked = ChkOnOff
                Next

            Case InputContractKB_Number

                ''                  [数値]の処理
                ''-----------------------------------------------
                Dim Idx As Integer              ''ﾙｰﾌﾟｶｳﾝﾀ
                For Idx = 0 To UBound(SetValue)

                    If CInt(SetValue(Idx).ContractNo) = CInt(Value) And _
                       SetValue(Idx).SummaryF = False Then

                        ''子Nodeの情報を変更
                        SetValue(Idx).Checked = ChkOnOff

                        ''親Nodeを持つ子Nodeの場合、親Nodeのﾁｪｯｸ値を更新
                        If SetValue(Idx).ChildF = True Then

                            ''親Node位置検索
                            Dim strIdx As Integer
                            For strIdx = Idx To 0 Step -1
                                If SetValue(strIdx).SummaryF = True Then
                                    Exit For
                                End If
                            Next

                            ''子Nodeが全てﾁｪｯｸOn/Offか
                            Dim isChkOn As Boolean = True         ''全てON
                            Dim isChkOff As Boolean = True        ''全てOFF
                            Dim isChkOth As Boolean = True        ''一部ON
                            Dim idxD As Integer
                            For idxD = strIdx + 1 To UBound(SetValue)

                                ''ﾁｪｯｸONが見つかった場合、「全てOFF」 = Falseにする
                                If SetValue(idxD).Checked = Me.TrvChecked_ON Then
                                    isChkOff = False
                                End If

                                ''ﾁｪｯｸOFFが見つかった場合、「全てON」 = Falseにする
                                If SetValue(idxD).Checked = Me.TrvChecked_OFF Then
                                    isChkOn = False
                                End If

                                ''次のNodeが親なら処理終了
                                If idxD <> UBound(SetValue) AndAlso _
                                   SetValue(idxD + 1).ChildF = False Then
                                    Exit For
                                End If
                            Next

                            ''全て「ﾁｪｯｸOn」Or「ﾁｪｯｸOn」なら、「一部On」= False
                            If isChkOn = True Or _
                               isChkOff = True Then
                                isChkOth = False
                            End If

                            ''親Nodeの値を変更
                            If isChkOn = True Then
                                SetValue(strIdx).Checked = Me.TrvChecked_ON
                            ElseIf isChkOff Then
                                SetValue(strIdx).Checked = Me.TrvChecked_OFF
                            ElseIf isChkOth Then
                                SetValue(strIdx).Checked = Me.TrvChecked_OTH
                            End If

                        End If

                        Exit For
                    End If
                Next

        End Select

    End Sub

#End Region

#Region "仮契約統合ﾎﾞﾀﾝ関係の処理"


    ''' <summary>
    ''' 機能：仮契約統合ボタンの処理
    ''' 説明：以下のOption機能有り
    ''' 　　　・処理状態通知画面
    ''' 　　　・例外Log出力
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Main_Btn_UnificationContract()

        ''ﾛｸﾞﾌｧｲﾙ初期化
        Dim tes As New TestClass2
        Dim outLogMsg As String                                        ''ﾛｸﾞ出力用エラーMsg
        Call Me.InitPGLogFile()                                        ''ﾛｸﾞﾌｧｲﾙ初期化
        Call WritePGLogLine(Me.OutLogKB.OutStr)
        Call WritePGLogLine(Me.OutLogKB.ActStr)

        ''ｴﾗｰﾒｯｾｰｼﾞ ※ﾕｰｻﾞｰが定義したｴﾗｰ 例)ﾌｧｲﾙの存在ﾁｪｯｸ等
        Dim ErrMsg As String                                            ''ｴﾗｰﾒｯｾｰｼﾞ
        Dim ErrMsgKB As String                                          ''ｴﾗｰ区分

        ''ｽﾃｰﾀｽ画面のｾｯﾄ
        Dim dspInfoMsg As String                                        ''進捗画面に表示する文言
        Dim frm_State As New Frm_WaitDialog

        Try
            'GSAパス存在チェック
            Dim blnRet As Boolean
            blnRet = CheckGsaPath()
            If blnRet = False Then
                Exit Sub
            End If

            ''                      以下、統合前のﾁｪｯｸ処理/ﾌｧｲﾙﾊﾟｽの取得
            ''---------------------------------------------------------------------------------
            ''Log書込/進捗状況を画面に通知する。
            Call WritePGLogLine(Me.OutLogKB.Titel_Pt1)                  ''ﾛｸﾞ出力
            Call SetInitWaitDialog(frm_State, "正契約ファイルの読込中…", 4)

            ''統合対象の正契約ﾌｧｲﾙﾊﾟｽを取得
            Dim PaymentPath As String
            PaymentPath = Me.GetPaymentPath(CommonVariable.CPNO, Me.Cmb_TmpContract.Text)

            ''統合対象の仮契約を取得
            Dim contractList As ArrayList
            contractList = GetAListtDate_NotPrentTrv_ContractInfo()

            ''仮契約統合処理実行前ﾁｪｯｸ 　※ﾕｰｻﾞｰ定義ｴﾗｰ検出　
            ErrMsgKB = ChkUnificationContract(ErrMsg, PaymentPath, contractList)
            Select Case ErrMsgKB
                Case Me.ErrKB_Err, _
                     Me.ErrKB_Alr
                    Exit Sub            ''Finallyへ移動し、ﾒｯｾｰｼﾞ処理を行う。

                Case ErrKB_Info
                    If MessageBox.Show(ErrMsg, Me.Text, MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) = DialogResult.OK Then
                        ''OK     ⇒処理続行
                    Else
                        ''Cancel ⇒処理終了
                        Exit Sub
                    End If
            End Select
            If ExcelWrite.ChkPaymentErr(Me.Name, "Btn_UnificationContract", _
                                        CommonVariable.CPNO, CInt(Me.Cmb_TmpContract.Text)) = False Then
                Exit Sub
            End If

            'PSファイル⇔DB2との月額保有数のチェック
            If ChkPaymentPriods(PaymentPath, contractList) = False Then
                Exit Sub
            End If



            ''                      以下、正契約の情報をDataTableへセット
            ''---------------------------------------------------------------------------------
            Dim XlsPaymentTable As DataTable                                ''Payment情報 
            Dim XlsDetailTable As DataTable                                 ''詳細情報
            XlsPaymentTable = Set_XlsPaymentTable(PaymentPath)
            XlsDetailTable = Set_XlsDetailTable(PaymentPath)

            ''Log書込/進捗状況を画面に通知する。
            Call WritePGLogLine(Me.OutLogKB.Titel_Pt2)
            Call SetStepProgress(frm_State, "仮契約ファイルの読込中…")


            ''                      以下、仮契約の情報をDataTableへセット
            ''---------------------------------------------------------------------------------
            Dim delNotFileContractList As ArrayList
            delNotFileContractList = DelFileNotExists_NotPrentTrv_ContractInfo(contractList)
            Dim TmpXlsPaymentTable(delNotFileContractList.Count - 1) As DataTable         ''Payment情報 
            Dim TmpXlsDetailTable(delNotFileContractList.Count - 1) As DataTable          ''詳細情報

            ''Paymentﾌｧｲﾙ
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt5, "PSﾌｧｲﾙ")
            For Idx As Integer = 0 To delNotFileContractList.Count - 1
                TmpXlsPaymentTable(Idx) = Set_TmpXlsPaymentTable(delNotFileContractList(Idx).ContractNo, delNotFileContractList(Idx).FilePath)
            Next

            ''詳細ﾌｧｲﾙ
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt6)
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt5, "詳細ﾌｧｲﾙ")
            For Idx As Integer = 0 To delNotFileContractList.Count - 1
                TmpXlsDetailTable(Idx) = Set_TmpXlsDetailTable(delNotFileContractList(Idx).ContractNo, delNotFileContractList(Idx).FilePath)
            Next

            ''Log書込/進捗状況を画面に通知する。
            Call WritePGLogLine(Me.OutLogKB.Titel_Pt3)
            Call SetStepProgress(frm_State, "正契約と仮契約をマージ中…")

            ''                      以下、正契約と仮契約の情報をﾏｰｼﾞ
            ''---------------------------------------------------------------------------------
            Dim UpdM_ContractTmpList As New ArrayList   ''仮契約情報Table更新用の情報を保持
            Dim MergePaymentTable As DataTable
            Dim MergeDetailTable As DataTable
            Call Get_MergeTable(PaymentPath, _
                                delNotFileContractList, _
                                MergePaymentTable, _
                                MergeDetailTable, _
                                XlsPaymentTable, _
                                XlsDetailTable, _
                                TmpXlsPaymentTable, _
                                TmpXlsDetailTable, _
                                UpdM_ContractTmpList)


            ''Log書込/進捗状況を画面に通知する。
            Call WritePGLogLine(Me.OutLogKB.Titel_Pt4)
            Call SetStepProgress(frm_State, "Excelﾌｧｲﾙの書込中…")

            ''                      以下、マージした情報を統合後の正契約に書込
            ''---------------------------------------------------------------------------------
            Call Create_UnificationXls(PaymentPath, _
                                       MergePaymentTable, _
                                       MergeDetailTable)

            ''                      以下、ﾌｧｲﾙを保存し、MDBを更新する。
            ''---------------------------------------------------------------------------------
            ''MDBの更新
            Call WritePGLogLine(Me.OutLogKB.Titel_Pt5)
            Call UpdMDB_Main_Btn_UnificationContract(Me.Cmb_TmpContract.Text, UpdM_ContractTmpList)

            ''MDBの値を取得して画面をリフレッシュ
            Call GetMdbInfomatino(Me.TBL_M_CONTRACT_BASE, Me.TBL_M_CONTRACT_DETAIL, Me.TBL_M_CONTRACT_TEMP)
            Call InitForm_Rdbutton(Me.ActKB_UnificationContract)

            ''完了メッセージ
            Call MsgBox(Prompt:=FileReader.GetMessage("MSG_0372"), _
                        Title:=Me.Text, _
                        Buttons:=MsgBoxStyle.Information)

        Catch ex As Exception
            Dim errDetail As String
            errDetail = GetExceptionErrMsg(frm_State.lbl_Message.Text)
            errDetail = errDetail & vbCrLf & _
                        "エラーの詳細については、Logフォルダ直下に作成される「契約統合_[CPNO].Log」を確認してください。" & vbCrLf & _
                        vbCrLf & _
                        "エラー内容：" & ex.Message
            Throw New Exception(errDetail)

        Finally

            ''ﾛｸﾞの書込
            Call WritePGLogLine(Me.OutLogKB.ActEnd)
            Call WritePGLogLine(Me.OutLogKB.OutEnd)

            ''※エラー補足：ユーザ定義エラーはここで処理。
            ''  Exceptionｴﾗｰは、ﾎﾞﾀﾝｸﾘｯｸｲﾍﾞﾝﾄで「失敗した処理の名前」＋ 「ｴﾗｰﾛｸﾞ参照してください。」のﾒｯｾｰｼﾞ表示。
            Call frm_State.Close()
            Select Case ErrMsgKB
                Case ""
                    ''処理なし
                Case Me.ErrKB_Err
                    Call MsgBox(Prompt:=ErrMsg, _
                                Buttons:=MsgBoxStyle.Critical, _
                                Title:=Me.Text)

                Case Me.ErrKB_Alr
                    Call MsgBox(Prompt:=ErrMsg, _
                                Buttons:=MsgBoxStyle.Exclamation, _
                                Title:=Me.Text)

            End Select

        End Try

    End Sub

    ''' <summary>
    ''' 機能：正契約Noからﾌｧｲﾙ名を取得
    ''' 説明：※ﾌｧｲﾙの存在ﾁｪｯｸ等は、「ChkUnificationContract」にて一括して行う。
    ''' </summary>
    ''' <param name="cpno"></param>
    ''' <param name="cmbValue"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetPaymentPath(ByVal cpno As String,
                                    ByVal cmbValue As String) As String

        ''初期化
        GetPaymentPath = ""

        ''契約順番が空なら、処理終了
        If cmbValue = "" Then
            Exit Function
        End If

        ''変数の宣言
        Dim rtnPath As String           ''戻り値
        Dim ofm As New OioFileManage
        Dim folderPath As String        ''ﾌｫﾙﾀﾞ
        Dim fileNM As String            ''ﾌｧｲﾙ名

        ''ﾊﾟｽ取得
        folderPath = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, _
                                            CInt(cmbValue))
        fileNM = ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, _
                                               CInt(cmbValue))

        ''戻り値
        rtnPath = folderPath & fileNM
        Return rtnPath

    End Function

    ''' <summary>
    ''' 機能：仮契約統合前ﾁｪｯｸ行う。
    ''' 説明：※ﾌｧｲﾙの存在ﾁｪｯｸ/統合済みﾃﾞｰﾀのﾁｪｯｸその他
    ''' </summary>
    ''' <param name="ErrMsg"></param>
    ''' <param name="PaymentPath"></param>
    ''' <param name="contractList"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ChkUnificationContract(ByRef ErrMsg As String, _
                                            ByVal PaymentPath As String, _
                                            ByRef contractList As ArrayList) As String

        ''警告ﾒｯｾｰｼﾞ
        Dim AlrMsg_001 As String = FileReader.GetMessage("MSG_0367")            ''画面_統合正契約Noが未入力
        Dim AlrMsg_002 As String = FileReader.GetMessage("MSG_0368")            ''画面_仮契約一覧が画面で1件もﾁｪｯｸなし。
        Dim AlrMsg_003 As String = FileReader.GetMessage("MSG_0383")            ''画面_仮契約一覧で選択した仮契約ファイルが1件もなし。

        ''ｴﾗｰﾒｯｾｰｼﾞ
        Dim ErrMsg_001 As String = FileReader.GetMessage("MSG_0369")            ''Paymentﾌｧｲﾙが存在しない。
        Dim ErrMsg_002 As String = FileReader.GetMessage("MSG_0376")            ''正契約：Payment/詳細ﾌｧｲﾙがOpen
        Dim ErrMsg_003 As String = FileReader.GetMessage("MSG_0445")            ''仮契約：Payment/詳細ﾌｧｲﾙがOpen

        ''確認ﾒｯｾｰｼﾞ
        Dim InfoMsg_001 As String = FileReader.GetMessage("MSG_0370")           ''既に統合済みの仮契約を選択しています。
        Dim InfoMsg_002 As String = FileReader.GetMessage("MSG_0371")           ''他の統合正契約Noで統合済の仮契約が選択されています。
        Dim InfoMsg_003 As String = FileReader.GetMessage("MSG_0377")           ''ﾌｧｲﾙが存在しない仮契約を選択しています。

        ''初期化
        ChkUnificationContract = ""

        Try

            ''                  以下、ﾁｪｯｸｴﾗｰなら処理終了
            ''--------------------------------------------------------------------
            ''統合正契約Noの入力有無
            If Me.Cmb_TmpContract.Text = "" Then
                ChkUnificationContract = ErrKB_Alr
                ErrMsg = AlrMsg_001
                Exit Function
            End If

            ''仮契約のﾁｪｯｸ有りﾃﾞｰﾀ判定
            If chkOn_Trv_ContractInfo_Date(contractList) = False Then
                ChkUnificationContract = ErrKB_Alr
                ErrMsg = AlrMsg_002
                Exit Function
            End If

            ''仮契約のファイルの存在ﾁｪｯｸ
            If chkExistsTmpFile(contractList) = False Then
                ChkUnificationContract = ErrKB_Alr
                ErrMsg = AlrMsg_003
                Exit Function
            End If

            ''統合正契約Paymentﾌｧｲﾙの存在ﾁｪｯｸ
            If chk_ExistsPaymentFile(PaymentPath) = False Then
                ChkUnificationContract = ErrKB_Err
                ErrMsg = ErrMsg_001
                Exit Function
            End If

            ''統合正契約Payment/詳細ﾌｧｲﾙのOPen存在ﾁｪｯｸ
            If chk_OpenPaymentFile(PaymentPath) = False Then
                ChkUnificationContract = ErrKB_Err
                ErrMsg = ErrMsg_002
                Exit Function
            End If

            ''仮契約Payment/詳細ﾌｧｲﾙのOPen存在ﾁｪｯｸ
            If chk_OpenTmpPaymentFile(contractList) = False Then
                ChkUnificationContract = ErrKB_Err
                ErrMsg = ErrMsg_003
                Exit Function
            End If

            ''            以下、確認ﾒｯｾｰｼﾞ　※確認事項を一覧で表示し、Yes/Noを判定
            ''--------------------------------------------------------------------
            Dim isInfo As Boolean = False
            Dim InfoMsg As String = "警告：内容を確認し、処理を続行する場合「OKﾎﾞﾀﾝ」を押してください。"

            Dim InfoSubMsg As String
            Dim tmpInfoMsg As String

            ''再統合の処理かどうか判定する。
            If chk_ExistsUnification(Me.TBL_M_CONTRACT_TEMP, Me.Cmb_TmpContract.Text, contractList, InfoMsg_001, tmpInfoMsg) = True Then
                isInfo = True
                InfoSubMsg = InfoSubMsg & vbCrLf & tmpInfoMsg
            End If

            ''既に統合済みの仮契約が含まれるかチェック
            If chk_ExistsTmpUnification(Me.TBL_M_CONTRACT_TEMP, contractList, InfoMsg_002, tmpInfoMsg) = True Then
                isInfo = True
                InfoSubMsg = InfoSubMsg & vbCrLf & tmpInfoMsg
            End If

            ''仮契約のﾌｧｲﾙの存在ﾁｪｯｸ
            If chk_ExistsTmpUnificationFile(Me.TBL_M_CONTRACT_TEMP, contractList, InfoMsg_003, tmpInfoMsg) = True Then
                isInfo = True
                InfoSubMsg = InfoSubMsg & vbCrLf & tmpInfoMsg
            End If

            ''ﾒｯｾｰｼﾞを戻す
            If isInfo = True Then
                ChkUnificationContract = ErrKB_Info
                ErrMsg = InfoMsg & InfoSubMsg
                Exit Function
            End If

        Catch ex As Exception
            Throw ex

        End Try

    End Function


    ''' <summary>
    ''' 機能：仮契約削除前ﾁｪｯｸ行う。
    ''' 説明：※ﾌｧｲﾙの存在ﾁｪｯｸ/その他
    ''' </summary>
    ''' <remarks></remarks>
    Private Function ChkDelContract(ByRef ErrMsg As String, _
                                    ByRef PaymentPath As String, _
                                    ByRef contractList As ArrayList) As String

        ''初期化
        ChkDelContract = ""

        ''警告ﾒｯｾｰｼﾞ
        Dim AlrMsg_001 As String = FileReader.GetMessage("MSG_0367")            ''画面_統合正契約Noが未入力
        Dim AlrMsg_002 As String = FileReader.GetMessage("MSG_0368")            ''画面_仮契約一覧が画面で1件もﾁｪｯｸなし。

        ''ｴﾗｰﾒｯｾｰｼﾞ
        Dim ErrMsg_001 As String = FileReader.GetMessage("MSG_0369")            ''Paymentﾌｧｲﾙが存在しない。
        Dim ErrMsg_002 As String = FileReader.GetMessage("MSG_0376")            ''Payment/詳細ﾌｧｲﾙがOpen

        Try

            ''                  以下、ﾁｪｯｸｴﾗｰなら処理終了
            ''--------------------------------------------------------------------
            ''統合正契約Noの入力有無
            If Me.Cmb_TmpContract.Text = "" Then
                ChkDelContract = ErrKB_Alr
                ErrMsg = AlrMsg_001
                Exit Function
            End If

            ''仮契約のﾁｪｯｸ有りﾃﾞｰﾀ判定
            If chkOn_Trv_ContractInfo_Date(contractList) = False Then
                ChkDelContract = ErrKB_Alr
                ErrMsg = AlrMsg_002
                Exit Function
            End If

            ''統合正契約Paymentﾌｧｲﾙの存在ﾁｪｯｸ
            If chk_ExistsPaymentFile(PaymentPath) = False Then
                ChkDelContract = ErrKB_Err
                ErrMsg = ErrMsg_001
                Exit Function
            End If

            ''統合正契約Payment/詳細ﾌｧｲﾙのOPen存在ﾁｪｯｸ
            If chk_OpenPaymentFile(PaymentPath) = False Then
                ChkDelContract = ErrKB_Err
                ErrMsg = ErrMsg_002
                Exit Function
            End If
        Catch ex As Exception
            Throw ex

        End Try
    End Function


    ''' <summary>
    ''' 機能：ﾂﾘｰﾋﾞｭｰにCheckOnのﾃﾞｰﾀが存在するかどうか判定
    ''' 説明：※仮契約統合前ﾁｪｯｸで使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Function chkOn_Trv_ContractInfo_Date(ByRef contractList As ArrayList) As Boolean

        ''初期化
        chkOn_Trv_ContractInfo_Date = False

        Dim IsChecked As Boolean = False                     ''ﾁｪｯｸONがあるかどうか?
        Dim contctValue As Trv_ContractInfo_Date
        For Each contctValue In contractList

            ''ﾁｪｯｸONの判定
            If contctValue.Checked = Me.TrvChecked_ON Then
                IsChecked = True
                Exit For
            End If

        Next

        ''1件でもﾁｪｯｸOnがあれば、ﾁｪｯｸOKとする。
        If IsChecked = True Then
            chkOn_Trv_ContractInfo_Date = True
        End If

    End Function

    ''' <summary>
    ''' 機能：画面で選択した仮契約ﾌｧｲﾙの存在ﾁｪｯｸ (詳細もチェックする。) 
    ''' 説明：※仮契約統合前ﾁｪｯｸで使用
    ''' </summary>
    ''' <param name="contractList"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function chkExistsTmpFile(ByRef contractList As ArrayList) As Boolean

        ''初期化
        chkExistsTmpFile = False

        ''仮契約ファイルの存在チェック
        Dim isFileExists As Boolean = False         ''仮契約が存在するかどうか？
        Dim tmpValue As Trv_ContractInfo_Date
        For Each tmpValue In contractList
            If tmpValue.Checked = Me.TrvChecked_ON And _
               tmpValue.FileExist = True Then

                chkExistsTmpFile = True
                Exit For

            End If
        Next

        ''返り値
        If chkExistsTmpFile = True Then
            chkExistsTmpFile = True
        Else
            chkExistsTmpFile = False
        End If

    End Function


    ''' <summary>
    ''' 機能：統合正契約Paymentﾌｧｲﾙの存在ﾁｪｯｸ (詳細もチェックする。) 
    ''' 説明：※仮契約統合前ﾁｪｯｸで使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Function chk_ExistsPaymentFile(ByVal PaymentPath As String) As Boolean

        ''初期化
        chk_ExistsPaymentFile = True

        ''Paymentﾌｧｲﾙの存在ﾁｪｯｸ
        If File.Exists(PaymentPath) = False Then
            chk_ExistsPaymentFile = False
            Exit Function
        End If

    End Function

    ''' <summary>
    ''' 機能：統合正契約Payment/詳細ﾌｧｲﾙのOPENﾁｪｯｸ
    ''' 説明：※仮契約統合前ﾁｪｯｸで使用
    ''' </summary>
    ''' <param name="PaymentPath"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function chk_OpenPaymentFile(ByVal PaymentPath As String) As Boolean

        ''初期化
        chk_OpenPaymentFile = True
        Try
            ''ﾌｧｲﾙのOpenﾁｪｯｸ
            Dim ofm As New OioFileManage
            If ofm.ChkOpenedExcelFile(PaymentPath) = False Then
                chk_OpenPaymentFile = False
            End If

        Catch ex As Exception
            Throw ex

        End Try

    End Function


    ''' <summary>
    ''' 機能：仮契約Payment/詳細ﾌｧｲﾙのOPENﾁｪｯｸ
    ''' 説明：※仮契約統合前ﾁｪｯｸで使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Function chk_OpenTmpPaymentFile(ByRef contractList As ArrayList) As Boolean

        ''初期化
        chk_OpenTmpPaymentFile = True
        Try

            ''ﾂﾘｰﾋﾞｭｰで選択した仮契約情報をﾙｰﾌﾟ
            Dim ofm As New OioFileManage
            Dim tmpValue As Trv_ContractInfo_Date
            For Each tmpValue In contractList

                ''ﾁｪｯｸなし/ﾌｧｲﾙなしはﾁｪｯｸ処理しない。
                If tmpValue.Checked = Me.TrvChecked_OFF Then
                    Continue For
                End If
                If tmpValue.FileExist = False Then
                    Continue For
                End If

                ''ﾌｧｲﾙのOpenﾁｪｯｸ
                If ofm.ChkOpenedExcelFile(tmpValue.FilePath) = False Then
                    chk_OpenTmpPaymentFile = False
                End If

            Next
        Catch ex As Exception
            Throw ex

        End Try

    End Function


    ''' <summary>
    ''' 機能：統合済の正契約Noの存在ﾁｪｯｸ
    ''' 説明：※仮契約統合前ﾁｪｯｸで使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Function chk_ExistsUnification(ByRef TBL_M_CONTRACT_TEMP As M_CONTRACT_TEMP, _
                                           ByRef CmbValue As String, _
                                           ByRef contractList As ArrayList, _
                                           ByVal InfoMsg As String, _
                                           ByRef tmpInfoMsg As String) As Boolean

        ''初期化
        chk_ExistsUnification = False

        ''統合済正契約Noの存在ﾁｪｯｸ
        tmpInfoMsg = vbCrLf & InfoMsg
        Dim reUnification As Boolean = False
        Dim rtnValue As String
        Dim Idx As Integer = 0
        Dim chkRow As DataRow
        Dim Sql_ExistsUniContractNo As String
        Sql_ExistsUniContractNo = Get_Sql_ExistsUniContractNo(CmbValue)
        For Each chkRow In TBL_M_CONTRACT_TEMP.Select(Sql_ExistsUniContractNo)

            ''再統合の仮契約が重複するなら、ﾒｯｾｰｼﾞを表示
            reUnification = False
            For Each tmpValue As Trv_ContractInfo_Date In contractList
                If (tmpValue.ContractNo = chkRow.Item(M_CONTRACT_TEMP.COLUMN_NAME_IN_CONTRACT_NO)) And _
                    tmpValue.Checked = Me.TrvChecked_ON Then

                    Idx = Idx + 1
                    chk_ExistsUnification = True

                    ''ﾒｯｾｰｼﾞのｾｯﾄ
                    If (Idx - 1) = 5 Then
                        tmpInfoMsg = tmpInfoMsg & vbCrLf & _
                                     " ⇒その他"
                        Exit Function
                    Else
                        tmpInfoMsg = tmpInfoMsg & vbCrLf & _
                                     " ⇒再統合　:" & chkRow.Item(M_CONTRACT_TEMP.COLUMN_NAME_IN_CONTRACT_NO)
                    End If
                    reUnification = True
                End If
            Next
        Next
    End Function


    ''' <summary>
    ''' 機能：統合済の仮契約の存在ﾁｪｯｸ
    ''' 説明：※仮契約統合前ﾁｪｯｸで使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Function chk_ExistsTmpUnification(ByRef TBL_M_CONTRACT_TEMP As M_CONTRACT_TEMP, _
                                              ByRef contractList As ArrayList, _
                                              ByVal InfoMsg As String, _
                                              ByRef tmpInfoMsg As String) As Boolean

        ''初期化
        chk_ExistsTmpUnification = False
        tmpInfoMsg = vbCrLf & InfoMsg

        Dim dspCount As Integer                ''ﾒｯｾｰｼﾞに表示する仮契約数
        Dim rows() As DataRow
        Dim isExists As Boolean = False        ''
        Dim In_Contract_No As String
        Dim Sql_ExistsUniTmpConstractNo As String
        For Each setValue As Trv_ContractInfo_Date In contractList

            If setValue.Checked = Me.TrvChecked_ON Then

                ''統合済仮契約の存在ﾁｪｯｸ
                In_Contract_No = setValue.ContractNo.PadLeft(3, "0")
                Sql_ExistsUniTmpConstractNo = Get_Sql_ExistsUniTmpConstractNo(Me.Cmb_TmpContract.Text, In_Contract_No)
                rows = TBL_M_CONTRACT_TEMP.Select(Sql_ExistsUniTmpConstractNo)
                If rows.Length > 0 Then
                    isExists = True
                    dspCount = dspCount + 1
                    If dspCount <> 5 Then
                        tmpInfoMsg = tmpInfoMsg & vbCrLf & _
                                     " ⇒仮契約番号:" & In_Contract_No
                    Else
                        tmpInfoMsg = tmpInfoMsg & vbCrLf & _
                                     " ⇒その他"
                        chk_ExistsTmpUnification = True
                        Exit Function
                    End If
                End If

            End If
        Next

        ''戻り値
        If isExists = True Then
            chk_ExistsTmpUnification = True
        End If

    End Function


    ''' <summary>
    ''' 機能：仮契約のﾌｧｲﾙの存在ﾁｪｯｸ
    ''' 説明：※仮契約統合前ﾁｪｯｸで使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Function chk_ExistsTmpUnificationFile(ByRef TBL_M_CONTRACT_TEMP As M_CONTRACT_TEMP, _
                                                  ByRef contractList As ArrayList, _
                                                  ByVal InfoMsg As String, _
                                                  ByRef tmpInfoMsg As String) As Boolean

        ''初期化
        chk_ExistsTmpUnificationFile = False
        tmpInfoMsg = vbCrLf & InfoMsg

        ''ﾂﾘｰﾋﾞｭｰでﾁｪｯｸ済みでかつ、ﾌｧｲﾙが存在しない仮契約を探す
        Dim dspCount As Integer
        Dim treeViewValue As Trv_ContractInfo_Date
        For Each treeViewValue In contractList

            If treeViewValue.Checked = Me.TrvChecked_ON Then
                ''ﾌｧｲﾙの存在ﾁｪｯｸを行う。
                If treeViewValue.FileExist = False Then

                    ''画面への表示ﾒｯｾｰｼﾞを変更
                    chk_ExistsTmpUnificationFile = True
                    dspCount = dspCount + 1
                    If (dspCount - 1) = 5 Then
                        tmpInfoMsg = tmpInfoMsg & vbCrLf & _
                                     " ⇒その他"
                        Exit Function
                    Else
                        tmpInfoMsg = tmpInfoMsg & vbCrLf & _
                                     " ⇒仮契約番号:" & treeViewValue.ContractNo
                    End If
                End If
            End If
        Next

    End Function


    ''' <summary>
    ''' 機能：正契約NoのPayment情報をTableへ格納する。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function Set_XlsPaymentTable(ByVal PaymentPath As String, _
                                         Optional ByVal ValueInsert As Boolean = False) As DataTable

        ''初期化
        Dim XlsPaymentTable = Create_XlsPaymentTable()
        Set_XlsPaymentTable = XlsPaymentTable
        Set_XlsPaymentTable.TableName = Me.Cmb_TmpContract.Text

        ''Excel変数宣言
        Dim xlApp As New Excel.Application
        Dim xlPSBook As Excel.Workbook
        Dim xlOioSheet As Excel.Worksheet
        Dim xlCell As Excel.Range
        Dim xlSearchCell As Excel.Range
        Try

            ''App 初期設定
            xlApp.ScreenUpdating = False
            xlApp.DisplayAlerts = False
            xlApp.EnableEvents = False

            ''Book/Sheetｾｯﾄ
            xlPSBook = xlApp.Workbooks.Open(PaymentPath)
            xlOioSheet = xlPSBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)

            ''App BookOpen後の設定値
            xlApp.Calculation = Excel.XlCalculation.xlCalculationManual

            ''Eofを判定
            Dim Eof As Integer
            xlCell = xlOioSheet.Cells(Me.Excel_PaymentStrRow, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)
            If IsNumeric(xlCell.Value) = False Then
                Exit Function
            End If
            xlSearchCell = xlOioSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.LINE_NO) & ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW & ":" & _
                                            ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.LINE_NO) & xlOioSheet.Rows.Count)

            xlCell = xlSearchCell.Find(What:="", _
                                       LookAt:=Excel.XlLookAt.xlWhole)
            Eof = xlCell.Row - 1

            ''ﾃﾞｰﾀを取得
            Dim tmpValue(,) As Object
            xlCell = xlOioSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG) & ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW & ":" & _
                                      ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12) & Eof)

            ''Unmatchリストでは値でｾｯﾄする。
            If ValueInsert = True Then
                tmpValue = xlCell.Value
            Else
                tmpValue = xlCell.FormulaR1C1Local
            End If

            ''配列の値をDataTableへ格納する。
            Call SetArrayDataInXlsPaymentTable(Me.InputFileKB_Contract, tmpValue, XlsPaymentTable)

            ''正常ﾛｸﾞ書込
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt1, "PSﾌｧｲﾙ")

            Return XlsPaymentTable

        Catch ex As Exception
            ''ｴﾗｰﾛｸﾞ書込
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt2, "PSﾌｧｲﾙ")
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt3, ex.Message)
            Throw ex

        Finally
            ''BookClose前設定変更
            xlApp.ScreenUpdating = True
            xlApp.Calculation = Excel.XlCalculation.xlCalculationAutomatic
            ExcelObjRelease.ReleaseExcelObj(xlSearchCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlOioSheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlPSBook) = False Then
                Call xlPSBook.Close()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.DisplayAlerts = True
            xlApp.EnableEvents = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Function


    ''' <summary>
    ''' 機能：正契約Noの詳細情報をTableへ格納する。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function Set_XlsDetailTable(ByVal DetailPath As String, _
                                        Optional ByVal ValueInsert As Boolean = False) As DataTable

        ''初期化
        Dim XlsDetailTable = Create_XlsDetailTable()
        Set_XlsDetailTable = XlsDetailTable

        ''Excel変数宣言
        Dim xlApp As New Excel.Application
        Dim xlDetailBook As Excel.Workbook
        Dim xlDetailSheet As Excel.Worksheet
        Dim xlCell As Excel.Range
        Dim xlSearchCell As Excel.Range
        Try

            ''App 初期設定
            xlApp.ScreenUpdating = False
            xlApp.DisplayAlerts = False
            xlApp.EnableEvents = False

            ''Book/Sheetｾｯﾄ
            xlDetailBook = xlApp.Workbooks.Open(DetailPath)
            xlDetailSheet = xlDetailBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)

            ''App BookOpen後の設定値
            xlApp.Calculation = Excel.XlCalculation.xlCalculationManual

            ''Eofを判定
            Dim Eof As Integer
            Dim KeyItem(,) As Object
            xlCell = xlDetailSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT) & ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW & ":" & _
                                         ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE) & Excel_PaymentEndRow)
            KeyItem = xlCell.Value
            Dim Idx As Integer
            For Idx = 1 To UBound(KeyItem, 1)

                If ExcelWrite.changeDBNullToString(KeyItem(Idx, 1)) = "" And
                   ExcelWrite.changeDBNullToString(KeyItem(Idx, 2)) = "" And
                   ExcelWrite.changeDBNullToString(KeyItem(Idx, 3)) = "" And
                   ExcelWrite.changeDBNullToString(KeyItem(Idx, 4)) = "" And
                   ExcelWrite.changeDBNullToString(KeyItem(Idx, 5)) = "" Then

                    Eof = ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW + Idx - 2
                    Exit For

                End If
            Next
            If Eof < ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW Then
                Exit Function
            End If

            ''ﾃﾞｰﾀを取得
            Dim tmpValue(,) As Object
            xlCell = xlDetailSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineDetailColumn.UPDATE_FLAG) & ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW & ":" & _
                                         ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE) & Eof)

            ''Unmatchは値で比較する。
            If ValueInsert = True Then
                tmpValue = xlCell.Value
            Else
                tmpValue = xlCell.Formula
            End If

            ''配列の値をDataTableへ格納する。
            Call SetArrayDataInXlsDetailTable(Me.InputFileKB_Contract, tmpValue, XlsDetailTable)

            Call SetChildCount(XlsDetailTable)

            ''正常ﾛｸﾞ書込
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt1, "詳細ﾌｧｲﾙ")

            Return XlsDetailTable

        Catch ex As Exception

            ''ｴﾗｰﾛｸﾞ書込
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt2, "詳細ﾌｧｲﾙ")
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt3, ex.Message)

            Throw ex

        Finally

            ''BookClose前設定変更
            xlApp.ScreenUpdating = True
            xlApp.Calculation = Excel.XlCalculation.xlCalculationAutomatic
            ExcelObjRelease.ReleaseExcelObj(xlSearchCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlDetailSheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlDetailBook) = False Then
                Call xlDetailBook.Close()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlDetailBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()

        End Try

    End Function

    ''' <summary>
    ''' 機能：詳細のS行に紐づくFeatureの数をセットする。
    ''' 説明：
    ''' </summary>
    ''' <param name="XlsDetailTable"></param>
    ''' <remarks></remarks>
    Private Sub SetChildCount(ByRef XlsDetailTable As DataTable)

        Dim filter As New StringBuilder
        Dim SLineRows() As DataRow
        Dim childRows() As DataRow

        ''S行
        filter.Remove(0, filter.Length)
        filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.IDENTITY_FLAG)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation("S"))
        SLineRows = XlsDetailTable.Select(filter.ToString)
        For Each tmpSRow As DataRow In SLineRows
            filter.Remove(0, filter.Length)
            filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(tmpSRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME)))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(tmpSRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX)))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(tmpSRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR)))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.IDENTITY_FLAG)
            filter.Append(CommonConstant.SQL_STR_NOT_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation("S"))
            childRows = XlsDetailTable.Select(filter.ToString)

            tmpSRow.Item(MergeTableColumn_ChildCount) = childRows.Length
        Next

    End Sub


    ''' <summary>
    ''' 機能：仮契約のPayment情報をTableへ格納する。
    ''' 説明：※現状Set_XlsPaymentTableと同じ処理だが、将来的に変更があったときのためガワだけ作る。
    ''' </summary>
    ''' <remarks></remarks>
    Private Function Set_TmpXlsPaymentTable(ByVal ContractNo As String, _
                                            ByVal PaymentPath As String, _
                                            Optional ByVal ValueInsert As Boolean = False) As DataTable

        ''初期化
        Dim TmpXlsPaymentTable = Create_XlsPaymentTable()
        Set_TmpXlsPaymentTable = TmpXlsPaymentTable
        Set_TmpXlsPaymentTable.TableName = ContractNo.PadLeft(3, "0")

        ''Excel変数宣言
        Dim xlApp As New Excel.Application
        Dim xlPSBook As Excel.Workbook
        Dim xlOioSheet As Excel.Worksheet
        Dim xlCell As Excel.Range
        Dim xlSearchCell As Excel.Range
        Try

            ''App 初期設定
            xlApp.ScreenUpdating = False
            xlApp.DisplayAlerts = False
            xlApp.EnableEvents = False

            ''Book/Sheetｾｯﾄ
            xlPSBook = xlApp.Workbooks.Open(PaymentPath)
            xlOioSheet = xlPSBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)

            ''App BookOpen後の設定値
            xlApp.Calculation = Excel.XlCalculation.xlCalculationManual

            ''Eofを判定
            Dim Eof As Integer
            xlCell = xlOioSheet.Cells(Me.Excel_PaymentStrRow, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)
            If IsNumeric(xlCell.Value) = False Then
                Exit Function
            End If
            xlSearchCell = xlOioSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.LINE_NO) & ExcelWrite.EXCEL_COST_PAYMENT_OUTROW & ":" & _
                                            ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.LINE_NO) & xlOioSheet.Rows.Count)
            xlCell = xlSearchCell.Find(What:="", _
                                       LookAt:=Excel.XlLookAt.xlWhole)
            Eof = xlCell.Row - 1

            ''ﾃﾞｰﾀを取得　  
            Dim tmpFormula(,) As Object         ''ﾃﾝﾌﾟﾚｰﾄ行のExcel式
            Dim tmpValue(,) As Object           ''貼付の値
            xlCell = xlOioSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG) & Me.Excel_PaymentStrRow & ":" & _
                                      ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12) & Eof)

            ''Unmatchは値で比較する。
            If ValueInsert = True Then
                tmpValue = xlCell.Value
            Else
                tmpValue = xlCell.FormulaR1C1Local
            End If

            ''配列の値をDataTableへ格納する。  　※Excel式は、ﾃﾝﾌﾟﾚｰﾄ行の式に置き換える。
            Call SetArrayDataInXlsPaymentTable(Me.InputFileKB_TmpContract, tmpValue, TmpXlsPaymentTable)

            ''正常ﾛｸﾞ書込
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt4, ContractNo & " 完了")
            Return TmpXlsPaymentTable

        Catch ex As Exception

            ''異常ﾛｸﾞ書込
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt4, ContractNo & " ※" & "「" & ex.Message & "」")
            Throw ex

        Finally

            ''BookClose前設定変更
            xlApp.ScreenUpdating = True
            xlApp.Calculation = Excel.XlCalculation.xlCalculationAutomatic
            ExcelObjRelease.ReleaseExcelObj(xlSearchCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlOioSheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlPSBook) = False Then
                Call xlPSBook.Close()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Function

    ''' <summary>
    ''' 機能：仮契約の詳細情報をTableへ格納する。
    ''' 説明：※現状Set_XlsDetailTableと同じ処理だが、将来的に変更があったときのためガワだけ作る。
    '''       ※Excelｵﾌﾞｼﾞｪｸﾄが残る場合があったため、修正（2014/9/22）
    ''' </summary>
    ''' <remarks></remarks>
    Private Function Set_TmpXlsDetailTable(ByVal ContractNo As String, _
                                           ByVal DetailPath As String, _
                                           Optional ByVal ValueInsert As Boolean = False) As DataTable

        ''初期化
        Dim XlsDetailTable = Create_XlsDetailTable()
        Set_TmpXlsDetailTable = XlsDetailTable

        ''Excel変数宣言
        Dim xlApp As New Excel.Application
        Dim xlBooks As Excel.Workbooks
        Dim xlDetailBook As Excel.Workbook
        Dim xlSheets As Excel.Sheets
        Dim xlDetailSheet As Excel.Worksheet
        Dim xlCell As Excel.Range

        Try

            ''App 初期設定
            xlApp.ScreenUpdating = False
            xlApp.DisplayAlerts = False
            xlApp.EnableEvents = False

            ''Book/Sheetｾｯﾄ
            xlBooks = xlApp.Workbooks
            xlDetailBook = xlBooks.Open(DetailPath)
            xlSheets = xlDetailBook.Worksheets
            xlDetailSheet = xlSheets.Item(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)

            ''App BookOpen後の設定値
            xlApp.Calculation = Excel.XlCalculation.xlCalculationManual

            ''Eofを判定
            Dim Eof As Integer
            Dim KeyItem(,) As Object
            xlCell = xlDetailSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT) & ExcelWrite.EXCEL_COST_DETAIL_OUTROW & ":" & _
                                         ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineDetailColumn.SEQ) & Excel_PaymentEndRow)
            KeyItem = xlCell.Value
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            Dim Idx As Integer
            For Idx = 1 To UBound(KeyItem, 1)

                If ExcelWrite.changeDBNullToString(KeyItem(Idx, 1)) = "" And
                   ExcelWrite.changeDBNullToString(KeyItem(Idx, 2)) = "" And
                   ExcelWrite.changeDBNullToString(KeyItem(Idx, 3)) = "" And
                   ExcelWrite.changeDBNullToString(KeyItem(Idx, 4)) = "" And
                   ExcelWrite.changeDBNullToString(KeyItem(Idx, 5)) = "" Then

                    Eof = ExcelWrite.EXCEL_COST_DETAIL_OUTROW + Idx - 2

                    Exit For

                End If
            Next
            If Eof < ExcelWrite.EXCEL_COST_DETAIL_OUTROW Then
                Exit Function
            End If

            ''ﾃﾞｰﾀを取得
            Dim tmpValue(,) As Object
            xlCell = xlDetailSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineDetailColumn.UPDATE_FLAG) & ExcelWrite.EXCEL_COST_DETAIL_OUTROW & ":" & _
                                         ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE) & Eof)

            ''Unmatchは値で比較する。
            If ValueInsert = True Then
                tmpValue = xlCell.Value
            Else
                tmpValue = xlCell.Formula
            End If
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            ''配列の値をDataTableへ格納する。
            Call SetArrayDataInXlsDetailTable(Me.InputFileKB_TmpContract, tmpValue, XlsDetailTable)

            Call SetChildCount(XlsDetailTable)

            ''正常ﾛｸﾞ書込
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt4, ContractNo & " 完了")
            Return XlsDetailTable

        Catch ex As Exception
            ''ｴﾗｰﾛｸﾞ書込
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt4, ContractNo & " ※" & "「" & ex.Message & "」")
            Throw ex

        Finally

            ''BookClose前設定変更
            xlApp.ScreenUpdating = True
            xlApp.Calculation = Excel.XlCalculation.xlCalculationAutomatic
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlDetailSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlDetailBook) = False Then
                Call xlDetailBook.Close()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlDetailBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlBooks, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try

    End Function

    ''' <summary>
    ''' 機能：Paymentﾌｧｲﾙの行情報から、仮契約を取得する。
    ''' 説明：
    ''' </summary>
    ''' <param name="inFileKB"></param>
    ''' <param name="Row"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetTmpContractNo(ByVal inFileKB As String, _
                                      ByRef Row As DataRow) As String

        ''初期化
        GetTmpContractNo = ""

        ''正契約 or 仮契約ファイルか判定する。
        Dim tmpValue As String
        Dim tmpContract As String           ''仮契約番号を保管
        Select Case inFileKB

            Case Me.InputFileKB_Contract
                ''正契約ﾌｧｲﾙの処理　※統合元の仮契約を取得
                tmpValue = ExcelWrite.changeDBNullToString(Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME))
                If tmpValue.Length >= 4 And _
                   tmpValue.IndexOf("仮契約No:") <> -1 Then
                    GetTmpContractNo = tmpValue.Substring(tmpValue.Length - 3, 3)
                Else
                    GetTmpContractNo = ""
                End If

            Case Me.InputFileKB_TmpContract
                ''仮契約ﾌｧｲﾙの処理   
                GetTmpContractNo = ExcelWrite.changeDBNullToString(Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT)).PadLeft(3, "0")

        End Select

    End Function


    ''' <summary>
    ''' 機能：詳細ﾌｧｲﾙの行情報から、仮契約を取得する。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetDTmpContractNo(ByVal inFileKB As String, _
                                       ByRef Row As DataRow) As String

        ''初期化
        GetDTmpContractNo = ""

        ''正契約 or 仮契約ファイルか判定する。
        Dim tmpValue As String
        Dim tmpContract As String           ''仮契約番号を保管
        Select Case inFileKB

            Case Me.InputFileKB_Contract
                ''正契約ﾌｧｲﾙの処理　※統合元の仮契約を取得
                tmpValue = ExcelWrite.changeDBNullToString(Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME))
                If tmpValue.Length >= 4 And _
                   tmpValue.IndexOf("仮契約No:") <> -1 Then
                    GetDTmpContractNo = tmpValue.Substring(tmpValue.Length - 3, 3)
                Else
                    GetDTmpContractNo = ""
                End If

            Case Me.InputFileKB_TmpContract
                ''仮契約ﾌｧｲﾙの処理   
                GetDTmpContractNo = ExcelWrite.changeDBNullToString(Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT)).PadLeft(3, "0")

        End Select

    End Function


    ''' <summary>
    ''' 機能：Paymentﾌｧｲﾙの行情報から、仮契約を取得する。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Get_MergeTable(ByVal PaymentPath As String, _
                               ByRef contractList As ArrayList, _
                               ByRef MergePaymentTable As DataTable, _
                               ByRef MergeDetailTable As DataTable, _
                               ByRef XlsPaymentTable As DataTable, _
                               ByRef XlsDetailTable As DataTable, _
                               ByRef TmpXlsPaymentTable() As DataTable, _
                               ByRef TmpXlsDetailTable() As DataTable, _
                               ByRef UpdM_ContractTmpList As ArrayList)

        Try
            ''初期化
            MergePaymentTable = Create_XlsPaymentTable()
            MergeDetailTable = Create_XlsDetailTable()

            ''Payment情報の統合
            Call Merge_PaymentTable(PaymentPath, contractList, MergePaymentTable, XlsPaymentTable, TmpXlsPaymentTable, UpdM_ContractTmpList)

            ''Detail情報の統合
            Call Merge_DetailTable(contractList, MergeDetailTable, XlsDetailTable, TmpXlsDetailTable, UpdM_ContractTmpList)

            ''MergeTableの値を更新
            Call Upd_MergeTableDate(MergePaymentTable, MergeDetailTable)

            ''正常ﾛｸﾞ書込
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt1, "マージ処理")

        Catch ex As Exception
            ''ｴﾗｰﾛｸﾞ書込
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt2, "マージ処理")
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt3, ex.Message)

            Throw ex

        End Try

    End Sub


    ''' <summary>
    ''' 機能：Paymentデータと詳細ﾃﾞｰﾀから、削除対象ﾃﾞｰﾀにFLGを立てる
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Get_DelMergeTable(ByVal PaymentPath As String, _
                                  ByRef contractList As ArrayList, _
                                  ByRef MergePaymentTable As DataTable, _
                                  ByRef MergeDetailTable As DataTable, _
                                  ByRef XlsPaymentTable As DataTable, _
                                  ByRef XlsDetailTable As DataTable, _
                                  ByRef UpdM_ContractTmpList As ArrayList)

        ''処理補足
        ''  「Merge_PaymentTable」と、「Merge_DetailTable」は統合処理のモジュールをそのまま使いまわし。
        ''　「正契約削除処理」+ 「仮契約追加処理」で成り立っているので、仮契約情報の引数にﾃﾞｰﾀ0件のダミー情報を渡す。   
        ''　 大幅な仕様変更があれば別モジュール化する。  
        Try
            ''初期化
            MergePaymentTable = Create_XlsPaymentTable()
            MergeDetailTable = Create_XlsDetailTable()

            ''Payment情報の統合          
            Dim DummyTable(-1) As DataTable
            Call Merge_PaymentTable(PaymentPath, contractList, MergePaymentTable, XlsPaymentTable, DummyTable, UpdM_ContractTmpList)

            ''Detail情報の統合
            Call Merge_DetailTable(contractList, MergeDetailTable, XlsDetailTable, DummyTable, UpdM_ContractTmpList)

            ''正常ﾛｸﾞ書込
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt1, "マージ処理")

        Catch ex As Exception
            ''ｴﾗｰﾛｸﾞ書込
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt2, "マージ処理")
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt3, ex.Message)

            Throw ex

        End Try
    End Sub


    ''' <summary>
    ''' 機能：正契約Paymentﾌｧｲﾙと仮契約Paymentﾌｧｲﾙを統合する。
    ''' 説明：※Merge_DetailTableで使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Merge_PaymentTable(ByVal PaymentPath As String, _
                                   ByRef contractList As ArrayList, _
                                   ByRef MergePaymentTable As DataTable, _
                                   ByRef XlsPaymentTable As DataTable, _
                                   ByRef TmpXlsPaymentTable() As DataTable, _
                                   ByRef UpdM_ContractTmpList As ArrayList)


        Try
            ''                  以下、正契約ﾃﾞｰﾀのマージ作業
            ''--------------------------------------------------------------
            Dim maxLineNo As Integer                        ''PaymentﾌｧｲﾙのLineNoのMax値をｾｯﾄ   ※仮契約のLinNoの開始位置にしよう
            Dim isUniDate As Boolean = False                ''フラグ：統合済仮契約の有無を判定
            Dim InsRow As DataRow
            Dim tmpRow As DataRow
            Dim tmpContract As Trv_ContractInfo_Date
            maxLineNo = CInt(Me.Cmb_TmpContract.Text & "00000")
            For Each tmpRow In XlsPaymentTable.Rows

                ''Paymentﾌｧｲﾙから既に統合済みの仮契約があれば、削除Flgを立てる。
                InsRow = MergePaymentTable.NewRow
                InsRow.ItemArray = tmpRow.ItemArray
                isUniDate = False
                For Each tmpContract In contractList
                    If tmpContract.ContractNo = tmpRow.Item(MergeTableColumn_TmpContract) And _
                       tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT).ToString.PadLeft(3, "0") = Me.Cmb_TmpContract.Text Then
                        isUniDate = True
                        Exit For
                    End If
                Next
                If isUniDate = True Then
                    InsRow.Item(Me.MergeTableColumn_DelInsert) = Me.DelInsert_Delete
                Else
                    InsRow.Item(Me.MergeTableColumn_DelInsert) = Me.DelInsert_None
                End If

                ''Sort用に先頭0埋ﾃﾞｰﾀをｾｯﾄ
                InsRow.Item(Me.MergeTableColumn_SortContract) = ""                 ''正契約はSort不要
                InsRow.Item(Me.MergeTableColumn_SortLineNo) = ""                   ''正契約はSort不要

                ''LinnoのMax値を取得
                If IsNumeric(tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO)) = True AndAlso _
                   CInt(tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO)) > maxLineNo AndAlso _
                   Not (tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG) = "U" And tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG) = "C") Then
                    maxLineNo = CInt(tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO))
                End If

                ''ﾃﾞｰﾀの追加
                MergePaymentTable.Rows.Add(InsRow)

            Next

            ''                  以下、仮契約ﾃﾞｰﾀのマージ作業
            ''--------------------------------------------------------------
            Dim Idx As Integer
            Dim TmpXlsPaymentDate As DataTable
            Dim contractNo As String                ''一時変数：正契約No
            Dim tmpItem14 As String                 ''一時変数：項目14ｾｯﾄする値        
            Dim tmpSerial As String                 ''一時変数：仮ｼﾘｱﾙ
            Dim tmpPatternCd As String              ''一時変数：ﾊﾟﾀｰﾝCD          ※仮ｼﾘｱﾙの採番に使用
            Dim tmpSerialIdx As String              ''一時変数：ｼﾘｱﾙの位置       ※仮ｼﾘｱﾙの採番に使用
            Dim tmpInFileNM As String               ''一時変数：ファイル名
            Dim UpdMContractTemp As UPD_M_CONTRACT_TEMP
            contractNo = Me.Cmb_TmpContract.Text
            For Idx = 0 To TmpXlsPaymentTable.Length - 1

                ''ﾃｰﾌﾞﾙ行のﾙｰﾌﾟ
                TmpXlsPaymentDate = TmpXlsPaymentTable(Idx)

                ''仮ｼﾘｱﾙの更新
                ''※Copy元/削除元に紐づくﾃﾞｰﾀを更新対象外にするため、別のモジュールで処理をする。
                Call UpdTmpSerial(TmpXlsPaymentDate, contractNo)

                For Each tmpRow In TmpXlsPaymentDate.Rows

                    ''抽出条件　　※作成中か、更新Flg = U and 締結済みしか出力しない。
                    If tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG) = "" Then

                        InsRow = MergePaymentTable.NewRow
                        InsRow.ItemArray = tmpRow.ItemArray

                        ''ﾌｧｲﾙ名ｾｯﾄ  ※仮契約番号を末尾にｾｯﾄ
                        InsRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME) = tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME) & _
                                                                                         Me.FileName_TmpConstract & _
                                                                                         contractList(Idx).ContractNo


                        ''契約順番ｾｯﾄ
                        InsRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT) = contractNo

                        ''項目14ｾｯﾄ
                        tmpItem14 = tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO)
                        InsRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM14) = tmpItem14

                        ''Linnoの再採番
                        maxLineNo = maxLineNo + 1
                        InsRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO) = maxLineNo

                        ''                              以下、仮ｼﾘｱﾙの再採番
                        ''-----------------------------------------------------------------------------
                        ''仮ｼﾘｱﾙの位置を取得
                        tmpSerialIdx = "CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02

                        ''仮ｼﾘｱﾙの存在すれば再際番
                        '' ※"@H" & "正契約NO(3桁)" & "仮契約NO(3桁)" & "SEQ(4桁)"
                        InsRow.Item(tmpSerialIdx) = tmpRow.Item(tmpSerialIdx)

                        ''追加/削除のFlgを立てる
                        InsRow.Item(Me.MergeTableColumn_DelInsert) = Me.DelInsert_Insert

                        ''Sort用に先頭"0"埋めしたﾃﾞｰﾀを取得
                        InsRow.Item(Me.MergeTableColumn_SortContract) = InsRow.Item(MergeTableColumn_TmpContract).PadLeft(3, "0")
                        InsRow.Item(Me.MergeTableColumn_SortLineNo) = InsRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO).PadLeft(10, "0")

                        ''ﾃﾞｰﾀの追加
                        MergePaymentTable.Rows.Add(InsRow)

                    ElseIf tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG) = "U" And tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG) = "C" Then

                        ''締結済ﾃﾞｰﾀは極力値を修正しない。
                        InsRow = MergePaymentTable.NewRow
                        InsRow.ItemArray = tmpRow.ItemArray

                        ''追加/削除のFlgを立てる
                        InsRow.Item(Me.MergeTableColumn_DelInsert) = Me.DelInsert_Insert

                        ''Sort用に先頭"0"埋めしたﾃﾞｰﾀを取得
                        InsRow.Item(Me.MergeTableColumn_SortContract) = InsRow.Item(MergeTableColumn_TmpContract).PadLeft(3, "0")
                        InsRow.Item(Me.MergeTableColumn_SortLineNo) = InsRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO).PadLeft(10, "0")

                        ''ﾃﾞｰﾀの追加
                        MergePaymentTable.Rows.Add(InsRow)

                    End If

                Next

                ''仮契約Table更新用情報を取得
                tmpInFileNM = ""
                For Each tmpContract In contractList
                    If TmpXlsPaymentTable(Idx).TableName = tmpContract.ContractNo Then
                        tmpInFileNM = Path.GetFileName(tmpContract.FilePath)
                        Exit For
                    End If
                Next
                UpdMContractTemp.InPsFileName = tmpInFileNM                        ''統合元 PSﾌｧｲﾙ名
                UpdMContractTemp.UnifiPSCount = TmpXlsPaymentDate.Rows.Count       ''統合件数：PSﾌｧｲﾙ                 
                UpdMContractTemp.UnMatchPSCount = 0                                ''Unmatch ：PSﾌｧｲﾙ
                Call UpdM_ContractTmpList.Add(UpdMContractTemp)
            Next

            ''ﾃｰﾌﾞﾙのｿｰﾄ   ※正契約ﾌｧｲﾙ⇒仮契約ﾌｧｲﾙ/契約番号/Linno順  
            Dim tmpView As New DataView(MergePaymentTable)
            tmpView.Sort = Me.MergeTableColumn_ContractKB & CommonConstant.STR_COMMA & _
                           Me.MergeTableColumn_SortContract & CommonConstant.STR_COMMA & _
                           Me.MergeTableColumn_SortLineNo
            MergePaymentTable = tmpView.ToTable()

        Catch ex As Exception
            Throw ex

        End Try

    End Sub


    ''' <summary>
    ''' 機能：正契約詳細ﾌｧｲﾙと仮契約詳細ﾌｧｲﾙを統合する。
    ''' 説明：Merge_DetailTableで使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Merge_DetailTable(ByRef contractList As ArrayList, _
                                  ByRef MergeDetailTable As DataTable, _
                                  ByRef XlsDetailTable As DataTable, _
                                  ByRef TmpXlsDetailTable() As DataTable, _
                                  ByRef UpdM_ContractTmpList As ArrayList)


        ''                  以下、正契約ﾃﾞｰﾀのマージ作業
        ''--------------------------------------------------------------
        Dim isUniDate As Boolean                        ''画面で選択した仮契約の有無
        Dim InsRow As DataRow
        Dim tmpRow As DataRow
        For Each tmpRow In XlsDetailTable.Rows

            ''ﾃﾞｰﾀの追加
            InsRow = MergeDetailTable.NewRow
            InsRow.ItemArray = tmpRow.ItemArray
            InsRow.Item(MergeTableColumn_ContractKB) = Me.InputFileKB_Contract

            ''画面で選択した仮契約と一致した場合、削除Flgを立てる。
            isUniDate = False
            For Each tmpContract As Trv_ContractInfo_Date In contractList
                If tmpContract.ContractNo = tmpRow.Item(MergeTableColumn_TmpContract) Then
                    isUniDate = True
                    Exit For
                End If
            Next
            If isUniDate = True Then
                InsRow.Item(Me.MergeTableColumn_DelInsert) = Me.DelInsert_Delete
            Else
                InsRow.Item(Me.MergeTableColumn_DelInsert) = Me.DelInsert_None
            End If
            InsRow.Item(Me.MergeTableColumn_SortContract) = tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT).ToString.PadLeft(3, "0")
            InsRow.Item(Me.MergeTableColumn_ExcelLine) = tmpRow.Item(MergeTableColumn_ExcelLine).ToString.PadLeft(8, "0")

            MergeDetailTable.Rows.Add(InsRow)

        Next

        ''                  以下、仮契約ﾃﾞｰﾀのマージ作業
        ''--------------------------------------------------------------
        Dim Idx As Integer
        Dim TmpXlsDetailDate As DataTable
        Dim contractNo As String                ''一時変数：正契約No
        Dim fileName As String                  ''一時変数：ファイル名
        contractNo = Me.Cmb_TmpContract.Text
        For Idx = 0 To TmpXlsDetailTable.Length - 1

            ''ﾃｰﾌﾞﾙ行のﾙｰﾌﾟ
            TmpXlsDetailDate = TmpXlsDetailTable(Idx)
            For Each tmpRow In TmpXlsDetailDate.Rows

                InsRow = MergeDetailTable.NewRow
                InsRow.ItemArray = tmpRow.ItemArray


                ''契約順番ｾｯﾄ
                InsRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT) = contractNo

                ''ﾌｧｲﾙ名ｾｯﾄ  ※仮契約番号を末尾にｾｯﾄ
                InsRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME) = tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME) & _
                                                                                       Me.FileName_TmpConstract & _
                                                                                       contractList(Idx).ContractNo

                InsRow.Item(MergeTableColumn_DelInsert) = Me.DelInsert_Insert
                InsRow.Item(MergeTableColumn_ContractKB) = Me.InputFileKB_TmpContract
                InsRow.Item(Me.MergeTableColumn_SortContract) = tmpRow.Item(Me.MergeTableColumn_TmpContract).ToString.PadLeft(3, "0")
                InsRow.Item(Me.MergeTableColumn_ExcelLine) = tmpRow.Item(MergeTableColumn_ExcelLine).ToString.PadLeft(8, "0")

                ''ﾃﾞｰﾀの追加
                MergeDetailTable.Rows.Add(InsRow)

            Next

            ''仮契約Table更新用情報を取得
            Dim TmpUpdM_ContractTmpList As UPD_M_CONTRACT_TEMP
            TmpUpdM_ContractTmpList = UpdM_ContractTmpList(Idx)
            TmpUpdM_ContractTmpList.TmpContract = contractList(Idx).ContractNo        ''仮契約番号
            TmpUpdM_ContractTmpList.UnifiDetailCount = TmpXlsDetailDate.Rows.Count    ''統合件数
            TmpUpdM_ContractTmpList.UnMatchDetailCount = 0                            ''Unmatch件数 
            UpdM_ContractTmpList(Idx) = TmpUpdM_ContractTmpList

        Next

        ''ﾃｰﾌﾞﾙのｿｰﾄ   ※正契約ﾌｧｲﾙ⇒仮契約ﾌｧｲﾙ/契約番号/Linno順  
        Dim tmpView As New DataView(MergeDetailTable)
        tmpView.Sort = Me.MergeTableColumn_SortContract & CommonConstant.SQL_STR_DESC & CommonConstant.STR_COMMA & _
                       Me.MergeTableColumn_ExcelLine
        MergeDetailTable = tmpView.ToTable()

    End Sub


    ''' <summary>
    ''' 機能：正契約詳細ﾌｧｲﾙと仮契約詳細ﾌｧｲﾙの統合情報をUpdateする。
    ''' 説明：Merge_DetailTableで使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Upd_MergeTableDate(ByRef MergePaymentTable As DataTable, _
                                   ByRef MergeDetailTable As DataTable)


        Try
            ''戻り値の初期化
            Dim UpdMergePaymentTable As DataTable
            Dim UpdMergeDetailTable As DataTable
            UpdMergePaymentTable = MergePaymentTable.Copy
            UpdMergeDetailTable = MergeDetailTable.Copy


            ''   以下、削除ﾃﾞｰﾀ作成で作った更新F = U,締結済みのﾃﾞｰﾀの重複ﾁｪｯｸをする。
            ''-----------------------------------------------------------------------
            Dim errMsg As String
            If DistinctContractDelMacroDate(MergePaymentTable, errMsg) = True Then
                Throw New Exception(errMsg)
            End If


            ''戻り値ｾｯﾄ
            MergePaymentTable = UpdMergePaymentTable
            MergeDetailTable = UpdMergeDetailTable

        Catch ex As Exception
            Throw ex
        End Try
    End Sub


    ''' <summary>
    ''' 機能：仮契約統合後のExcelﾌｧｲﾙを作成する。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Create_UnificationXls(ByVal PaymentPath As String, _
                                      ByRef MergePaymentTable As DataTable, _
                                      ByRef MergeDetailTable As DataTable)

        Dim isActSuccess As Boolean = False     ''処理が成功したかどうか　※ファイル名のSuffixの更新するために使用

        ''Excel変数の宣言
        Dim xlApp As New Excel.Application
        Dim xlPaymentBook As Excel.Workbook
        Dim xlOioSheet As Excel.Worksheet
        Dim xlDetailSheet As Excel.Worksheet
        Dim xlCell As Excel.Range
        Try

            ''App初期化
            xlApp.EnableEvents = False
            xlApp.DisplayAlerts = False
            xlApp.ScreenUpdating = False

            ''BookのOpen
            xlPaymentBook = xlApp.Workbooks.Open(PaymentPath)
            xlApp.Calculation = Excel.XlCalculation.xlCalculationManual

            ''再統合の場合、Bookから統合済みのﾃﾞｰﾀを削除する。
            Call Del_UniContractXlsDate(xlPaymentBook, _
                                        MergePaymentTable, _
                                        MergeDetailTable)

            ''統合後のﾃﾞｰﾀが65000件を超えるﾃﾞｰﾀの場合、ｴﾗｰﾒｯｾｰｼﾞを表示する。
            Const ErrMaxCount As Integer = 65000
            Dim countSQL As String
            countSQL = MergeTableColumn_DelInsert & _
                                        CommonConstant.SQL_STR_NOT_EQUAL & _
                                        StringEdit.EncloseSingleQuotation(Me.DelInsert_Delete)
            If (MergePaymentTable.Select(countSQL).Length + 1) > ErrMaxCount Or _
                (MergeDetailTable.Select(countSQL).Length + 1) > ErrMaxCount Then

                ''統合後のﾃﾞｰﾀ出力件数が65000件を超えました。
                Throw New Exception(FileReader.GetMessage("MSG_0375").Replace("@1", (MergePaymentTable.Select(countSQL).Length + 1)).Replace("@2", (MergeDetailTable.Select(countSQL).Length + 1)))

            End If

            ''ｵｰﾄﾌｨﾙﾀの設定値をOffにする。   ｵｰﾄﾌｨﾙﾀ解除 ⇒　ｵｰﾄﾌｨﾙﾀ再設定
            ''※Excelの謎仕様：ｵｰﾄﾌｨﾙﾀ、Window枠の操作をする場合、ScreenUpdate Off　And ｼｰﾄのActive処理が必要。
            xlApp.ScreenUpdating = True
            xlOioSheet = xlPaymentBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)
            xlDetailSheet = xlPaymentBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)
            xlOioSheet.AutoFilterMode = False
            xlDetailSheet.AutoFilterMode = False
            xlCell = xlOioSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG) & ExcelWrite.EXCEL_COST_PAYMENT_OUTROW - 1 & ":" & _
                                      ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12) & ExcelWrite.EXCEL_COST_PAYMENT_OUTROW - 1)
            Call xlOioSheet.Activate()
            Call xlCell.Select()
            Call xlApp.Selection.autofilter()
            xlCell = xlDetailSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineDetailColumn.UPDATE_FLAG) & ExcelWrite.EXCEL_COST_DETAIL_OUTROW - 1 & ":" & _
                                         ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE) & ExcelWrite.EXCEL_COST_DETAIL_OUTROW - 1)
            Call xlDetailSheet.Activate()
            Call xlCell.Select()
            Call xlApp.Selection.autofilter()
            Call xlOioSheet.Activate()
            xlApp.ScreenUpdating = False

            ''ﾃﾝﾌﾟﾚｰﾄ行のExcel式を取得
            Dim PsFormula(,) As Object
            Dim DetailSumFormula(,) As Object
            Dim DetailFormula(,) As Object
            xlCell = xlOioSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG) & ExcelWrite.EXCEL_PAYMENTLINE_TMPROW & ":" & _
                                      ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12) & ExcelWrite.EXCEL_PAYMENTLINE_TMPROW)
            PsFormula = xlCell.FormulaR1C1Local
            xlCell = xlDetailSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineDetailColumn.UPDATE_FLAG) & ExcelWrite.EXCEL_PAYMENTDETAIL_SUMTMPROW & ":" & _
                                         ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE) & ExcelWrite.EXCEL_PAYMENTDETAIL_SUMTMPROW)
            DetailSumFormula = xlCell.FormulaR1C1Local

            xlCell = xlDetailSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineDetailColumn.UPDATE_FLAG) & ExcelWrite.EXCEL_PAYMENTDETAIL_TMPROW & ":" & _
                                         ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE) & ExcelWrite.EXCEL_PAYMENTDETAIL_TMPROW)
            DetailFormula = xlCell.FormulaR1C1Local


            ''統合ファイル出力用のデータを取得
            Dim xlsPasteArea As PasteArea
            Dim outPaymentData(,) As Object                         ''Paymentへ出力用配列
            Dim outDetailData(,) As Object                          ''詳細へ出力用配列
            Call Get_OutExcelArrayFromTable(xlsPasteArea, _
                                            outPaymentData, _
                                            outDetailData, _
                                            PsFormula, _
                                            DetailFormula, _
                                            DetailSumFormula, _
                                            MergePaymentTable, _
                                            MergeDetailTable)

            ''統合後のﾌｧｲﾙ作成
            If IsNothing(outPaymentData) = False Then
                Call OutUniXlsPaymentFile(xlsPasteArea, xlPaymentBook, outPaymentData)
            End If
            If IsNothing(outDetailData) = False Then
                Call OutUniXlsDetailFile(xlsPasteArea, xlPaymentBook, outDetailData)
            End If

            ''Bookの別名保存 ※保存前に、「自動計算機能」をONにする。
            xlApp.Calculation = Excel.XlCalculation.xlCalculationAutomatic
            '※VBActNMListに統合
            Call ExcelWrite.KickVBABookSave(xlApp, xlPaymentBook, ExcelWrite.VBActNMList.仮契約統合, CommonVariable.USERID, CommonVariable.USERPW)


            ''正常ﾛｸﾞ書込
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt1, "書込処理")
            isActSuccess = True

        Catch ex As Exception
            ''ｴﾗｰﾛｸﾞ書込
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt2, "書込処理")
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt3, ex.Message)
            Throw ex

        Finally
            ''Excelの開放
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlDetailSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlOioSheet, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.DisplayAlerts = False
            If IsNothing(xlPaymentBook) = False Then
                xlPaymentBook.Close()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlPaymentBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try
    End Sub


    ''' <summary>
    ''' 機能：統合済の仮契約ﾃﾞｰﾀを削除する。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Del_UniContractXlsDate(ByRef xlPaymentBook As Excel.Workbook, _
                                       ByRef MergePaymentTable As DataTable, _
                                       ByRef MergeDetailTable As DataTable)

        Dim xlOioSheet As Excel.Worksheet
        Dim xlDetailSheet As Excel.Worksheet
        Dim xlDelRow As Excel.Range
        Try

            ''ｼｰﾄのｾｯﾄ
            xlOioSheet = xlPaymentBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)
            xlDetailSheet = xlPaymentBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)

            ''                  以下、Paymentの処理
            ''---------------------------------------------------------------
            ''Paymentﾌｧｲﾙの削除対象ﾃﾞｰﾀ取得  
            Dim delPaymentDataArray As ArrayList
            delPaymentDataArray = GetArrayInExcelDelPaymentData(MergePaymentTable)

            ''Paymentﾌｧｲﾙの削除対象ﾃﾞｰﾀの値を元にExcelを削除
            For Each tmpValue As String In delPaymentDataArray

                xlDelRow = xlOioSheet.Rows(tmpValue)
                Call xlDelRow.Delete()

            Next


            ''                  以下、詳細の処理
            ''---------------------------------------------------------------
            ''Detailﾌｧｲﾙの削除対象ﾃﾞｰﾀ取得  
            Dim delDetailDataArray As ArrayList
            delDetailDataArray = GetArrayInExcelDelDetailData(MergeDetailTable)

            ''Detailﾌｧｲﾙの削除対象ﾃﾞｰﾀの値を元にExcelを削除
            For Each tmpValue As String In delDetailDataArray

                xlDelRow = xlDetailSheet.Rows(tmpValue)
                Call xlDelRow.Delete()

            Next

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlDelRow, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlDetailSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlOioSheet, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try


    End Sub


    ''' <summary>
    ''' 機能：統合済の削除対象仮契約ﾃﾞｰﾀを配列にｾｯﾄ
    ''' 説明：※Del_UniContractXlsDateで使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetArrayInExcelDelPaymentData(ByRef MergePaymentTable As DataTable) As ArrayList

        Try
            ''初期化     
            Dim rtnArrayList = New ArrayList

            ''Paymentﾌｧｲﾙから、削除対象ﾃﾞｰﾀ件数を取得
            Dim count As Integer
            Dim DelPaymentRows() As DataRow
            Dim Sql_DeleteMergePaymentTable As String
            Sql_DeleteMergePaymentTable = Get_Sql_DeleteMergePaymentTable()
            DelPaymentRows = MergePaymentTable.Select(Sql_DeleteMergePaymentTable)
            count = DelPaymentRows.Length
            If count = 0 Then                               ''0件なら終了
                Return rtnArrayList
            End If

            ''削除対象行を配列に格納する。
            ''※1行づつ削除すると効率が悪いため、連番の場合「2:4」のようにまとめる。
            Dim tmpIdx As Integer
            Dim DelStrIdx As Integer                        ''削除開始位置
            Dim DelEndIdx As Integer                        ''削除終了位置
            Dim setValue As String                          ''DelArrayInPaymentに挿入用
            Dim DelArrayInPayment As New ArrayList          ''削除対象行を格納
            For i As Integer = count - 1 To 0 Step -1

                ''初回の処理
                If i = count - 1 Then
                    DelStrIdx = CInt(DelPaymentRows(i).Item(MergeTableColumn_ExcelLine))
                    DelEndIdx = CInt(DelPaymentRows(i).Item(MergeTableColumn_ExcelLine))
                End If

                ''次の値 =　連番の場合、行削除を行わず次の値へ
                DelStrIdx = CInt(DelPaymentRows(i).Item(MergeTableColumn_ExcelLine))
                If i <> 0 AndAlso _
                   CInt(DelPaymentRows(i).Item(MergeTableColumn_ExcelLine)) - 1 = CInt(DelPaymentRows(i - 1).Item(MergeTableColumn_ExcelLine)) Then

                    ''処理なし

                Else
                    ''連番以外の場合、削除範囲を確定する。
                    setValue = DelStrIdx & ":" & DelEndIdx
                    rtnArrayList.Add(setValue)
                    DelStrIdx = CInt(DelPaymentRows(i).Item(MergeTableColumn_ExcelLine))
                    DelEndIdx = CInt(DelPaymentRows(i).Item(MergeTableColumn_ExcelLine))

                End If
            Next
            Return rtnArrayList

        Catch ex As Exception
            Throw ex

        End Try

    End Function


    ''' <summary>
    ''' 機能：統合済の削除対象仮契約ﾃﾞｰﾀを配列にｾｯﾄ
    ''' 説明：※Del_UniContractXlsDateで使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetArrayInExcelDelDetailData(ByRef MergeDetailTable As DataTable) As ArrayList

        ''初期化     
        Dim rtnArrayList = New ArrayList

        ''Detailﾌｧｲﾙから、削除対象ﾃﾞｰﾀ件数を取得
        Dim count As Integer
        Dim DelDetailRows() As DataRow
        Dim Sql_DeleteMergeDetailTable As String
        Sql_DeleteMergeDetailTable = Get_Sql_DeleteMergeDetailTable()
        DelDetailRows = MergeDetailTable.Select(Sql_DeleteMergeDetailTable)
        count = DelDetailRows.Length - 1

        ''0件なら処理を行わない。
        If count <= 0 Then
            Return rtnArrayList
        End If


        ''削除対象行を配列に格納する。
        ''※1行づつ削除すると効率が悪いため、連番の場合「2:4」のようにまとめる。
        Dim tmpIdx As Integer
        Dim DelStrIdx As Integer                        ''削除開始位置
        Dim DelEndIdx As Integer                        ''削除終了位置
        Dim setValue As String                          ''DelArrayInDetailに挿入用
        Dim DelArrayInDetail As New ArrayList           ''削除対象行を格納
        Dim Dellist As Boolean

        Dellist = True

        For i As Integer = count To 0 Step -1

            ''範囲初期化の処理
            If Dellist = True Then
                DelStrIdx = CInt(DelDetailRows(i).Item(MergeTableColumn_ExcelLine))
                DelEndIdx = CInt(DelDetailRows(i).Item(MergeTableColumn_ExcelLine))
                Dellist = False
            End If

            ''次の値 =　連番の場合、行削除を行わず次の値へ
            DelStrIdx = CInt(DelDetailRows(i).Item(MergeTableColumn_ExcelLine))
            If i <> 0 AndAlso _
               CInt(DelDetailRows(i).Item(MergeTableColumn_ExcelLine)) - 1 = CInt(DelDetailRows(i - 1).Item(MergeTableColumn_ExcelLine)) Then

                ''処理なし

            Else
                setValue = DelStrIdx & ":" & DelEndIdx
                rtnArrayList.Add(setValue)
                Dellist = True
            End If
        Next


        Return rtnArrayList

    End Function


    ''' <summary>
    ''' 機能：DataTableの値を配列へ変換する。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Get_OutExcelArrayFromTable(ByRef xlsPasteArea As PasteArea, _
                                           ByRef outPaymentData(,) As Object, _
                                           ByRef outDetailData(,) As Object, _
                                           ByRef PsFormula(,) As Object, _
                                           ByRef DetailFormula(,) As Object, _
                                           ByRef DetailSumFormula(,) As Object, _
                                           ByRef MergePaymentTable As DataTable, _
                                           ByRef MergeDetailTable As DataTable)


        ''貼付範囲の取得
        xlsPasteArea = GetXlsPasteArea(MergePaymentTable, MergeDetailTable)

        ''Payment/詳細のTable情報を配列へ変換する。
        outPaymentData = GetOutPaymentData(MergePaymentTable, PsFormula)
        outDetailData = GetOutDetailData(MergeDetailTable, DetailFormula, DetailSumFormula, xlsPasteArea.Str_PasteDetail)


    End Sub


    ''' <summary>
    ''' 機能：MergePaymentTableの値を配列へ変換する。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetOutPaymentData(ByRef MergePaymentTable As DataTable, _
                                       ByRef PsFormula(,) As Object) As Object(,)

        ''戻り値宣言
        Dim rtnValue(,) As Object

        ''配列の領域確保
        Dim PSRows() As DataRow
        Dim arrayCount As Integer
        Dim Sql_GetContractOutPaymentData As String
        Sql_GetContractOutPaymentData = GetSql_GetContractOutPaymentData()
        PSRows = MergePaymentTable.Select(Sql_GetContractOutPaymentData)

        ''値がなければ処理終了
        If PSRows.Length = 0 Then
            Return Nothing
        End If

        ''配列の値をｾｯﾄ
        arrayCount = PSRows.Length - 1
        ReDim rtnValue(arrayCount, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12 - 1)
        For Idx As Integer = 0 To arrayCount
            For IdxD As Integer = 0 To ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12 - 1
                ''展開金額
                If IdxD = ExcelWrite.ExcelPaymentLineColumn.PRICE_TO_SPLIT - 1 Then
                    ''Payment展開Flgに応じて、固定値⇔計算式をセット
                    Select Case PSRows(Idx).Item(ExcelWrite.ExcelPaymentLineColumn.PAY_FLAG - 1)
                        Case ExcelWrite.Payflg_Value
                            ''値
                            rtnValue(Idx, IdxD) = PSRows(Idx).Item(IdxD)
                            Continue For
                        Case ExcelWrite.Payflg_Irregular
                            ''式 --何も処理をしない。                                                  
                        Case Else
                            ''式 --何も処理をしない。                                                  
                    End Select
                End If
                ''月額　※Payment展開Flgに応じて、固定値⇔計算式をセット
                If IdxD >= ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1 - 1 Then
                    Select Case PSRows(Idx).Item(ExcelWrite.ExcelPaymentLineColumn.PAY_FLAG - 1)
                        Case ExcelWrite.Payflg_Value
                            ''式 --何も処理をしない。                                                       
                        Case ExcelWrite.Payflg_Irregular
                            ''値
                            rtnValue(Idx, IdxD) = PSRows(Idx).Item(IdxD)
                            Continue For
                        Case Else
                            ''式 --何も処理をしない。                                                       
                    End Select
                End If

                ''Excelのﾃﾝﾌﾟﾚ-ﾄ行に式があれば、式を優先
                If PsFormula(1, IdxD + 1).ToString.IndexOf("=") <> -1 Then
                    rtnValue(Idx, IdxD) = PsFormula(1, IdxD + 1)
                Else
                    rtnValue(Idx, IdxD) = PSRows(Idx).Item(IdxD)
                End If
            Next
        Next
        Return rtnValue

    End Function


    ''' <summary>
    ''' 機能：MergeDetailTableの値を配列へ変換する。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetOutDetailData(ByRef MergeDetailTable As DataTable, _
                                      ByRef DetailFormula(,) As Object, _
                                      ByRef DetailSumFormula(,) As Object, _
                                      ByVal Str_PasteDetail As Integer) As Object(,)
        ''戻り値宣言
        Dim rtnValue(,) As Object

        ''配列の領域確保
        Dim DetailRows() As DataRow
        Dim arrayCount As Integer
        Dim Sql_GetContractOutDetailData As String
        Sql_GetContractOutDetailData = GetSql_GetContractOutDetailData()
        DetailRows = MergeDetailTable.Select(Sql_GetContractOutDetailData)

        ''値がなければ処理終了
        If DetailRows.Length = 0 Then
            Return Nothing
        End If

        ''配列の値をｾｯﾄ
        arrayCount = DetailRows.Length - 1
        ReDim rtnValue(arrayCount, ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE - 1)
        For Idx As Integer = 0 To arrayCount
            For IdxD As Integer = 0 To ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE - 1
                ''Excelのﾃﾝﾌﾟﾚ-ﾄ行に式があれば、式を優先
                If DetailFormula(1, IdxD + 1).ToString.IndexOf("=") <> -1 Then
                    rtnValue(Idx, IdxD) = DetailFormula(1, IdxD + 1)
                Else
                    rtnValue(Idx, IdxD) = DetailRows(Idx).Item(IdxD)
                End If

            Next
            Call GetSummaryDetailLine(Idx, rtnValue, DetailRows(Idx), DetailSumFormula, Str_PasteDetail)
        Next
        Return rtnValue

    End Function

    ''' <summary>
    ''' 機　能：1行分の詳細シートに出力情報を取得
    ''' 説　明：※集計行の処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetSummaryDetailLine(ByVal Idx As Integer, _
                                     ByRef rtnValue(,) As Object, _
                                     ByRef outputRow As DataRow, _
                                     ByVal formula_SummaryRow(,) As Object, _
                                     ByVal Str_PasteDetail As Integer)

        ''S行以外は対象外
        If rtnValue(Idx, ExcelWrite.ExcelPaymentLineDetailColumn.IDENTITY_FLAG - 1) <> "S" Then
            Exit Sub
        End If

        Dim at_1 As Integer             ''Sum式で使用：@1の置換文字として使用
        Dim at_2 As Integer             ''Sum式で使用：@2の置換文字として使用
        For IdxD As Integer = 0 To ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE - 1
            Select Case IdxD
                Case ExcelWrite.ExcelPaymentLineDetailColumn.LIST_PRICE_PROPOSAL - 1, _
                     ExcelWrite.ExcelPaymentLineDetailColumn.LIST_PRICE - 1, _
                     ExcelWrite.ExcelPaymentLineDetailColumn.COST - 1, _
                     ExcelWrite.ExcelPaymentLineDetailColumn.HWMA_LIST_PRICE - 1
                    'Excel式
                    rtnValue(Idx, IdxD) = formula_SummaryRow(1, IdxD + 1)

                Case ExcelWrite.ExcelPaymentLineDetailColumn.LIST_PRICE_TOTAL_PROPOSAL - 1, _
                     ExcelWrite.ExcelPaymentLineDetailColumn.LIST_PRICE_TOTAL - 1, _
                     ExcelWrite.ExcelPaymentLineDetailColumn.COST_TOTAL - 1, _
                     ExcelWrite.ExcelPaymentLineDetailColumn.HWMA_LIST_PRICE_TOTAL - 1

                    ''Excel式:Sum式の"@1"と"@2"に集計範囲をセット
                    at_1 = (Idx + Str_PasteDetail) + 1
                    at_2 = (Idx + Str_PasteDetail) + CInt(outputRow.Item(Me.MergeTableColumn_ChildCount))
                    rtnValue(Idx, IdxD) = formula_SummaryRow(1, IdxD + 1).Replace("@1", at_1) _
                                                                         .Replace("@2", at_2)
            End Select
        Next

    End Sub

    ''' <summary>
    ''' 機能：配列データの貼付範囲を取得する。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetXlsPasteArea(ByRef MergePaymentTable As DataTable,
                                     ByRef MergeDetailTable As DataTable) As PasteArea

        Dim rtnValue As PasteArea

        ''仮契約の開始位置取得　※統合前Payment終了位置を取得
        Dim Sql_GetPaymentXlsPasteArea_1 As String
        Dim Sql_GetDetailXlsPasteArea_1 As String
        Sql_GetPaymentXlsPasteArea_1 = GetSql_GetPaymentXlsPasteArea_1()
        Sql_GetDetailXlsPasteArea_1 = GetSql_GetDetailXlsPasteArea_1()
        rtnValue.Str_PastePS = MergePaymentTable.Select(Sql_GetPaymentXlsPasteArea_1).Length + ExcelWrite.EXCEL_COST_PAYMENT_OUTROW
        rtnValue.Str_PasteDetail = MergeDetailTable.Select(Sql_GetDetailXlsPasteArea_1).Length + ExcelWrite.EXCEL_COST_DETAIL_OUTROW

        ''仮契約の終了位置
        Dim Sql_GetPaymentXlsPasteArea_2 As String
        Dim Sql_GetDetailXlsPasteArea_2 As String
        Sql_GetPaymentXlsPasteArea_2 = GetSql_GetPaymentXlsPasteArea_2()
        Sql_GetDetailXlsPasteArea_2 = GetSql_GetDetailXlsPasteArea_2()
        rtnValue.End_PastePS = MergePaymentTable.Select(Sql_GetPaymentXlsPasteArea_2).Length + rtnValue.Str_PastePS - 1
        rtnValue.End_PasteDetail = MergeDetailTable.Select(Sql_GetDetailXlsPasteArea_2).Length + rtnValue.Str_PasteDetail - 1

        ''ﾃﾞｰﾀの貼付範囲を取得
        Dim pastePsArea As String
        Dim pasteDetailArea As String
        pastePsArea = ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG) & rtnValue.Str_PastePS & _
                       ":" & _
                       ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12) & rtnValue.End_PastePS
        rtnValue.Area_PastePS = pastePsArea
        pasteDetailArea = ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineDetailColumn.UPDATE_FLAG) & rtnValue.Str_PasteDetail & _
                          ":" & _
                          ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE) & rtnValue.End_PasteDetail

        rtnValue.Area_PasteDetail = pasteDetailArea

        ''値を返却
        Return rtnValue

    End Function


    ''' <summary>
    ''' 機能：引数ﾃﾞｰﾀから仮契約統合後Paymentﾌｧｲﾙを作成する。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub OutUniXlsPaymentFile(ByRef xlsPasteArea As PasteArea, _
                                     ByRef xlPaymentBook As Excel.Workbook, _
                                     ByRef outPaymentData(,) As Object)

        ''Excel変数宣言
        Dim xlOioSheet As Excel.Worksheet
        Dim xlCell As Excel.Range
        Dim xlTmpRow As Excel.Range
        Try
            ''ｼｰﾄのｾｯﾄ
            xlOioSheet = xlPaymentBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)

            ''                    　以下、ﾃﾝﾌﾟﾚｰﾄ行のｾｯﾄ
            ''------------------------------------------------------------------
            ''ﾃﾝﾌﾟﾚｰﾄ行のｾｯﾄ
            Const PateCount As Integer = 1000       ''貼付件数
            Dim DateCount As Integer                ''ﾃﾞｰﾀ件数
            Dim PasteCount As Integer               ''貼付回数
            Dim strIdx As Integer                   ''ｺﾋﾟｰ開始位置
            Dim endIdx As Integer                   ''ｺﾋﾟｰ終了位置
            Dim CopyArea As String                  ''貼付範囲            

            ''貼付回数の取得
            DateCount = UBound(outPaymentData, 1) + 1
            PasteCount = System.Math.Truncate((DateCount - 1) / PateCount) + 1

            ''テンプレート行のコピペ
            xlTmpRow = xlOioSheet.Rows(ExcelWrite.EXCEL_PAYMENTLINE_TMPROW & ":" & ExcelWrite.EXCEL_PAYMENTLINE_TMPROW)
            xlTmpRow.Hidden = False
            For Idx As Integer = 1 To PasteCount

                ''開始/終了位置の取得
                strIdx = ((Idx - 1) * PateCount) + xlsPasteArea.Str_PastePS
                If DateCount >= (Idx * PateCount) Then
                    endIdx = (Idx * PateCount) + xlsPasteArea.Str_PastePS - 1
                Else
                    endIdx = ((Idx - 1) * PateCount) + (DateCount Mod PateCount) + xlsPasteArea.Str_PastePS - 1
                End If

                ''貼付範囲の取得
                CopyArea = strIdx & ":" & endIdx

                ''貼付処理
                xlCell = xlOioSheet.Range(CopyArea)
                Call xlTmpRow.Copy()
                Call xlCell.PasteSpecial()

            Next
            xlTmpRow.Hidden = True

            ''                    以下、セルの値の貼付
            ''------------------------------------------------------------------
            xlCell = xlOioSheet.Range(xlsPasteArea.Area_PastePS)
            xlCell.Formula = outPaymentData

            '不要な月額を削除する。
            Call ExcelWrite.CreatePaymentPeriod(xlOioSheet,
                                                ExcelWrite.ChgExcelRowNumberToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1),
                                                CommonVariable.PaymentPeriod)

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlTmpRow, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlOioSheet, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try
    End Sub


    ''' <summary>
    ''' 機能：引数ﾃﾞｰﾀから仮契約統合後Detailﾌｧｲﾙを作成する。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub OutUniXlsDetailFile(ByRef xlsPasteArea As PasteArea, _
                                    ByRef xlDetailBook As Excel.Workbook, _
                                    ByRef outDetailData(,) As Object)

        ''Excel変数宣言
        Dim xlDetailSheet As Excel.Worksheet
        Dim xlCell As Excel.Range
        Dim xlTmpRow As Excel.Range
        Try
            ''ｼｰﾄのｾｯﾄ
            xlDetailSheet = xlDetailBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)
            ''                    　以下、ﾃﾝﾌﾟﾚｰﾄ行のｾｯﾄ
            ''------------------------------------------------------------------
            ''ﾃﾝﾌﾟﾚｰﾄ行のｾｯﾄ
            Const PateCount As Integer = 15         ''貼付件数
            Dim DateCount As Integer                ''ﾃﾞｰﾀ件数
            Dim PasteCount As Integer               ''貼付回数
            Dim strIdx As Integer                   ''ｺﾋﾟｰ開始位置
            Dim endIdx As Integer                   ''ｺﾋﾟｰ終了位置
            Dim CopyArea As String                  ''貼付範囲            

            ''貼付回数の取得
            DateCount = UBound(outDetailData, 1) + 1
            PasteCount = System.Math.Truncate((DateCount - 1) / PateCount) + 1
            xlTmpRow = xlDetailSheet.Rows(ExcelWrite.EXCEL_PAYMENTDETAIL_TMPROW & ":" & ExcelWrite.EXCEL_PAYMENTDETAIL_TMPROW)
            xlTmpRow.Hidden = False
            For Idx As Integer = 1 To PasteCount

                ''開始/終了位置の取得
                strIdx = (Idx - 1) * PateCount + xlsPasteArea.Str_PasteDetail
                If DateCount >= Idx * PateCount Then
                    endIdx = (Idx * PateCount) + xlsPasteArea.Str_PasteDetail - 1
                Else
                    endIdx = ((Idx - 1) * PateCount) + (DateCount Mod PateCount) + xlsPasteArea.Str_PasteDetail - 1
                End If

                ''貼付範囲の取得
                CopyArea = strIdx & ":" & endIdx

                ''貼付処理
                xlCell = xlDetailSheet.Range(CopyArea)
                Call xlTmpRow.Copy()
                Call xlCell.PasteSpecial()

            Next
            xlTmpRow.Hidden = True

            Call InsSummaryTmpRow(xlDetailSheet, outDetailData, xlsPasteArea.Str_PasteDetail)

            ''                    以下、セルの値の貼付
            ''------------------------------------------------------------------
            xlCell = xlDetailSheet.Range(xlsPasteArea.Area_PasteDetail)
            xlCell.Formula = outDetailData

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlTmpRow, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlDetailSheet, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub


    ''' <summary>
    ''' 機能：MDBの更新処理
    ''' 説明：仮契約統合ボタンの処理時、「仮契約Table」を更新する。
    ''' </summary>
    ''' <param name="cmbValue"></param>
    ''' <param name="UpdM_ContractTmpList"></param>
    ''' <remarks></remarks>
    Private Sub UpdMDB_Main_Btn_UnificationContract(ByVal cmbValue As String, _
                                                    ByRef UpdM_ContractTmpList As ArrayList)

        Try

            ''仮契約情報の更新
            Call UpdM_ContractTemp_Btn_UnificationContract(CommonVariable.CPNO, _
                                                           CInt(Me.Cmb_TmpContract.Text), _
                                                           UpdM_ContractTmpList)
            ''正常ﾛｸﾞ書込
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt1, "DB更新")

        Catch ex As Exception
            ''ｴﾗｰﾛｸﾞ書込
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt2, "DB更新")
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt3, ex.Message)

            ''異常終了 ⇒ RollBack
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' 機能：仮契約Tableを更新する
    ''' 説明：
    ''' </summary>
    ''' <param name="Cpno"></param>
    ''' <param name="Contract"></param>
    ''' <param name="contractList"></param>
    ''' <remarks></remarks>
    Private Sub UpdM_ContractTemp_Btn_UnificationContract(ByVal Cpno As String, _
                                                          ByVal Contract As Integer, _
                                                          ByRef contractList As ArrayList)

        Dim UpdMContractTmp As UPD_M_CONTRACT_TEMP
        Dim Sql_UpdM_ContractTemp_UnificationContract As String
        Dim blnRet As Boolean
        Dim dt As M_CONTRACT_TEMP
        Dim dtUpData As M_CONTRACT_TEMP
        Dim wc As New WebDb.WebDbCommon
        Dim strMsg As String
        Dim strWhere As String

        Try
            '認証設定
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW

            For Each UpdMContractTmp In contractList
                dt = New M_CONTRACT_TEMP
                ''ﾃﾞｰﾀの有無でInsert/Updateを切替
                If ChkExistsMContractTmp(Cpno, Contract, UpdMContractTmp) = True Then
                    '仮契約情報取得
                    blnRet = wc.GetContractTempData(Cpno, dt, strMsg)
                    If blnRet = False Then
                        Throw New Exception(strMsg)
                        Exit Sub
                    End If
                    '統合先_正契約順番、統合元_仮契約順番で抽出
                    strWhere = M_CONTRACT_TEMP.COLUMN_NAME_OUT_CONTRACT_NO & "='" & Contract.ToString.PadLeft(3, "0") & "' AND " & _
                               M_CONTRACT_TEMP.COLUMN_NAME_IN_CONTRACT_NO & "='" & UpdMContractTmp.TmpContract.ToString.PadLeft(3, "0") & "'"
                    Dim rows() As DataRow = dt.Select(strWhere)
                    dtUpData = New M_CONTRACT_TEMP
                    dtUpData.ImportRow(rows(0))

                    'データセット
                    Call SetUpdateDataTemp(UpdMContractTmp, dtUpData)

                    'Update処理
                    blnRet = wc.UpdateContractTempData(dtUpData, strMsg)
                    dtUpData = Nothing
                Else
                    'データセット
                    Call SetInsertDataTemp(Cpno, Contract, UpdMContractTmp, dt)

                    'Insert処理
                    blnRet = wc.InsertContractTempData(dt, strMsg)
                End If
                If blnRet = False Then
                    Throw New Exception(strMsg)
                End If
                dt = Nothing
            Next

        Catch ex As Exception
            Throw ex

        End Try

    End Sub

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="strCpno"></param>
    ''' <param name="Contract"></param>
    ''' <param name="UpdMContractTmp"></param>
    ''' <param name="dt"></param>
    ''' <remarks></remarks>
    Private Sub SetInsertDataTemp(ByVal strCpno As String,
                                  ByVal Contract As Integer,
                                  ByVal UpdMContractTmp As UPD_M_CONTRACT_TEMP,
                                  ByRef dt As M_CONTRACT_TEMP)

        Dim row As DataRow

        Try
            row = dt.NewRow
            row(M_CONTRACT_TEMP.COLUMN_NAME_CPNO) = strCpno
            row(M_CONTRACT_TEMP.COLUMN_NAME_OUT_CONTRACT_NO) = Contract.ToString.PadLeft(3, "0")
            row(M_CONTRACT_TEMP.COLUMN_NAME_IN_CONTRACT_NO) = UpdMContractTmp.TmpContract.ToString.PadLeft(3, "0")
            row(M_CONTRACT_TEMP.COLUMN_NAME_IN_PS_FILENAME) = Path.GetFileName(UpdMContractTmp.InPsFileName)
            row(M_CONTRACT_TEMP.COLUMN_NAME_IN_PS_COUNT) = UpdMContractTmp.UnifiPSCount
            row(M_CONTRACT_TEMP.COLUMN_NAME_IN_DETAIL_COUNT) = UpdMContractTmp.UnifiDetailCount
            row(M_CONTRACT_TEMP.COLUMN_NAME_PS_UNMATCH_COUNT) = 0
            row(M_CONTRACT_TEMP.COLUMN_NAME_DETAIL_UNMATCH_COUNT) = 0
            row(M_CONTRACT_TEMP.COLUMN_NAME_STATUS) = "1"
            row(M_CONTRACT_TEMP.COLUMN_NAME_UNIFICATION_DATE) = Date.Now
            dt.Rows.Add(row)

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="UpdMContractTmp"></param>
    ''' <param name="dt"></param>
    ''' <remarks></remarks>
    Private Sub SetUpdateDataTemp(ByVal UpdMContractTmp As UPD_M_CONTRACT_TEMP,
                                  ByRef dt As M_CONTRACT_TEMP)

        Try
            '統合元 PS件数  
            dt.Rows(0).Item(M_CONTRACT_TEMP.COLUMN_NAME_IN_PS_COUNT) = UpdMContractTmp.UnifiPSCount
            '統合元 詳細件数
            dt.Rows(0).Item(M_CONTRACT_TEMP.COLUMN_NAME_IN_DETAIL_COUNT) = UpdMContractTmp.UnifiDetailCount
            'ｽﾃｰﾀｽ
            dt.Rows(0).Item(M_CONTRACT_TEMP.COLUMN_NAME_STATUS) = "1"
            '統合作業日 
            dt.Rows(0).Item(M_CONTRACT_TEMP.COLUMN_NAME_UNIFICATION_DATE) = Date.Now

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="UpdMContractTmp"></param>
    ''' <param name="dt"></param>
    ''' <remarks></remarks>
    Private Sub SetUpdateDataTempDiff(ByVal UpdMContractTmp As UPD_M_CONTRACT_TEMP, ByRef dt As M_CONTRACT_TEMP)

        Try
            'PSｱﾝﾏｯﾁ件数      
            dt.Rows(0).Item(M_CONTRACT_TEMP.COLUMN_NAME_PS_UNMATCH_COUNT) = UpdMContractTmp.UnMatchPSCount
            '詳細ｱﾝﾏｯﾁ件数
            dt.Rows(0).Item(M_CONTRACT_TEMP.COLUMN_NAME_DETAIL_UNMATCH_COUNT) = UpdMContractTmp.UnMatchDetailCount
            'ｽﾃｰﾀｽ    
            dt.Rows(0).Item(M_CONTRACT_TEMP.COLUMN_NAME_STATUS) = "1"
            'ﾁｪｯｸ作業日    
            dt.Rows(0).Item(M_CONTRACT_TEMP.COLUMN_NAME_CHECK_DATE) = Date.Now

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' 機能：仮契約情報の存在ﾁｪｯｸ
    ''' 説明：
    ''' </summary>
    ''' <param name="Cpno"></param>
    ''' <param name="Contract"></param>
    ''' <param name="UpdMContractTmp"></param>
    ''' <returns>True:データ有 False:データ無</returns>
    ''' <remarks></remarks>
    Private Function ChkExistsMContractTmp(ByVal Cpno As String, _
                                           ByVal Contract As Integer, _
                                           ByRef UpdMContractTmp As UPD_M_CONTRACT_TEMP) As Boolean


        Dim strMsg As String = ""
        Dim wc As New WebDb.WebDbCommon
        Dim blnRet As Boolean
        Dim dt As New M_CONTRACT_TEMP
        Dim strWhere As New StringBuilder

        ChkExistsMContractTmp = False

        Try
            '認証設定
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW

            '仮契約情報取得
            blnRet = wc.GetContractTempData(Cpno, dt, strMsg)
            If blnRet = False Then
                Throw New Exception(strMsg)
                Exit Function
            End If

            If dt.Rows.Count > 0 Then
                strWhere.Append(M_CONTRACT_TEMP.COLUMN_NAME_OUT_CONTRACT_NO)
                strWhere.Append(CommonConstant.STR_EQUAL)
                strWhere.Append(StringEdit.EncloseSingleQuotation(Contract.ToString.PadLeft(3, "0")))
                strWhere.Append(CommonConstant.SQL_STR_AND)
                strWhere.Append(M_CONTRACT_TEMP.COLUMN_NAME_IN_CONTRACT_NO)
                strWhere.Append(CommonConstant.STR_EQUAL)
                strWhere.Append(StringEdit.EncloseSingleQuotation(UpdMContractTmp.TmpContract.ToString.PadLeft(3, "0")))
                If dt.Select(strWhere.ToString).Length > 0 Then
                    ChkExistsMContractTmp = True
                End If
            End If


        Catch ex As Exception
            Throw ex
        End Try

    End Function

    ''' <summary>
    ''' 機能：更新Flg = U、ロックFlg=Cで、Linnoが重複しているﾃﾞｰﾀをﾁｪｯｸする。
    ''' 説明：
    ''' </summary>
    ''' <param name="MergePaymentTable"></param>
    ''' <param name="errMsg"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function DistinctContractDelMacroDate(ByRef MergePaymentTable As DataTable, _
                                                  ByRef errMsg As String) As Boolean

        ''初期化
        Dim rtnMsg As String = ""
        DistinctContractDelMacroDate = False

        ''更新Flg = U、ロックFlg=Cのﾃﾞｰﾀを取得
        Dim tmpRow() As DataRow
        Dim Sql_DistinctContractDelMacroDate As String
        Sql_DistinctContractDelMacroDate = GetSql_DistinctContractDelMacroDate()
        tmpRow = MergePaymentTable.Select(Sql_DistinctContractDelMacroDate, _
                                          "CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO & " , " & _
                                          MergeTableColumn_SortContract)
        If IsNothing(tmpRow) = True Then
            Exit Function
        End If

        ''更新Flg = U、ロックFlg=Cのﾃﾞｰﾀから、重複するﾃﾞｰﾀを取得
        Dim isDistinct As Boolean = False
        Dim Idx As Integer
        For Idx = 0 To UBound(tmpRow)

            ''次のﾃﾞｰﾀが同じLinnoなら、重複有とする。  ※Linnoでソート済み
            If (Idx + 1) <= UBound(tmpRow) AndAlso _
               tmpRow(Idx).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO) = _
               tmpRow(Idx + 1).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO) Then

                isDistinct = True
                rtnMsg = "以下の契約順番のファイルで、重複する更新ﾃﾞｰﾀが存在します。" & vbCrLf & _
                     "更新Flg=U、ロックFlg=C のデータを検索し、重複した行番号のﾃﾞｰﾀがセットされていないか確認してください。" & vbCrLf & _
                     "　・契約順番：" & tmpRow(Idx).Item(Me.MergeTableColumn_FileContract) & vbCrLf & _
                     "　・契約順番：" & tmpRow(Idx + 1).Item(Me.MergeTableColumn_FileContract)
                errMsg = rtnMsg
                Exit For
            End If
        Next
        Return isDistinct

    End Function


    ''' <summary>
    ''' 機能：4)処理開始時指示　ﾎﾞﾀﾝ押下時のException時に表示するﾒｯｾｰｼﾞ取得
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetExceptionErrMsg(ByVal lblText As String) As String

        ''初期化
        GetExceptionErrMsg = ""

        ''進捗画面の文言
        Const LblMsg_001 As String = "正契約ファイルの読込中…"
        Const LblMsg_002 As String = "仮契約ファイルの読込中…"
        Const LblMsg_003 As String = "削除対象ﾃﾞｰﾀ検索中…"
        Const LblMsg_004 As String = "Excelﾃﾞｰﾀの削除中…"
        Const LblMsg_005 As String = "MDBの更新中…"
        Const LblMsg_006 As String = "Excelﾌｧｲﾙの書込中…"
        Const LblMsg_007 As String = "Unmatchﾃﾞｰﾀ検索中…"
        Const LblMsg_008 As String = "仮契約リセット中…"

        ''戻り値
        Const RtnMsg_001 As String = "正契約ファイルの読込中にエラーが発生しました。"
        Const RtnMsg_002 As String = "仮契約ファイルの読込中にエラーが発生しました。"
        Const RtnMsg_003 As String = "削除対象ﾃﾞｰﾀ検索中にエラーが発生しました。"
        Const RtnMsg_004 As String = "Excelﾃﾞｰﾀの削除中にエラーが発生しました。"
        Const RtnMsg_005 As String = "MDBの更新中にエラーが発生しました。"
        Const RtnMsg_006 As String = "Excelﾌｧｲﾙの書込中にエラーが発生しました。"
        Const RtnMsg_007 As String = "Unmatchﾃﾞｰﾀ検索中にエラーが発生しました。"
        Const RtnMsg_008 As String = "仮契約リセット中にエラーが発生しました。"

        ''進捗画面の文言に応じてﾒｯｾｰｼﾞを返す
        Select Case lblText
            Case LblMsg_001
                Return RtnMsg_001
            Case LblMsg_002
                Return RtnMsg_002
            Case LblMsg_003
                Return RtnMsg_003
            Case LblMsg_004
                Return RtnMsg_004
            Case LblMsg_005
                Return RtnMsg_005
            Case LblMsg_006
                Return RtnMsg_006
            Case LblMsg_007
                Return RtnMsg_007
            Case LblMsg_008
                Return RtnMsg_008
        End Select

    End Function

    ''' <summary>
    ''' 機能：詳細シートのサマリテンプレ行作成
    ''' 説明：
    ''' </summary>
    ''' <param name="xlDetailSheet"></param>
    ''' <param name="outDetailData"></param>
    ''' <param name="strIdx"></param>
    ''' <remarks></remarks>
    Private Sub InsSummaryTmpRow(ByRef xlDetailSheet As Excel.Worksheet, _
                                 ByRef outDetailData(,) As Object, _
                                 ByVal strIdx As Integer)

        Dim xlTmpCell As Excel.Range
        Dim xlPasteCell As Excel.Range
        Try
            xlTmpCell = xlDetailSheet.Rows(ExcelWrite.EXCEL_PAYMENTDETAIL_SUMTMPROW)
            xlTmpCell.Hidden = False
            Call xlTmpCell.Copy()
            For idx As Integer = 0 To UBound(outDetailData, 1)
                If outDetailData(idx, ExcelWrite.ExcelPaymentLineDetailColumn.IDENTITY_FLAG - 1) = "S" Then
                    xlPasteCell = xlDetailSheet.Rows(strIdx + idx)
                    Call xlPasteCell.PasteSpecial()
                End If
            Next
            xlTmpCell.Hidden = True
        Catch ex As Exception
            Throw ex
        Finally
            ExcelObjRelease.ReleaseExcelObj(xlTmpCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPasteCell, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try

    End Sub

    ''' <summary>
    ''' 機能：仮契約Paymentﾃﾞｰﾀの仮ｼﾘｱﾙを更新する
    ''' 説明：※削除ﾃﾞｰﾀは更新対象外とする。
    ''' </summary>
    ''' <param name="TmpXlsPaymentTable"></param>
    ''' <param name="contractNo"></param>
    ''' <remarks></remarks>
    Private Sub UpdTmpSerial(ByRef TmpXlsPaymentTable As DataTable,
                             ByVal contractNo As String)

        ''定数
        Const DEL_NO As String = "削除元NO ="
        Const COPY_NO As String = "ｺﾋﾟｰ元NO ="

        Try

            ''                  削除元/コピー元のNoを取得する。
            ''--------------------------------------------------------------------
            Dim colNMItem10 As String               ''Tableの項目名:項目10
            Dim colNMTmpSerial As String            ''Tableの項目名:仮ｼﾘｱﾙ
            Dim refNOList As New ArrayList          ''Copy元/削除元のNoをﾘｽﾄ化
            Dim filter As New StringBuilder
            Dim item10 As String
            Dim tmpSerial As String
            colNMItem10 = "CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10
            colNMTmpSerial = "CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02
            filter.Append(colNMItem10)
            filter.Append(CommonConstant.SQL_STR_LIKE)
            filter.Append(StringEdit.EncloseSingleQuotation(DEL_NO & "*"))
            filter.Append(CommonConstant.SQL_STR_OR)
            filter.Append(colNMItem10)
            filter.Append(CommonConstant.SQL_STR_LIKE)
            filter.Append(StringEdit.EncloseSingleQuotation(COPY_NO & "*"))
            For Each tmpRow As DataRow In TmpXlsPaymentTable.Select(filter.ToString)

                item10 = tmpRow.Item(colNMItem10)
                If item10.IndexOf(DEL_NO) <> -1 Then
                    tmpSerial = item10.Replace(DEL_NO, "")
                    If IsNumeric(tmpSerial) = True Then
                        refNOList.Add(CInt(tmpSerial))
                    End If
                End If
                If item10.IndexOf(COPY_NO) <> -1 Then
                    tmpSerial = item10.Replace(COPY_NO, "")
                    If IsNumeric(tmpSerial) = True Then
                        refNOList.Add(CInt(tmpSerial))
                    End If
                End If
            Next


            ''                    仮ｼﾘｱﾙを更新する。
            ''--------------------------------------------------------------------
            Dim lineNo As Integer
            For Each tmpRow As DataRow In TmpXlsPaymentTable.Rows

                item10 = tmpRow.Item(colNMItem10)
                tmpSerial = tmpRow.Item(colNMTmpSerial)

                ''削除元/コピー元は対象外
                If item10.IndexOf(DEL_NO) <> -1 Or _
                   item10.IndexOf(COPY_NO) <> -1 Then
                    Continue For
                End If

                ''仮ｼﾘｱﾙ以外は対象外
                If Not (ExcelWrite.changeDBNullToString(tmpRow.Item(colNMTmpSerial)).Length >= 12 AndAlso _
                        ExcelWrite.changeDBNullToString(tmpRow.Item(colNMTmpSerial).SubString(0, 2)) = "@H") Then
                    Continue For
                End If

                ''LineNoが数字以外は対象外                
                If IsNumeric(tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO)) = False Then
                    Continue For
                End If

                ''削除元/Copy元のLinnoは対象外
                lineNo = CInt(tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO))
                If refNOList.IndexOf(lineNo) <> -1 Then
                    Continue For
                End If

                ''締結済ﾃﾞｰﾀは極力値を修正しない。
                If tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG) = "U" And tmpRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG) = "C" Then
                    Continue For
                End If

                ''仮ｼﾘｱﾙの更新
                tmpSerial = "@H" & _
                            contractNo & _
                            tmpRow.Item(MergeTableColumn_TmpContract) & _
                            tmpRow.Item(colNMTmpSerial).SubString(5, 7)
                tmpRow.Item(colNMTmpSerial) = tmpSerial
            Next

        Catch ex As Exception
            Throw ex

        End Try

    End Sub

#End Region

#Region "仮契約削除ﾎﾞﾀﾝ関係の処理"

    ''' <summary>
    ''' 機能：仮契約削除ボタンの処理
    ''' 説明：以下のOption機能有り
    ''' 　　　・処理状態通知画面
    ''' 　　　・例外Log出力
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Main_Btn_DelContract()

        Dim outLogMsg As String                                         ''ﾛｸﾞ出力用エラーMsg
        Call Me.InitPGLogFile()
        Call WritePGLogLine(Me.OutLogKB.OutStr)
        Call WritePGLogLine(Me.OutLogKB.DelStr)

        ''ｴﾗｰﾒｯｾｰｼﾞ ※ﾕｰｻﾞｰが定義したｴﾗｰ 例)ﾌｧｲﾙの存在ﾁｪｯｸ等
        Dim ErrMsg As String                                             ''ｴﾗｰﾒｯｾｰｼﾞ
        Dim ErrMsgKB As String                                           ''ｴﾗｰ区分

        ''ｽﾃｰﾀｽ画面のｾｯﾄ
        Dim dspInfoMsg As String                                         ''進捗画面に表示する文言
        Dim frm_State As New Frm_WaitDialog
        Try
            'GSAパス存在チェック
            Dim blnRet As Boolean
            blnRet = CheckGsaPath()
            If blnRet = False Then
                Exit Sub
            End If

            ''Log書込/進捗状況を画面に通知する。
            Call WritePGLogLine(Me.OutLogKB.Titel_Pt1)
            Call SetInitWaitDialog(frm_State, "正契約ファイルの読込中…", 3)

            ''削除対象の正契約ﾌｧｲﾙﾊﾟｽを取得
            Dim PaymentPath As String
            PaymentPath = Me.GetPaymentPath(CommonVariable.CPNO, Me.Cmb_TmpContract.Text)

            ''仮契約一覧の情報を取得
            Dim contractList As ArrayList
            contractList = GetAListtDate_NotPrentTrv_ContractInfo()
            ErrMsgKB = ChkDelContract(ErrMsg, PaymentPath, contractList)
            Select Case ErrMsgKB
                Case Me.ErrKB_Err, _
                     Me.ErrKB_Alr
                    Exit Sub                                                ''Finallyへ移動し、ﾒｯｾｰｼﾞ処理を行う。
            End Select

            If ExcelWrite.ChkPaymentErr(Me.Name, "Btn_DelContract", _
                                        CommonVariable.CPNO, CInt(Me.Cmb_TmpContract.Text)) = False Then
                Exit Sub
            End If

            ''正契約の情報をDataTableへセット
            Dim XlsPaymentTable As DataTable                                ''Payment情報 
            Dim XlsDetailTable As DataTable                                 ''詳細情報
            XlsPaymentTable = Set_XlsPaymentTable(PaymentPath)
            XlsDetailTable = Set_XlsDetailTable(PaymentPath)

            ''Log書込/進捗状況を画面に通知する。
            Call WritePGLogLine(Me.OutLogKB.Titel_Pt6)
            Call SetStepProgress(frm_State, "削除対象ﾃﾞｰﾀ検索中…")

            ''削除対象ﾃﾞｰﾀにフラグを立てる
            Dim checkOnContractList As ArrayList
            checkOnContractList = DelAListtDate_NotChecked(contractList)

            ''削除対象ﾃﾞｰﾀにFlgを立てる。
            Dim UpdM_ContractTmpList As New ArrayList                       ''仮契約情報Table更新用の情報を保持
            Dim MergePaymentTable As DataTable
            Dim MergeDetailTable As DataTable
            Call Get_DelMergeTable(PaymentPath, _
                                   checkOnContractList, _
                                   MergePaymentTable, _
                                   MergeDetailTable, _
                                   XlsPaymentTable, _
                                   XlsDetailTable, _
                                   UpdM_ContractTmpList)

            ''Log書込/進捗状況を画面に通知する。
            Call WritePGLogLine(Me.OutLogKB.Titel_Pt7)
            Call SetStepProgress(frm_State, "Excelﾃﾞｰﾀの削除中…")

            ''削除対象ﾃﾞｰﾀをExcelﾌｧｲﾙから削除する。※仮契約統合の処理をそのまま流用。大幅な仕様変更があれば別モジュール化する。
            Call Create_UnificationXls(PaymentPath, _
                                       MergePaymentTable, _
                                       MergeDetailTable)

            ''MDBの更新
            Call WritePGLogLine(Me.OutLogKB.Titel_Pt5)
            Call UpdMDB_Main_Btn_DelContract(CommonVariable.CPNO, Me.Cmb_TmpContract.Text, checkOnContractList)

            ''MDBの値を取得して画面をリフレッシュ
            Call GetMdbInfomatino(Me.TBL_M_CONTRACT_BASE, Me.TBL_M_CONTRACT_DETAIL, Me.TBL_M_CONTRACT_TEMP)
            Call InitForm_Rdbutton(Me.ActKB_DelContract)

            ''完了メッセージ
            Call MsgBox(Prompt:=FileReader.GetMessage("MSG_0378"), _
                        Title:=Me.Text, _
                        Buttons:=MsgBoxStyle.Information)

        Catch ex As Exception
            Dim errDetail As String
            errDetail = Me.GetExceptionErrMsg(frm_State.lbl_Message.Text)
            errDetail = errDetail & vbCrLf & _
                        "エラーの詳細については、Logフォルダ直下に作成される「契約統合_[CPNO].Log」を確認してください。" & vbCrLf & _
                        vbCrLf & _
                        "エラー内容：" & ex.Message
            Throw New Exception(errDetail)

        Finally

            ''ﾛｸﾞの書込
            Call WritePGLogLine(Me.OutLogKB.DelEnd)
            Call WritePGLogLine(Me.OutLogKB.OutEnd)

            ''※エラー補足：ユーザ定義エラーはここで処理。
            ''  Exceptionｴﾗｰは、ﾎﾞﾀﾝｸﾘｯｸｲﾍﾞﾝﾄで「失敗した処理の名前」＋ 「ｴﾗｰﾛｸﾞ参照してください。」のﾒｯｾｰｼﾞ表示。
            Call frm_State.Close()
            Select Case ErrMsgKB
                Case ""
                    ''処理なし
                Case Me.ErrKB_Err
                    Call MsgBox(Prompt:=ErrMsg, _
                                Buttons:=MsgBoxStyle.Critical, _
                                Title:=Me.Text)

                Case Me.ErrKB_Alr
                    Call MsgBox(Prompt:=ErrMsg, _
                                Buttons:=MsgBoxStyle.Exclamation, _
                                Title:=Me.Text)

            End Select
        End Try
    End Sub

    ''' <summary>
    ''' 機能：DBの更新処理
    ''' 説明：仮契約統合ボタンの処理時、「SuffixTable」と、「仮契約Table」を更新する。
    ''' </summary>
    ''' <param name="Cpno"></param>
    ''' <param name="cmbValue"></param>
    ''' <param name="contractList"></param>
    ''' <remarks></remarks>
    Private Sub UpdMDB_Main_Btn_DelContract(ByVal Cpno As String, _
                                            ByVal cmbValue As String, _
                                            ByRef contractList As ArrayList)

        Try
            ''仮契約情報の更新
            Call UpdM_ContractTemp_Btn_DelContract(Cpno, _
                                                   CInt(Me.Cmb_TmpContract.Text), _
                                                   contractList)

            ''正常ﾛｸﾞ書込
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt1, "DB更新")

        Catch ex As Exception
            ''ｴﾗｰﾛｸﾞ書込
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt2, "DB更新")
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt3, ex.Message)
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' 機能：仮契約Tableを更新する
    ''' 説明：※仮契約削除機能で使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub UpdM_ContractTemp_Btn_DelContract(ByVal Cpno As String, _
                                                  ByVal Contract As Integer, _
                                                  ByRef contractList As ArrayList)
        Dim wc As New WebDb.WebDbCommon
        Dim blnRet As Boolean
        Dim strMsg As String = ""
        Dim dt As New M_CONTRACT_TEMP
        Dim strWhere As String

        Try
            '認証設定
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW

            For Each tmpValue As Trv_ContractInfo_Date In contractList
                '仮契約情報取得
                blnRet = wc.GetContractTempData(CommonVariable.CPNO, dt, strMsg)
                If blnRet = False Then
                    Throw New Exception(strMsg)
                    Exit Sub
                End If
                '統合先_正契約順番、統合元_仮契約順番で抽出
                strWhere = M_CONTRACT_TEMP.COLUMN_NAME_OUT_CONTRACT_NO & "='" & Contract.ToString.PadLeft(3, "0") & "' AND " & _
                           M_CONTRACT_TEMP.COLUMN_NAME_IN_CONTRACT_NO & "='" & CInt(tmpValue.ContractNo).ToString.PadLeft(3, "0") & "'"
                Dim row() As DataRow = dt.Select(strWhere)

                'データセット
                row(0).Item(M_CONTRACT_TEMP.COLUMN_NAME_STATUS) = "2"
                Dim dtUpData As New M_CONTRACT_TEMP
                dtUpData.ImportRow(row(0))

                '仮契約情報更新(ｽﾃｰﾀｽを削除)
                ''仮契約情報のにUpdate
                blnRet = wc.UpdateContractTempData(dtUpData, strMsg)
                If blnRet = False Then
                    Throw New Exception(strMsg)
                    Exit Sub
                End If
            Next

        Catch ex As Exception
            Throw ex

        End Try

    End Sub

#End Region

#Region "統合正契約ﾁｪｯｸﾎﾞﾀﾝ関係の処理"

    ''' <summary>
    ''' 機能：統合正契約チェックボタンの処理
    ''' 説明：以下のOption機能有り
    ''' 　　　・処理状態通知画面
    ''' 　　　・例外Log出力
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Main_Btn_ChkContractDeff()

        ''ﾛｸﾞ情報開始
        Dim tes As New TestClass2
        Dim outLogMsg As String                                         ''ﾛｸﾞ出力用エラーMsg
        Call Me.InitPGLogFile()
        Call WritePGLogLine(Me.OutLogKB.OutStr)
        Call WritePGLogLine(Me.OutLogKB.UnMStr)

        ''ｴﾗｰの処理    ※ユーザ定義エラー
        Dim ErrMsgKB As String
        Dim ErrMsg As String

        ''ｽﾃｰﾀｽ画面のｾｯﾄ
        Dim dspInfoMsg As String                                         ''進捗画面に表示する文言
        Dim frm_State As New Frm_WaitDialog
        Try

            ''Log書込/進捗状況を画面に通知する。
            Call WritePGLogLine(Me.OutLogKB.Titel_Pt1)
            Call SetInitWaitDialog(frm_State, "正契約ファイルの読込中…", 4)

            ''                      以下、統合前のﾁｪｯｸ処理/ﾌｧｲﾙﾊﾟｽの取得
            ''---------------------------------------------------------------------------------
            ''統合対象の正契約ﾌｧｲﾙﾊﾟｽを取得
            Dim PaymentPath As String
            PaymentPath = Me.GetPaymentPath(CommonVariable.CPNO, Me.Cmb_TmpContract.Text)

            ''統合対象の仮契約を取得
            Dim contractList As ArrayList
            contractList = GetAListtDate_NotPrentTrv_ContractInfo()

            ''統合正契約ﾁｪｯｸ処理実行前ﾁｪｯｸ 　※ﾕｰｻﾞｰ定義ｴﾗｰ検出　            
            ErrMsgKB = chkContractDeff(ErrMsg, PaymentPath, contractList)
            Select Case ErrMsgKB
                Case Me.ErrKB_Err, _
                     Me.ErrKB_Alr
                    Exit Sub            ''Finallyへ移動し、ﾒｯｾｰｼﾞ処理を行う。

                Case ErrKB_Info
                    If MessageBox.Show(ErrMsg, Me.Text, MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) = DialogResult.OK Then
                        ''OK     ⇒処理続行
                    Else
                        ''Cancel ⇒処理終了
                        Exit Sub
                    End If
            End Select
            If ExcelWrite.ChkPaymentErr(Me.Name, "Btn_ChkContractDeff", _
                                        CommonVariable.CPNO, CInt(Me.Cmb_TmpContract.Text)) = False Then
                Exit Sub
            End If
            'PSファイル⇔DB2との月額保有数のチェック
            If ChkPaymentPriods(PaymentPath, contractList) = False Then
                Exit Sub
            End If

            ''                      以下、正契約の情報をDataTableへセット
            ''---------------------------------------------------------------------------------
            Dim XlsPaymentTable As DataTable                                ''Payment情報 
            Dim XlsDetailTable As DataTable                                 ''詳細情報
            XlsPaymentTable = Set_XlsPaymentTable(PaymentPath, True)
            XlsDetailTable = Set_XlsDetailTable(PaymentPath, True)


            ''Log書込/進捗状況を画面に通知する。
            Call WritePGLogLine(Me.OutLogKB.Titel_Pt2)
            Call SetStepProgress(frm_State, "仮契約ファイルの読込中…")

            ''                      以下、仮契約の情報をDataTableへセット
            ''---------------------------------------------------------------------------------
            Dim delNotFileContractList As ArrayList
            delNotFileContractList = DelFileNotExists_NotPrentTrv_ContractInfo(contractList)
            Dim TmpXlsPaymentTable(delNotFileContractList.Count - 1) As DataTable         ''Payment情報 
            Dim TmpXlsDetailTable(delNotFileContractList.Count - 1) As DataTable          ''詳細情報

            ''Paymentﾌｧｲﾙ
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt5, "PSﾌｧｲﾙ")
            For Idx As Integer = 0 To delNotFileContractList.Count - 1
                TmpXlsPaymentTable(Idx) = Set_TmpXlsPaymentTable(delNotFileContractList(Idx).ContractNo, delNotFileContractList(Idx).FilePath, True)
            Next

            ''詳細ﾌｧｲﾙ
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt6)
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt5, "詳細ﾌｧｲﾙ")
            For Idx As Integer = 0 To delNotFileContractList.Count - 1
                TmpXlsDetailTable(Idx) = Set_TmpXlsDetailTable(delNotFileContractList(Idx).ContractNo, delNotFileContractList(Idx).FilePath, True)
            Next


            ''Log書込/進捗状況を画面に通知する。
            Call WritePGLogLine(Me.OutLogKB.Titel_Pt8)
            Call SetStepProgress(frm_State, "Unmatchﾃﾞｰﾀ検索中…")

            ''                      以下、Unmatch情報の検索中
            ''---------------------------------------------------------------------------------
            Dim UnmatchPSTable As DataTable
            Dim UnmatchDetailTable As DataTable
            Dim UnmatchSumPSTable As DataTable
            Dim UnmatchSumDetailTable As DataTable
            Dim UpdM_ContractTmpList As New ArrayList
            Call Get_UnmatchTable(PaymentPath, _
                                  delNotFileContractList, _
                                  UnmatchPSTable, _
                                  UnmatchDetailTable, _
                                  UnmatchSumPSTable, _
                                  UnmatchSumDetailTable, _
                                  XlsPaymentTable, _
                                  XlsDetailTable, _
                                  TmpXlsPaymentTable, _
                                  TmpXlsDetailTable, _
                                  UpdM_ContractTmpList)


            ''Log書込/進捗状況を画面に通知する。
            Call WritePGLogLine(Me.OutLogKB.Titel_Pt4)
            Call SetStepProgress(frm_State, "Excelﾌｧｲﾙの書込中…")

            ''                      以下、Unmatch情報を統合後の正契約に書込
            ''---------------------------------------------------------------------------------
            Call Create_UnmatchListXls(UnmatchPSTable, _
                                       UnmatchDetailTable, _
                                       UnmatchSumPSTable, _
                                       UnmatchSumDetailTable)

            ''                      以下、MDBを更新する。
            ''---------------------------------------------------------------------------------
            Call SetStepProgress(frm_State, "DBの更新中…")
            Call UpdMDB_Main_Btn_ChkContractDeff(Cmb_TmpContract.Text, UpdM_ContractTmpList)

            ''完了メッセージ
            Call MsgBox(Prompt:=FileReader.GetMessage("MSG_0382"), _
                        Title:=Me.Text, _
                        Buttons:=MsgBoxStyle.Information)

        Catch ex As Exception
            Dim errDetail As String
            errDetail = Me.GetExceptionErrMsg(frm_State.lbl_Message.Text)
            errDetail = errDetail & vbCrLf & _
                        "エラーの詳細については、Logフォルダ直下に作成される「契約統合_[CPNO].Log」を確認してください。" & vbCrLf & _
                        vbCrLf & _
                        "エラー内容：" & ex.Message
            Throw New Exception(errDetail)

        Finally
            ''ﾛｸﾞの書込
            Call WritePGLogLine(Me.OutLogKB.UnMEnd)
            Call WritePGLogLine(Me.OutLogKB.OutEnd)

            ''進捗画面Close
            Call frm_State.Close()

            ''ﾕｰｻﾞｰ定義ｴﾗｰの処理         ※ボタン押下後の画面入力チェックﾒｯｾｰｼﾞ等を処理する。
            Select Case ErrMsgKB
                Case ""
                    ''処理なし
                Case Me.ErrKB_Err
                    Call MsgBox(Prompt:=ErrMsg, _
                                Buttons:=MsgBoxStyle.Critical, _
                                Title:=Me.Text)

                Case Me.ErrKB_Alr
                    Call MsgBox(Prompt:=ErrMsg, _
                                Buttons:=MsgBoxStyle.Exclamation, _
                                Title:=Me.Text)

            End Select

        End Try
    End Sub


    ''' <summary>
    ''' 機能：統合正契約ﾁｪｯｸ前の実行前ﾁｪｯｸ
    ''' 説明：※ﾌｧｲﾙの存在ﾁｪｯｸ/画面の仮契約一覧のﾁｪｯｸ
    ''' </summary>
    ''' <remarks></remarks>
    Private Function chkContractDeff(ByRef ErrMsg As String, _
                                     ByRef PaymentPath As String, _
                                     ByRef contractList As ArrayList) As String

        ''初期化
        chkContractDeff = ""

        ''警告ﾒｯｾｰｼﾞ
        Dim AlrMsg_001 As String = FileReader.GetMessage("MSG_0367")            ''画面_統合正契約Noが未入力
        Dim AlrMsg_002 As String = FileReader.GetMessage("MSG_0368")            ''画面_仮契約一覧が画面で1件もﾁｪｯｸなし。

        ''ｴﾗｰﾒｯｾｰｼﾞ
        Dim ErrMsg_001 As String = FileReader.GetMessage("MSG_0369")            ''Paymentﾌｧｲﾙが存在しない。
        Dim ErrMsg_002 As String = FileReader.GetMessage("MSG_0376")            ''Payment/詳細ﾌｧｲﾙがOpen
        Dim ErrMsg_003 As String = FileReader.GetMessage("MSG_0445")            ''仮契約：Payment/詳細ﾌｧｲﾙがOpen

        ''確認ﾒｯｾｰｼﾞ
        Dim InfoMsg_001 As String = FileReader.GetMessage("MSG_0377")           ''ﾌｧｲﾙが存在しない仮契約を選択しています。

        Try
            ''統合正契約Noの入力有無
            If Me.Cmb_TmpContract.Text = "" Then
                chkContractDeff = ErrKB_Alr
                ErrMsg = AlrMsg_001
                Exit Function
            End If

            ''仮契約のﾁｪｯｸ有りﾃﾞｰﾀ判定
            If chkOn_Trv_ContractInfo_Date(contractList) = False Then
                chkContractDeff = ErrKB_Alr
                ErrMsg = AlrMsg_002
                Exit Function
            End If

            ''統合正契約Paymentﾌｧｲﾙの存在ﾁｪｯｸ
            If chk_ExistsPaymentFile(PaymentPath) = False Then
                chkContractDeff = ErrKB_Err
                ErrMsg = ErrMsg_001
                Exit Function
            End If

            ''統合正契約Payment/詳細ﾌｧｲﾙのOPen存在ﾁｪｯｸ
            If chk_OpenPaymentFile(PaymentPath) = False Then
                chkContractDeff = ErrKB_Err
                ErrMsg = ErrMsg_002
                Exit Function
            End If

            ''仮契約Payment/詳細ﾌｧｲﾙのOPen存在ﾁｪｯｸ
            If chk_OpenTmpPaymentFile(contractList) = False Then
                chkContractDeff = ErrKB_Err
                ErrMsg = ErrMsg_003
                Exit Function
            End If

            ''            以下、確認ﾒｯｾｰｼﾞ　※確認事項を一覧で表示し、Yes/Noを判定
            ''--------------------------------------------------------------------
            ''仮契約のﾌｧｲﾙの存在ﾁｪｯｸ
            Dim isInfo As Boolean = False
            Dim InfoMsg As String = "警告情報が存在します。" & vbCrLf & _
                                    "内容を確認し、処理を続行する場合「OKﾎﾞﾀﾝ」を押してください。"
            Dim InfoSubMsg As String
            Dim tmpInfoMsg As String
            If chk_ExistsTmpUnificationFile(Me.TBL_M_CONTRACT_TEMP, contractList, InfoMsg_001, tmpInfoMsg) = True Then
                isInfo = True
                InfoSubMsg = InfoSubMsg & vbCrLf & tmpInfoMsg
            End If

            ''ﾒｯｾｰｼﾞを戻す
            If isInfo = True Then
                chkContractDeff = ErrKB_Info
                ErrMsg = InfoMsg & InfoSubMsg
                Exit Function
            End If

        Catch ex As Exception
            Throw ex

        End Try

    End Function


    ''' <summary>
    ''' 機能：Payment/詳細ﾌｧｲﾙ情報から、Unmatch情報を取得
    ''' 説明：※統合正契約ﾁｪｯｸ処理で使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Get_UnmatchTable(ByVal PaymentPath As String, _
                                 ByVal contractList As ArrayList, _
                                 ByRef UnmatchPSTable As DataTable, _
                                 ByRef UnmatchDetailTable As DataTable, _
                                 ByRef UnmatchSumPSTable As DataTable, _
                                 ByRef UnmatchSumDetailTable As DataTable, _
                                 ByRef XlsPaymentTable As DataTable, _
                                 ByRef XlsDetailTable As DataTable, _
                                 ByRef TmpXlsPaymentTable() As DataTable, _
                                 ByRef TmpXlsDetailTable() As DataTable, _
                                 ByRef UpdM_ContractTmpList As ArrayList)

        ''初期化/戻り値セット
        Dim rtnPStable As DataTable
        Dim rtnDetailtable As DataTable
        Dim rtnSumPStable As DataTable
        Dim rtnSumDetailtable As DataTable
        rtnPStable = Create_XlsPaymentTable()
        rtnDetailtable = Create_XlsDetailTable()
        rtnSumPStable = Create_XlsSumUnmatchPSTable()
        rtnSumDetailtable = Create_XlsSumUnmatchDetailTable()
        UnmatchPSTable = rtnPStable
        UnmatchDetailTable = rtnDetailtable
        UnmatchSumPSTable = rtnSumPStable
        UnmatchSumDetailTable = rtnSumDetailtable

        Try
            ''仮契約Payment情報のファイル名を加工     ※検索のKeyにファイル名を使用できるように、「仮契約No:XXX」を追加
            Call SetPSTableTmpFileName(TmpXlsPaymentTable)

            ''仮契約Detail情報のファイル名を加工      ※検索のKeyにファイル名を使用できるように、「仮契約No:XXX」を追加
            Call SetDetailTableTmpFileName(TmpXlsDetailTable)

            ''PaymentのUnmatch情報取得
            rtnPStable = GetPaymentDate_UnmatchTable(XlsPaymentTable, TmpXlsPaymentTable, contractList)

            ''個別詳細のUnmatch情報取得
            rtnDetailtable = GetDetailDate_UnmatchTable(XlsDetailTable, TmpXlsDetailTable, contractList)

            ''サマリ情報:PaymentのUnmatch情報取得   ※サマリ情報
            Dim T_UpdM_ContractTmpList(contractList.Count - 1) As UPD_M_CONTRACT_TEMP
            rtnSumPStable = GetSumPaymentDate_UnmatchTable(PaymentPath, XlsPaymentTable, TmpXlsPaymentTable, contractList, T_UpdM_ContractTmpList)

            ''サマリ情報:個別詳細のUnmatch情報取得　※サマリ情報
            rtnSumDetailtable = GetSumDetailDate_UnmatchTable(PaymentPath, XlsDetailTable, TmpXlsDetailTable, contractList, T_UpdM_ContractTmpList)

            ''MDBの更新情報をセット
            For Each tmpvalue As UPD_M_CONTRACT_TEMP In T_UpdM_ContractTmpList
                UpdM_ContractTmpList.Add(tmpvalue)
            Next

            ''戻り値のセット
            UnmatchPSTable = rtnPStable
            UnmatchDetailTable = rtnDetailtable
            UnmatchSumPSTable = rtnSumPStable
            UnmatchSumDetailTable = rtnSumDetailtable

            ''正常ﾛｸﾞ書込
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt1, "Unmatch情報検索処理")

        Catch ex As Exception
            ''ｴﾗｰﾛｸﾞ書込
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt2, "Unmatch情報検索処理")
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt3, ex.Message)

            Throw ex

        End Try

    End Sub


    ''' <summary>
    ''' 機能：仮契約Payment情報のファイル名に「仮契約No:XXX」を追加
    ''' 説明：※Unmatch検索値のKey値としてファイル名を使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetPSTableTmpFileName(ByRef TmpXlsPaymentTable() As DataTable)

        Try

            ''Unmatch検索値のKey値として使用できるように、仮契約情報のファイル名に「仮契約No:XXX」を追加する。
            Dim SetFileNM As String
            For Each TmpTable As DataTable In TmpXlsPaymentTable
                For Each tmpValue As DataRow In TmpTable.Rows
                    SetFileNM = tmpValue.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME)
                    SetFileNM = SetFileNM & _
                                "_仮契約No:" & _
                                tmpValue.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT).PadLeft(3, "3")
                    tmpValue.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME) = SetFileNM
                Next
            Next

        Catch ex As Exception
            Throw ex
        End Try
    End Sub


    ''' <summary>
    ''' 機能：UnmatchTableにレコードを追加する。
    ''' 説明：※詳細情報を追加
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub AddDetailUnmatchDate(ByVal UnmatchKB As String, _
                                     ByRef row As DataRow, _
                                     ByRef rtnTable As DataTable, _
                                     Optional ByRef searchRow As DataRow = Nothing)

        ''Key一致の場合は比較処理。それ以外はrtnTableに無条件Addする。
        Try
            Dim insRow As DataRow
            Select Case UnmatchKB
                Case Me.UnmatchKB_KeyOK

                    Dim unmatchCount As Integer
                    If chkAddDetailUnmatchDate(row, searchRow, unmatchCount) Then

                        ''Unmatch情報の追加
                        insRow = rtnTable.NewRow
                        insRow.ItemArray = row.ItemArray
                        insRow.Item(UnmatchTableColumn_UnmatchKB) = UnmatchKB_KeyOK
                        insRow.Item(UnmatchTableColumn_UnmatchSort) = UnmatchSort_KeyOK & "_" & searchRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT).ToString.PadLeft(3, "0")
                        insRow.Item(UnmatchTableColumn_UnmatchCount) = unmatchCount
                        Call rtnTable.Rows.Add(insRow)

                        ''仮契約データにKey一致ﾁｪｯｸ済みのFlgを立てる。　
                        ''※Key一致しなかった仮契約ﾃﾞｰﾀは後続の処理で、「仮契約のみ」として判定する。
                        row.Item(UnmatchTableColumn_IsUnmatchChk) = IsUnmatchChk_ON
                        row.Item(UnmatchTableColumn_UnmatchKB) = IsUnmatchChk_ON
                        row.Item(UnmatchTableColumn_UnmatchCount) = Me.UnmatchChar
                        searchRow.Item(UnmatchTableColumn_IsUnmatchChk) = UnmatchKB_KeyNG
                        searchRow.Item(UnmatchTableColumn_UnmatchKB) = UnmatchKB_KeyNG
                        searchRow.Item(UnmatchTableColumn_UnmatchCount) = unmatchCount

                    Else
                        row.Item(UnmatchTableColumn_UnmatchCount) = 0
                        row.Item(UnmatchTableColumn_IsUnmatchChk) = IsUnmatchChk_ON
                        row.Item(UnmatchTableColumn_UnmatchKB) = UnmatchKB_KeyOK
                        searchRow.Item(UnmatchTableColumn_IsUnmatchChk) = IsUnmatchChk_ON
                        searchRow.Item(UnmatchTableColumn_UnmatchKB) = UnmatchKB_KeyOK
                        searchRow.Item(UnmatchTableColumn_UnmatchCount) = 0
                    End If

                Case UnmatchKB_ConOnly

                    ''Unmatch情報の追加
                    insRow = rtnTable.NewRow
                    insRow.ItemArray = row.ItemArray
                    insRow.Item(UnmatchTableColumn_UnmatchCount) = 0
                    insRow.Item(UnmatchTableColumn_UnmatchKB) = UnmatchKB_ConOnly
                    insRow.Item(UnmatchTableColumn_UnmatchSort) = UnmatchSort_ConOnly & "_" & _
                                                                  row.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT).ToString.PadLeft(3, "0")
                    Call rtnTable.Rows.Add(insRow)

                    ''Unmatchサマリの件数集計に使用
                    row.Item(UnmatchTableColumn_UnmatchKB) = UnmatchKB_ConOnly
                    row.Item(UnmatchTableColumn_UnmatchCount) = 0
                    row.Item(UnmatchTableColumn_UnmatchSort) = UnmatchSort_ConOnly

                Case UnmatchKB_TmpOnly

                    ''Unmatch情報の追加
                    insRow = rtnTable.NewRow
                    insRow.ItemArray = searchRow.ItemArray
                    insRow.Item(UnmatchTableColumn_UnmatchCount) = 0
                    insRow.Item(UnmatchTableColumn_UnmatchKB) = UnmatchKB_TmpOnly
                    insRow.Item(UnmatchTableColumn_UnmatchSort) = UnmatchSort_TmpOnly & "_" &
                                                                  row.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT).ToString.PadLeft(3, "0")
                    Call rtnTable.Rows.Add(insRow)

                    ''Unmatchﾘｽﾄの件数表示に使用
                    row.Item(UnmatchTableColumn_UnmatchKB) = UnmatchKB_TmpOnly
                    row.Item(UnmatchTableColumn_UnmatchCount) = 0
                    row.Item(UnmatchTableColumn_UnmatchSort) = UnmatchSort_TmpOnly
                    searchRow.Item(UnmatchTableColumn_UnmatchKB) = UnmatchKB_TmpOnly
                    searchRow.Item(UnmatchTableColumn_UnmatchCount) = 0
                    searchRow.Item(UnmatchTableColumn_UnmatchSort) = UnmatchSort_TmpOnly

            End Select
        Catch ex As Exception
            Throw ex

        End Try

    End Sub


    ''' <summary>
    ''' 機能：仮契約Detail情報のファイル名に「仮契約No:XXX」を追加
    ''' 説明：※Unmatch検索値のKey値としてファイル名を使用
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetDetailTableTmpFileName(ByRef TmpXlsDetailTable() As DataTable)

        Try

            ''Unmatch検索値のKey値として使用できるように、仮契約情報のファイル名に「仮契約No:XXX」を追加する。
            Dim SetFileNM As String
            For Each TmpTable As DataTable In TmpXlsDetailTable
                For Each tmpValue As DataRow In TmpTable.Rows
                    SetFileNM = tmpValue.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME)
                    SetFileNM = SetFileNM & _
                                "_仮契約No:" & _
                                tmpValue.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT).PadLeft(3, "3")
                    tmpValue.Item("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME) = SetFileNM
                Next
            Next

        Catch ex As Exception
            Throw ex
        End Try
    End Sub


    ''' <summary>
    ''' 機能：正契約と仮契約PaymentのUnmatch情報を取得する。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetPaymentDate_UnmatchTable(ByRef XlsPaymentTable As DataTable, _
                                                 ByRef TmpXlsPaymentTable() As DataTable, _
                                                 ByRef contractList As ArrayList) As DataTable

        ''初期化/戻り値設定
        Dim rtnTable As DataTable
        rtnTable = Create_XlsPaymentTable()
        GetPaymentDate_UnmatchTable = rtnTable

        Dim row As DataRow                                  ''正契約ﾙｰﾌﾟ行情報 
        Dim tmpRow As DataRow                               ''仮契約ﾙｰﾌﾟ行情報 
        Dim searchRow() As DataRow                          ''「正契約　⇒　仮契約」の検索結果
        Dim Sql_SelPaymentDate_UnmatchTable_1 As String     ''正契約Table検索SQL：仮契約有りのPayment情報の検索SQL
        Dim Sql_SelPaymentDate_UnmatchTable_2 As String     ''仮契約Table検索SQL：「正契約　⇒　仮契約」の検索SQL
        Dim Sql_SelPaymentDate_UnmatchTable_3 As String     ''仮契約Table検索SQL：「正契約　⇒　仮契約」のUnmatch検索SQL
        Try

            ''仮契約なしなら、処理なし
            If IsNothing(TmpXlsPaymentTable) = True Then
                Exit Function
            End If

            ''正契約ﾙｰﾌﾟ
            Sql_SelPaymentDate_UnmatchTable_1 = GetSql_SelPaymentDate_UnmatchTable_1()
            For Each row In XlsPaymentTable.Select(Sql_SelPaymentDate_UnmatchTable_1)

                ''一致ﾃﾞｰﾀの作成処理
                For idx As Integer = 0 To TmpXlsPaymentTable.Length - 1

                    ''削除ﾃﾞｰﾀ作成対応のため、2回ﾁｪｯｸ処理をする。
                    ''※1回目：有効無効FLGを一致条件に含める。
                    Sql_SelPaymentDate_UnmatchTable_2 = GetSql_SelPaymentDate_UnmatchTable_2(row)
                    searchRow = TmpXlsPaymentTable(idx).Select(Sql_SelPaymentDate_UnmatchTable_2)
                    If searchRow.Length > 0 Then
                        Call AddPSUnmatchDate(Me.UnmatchKB_KeyOK, row, rtnTable, searchRow(0))
                        Exit For
                    End If

                Next

                ''「正契約のみ」ﾃﾞｰﾀ作成処理
                Dim tmpValue As Trv_ContractInfo_Date
                Dim tmpFileNM As String
                If searchRow.Length = 0 Then
                    For Each tmpValue In contractList
                        tmpFileNM = "_仮契約No:" & tmpValue.ContractNo.ToString.PadLeft(3, "0")
                        If row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME).ToString.IndexOf(tmpFileNM) <> -1 Then
                            Call AddPSUnmatchDate(Me.UnmatchKB_ConOnly, row, rtnTable)
                        End If
                    Next
                End If

            Next

            ''「仮契約のみ」ﾃﾞｰﾀ作成処理
            Sql_SelPaymentDate_UnmatchTable_3 = GetSql_SelPaymentDate_UnmatchTable_3()
            For idx As Integer = 0 To TmpXlsPaymentTable.Length - 1
                For Each tmpRow In TmpXlsPaymentTable(idx).Select(Sql_SelPaymentDate_UnmatchTable_3)
                    Call AddPSUnmatchDate(Me.UnmatchKB_TmpOnly, row, rtnTable, tmpRow)
                Next
            Next
            Return rtnTable

        Catch ex As Exception
            Throw ex

        End Try

    End Function


    ''' <summary>
    ''' 機能：正契約と仮契約詳細のUnmatch情報を取得する。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetDetailDate_UnmatchTable(ByRef XlsDetailTable As DataTable, _
                                                ByRef TmpXlsDetailTable() As DataTable, _
                                                ByRef contractList As ArrayList) As DataTable

        ''初期化/戻り値設定
        Dim rtnTable As DataTable
        rtnTable = Create_XlsDetailTable()
        GetDetailDate_UnmatchTable = rtnTable

        Dim row As DataRow                                  ''正契約ﾙｰﾌﾟ行情報 
        Dim tmpRow As DataRow                               ''仮契約ﾙｰﾌﾟ行情報 
        Dim searchRow() As DataRow                          ''「正契約　⇒　仮契約」の検索結果
        Dim Sql_SelDetailDate_UnmatchTable_1 As String      ''正契約Table検索SQL：仮契約有りのPayment情報の検索SQL
        Dim Sql_SelDetailDate_UnmatchTable_2 As String      ''仮契約Table検索SQL：「正契約　⇒　仮契約」の検索SQL
        Dim Sql_SelDetailDate_UnmatchTable_3 As String      ''仮契約Table検索SQL：「正契約　⇒　仮契約」のUnmatch検索SQL

        Try

            ''仮契約なしなら、処理なし
            If IsNothing(TmpXlsDetailTable) = True Then
                Exit Function
            End If

            ''正契約ﾙｰﾌﾟ
            Dim unmatchCounta As Integer
            Sql_SelDetailDate_UnmatchTable_1 = GetSql_SelDetailDate_UnmatchTable_1()
            For Each row In XlsDetailTable.Select(Sql_SelDetailDate_UnmatchTable_1)

                ''一致ﾃﾞｰﾀの作成処理
                For idx As Integer = 0 To TmpXlsDetailTable.Length - 1

                    Sql_SelDetailDate_UnmatchTable_2 = GetSql_SelDetailDate_UnmatchTable_2(row)
                    searchRow = TmpXlsDetailTable(idx).Select(Sql_SelDetailDate_UnmatchTable_2)
                    If searchRow.Length > 0 Then
                        Call AddDetailUnmatchDate(Me.UnmatchKB_KeyOK, row, rtnTable, searchRow(0))
                        Exit For
                    End If

                Next

                ''「正契約のみ」ﾃﾞｰﾀ作成処理
                Dim tmpValue As Trv_ContractInfo_Date
                Dim tmpFileNM As String
                If searchRow.Length = 0 Then
                    For Each tmpValue In contractList
                        tmpFileNM = "_仮契約No:" & tmpValue.ContractNo.ToString.PadLeft(3, "0")
                        If row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME).ToString.IndexOf(tmpFileNM) <> -1 Then
                            Call AddPSUnmatchDate(Me.UnmatchKB_ConOnly, row, rtnTable)
                        End If
                    Next
                End If
            Next

            ''「仮契約のみ」ﾃﾞｰﾀ作成処理
            Sql_SelDetailDate_UnmatchTable_3 = GetSql_SelDetailDate_UnmatchTable_3()
            For idx As Integer = 0 To TmpXlsDetailTable.Length - 1
                For Each tmpRow In TmpXlsDetailTable(idx).Select(Sql_SelDetailDate_UnmatchTable_3)
                    Call AddDetailUnmatchDate(Me.UnmatchKB_TmpOnly, tmpRow, rtnTable, tmpRow)
                Next
            Next
            Return rtnTable

        Catch ex As Exception
            Throw ex

        End Try

    End Function


    ''' <summary>
    ''' 機能：UnmatchTableにレコードを追加する。
    ''' 説明：※Payment情報を追加
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub AddPSUnmatchDate(ByVal UnmatchKB As String, _
                                 ByRef row As DataRow, _
                                 ByRef rtnTable As DataTable, _
                                 Optional ByRef searchRow As DataRow = Nothing)

        ''Key一致の場合は比較処理。それ以外はrtnTableに無条件Addする。
        Try
            Dim insRow As DataRow
            Dim unmatchCount As Integer
            Select Case UnmatchKB
                Case Me.UnmatchKB_KeyOK

                    If chkAddPSUnmatchDate(row, searchRow, unmatchCount) = False Then

                        ''Unmatch情報の追加
                        insRow = rtnTable.NewRow
                        insRow.ItemArray = row.ItemArray
                        insRow.Item(UnmatchTableColumn_UnmatchCount) = unmatchCount
                        insRow.Item(UnmatchTableColumn_UnmatchKB) = UnmatchKB_KeyNG
                        insRow.Item(UnmatchTableColumn_UnmatchSort) = UnmatchSort_KeyOK & "_" & _
                                                                      searchRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT).ToString.PadLeft(3, "0")
                        Call rtnTable.Rows.Add(insRow)

                        ''仮契約データにKey一致ﾁｪｯｸ済みのFlgを立てる。　
                        ''※Key一致しなかった仮契約ﾃﾞｰﾀは後続の処理で、「仮契約のみ」として判定する。
                        row.Item(UnmatchTableColumn_IsUnmatchChk) = IsUnmatchChk_ON
                        row.Item(UnmatchTableColumn_UnmatchKB) = UnmatchKB_KeyNG
                        row.Item(UnmatchTableColumn_UnmatchCount) = unmatchCount
                        searchRow.Item(UnmatchTableColumn_IsUnmatchChk) = IsUnmatchChk_ON
                        searchRow.Item(UnmatchTableColumn_UnmatchKB) = UnmatchKB_KeyNG
                        searchRow.Item(UnmatchTableColumn_UnmatchCount) = unmatchCount
                    Else
                        row.Item(UnmatchTableColumn_UnmatchCount) = 0
                        row.Item(UnmatchTableColumn_IsUnmatchChk) = IsUnmatchChk_ON
                        row.Item(UnmatchTableColumn_UnmatchKB) = UnmatchKB_KeyOK
                        searchRow.Item(UnmatchTableColumn_IsUnmatchChk) = IsUnmatchChk_ON
                        searchRow.Item(UnmatchTableColumn_UnmatchKB) = UnmatchKB_KeyOK
                        searchRow.Item(UnmatchTableColumn_UnmatchCount) = 0
                    End If


                Case UnmatchKB_ConOnly

                    ''Unmatch情報の追加
                    insRow = rtnTable.NewRow
                    insRow.ItemArray = row.ItemArray
                    insRow.Item(UnmatchTableColumn_UnmatchCount) = 0
                    insRow.Item(UnmatchTableColumn_UnmatchKB) = UnmatchKB_ConOnly
                    insRow.Item(UnmatchTableColumn_UnmatchSort) = UnmatchSort_ConOnly & "_" & _
                                                                  row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT).ToString.PadLeft(3, "0")
                    Call rtnTable.Rows.Add(insRow)

                    ''Unmatchﾘｽﾄの件数表示に使用
                    row.Item(UnmatchTableColumn_UnmatchKB) = UnmatchKB_ConOnly
                    row.Item(UnmatchTableColumn_UnmatchCount) = 0

                Case UnmatchKB_TmpOnly

                    ''Unmatch情報の追加
                    insRow = rtnTable.NewRow
                    insRow.ItemArray = searchRow.ItemArray
                    insRow.Item(UnmatchTableColumn_UnmatchCount) = 0
                    insRow.Item(UnmatchTableColumn_UnmatchKB) = UnmatchKB_TmpOnly
                    insRow.Item(UnmatchTableColumn_UnmatchSort) = UnmatchSort_TmpOnly & "_" & searchRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT).ToString.PadLeft(3, "0")
                    Call rtnTable.Rows.Add(insRow)

                    ''Unmatchﾘｽﾄの件数表示に使用
                    searchRow.Item(UnmatchTableColumn_UnmatchKB) = UnmatchKB_TmpOnly
                    searchRow.Item(UnmatchTableColumn_UnmatchCount) = 0

            End Select

        Catch ex As Exception
            Throw ex

        End Try
    End Sub


    ''' <summary>
    ''' 機能：Key一致時に、各項目値が一致するか判定する。
    ''' 説明：※Payment情報
    ''' </summary>
    ''' <remarks></remarks>
    Private Function chkAddPSUnmatchDate(ByRef row As DataRow, _
                                         ByRef searchRow As DataRow, _
                                         ByRef unmatchCount As Integer) As Boolean

        ''初期化
        chkAddPSUnmatchDate = True
        unmatchCount = 0

        ''正契約と仮契約の項目値を全て比較        
        Dim Idx As Integer
        Dim rtnChk As Boolean = True
        Dim month As Integer = (CommonVariable.PaymentPeriod * 12)
        For Idx = ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG To _
                  ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL + month

            ''Linnoはﾁｪｯｸしない。
            If Idx = ExcelWrite.ExcelPaymentLineColumn.LINE_NO Then
                Continue For
            End If

            ''契約順番はﾁｪｯｸしない。
            If Idx = ExcelWrite.ExcelPaymentLineColumn.CONTRACT Then
                Continue For
            End If

            ''仮シリアルはﾁｪｯｸしない。
            If Idx = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02 Then
                Continue For
            End If

            ''項目14はﾁｪｯｸしない。
            If Idx = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM14 Then
                Continue For
            End If

            If row.Item("CellNM" & Idx) <> searchRow("CellNM" & Idx) Then
                unmatchCount = unmatchCount + 1
                row.Item("CellNM" & Idx) = UnmatchChar & row.Item("CellNM" & Idx)
                rtnChk = False
            End If
        Next
        chkAddPSUnmatchDate = rtnChk

    End Function


    ''' <summary>
    ''' 機能：Key一致時に、各項目値が一致するか判定する。
    ''' 説明：※詳細情報
    ''' </summary>
    ''' <remarks></remarks>
    Private Function chkAddDetailUnmatchDate(ByRef row As DataRow, _
                                             ByRef searchRow As DataRow, _
                                             ByRef unmatchCount As Integer) As Boolean

        ''初期化
        chkAddDetailUnmatchDate = False
        unmatchCount = 0

        ''正契約と仮契約の項目値を全て比較        
        Dim Idx As Integer
        Dim rtnChk As Boolean = False
        '【既存バグ修正】「サーバー制御/Status」はチェック対象外
        For Idx = ExcelWrite.ExcelPaymentLineDetailColumn.VALID_FLAG To _
                  ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE

            ''契約順番はチェックしない。
            If Idx = ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT Then
                Continue For
            End If

            If row.Item("CellNM" & Idx) <> searchRow("CellNM" & Idx) Then
                row.Item("CellNM" & Idx) = UnmatchChar & row.Item("CellNM" & Idx)
                unmatchCount = unmatchCount + 1
                rtnChk = True
            End If
        Next
        chkAddDetailUnmatchDate = rtnChk

    End Function


    ''' <summary>
    ''' 機能：Unmatch集計シート出力ﾃﾞｰﾀ作成
    ''' 説明：※Payment情報
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSumPaymentDate_UnmatchTable(ByVal PaymentPath As String, _
                                                    ByRef XlsPaymentTable As DataTable, _
                                                    ByRef TmpXlsPaymentTable() As DataTable, _
                                                    ByRef contractList As ArrayList, _
                                                    ByRef T_UpdM_ContractTmpList() As UPD_M_CONTRACT_TEMP) As DataTable

        ''初期化
        Dim rtnTable As DataTable
        rtnTable = Create_XlsSumUnmatchPSTable()
        GetSumPaymentDate_UnmatchTable = rtnTable


        ''PaymentのSummaryｼｰﾄ情報を宣言
        Dim insValue As OutUnmatchSumSheet
        Dim summaryList As New ArrayList
        Dim setContractTmpList As UPD_M_CONTRACT_TEMP                       ''MDBの更新に使用：仮契約情報を格納

        Try

            ''                                      ▼仮契約の情報をｾｯﾄ
            ''---------------------------------------------------------------------------------------------------------------
            ''Payment用の集計数量を宣言      　                             ※「Paymentの値 = 仮契約の合計値」になるものを宣言
            Dim sumMatch_Count As Integer                                   ''一致行
            Dim sumTmponly As Integer                                       ''仮契約のみ
            Dim sumKeyOK As Integer                                         ''Key一致　行数
            Dim sumKeyOKItem As Integer                                     ''Key一致　項目数


            ''件数取得用のSQLを宣言                                         
            Dim Sql_SelUnmTbl_UpdDate As String                             ''更新日時
            Dim Sql_SelUnmTbl_SumCount As String                            ''総行数
            Dim Sql_SelUnmTbl_MatchCount As String                          ''一致件数
            Dim Sql_SelUnmTbl_KeyOK As String                               ''Key一致　行数
            Dim Sql_SelUnmTbl_KeyOKItem As String                           ''Key一致　項目数
            Dim Sql_SelUnmTbl_ConOnly As String                             ''正契約のみ　
            Dim Sql_SelUnmTbl_TmpOnly As String                             ''仮契約のみ


            ''SQL取得
            Sql_SelUnmTbl_SumCount = GetSql_SelUnmTbl_SumCount()              ''総行数
            Sql_SelUnmTbl_MatchCount = GetSql_SelUnmTbl_MatchCount()          ''一致件数
            Sql_SelUnmTbl_TmpOnly = GetSql_SelUnmTbl_TmpOnly()                ''仮契約のみ
            Sql_SelUnmTbl_KeyOK = GetSql_SelUnmTbl_KeyOK()                    ''Key一致　行数


            ''仮契約情報をｾｯﾄ
            Dim TmpTable As DataTable
            Dim keyOKItem As Integer
            Dim tmpRows() As DataRow
            For Idx As Integer = 0 To TmpXlsPaymentTable.Length - 1

                TmpTable = TmpXlsPaymentTable(Idx)

                ''契約順番
                insValue.contract = contractList(Idx).ContractNo

                ''ファイル名
                insValue.in_PS_Filename = Path.GetFileName(contractList(Idx).FilePath)

                ''更新日時
                insValue.update_Date = File.GetLastWriteTime(contractList(Idx).FilePath).ToString("yyyy/MM/dd HH:mm:ss")

                ''一致件数
                tmpRows = TmpTable.Select(Sql_SelUnmTbl_MatchCount)
                insValue.match_Count = tmpRows.Length

                ''総行数
                tmpRows = TmpTable.Select(GetSql_SelUnmTbl_SumCount)
                insValue.sum_Count = tmpRows.Length

                ''正契約のみ行数
                insValue.cononly_Unmatchcount = "-"

                ''仮契約のみ行数
                tmpRows = TmpTable.Select(Sql_SelUnmTbl_TmpOnly)
                insValue.tmponly_Unmatchcount = tmpRows.Length

                ''Key一致　行数
                tmpRows = TmpTable.Select(Sql_SelUnmTbl_KeyOK)
                If tmpRows.Length = 0 Then
                    insValue.keyok_Allcount = 0
                    insValue.keyok_Unmatchcount = 0
                Else
                    ''Key一致行数 / Key一致項目数
                    insValue.keyok_Allcount = tmpRows.Length
                    For Each tmpRow As DataRow In tmpRows
                        keyOKItem = keyOKItem + CInt(tmpRow.Item(UnmatchTableColumn_UnmatchCount))
                    Next
                    insValue.keyok_Unmatchcount = keyOKItem
                    keyOKItem = 0
                End If

                ''仮契約MDB更新情報を取得する。
                T_UpdM_ContractTmpList(Idx).TmpContract = contractList(Idx).ContractNo
                T_UpdM_ContractTmpList(Idx).InPsFileName = Path.GetFileName(contractList(Idx).FilePath)
                T_UpdM_ContractTmpList(Idx).UnMatchPSCount = insValue.keyok_Allcount + _
                                                             insValue.tmponly_Unmatchcount

                ''Payment更新用にサマリする。
                sumMatch_Count = sumMatch_Count + insValue.match_Count
                sumTmponly = sumTmponly + insValue.tmponly_Unmatchcount
                sumKeyOK = sumKeyOK + insValue.keyok_Allcount
                sumKeyOKItem = sumKeyOKItem + insValue.keyok_Unmatchcount

                ''サマリ情報をｾｯﾄ
                Call summaryList.Add(insValue)

            Next


            ''                                      ▼正契約の情報をｾｯﾄ
            ''---------------------------------------------------------------------------------------------------------------
            ''SQL宣言/ｾｯﾄ
            Dim Sql_SelPSUnmTbl_UpdDate As String                           ''更新日時
            Sql_SelPSUnmTbl_UpdDate = GetSql_SelPSUnmTbl_UpdDate(CommonVariable.CPNO, CInt(Me.Cmb_TmpContract.Text))
            Sql_SelUnmTbl_ConOnly = GetSql_SelUnmTbl_ConOnly()                ''正契約のみ

            ''契約順番
            insValue.contract = Me.Cmb_TmpContract.Text

            ''ファイル名
            insValue.in_PS_Filename = Path.GetFileName(PaymentPath)

            ''更新日時
            insValue.update_Date = File.GetLastWriteTime(PaymentPath).ToString("yyyy/MM/dd HH:mm:ss")

            ''一致する行数        
            insValue.match_Count = sumMatch_Count

            ''総行数
            tmpRows = XlsPaymentTable.Select("")
            insValue.sum_Count = tmpRows.Length

            ''正契約のみ行数        
            tmpRows = XlsPaymentTable.Select(Sql_SelUnmTbl_ConOnly)
            insValue.cononly_Unmatchcount = tmpRows.Length

            ''仮契約のみ行数        
            insValue.tmponly_Unmatchcount = sumTmponly

            ''Key一致　行数
            insValue.keyok_Allcount = sumKeyOK

            ''Key一致　項目数
            insValue.keyok_Unmatchcount = sumKeyOKItem

            ''サマリ情報をｾｯﾄ
            Call summaryList.Insert(0, insValue)

            ''                                      ▼ArrayList情報をTableにｾｯﾄ
            ''---------------------------------------------------------------------------------------------------------------
            Call XlsSumUnmatchPSTable(rtnTable, summaryList)
            Return rtnTable

        Catch ex As Exception
            Throw ex

        End Try

    End Function


    ''' <summary>
    ''' 機能：Unmatch集計シート出力ﾃﾞｰﾀ作成
    ''' 説明：※詳細情報
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSumDetailDate_UnmatchTable(ByVal DetailPath As String, _
                                                   ByRef XlsDetailTable As DataTable, _
                                                   ByRef TmpXlsDetailTable() As DataTable, _
                                                   ByRef contractList As ArrayList, _
                                                   ByRef T_UpdM_ContractTmpList() As UPD_M_CONTRACT_TEMP) As DataTable

        ''初期化
        Dim rtnTable As DataTable
        rtnTable = Create_XlsSumUnmatchDetailTable()
        GetSumDetailDate_UnmatchTable = rtnTable


        ''DetailのSummaryｼｰﾄ情報を宣言
        Dim insValue As OutUnmatchSumSheet
        Dim summaryList As New ArrayList

        Try

            ''                                      ▼仮契約の情報をｾｯﾄ
            ''---------------------------------------------------------------------------------------------------------------
            ''Detail用の集計数量を宣言      　                             ※「Detailの値 = 仮契約の合計値」になるものを宣言
            Dim sumMatch_Count As Integer                                   ''一致行
            Dim sumTmponly As Integer                                       ''仮契約のみ
            Dim sumKeyOK As Integer                                         ''Key一致　行数
            Dim sumKeyOKItem As Integer                                     ''Key一致　項目数


            ''件数取得用のSQLを宣言                                         
            Dim Sql_SelDUnmTbl_UpdDate As String                             ''更新日時
            Dim Sql_SelDUnmTbl_SumCount As String                            ''総行数
            Dim Sql_SelDUnmTbl_MatchCount As String                          ''一致件数
            Dim Sql_SelDUnmTbl_KeyOK As String                               ''Key一致　行数
            Dim Sql_SelDUnmTbl_KeyOKItem As String                           ''Key一致　項目数
            Dim Sql_SelDUnmTbl_ConOnly As String                             ''正契約のみ　
            Dim Sql_SelDUnmTbl_TmpOnly As String                             ''仮契約のみ


            ''SQL取得
            Sql_SelDUnmTbl_SumCount = GetSql_SelDUnmTbl_SumCount()              ''総行数
            Sql_SelDUnmTbl_MatchCount = GetSql_SelDUnmTbl_MatchCount()          ''一致件数
            Sql_SelDUnmTbl_TmpOnly = GetSql_SelDUnmTbl_TmpOnly()                ''仮契約のみ
            Sql_SelDUnmTbl_KeyOK = GetSql_SelDUnmTbl_KeyOK()                    ''Key一致　行数


            ''仮契約情報をｾｯﾄ
            Dim TmpTable As DataTable
            Dim keyOKItem As Integer
            Dim tmpRows() As DataRow
            For Idx As Integer = 0 To TmpXlsDetailTable.Length - 1

                TmpTable = TmpXlsDetailTable(Idx)

                ''契約順番
                insValue.contract = contractList(Idx).ContractNo

                ''ファイル名
                insValue.in_PS_Filename = Path.GetFileName(contractList(Idx).FilePath)

                ''更新日時
                insValue.update_Date = File.GetLastWriteTime(contractList(Idx).FilePath).ToString("yyyy/MM/dd HH:mm:ss")

                ''一致件数
                tmpRows = TmpTable.Select(Sql_SelDUnmTbl_MatchCount)
                insValue.match_Count = tmpRows.Length

                ''総行数
                tmpRows = TmpTable.Select(GetSql_SelDUnmTbl_SumCount)
                insValue.sum_Count = tmpRows.Length

                ''正契約のみ行数
                insValue.cononly_Unmatchcount = "-"

                ''仮契約のみ行数
                tmpRows = TmpTable.Select(Sql_SelDUnmTbl_TmpOnly)
                insValue.tmponly_Unmatchcount = tmpRows.Length

                ''Key一致　行数
                tmpRows = TmpTable.Select(Sql_SelDUnmTbl_KeyOK)
                If tmpRows.Length = 0 Then
                    insValue.keyok_Allcount = 0
                    insValue.keyok_Unmatchcount = 0
                Else
                    ''Key一致行数 / Key一致項目数
                    insValue.keyok_Allcount = tmpRows.Length
                    For Each tmpRow As DataRow In tmpRows
                        keyOKItem = keyOKItem + CInt(tmpRow.Item(UnmatchTableColumn_UnmatchCount))
                    Next
                    insValue.keyok_Unmatchcount = keyOKItem
                    keyOKItem = 0
                End If

                ''仮契約MDB更新情報を取得する。  ※Paymentの処理でInsertした行を件数Updateする。
                T_UpdM_ContractTmpList(Idx).TmpContract = contractList(Idx).ContractNo
                T_UpdM_ContractTmpList(Idx).InPsFileName = Path.GetFileName(contractList(Idx).FilePath)
                T_UpdM_ContractTmpList(Idx).UnMatchDetailCount = insValue.keyok_Allcount + _
                                                                 insValue.tmponly_Unmatchcount

                ''Detail更新用にサマリする。
                sumMatch_Count = sumMatch_Count + insValue.match_Count
                sumTmponly = sumTmponly + insValue.tmponly_Unmatchcount
                sumKeyOK = sumKeyOK + insValue.keyok_Allcount
                sumKeyOKItem = sumKeyOKItem + insValue.keyok_Unmatchcount

                ''サマリ情報をｾｯﾄ
                Call summaryList.Add(insValue)

            Next


            ''                                      ▼正契約の情報をｾｯﾄ
            ''---------------------------------------------------------------------------------------------------------------
            ''SQL宣言/ｾｯﾄ
            Dim Sql_SelDPSUnmTbl_UpdDate As String                           ''更新日時
            Sql_SelDPSUnmTbl_UpdDate = GetSql_SelDPSUnmTbl_UpdDate(CommonVariable.CPNO, CInt(Me.Cmb_TmpContract.Text))
            Sql_SelDUnmTbl_ConOnly = GetSql_SelDUnmTbl_ConOnly()              ''正契約のみ

            ''契約順番
            insValue.contract = Me.Cmb_TmpContract.Text

            ''ファイル名
            insValue.in_PS_Filename = Path.GetFileName(DetailPath)

            ''更新日時
            insValue.update_Date = File.GetLastWriteTime(DetailPath).ToString("yyyy/MM/dd HH:mm:ss")

            ''一致する行数        
            insValue.match_Count = sumMatch_Count

            ''総行数
            tmpRows = XlsDetailTable.Select("")
            insValue.sum_Count = tmpRows.Length

            ''正契約のみ行数        
            tmpRows = XlsDetailTable.Select(Sql_SelDUnmTbl_ConOnly)
            insValue.cononly_Unmatchcount = tmpRows.Length

            ''仮契約のみ行数        
            insValue.tmponly_Unmatchcount = sumTmponly

            ''Key一致　行数
            insValue.keyok_Allcount = sumKeyOK

            ''Key一致　項目数
            insValue.keyok_Unmatchcount = sumKeyOKItem

            ''サマリ情報をｾｯﾄ
            Call summaryList.Insert(0, insValue)


            ''                                      ▼ArrayList情報をTableにｾｯﾄ
            ''---------------------------------------------------------------------------------------------------------------
            Call XlsSumUnmatchDetailTable(rtnTable, summaryList)
            Return rtnTable

        Catch ex As Exception
            Throw ex

        End Try

    End Function


    ''' <summary>
    ''' 機能：ArrayListのUnmatchサマリ情報をTableに振り返る。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub XlsSumUnmatchPSTable(ByRef rtnTable As DataTable, _
                                     ByRef summaryList As ArrayList)


        Try
            ''ArrayListの値をDataTableへ振り返る。
            Dim insRow As DataRow
            For Each tmpValue As OutUnmatchSumSheet In summaryList

                ''テーブルにセット
                insRow = rtnTable.NewRow
                insRow.Item(SumUnmatchTableColumn_CONTRACT_NO) = tmpValue.contract
                insRow.Item(SumUnmatchTableColumn_IN_PS_FILENAME) = tmpValue.in_PS_Filename
                insRow.Item(SumUnmatchTableColumn_UPDATE_DATE) = tmpValue.update_Date
                insRow.Item(SumUnmatchTableColumn_SUM_COUNT) = tmpValue.sum_Count
                insRow.Item(SumUnmatchTableColumn_MATCH_COUNT) = tmpValue.match_Count
                insRow.Item(SumUnmatchTableColumn_CONONLY_UNMATCHCOUNT) = tmpValue.cononly_Unmatchcount
                insRow.Item(SumUnmatchTableColumn_TMPONLY_UNMATCHCOUNT) = tmpValue.tmponly_Unmatchcount
                insRow.Item(SumUnmatchTableColumn_KEYOK_ALLCOUNT) = tmpValue.keyok_Allcount
                insRow.Item(SumUnmatchTableColumn_KEYOK_UNMATCHCOUNT) = tmpValue.keyok_Unmatchcount
                Call rtnTable.Rows.Add(insRow)

            Next

        Catch ex As Exception
            Throw ex

        End Try
    End Sub


    ''' <summary>
    ''' 機能：ArrayListのUnmatchサマリ情報をTableに振り返る。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub XlsSumUnmatchDetailTable(ByRef rtnTable As DataTable, _
                                         ByRef summaryList As ArrayList)


        ''ArrayListの値をDataTableへ振り返る。
        Try
            Dim insRow As DataRow
            For Each tmpValue As OutUnmatchSumSheet In summaryList

                ''テーブルにセット
                insRow = rtnTable.NewRow
                insRow.Item(SumUnmatchTableColumn_CONTRACT_NO) = tmpValue.contract
                insRow.Item(SumUnmatchTableColumn_IN_PS_FILENAME) = tmpValue.in_PS_Filename
                insRow.Item(SumUnmatchTableColumn_UPDATE_DATE) = tmpValue.update_Date
                insRow.Item(SumUnmatchTableColumn_SUM_COUNT) = tmpValue.sum_Count
                insRow.Item(SumUnmatchTableColumn_MATCH_COUNT) = tmpValue.match_Count
                insRow.Item(SumUnmatchTableColumn_CONONLY_UNMATCHCOUNT) = tmpValue.cononly_Unmatchcount
                insRow.Item(SumUnmatchTableColumn_TMPONLY_UNMATCHCOUNT) = tmpValue.tmponly_Unmatchcount
                insRow.Item(SumUnmatchTableColumn_KEYOK_ALLCOUNT) = tmpValue.keyok_Allcount
                insRow.Item(SumUnmatchTableColumn_KEYOK_UNMATCHCOUNT) = tmpValue.keyok_Unmatchcount
                Call rtnTable.Rows.Add(insRow)

            Next
        Catch ex As Exception
            Throw ex

        End Try
    End Sub


    ''' <summary>
    ''' 機能：Unmatchﾘｽﾄを作成する。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Create_UnmatchListXls(ByRef UnmatchPSTable As DataTable, _
                                      ByRef UnmatchDetailTable As DataTable, _
                                      ByRef UnmatchSumPSTable As DataTable, _
                                      ByRef UnmatchSumDetailTable As DataTable)

        ''定数
        Const SheetNM_Sum As String = "サマリ"
        Const SheetNM_PS As String = "PS比較"
        Const SheetNM_Detail As String = "詳細比較"
        Const SheetNM_List As String = "リスト"

        ''Excel変数の宣言
        Dim xlApp As New Excel.Application
        Dim xlUnmatchBook As Excel.Workbook
        Dim xlSummarySheet As Excel.Worksheet
        Dim xlPSSheet As Excel.Worksheet
        Dim xlDetailSheet As Excel.Worksheet
        Dim xlListSheet As Excel.Worksheet

        Try
            ''Tmplateファイルをコピーして名前を変える。
            Dim ofm As New OioFileManage
            Dim UmmatchPath As String                           ''Unmatchリストのﾊﾟｽ
            Dim UmmatchTmpPath As String                        ''Unmatchリストのﾃﾝﾌﾟﾚﾌｧｲﾙﾊﾟｽ
            UmmatchPath = ofm.GetUnmatchFilePath(CommonVariable.CPNO, CInt(Me.Cmb_TmpContract.Text))
            UmmatchTmpPath = ofm.GetUnmatchTmpFilePath
            Call File.Copy(UmmatchTmpPath, UmmatchPath)

            ''Excel出力用の配列をｾｯﾄ
            Dim outUnmatchPS(,) As Object
            Dim outUnmatchDetail(,) As Object
            Dim outSumUnmatchPS(,) As Object
            Dim outSumUnmatchDetail(,) As Object
            Call GetOutUnmatchPS(UnmatchPSTable, outUnmatchPS)
            Call GetOutUnmatchDetail(UnmatchDetailTable, outUnmatchDetail)
            Call GetOutUnmatchSumPS(UnmatchSumPSTable, outSumUnmatchPS)
            Call GetOutUnmatchSumDetail(UnmatchSumDetailTable, outSumUnmatchDetail)

            ''App初期化
            xlApp.EnableEvents = False
            xlApp.DisplayAlerts = False
            xlApp.ScreenUpdating = False

            ''BookのOpen
            xlUnmatchBook = xlApp.Workbooks.Open(UmmatchPath)
            xlApp.Calculation = Excel.XlCalculation.xlCalculationManual

            ''ｼｰﾄのｾｯﾄ
            xlSummarySheet = xlUnmatchBook.Worksheets(SheetNM_Sum)
            xlPSSheet = xlUnmatchBook.Worksheets(SheetNM_PS)
            xlDetailSheet = xlUnmatchBook.Worksheets(SheetNM_Detail)
            xlListSheet = xlUnmatchBook.Worksheets(SheetNM_List)

            ''ｼｰﾄに値を書込
            Call WriteUnMListSheet(Me.TBL_M_CONTRACT_BASE, xlListSheet, CommonVariable.CPNO)
            Call WriteUnMSummarySheet(xlSummarySheet, outSumUnmatchPS, outSumUnmatchDetail)
            Call WriteUnMPSSheet(xlPSSheet, outUnmatchPS)
            Call WriteUnMDetailSheet(xlDetailSheet, outUnmatchDetail)

            ''Bookの保存
            xlApp.Calculation = Excel.XlCalculation.xlCalculationAutomatic
            Call xlUnmatchBook.Save()

            ''正常ﾛｸﾞ書込
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt1, "Excel書込処理")

        Catch ex As Exception
            Throw ex

            ''ｴﾗｰﾛｸﾞ書込
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt2, "Excel書込処理")
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt3, ex.Message)

        Finally
            xlApp.ScreenUpdating = True
            xlApp.Calculation = Excel.XlCalculation.xlCalculationAutomatic
            ExcelObjRelease.ReleaseExcelObj(xlDetailSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPSSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSummarySheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlListSheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlUnmatchBook) = False Then
                Call xlUnmatchBook.Close()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlUnmatchBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Sub


    ''' <summary>
    ''' 機能：Unmatchﾘｽﾄ出力用の配列データをセット
    ''' 説明：※PS比較ｼｰﾄ出力用
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetOutUnmatchPS(ByRef UnmatchPSTable As DataTable, _
                                ByRef outUnmatchPS(,) As Object)


        ''定数
        Const StrIdx As Integer = 2                 ''Payment項目の開始位置　※検索結果/不一致項目の後ろ

        ''値が1件もなければ処理を終了する。
        If UnmatchPSTable.Rows.Count = 0 Then
            outUnmatchPS = Nothing
            Exit Sub
        End If

        ''戻り値/初期化
        Dim rtnValue(,) As Object
        Dim month As Integer = CommonVariable.PaymentPeriod * 12
        ReDim rtnValue(UnmatchPSTable.Rows.Count - 1, ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL + month + StrIdx - 1)

        outUnmatchPS = rtnValue

        Try

            ''値を配列にセットする。
            Dim Idx As Integer = -1
            Dim IdxD As Integer
            Dim tmpRow As DataRow
            For Each tmpRow In UnmatchPSTable.Select("", UnmatchTableColumn_UnmatchSort)

                Idx = Idx + 1

                ''検索結果
                If tmpRow.Item(UnmatchTableColumn_UnmatchKB) = Me.UnmatchKB_KeyNG Then
                    rtnValue(Idx, 0) = UnmatchKB_KeyOK
                Else
                    rtnValue(Idx, 0) = tmpRow.Item(UnmatchTableColumn_UnmatchKB)
                End If

                ''不一致項目数
                rtnValue(Idx, 1) = tmpRow.Item(UnmatchTableColumn_UnmatchCount)

                ''その他項目
                For IdxD = StrIdx To ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL + month - 1
                    rtnValue(Idx, IdxD) = tmpRow.Item("CellNM" & IdxD + 1)
                Next
            Next
            outUnmatchPS = rtnValue

        Catch ex As Exception
            Throw ex

        End Try
    End Sub


    ''' <summary>
    ''' 機能：Unmatchﾘｽﾄ出力用の配列データをセット
    ''' 説明：※Detail比較ｼｰﾄ出力用
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetOutUnmatchDetail(ByRef UnmatchDetailTable As DataTable, _
                                    ByRef outUnmatchDetail(,) As Object)


        ''定数
        Const StrIdx As Integer = 2                 ''Detail項目の開始位置　※検索結果/不一致項目の後ろ

        ''値が1件もなければ処理を終了する。
        If UnmatchDetailTable.Rows.Count = 0 Then
            outUnmatchDetail = Nothing
            Exit Sub
        End If

        ''戻り値/初期化
        Dim rtnValue(,) As Object
        ReDim rtnValue(UnmatchDetailTable.Rows.Count - 1, ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE + StrIdx - 1)
        outUnmatchDetail = rtnValue

        Try

            ''値を配列にセットする。
            Dim Idx As Integer = -1
            Dim IdxD As Integer
            Dim tmpRow As DataRow
            For Each tmpRow In UnmatchDetailTable.Select("", UnmatchTableColumn_UnmatchSort)

                Idx = Idx + 1
                tmpRow = UnmatchDetailTable.Rows(Idx)

                ''検索結果
                If tmpRow.Item(UnmatchTableColumn_UnmatchKB) = Me.UnmatchKB_KeyNG Then
                    rtnValue(Idx, 0) = UnmatchKB_KeyOK
                Else
                    rtnValue(Idx, 0) = tmpRow.Item(UnmatchTableColumn_UnmatchKB)
                End If

                ''不一致項目数
                rtnValue(Idx, 1) = tmpRow.Item(UnmatchTableColumn_UnmatchCount)

                ''その他項目
                For IdxD = StrIdx To ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE - 1
                    rtnValue(Idx, IdxD) = tmpRow.Item("CellNM" & IdxD + 1)
                Next
            Next
            outUnmatchDetail = rtnValue

        Catch ex As Exception
            Throw ex

        End Try

    End Sub


    ''' <summary>
    ''' 機能：Unmatchﾘｽﾄ出力用の配列データをセット
    ''' 説明：※サマリシート出力用
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetOutUnmatchSumPS(ByRef UnmatchSumPSTable As DataTable, _
                                   ByRef outUnmatchSumPS(,) As Object)


        ''値が1件もなければ処理を終了する。
        If UnmatchSumPSTable.Rows.Count = 0 Then
            outUnmatchSumPS = Nothing
            Exit Sub
        End If

        ''戻り値/初期化
        Dim rtnValue(,) As Object
        ReDim rtnValue(UnmatchSumPSTable.Rows.Count - 1, UnmatchSumPSTable.Columns.Count - 1)
        outUnmatchSumPS = rtnValue

        Try

            ''値を配列にセットする。
            Dim Idx As Integer
            Dim IdxD As Integer
            Dim tmpRow As DataRow
            For Idx = 0 To UnmatchSumPSTable.Rows.Count - 1

                tmpRow = UnmatchSumPSTable.Rows(Idx)

                ''値セット
                rtnValue(Idx, 0) = tmpRow.Item(SumUnmatchTableColumn_CONTRACT_NO)                   ''契約No
                rtnValue(Idx, 1) = tmpRow.Item(SumUnmatchTableColumn_IN_PS_FILENAME)                ''ファイル名
                rtnValue(Idx, 2) = tmpRow.Item(SumUnmatchTableColumn_UPDATE_DATE)                   ''更新日時
                rtnValue(Idx, 3) = tmpRow.Item(SumUnmatchTableColumn_SUM_COUNT)                     ''総行数
                rtnValue(Idx, 4) = tmpRow.Item(SumUnmatchTableColumn_MATCH_COUNT)                   ''一致行数
                rtnValue(Idx, 5) = tmpRow.Item(SumUnmatchTableColumn_CONONLY_UNMATCHCOUNT)          ''正契約のみ行数
                rtnValue(Idx, 6) = tmpRow.Item(SumUnmatchTableColumn_TMPONLY_UNMATCHCOUNT)          ''仮契約のみ行数
                rtnValue(Idx, 7) = tmpRow.Item(SumUnmatchTableColumn_KEYOK_ALLCOUNT)                ''Key一致 行数
                rtnValue(Idx, 8) = tmpRow.Item(SumUnmatchTableColumn_KEYOK_UNMATCHCOUNT)            ''Key一致 項目数

            Next
            outUnmatchSumPS = rtnValue

        Catch ex As Exception
            Throw ex

        End Try
    End Sub


    ''' <summary>
    ''' 機能：Unmatchﾘｽﾄ出力用の配列データをセット
    ''' 説明：※サマリシート出力用
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetOutUnmatchSumDetail(ByRef UnmatchSumDetailTable As DataTable, _
                                       ByRef outUnmatchSumDetail(,) As Object)


        ''値が1件もなければ処理を終了する。
        If UnmatchSumDetailTable.Rows.Count = 0 Then
            outUnmatchSumDetail = Nothing
            Exit Sub
        End If

        ''戻り値/初期化
        Dim rtnValue(,) As Object
        ReDim rtnValue(UnmatchSumDetailTable.Rows.Count - 1, UnmatchSumDetailTable.Columns.Count - 1)
        outUnmatchSumDetail = rtnValue

        Try

            ''値を配列にセットする。
            Dim Idx As Integer
            Dim IdxD As Integer
            Dim tmpRow As DataRow
            For Idx = 0 To UnmatchSumDetailTable.Rows.Count - 1

                tmpRow = UnmatchSumDetailTable.Rows(Idx)

                ''値セット
                rtnValue(Idx, 0) = tmpRow.Item(SumUnmatchTableColumn_CONTRACT_NO)                   ''契約No
                rtnValue(Idx, 1) = tmpRow.Item(SumUnmatchTableColumn_IN_PS_FILENAME)                ''ファイル名
                rtnValue(Idx, 2) = tmpRow.Item(SumUnmatchTableColumn_UPDATE_DATE)                   ''更新日時
                rtnValue(Idx, 3) = tmpRow.Item(SumUnmatchTableColumn_SUM_COUNT)                     ''総行数
                rtnValue(Idx, 4) = tmpRow.Item(SumUnmatchTableColumn_MATCH_COUNT)                   ''一致行数
                rtnValue(Idx, 5) = tmpRow.Item(SumUnmatchTableColumn_CONONLY_UNMATCHCOUNT)          ''正契約のみ行数
                rtnValue(Idx, 6) = tmpRow.Item(SumUnmatchTableColumn_TMPONLY_UNMATCHCOUNT)          ''仮契約のみ行数
                rtnValue(Idx, 7) = tmpRow.Item(SumUnmatchTableColumn_KEYOK_ALLCOUNT)                ''Key一致 行数
                rtnValue(Idx, 8) = tmpRow.Item(SumUnmatchTableColumn_KEYOK_UNMATCHCOUNT)            ''Key一致 項目数

            Next
            outUnmatchSumDetail = rtnValue

        Catch ex As Exception
            Throw ex

        End Try
    End Sub


    ''' <summary>
    ''' 機能：Umantchﾘｽﾄのﾘｽﾄｼｰﾄ書込
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub WriteUnMListSheet(ByRef TBL_M_CONTRACT_BASE As M_CONTRACT_BASETable, _
                                  ByRef xlListSheet As Excel.Worksheet, _
                                  ByVal CPNO As String)

        ''定数
        Const CellIdx_ConStrYear As String = "A2"               ''契約期間開始_年
        Const CellIdx_ConStrMonth As String = "A3"              ''契約期間開始_月
        Const CellIdx_ConEndYear As String = "B2"               ''契約期間終了_年
        Const CellIdx_ConEndMonth As String = "B3"              ''契約期間終了_月
        Const CellIdx_PayStrYear As String = "C2"               ''Payment開始年
        Dim xlCell As Excel.Range
        Dim rows() As DataRow
        Try

            ''契約基本情報取得
            rows = Me.TBL_M_CONTRACT_BASE.Select("CPNO = '@'".Replace("@", CPNO))
            If rows.Length = 0 Then
                Exit Sub
            End If

            ''ﾘｽﾄｼｰﾄのセット
            xlCell = xlListSheet.Range(CellIdx_ConStrYear)
            xlCell.Value = rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_START_YEAR)
            xlCell = xlListSheet.Range(CellIdx_ConStrMonth)
            xlCell.Value = rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_START_MONTH)
            xlCell = xlListSheet.Range(CellIdx_ConEndYear)
            xlCell.Value = rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_END_YEAR)
            xlCell = xlListSheet.Range(CellIdx_ConEndMonth)
            xlCell.Value = rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_END_MONTH)
            xlCell = xlListSheet.Range(CellIdx_PayStrYear)
            xlCell.Value = rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_EXCEL_START).ToString.Substring(0, 4)

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' 機能：Umantchﾘｽﾄのｻﾏﾘｼｰﾄ書込
    ''' 説明：
    ''' </summary>
    ''' <param name="xlSummarySheet"></param>
    ''' <param name="outSumUnmatchPS"></param>
    ''' <param name="outSumUnmatchDetail"></param>
    ''' <remarks></remarks>
    Private Sub WriteUnMSummarySheet(ByRef xlSummarySheet As Excel.Worksheet, _
                                     ByRef outSumUnmatchPS(,) As Object, _
                                     ByRef outSumUnmatchDetail(,) As Object)

        ''定数
        Const OutPSStrIdx As Integer = 11
        Const OutDetailStrIdx As Integer = 18
        Const CellIdx_TmpRowSumDetail As String = "B4:J4"
        Const CellIdx_TmpRowNomDetail As String = "B5:J5"
        Const CellIdx_OutRowFomDetail As String = "B@Str:J@End"
        Const CellIdx_TmpRowSumPs As String = "B4:P4"
        Const CellIdx_TmpRowNomPs As String = "B5:P5"
        Const CellIdx_OutRowFomPs As String = "B@Str:P@End"
        Const CellIdx_OutRowValPs As String = "B@Str:J@End"

        ''Excel変数の宣言        
        Dim xlCell As Excel.Range
        Dim xlCopyCell As Excel.Range

        ''書込位置の取得に使用
        Dim outArea As String                          ''挿入範囲
        Dim insStrIdx As Integer                       ''挿入開始位置をｾｯﾄ
        Dim insEndIdx As Integer                       ''挿入終了位置をｾｯﾄ
        Try

            ''ﾃﾝﾌﾟﾚ行の表示
            xlCopyCell = xlSummarySheet.Rows("3:5")
            xlCopyCell.Hidden = False


            ''              ▼以下、詳細サマリの作成処理
            ''----------------------------------------------------------
            ''ﾃﾝﾌﾟﾚｰﾄ行のコピペ      ※一行目(黄色行の挿入)
            xlCopyCell = xlSummarySheet.Range(CellIdx_TmpRowSumDetail)
            Call xlCopyCell.Copy()
            insStrIdx = OutDetailStrIdx
            insEndIdx = OutDetailStrIdx
            outArea = CellIdx_OutRowFomDetail.Replace("@Str", insStrIdx) _
                                             .Replace("@End", insEndIdx)
            xlCell = xlSummarySheet.Range(outArea)
            Call xlCell.PasteSpecial()

            ''ﾃﾝﾌﾟﾚｰﾄ行のコピペ      ※二行目以降(白行の挿入)
            If UBound(outSumUnmatchDetail, 1) + 1 >= 2 Then
                xlCopyCell = xlSummarySheet.Range(CellIdx_TmpRowNomDetail)
                Call xlCopyCell.Copy()
                insStrIdx = OutDetailStrIdx + 1
                insEndIdx = OutDetailStrIdx + UBound(outSumUnmatchDetail, 1)
                outArea = CellIdx_OutRowFomDetail.Replace("@Str", insStrIdx) _
                                                 .Replace("@End", insEndIdx)
                xlCell = xlSummarySheet.Range(outArea)
                Call xlCell.PasteSpecial()
            End If

            ''値の貼付
            If UBound(outSumUnmatchDetail, 1) + 1 >= 2 Then
                insStrIdx = OutDetailStrIdx
                insEndIdx = OutDetailStrIdx + UBound(outSumUnmatchDetail, 1)
            Else
                insStrIdx = OutDetailStrIdx
                insEndIdx = OutDetailStrIdx
            End If
            outArea = CellIdx_OutRowFomDetail.Replace("@Str", insStrIdx) _
                                             .Replace("@End", insEndIdx)
            xlCell = xlSummarySheet.Range(outArea)
            xlCell.Value = outSumUnmatchDetail


            ''              ▼以下、PSサマリの作成処理
            ''----------------------------------------------------------
            ''出力件数だけ、Insert処理をする。
            insStrIdx = OutPSStrIdx
            insEndIdx = OutPSStrIdx + UBound(outSumUnmatchPS, 1)
            outArea = insStrIdx.ToString & ":" & insEndIdx.ToString
            xlCell = xlSummarySheet.Range(outArea)
            Call xlCell.Insert()

            ''ﾃﾝﾌﾟﾚｰﾄ行のコピペ      ※一行目(黄色行の挿入)
            xlCopyCell = xlSummarySheet.Range(CellIdx_TmpRowSumPs)
            Call xlCopyCell.Copy()
            insStrIdx = OutPSStrIdx
            insEndIdx = OutPSStrIdx
            outArea = CellIdx_OutRowFomPs.Replace("@Str", insStrIdx) _
                                         .Replace("@End", insEndIdx)
            xlCell = xlSummarySheet.Range(outArea)
            Call xlCell.PasteSpecial()

            ''ﾃﾝﾌﾟﾚｰﾄ行のコピペ      ※二行目以降(白行の挿入)
            If UBound(outSumUnmatchPS, 1) + 1 >= 2 Then
                xlCopyCell = xlSummarySheet.Range(CellIdx_TmpRowNomPs)
                Call xlCopyCell.Copy()
                insStrIdx = OutPSStrIdx + 1
                insEndIdx = OutPSStrIdx + UBound(outSumUnmatchPS, 1)
                outArea = CellIdx_OutRowFomPs.Replace("@Str", insStrIdx) _
                                             .Replace("@End", insEndIdx)
                xlCell = xlSummarySheet.Range(outArea)
                Call xlCell.PasteSpecial()
            End If

            ''値の貼付
            If UBound(outSumUnmatchPS, 1) + 1 >= 2 Then
                insStrIdx = OutPSStrIdx
                insEndIdx = OutPSStrIdx + UBound(outSumUnmatchPS, 1)
            Else
                insStrIdx = OutPSStrIdx
                insEndIdx = OutPSStrIdx
            End If
            outArea = CellIdx_OutRowValPs.Replace("@Str", insStrIdx) _
                                         .Replace("@End", insEndIdx)
            xlCell = xlSummarySheet.Range(outArea)
            xlCell.Value = outSumUnmatchPS

            ''ﾃﾝﾌﾟﾚ行の非表示
            xlCopyCell = xlSummarySheet.Rows("3:5")
            xlCopyCell.Hidden = True

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCopyCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' 機能：PS比較シートの作成
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub WriteUnMPSSheet(ByRef xlPSSheet As Excel.Worksheet, _
                                ByRef outUnmatchPS(,) As Object)


        ''定数
        Dim month As Integer = (CommonVariable.PaymentPeriod * 12)
        Dim CellIdx_CopyRow As String = "A@Str:" & ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL + month) & "@End"

        ''変数の宣言
        Dim setArea As String
        Dim xlCell As Excel.Range
        Dim xlCopyCell As Excel.Range
        Try
            ''データ0件なら処理を終了
            If IsNothing(outUnmatchPS) = True Then
                Exit Sub
            End If

            ''ﾃﾝﾌﾟﾚ行の表示
            xlCopyCell = xlPSSheet.Rows("2:2")
            xlCopyCell.Hidden = False

            ''ﾃﾝﾌﾟﾚ行のコピペ
            Call CopyTmpUnMPSSheet(xlPSSheet, UBound(outUnmatchPS, 1) + 1)

            ''値の貼付
            setArea = CellIdx_CopyRow.Replace("@Str", ExcelWrite.EXCEL_COST_PAYMENT_OUTROW) _
                                     .Replace("@End", ExcelWrite.EXCEL_COST_PAYMENT_OUTROW + UBound(outUnmatchPS, 1))
            xlCell = xlPSSheet.Range(setArea)
            xlCell.Value = outUnmatchPS

            ''背景色の変更
            Call ChgBackColorUnMPSSheet(xlPSSheet, outUnmatchPS)

            ''ﾃﾝﾌﾟﾚ行の非表示
            xlCopyCell = xlPSSheet.Rows("2:2")
            xlCopyCell.Hidden = True

            '不要な年額/月額
            Const RANGE_PAYSTRYEAR As String = "DN"
            ExcelWrite.CreatePaymentPeriod(xlPSSheet, RANGE_PAYSTRYEAR, CommonVariable.PaymentPeriod)

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCopyCell, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub


    ''' <summary>
    ''' 機能：ﾃﾝﾌﾟﾚ行のコピペ
    ''' 説明：※PS比較シートの処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub CopyTmpUnMPSSheet(ByRef xlPSSheet As Excel.Worksheet, _
                                  ByVal outCount As Integer)


        ''補足：一度に大量の行をCopy/Pasteするとｴﾗｰになるので、1000件づつCopyする。                    
        ''定数
        Const CopyMax As Integer = 1000         ''一回のｺﾋﾟｰ行数
        Dim month As Integer = (CommonVariable.PaymentPeriod * 12)
        Dim CopyTmpArea As String = "A@Str:" & ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL + month) & "@End"

        ''変数宣言
        Dim xlCopyCell As Excel.Range
        Dim xlPasteCell As Excel.Range
        Dim CopyCount As Integer                 ''Copy回数
        Dim CopyArea As String                   ''Copy範囲  ※「A?:IT?」形式
        Dim strIdx As Integer                    ''Copy範囲　開始位置
        Dim endIdx As Integer                    ''Copy範囲　終了位置

        Try

            ''1000件づつ貼り付ける。
            CopyCount = System.Math.Truncate((outCount + 1) / CopyMax) + 1
            xlCopyCell = xlPSSheet.Range(CopyTmpArea.Replace("@Str", 2).Replace("@End", 2))
            Call xlCopyCell.Copy()

            For Idx As Integer = 1 To CopyCount

                ''開始位置
                strIdx = Excel_PaymentStrRow + (CopyMax * (Idx - 1))

                ''終了位置
                If CopyCount <= Excel_PaymentStrRow + (CopyMax * (Idx)) - 1 Then
                    endIdx = Excel_PaymentStrRow + outCount - 1
                Else
                    endIdx = Excel_PaymentStrRow + (CopyMax * (Idx)) - 1
                End If
                CopyArea = CopyTmpArea.Replace("@Str", strIdx) _
                                      .Replace("@End", endIdx)

                ''貼付
                xlPasteCell = xlPSSheet.Range(CopyArea)
                Call xlPasteCell.PasteSpecial()

            Next

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCopyCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPasteCell, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub


    ''' <summary>
    ''' 機能：検索結果に応じてセルの背景色を変更する。
    ''' 説明：※PS比較シートの処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub ChgBackColorUnMPSSheet(ByRef xlPSSheet As Excel.Worksheet, _
                                       ByRef outUnmatchPS(,) As Object)

        ''定数
        Const CellIdx_Unmatch As Integer = 0                                ''セルの位置：検索結果
        Dim month As Integer = (CommonVariable.PaymentPeriod * 12)
        Dim CellIdx_ChgArea As String = "A@:" & ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL + month) & "@"                       ''セルの範囲：背景色変更


        Dim xlCell As Excel.Range
        Dim xlInterior As Excel.Interior
        Try
            Dim Idx As Integer
            For Idx = 0 To UBound(outUnmatchPS, 1)

                ''検索結果に応じて、背景色を変更する。
                Dim IdxD As Integer
                Dim setColor As Integer
                Dim Color_lightRed As Integer = RGB(255, 153, 204)              ''Key一致：薄赤
                Dim Color_lightBule As Integer = RGB(204, 255, 204)             ''正契約 ：薄青
                Dim Color_lightGreen As Integer = RGB(204, 255, 255)            ''仮契約 ：薄緑
                Select Case outUnmatchPS(Idx, CellIdx_Unmatch)
                    Case UnmatchKB_KeyOK
                        ''Key一致の場合、ｴﾗｰｾﾙの背景色を変更する。
                        setColor = Color_lightRed
                        For IdxD = ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG To ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL + month
                            If outUnmatchPS(Idx, IdxD - 1).ToString.IndexOf(UnmatchChar) <> -1 Then
                                xlCell = xlPSSheet.Cells(Idx + Excel_PaymentStrRow, IdxD)
                                xlCell.Value = (xlCell.Value).ToString.Replace(UnmatchChar, "")
                                xlInterior = xlCell.Interior
                                xlInterior.Color = setColor
                            End If
                        Next
                    Case UnmatchKB_ConOnly

                        ''背景色のセット
                        setColor = Color_lightBule
                        xlCell = xlPSSheet.Range(CellIdx_ChgArea.Replace("@", Idx + Excel_PaymentStrRow))
                        xlInterior = xlCell.Interior
                        xlInterior.Color = setColor

                    Case UnmatchKB_TmpOnly

                        ''背景色のセット
                        setColor = Color_lightGreen
                        xlCell = xlPSSheet.Range(CellIdx_ChgArea.Replace("@", Idx + Excel_PaymentStrRow))
                        xlInterior = xlCell.Interior
                        xlInterior.Color = setColor

                End Select

            Next

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlInterior, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub


    ''' <summary>
    ''' 機能：Detail比較シートの作成
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub WriteUnMDetailSheet(ByRef xlDetailSheet As Excel.Worksheet, _
                                    ByRef outUnmatchDetail(,) As Object)

        ''定数
        Dim CellIdx_CopyRow As String = ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineDetailColumn.UPDATE_FLAG) & "@Str" & ":" & _
                                         ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE) & "@End"

        ''変数の宣言
        Dim setArea As String
        Dim xlCell As Excel.Range
        Dim xlCopyCell As Excel.Range
        Try
            ''1件もなければ終了
            If IsNothing(outUnmatchDetail) = True Then
                Exit Sub
            End If

            ''ﾃﾝﾌﾟﾚ行の表示
            xlCopyCell = xlDetailSheet.Rows("2:2")
            xlCopyCell.Hidden = False

            ''ﾃﾝﾌﾟﾚ行のコピペ
            Call CopyTmpUnMDetailSheet(xlDetailSheet, UBound(outUnmatchDetail, 1) + 1, outUnmatchDetail)

            ''値の貼付
            setArea = CellIdx_CopyRow.Replace("@Str", ExcelWrite.EXCEL_COST_DETAIL_OUTROW) _
                                     .Replace("@End", ExcelWrite.EXCEL_COST_DETAIL_OUTROW + UBound(outUnmatchDetail, 1))

            xlCell = xlDetailSheet.Range(setArea)
            xlCell.Value = outUnmatchDetail

            ''背景色の変更
            Call ChgBackColorUnMDetailSheet(xlDetailSheet, outUnmatchDetail)

            ''ﾃﾝﾌﾟﾚ行の非表示
            xlCopyCell = xlDetailSheet.Rows("2:2")
            xlCopyCell.Hidden = True

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCopyCell, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' 機能：ﾃﾝﾌﾟﾚ行のコピペ
    ''' 説明：※Detail比較シートの処理
    ''' </summary>
    ''' <param name="xlDetailSheet"></param>
    ''' <param name="outCount"></param>
    ''' <param name="outUnmatchDetail"></param>
    ''' <remarks></remarks>
    Private Sub CopyTmpUnMDetailSheet(ByRef xlDetailSheet As Excel.Worksheet, _
                                      ByVal outCount As Integer, _
                                      ByRef outUnmatchDetail(,) As Object)

        ''補足：一度に大量の行をCopy/Pasteするとｴﾗｰになるので、1000件づつCopyする。                    
        ''定数
        Const CopyMax As Integer = 1000         ''一回のｺﾋﾟｰ行数

        ''変数宣言
        Dim xlCopyCell As Excel.Range
        Dim xlPasteCell As Excel.Range
        Dim CopyCount As Integer                 ''Copy回数
        Dim CopyArea As String                   ''Copy範囲  ※「A?:IT?」形式
        Dim strIdx As Integer                    ''Copy範囲　開始位置
        Dim endIdx As Integer                    ''Copy範囲　終了位置

        Try
            ''1000件づつ貼り付ける。
            CopyCount = System.Math.Truncate((outCount + 1) / CopyMax) + 1
            xlCopyCell = xlDetailSheet.Rows(ExcelWrite.EXCEL_PAYMENTDETAIL_TMPROW)
            xlCopyCell.Hidden = False
            Call xlCopyCell.Copy()

            For Idx As Integer = 1 To CopyCount

                ''開始位置
                strIdx = ExcelWrite.EXCEL_COST_DETAIL_OUTROW + (CopyMax * (Idx - 1))

                ''終了位置
                If CopyCount <= ExcelWrite.EXCEL_COST_DETAIL_OUTROW + (CopyMax * (Idx)) - 1 Then
                    endIdx = ExcelWrite.EXCEL_COST_DETAIL_OUTROW + outCount - 1
                Else
                    endIdx = ExcelWrite.EXCEL_COST_DETAIL_OUTROW + (CopyMax * (Idx)) - 1
                End If
                CopyArea = strIdx & ":" & endIdx
                ''貼付
                xlPasteCell = xlDetailSheet.Rows(CopyArea)

                Call xlPasteCell.PasteSpecial()

            Next

            ''サマリ行の処理
            xlCopyCell = xlDetailSheet.Rows(ExcelWrite.EXCEL_PAYMENTDETAIL_SUMTMPROW)
            xlCopyCell.Hidden = False
            Call xlCopyCell.Copy()
            For idx As Integer = 0 To UBound(outUnmatchDetail, 1)
                If outUnmatchDetail(idx, ExcelWrite.ExcelPaymentLineDetailColumn.IDENTITY_FLAG - 1) = "S" Then
                    xlPasteCell = xlDetailSheet.Rows(idx + ExcelWrite.EXCEL_COST_DETAIL_OUTROW)
                    Call xlPasteCell.PasteSpecial()
                End If
            Next
            xlCopyCell = xlDetailSheet.Rows(ExcelWrite.EXCEL_PAYMENTDETAIL_TMPROW)
            xlCopyCell.Hidden = True

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCopyCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPasteCell, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub


    ''' <summary>
    ''' 機能：検索結果に応じてセルの背景色を変更する。
    ''' 説明：※Detail比較シートの処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub ChgBackColorUnMDetailSheet(ByRef xlDetailSheet As Excel.Worksheet, _
                                           ByRef outUnmatchDetail(,) As Object)

        ''定数
        Const CellIdx_Unmatch As Integer = 0                                ''セルの位置：検索結果
        Dim CellIdx_ChgArea As String = ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineDetailColumn.UPDATE_FLAG) & "@" & ":" & _
                                        ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE) & "@"
        Dim xlCell As Excel.Range
        Dim xlInterior As Excel.Interior
        Try
            Dim Idx As Integer
            Dim IdxD As Integer
            For Idx = 0 To UBound(outUnmatchDetail, 1)

                ''検索結果に応じて、背景色を変更する。
                Dim setColor As Integer                                      ''Key一致：なし
                Dim Color_lightRed As Integer = RGB(255, 153, 204)           ''Key一致：薄赤
                Dim Color_lightBule As Integer = RGB(204, 255, 204)          ''正契約 ：薄青
                Dim Color_lightGreen As Integer = RGB(204, 255, 255)         ''仮契約 ：薄緑
                Select Case outUnmatchDetail(Idx, CellIdx_Unmatch)
                    Case UnmatchKB_KeyOK
                        ''Key一致の場合、ｴﾗｰの背景色をｾｯﾄ
                        setColor = Color_lightRed
                        For IdxD = ExcelWrite.ExcelPaymentLineDetailColumn.VALID_FLAG To ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE
                            If outUnmatchDetail(Idx, IdxD - 1).ToString.IndexOf(UnmatchChar) <> -1 Then
                                xlCell = xlDetailSheet.Cells(ExcelWrite.EXCEL_COST_DETAIL_OUTROW + Idx, IdxD)
                                xlCell.Value = (xlCell.Value).ToString.Replace(UnmatchChar, "")
                                xlInterior = xlCell.Interior
                                xlInterior.Color = setColor
                            End If
                        Next

                    Case UnmatchKB_ConOnly

                        ''背景色のセット
                        setColor = Color_lightBule
                        xlCell = xlDetailSheet.Range(CellIdx_ChgArea.Replace("@", Idx + ExcelWrite.EXCEL_COST_DETAIL_OUTROW))
                        xlInterior = xlCell.Interior
                        xlInterior.Color = setColor

                    Case UnmatchKB_TmpOnly

                        ''背景色のセット
                        setColor = Color_lightGreen
                        xlCell = xlDetailSheet.Range(CellIdx_ChgArea.Replace("@", Idx + ExcelWrite.EXCEL_COST_DETAIL_OUTROW))
                        xlInterior = xlCell.Interior
                        xlInterior.Color = setColor

                End Select

            Next

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlInterior, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' 機能：仮契約情報を更新する。
    ''' 説明：
    ''' </summary>
    ''' <param name="CmbValue"></param>
    ''' <param name="UpdContractTmpList"></param>
    ''' <remarks></remarks>
    Private Sub UpdMDB_Main_Btn_ChkContractDeff(ByVal CmbValue As String, _
                                                ByRef UpdContractTmpList As ArrayList)

        Try
            ''仮契約情報の更新
            Call UpdM_ContractTemp_Btn_ChkContractDeff(CommonVariable.CPNO, _
                                                       CInt(Me.Cmb_TmpContract.Text), _
                                                       UpdContractTmpList)

            ''正常ﾛｸﾞ書込
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt1, "DB更新")

        Catch ex As Exception
            ''ｴﾗｰﾛｸﾞ書込
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt2, "DB更新")
            Call WritePGLogLine(Me.OutLogKB.Normal_Pt3, ex.Message)
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' 機能：仮契約Tableを更新する
    ''' 説明：
    ''' </summary>
    ''' <param name="Cpno"></param>
    ''' <param name="Contract"></param>
    ''' <param name="contractList"></param>
    ''' <remarks></remarks>
    Private Sub UpdM_ContractTemp_Btn_ChkContractDeff(ByVal Cpno As String, _
                                                      ByVal Contract As Integer, _
                                                      ByRef contractList As ArrayList)

        Dim UpdMContractTmp As UPD_M_CONTRACT_TEMP
        Dim dt As New M_CONTRACT_TEMP
        Dim strMsg As String
        Dim wc As New WebDb.WebDbCommon
        Dim blnRet As Boolean
        Dim strWhere As String
        Dim dtUpData As M_CONTRACT_TEMP

        Try
            '認証設定
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW

            '仮契約情報取得
            blnRet = wc.GetContractTempData(Cpno, dt, strMsg)
            If blnRet = False Then
                Throw New Exception(strMsg)
                Exit Sub
            End If

            For Each UpdMContractTmp In contractList
                '統合先_正契約順番、統合元_仮契約順番で抽出
                strWhere = M_CONTRACT_TEMP.COLUMN_NAME_OUT_CONTRACT_NO & "='" & Contract.ToString.PadLeft(3, "0") & "' AND " & _
                           M_CONTRACT_TEMP.COLUMN_NAME_IN_CONTRACT_NO & "='" & UpdMContractTmp.TmpContract.ToString.PadLeft(3, "0") & "'"
                Dim rows() As DataRow = dt.Select(strWhere)
                dtUpData = New M_CONTRACT_TEMP
                dtUpData.ImportRow(rows(0))

                'データセット
                Call SetUpdateDataTempDiff(UpdMContractTmp, dtUpData)

                '更新処理
                blnRet = wc.UpdateContractTempData(dtUpData, strMsg)
                dtUpData = Nothing
                If blnRet = False Then
                    Throw New Exception(strMsg)
                End If
            Next

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

#End Region

#Region "仮契約リセットﾎﾞﾀﾝ関係の処理"

    ''' <summary>
    '''概  要：ﾘﾌﾚｯｼｭﾎﾞﾀﾝの処理を行う。
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Main_Btn_ReSetContract(ByVal IsContractEnd As Boolean,
                                       ByVal isTmpContractCmbAst As Boolean)

        ''ｽﾃｰﾀｽ画面のｾｯﾄ
        Dim dspInfoMsg As String                                        ''進捗画面に表示する文言
        Dim frm_State As New Frm_WaitDialog

        Try
            ''Log書込/進捗状況を画面に通知する。
            Call Me.InitPGLogFile()                                        ''ﾛｸﾞﾌｧｲﾙ初期化
            Call WritePGLogLine(Me.OutLogKB.OutStr)
            Call WritePGLogLine(Me.OutLogKB.ReSetStr)
            Call SetInitWaitDialog(frm_State, "仮契約リセット中…", 2)

            ''画面からリセット対象の仮契約を取得
            Dim contractList As ArrayList
            contractList = GetAListtDate_NotPrentTrv_ContractInfo()

            ''MDB初期化/ﾌｧｲﾙを移動に必要なデータを取得
            Dim mmc As New MasterMdbControl
            Dim createTime As String
            createTime = Now.ToString("yyyyMMdd_HHmmss")       ''作成日：BackUpフォルダ名に使用

            ''画面で選択した仮契約分ループする。
            Dim isSuffixZero As Boolean
            Dim isChkContract As Boolean = False
            Dim tmpContractInfo As Trv_ContractInfo_Date
            For Each tmpContractInfo In contractList

                ''ﾁｪｯｸされているかどうか判定
                If tmpContractInfo.Checked = Me.TrvChecked_ON Then

                    ''対象ﾃﾞｰﾀが存在するかどうか？
                    isChkContract = True

                    ''MDBの値を初期化する。
                    isSuffixZero = False
                    If isTmpContractCmbAst = True Then
                        ''[*]の場合、必ずSuffix初期化
                        isSuffixZero = True
                    Else
                        ''重複する仮契約はSuffixを初期化しない。
                        If tmpContractInfo.DispName.IndexOf("※別の正契約順番で重複登録されています。") <> -1 Then
                            isSuffixZero = False
                        Else
                            isSuffixZero = True
                        End If
                    End If
                    Call ReSetMDB_TmpContractDate(CInt(tmpContractInfo.ContractNo), isTmpContractCmbAst)

                    ''ﾌｧｲﾙを移動/Copyする。
                    Dim isMove As Boolean = True
                    If isSuffixZero = False Then
                        isMove = False
                    End If
                    Call MoveTmpContractFileToBackUP(CommonVariable.CPNO, CInt(tmpContractInfo.ContractNo), createTime, isMove)

                End If

            Next

            ''正契約を締結済みにする。
            If IsContractEnd = True Then
                Call ReSetMDB_ContractDate(CInt(Me.Cmb_TmpContract.Text))
            End If

        Catch ex As Exception
            Dim errDetail As String
            errDetail = GetExceptionErrMsg(frm_State.lbl_Message.Text)
            errDetail = errDetail & vbCrLf & _
                        "エラーの詳細については、Logフォルダ直下に作成される「契約統合_[CPNO].Log」を確認してください。" & vbCrLf & _
                        vbCrLf & _
                        "エラー内容：" & ex.Message
            Throw New Exception(errDetail)

        Finally
            frm_State.Close()
            ''ﾛｸﾞの書込
            Call WritePGLogLine(Me.OutLogKB.ReSetEnd)
            Call WritePGLogLine(Me.OutLogKB.OutEnd)

        End Try

    End Sub

    ''' <summary>
    '''概  要：MDBより、契約情報をリフレッシュする。
    '''説  明：
    ''' </summary>
    ''' <param name="ContractNo"></param>
    ''' <remarks></remarks>
    Private Sub ReSetMDB_ContractDate(ByVal ContractNo As Integer)

        Dim wc As New WebDb.WebDbCommon
        Dim strMsg As String
        Dim blnRet As Boolean
        Dim dt As New M_CONTRACT_DETAILTable

        Try
            '認証設定
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW

            '契約詳細情報取得
            blnRet = wc.GetContractDetailData(CommonVariable.CPNO, ContractNo, dt, strMsg)
            If blnRet = False Then
                Throw New Exception(strMsg)
                Exit Sub
            End If

            'データセット
            dt.Rows(0).Item(M_CONTRACT_DETAILTable.COLUMN_NAME_STATUS) = "1"


            '更新処理
            blnRet = wc.UpdateContractDetailData(dt, strMsg)
            If blnRet = False Then
                Throw New Exception(strMsg)
                Exit Sub
            End If

        Catch ex As Exception
            Throw ex

        End Try

    End Sub

    ''' <summary>
    '''概  要：WebServiceより、仮契約情報をリフレッシュする。
    '''説  明：
    ''' </summary>
    ''' <param name="ContractNo"></param>
    ''' <param name="isTmpContractCmbAst"></param>
    ''' <remarks></remarks>
    Private Sub ReSetMDB_TmpContractDate(ByVal ContractNo As Integer,
                                         ByVal isTmpContractCmbAst As Boolean)

        Dim wc As New WebDb.WebDbCommon
        Dim strMsg As String = ""
        Dim blnRet As Boolean
        Dim dt As New M_CONTRACT_TEMP
        Dim strWhere As String = ""
        Dim dtUpData As New M_CONTRACT_TEMP

        Try
            '認証設定
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW

            '仮契約情報取得
            blnRet = wc.GetContractTempData(CommonVariable.CPNO, dt, strMsg)
            If blnRet = False Then
                Throw New Exception(strMsg)
                Exit Sub
            End If
            'データ抽出
            strWhere = M_CONTRACT_TEMP.COLUMN_NAME_IN_CONTRACT_NO & "='" & ContractNo.ToString.PadLeft(3, "0") & "'"
            If isTmpContractCmbAst = False Then
                strWhere = strWhere & " AND " & M_CONTRACT_TEMP.COLUMN_NAME_OUT_CONTRACT_NO & "='" & Me.Cmb_TmpContract.Text.PadLeft(3, "0") & "'"
            End If
            'データセット
            For Each row As DataRow In dt.Select(strWhere)
                row(M_CONTRACT_TEMP.COLUMN_NAME_STATUS) = "9"
                dtUpData.ImportRow(row)
            Next

            '仮契約情報更新
            blnRet = wc.UpdateContractTempData(dt, strMsg)
            If blnRet = False Then
                Throw New Exception(strMsg)
                Exit Sub
            End If

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' 機　能：仮契約ﾌｧｲﾙをBackUpフォルダに移動する。
    ''' 説　明：※メニューへﾎﾞﾀﾝ押下時に使用
    ''' </summary>
    ''' <param name="CPNO"></param>
    ''' <param name="ContractNo"></param>
    ''' <param name="createTime"></param>
    ''' <param name="isMove"></param>
    ''' <remarks></remarks>
    Private Sub MoveTmpContractFileToBackUP(ByVal CPNO As String, _
                                            ByVal ContractNo As Integer, _
                                            ByVal createTime As String, _
                                            ByVal isMove As Boolean)

        Try

            ''BackUpフォルダを作成
            Dim ofm As New OioFileManage
            Call ofm.CreateTmpConBackUpFolder(CPNO, ContractNo, createTime)

            ''BackUp対象のﾌｫﾙﾀﾞﾊﾟｽを取得
            Dim copyDir As OioFileManage.TmpContractBackUpPath
            copyDir = ofm.GetDetailTmpConCopyFolder(CPNO, ContractNo)

            ''BackUp出力先ﾌｫﾙﾀﾞﾊﾟｽを取得
            Dim pasteDir As OioFileManage.TmpContractBackUpPath
            pasteDir = ofm.GetDetailTmpConBackUpFolder(CPNO, ContractNo)

            ''対象フォルダをBackUpする。
            Call MoveTmpContractFile(copyDir, pasteDir, isMove)

        Catch ex As Exception
            Throw ex

        End Try

    End Sub

    ''' <summary>
    ''' 機　能：引数のﾊﾟｽを元に、仮契約ファイルのフォルダをBackUpフォルダに移す。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub MoveTmpContractFile(ByRef copyDir As OioFileManage.TmpContractBackUpPath, _
                                    ByRef pasteDir As OioFileManage.TmpContractBackUpPath, _
                                    ByVal isMove As Boolean)

        ''             以下、各ﾌｧｲﾙをBackUpの移動
        ''-----------------------------------------------------
        Try
            ''Excleフォルダ
            If System.IO.Directory.Exists(copyDir.Excel) = True Then
                Call FolderMove(copyDir.Excel, pasteDir.Excel, isMove)
            End If

            ''Csv1フォルダ
            If System.IO.Directory.Exists(copyDir.Csv1) = True Then
                Call FolderMove(copyDir.Csv1, pasteDir.Csv1, isMove)
            End If

            ''Csv2フォルダ
            If System.IO.Directory.Exists(copyDir.Csv2) = True Then
                Call FolderMove(copyDir.Csv2, pasteDir.Csv2, isMove)
            End If

            ''Configフォルダ
            If System.IO.Directory.Exists(copyDir.Config) = True Then
                Call FolderMove(copyDir.Config, pasteDir.Config, isMove)
            End If

            ''Outputフォルダ
            If System.IO.Directory.Exists(copyDir.Output) = True Then
                Call FolderMove(copyDir.Output, pasteDir.Output, isMove)
            End If

            ''CsvTmpフォルダ
            If System.IO.Directory.Exists(copyDir.CsvTmp) = True Then
                Call FolderMove(copyDir.CsvTmp, pasteDir.CsvTmp, isMove)
            End If

        Catch ex As Exception
            Throw ex

        End Try

    End Sub


    ''' <summary>
    ''' 機　能：フォルダ直下のﾌｧｲﾙ/ディレクトリを移動する。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub FolderMove(ByVal copyDir As String, _
                           ByVal pasteDir As String, _
                           ByVal isMove As Boolean)

        Try

            ''フォルダ内のファイルの移動
            Dim copyFilePaths() As String
            copyFilePaths = System.IO.Directory.GetFiles(copyDir)
            For Each copyFilePath As String In copyFilePaths
                If isMove = True Then
                    System.IO.File.Move(copyFilePath, _
                                        pasteDir & "\" & Path.GetFileName(copyFilePath))
                Else
                    System.IO.File.Copy(copyFilePath, _
                                        pasteDir & "\" & Path.GetFileName(copyFilePath))
                End If
            Next

            ''フォルダ内のフォルダの移動
            Dim copyDirPaths() As String
            Dim TmpDir() As String
            copyDirPaths = System.IO.Directory.GetDirectories(copyDir)
            For Each copyDirPath As String In copyDirPaths
                TmpDir = Split(copyDirPath, "\")
                If isMove = True Then
                    System.IO.Directory.Move(copyDirPath, _
                                             pasteDir & "\" & TmpDir(UBound(TmpDir)))
                Else
                    My.Computer.FileSystem.CopyDirectory(copyDirPath, pasteDir & "\" & TmpDir(UBound(TmpDir)), True)
                End If
            Next

        Catch ex As Exception
            Throw ex

        End Try

    End Sub

    ''' <summary>
    '''概  要：仮契約リセット処理の処理前の確認ﾒｯｾｰｼﾞを表示する。
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetMessageReSetContract(ByRef msg As String, _
                                        ByRef msgIcon As MessageBoxIcon, _
                                        ByRef msgButton As MessageBoxButtons)


        ''ﾒｯｾｰｼﾞ一覧
        Const InfoMessage_001 As String = "他の正契約で重複した仮契約が含まれています。" & vbCrLf & _
                                          "該当する正契約を締結済にして、処理を続行してもよろしいですか？" & vbCrLf & _
                                          "※続行した場合、仮契約ファイルはBackUpフォルダに移動します。" & vbCrLf & _
                                          "" & vbCrLf & _
                                          "　はい　　　：「締結済」にして処理を続行" & vbCrLf & _
                                          "　いいえ　　：「締結済」にしないで、処理を続行" & vbCrLf & _
                                          "　キャンセル：処理を中断する。"

        Const InfoMessage_002 As String = "仮契約のﾘﾌﾚｯｼｭを行います。" & vbCrLf & _
                                          "該当する正契約を締結済にして、処理を続行してもよろしいですか？" & vbCrLf & _
                                          "※続行した場合、仮契約ファイルはBackUpフォルダに移動します。" & vbCrLf & _
                                          "" & vbCrLf & _
                                          "　はい　　　：「締結済」にして処理を続行" & vbCrLf & _
                                          "　いいえ　　：「締結済」にしないで、処理を続行" & vbCrLf & _
                                          "　キャンセル：処理を中断する。"

        Const InfoMessage_003 As String = "仮契約のﾘﾌﾚｯｼｭを行います。" & vbCrLf & _
                                          "「*」を指定しているため、正契約を締結済にはできませんがよろしいでしょうか？" & vbCrLf & _
                                          "※続行した場合、仮契約ファイルはBackUpフォルダに移動します。" & vbCrLf & _
                                          "" & vbCrLf & _
                                          "　はい　　　：「締結済」にしないで、処理を続行" & vbCrLf & _
                                          "　いいえ　　：処理を中断する。"

        ''以下、条件に応じて戻すメッセージを変更する。
        ''ﾒｯｾｰｼﾞ_001
        If Me.Cmb_TmpContract.Text <> "*" And _
           ChkExistsContract() = True Then
            msg = InfoMessage_001
            msgIcon = MessageBoxIcon.Information
            msgButton = MessageBoxButtons.YesNoCancel
            Exit Sub
        End If

        ''ﾒｯｾｰｼﾞ_002
        If Me.Cmb_TmpContract.Text <> "*" And _
           ChkExistsContract() = False Then
            msg = InfoMessage_002
            msgIcon = MessageBoxIcon.Information
            msgButton = MessageBoxButtons.YesNoCancel
            Exit Sub
        End If

        ''ﾒｯｾｰｼﾞ_003
        If Me.Cmb_TmpContract.Text = "*" Then
            msg = InfoMessage_003
            msgIcon = MessageBoxIcon.Information
            msgButton = MessageBoxButtons.YesNo
            Exit Sub
        End If

    End Sub


    ''' <summary>
    '''概  要：重複する仮契約が存在するかチェックする。
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function ChkExistsContract() As Boolean

        ''初期化
        Dim isExistsContract As Boolean = False
        ChkExistsContract = isExistsContract

        ''ﾂﾘｰﾋﾞｭｰをループして、重複した仮契約が存在するかチェックする。
        Dim contractItem As Trv_ContractInfo_Date
        Dim contractList As ArrayList
        contractList = GetAListtDate_NotPrentTrv_ContractInfo()
        For Each contractItem In contractList
            If contractItem.Checked = Me.TrvChecked_ON And _
               contractItem.DispName.IndexOf("※別の正契約順番で重複登録されています。") <> -1 Then
                isExistsContract = True
                Exit For
            End If
        Next
        ChkExistsContract = isExistsContract

    End Function

    ''' <summary>
    '''概  要：重複している仮契約情報を削除する。
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub DelDistinctRows(ByRef rows() As DataRow)

        Dim tmpRow As DataRow
        Dim rowList As New ArrayList
        Dim contractList As New ArrayList

        ''配列にﾃﾞｰﾀがなければ処理終了
        Dim DummyTable As New DataTable
        If rows.Length = 0 Then
            rows = DummyTable.Select("")
            Exit Sub
        End If

        ''重複しない仮契約をArrayListにセットする。
        For Idx As Integer = 0 To rows.Length - 1

            ''契約順番が重複している仮契約は、値を追加しない。
            If contractList.IndexOf(rows(Idx).Item(M_CONTRACT_TEMP.COLUMN_NAME_IN_CONTRACT_NO)) = -1 Then
                Call contractList.Add(rows(Idx).Item(M_CONTRACT_TEMP.COLUMN_NAME_IN_CONTRACT_NO))
                Call rowList.Add(rows(Idx))
            End If

        Next

        ''ArrayListを配列に入れ替える。    
        If rowList.Count = 0 Then
            rows = DummyTable.Select("")
        Else
            Dim rtnRows(rowList.Count - 1) As DataRow
            For idx As Integer = 0 To rowList.Count - 1
                rtnRows(idx) = rowList(idx)
            Next
            rows = rtnRows
        End If
    End Sub

#End Region

#Region "テーブル定義"

    ''' <summary>
    ''' 機能：Paymentﾌｧｲﾙの情報を格納するTableを定義する。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function Create_XlsPaymentTable() As DataTable


        ''ﾃｰﾌﾞﾙの列を定義する。
        Dim rtnTable As New DataTable
        For i As Integer = ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG To _
                           ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12
            rtnTable.Columns.Add("CellNM" & i, Type.GetType("System.String"))
        Next

        ''ﾏｰｼﾞ処理に必要な項目
        rtnTable.Columns.Add(MergeTableColumn_ContractKB, Type.GetType("System.String"))
        rtnTable.Columns.Add(MergeTableColumn_TmpContract, Type.GetType("System.String"))
        rtnTable.Columns.Add(MergeTableColumn_ExcelLine, Type.GetType("System.String"))
        rtnTable.Columns.Add(MergeTableColumn_DelInsert, Type.GetType("System.String"))
        rtnTable.Columns.Add(MergeTableColumn_FileContract, Type.GetType("System.String"))
        rtnTable.Columns.Add(MergeTableColumn_SortLineNo, Type.GetType("System.String"))
        rtnTable.Columns.Add(MergeTableColumn_SortContract, Type.GetType("System.String"))

        ''UnMatch処理に必要な項目
        rtnTable.Columns.Add(UnmatchTableColumn_UnmatchKB, Type.GetType("System.String"))
        rtnTable.Columns.Add(UnmatchTableColumn_UnmatchCount, Type.GetType("System.String"))
        rtnTable.Columns.Add(UnmatchTableColumn_UnmatchSort, Type.GetType("System.String"))
        rtnTable.Columns.Add(UnmatchTableColumn_IsUnmatchChk, Type.GetType("System.String"))

        Return rtnTable

    End Function


    ''' <summary>
    ''' 機能：詳細ﾌｧｲﾙの情報を格納するTableを定義する。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function Create_XlsDetailTable() As DataTable


        ''ﾃｰﾌﾞﾙの列を定義する。
        Dim rtnTable As New DataTable
        For i As Integer = ExcelWrite.ExcelPaymentLineDetailColumn.UPDATE_FLAG To _
                           ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE
            rtnTable.Columns.Add("CellNM" & i, Type.GetType("System.String"))
        Next
        ''ﾏｰｼﾞ処理に必要な項目
        rtnTable.Columns.Add(MergeTableColumn_ContractKB, Type.GetType("System.String"))
        rtnTable.Columns.Add(MergeTableColumn_TmpContract, Type.GetType("System.String"))
        rtnTable.Columns.Add(MergeTableColumn_ExcelLine, Type.GetType("System.String"))
        rtnTable.Columns.Add(MergeTableColumn_DelInsert, Type.GetType("System.String"))
        rtnTable.Columns.Add(MergeTableColumn_SortContract, Type.GetType("System.String"))
        rtnTable.Columns.Add(MergeTableColumn_ChildCount, Type.GetType("System.String"))

        ''UnMatch処理に必要な項目
        rtnTable.Columns.Add(UnmatchTableColumn_UnmatchKB, Type.GetType("System.String"))
        rtnTable.Columns.Add(UnmatchTableColumn_UnmatchCount, Type.GetType("System.String"))
        rtnTable.Columns.Add(UnmatchTableColumn_UnmatchSort, Type.GetType("System.String"))
        rtnTable.Columns.Add(UnmatchTableColumn_IsUnmatchChk, Type.GetType("System.String"))

        Return rtnTable

    End Function


    ''' <summary>
    ''' 機能：Payment配列の値をTableへｾｯﾄ
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetArrayDataInXlsPaymentTable(ByVal inFileKB As String, _
                                              ByRef TmpValue(,) As Object, _
                                              ByRef XlsPaymentTable As DataTable)

        Try
            Dim row As DataRow
            Dim Idx As Integer                  ''ﾙｰﾌﾟ変数:Payment行数分ﾙｰﾌﾟ
            Dim IdxD As Integer                 ''ﾙｰﾌﾟ変数:詳細行数分ﾙｰﾌﾟ
            For Idx = 1 To UBound(TmpValue, 1)

                row = XlsPaymentTable.NewRow
                For IdxD = ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG To _
                           ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12
                    row.Item("CellNM" & IdxD) = ExcelWrite.changeDBNullToString(TmpValue(Idx, IdxD))
                Next

                ''追加項目のｾｯﾄ            
                row.Item(Me.MergeTableColumn_ContractKB) = inFileKB
                row.Item(Me.MergeTableColumn_TmpContract) = GetTmpContractNo(inFileKB, row)
                row.Item(Me.MergeTableColumn_FileContract) = XlsPaymentTable.TableName
                row.Item(Me.MergeTableColumn_ExcelLine) = (Idx - 1) + ExcelWrite.EXCEL_COST_PAYMENT_OUTROW
                row.Item(Me.MergeTableColumn_DelInsert) = ""

                ''追加
                XlsPaymentTable.Rows.Add(row)

            Next

        Catch ex As Exception
            Throw ex

        End Try

    End Sub


    ''' <summary>
    ''' 機能：Detail配列の値をTableへｾｯﾄ
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetArrayDataInXlsDetailTable(ByVal InFileKB As String, _
                                             ByRef TmpValue(,) As Object, _
                                             ByRef XlsDetailTable As DataTable)

        Dim row As DataRow
        Dim Idx As Integer                  ''ﾙｰﾌﾟ変数:Payment行数分ﾙｰﾌﾟ
        Dim IdxD As Integer                 ''ﾙｰﾌﾟ変数:詳細行数分ﾙｰﾌﾟ
        Dim childCount As Integer           ''S行に紐づく子行が何行存在するか?

        Try
            For Idx = 1 To UBound(TmpValue, 1)

                row = XlsDetailTable.NewRow
                For IdxD = ExcelWrite.ExcelPaymentLineDetailColumn.UPDATE_FLAG To _
                           ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE
                    row.Item("CellNM" & IdxD) = ExcelWrite.changeDBNullToString(TmpValue(Idx, IdxD))
                Next

                row.Item(MergeTableColumn_ContractKB) = InFileKB
                row.Item(MergeTableColumn_TmpContract) = GetDTmpContractNo(InFileKB, row)
                row.Item(MergeTableColumn_ExcelLine) = (Idx - 1) + ExcelWrite.EXCEL_COST_DETAIL_OUTROW
                row.Item(MergeTableColumn_DelInsert) = ""

                Call XlsDetailTable.Rows.Add(row)
            Next

        Catch ex As Exception
            Throw ex

        End Try
    End Sub

    ''' <summary>
    ''' 機能：Unmatchサマリ(PS)情報を格納するTableを定義する。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function Create_XlsSumUnmatchPSTable() As DataTable

        ''ﾃｰﾌﾞﾙの列を定義する。
        Dim rtnTable As New DataTable

        ''ﾃｰﾌﾞﾙの列を定義する。
        rtnTable.Columns.Add(SumUnmatchTableColumn_CONTRACT_NO, Type.GetType("System.String"))
        rtnTable.Columns.Add(SumUnmatchTableColumn_IN_PS_FILENAME, Type.GetType("System.String"))
        rtnTable.Columns.Add(SumUnmatchTableColumn_UPDATE_DATE, Type.GetType("System.String"))
        rtnTable.Columns.Add(SumUnmatchTableColumn_SUM_COUNT, Type.GetType("System.String"))
        rtnTable.Columns.Add(SumUnmatchTableColumn_MATCH_COUNT, Type.GetType("System.String"))
        rtnTable.Columns.Add(SumUnmatchTableColumn_CONONLY_UNMATCHCOUNT, Type.GetType("System.String"))
        rtnTable.Columns.Add(SumUnmatchTableColumn_TMPONLY_UNMATCHCOUNT, Type.GetType("System.String"))
        rtnTable.Columns.Add(SumUnmatchTableColumn_KEYOK_ALLCOUNT, Type.GetType("System.String"))
        rtnTable.Columns.Add(SumUnmatchTableColumn_KEYOK_UNMATCHCOUNT, Type.GetType("System.String"))

        Return rtnTable

    End Function


    ''' <summary>
    ''' 機能：Unmatchサマリ(詳細)情報を格納するTableを定義する。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function Create_XlsSumUnmatchDetailTable() As DataTable

        ''ﾃｰﾌﾞﾙの列を定義する。
        Dim rtnTable As New DataTable

        ''ﾃｰﾌﾞﾙの列を定義する。
        rtnTable.Columns.Add(SumUnmatchTableColumn_CONTRACT_NO, Type.GetType("System.String"))
        rtnTable.Columns.Add(SumUnmatchTableColumn_IN_PS_FILENAME, Type.GetType("System.String"))
        rtnTable.Columns.Add(SumUnmatchTableColumn_UPDATE_DATE, Type.GetType("System.String"))
        rtnTable.Columns.Add(SumUnmatchTableColumn_MATCH_COUNT, Type.GetType("System.String"))
        rtnTable.Columns.Add(SumUnmatchTableColumn_SUM_COUNT, Type.GetType("System.String"))
        rtnTable.Columns.Add(SumUnmatchTableColumn_CONONLY_UNMATCHCOUNT, Type.GetType("System.String"))
        rtnTable.Columns.Add(SumUnmatchTableColumn_TMPONLY_UNMATCHCOUNT, Type.GetType("System.String"))
        rtnTable.Columns.Add(SumUnmatchTableColumn_KEYOK_ALLCOUNT, Type.GetType("System.String"))
        rtnTable.Columns.Add(SumUnmatchTableColumn_KEYOK_UNMATCHCOUNT, Type.GetType("System.String"))

        Return rtnTable

    End Function


#End Region

#Region "処理中ダイアログ関係の処理"

    ''' <summary>
    ''' 機　能：処理中ﾀﾞｲｱﾙﾛｸﾞの初期設定
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetInitWaitDialog(ByRef waitDialog As Frm_WaitDialog, _
                                  ByVal stateMsg As String, _
                                  ByVal progMax As Integer)

        waitDialog.Text = "ﾃﾞｰﾀ処理中・・・"
        waitDialog.lbl_Message.Text = stateMsg
        waitDialog.Pic_Excel.Visible = True
        waitDialog.ProgressMin = 0
        waitDialog.ProgressMax = progMax
        waitDialog.ProgressStep = 0
        waitDialog.ProgressValue = 0
        waitDialog.Show(Me)
        waitDialog.Refresh()

    End Sub


    ''' <summary>
    ''' 機　能：処理中ﾀﾞｲｱﾙﾛｸﾞのﾌﾟﾛｸﾞﾚｽﾊﾞｰ更新
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetStepProgress(ByRef waitDialog As Frm_WaitDialog, _
                                Optional ByVal stateMsg As String = "")

        waitDialog.lbl_Message.Text = stateMsg
        waitDialog.ProgressValue = waitDialog.Prg_Process.Value + 1
        waitDialog.Refresh()

    End Sub

    ''' <summary>
    ''' 機　能：処理中ﾀﾞｲｱﾙﾛｸﾞのﾒｯｾｰｼﾞ変更
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetDispMsg(ByRef waitDialog As Frm_WaitDialog, _
                           ByVal stateMsg As String, _
                           Optional ByVal ProgressMax As Integer = 0)

        waitDialog.Text = stateMsg
        If ProgressMax <> 0 Then
            waitDialog.Pic_Excel.Visible = True
            waitDialog.ProgressMin = 0
            waitDialog.ProgressMax = ProgressMax
            waitDialog.ProgressStep = 1
            waitDialog.ProgressValue = 0
        End If
        waitDialog.Refresh()

    End Sub

#End Region

#Region "Log出力関係の処理"

    ''' <summary>
    ''' 機能：ﾛｸﾞﾌｧｲﾙの初期化
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InitPGLogFile()

        ''ファイルの出力先を取得
        Dim outFileName As String
        Dim outputDir As String = ""
        Dim outputPath As String = ""
        outFileName = "契約統合_@.log".Replace("@", CommonVariable.CPNO)
        outputDir = FileManager.GetLocalFolderPath(CommonConstant.FOLDERNAME_LOG)
        outputPath = outputDir & outFileName

        ''ﾌｧｲﾙ削除　※再作成の処理は「WritePGLogLine」内で行われる。
        Call File.Delete(outputPath)

    End Sub


    ''' <summary>
    ''' 機能：ﾛｸﾞﾒｯｾｰｼﾞ書込
    ''' 説明：※追記で書込を行う。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub WritePGLogLine(ByVal OutLogKB As Integer, _
                               Optional ByVal OutLine As String = "")

        Const ENCODE_SHIFT_JIS As String = "shift-jis"

        ''ファイルの出力先を取得
        Dim outFileName As String
        Dim outputDir As String = ""
        Dim outputPath As String = ""
        outFileName = "契約統合_@.log".Replace("@", CommonVariable.CPNO)
        outputDir = FileManager.GetLocalFolderPath(CommonConstant.FOLDERNAME_LOG)
        outputPath = outputDir & outFileName


        ''ファイルオブジェクトの作成
        Dim logWriter As StreamWriter = Nothing
        Dim hStream As System.IO.FileStream
        If File.Exists(outputPath) = False Then
            ''ファイルを作成
            hStream = System.IO.File.Create(outputPath)
            Try
                ' hStream が閉じられることを保証するために Try ～ Finally を使用する
                Try
                Finally
                    ''ﾌｧｲﾙを閉じる
                    If Not hStream Is Nothing Then
                        hStream.Close()
                    End If
                End Try
            Finally
                ''hStreamを破棄する
                If Not hStream Is Nothing Then
                    Dim cDisposable As System.IDisposable = hStream
                    cDisposable.Dispose()
                End If
            End Try
        End If

        logWriter = New StreamWriter(outputPath, True, Encoding.GetEncoding(ENCODE_SHIFT_JIS))

        ''メッセージの書込
        Dim OutMsg As String
        OutMsg = GetPGLogLine(OutLogKB, OutLine)
        logWriter.WriteLine(OutMsg)

        ''ファイルオブジェクトの解放
        If IsNothing(logWriter) = False Then
            logWriter.Close()
        End If

    End Sub


    ''' <summary>
    ''' 機能：ﾛｸﾞﾒｯｾｰｼﾞのフォーマットを変換する。
    ''' 説明：※追記で書込を行う。
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetPGLogLine(ByVal OutLogKB As OutLogKB, _
                                  ByVal OutLine As String) As String

        Dim AddLine As String
        Dim outTime As String = Now.ToString("HH:mm:ss") & ","    ''「HH:mm:ss」 + 「,」は必ず出力 
        Select Case OutLogKB
            Case OutLogKB.OutStr
                AddLine = outTime & "処理_STR"

            Case OutLogKB.ActStr
                AddLine = outTime & "=========================================================" & vbCrLf & _
                          outTime & "       　　　仮契約の統合処理を開始します。              " & vbCrLf & _
                          outTime & "========================================================="

            Case OutLogKB.DelStr
                AddLine = outTime & "=========================================================" & vbCrLf & _
                          outTime & "       　　　仮契約の削除処理を開始します。              " & vbCrLf & _
                          outTime & "========================================================="

            Case OutLogKB.UnMStr
                AddLine = outTime & "=========================================================" & vbCrLf & _
                          outTime & "       　　　UnMatchリスト作成処理を開始します。         " & vbCrLf & _
                          outTime & "========================================================="

            Case OutLogKB.ReSetStr
                AddLine = outTime & "=========================================================" & vbCrLf & _
                          outTime & "       　　　仮契約リセット処理を開始します。            " & vbCrLf & _
                          outTime & "========================================================="

            Case OutLogKB.Titel_Pt1
                AddLine = outTime & vbCrLf & _
                          outTime & "	      ▼正契約情報ファイルの読込処理                  " & vbCrLf & _
                          outTime & "---------------------------------------------------------"

            Case OutLogKB.Titel_Pt2
                AddLine = outTime & vbCrLf & _
                          outTime & "	      ▼仮情報ファイルの読込処理                      " & vbCrLf & _
                          outTime & "---------------------------------------------------------"

            Case OutLogKB.Titel_Pt3
                AddLine = outTime & vbCrLf & _
                          outTime & "	      ▼正契約情報と仮契約情報をマージ処理            " & vbCrLf & _
                          outTime & "---------------------------------------------------------"

            Case OutLogKB.Titel_Pt4
                AddLine = outTime & vbCrLf & _
                          outTime & "	      ▼Excelﾌｧｲﾙにﾃﾞｰﾀを書込処理                     " & vbCrLf & _
                          outTime & "---------------------------------------------------------"

            Case OutLogKB.Titel_Pt5
                AddLine = outTime & vbCrLf & _
                          outTime & "	      ▼MDBの更新処理　　　　　　                     " & vbCrLf & _
                          outTime & "---------------------------------------------------------"

            Case OutLogKB.Titel_Pt6
                AddLine = outTime & vbCrLf & _
                          outTime & "	      ▼削除対象データの検索処理　　　                " & vbCrLf & _
                          outTime & "---------------------------------------------------------"

            Case OutLogKB.Titel_Pt7
                AddLine = outTime & vbCrLf & _
                          outTime & "	      ▼Excelファイルの削除処理 　　　                " & vbCrLf & _
                          outTime & "---------------------------------------------------------"

            Case OutLogKB.Titel_Pt8
                AddLine = outTime & vbCrLf & _
                          outTime & "	      ▼Unmatch情報検索処理 　　　                    " & vbCrLf & _
                          outTime & "---------------------------------------------------------"

            Case OutLogKB.Normal_Pt1
                AddLine = outTime & "◆完了:" & OutLine

            Case OutLogKB.Normal_Pt2
                AddLine = outTime & "◆エラー：" & OutLine

            Case OutLogKB.Normal_Pt3
                AddLine = outTime & ("　⇒「@」").Replace("@", OutLine) & vbCrLf & _
                          outTime

            Case OutLogKB.Normal_Pt4
                AddLine = outTime & ("◆　　　⇒仮契約No：@").Replace("@", OutLine)

            Case OutLogKB.Normal_Pt5
                AddLine = outTime & ("◆以下、@の処理").Replace("@", OutLine)

            Case OutLogKB.Normal_Pt6
                AddLine = outTime & ""      ''空行

            Case OutLogKB.UnMEnd
                AddLine = outTime & "=========================================================" & vbCrLf & _
                          outTime & "       　　　UnMatchリスト作成処理を終了します。         " & vbCrLf & _
                          outTime & "========================================================="

            Case OutLogKB.DelEnd
                AddLine = outTime & "=========================================================" & vbCrLf & _
                          outTime & "       　　　仮契約の削除処理を終了します。              " & vbCrLf & _
                          outTime & "========================================================="

            Case OutLogKB.ActEnd
                AddLine = outTime & "=========================================================" & vbCrLf & _
                          outTime & "       　　　仮契約の統合処理を終了します。              " & vbCrLf & _
                          outTime & "========================================================="

            Case OutLogKB.ReSetEnd
                AddLine = outTime & "=========================================================" & vbCrLf & _
                          outTime & "       　　　仮契約リセット処理を終了します。              " & vbCrLf & _
                          outTime & "========================================================="


            Case OutLogKB.OutEnd
                AddLine = outTime & "処理_END"

        End Select
        Return AddLine

    End Function

    ''' <summary>
    ''' 機能：GSAパス存在チェック
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckGsaPath() As Boolean

        Dim mmc As New MasterMdbControl
        Dim strGsaPath As String

        CheckGsaPath = False

        Try
            strGsaPath = mmc.GetMasterMbdPath.Server_MasterMdb_FolderName

            If Directory.Exists(strGsaPath) = False Then
                MsgBox(FileReader.GetMessage("MSG_0443"), vbCritical, Me.Text)
                Exit Function
            End If

            CheckGsaPath = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "CheckGsaPath")
        End Try

    End Function

    ''' <summary>
    ''' 機能：契約締結済み/廃案案件チェック
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckStatus() As Boolean

        Dim blnRet As Boolean
        Dim wc As New WebDb.WebDbCommon
        Dim strMsg As String
        Dim dt As New M_CONTRACT_DETAILTable
        Dim strContractNo As String
        Dim strStatus As String

        CheckStatus = False

        Try
            '認証設定
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW

            '契約詳細情報取得
            strContractNo = Cmb_TmpContract.Text.Trim
            blnRet = wc.GetContractDetailData(CommonVariable.CPNO, strContractNo, dt, strMsg)
            If blnRet = False Then
                Throw New Exception(strMsg)
                Exit Function
            End If

            '1:契約済み or 2：廃案の場合、
            strStatus = ExcelWrite.changeDBNullToZero(dt.Rows(0).Item(M_CONTRACT_DETAILTable.COLUMN_NAME_STATUS))
            If strStatus = "1" Or strStatus = "2" Then
                MsgBox(FileReader.GetMessage("MSG_0444"), MsgBoxStyle.Critical, Me.Text)
                Exit Function
            End If

            CheckStatus = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "CheckStatus")

        End Try

    End Function

    Private Function ChkPaymentPriods(ByVal paymentPath As String,
                                      ByRef contractList As ArrayList) As Boolean

        '初期化
        ChkPaymentPriods = True

        '正契約/仮契約を配列へセット
        Dim filePaths() As String
        Dim tmpList As New ArrayList
        Dim tmpvalue As Trv_ContractInfo_Date
        ''正契約のパス
        tmpList.Add(paymentPath)
        ''仮契約のパス
        For Each tmpvalue In contractList
            ''ﾁｪｯｸなし/ﾌｧｲﾙなしはﾁｪｯｸ処理しない。
            If tmpvalue.Checked = Me.TrvChecked_OFF Then
                Continue For
            End If
            If tmpvalue.FileExist = False Then
                Continue For
            End If
            tmpList.Add(tmpvalue.FilePath)
        Next
        filePaths = DirectCast(tmpList.ToArray(GetType(String)), String())

        '日付のチェック
        Dim rtnCd As Integer
        Dim rtnMsg As String
        rtnCd = ExcelWrite.chkPayPeriod(rtnMsg,
                                        ExcelWrite.enmChkPayPeriodCallMethod.mergeContract,
                                        filePaths)
        Select Case rtnCd
            Case ExcelWrite.enmChkPayPeriodRtnCd.ChkOK              'OK
            Case ExcelWrite.enmChkPayPeriodRtnCd.ChkNG,
                 ExcelWrite.enmChkPayPeriodRtnCd.ChkException       'NG/例外
                Call MsgBox(rtnMsg, MsgBoxStyle.Critical)
                ChkPaymentPriods = False
                Exit Function
        End Select

    End Function

#End Region

#End Region

End Class