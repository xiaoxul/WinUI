﻿Imports System.IO
Imports System.Text
Imports System.Data.OleDb
Imports Microsoft.Office.Interop
Imports MUSE.Utility
Imports MUSE.Utility.OioBamaCommmon
Imports MUSE.Utility.SharedClass

Public Class ExcelEla

#Region "Const"

    '------------------------------------------
    'Excel関連
    '------------------------------------------
    Private Const EXCEL_MAX_ROW As Integer = 65536      'EXCELの最終行

    Private Const EXCEL_COL_ELA_DATA_NO1 As Integer = 1
    Private Const EXCEL_COL_ELA_DATA_NO3 As Integer = 2
    Private Const EXCEL_COL_ELA_DATA_NO8 As Integer = 3
    Private Const EXCEL_COL_ELA_SVC_START As Integer = 4
    Private Const EXCEL_COL_ELA_SVC_END As Integer = 5
    Private Const EXCEL_COL_ELA_INST_YM As Integer = 6
    Private Const EXCEL_COL_ELA_PAY_START_YM As Integer = 7
    Private Const EXCEL_COL_ELA_PAY_END_YM As Integer = 8
    Private Const EXCEL_COL_ELA_PAY_FLAG As Integer = 9
    Private Const EXCEL_COL_ELA_PAY_METHOD As Integer = 10
    Private Const EXCEL_COL_ELA_LIST_PRICE_PROPOSAL As Integer = 11
    Private Const EXCEL_COL_ELA_LIST_PRICE As Integer = 12
    Private Const EXCEL_COL_ELA_OFFERING_PRICE As Integer = 13
    Private Const EXCEL_COL_ELA_MONTH001 As Integer = 14
    Private Const EXCEL_COL_ELA_MONTH002 As Integer = 15
    Private Const EXCEL_COL_ELA_MONTH003 As Integer = 16
    Private Const EXCEL_COL_ELA_MONTH004 As Integer = 17
    Private Const EXCEL_COL_ELA_MONTH005 As Integer = 18
    Private Const EXCEL_COL_ELA_MONTH006 As Integer = 19
    Private Const EXCEL_COL_ELA_MONTH007 As Integer = 20
    Private Const EXCEL_COL_ELA_MONTH008 As Integer = 21
    Private Const EXCEL_COL_ELA_MONTH009 As Integer = 22
    Private Const EXCEL_COL_ELA_MONTH010 As Integer = 23
    Private Const EXCEL_COL_ELA_MONTH011 As Integer = 24
    Private Const EXCEL_COL_ELA_MONTH012 As Integer = 25
    Private Const EXCEL_COL_ELA_MONTH013 As Integer = 26
    Private Const EXCEL_COL_ELA_MONTH014 As Integer = 27
    Private Const EXCEL_COL_ELA_MONTH015 As Integer = 28
    Private Const EXCEL_COL_ELA_MONTH016 As Integer = 29
    Private Const EXCEL_COL_ELA_MONTH017 As Integer = 30
    Private Const EXCEL_COL_ELA_MONTH018 As Integer = 31
    Private Const EXCEL_COL_ELA_MONTH019 As Integer = 32
    Private Const EXCEL_COL_ELA_MONTH020 As Integer = 33
    Private Const EXCEL_COL_ELA_MONTH021 As Integer = 34
    Private Const EXCEL_COL_ELA_MONTH022 As Integer = 35
    Private Const EXCEL_COL_ELA_MONTH023 As Integer = 36
    Private Const EXCEL_COL_ELA_MONTH024 As Integer = 37
    Private Const EXCEL_COL_ELA_MONTH025 As Integer = 38
    Private Const EXCEL_COL_ELA_MONTH026 As Integer = 39
    Private Const EXCEL_COL_ELA_MONTH027 As Integer = 40
    Private Const EXCEL_COL_ELA_MONTH028 As Integer = 41
    Private Const EXCEL_COL_ELA_MONTH029 As Integer = 42
    Private Const EXCEL_COL_ELA_MONTH030 As Integer = 43
    Private Const EXCEL_COL_ELA_MONTH031 As Integer = 44
    Private Const EXCEL_COL_ELA_MONTH032 As Integer = 45
    Private Const EXCEL_COL_ELA_MONTH033 As Integer = 46
    Private Const EXCEL_COL_ELA_MONTH034 As Integer = 47
    Private Const EXCEL_COL_ELA_MONTH035 As Integer = 48
    Private Const EXCEL_COL_ELA_MONTH036 As Integer = 49
    Private Const EXCEL_COL_ELA_MONTH037 As Integer = 50
    Private Const EXCEL_COL_ELA_MONTH038 As Integer = 51
    Private Const EXCEL_COL_ELA_MONTH039 As Integer = 52
    Private Const EXCEL_COL_ELA_MONTH040 As Integer = 53
    Private Const EXCEL_COL_ELA_MONTH041 As Integer = 54
    Private Const EXCEL_COL_ELA_MONTH042 As Integer = 55
    Private Const EXCEL_COL_ELA_MONTH043 As Integer = 56
    Private Const EXCEL_COL_ELA_MONTH044 As Integer = 57
    Private Const EXCEL_COL_ELA_MONTH045 As Integer = 58
    Private Const EXCEL_COL_ELA_MONTH046 As Integer = 59
    Private Const EXCEL_COL_ELA_MONTH047 As Integer = 60
    Private Const EXCEL_COL_ELA_MONTH048 As Integer = 61
    Private Const EXCEL_COL_ELA_MONTH049 As Integer = 62
    Private Const EXCEL_COL_ELA_MONTH050 As Integer = 63
    Private Const EXCEL_COL_ELA_MONTH051 As Integer = 64
    Private Const EXCEL_COL_ELA_MONTH052 As Integer = 65
    Private Const EXCEL_COL_ELA_MONTH053 As Integer = 66
    Private Const EXCEL_COL_ELA_MONTH054 As Integer = 67
    Private Const EXCEL_COL_ELA_MONTH055 As Integer = 68
    Private Const EXCEL_COL_ELA_MONTH056 As Integer = 69
    Private Const EXCEL_COL_ELA_MONTH057 As Integer = 70
    Private Const EXCEL_COL_ELA_MONTH058 As Integer = 71
    Private Const EXCEL_COL_ELA_MONTH059 As Integer = 72
    Private Const EXCEL_COL_ELA_MONTH060 As Integer = 73
    Private Const EXCEL_COL_ELA_MONTH061 As Integer = 74
    Private Const EXCEL_COL_ELA_MONTH062 As Integer = 75
    Private Const EXCEL_COL_ELA_MONTH063 As Integer = 76
    Private Const EXCEL_COL_ELA_MONTH064 As Integer = 77
    Private Const EXCEL_COL_ELA_MONTH065 As Integer = 78
    Private Const EXCEL_COL_ELA_MONTH066 As Integer = 79
    Private Const EXCEL_COL_ELA_MONTH067 As Integer = 80
    Private Const EXCEL_COL_ELA_MONTH068 As Integer = 81
    Private Const EXCEL_COL_ELA_MONTH069 As Integer = 82
    Private Const EXCEL_COL_ELA_MONTH070 As Integer = 83
    Private Const EXCEL_COL_ELA_MONTH071 As Integer = 84
    Private Const EXCEL_COL_ELA_MONTH072 As Integer = 85
    Private Const EXCEL_COL_ELA_MONTH073 As Integer = 86
    Private Const EXCEL_COL_ELA_MONTH074 As Integer = 87
    Private Const EXCEL_COL_ELA_MONTH075 As Integer = 88
    Private Const EXCEL_COL_ELA_MONTH076 As Integer = 89
    Private Const EXCEL_COL_ELA_MONTH077 As Integer = 90
    Private Const EXCEL_COL_ELA_MONTH078 As Integer = 91
    Private Const EXCEL_COL_ELA_MONTH079 As Integer = 92
    Private Const EXCEL_COL_ELA_MONTH080 As Integer = 93
    Private Const EXCEL_COL_ELA_MONTH081 As Integer = 94
    Private Const EXCEL_COL_ELA_MONTH082 As Integer = 95
    Private Const EXCEL_COL_ELA_MONTH083 As Integer = 96
    Private Const EXCEL_COL_ELA_MONTH084 As Integer = 97
    Private Const EXCEL_COL_ELA_MONTH085 As Integer = 98
    Private Const EXCEL_COL_ELA_MONTH086 As Integer = 99
    Private Const EXCEL_COL_ELA_MONTH087 As Integer = 100
    Private Const EXCEL_COL_ELA_MONTH088 As Integer = 101
    Private Const EXCEL_COL_ELA_MONTH089 As Integer = 102
    Private Const EXCEL_COL_ELA_MONTH090 As Integer = 103
    Private Const EXCEL_COL_ELA_MONTH091 As Integer = 104
    Private Const EXCEL_COL_ELA_MONTH092 As Integer = 105
    Private Const EXCEL_COL_ELA_MONTH093 As Integer = 106
    Private Const EXCEL_COL_ELA_MONTH094 As Integer = 107
    Private Const EXCEL_COL_ELA_MONTH095 As Integer = 108
    Private Const EXCEL_COL_ELA_MONTH096 As Integer = 109
    Private Const EXCEL_COL_ELA_MONTH097 As Integer = 110
    Private Const EXCEL_COL_ELA_MONTH098 As Integer = 111
    Private Const EXCEL_COL_ELA_MONTH099 As Integer = 112
    Private Const EXCEL_COL_ELA_MONTH100 As Integer = 113
    Private Const EXCEL_COL_ELA_MONTH101 As Integer = 114
    Private Const EXCEL_COL_ELA_MONTH102 As Integer = 115
    Private Const EXCEL_COL_ELA_MONTH103 As Integer = 116
    Private Const EXCEL_COL_ELA_MONTH104 As Integer = 117
    Private Const EXCEL_COL_ELA_MONTH105 As Integer = 118
    Private Const EXCEL_COL_ELA_MONTH106 As Integer = 119
    Private Const EXCEL_COL_ELA_MONTH107 As Integer = 120
    Private Const EXCEL_COL_ELA_MONTH108 As Integer = 121
    Private Const EXCEL_COL_ELA_MONTH109 As Integer = 122
    Private Const EXCEL_COL_ELA_MONTH110 As Integer = 123
    Private Const EXCEL_COL_ELA_MONTH111 As Integer = 124
    Private Const EXCEL_COL_ELA_MONTH112 As Integer = 125
    Private Const EXCEL_COL_ELA_MONTH113 As Integer = 126
    Private Const EXCEL_COL_ELA_MONTH114 As Integer = 127
    Private Const EXCEL_COL_ELA_MONTH115 As Integer = 128
    Private Const EXCEL_COL_ELA_MONTH116 As Integer = 129
    Private Const EXCEL_COL_ELA_MONTH117 As Integer = 130
    Private Const EXCEL_COL_ELA_MONTH118 As Integer = 131
    Private Const EXCEL_COL_ELA_MONTH119 As Integer = 132
    Private Const EXCEL_COL_ELA_MONTH120 As Integer = 133
    Private Const EXCEL_COL_ELA_MONTH121 As Integer = 134
    Private Const EXCEL_COL_ELA_MONTH122 As Integer = 135
    Private Const EXCEL_COL_ELA_MONTH123 As Integer = 136
    Private Const EXCEL_COL_ELA_MONTH124 As Integer = 137
    Private Const EXCEL_COL_ELA_MONTH125 As Integer = 138
    Private Const EXCEL_COL_ELA_MONTH126 As Integer = 139
    Private Const EXCEL_COL_ELA_MONTH127 As Integer = 140
    Private Const EXCEL_COL_ELA_MONTH128 As Integer = 141
    Private Const EXCEL_COL_ELA_MONTH129 As Integer = 142
    Private Const EXCEL_COL_ELA_MONTH130 As Integer = 143
    Private Const EXCEL_COL_ELA_MONTH131 As Integer = 144
    Private Const EXCEL_COL_ELA_MONTH132 As Integer = 145
    Private Const EXCEL_COL_ELA_MONTH133 As Integer = 146
    Private Const EXCEL_COL_ELA_MONTH134 As Integer = 147
    Private Const EXCEL_COL_ELA_MONTH135 As Integer = 148
    Private Const EXCEL_COL_ELA_MONTH136 As Integer = 149
    Private Const EXCEL_COL_ELA_MONTH137 As Integer = 150
    Private Const EXCEL_COL_ELA_MONTH138 As Integer = 151
    Private Const EXCEL_COL_ELA_MONTH139 As Integer = 152
    Private Const EXCEL_COL_ELA_MONTH140 As Integer = 153
    Private Const EXCEL_COL_ELA_MONTH141 As Integer = 154
    Private Const EXCEL_COL_ELA_MONTH142 As Integer = 155
    Private Const EXCEL_COL_ELA_MONTH143 As Integer = 156
    Private Const EXCEL_COL_ELA_MONTH144 As Integer = 157
    Private Const EXCEL_COL_ELA_MONTH145 As Integer = 158
    Private Const EXCEL_COL_ELA_MONTH146 As Integer = 159
    Private Const EXCEL_COL_ELA_MONTH147 As Integer = 160
    Private Const EXCEL_COL_ELA_MONTH148 As Integer = 161
    Private Const EXCEL_COL_ELA_MONTH149 As Integer = 162
    Private Const EXCEL_COL_ELA_MONTH150 As Integer = 163
    Private Const EXCEL_COL_ELA_MONTH151 As Integer = 164
    Private Const EXCEL_COL_ELA_MONTH152 As Integer = 165
    Private Const EXCEL_COL_ELA_MONTH153 As Integer = 166
    Private Const EXCEL_COL_ELA_MONTH154 As Integer = 167
    Private Const EXCEL_COL_ELA_MONTH155 As Integer = 168
    Private Const EXCEL_COL_ELA_MONTH156 As Integer = 169
    Private Const EXCEL_COL_ELA_MONTH157 As Integer = 170
    Private Const EXCEL_COL_ELA_MONTH158 As Integer = 171
    Private Const EXCEL_COL_ELA_MONTH159 As Integer = 172
    Private Const EXCEL_COL_ELA_MONTH160 As Integer = 173
    Private Const EXCEL_COL_ELA_MONTH161 As Integer = 174
    Private Const EXCEL_COL_ELA_MONTH162 As Integer = 175
    Private Const EXCEL_COL_ELA_MONTH163 As Integer = 176
    Private Const EXCEL_COL_ELA_MONTH164 As Integer = 177
    Private Const EXCEL_COL_ELA_MONTH165 As Integer = 178
    Private Const EXCEL_COL_ELA_MONTH166 As Integer = 179
    Private Const EXCEL_COL_ELA_MONTH167 As Integer = 180
    Private Const EXCEL_COL_ELA_MONTH168 As Integer = 181
    Private Const EXCEL_COL_ELA_MONTH169 As Integer = 182
    Private Const EXCEL_COL_ELA_MONTH170 As Integer = 183
    Private Const EXCEL_COL_ELA_MONTH171 As Integer = 184
    Private Const EXCEL_COL_ELA_MONTH172 As Integer = 185
    Private Const EXCEL_COL_ELA_MONTH173 As Integer = 186
    Private Const EXCEL_COL_ELA_MONTH174 As Integer = 187
    Private Const EXCEL_COL_ELA_MONTH175 As Integer = 188
    Private Const EXCEL_COL_ELA_MONTH176 As Integer = 189
    Private Const EXCEL_COL_ELA_MONTH177 As Integer = 190
    Private Const EXCEL_COL_ELA_MONTH178 As Integer = 191
    Private Const EXCEL_COL_ELA_MONTH179 As Integer = 192
    Private Const EXCEL_COL_ELA_MONTH180 As Integer = 193
    Private Const EXCEL_COL_ELA_MONTH181 As Integer = 194
    Private Const EXCEL_COL_ELA_MONTH182 As Integer = 195
    Private Const EXCEL_COL_ELA_MONTH183 As Integer = 196
    Private Const EXCEL_COL_ELA_MONTH184 As Integer = 197
    Private Const EXCEL_COL_ELA_MONTH185 As Integer = 198
    Private Const EXCEL_COL_ELA_MONTH186 As Integer = 199
    Private Const EXCEL_COL_ELA_MONTH187 As Integer = 200
    Private Const EXCEL_COL_ELA_MONTH188 As Integer = 201
    Private Const EXCEL_COL_ELA_MONTH189 As Integer = 202
    Private Const EXCEL_COL_ELA_MONTH190 As Integer = 203
    Private Const EXCEL_COL_ELA_MONTH191 As Integer = 204
    Private Const EXCEL_COL_ELA_MONTH192 As Integer = 205
    Private Const EXCEL_COL_ELA_MONTH193 As Integer = 206
    Private Const EXCEL_COL_ELA_MONTH194 As Integer = 207
    Private Const EXCEL_COL_ELA_MONTH195 As Integer = 208
    Private Const EXCEL_COL_ELA_MONTH196 As Integer = 209
    Private Const EXCEL_COL_ELA_MONTH197 As Integer = 210
    Private Const EXCEL_COL_ELA_MONTH198 As Integer = 211
    Private Const EXCEL_COL_ELA_MONTH199 As Integer = 212
    Private Const EXCEL_COL_ELA_MONTH200 As Integer = 213
    Private Const EXCEL_COL_ELA_MONTH201 As Integer = 214
    Private Const EXCEL_COL_ELA_MONTH202 As Integer = 215
    Private Const EXCEL_COL_ELA_MONTH203 As Integer = 216
    Private Const EXCEL_COL_ELA_MONTH204 As Integer = 217
    Private Const EXCEL_COL_ELA_MONTH205 As Integer = 218
    Private Const EXCEL_COL_ELA_MONTH206 As Integer = 219
    Private Const EXCEL_COL_ELA_MONTH207 As Integer = 220
    Private Const EXCEL_COL_ELA_MONTH208 As Integer = 221
    Private Const EXCEL_COL_ELA_MONTH209 As Integer = 222
    Private Const EXCEL_COL_ELA_MONTH210 As Integer = 223
    Private Const EXCEL_COL_ELA_MONTH211 As Integer = 224
    Private Const EXCEL_COL_ELA_MONTH212 As Integer = 225
    Private Const EXCEL_COL_ELA_MONTH213 As Integer = 226
    Private Const EXCEL_COL_ELA_MONTH214 As Integer = 227
    Private Const EXCEL_COL_ELA_MONTH215 As Integer = 228
    Private Const EXCEL_COL_ELA_MONTH216 As Integer = 229
    Private Const EXCEL_COL_ELA_MONTH217 As Integer = 230
    Private Const EXCEL_COL_ELA_MONTH218 As Integer = 231
    Private Const EXCEL_COL_ELA_MONTH219 As Integer = 232
    Private Const EXCEL_COL_ELA_MONTH220 As Integer = 233
    Private Const EXCEL_COL_ELA_MONTH221 As Integer = 234
    Private Const EXCEL_COL_ELA_MONTH222 As Integer = 235
    Private Const EXCEL_COL_ELA_MONTH223 As Integer = 236
    Private Const EXCEL_COL_ELA_MONTH224 As Integer = 237
    Private Const EXCEL_COL_ELA_MONTH225 As Integer = 238
    Private Const EXCEL_COL_ELA_MONTH226 As Integer = 239
    Private Const EXCEL_COL_ELA_MONTH227 As Integer = 240
    Private Const EXCEL_COL_ELA_MONTH228 As Integer = 241
    Private Const EXCEL_COL_ELA_MONTH229 As Integer = 242
    Private Const EXCEL_COL_ELA_MONTH230 As Integer = 243
    Private Const EXCEL_COL_ELA_MONTH231 As Integer = 244
    Private Const EXCEL_COL_ELA_MONTH232 As Integer = 245
    Private Const EXCEL_COL_ELA_MONTH233 As Integer = 246
    Private Const EXCEL_COL_ELA_MONTH234 As Integer = 247
    Private Const EXCEL_COL_ELA_MONTH235 As Integer = 248
    Private Const EXCEL_COL_ELA_MONTH236 As Integer = 249
    Private Const EXCEL_COL_ELA_MONTH237 As Integer = 250
    Private Const EXCEL_COL_ELA_MONTH238 As Integer = 251
    Private Const EXCEL_COL_ELA_MONTH239 As Integer = 252
    Private Const EXCEL_COL_ELA_MONTH240 As Integer = 253

    Private Const EXCEL_ROWDATA_START_ELA_DATA As Integer = 4

#End Region

#Region "Enum"

    '取得結果(ELAデータ)
    Private Enum EXCEL_COL_ELA
        DATA_NO1 = 1
        DATA_NO3
        DATA_NO8
        SVC_START
        SVC_END
        INST_YM
        PAY_START_YM
        PAY_END_YM
        PAY_FLAG
        PAY_METHOD
        LIST_PRICE_PROPOSAL
        LIST_PRICE
        OFFERING_PRICE
        MONTH001
        MONTH002
        MONTH003
        MONTH004
        MONTH005
        MONTH006
        MONTH007
        MONTH008
        MONTH009
        MONTH010
        MONTH011
        MONTH012
        MONTH013
        MONTH014
        MONTH015
        MONTH016
        MONTH017
        MONTH018
        MONTH019
        MONTH020
        MONTH021
        MONTH022
        MONTH023
        MONTH024
        MONTH025
        MONTH026
        MONTH027
        MONTH028
        MONTH029
        MONTH030
        MONTH031
        MONTH032
        MONTH033
        MONTH034
        MONTH035
        MONTH036
        MONTH037
        MONTH038
        MONTH039
        MONTH040
        MONTH041
        MONTH042
        MONTH043
        MONTH044
        MONTH045
        MONTH046
        MONTH047
        MONTH048
        MONTH049
        MONTH050
        MONTH051
        MONTH052
        MONTH053
        MONTH054
        MONTH055
        MONTH056
        MONTH057
        MONTH058
        MONTH059
        MONTH060
        MONTH061
        MONTH062
        MONTH063
        MONTH064
        MONTH065
        MONTH066
        MONTH067
        MONTH068
        MONTH069
        MONTH070
        MONTH071
        MONTH072
        MONTH073
        MONTH074
        MONTH075
        MONTH076
        MONTH077
        MONTH078
        MONTH079
        MONTH080
        MONTH081
        MONTH082
        MONTH083
        MONTH084
        MONTH085
        MONTH086
        MONTH087
        MONTH088
        MONTH089
        MONTH090
        MONTH091
        MONTH092
        MONTH093
        MONTH094
        MONTH095
        MONTH096
        MONTH097
        MONTH098
        MONTH099
        MONTH100
        MONTH101
        MONTH102
        MONTH103
        MONTH104
        MONTH105
        MONTH106
        MONTH107
        MONTH108
        MONTH109
        MONTH110
        MONTH111
        MONTH112
        MONTH113
        MONTH114
        MONTH115
        MONTH116
        MONTH117
        MONTH118
        MONTH119
        MONTH120
        MONTH121
        MONTH122
        MONTH123
        MONTH124
        MONTH125
        MONTH126
        MONTH127
        MONTH128
        MONTH129
        MONTH130
        MONTH131
        MONTH132
        MONTH133
        MONTH134
        MONTH135
        MONTH136
        MONTH137
        MONTH138
        MONTH139
        MONTH140
        MONTH141
        MONTH142
        MONTH143
        MONTH144
        MONTH145
        MONTH146
        MONTH147
        MONTH148
        MONTH149
        MONTH150
        MONTH151
        MONTH152
        MONTH153
        MONTH154
        MONTH155
        MONTH156
        MONTH157
        MONTH158
        MONTH159
        MONTH160
        MONTH161
        MONTH162
        MONTH163
        MONTH164
        MONTH165
        MONTH166
        MONTH167
        MONTH168
        MONTH169
        MONTH170
        MONTH171
        MONTH172
        MONTH173
        MONTH174
        MONTH175
        MONTH176
        MONTH177
        MONTH178
        MONTH179
        MONTH180
        MONTH181
        MONTH182
        MONTH183
        MONTH184
        MONTH185
        MONTH186
        MONTH187
        MONTH188
        MONTH189
        MONTH190
        MONTH191
        MONTH192
        MONTH193
        MONTH194
        MONTH195
        MONTH196
        MONTH197
        MONTH198
        MONTH199
        MONTH200
        MONTH201
        MONTH202
        MONTH203
        MONTH204
        MONTH205
        MONTH206
        MONTH207
        MONTH208
        MONTH209
        MONTH210
        MONTH211
        MONTH212
        MONTH213
        MONTH214
        MONTH215
        MONTH216
        MONTH217
        MONTH218
        MONTH219
        MONTH220
        MONTH221
        MONTH222
        MONTH223
        MONTH224
        MONTH225
        MONTH226
        MONTH227
        MONTH228
        MONTH229
        MONTH230
        MONTH231
        MONTH232
        MONTH233
        MONTH234
        MONTH235
        MONTH236
        MONTH237
        MONTH238
        MONTH239
        MONTH240
    End Enum

#End Region

#Region "Inner Class"


    '取得結果(ELAデータ)
    Private Class ElaExcelDataTable
        Inherits DataTable

        Public Sub New()

            Me.TableName = "ElaExcelDataTable"

            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.DATA_NO1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.DATA_NO3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.DATA_NO8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.SVC_START, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.SVC_END, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.INST_YM, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.PAY_START_YM, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.PAY_END_YM, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.PAY_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.PAY_METHOD, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.LIST_PRICE_PROPOSAL, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.LIST_PRICE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.OFFERING_PRICE, Type.GetType("System.String"))

            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH001, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH002, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH003, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH004, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH005, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH006, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH007, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH008, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH009, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH010, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH011, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH012, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH013, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH014, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH015, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH016, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH017, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH018, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH019, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH020, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH021, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH022, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH023, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH024, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH025, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH026, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH027, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH028, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH029, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH030, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH031, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH032, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH033, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH034, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH035, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH036, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH037, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH038, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH039, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH040, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH041, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH042, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH043, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH044, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH045, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH046, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH047, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH048, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH049, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH050, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH051, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH052, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH053, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH054, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH055, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH056, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH057, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH058, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH059, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH060, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH061, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH062, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH063, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH064, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH065, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH066, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH067, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH068, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH069, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH070, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH071, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH072, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH073, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH074, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH075, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH076, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH077, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH078, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH079, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH080, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH081, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH082, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH083, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH084, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH085, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH086, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH087, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH088, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH089, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH090, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH091, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH092, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH093, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH094, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH095, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH096, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH097, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH098, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH099, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH100, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH101, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH102, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH103, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH104, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH105, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH106, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH107, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH108, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH109, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH110, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH111, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH112, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH113, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH114, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH115, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH116, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH117, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH118, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH119, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH120, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH121, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH122, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH123, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH124, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH125, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH126, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH127, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH128, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH129, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH130, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH131, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH132, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH133, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH134, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH135, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH136, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH137, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH138, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH139, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH140, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH141, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH142, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH143, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH144, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH145, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH146, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH147, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH148, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH149, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH150, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH151, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH152, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH153, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH154, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH155, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH156, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH157, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH158, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH159, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH160, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH161, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH162, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH163, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH164, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH165, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH166, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH167, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH168, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH169, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH170, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH171, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH172, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH173, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH174, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH175, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH176, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH177, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH178, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH179, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH180, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH181, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH182, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH183, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH184, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH185, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH186, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH187, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH188, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH189, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH190, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH191, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH192, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH193, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH194, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH195, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH196, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH197, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH198, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH199, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH200, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH201, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH202, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH203, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH204, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH205, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH206, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH207, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH208, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH209, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH210, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH211, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH212, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH213, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH214, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH215, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH216, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH217, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH218, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH219, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH220, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH221, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH222, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH223, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH224, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH225, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH226, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH227, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH228, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH229, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH230, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH231, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH232, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH233, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH234, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH235, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH236, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH237, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH238, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH239, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_ELA.MONTH240, Type.GetType("System.String"))

            Me.Columns.Add("ExcelRow", Type.GetType("System.Int32"))
        End Sub
    End Class

#End Region


#Region "Variable"
    Dim WS1PayPeriod As Integer     'WS1シートの保有年数。取込み時にDBの保有年数ではなくPSﾌｧｲﾙの保有年数を使用する。
    Dim ElaStartYear As Integer     'ELAデータシートの月額情報開始年
    Dim ElaStartMonth As Integer    'ELAデータシートの月額情報開始月
    Dim PayStartYear As Integer     'Paymentシートの月額情報開始年
#End Region


#Region "Public"

    ''' <summary>
    ''' 機能：ELAデータPayment反映処理
    ''' </summary>
    ''' <param name="strPSFileName"></param>
    ''' <param name="strELAFileName"></param>
    ''' <param name="intOutputCnt"></param>
    ''' <param name="waitDialog"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function InputEla(ByVal strPSFileName As String,
                             ByVal strELAFileName As String,
                             ByRef intOutputCnt As Integer,
                             ByRef waitDialog As Frm_WaitDialog) As Boolean

        Dim blnRet As Boolean
        Dim ElaData As ElaExcelDataTable
        Dim ew As New ExcelWrite
        Dim xlApp As New Excel.Application
        Dim xlPsBook As Excel.Workbook
        Dim xlPsSheet As Excel.Worksheet
        Dim xlWs1Sheet As Excel.Worksheet

        InputEla = False

        Try
            Debug.Print(Now.ToString("HH:mm:ss") & "　開始")
            xlApp.EnableEvents = False
            xlApp.DisplayAlerts = False

            '------------------------------------------
            'Payment読込
            '------------------------------------------
            xlPsBook = xlApp.Workbooks.Open(strPSFileName)
            xlPsSheet = xlPsBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)

            'WS1シートの保有年数取得  　※cpno/strYearの戻り値は不要なのでdummyの変数を宣言
            Dim dummyCpno, rtnMsg As String
            Dim dummyYear As Integer
            xlWs1Sheet = xlPsBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_WS1)
            rtnMsg = ExcelWrite.GetWS1PayPeriod(strPSFileName, dummyCpno, dummyYear, Me.WS1PayPeriod)
            If rtnMsg <> "" Then Throw New Exception(rtnMsg)

            'Excelのオートフィルタを初期化
            Call ew.CrearAutoFilter(xlPsSheet)

            '------------------------------------------
            'Elaデータファイル読込
            '------------------------------------------
            blnRet = GetElaData(strELAFileName, xlApp, ElaData, intOutputCnt)
            If blnRet = False Then
                Exit Function
            ElseIf intOutputCnt = 0 Then
                InputEla = True
                Exit Function
            End If
            waitDialog.PerformStep()

            '------------------------------------------
            'Payment出力
            '------------------------------------------
            blnRet = ElaReflection(strELAFileName, ElaData, xlPsSheet)
            If blnRet = False Then
                Exit Function
            End If
            ExcelObjRelease.ReleaseExcelObj(xlPsSheet, ExcelObjRelease.OBJECT_NOTHING)
            waitDialog.PerformStep()

            'Bookの保存(別名保存のマクロをキックする)
            '※VBActNMListに統合
            Call ExcelWrite.KickVBABookSave(xlApp, xlPsBook, ExcelWrite.VBActNMList.ELA, CommonVariable.USERID, CommonVariable.USERPW)

            Debug.Print(Now.ToString("HH:mm:ss") & "　終了")

            InputEla = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "InputEla")

        Finally
            'エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlWs1Sheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPsSheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlPsBook) = False Then
                xlPsBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlPsBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPsBook, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try

    End Function

#End Region

#Region "Private"


#Region "読込関連"

    ''' <summary>
    ''' 機能：Elaデータファイル読込
    ''' </summary>
    ''' <param name="strElaFileName"></param>
    ''' <param name="xlApp"></param>
    ''' <param name="ElaData"></param>
    ''' <param name="intOutputCnt"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetElaData(ByVal strElaFileName As String,
                                  ByVal xlApp As Excel.Application,
                                  ByRef ElaData As ElaExcelDataTable,
                                  ByRef intOutputCnt As Integer) As Boolean

        Dim ew As New ExcelWrite
        Dim intRowCnt As Integer
        Dim intColCnt As Integer
        Dim strRange As String

        Dim xlBook As Excel.Workbook
        Dim xlSheet As Excel.Worksheet
        Dim xlRange As Excel.Range

        GetElaData = False

        Try
            xlBook = xlApp.Workbooks.Open(strElaFileName)

            '------------------------------------------
            'ﾃﾞｰﾀｼｰﾄ読込
            '------------------------------------------
            ElaData = New ElaExcelDataTable
            xlSheet = xlBook.Worksheets(ExcelWrite.EXCEL_SHEET_ELA_DATA)

            'Excelのオートフィルタを初期化
            Call ew.CrearAutoFilter(xlSheet)

            ElaStartYear = Year(xlSheet.Range("N3").Value)
            ElaStartMonth = Month(xlSheet.Range("N3").Value)

            For intRowCnt = EXCEL_ROWDATA_START_ELA_DATA To EXCEL_MAX_ROW
                strRange = "A@:IS@"
                xlRange = xlSheet.Range(strRange.Replace("@", intRowCnt.ToString))

                'EOF判定
                If ExcelWrite.changeDBNullToString(xlRange(1, EXCEL_COL_ELA.DATA_NO1).Value) = "" Then
                    Exit For
                End If

                Dim row As DataRow
                row = ElaData.NewRow
                For intColCnt = EXCEL_COL_ELA.DATA_NO1 To EXCEL_COL_ELA.MONTH240
                    row("CellNM" & intColCnt) = ExcelWrite.changeDBNullToString(xlRange(1, intColCnt).Value).Trim
                Next

                'Excelの行番号
                row("ExcelRow") = intRowCnt

                ElaData.Rows.Add(row)
            Next
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            intOutputCnt = ElaData.Rows.Count

            GetElaData = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "GetElaData")

        Finally
            'エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBook) = False Then
                xlBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()

        End Try

    End Function

    ''' <summary>
    ''' 機能：Payment出力
    ''' </summary>
    ''' <param name="strElaFileName"></param>
    ''' <param name="ElaData"></param>
    ''' <param name="xlSheet"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ElaReflection(ByVal strElaFileName As String,
                                     ByVal ElaData As ElaExcelDataTable,
                                     ByRef xlSheet As Excel.Worksheet) As Boolean

        Dim blnRet As Boolean
        Dim xlCell As Excel.Range = Nothing

        ElaReflection = False

        Try

            '------------------------------------------
            '追加行作成
            '------------------------------------------
            blnRet = AddPaymentLine(strElaFileName, ElaData, xlSheet)
            If blnRet = False Then
                Exit Function
            End If

            ElaReflection = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "AddPaymentLine")

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

        End Try

    End Function

    ''' <summary>
    ''' 機能：追加行作成
    ''' </summary>
    ''' <param name="strElaFileName"></param>
    ''' <param name="ElaData"></param>
    ''' <param name="xlSheet"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function AddPaymentLine(ByVal strElaFileName As String,
                                    ByVal ElaData As ElaExcelDataTable,
                                    ByRef xlSheet As Excel.Worksheet) As Boolean

        Dim periodMonth As Integer = 12 * Me.WS1PayPeriod

        Dim COL_MAX As Integer = ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL + periodMonth
        Dim COL_TITLE As String = ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG) & "5" & ":" &
                                  ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL + periodMonth) & "5"
        Dim COL_AREA As String = ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG) & "@" & ":" &
                                    ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL + periodMonth) & "@"

        Dim intLineRow As Integer
        Dim blnRet As Boolean
        Dim objCellFormula(1, COL_MAX) As Object
        Dim objCellData(1, COL_MAX) As Object
        Dim objCellYearMonth(1, COL_MAX) As Object
        Dim strRange As String
        Dim intLineNo As Integer = 0
        Dim strWork As String
        Dim intCnt As Integer
        Dim intPsCount As Integer
        Dim strFileName As String
        Dim lngWorkLineNo As Long
        Dim xlCell As Excel.Range = Nothing
        Dim xlEntireRow As Excel.Range = Nothing
        Dim objCellLineNo(,) As Object

        AddPaymentLine = False

        Try
            '------------------------------------
            '出力位置とLINE_NO取得
            '------------------------------------
            'STATUSからNOまでのデータを取得する
            strRange = ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.CsvPaymentLineColumn.LOCK_FLAG) & ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW.ToString &
                       ":" &
                       ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.CsvPaymentLineColumn.LINE_NO) & EXCEL_MAX_ROW.ToString
            blnRet = ExcelWrite.GetCellValue(xlSheet, strRange, objCellLineNo)
            For intCnt = 1 To (EXCEL_MAX_ROW - 6)
                'NOから最終行を判定する
                strWork = ExcelWrite.changeDBNullToString(objCellLineNo(intCnt, 3))
                If strWork.Trim = "" Then
                    Exit For
                End If
                '契約済みデータは対象外
                If ExcelWrite.changeDBNullToString(objCellLineNo(intCnt, 1)) = "C" Then
                    Continue For
                End If

                If IsNumeric(strWork) = True Then
                    lngWorkLineNo = Long.Parse(strWork)
                    If intLineNo < lngWorkLineNo Then
                        intLineNo = lngWorkLineNo
                    End If
                End If
            Next
            intLineRow = intCnt - 1 + ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW
            If intLineNo = 0 Then
                intLineNo = Integer.Parse(CommonVariable.CONTRACTNO.ToString & "00000")
            End If

            '------------------------------------
            'サンプル行（２行目）コピー
            '------------------------------------
            intPsCount = ElaData.Rows.Count
            'データ行表示
            strRange = ExcelWrite.EXCEL_PAYMENTLINE_TMPROW.ToString & ":" & ExcelWrite.EXCEL_PAYMENTLINE_TMPROW.ToString
            xlCell = xlSheet.Range(strRange)
            xlEntireRow = xlCell.EntireRow
            xlEntireRow.Hidden = False
            ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)

            '罫線設定
            Const DIVISION_LINES As Integer = 1000
            Dim intSho As Integer = intPsCount \ DIVISION_LINES
            Dim intAmari As Integer = intPsCount Mod DIVISION_LINES

            For intCnt = 1 To intSho
                strRange = ExcelWrite.EXCEL_PAYMENTLINE_TMPROW.ToString & ":" & ExcelWrite.EXCEL_PAYMENTLINE_TMPROW.ToString
                xlCell = xlSheet.Range(strRange)
                xlCell.Copy()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                strRange = (intLineRow + (intCnt - 1) * DIVISION_LINES).ToString() & ":" & (intLineRow + intCnt * DIVISION_LINES - 1).ToString()
                xlCell = xlSheet.Range(strRange)
                xlCell.Insert()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            Next
            If intAmari <> 0 Then
                strRange = ExcelWrite.EXCEL_PAYMENTLINE_TMPROW.ToString & ":" & ExcelWrite.EXCEL_PAYMENTLINE_TMPROW.ToString
                xlCell = xlSheet.Range(strRange)
                xlCell.Copy()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                strRange = (intLineRow + (intSho * DIVISION_LINES)).ToString() & ":" & (intLineRow + (intSho * DIVISION_LINES + intAmari) - 1).ToString()
                xlCell = xlSheet.Range(strRange)
                xlCell.Insert()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            End If
            'データ行非表示
            strRange = ExcelWrite.EXCEL_PAYMENTLINE_TMPROW.ToString & ":" & ExcelWrite.EXCEL_PAYMENTLINE_TMPROW.ToString
            xlCell = xlSheet.Range(strRange)
            xlEntireRow = xlCell.EntireRow
            xlEntireRow.Hidden = True
            ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)

            '月額展開の年月行取得
            blnRet = ExcelWrite.GetCellValue(xlSheet, COL_TITLE, objCellYearMonth)

            strFileName = Path.GetFileName(strElaFileName)

            '------------------------------------
            'データセット
            '------------------------------------
            Debug.Print(Now.ToString("HH:mm:ss") & "　開始データセット")
            For Each rowBase As DataRow In ElaData.Select(Nothing, "ExcelRow")
                intLineNo = intLineNo + 1

                '１行取得：計算式
                strRange = (COL_AREA).Replace("@", intLineRow.ToString)
                blnRet = GetCellFormula(xlSheet, strRange, objCellData)

                'データセット
                '有効無効
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG) = "X"
                'NO
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.LINE_NO) = intLineNo.ToString
                'ﾌｧｲﾙ名
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.FILE_NAME) = strFileName
                '契約順番
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.CONTRACT) = CommonVariable.CONTRACTNO
                '価格承認申請
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.ST_APPROVAL) = ""
                'BU
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.BU) = "SWG"
                'Brand
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.BRAND) = "ESW"
                'ﾊﾟﾀｰﾝNO
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD) = "33"
                'ﾊﾟﾀｰﾝ名称
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PATTERN) = "ｵﾌｧﾘﾝｸﾞSW(SRO/ESSO/ELA)"
                '項目1
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01) = GetDbData(rowBase, EXCEL_COL_ELA.DATA_NO1)
                '項目3
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03) = GetDbData(rowBase, EXCEL_COL_ELA.DATA_NO3)
                '項目8
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM08) = GetDbData(rowBase, EXCEL_COL_ELA.DATA_NO8)
                '項目10
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10) = strFileName

                '項目11
                strWork = GetDbData(rowBase, EXCEL_COL_ELA.SVC_START)
                If IsDate(strWork) = True Then
                    strWork = Date.Parse(strWork).ToString("yyyy/MM/dd")
                End If
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11) = strWork

                '項目12
                strWork = GetDbData(rowBase, EXCEL_COL_ELA.SVC_END)
                If IsDate(strWork) = True Then
                    strWork = Date.Parse(strWork).ToString("yyyy/MM/dd")
                End If
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12) = strWork

                '数量
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.QTY) = 1
                '出荷年月
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.INST_DATE) = GetDbData(rowBase, EXCEL_COL_ELA.INST_YM)
                '元本計算開始年月
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE) = GetDbData(rowBase, EXCEL_COL_ELA.PAY_START_YM)
                '元本計算終了年月
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE) = GetDbData(rowBase, EXCEL_COL_ELA.PAY_END_YM)
                'Payment展開
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_FLAG) = GetDbData(rowBase, EXCEL_COL_ELA.PAY_FLAG)
                '支払方法
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD) = GetDbData(rowBase, EXCEL_COL_ELA.PAY_METHOD)
                'Listprice単価(提案時)
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL) = GetDbData(rowBase, EXCEL_COL_ELA.LIST_PRICE_PROPOSAL)
                'Listprice単価(ﾘﾌﾚｯｼｭ)
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH) = GetDbData(rowBase, EXCEL_COL_ELA.LIST_PRICE)
                'Offering Price単価
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC) = GetDbData(rowBase, EXCEL_COL_ELA.OFFERING_PRICE)


                ''月額Payment
                Dim i As Integer
                Dim idx As Integer

                Dim CalPayst As Integer
                Dim CalPayed As Integer
                Dim CalEla As Integer

                Dim SetStart As Integer
                Dim SetEnd As Integer

                ''Paymentの設定範囲を計算
                PayStartYear = xlSheet.Range(ExcelWrite.EXCEL_COL_PAYMENT_START_YEAR).Value

                CalPayst = (PayStartYear - 2000) * 12 + 1
                CalPayed = (PayStartYear + Me.WS1PayPeriod - 1 - 2000) * 12 + 1
                CalEla = (ElaStartYear - 2000) * 12 + ElaStartMonth

                SetStart = CalEla - CalPayst
                SetEnd = CalPayed - CalEla

                idx = 0
                If GetDbData(rowBase, EXCEL_COL_ELA.PAY_FLAG) = "変則" And _
                    SetStart > 0 And _
                    SetStart < SetEnd Then
                    For i = SetStart To SetEnd
                        objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1 + i) = GetDbData(rowBase, EXCEL_COL_ELA.MONTH001 + idx)
                        idx = idx + 1
                    Next i
                End If

                strRange = (COL_AREA).Replace("@", intLineRow.ToString)
                xlCell = xlSheet.Range(strRange)
                xlCell.Value = objCellData
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

                intLineRow = intLineRow + 1
            Next
            Debug.Print(Now.ToString("HH:mm:ss") & "　終了時データセット")

            AddPaymentLine = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "AddPaymentLine")

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

        End Try

    End Function

    ''' <summary>
    ''' 機能：データテーブルのデータ取得
    ''' </summary>
    ''' <param name="dr"></param>
    ''' <param name="intFieldNo"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetDbData(ByVal dr As DataRow, ByVal intFieldNo As Integer) As String

        GetDbData = ""

        Try
            GetDbData = ExcelWrite.changeDBNullToString(dr("CellNM" & intFieldNo.ToString))

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "GetDbData")

        End Try

    End Function

    ''' <summary>
    ''' 機　能：セル式取得
    ''' </summary>
    ''' <param name="xlSheet"></param>
    ''' <param name="strRange"></param>
    ''' <param name="ExcelFormula"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetCellFormula(ByVal xlSheet As Excel.Worksheet, ByVal strRange As String, ByRef ExcelFormula(,) As Object) As Boolean

        Dim xlCell As Excel.Range = Nothing

        GetCellFormula = False

        Try
            xlCell = xlSheet.Range(strRange)
            ExcelFormula = xlCell.Formula

            GetCellFormula = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "GetCellFormula")

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Function

#End Region

#End Region

End Class
