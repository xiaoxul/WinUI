﻿Imports System.IO
Imports System.Text
Imports Microsoft.Office.Interop
Imports System.Data.OleDb
Imports MUSE.Utility
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.OioBamaCommmon
Imports MUSE.Utility.UserMessageBox
Imports MUSE.WinUI.OioBamaCommmon
Imports MUSE.DataAccess.OleDb
Imports MUSE.Utility.UserDataTable.Master

Public Class NewExcelIGF

#Region "定数"

    '==============================
    'EXCEL行位置
    '==============================
    'PaymentLine データ開始行
    Private Const EXCEL_PAYMENTLINEDATE_OUTROW As Integer = 6

    'IGFの出力開始行
    Private Const EXCEL_IGFDATA_OUTROW As Integer = 10

    'EXCELの最終行
    Private Const EXCEL_MAX_ROW As Integer = 65536

    ''IGFファイルシート名
    Private Const IGFSHEETNM_ORDER As String = "依頼前"
    Private Const IGFSHEETNM_RESULT As String = "依頼後"

    ''項目値
    Private Const CELLVALUE_SortNMQCOS_ON As String = "0"
    Private Const CELLVALUE_SortNMQCOS_OFF As String = "1"
    Private Const CELLVALUE_SortNMNewOrDel_DEL As String = "0"
    Private Const CELLVALUE_SortNMNewOrDel_NEW As String = "1"

    Private Const CELLVALUE_SummaryNM_Normal As String = "0"
    Private Const CELLVALUE_SummaryNM_InstDay As String = "1"
    Private Const CELLVALUE_SummaryNM_BrandInfo As String = "2"
    Private Const CELLVALUE_SummaryNM_SortNMQCOS As String = "3"
    Private Const CELLVALUE_SummaryNM_NewOrDel As String = "4"
    Private Const CELLVALUE_SummaryNM_ALLSUM As String = "5"
    Private Const CELLVALUE_SummaryNM_IGFINSROW As String = "6"
    Private Const CELLVALUE_SummaryNM_IGFDELROW As String = "7"

    ' ''集計式
    ''期間合計
    Private Const SUMMARYROW_FOMULA_SUMMARY_TERM As String = "=SUBTOTAL(9,@STR:@END)"

    ''年度金額
    Private Const SUMMARYROW_FOMULA_PRICE_YEAR As String = "=SUBTOTAL(9,@STR:@END)"

    ''月度金額
    Private Const SUMMARYROW_FOMULA_PRICE_YEAR_MONTH As String = "=SUBTOTAL(9,@STR:@END)"

    Private SUMMARYROW_FOMULA_PRICE_TO_SPLIT As String = "=Row@".Replace("Row", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.IGF_RATE))

    ''IGF作成処理の終了ステータス`
    Public Const IGFCREATE_EXITSTATE_OK As String = "正常終了"
    Public Const IGFCREATE_EXITSTATE_DATAZERO As String = "出力件数が0件"

#End Region

#Region "構造体"
    Private Structure SummaryRowFomula
        Dim ListPrice As String                 ''ListPrice
        Dim DPerAfter As String                 ''D%適用後(元本)
        Dim DPerAfterrate As String             ''D%適用後(金利含む)
        Dim IGF As String                       ''IGF金利
        Dim PRICE_CONT_TOTAL As String          ''契約期間内
        Dim PRICE_OO_CONT_TOTAL As String       ''契約期間外

        ''年度金額
        Dim PRICE_YEAR1 As String               ''年度情報1
        Dim PRICE_YEAR2 As String               ''年度情報2
        Dim PRICE_YEAR3 As String               ''年度情報3
        Dim PRICE_YEAR4 As String               ''年度情報4
        Dim PRICE_YEAR5 As String               ''年度情報5
        Dim PRICE_YEAR6 As String               ''年度情報6
        Dim PRICE_YEAR7 As String               ''年度情報7
        Dim PRICE_YEAR8 As String               ''年度情報8
        Dim PRICE_YEAR9 As String               ''年度情報9
        Dim PRICE_YEAR10 As String              ''年度情報10
        Dim PRICE_YEAR11 As String              ''年度情報11
        Dim PRICE_YEAR12 As String              ''年度情報12
        Dim PRICE_YEAR13 As String              ''年度情報13
        Dim PRICE_YEAR14 As String              ''年度情報14
        Dim PRICE_YEAR15 As String              ''年度情報15
        Dim PRICE_YEAR16 As String              ''年度情報16
        Dim PRICE_YEAR17 As String              ''年度情報17
        Dim PRICE_YEAR18 As String              ''年度情報18
        Dim PRICE_YEAR19 As String              ''年度情報19
        Dim PRICE_YEAR20 As String              ''年度情報20
        Dim PRICE_PAST_CONTRACT As String       ''年度情報20

        ''月度金額
        Dim PRICE_YEAR1_MONTH1 As String        ''年度1_月度情報1
        Dim PRICE_YEAR1_MONTH2 As String        ''年度1_月度情報2
        Dim PRICE_YEAR1_MONTH3 As String        ''年度1_月度情報3
        Dim PRICE_YEAR1_MONTH4 As String        ''年度1_月度情報4
        Dim PRICE_YEAR1_MONTH5 As String        ''年度1_月度情報5
        Dim PRICE_YEAR1_MONTH6 As String        ''年度1_月度情報6
        Dim PRICE_YEAR1_MONTH7 As String        ''年度1_月度情報7
        Dim PRICE_YEAR1_MONTH8 As String        ''年度1_月度情報8
        Dim PRICE_YEAR1_MONTH9 As String        ''年度1_月度情報9
        Dim PRICE_YEAR1_MONTH10 As String       ''年度1_月度情報10
        Dim PRICE_YEAR1_MONTH11 As String       ''年度1_月度情報11
        Dim PRICE_YEAR1_MONTH12 As String       ''年度1_月度情報12
        Dim PRICE_YEAR2_MONTH1 As String        ''年度2_月度情報1
        Dim PRICE_YEAR2_MONTH2 As String        ''年度2_月度情報2
        Dim PRICE_YEAR2_MONTH3 As String        ''年度2_月度情報3
        Dim PRICE_YEAR2_MONTH4 As String        ''年度2_月度情報4
        Dim PRICE_YEAR2_MONTH5 As String        ''年度2_月度情報5
        Dim PRICE_YEAR2_MONTH6 As String        ''年度2_月度情報6
        Dim PRICE_YEAR2_MONTH7 As String        ''年度2_月度情報7
        Dim PRICE_YEAR2_MONTH8 As String        ''年度2_月度情報8
        Dim PRICE_YEAR2_MONTH9 As String        ''年度2_月度情報9
        Dim PRICE_YEAR2_MONTH10 As String       ''年度2_月度情報10
        Dim PRICE_YEAR2_MONTH11 As String       ''年度2_月度情報11
        Dim PRICE_YEAR2_MONTH12 As String       ''年度2_月度情報12
        Dim PRICE_YEAR3_MONTH1 As String        ''年度3_月度情報1
        Dim PRICE_YEAR3_MONTH2 As String        ''年度3_月度情報2
        Dim PRICE_YEAR3_MONTH3 As String        ''年度3_月度情報3
        Dim PRICE_YEAR3_MONTH4 As String        ''年度3_月度情報4
        Dim PRICE_YEAR3_MONTH5 As String        ''年度3_月度情報5
        Dim PRICE_YEAR3_MONTH6 As String        ''年度3_月度情報6
        Dim PRICE_YEAR3_MONTH7 As String        ''年度3_月度情報7
        Dim PRICE_YEAR3_MONTH8 As String        ''年度3_月度情報8
        Dim PRICE_YEAR3_MONTH9 As String        ''年度3_月度情報9
        Dim PRICE_YEAR3_MONTH10 As String       ''年度3_月度情報10
        Dim PRICE_YEAR3_MONTH11 As String       ''年度3_月度情報11
        Dim PRICE_YEAR3_MONTH12 As String       ''年度3_月度情報12
        Dim PRICE_YEAR4_MONTH1 As String        ''年度4_月度情報1
        Dim PRICE_YEAR4_MONTH2 As String        ''年度4_月度情報2
        Dim PRICE_YEAR4_MONTH3 As String        ''年度4_月度情報3
        Dim PRICE_YEAR4_MONTH4 As String        ''年度4_月度情報4
        Dim PRICE_YEAR4_MONTH5 As String        ''年度4_月度情報5
        Dim PRICE_YEAR4_MONTH6 As String        ''年度4_月度情報6
        Dim PRICE_YEAR4_MONTH7 As String        ''年度4_月度情報7
        Dim PRICE_YEAR4_MONTH8 As String        ''年度4_月度情報8
        Dim PRICE_YEAR4_MONTH9 As String        ''年度4_月度情報9
        Dim PRICE_YEAR4_MONTH10 As String       ''年度4_月度情報10
        Dim PRICE_YEAR4_MONTH11 As String       ''年度4_月度情報11
        Dim PRICE_YEAR4_MONTH12 As String       ''年度4_月度情報12
        Dim PRICE_YEAR5_MONTH1 As String        ''年度5_月度情報1
        Dim PRICE_YEAR5_MONTH2 As String        ''年度5_月度情報2
        Dim PRICE_YEAR5_MONTH3 As String        ''年度5_月度情報3
        Dim PRICE_YEAR5_MONTH4 As String        ''年度5_月度情報4
        Dim PRICE_YEAR5_MONTH5 As String        ''年度5_月度情報5
        Dim PRICE_YEAR5_MONTH6 As String        ''年度5_月度情報6
        Dim PRICE_YEAR5_MONTH7 As String        ''年度5_月度情報7
        Dim PRICE_YEAR5_MONTH8 As String        ''年度5_月度情報8
        Dim PRICE_YEAR5_MONTH9 As String        ''年度5_月度情報9
        Dim PRICE_YEAR5_MONTH10 As String       ''年度5_月度情報10
        Dim PRICE_YEAR5_MONTH11 As String       ''年度5_月度情報11
        Dim PRICE_YEAR5_MONTH12 As String       ''年度5_月度情報12
        Dim PRICE_YEAR6_MONTH1 As String        ''年度6_月度情報1
        Dim PRICE_YEAR6_MONTH2 As String        ''年度6_月度情報2
        Dim PRICE_YEAR6_MONTH3 As String        ''年度6_月度情報3
        Dim PRICE_YEAR6_MONTH4 As String        ''年度6_月度情報4
        Dim PRICE_YEAR6_MONTH5 As String        ''年度6_月度情報5
        Dim PRICE_YEAR6_MONTH6 As String        ''年度6_月度情報6
        Dim PRICE_YEAR6_MONTH7 As String        ''年度6_月度情報7
        Dim PRICE_YEAR6_MONTH8 As String        ''年度6_月度情報8
        Dim PRICE_YEAR6_MONTH9 As String        ''年度6_月度情報9
        Dim PRICE_YEAR6_MONTH10 As String       ''年度6_月度情報10
        Dim PRICE_YEAR6_MONTH11 As String       ''年度6_月度情報11
        Dim PRICE_YEAR6_MONTH12 As String       ''年度6_月度情報12
        Dim PRICE_YEAR7_MONTH1 As String        ''年度7_月度情報1
        Dim PRICE_YEAR7_MONTH2 As String        ''年度7_月度情報2
        Dim PRICE_YEAR7_MONTH3 As String        ''年度7_月度情報3
        Dim PRICE_YEAR7_MONTH4 As String        ''年度7_月度情報4
        Dim PRICE_YEAR7_MONTH5 As String        ''年度7_月度情報5
        Dim PRICE_YEAR7_MONTH6 As String        ''年度7_月度情報6
        Dim PRICE_YEAR7_MONTH7 As String        ''年度7_月度情報7
        Dim PRICE_YEAR7_MONTH8 As String        ''年度7_月度情報8
        Dim PRICE_YEAR7_MONTH9 As String        ''年度7_月度情報9
        Dim PRICE_YEAR7_MONTH10 As String       ''年度7_月度情報10
        Dim PRICE_YEAR7_MONTH11 As String       ''年度7_月度情報11
        Dim PRICE_YEAR7_MONTH12 As String       ''年度7_月度情報12
        Dim PRICE_YEAR8_MONTH1 As String        ''年度8_月度情報1
        Dim PRICE_YEAR8_MONTH2 As String        ''年度8_月度情報2
        Dim PRICE_YEAR8_MONTH3 As String        ''年度8_月度情報3
        Dim PRICE_YEAR8_MONTH4 As String        ''年度8_月度情報4
        Dim PRICE_YEAR8_MONTH5 As String        ''年度8_月度情報5
        Dim PRICE_YEAR8_MONTH6 As String        ''年度8_月度情報6
        Dim PRICE_YEAR8_MONTH7 As String        ''年度8_月度情報7
        Dim PRICE_YEAR8_MONTH8 As String        ''年度8_月度情報8
        Dim PRICE_YEAR8_MONTH9 As String        ''年度8_月度情報9
        Dim PRICE_YEAR8_MONTH10 As String       ''年度8_月度情報10
        Dim PRICE_YEAR8_MONTH11 As String       ''年度8_月度情報11
        Dim PRICE_YEAR8_MONTH12 As String       ''年度8_月度情報12
        Dim PRICE_YEAR9_MONTH1 As String        ''年度9_月度情報1
        Dim PRICE_YEAR9_MONTH2 As String        ''年度9_月度情報2
        Dim PRICE_YEAR9_MONTH3 As String        ''年度9_月度情報3
        Dim PRICE_YEAR9_MONTH4 As String        ''年度9_月度情報4
        Dim PRICE_YEAR9_MONTH5 As String        ''年度9_月度情報5
        Dim PRICE_YEAR9_MONTH6 As String        ''年度9_月度情報6
        Dim PRICE_YEAR9_MONTH7 As String        ''年度9_月度情報7
        Dim PRICE_YEAR9_MONTH8 As String        ''年度9_月度情報8
        Dim PRICE_YEAR9_MONTH9 As String        ''年度9_月度情報9
        Dim PRICE_YEAR9_MONTH10 As String       ''年度9_月度情報10
        Dim PRICE_YEAR9_MONTH11 As String       ''年度9_月度情報11
        Dim PRICE_YEAR9_MONTH12 As String       ''年度9_月度情報12
        Dim PRICE_YEAR10_MONTH1 As String       ''年度10_月度情報1
        Dim PRICE_YEAR10_MONTH2 As String       ''年度10_月度情報2
        Dim PRICE_YEAR10_MONTH3 As String       ''年度10_月度情報3
        Dim PRICE_YEAR10_MONTH4 As String       ''年度10_月度情報4
        Dim PRICE_YEAR10_MONTH5 As String       ''年度10_月度情報5
        Dim PRICE_YEAR10_MONTH6 As String       ''年度10_月度情報6
        Dim PRICE_YEAR10_MONTH7 As String       ''年度10_月度情報7
        Dim PRICE_YEAR10_MONTH8 As String       ''年度10_月度情報8
        Dim PRICE_YEAR10_MONTH9 As String       ''年度10_月度情報9
        Dim PRICE_YEAR10_MONTH10 As String      ''年度10_月度情報10
        Dim PRICE_YEAR10_MONTH11 As String      ''年度10_月度情報11
        Dim PRICE_YEAR10_MONTH12 As String      ''年度10_月度情報12
        Dim PRICE_YEAR11_MONTH1 As String       ''年度11_月度情報1
        Dim PRICE_YEAR11_MONTH2 As String       ''年度11_月度情報2
        Dim PRICE_YEAR11_MONTH3 As String       ''年度11_月度情報3
        Dim PRICE_YEAR11_MONTH4 As String       ''年度11_月度情報4
        Dim PRICE_YEAR11_MONTH5 As String       ''年度11_月度情報5
        Dim PRICE_YEAR11_MONTH6 As String       ''年度11_月度情報6
        Dim PRICE_YEAR11_MONTH7 As String       ''年度11_月度情報7
        Dim PRICE_YEAR11_MONTH8 As String       ''年度11_月度情報8
        Dim PRICE_YEAR11_MONTH9 As String       ''年度11_月度情報9
        Dim PRICE_YEAR11_MONTH10 As String      ''年度11_月度情報10
        Dim PRICE_YEAR11_MONTH11 As String      ''年度11_月度情報11
        Dim PRICE_YEAR11_MONTH12 As String      ''年度11_月度情報12
        Dim PRICE_YEAR12_MONTH1 As String       ''年度12_月度情報1
        Dim PRICE_YEAR12_MONTH2 As String       ''年度12_月度情報2
        Dim PRICE_YEAR12_MONTH3 As String       ''年度12_月度情報3
        Dim PRICE_YEAR12_MONTH4 As String       ''年度12_月度情報4
        Dim PRICE_YEAR12_MONTH5 As String       ''年度12_月度情報5
        Dim PRICE_YEAR12_MONTH6 As String       ''年度12_月度情報6
        Dim PRICE_YEAR12_MONTH7 As String       ''年度12_月度情報7
        Dim PRICE_YEAR12_MONTH8 As String       ''年度12_月度情報8
        Dim PRICE_YEAR12_MONTH9 As String       ''年度12_月度情報9
        Dim PRICE_YEAR12_MONTH10 As String      ''年度12_月度情報10
        Dim PRICE_YEAR12_MONTH11 As String      ''年度12_月度情報11
        Dim PRICE_YEAR12_MONTH12 As String      ''年度12_月度情報12
        Dim PRICE_YEAR13_MONTH1 As String       ''年度13_月度情報1
        Dim PRICE_YEAR13_MONTH2 As String       ''年度13_月度情報2
        Dim PRICE_YEAR13_MONTH3 As String       ''年度13_月度情報3
        Dim PRICE_YEAR13_MONTH4 As String       ''年度13_月度情報4
        Dim PRICE_YEAR13_MONTH5 As String       ''年度13_月度情報5
        Dim PRICE_YEAR13_MONTH6 As String       ''年度13_月度情報6
        Dim PRICE_YEAR13_MONTH7 As String       ''年度13_月度情報7
        Dim PRICE_YEAR13_MONTH8 As String       ''年度13_月度情報8
        Dim PRICE_YEAR13_MONTH9 As String       ''年度13_月度情報9
        Dim PRICE_YEAR13_MONTH10 As String      ''年度13_月度情報10
        Dim PRICE_YEAR13_MONTH11 As String      ''年度13_月度情報11
        Dim PRICE_YEAR13_MONTH12 As String      ''年度13_月度情報12
        Dim PRICE_YEAR14_MONTH1 As String       ''年度14_月度情報1
        Dim PRICE_YEAR14_MONTH2 As String       ''年度14_月度情報2
        Dim PRICE_YEAR14_MONTH3 As String       ''年度14_月度情報3
        Dim PRICE_YEAR14_MONTH4 As String       ''年度14_月度情報4
        Dim PRICE_YEAR14_MONTH5 As String       ''年度14_月度情報5
        Dim PRICE_YEAR14_MONTH6 As String       ''年度14_月度情報6
        Dim PRICE_YEAR14_MONTH7 As String       ''年度14_月度情報7
        Dim PRICE_YEAR14_MONTH8 As String       ''年度14_月度情報8
        Dim PRICE_YEAR14_MONTH9 As String       ''年度14_月度情報9
        Dim PRICE_YEAR14_MONTH10 As String      ''年度14_月度情報10
        Dim PRICE_YEAR14_MONTH11 As String      ''年度14_月度情報11
        Dim PRICE_YEAR14_MONTH12 As String      ''年度14_月度情報12
        Dim PRICE_YEAR15_MONTH1 As String       ''年度15_月度情報1
        Dim PRICE_YEAR15_MONTH2 As String       ''年度15_月度情報2
        Dim PRICE_YEAR15_MONTH3 As String       ''年度15_月度情報3
        Dim PRICE_YEAR15_MONTH4 As String       ''年度15_月度情報4
        Dim PRICE_YEAR15_MONTH5 As String       ''年度15_月度情報5
        Dim PRICE_YEAR15_MONTH6 As String       ''年度15_月度情報6
        Dim PRICE_YEAR15_MONTH7 As String       ''年度15_月度情報7
        Dim PRICE_YEAR15_MONTH8 As String       ''年度15_月度情報8
        Dim PRICE_YEAR15_MONTH9 As String       ''年度15_月度情報9
        Dim PRICE_YEAR15_MONTH10 As String      ''年度15_月度情報10
        Dim PRICE_YEAR15_MONTH11 As String      ''年度15_月度情報11
        Dim PRICE_YEAR15_MONTH12 As String      ''年度15_月度情報12
        Dim PRICE_YEAR16_MONTH1 As String       ''年度16_月度情報1
        Dim PRICE_YEAR16_MONTH2 As String       ''年度16_月度情報2
        Dim PRICE_YEAR16_MONTH3 As String       ''年度16_月度情報3
        Dim PRICE_YEAR16_MONTH4 As String       ''年度16_月度情報4
        Dim PRICE_YEAR16_MONTH5 As String       ''年度16_月度情報5
        Dim PRICE_YEAR16_MONTH6 As String       ''年度16_月度情報6
        Dim PRICE_YEAR16_MONTH7 As String       ''年度16_月度情報7
        Dim PRICE_YEAR16_MONTH8 As String       ''年度16_月度情報8
        Dim PRICE_YEAR16_MONTH9 As String       ''年度16_月度情報9
        Dim PRICE_YEAR16_MONTH10 As String      ''年度16_月度情報10
        Dim PRICE_YEAR16_MONTH11 As String      ''年度16_月度情報11
        Dim PRICE_YEAR16_MONTH12 As String      ''年度16_月度情報12
        Dim PRICE_YEAR17_MONTH1 As String       ''年度17_月度情報1
        Dim PRICE_YEAR17_MONTH2 As String       ''年度17_月度情報2
        Dim PRICE_YEAR17_MONTH3 As String       ''年度17_月度情報3
        Dim PRICE_YEAR17_MONTH4 As String       ''年度17_月度情報4
        Dim PRICE_YEAR17_MONTH5 As String       ''年度17_月度情報5
        Dim PRICE_YEAR17_MONTH6 As String       ''年度17_月度情報6
        Dim PRICE_YEAR17_MONTH7 As String       ''年度17_月度情報7
        Dim PRICE_YEAR17_MONTH8 As String       ''年度17_月度情報8
        Dim PRICE_YEAR17_MONTH9 As String       ''年度17_月度情報9
        Dim PRICE_YEAR17_MONTH10 As String      ''年度17_月度情報10
        Dim PRICE_YEAR17_MONTH11 As String      ''年度17_月度情報11
        Dim PRICE_YEAR17_MONTH12 As String      ''年度17_月度情報12
        Dim PRICE_YEAR18_MONTH1 As String       ''年度18_月度情報1
        Dim PRICE_YEAR18_MONTH2 As String       ''年度18_月度情報2
        Dim PRICE_YEAR18_MONTH3 As String       ''年度18_月度情報3
        Dim PRICE_YEAR18_MONTH4 As String       ''年度18_月度情報4
        Dim PRICE_YEAR18_MONTH5 As String       ''年度18_月度情報5
        Dim PRICE_YEAR18_MONTH6 As String       ''年度18_月度情報6
        Dim PRICE_YEAR18_MONTH7 As String       ''年度18_月度情報7
        Dim PRICE_YEAR18_MONTH8 As String       ''年度18_月度情報8
        Dim PRICE_YEAR18_MONTH9 As String       ''年度18_月度情報9
        Dim PRICE_YEAR18_MONTH10 As String      ''年度18_月度情報10
        Dim PRICE_YEAR18_MONTH11 As String      ''年度18_月度情報11
        Dim PRICE_YEAR18_MONTH12 As String      ''年度18_月度情報12
        Dim PRICE_YEAR19_MONTH1 As String       ''年度19_月度情報1
        Dim PRICE_YEAR19_MONTH2 As String       ''年度19_月度情報2
        Dim PRICE_YEAR19_MONTH3 As String       ''年度19_月度情報3
        Dim PRICE_YEAR19_MONTH4 As String       ''年度19_月度情報4
        Dim PRICE_YEAR19_MONTH5 As String       ''年度19_月度情報5
        Dim PRICE_YEAR19_MONTH6 As String       ''年度19_月度情報6
        Dim PRICE_YEAR19_MONTH7 As String       ''年度19_月度情報7
        Dim PRICE_YEAR19_MONTH8 As String       ''年度19_月度情報8
        Dim PRICE_YEAR19_MONTH9 As String       ''年度19_月度情報9
        Dim PRICE_YEAR19_MONTH10 As String      ''年度19_月度情報10
        Dim PRICE_YEAR19_MONTH11 As String      ''年度19_月度情報11
        Dim PRICE_YEAR19_MONTH12 As String      ''年度19_月度情報12
        Dim PRICE_YEAR20_MONTH1 As String       ''年度20_月度情報1
        Dim PRICE_YEAR20_MONTH2 As String       ''年度20_月度情報2
        Dim PRICE_YEAR20_MONTH3 As String       ''年度20_月度情報3
        Dim PRICE_YEAR20_MONTH4 As String       ''年度20_月度情報4
        Dim PRICE_YEAR20_MONTH5 As String       ''年度20_月度情報5
        Dim PRICE_YEAR20_MONTH6 As String       ''年度20_月度情報6
        Dim PRICE_YEAR20_MONTH7 As String       ''年度20_月度情報7
        Dim PRICE_YEAR20_MONTH8 As String       ''年度20_月度情報8
        Dim PRICE_YEAR20_MONTH9 As String       ''年度20_月度情報9
        Dim PRICE_YEAR20_MONTH10 As String      ''年度20_月度情報10
        Dim PRICE_YEAR20_MONTH11 As String      ''年度20_月度情報11
        Dim PRICE_YEAR20_MONTH12 As String      ''年度20_月度情報12

    End Structure

    ''行のグループ化に使用
    Private Structure GrIndex
        Dim BrandInfo As Integer
        Dim InstDay As Integer
        Dim QCOS As Integer
        Dim NewOrDel As Integer
        Dim ALLSUM As Integer
    End Structure

    ''IGF金利行の初期日付
    Private Structure IGFDefaultDate
        Dim INST_DATE As String           ''導入年月
        Dim PAY_START_DATE As String      ''元本計算・開始年月
        Dim PAY_END_DATE As String        ''元本計算・終了年月
        Dim IGF_START_DATE As String      ''IGF計算・開始年月
        Dim IGF_END_DATE As String        ''IGF計算・終了年月              
    End Structure

#End Region

#Region "列挙体"
    ''' <summary>
    ''' This is col index type
    ''' Called by 'GetIGFColIdxMontlyEnd'
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum enmIGFColIdxType
        TypeMontlyEnd = 1
        TypeErrInfo = 2
        TypePSMontlyEnd = 3
    End Enum
#End Region

    ''ローカルで使用するDataTable定義用のインナークラスを定義
#Region "インナークラス"

    Private Class PSExcelDataTable
        Inherits DataTable

        Public Sub New()

            Me.TableName = "PSExcelDataTable"

            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.ST_COST, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.ST_APPROVAL, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROJ_ID, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT_SEQ, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.NEW_EXIST, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CUST_CATEGORY, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LETTER_PLAN_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LETTER_ACCEPT_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.ORDER_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LETTER_ID, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.ORDERCODE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BU, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.SUM_CATEGORY, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND_SUB, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.OP1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.OP2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND_SIZE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.NON_SBO, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.POSTSCRIPT, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.TOPACS_CPNO, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_FORM, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_REQ, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_CONF, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM04, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM05, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM06, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM07, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM08, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM09, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM13, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM14, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM15, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM16, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM17, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM18, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM19, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM20, Type.GetType("System.String"))
            'START 変更管理#??（1346 e-PricerValidation対応）　2016/01 sugo
            'Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM21, Type.GetType("System.String"))
            'END   変更管理#??（1346 e-PricerValidation対応）　2016/01 sugo
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM22, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM23, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM24, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.WD_ANNT_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.WD_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_CHG_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.QTY, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.INST_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_START_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_END_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BID_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_MONTHS, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_VALIDATION, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_APPLIED, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_NO, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_FORM, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_MANAGMENT, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_RATE_IOC, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_PROPOSAL, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.DP_IOC, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC, Type.GetType("System.String"))
            'START 変更管理#??（1346 e-PricerValidation対応）　2016/01 sugo
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC_VAL, Type.GetType("System.String"))
            'END   変更管理#??（1346 e-PricerValidation対応）　2016/01 sugo
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.COST_RATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.COST, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.COST_TOTAL, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.COST_INPUT_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_TO_SPLIT, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_IOC, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_TOTAL_IOC, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.COST_TOTAL_IOC, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_TOTAL_IGF, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT_IN, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT_OUT, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_DEFF_IGF, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12, Type.GetType("System.String"))

            ''集計行の作成時：PRICE_YEAR12_MONTH12のSubTotalを格納
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12 + 1, Type.GetType("System.String"))

            ''以下、ソート順
            Me.Columns.Add("SortNMNewOrDel", Type.GetType("System.String"))
            Me.Columns.Add("SortNMQCOS", Type.GetType("System.String"))
            Me.Columns.Add("SortNMInstDay", Type.GetType("System.String"))
            Me.Columns.Add("SortNMSummaryCategory", Type.GetType("System.String"))
            Me.Columns.Add("SortNMBrandInfo", Type.GetType("System.String"))
            Me.Columns.Add("SortNMFILE_NAME", Type.GetType("System.String"))
            Me.Columns.Add("SortNMFILE_NAME_SUFFIX", Type.GetType("System.String"))
            Me.Columns.Add("SortNMFILE_NAME_SUFFIX_INTR", Type.GetType("System.String"))
            Me.Columns.Add("SortNMPatternCD", Type.GetType("System.String"))
            Me.Columns.Add("SortNMExcelRow", Type.GetType("System.String"))

            ''以下、集計行の区分
            Me.Columns.Add("SummaryNM", Type.GetType("System.String"))          ''0:通常　1:小分類　2中分類 3:大分類 ・・・・・・　N：分類

            ''以下、Excel行
            Me.Columns.Add("ExcelRow", Type.GetType("System.String"))
            Me.Columns.Add("OutExcelRow", Type.GetType("System.String"))      ''出力行位置：SubTotalの計算等に使用
            Me.Columns.Add("IGF_AFTER", Type.GetType("System.String"))        ''IGF適用後
            Me.Columns.Add("IGF_RATE", Type.GetType("System.String"))         ''IGF金利

        End Sub

    End Class

    ''個別詳細.Xlsの値を格納
    Private Class DetailExcelDataTable
        Inherits DataTable

        Public Sub New()

            Me.TableName = "DetailExcelDataTable"

            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.UPDATE_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.LOCK_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.VALID_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.SEQ, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.IDENTITY_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.PROD_NO, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.PROD_NAME, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.WD_ANNT_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.WD_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.PRICE_CHG_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.MES_CATEGORY, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.MES_GROUP, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.SPECIAL_FEATURE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.QTY_INTEGER, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.LIST_PRICE_PROPOSAL, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.LIST_PRICE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.LIST_PRICE_TOTAL_PROPOSAL, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.LIST_PRICE_TOTAL, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.COST_RATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.COST, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.COST_TOTAL, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineDetailColumn.COST_INPUT_DATE, Type.GetType("System.String"))

        End Sub

    End Class

    ''IGF.xlsへの出力対象データを格納する。
    Private Class IGFDataTable
        Inherits DataTable

        Sub New()

            ''テーブル
            Me.TableName = "IGFDataTable"

            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.LOCK_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.VALID_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.LINE_NO, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.FILE_NAME, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.FILE_NAME_SUFFIX, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.FILE_NAME_SUFFIX_INTR, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.CONTRACT, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.CALCULATION, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PROJ_ID, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.CONTRACT_SEQ, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.NEW_EXIST, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.CUST_CATEGORY, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.LETTER_PLAN_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.LETTER_ACCEPT_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.ORDER_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.LETTER_ID, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.BU, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.BRAND, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.SUM_CATEGORY, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.BRAND_SUB, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.OP1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.BRAND_AP_FORM, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.BRAND_AP_REQ, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.BRAND_AP_CONF, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PATTERN_CD, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PATTERN, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PROD_ITEM01, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PROD_ITEM02, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PROD_ITEM03, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PROD_ITEM04, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PROD_ITEM05, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PROD_ORIGIN_INFO, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PROD_ITEM11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PROD_ITEM12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PROD_ITEM13, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PROD_ITEM14, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PROD_ITEM15, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PROD_ITEM16, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PROD_ITEM17, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PROD_ITEM18, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PROD_ITEM19, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PROD_ITEM20, Type.GetType("System.String"))
            'START 変更管理#??（1346 e-PricerValidation対応）　2016/01 sugo
            'Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PROD_ITEM21, Type.GetType("System.String"))
            'END   変更管理#??（1346 e-PricerValidation対応）　2016/01 sugo
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PROD_ITEM22, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PROD_ITEM23, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PROD_ITEM24, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.WD_ANNT_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.WD_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_CHG_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.QTY, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.INST_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PAY_START_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PAY_END_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PAY_MONTHS, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.BID_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PAY_METHOD, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.IGF_APPLIED, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.IGF_CONT_NO, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.IGF_CONT_FORM, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.IGF_CONT_MANAGMENT, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.ACT_START_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.IGF_START_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.IGF_END_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.IGF_MONTHS, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.IGF_RATE_IOC, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.LIST_PRICE_PROPOSAL, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.LIST_PRICE_REFLESH, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_PROPOSAL, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_REFLESH, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.DP_IOC, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_UNIT_IOC, Type.GetType("System.String"))
            'Rewq.1346 2015/12 Str
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_UNIT_IOC_VAL, Type.GetType("System.String"))
            'Rewq.1346 2015/12 End
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_QTY_IOC, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_TO_SPLIT, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_IOC, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_TOTAL_IOC, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.IGF_AFTER, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.IGF_RATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.CONTRACT_IN, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.CONTRACT_OUT, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR13, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR14, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR15, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR16, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR17, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR18, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR19, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR20, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_PAST_CONTRACT, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH12, Type.GetType("System.String"))

            ''特殊列
            ''IGFファイルのExcel行位置
            Me.Columns.Add("ExcelRow", Type.GetType("System.String"))

            ''IGFファイルの取込先位置
            Me.Columns.Add("OutPSExcelRow", Type.GetType("System.String"))

        End Sub

    End Class

#End Region

#Region "IGFファイル作成処理"

    ''' <summary>
    ''' IGFファイル作成処理
    ''' </summary>
    ''' <remarks></remarks>
    Public Function OutputExcelIGF(ByVal PSXlsPath As String, _
                                   ByVal IGFTemplatePath As String, _
                                   ByVal OutIGFFilePath As String, _
                                   ByRef exitState As String,
                                   ByRef strMsg As String) As Boolean

        ''初期化
        exitState = IGFCREATE_EXITSTATE_OK

        Dim xlApp As New Excel.Application
        Dim xlBooks As Excel.Workbooks
        Dim excelWrite As New ExcelWrite

        ''IGFファイル
        Dim xlIGFBook As Excel.Workbook
        Dim xlIGFSheets As Excel.Sheets
        Dim xlIGFResultSheet As Excel.Worksheet

        ''PaymentSheet.Xls
        Dim xlPSBook As Excel.Workbook
        Dim xlPSSheets As Excel.Sheets
        Dim xlWS1Sheet As Excel.Worksheet
        Dim xlOBAMAPSSheet As Excel.Worksheet

        Dim FindRange As Excel.Range
        Dim firstAddress As String
        Dim wSheets As Excel.Sheets
        Dim wSheet As Excel.Worksheet
        Dim wValue As String

        'START 変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
        Dim xlNames As Excel.Names
        Dim xlName As Excel.Name
        Dim xlCells As Excel.Range
        Dim xlFindCells As Excel.Range
        'END   変更管理#3?（Excel.exeの解放対応)　2017/01 sugo

        OutputExcelIGF = False

        Try
            'Payment保存期間とWS1との整合性チェック
            Dim rtnMsg As String
            Dim startDate As String     'Payment開始年
            Dim wPeriod As Integer      '保有期間

            'Payment開始年と保有年月を取得
            startDate = Format(CommonVariable.PaymentStart, "yyyy/MM/dd")
            wPeriod = CommonVariable.PaymentPeriod  'getDeploymentPeriod()

            'Payment期間チェック
            If excelWrite.chkPayPeriod(rtnMsg, _
                                       excelWrite.enmChkPayPeriodCallMethod.importIGF, _
                                       PSXlsPath, _
                                       startDate, _
                                       wPeriod) <> excelWrite.enmChkPayPeriodRtnCd.ChkOK Then
                'チェックエラー時終了
                strMsg = rtnMsg
                OutputExcelIGF = True
                exitState = IGFCREATE_EXITSTATE_DATAZERO
                Exit Function
            End If

            'Excelオブジェクトの設定
            xlApp.EnableEvents = False
            xlApp.DisplayAlerts = False
            xlBooks = xlApp.Workbooks

            ''IGFTemplate.Xlsのシートのセット
            xlIGFBook = xlBooks.Open(IGFTemplatePath)

            xlApp.ScreenUpdating = False
            xlApp.Calculation = Excel.XlCalculation.xlCalculationManual
            xlIGFSheets = xlIGFBook.Worksheets
            xlIGFResultSheet = xlIGFSheets.Item("依頼後")

            ''PaymentSheet.Xlsのシートのセット
            xlPSBook = xlBooks.Open(PSXlsPath)
            xlPSSheets = xlPSBook.Worksheets
            xlOBAMAPSSheet = xlPSSheets.Item(excelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)

            ''WS1シートをコピー
            xlWS1Sheet = xlPSSheets.Item(excelWrite.EXCEL_PAYMENTLINEDATE_WS1)

            '※シート"WS1"をそのままコピーするとExcelがフリーズするため、別名にしてからコピーするよう変更
            Dim xlWS1AltSheet As Excel.Worksheet
            'Paymentシートー内でWS1を複製
            xlWS1Sheet.Copy(Before:=xlWS1Sheet)
            '複製したシート"WS1 (2)"をIGFBookにコピー
            xlWS1AltSheet = xlPSSheets.Item(excelWrite.EXCEL_PAYMENTLINEDATE_WS1 & " (2)")
            xlWS1AltSheet.Copy(Before:=xlIGFResultSheet)
            Call DelExcelNames(xlApp)
            ExcelObjRelease.ReleaseExcelObj(xlWS1Sheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlWS1AltSheet, ExcelObjRelease.OBJECT_NOTHING)
            'コピーしたシート名"WS1 (2)"の"(2)"を除去
            Dim xlWS1AltSheet2 As Excel.Worksheet
            xlWS1AltSheet2 = xlIGFSheets.Item(excelWrite.EXCEL_PAYMENTLINEDATE_WS1 & " (2)")
            xlWS1AltSheet2.Name = excelWrite.EXCEL_PAYMENTLINEDATE_WS1      'リネーム
            ExcelObjRelease.ReleaseExcelObj(xlWS1AltSheet2, ExcelObjRelease.OBJECT_NOTHING)


            ''Excelのオートフィルタを初期化
            Call excelWrite.CrearAutoFilter(xlOBAMAPSSheet)

            ''IGFファイルの基本契約期間とExcel開始年の書き込み
            Call SetExcelStrRow(xlIGFResultSheet)

            ''個別PS.Xlsのデータを取得   
            Dim PSDateTable As PSExcelDataTable
            PSDateTable = GetPSDataTable(xlOBAMAPSSheet)

            ''出力対象データのみ取得
            Dim OutIGFDataTable As PSExcelDataTable
            OutIGFDataTable = GetOutIGFData(PSDateTable)

            ''出力対象データ0件の場合、エラーメッセージを表示させる。
            If OutIGFDataTable.Rows.Count = 0 Then
                exitState = IGFCREATE_EXITSTATE_DATAZERO
                OutputExcelIGF = True
                Exit Function
            End If

            ''データテーブルをソート
            OutIGFDataTable = SortByBrCategory(OutIGFDataTable)

            ''集計行の作成
            Call SetSummaryRow(OutIGFDataTable)

            ''集計行分をソート
            OutIGFDataTable = SortBySummaryRow(OutIGFDataTable)

            ''新規/削除行のExcel式をセット
            Call SetSummaryRowFomula(OutIGFDataTable)

            ''総合計行のExcel式をセット
            Call SetAllSumSummaryRowFomula(OutIGFDataTable)

            ''IGF金利行の作成
            Call SetIGFInterestrate(OutIGFDataTable, CommonVariable.CONTRACTNO)

            ''IGF結果ファイルにデータを出力
            Call OutIGFResultSheet(xlIGFResultSheet, OutIGFDataTable)

            '外部リンクの置換処理
            wSheets = xlIGFBook.Worksheets
            'START 変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
            For intCnt As Integer = 1 To wSheets.Count   'シート毎処理
                wSheet = wSheets.Item(intCnt)
                '外部リンクを含むセルを検索
                xlCells = wSheet.Cells
                FindRange = xlCells.Find(What:="[", _
                                         LookIn:=Excel.XlFindLookIn.xlFormulas, _
                                         LookAt:=Excel.XlLookAt.xlPart, _
                                         SearchDirection:=Excel.XlSearchDirection.xlNext, _
                                         MatchCase:=False, _
                                         MatchByte:=False, _
                                         SearchFormat:=False)
                If FindRange IsNot Nothing Then
                    firstAddress = FindRange.Address
                    Do
                        '数式を値に置き換え
                        xlFindCells = FindRange.Cells
                        wValue = xlFindCells.Value.ToString
                        xlFindCells.Formula = ""
                        xlFindCells.Value = wValue
                        ExcelObjRelease.ReleaseExcelObj(xlFindCells, ExcelObjRelease.OBJECT_NOTHING)
                        '次を検索
                        FindRange = xlCells.FindNext(FindRange)

                        If FindRange Is Nothing Then
                            Exit Do
                        Else
                            If FindRange.Address = firstAddress Then
                                Exit Do
                            End If
                        End If
                    Loop While FindRange IsNot Nothing
                End If
                ExcelObjRelease.ReleaseExcelObj(FindRange, ExcelObjRelease.OBJECT_NOTHING)
                ExcelObjRelease.ReleaseExcelObj(xlCells, ExcelObjRelease.OBJECT_NOTHING)
                ExcelObjRelease.ReleaseExcelObj(wSheet, ExcelObjRelease.OBJECT_NOTHING)
            Next
            ExcelObjRelease.ReleaseExcelObj(FindRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(wSheets, ExcelObjRelease.OBJECT_NOTHING)

            xlNames = xlIGFBook.Names
            For intCnt As Integer = xlNames.Count To 1 Step -1
                xlName = xlNames.Item(intCnt)
                xlName.Delete()
                ExcelObjRelease.ReleaseExcelObj(xlName, ExcelObjRelease.OBJECT_NOTHING)
            Next
            ExcelObjRelease.ReleaseExcelObj(xlNames, ExcelObjRelease.OBJECT_NOTHING)
            'For Each wSheet In wSheets  'シート毎処理
            '    With wSheet
            '        '外部リンクを含むセルを検索
            '        FindRange = .Cells.Find(What:="[", _
            '                                LookIn:=Excel.XlFindLookIn.xlFormulas, _
            '                                LookAt:=Excel.XlLookAt.xlPart, _
            '                                SearchDirection:=Excel.XlSearchDirection.xlNext, _
            '                                MatchCase:=False, _
            '                                MatchByte:=False, _
            '                                SearchFormat:=False)
            '        If FindRange IsNot Nothing Then
            '            firstAddress = FindRange.Address
            '            Do
            '                '数式を値に置き換え
            '                wValue = FindRange.Cells.Value.ToString
            '                FindRange.Cells.Formula = ""
            '                FindRange.Cells.Value = wValue
            '                '次を検索
            '                FindRange = .Cells.FindNext(FindRange)

            '                If FindRange Is Nothing Then
            '                    Exit Do
            '                Else
            '                    If FindRange.Address = firstAddress Then
            '                        Exit Do
            '                    End If
            '                End If
            '            Loop While FindRange IsNot Nothing
            '        End If
            '    End With
            'Next

            'For Each xlName As Excel.Name In xlIGFBook.Names
            '    xlName.Delete()
            'Next
            'END   変更管理#3?（Excel.exeの解放対応)　2017/01 sugo

            ''Bookの保存
            xlApp.Calculation = Excel.XlCalculation.xlCalculationAutomatic
            xlIGFBook.SaveAs(OutIGFFilePath)

            ''プロパティにファイル名を記載 str
            'Dim obj As Object
            'Dim fso As Object

            'fso = CreateObject("Scripting.FileSystemObject")
            'obj = GetObject(OutIGFFilePath)

            'obj.BuiltinDocumentProperties("Category") = xlIGFBook.Name
            'obj.save()

            'obj = Nothing
            'fso = Nothing

            Dim properties As Object
            properties = xlIGFBook.BuiltinDocumentProperties
            properties.Item("Category").value = xlIGFBook.Name
            xlIGFBook.Save()

            properties = Nothing
            ''プロパティにファイル名を記載 end

            OutputExcelIGF = True

        Catch ex As Exception

            strMsg = ex.Message.ToString & "(OutputExcelIGF)"

        Finally
            'START 変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
            ExcelObjRelease.ReleaseExcelObj(xlFindCells, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(FindRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlName, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlNames, ExcelObjRelease.OBJECT_NOTHING)
            'END   変更管理#3?（Excel.exeの解放対応)　2017/01 sugo

            ''IGFファイル
            ExcelObjRelease.ReleaseExcelObj(xlIGFResultSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlIGFSheets, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlIGFBook) = False Then
                xlIGFBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlIGFBook, ExcelObjRelease.OBJECT_NOTHING)

            ''PaymentSheet.Xls
            ExcelObjRelease.ReleaseExcelObj(xlWS1Sheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlOBAMAPSSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPSSheets, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlPSBook) = False Then
                xlPSBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)

            ExcelObjRelease.ReleaseExcelObj(xlBooks, ExcelObjRelease.OBJECT_NOTHING)

            ''Application
            xlApp.ScreenUpdating = True
            xlApp.DisplayAlerts = True
            xlApp.EnableEvents = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()

        End Try

    End Function

#End Region

#Region "IGFファイルPS反映処理"

    ''' <summary>
    ''' Set IGFFile payperiod 
    ''' Set by 'IGFReflection' before IGFFile open
    ''' </summary>
    ''' <remarks></remarks>
    Private m_PayPeriod As Integer


    ''' <summary>
    ''' IGFファイル読込処理
    ''' </summary>
    ''' <remarks></remarks>
    Public Function IGFReflection(ByVal IGFFilePath As String, _
                                  ByVal PSFilePath As String, _
                                  ByRef countIGFRow As Integer, _
                                  ByRef countOutputRow As Integer) As Boolean

        ''初期化
        IGFReflection = False
        countIGFRow = 0
        countOutputRow = 0

        Dim xlApp As New Excel.Application

        ''IGFファイル
        Dim xlIGFBook As Excel.Workbook
        Dim xlIGFResultSheet As Excel.Worksheet

        ''PaymentSheet.Xls
        Dim xlPSBook As Excel.Workbook
        Dim xlOBAMAPSSheet As Excel.Worksheet
        Dim xlDummySheet As Excel.Worksheet

        Dim excelWrite As New ExcelWrite

        ''セル情報
        Dim xlRange As Excel.Range

        Try
            ''Excelオブジェクトの設定
            xlApp.EnableEvents = False
            xlApp.DisplayAlerts = False

            ' Payment保有年数取得
            Dim dummyCpno, rtnMsg As String
            Dim dummyExcelStrYear As Integer
            rtnMsg = excelWrite.GetWS1PayPeriod(IGFFilePath, dummyCpno, dummyExcelStrYear, m_PayPeriod)
            If rtnMsg <> "" Then Throw New Exception(rtnMsg)

            ''IGF.Xlsのシートのセット
            xlIGFBook = xlApp.Workbooks.Open(IGFFilePath)
            xlIGFResultSheet = xlIGFBook.Worksheets("依頼後")

            ''PaymentSheet.Xlsのシートのセット
            xlPSBook = xlApp.Workbooks.Open(PSFilePath)
            xlOBAMAPSSheet = xlPSBook.Worksheets(excelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)
            xlDummySheet = xlPSBook.Worksheets(excelWrite.EXCEL_PAYMENTLINEDATE_DUMMYSHEET)

            ''※補足：チェックNGなら、呼び出し元にメッセージを返す。
            ''　　　　呼び出し元にて、メッセージの種類は警告として扱う。
            rtnMsg = ChkXlsInputErr(xlIGFResultSheet)
            If rtnMsg <> "" Then
                Throw New Exception(rtnMsg)
            End If

            ''Excelのオートフィルタを初期化
            Call ExcelWrite.CrearAutoFilter(xlOBAMAPSSheet)
            Call excelWrite.CrearAutoFilter(xlIGFResultSheet)

            ''個別PS.Xlsから不要なIGF行の削除
            Call DelIGFRow(xlOBAMAPSSheet, CommonVariable.CONTRACTNO)

            ''個別PS.Xlsのデータを取得
            Dim PSDateTable As PSExcelDataTable
            PSDateTable = GetPSDataTable(xlOBAMAPSSheet)

            ''IGF.Xlsのデータを取得
            Dim IGFDateTable As IGFDataTable
            IGFDateTable = GetIGFDataTable(xlIGFResultSheet)

            ''IGFデータから、集計行等の不要なデータを削除する。
            IGFDateTable = DelIGFSummaryRow(IGFDateTable)

            ''IGFファイルの件数を取得
            countIGFRow = IGFDateTable.Rows.Count

            ''IGF.XlsとPS.Xlsを比較し、出力対象データを取得する。
            Dim OutPSDataTable As IGFDataTable          ''Payment.Xlsに取込み成功したIGF情報
            Dim NGPSDataTable As IGFDataTable           ''Payment.Xlsに取込み失敗したIGF情報
            Call GetOutPSData(IGFDateTable, _
                              PSDateTable, _
                              OutPSDataTable, _
                              NGPSDataTable, _
                              countOutputRow)

            ''IGFのエラーメッセージ削除
            xlApp.DisplayAlerts = False
            xlRange = xlIGFResultSheet.Columns(excelWrite.IGFColumn.PRICE_FINANCE + 1)
            xlRange.Value = ""

            ''IGF未取込みデータが存在する場合、処理終了
            If countOutputRow < countIGFRow Then

                ''IGFファイルに取込失敗情報を書き込み
                Call SetNGIGFData(xlIGFResultSheet, NGPSDataTable)
                xlIGFBook.Save()

                Return False

            End If

            ''IGFBookのClose
            ExcelObjRelease.ReleaseExcelObj(xlIGFResultSheet, ExcelObjRelease.OBJECT_NOTHING)
            xlIGFBook.Close()
            ExcelObjRelease.ReleaseExcelObj(xlIGFBook, ExcelObjRelease.OBJECT_NOTHING)

            Dim Msg As String
            Call ConvertIGFData(IGFFilePath, OutPSDataTable, Msg)

            ''IGFファイルの情報をPSシートに上書き
            Call SetIGFData(xlOBAMAPSSheet, OutPSDataTable)

            ''IGF金利行の作成
            Call InsertIGFRow(xlApp, xlOBAMAPSSheet, xlDummySheet, IGFDateTable, CommonVariable.CONTRACTNO, PSDateTable.Rows.Count)

            ''Bookの保存(別名保存のマクロをキックする)
            Call excelWrite.KickVBABookSave(xlApp, xlPSBook, excelWrite.VBActNMList.IGF取込, CommonVariable.USERID, CommonVariable.USERPW)

            ''正常終了
            IGFReflection = True

        Catch ex As Exception
            Throw ex

        Finally
            'オブジェクトの解放

            ''IGFファイル
            ExcelObjRelease.ReleaseExcelObj(xlIGFResultSheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlIGFBook) = False Then
                xlIGFBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlIGFBook, ExcelObjRelease.OBJECT_NOTHING)

            ''PaymentSheet.Xls
            ExcelObjRelease.ReleaseExcelObj(xlOBAMAPSSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlDummySheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlPSBook) = False Then
                xlPSBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)

            ''Application
            xlApp.DisplayAlerts = True
            xlApp.EnableEvents = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()

        End Try

    End Function

    ''' <summary>
    ''' IGFファイルの可変月額位置を取得
    ''' </summary>
    ''' <param name="IGFColIdxType"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetIGFColIdxMonthlyEnd(ByVal IGFColIdxType As enmIGFColIdxType) As Integer

        Try
            ' 月額終了 or 取込エラー
            Select Case IGFColIdxType
                Case enmIGFColIdxType.TypeMontlyEnd
                    Return ExcelWrite.IGFColumn.PRICE_PAST_CONTRACT + (m_PayPeriod * 12)
                Case enmIGFColIdxType.TypePSMontlyEnd
                    Return ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL + (m_PayPeriod * 12)
                Case enmIGFColIdxType.TypeErrInfo
                    Return ExcelWrite.IGFColumn.PRICE_PAST_CONTRACT + (m_PayPeriod * 12) + 3
            End Select
        Catch ex As Exception
            Throw ex
        End Try

    End Function

#End Region

#Region "プライベートメソッド"

    ''' <summary>
    ''' 概 要：Payment.Xlsの情報をデータテーブルへ格納する。
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetPSDataTable(ByRef xlOBAMAPSSheet As Excel.Worksheet) As PSExcelDataTable

        Dim rtnTable As New PSExcelDataTable
        'START 変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
        Dim xlCells As Excel.Range
        'END   変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
        Dim xlRange As Excel.Range
        Dim MyArray(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12) As Object

        Try
            'START 変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
            xlCells = xlOBAMAPSSheet.Cells
            'END   変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
            For i As Integer = ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW To EXCEL_MAX_ROW

                'START 変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
                ''EOF判定
                xlRange = DirectCast(xlCells.Item(i.ToString, ExcelWrite.ExcelPaymentLineColumn.LINE_NO), Excel.Range)
                If ExcelWrite.changeDBNullToString(xlRange.Value) = "" Then
                    Exit For
                End If
                ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                'xlRange = xlOBAMAPSSheet.Range(ExcelWrite.EXCEL_PAYMENT_LINE_RANGE.Replace("@", i.ToString))

                ' ''EOF判定
                'If ExcelWrite.changeDBNullToString(xlRange(1, ExcelWrite.ExcelPaymentLineColumn.LINE_NO).Value) = "" Then
                '    Exit For
                'End If
                'END   変更管理#3?（Excel.exeの解放対応)　2017/01 sugo

                MyArray = xlOBAMAPSSheet.Range(ExcelWrite.EXCEL_PAYMENT_LINE_RANGE.Replace("@", i.ToString)).Value

                ''Paymentの値をセットする
                Dim row As DataRow
                row = rtnTable.NewRow

                For j As Integer = ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG To ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12
                    row("CellNM" & j) = ExcelWrite.changeDBNullToString(MyArray(1, j))
                Next

                ''Excelの行番号
                row("ExcelRow") = i

                ''データを追加する。
                rtnTable.Rows.Add(row)

            Next

            Return rtnTable

        Catch ex As Exception
            Throw ex

        Finally
            'START 変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
            ExcelObjRelease.ReleaseExcelObj(xlCells, ExcelObjRelease.OBJECT_NOTHING)
            'END   変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try
    End Function

    ''' <summary>
    ''' 概 要：個別詳細.Xlsの情報をデータテーブルへ格納する。
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetDetailDataTable(ByVal xlDetailSheet As Excel.Worksheet) As DetailExcelDataTable

        Dim rtnTable As New DetailExcelDataTable
        Dim xlRange As Excel.Range

        Try

            For i As Integer = EXCEL_PAYMENTLINEDATE_OUTROW To EXCEL_MAX_ROW

                xlRange = xlDetailSheet.Range(("A@:Z@").Replace("@", i))

                ''EOF判定
                If ExcelWrite.changeDBNullToString(xlRange(1, ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT).Value) = "" And
                   ExcelWrite.changeDBNullToString(xlRange(1, ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME).Value) = "" And
                   ExcelWrite.changeDBNullToString(xlRange(1, ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX).Value) = "" And
                   ExcelWrite.changeDBNullToString(xlRange(1, ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR).Value) = "" And
                   ExcelWrite.changeDBNullToString(xlRange(1, ExcelWrite.ExcelPaymentLineDetailColumn.SEQ).Value) = "" Then

                    Exit For
                End If

                ''Paymentの値をセットする
                Dim row As DataRow
                row = rtnTable.NewRow
                For j As Integer = ExcelWrite.ExcelPaymentLineDetailColumn.UPDATE_FLAG To ExcelWrite.ExcelPaymentLineDetailColumn.COST_INPUT_DATE
                    row("CellNM" & j) = ExcelWrite.changeDBNullToString(xlRange(1, j).Value)
                Next

                ''データを追加する。
                rtnTable.Rows.Add(row)

            Next

            Return rtnTable

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try
    End Function

    ''' <summary>
    ''' 概 要：Payment.Xlsのデータテーブルより、出力対象のIGFデータを取得する。
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetOutIGFData(ByVal PSDateTable As PSExcelDataTable) As PSExcelDataTable

        ''戻り値
        Dim rtnTable As New PSExcelDataTable

        Try

            ''直接入力以外
            Dim filter As New StringBuilder
            filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(""))
            filter.Append(CommonConstant.SQL_STR_AND)

            ''N行とコメント行以外
            filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG)
            filter.Append(CommonConstant.SQL_STR_NOT)
            filter.Append(CommonConstant.SQL_STR_IN)
            filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            filter.Append(StringEdit.EncloseSingleQuotation("C"))
            filter.Append(CommonConstant.STR_COMMA)
            filter.Append(StringEdit.EncloseSingleQuotation("N"))
            filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_APPLIED)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation("Y"))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD)
            filter.Append(CommonConstant.SQL_STR_NOT_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation("29"))
            filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

            ''直接入力
            filter.Append(CommonConstant.SQL_STR_OR)
            filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(""))
            filter.Append(CommonConstant.SQL_STR_AND)

            ''N行とコメント行以外
            filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG)
            filter.Append(CommonConstant.SQL_STR_NOT)
            filter.Append(CommonConstant.SQL_STR_IN)
            filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            filter.Append(StringEdit.EncloseSingleQuotation("C"))
            filter.Append(CommonConstant.STR_COMMA)
            filter.Append(StringEdit.EncloseSingleQuotation("N"))
            filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_APPLIED)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation("Y"))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation("25"))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN)
            filter.Append(CommonConstant.SQL_STR_NOT)
            filter.Append(CommonConstant.SQL_STR_LIKE)
            filter.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_IGF_INTERESTRATE & "*"))
            filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

            Dim PatternCD As String
            Dim ChangePatternCD As String
            Dim PatternNM As String
            For Each row As DataRow In PSDateTable.Select(filter.ToString)

                ''ソート順作成のために必要な情報をセット
                ''パターンCDの取得
                PatternCD = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD)
                PatternNM = row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN)
                ChangePatternCD = ExcelWrite.GetPatternCD(PatternCD, PatternNM)
                ''判定できないパターンは、最後に出力
                If ChangePatternCD = "" Then
                    ChangePatternCD = "99"
                End If

                ''①パターンCD
                row.Item("SortNMPatternCD") = ChangePatternCD

                ''②新規か削除か判断
                If IsNumeric(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.QTY)) = True AndAlso _
                   CInt(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.QTY)) < 0 Then
                    row.Item("SortNMNewOrDel") = CELLVALUE_SortNMNewOrDel_DEL
                Else
                    row.Item("SortNMNewOrDel") = CELLVALUE_SortNMNewOrDel_NEW
                End If

                ''③導入年月(ソート時に通常行を先頭にするため、先頭に0をつける)
                row.Item("SortNMInstDay") = CDate(row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.INST_DATE)).ToString("yyyyMM")

                row.Item("SummaryNM") = CELLVALUE_SummaryNM_Normal

                ''PaymentのExcel並び順
                row.Item("SortNMExcelRow") = row.Item("ExcelRow").ToString.PadLeft(8, "0")

                rtnTable.ImportRow(row)

            Next

            Return rtnTable

        Catch ex As Exception
            Throw ex
        End Try

    End Function


    ''' <summary>
    ''' 概 要：Payment.Xlsのデータテーブルより、出力対象のIGFデータを取得する。
    ''' 説 明：※HW AAS とHW MESのみ
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetHWAASIGFDate(ByRef rtnTable As IGFDataTable,
                                ByVal PSDateTable As PSExcelDataTable,
                                ByVal BaseFilter As String)

        Dim rows() As DataRow

        ''特殊フューチャーを含まないレコードの抽出
        Dim filter As New StringBuilder
        filter.Append(BaseFilter.ToString)
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD)
        filter.Append(" IN ")
        filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        filter.Append(" '1' , '2' ")
        filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.OP1)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(""))

        ''データ取得
        rows = PSDateTable.Select(filter.ToString)

        ''特殊フューチャーの金額を集計し、BOXの金額へ加算する。
        Dim Qty As Integer
        Dim DPIOC As Decimal
        Dim ListPrice As Decimal
        Dim sumListPrice As Decimal
        Dim PriceQtyIOC As Decimal
        Dim sumPriceQtyIOC As Decimal
        Dim fFeature As New StringBuilder

        For i As Integer = 0 To rows.Length - 1

            ''BOXの金額、数量をセット
            Qty = rows(i).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.QTY)
            sumListPrice = rows(i).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH)
            sumPriceQtyIOC = rows(i).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC)

            ''BOXに紐づく特殊フューチャーを取得
            fFeature.Remove(0, fFeature.Length)
            fFeature.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD)
            fFeature.Append(CommonConstant.SQL_STR_EQUAL)
            fFeature.Append(StringEdit.EncloseSingleQuotation(rows(i).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD)))
            fFeature.Append(CommonConstant.SQL_STR_AND)
            fFeature.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME)
            fFeature.Append(CommonConstant.SQL_STR_EQUAL)
            fFeature.Append(StringEdit.EncloseSingleQuotation(rows(i).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME)))
            fFeature.Append(CommonConstant.SQL_STR_AND)
            fFeature.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX)
            fFeature.Append(CommonConstant.SQL_STR_EQUAL)
            fFeature.Append(StringEdit.EncloseSingleQuotation(rows(i).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX)))
            fFeature.Append(CommonConstant.SQL_STR_AND)
            fFeature.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR)
            fFeature.Append(CommonConstant.SQL_STR_EQUAL)
            fFeature.Append(StringEdit.EncloseSingleQuotation(rows(i).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR)))
            fFeature.Append(CommonConstant.SQL_STR_AND)
            fFeature.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT)
            fFeature.Append(CommonConstant.SQL_STR_EQUAL)
            fFeature.Append(StringEdit.EncloseSingleQuotation(rows(i).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT)))
            fFeature.Append(CommonConstant.SQL_STR_AND)
            fFeature.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.OP1)
            fFeature.Append(CommonConstant.SQL_STR_NOT_EQUAL)
            fFeature.Append(StringEdit.EncloseSingleQuotation(""))

            ''特殊フューチャーの金額を集計
            For Each tempRow As DataRow In PSDateTable.Select(fFeature.ToString)
                sumListPrice = sumListPrice + tempRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH)
                sumPriceQtyIOC = sumPriceQtyIOC + tempRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC)
            Next

            ''単価、D%を算出
            ListPrice = sumListPrice / Qty
            PriceQtyIOC = sumPriceQtyIOC / Qty
            DPIOC = 1 - (sumPriceQtyIOC / sumListPrice)

            ''集計金額のセット
            ''※注意！！
            ''　IGFTableのカラム名にはIGFColumn列挙体ではなく、PaymentLineColumnを使用する。
            ''　理由：PaymentSheet.Xlsの方が項目数が多いため、後の修正のためにPaymentの情報を全て所持したいから。
            rows(i).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH) = ListPrice
            rows(i).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH) = sumListPrice
            rows(i).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.DP_IOC) = DPIOC                                ''IOC D%
            rows(i).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC) = PriceQtyIOC                  ''IOC単価
            rows(i).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC) = sumPriceQtyIOC                ''IOC合計

            ''返り値のセット
            Dim insRow As DataRow
            insRow = rtnTable.NewRow
            For j As Integer = 0 To rows(i).ItemArray.Length - 1
                insRow(j) = ExcelWrite.changeDBNullToString(rows(i).Item(j))
            Next

            rtnTable.Rows.Add(insRow)
        Next
    End Sub


    ''' <summary>
    ''' 概 要：Payment.Xlsのデータテーブルより、出力対象のIGFデータを取得する。
    ''' 説 明：※HW AAS とHW MES以外
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetOtherIGFDate(ByRef rtnTable As IGFDataTable,
                                ByVal PSDateTable As PSExcelDataTable,
                                ByVal BaseFilter As String)


        Dim rows() As DataRow

        ''HW AAS or HW MES 以外のデータを取得
        Dim filter As New StringBuilder
        filter.Append(BaseFilter.ToString)
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD)
        filter.Append(" NOT IN ")
        filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        filter.Append(" '1' , '2' ")
        filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

        ''データ取得
        rows = PSDateTable.Select(filter.ToString)

        ''返り値のセット
        Dim insRow As DataRow
        For Each row As DataRow In rows
            insRow = rtnTable.NewRow()
            For j As Integer = 0 To row.ItemArray.Length - 1
                insRow.Item(j) = ExcelWrite.changeDBNullToString(row.Item(j))
            Next

            rtnTable.Rows.Add(insRow)
        Next

    End Sub


    ''' <summary>
    ''' 概 要：Qcos製品の有無,BU+Brand,SubBrand,導入年月でソートする。
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function SortByBrCategory(ByRef OutIGFDataTable As PSExcelDataTable) As PSExcelDataTable

        For Each Row As DataRow In OutIGFDataTable.Rows
            Select Case Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BU).ToString
                Case "STG"
                    Select Case Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND).ToString
                        Case "HW"
                            Row.Item("SortNMBrandInfo") = "01"
                        Case "HW BRAND SW"
                            Row.Item("SortNMBrandInfo") = "02"
                        Case "HW BRAND SWMA"
                            Row.Item("SortNMBrandInfo") = "03"
                        Case "HW brand SVC"
                            Row.Item("SortNMBrandInfo") = "04"
                        Case Else
                            Row.Item("SortNMBrandInfo") = "05"
                    End Select
                Case "SWG"
                    Select Case Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND).ToString
                        Case "ESW"
                            Row.Item("SortNMBrandInfo") = "06"
                        Case "SW Brand SW"
                            Row.Item("SortNMBrandInfo") = "07"
                        Case "SW Brand SWMA"
                            Row.Item("SortNMBrandInfo") = "08"
                        Case "PA-Media"
                            Row.Item("SortNMBrandInfo") = "09"
                        Case "PA-License"
                            Row.Item("SortNMBrandInfo") = "10"
                        Case "PA-S&S"
                            Row.Item("SortNMBrandInfo") = "11"
                        Case "SW Brand Service"
                            Row.Item("SortNMBrandInfo") = "12"
                        Case Else
                            Row.Item("SortNMBrandInfo") = "13"
                    End Select
                Case "GTS"
                    Select Case Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND).ToString
                        Case "GTS-MTS"
                            Row.Item("SortNMBrandInfo") = "14"
                        Case "GTS-ITS"
                            Row.Item("SortNMBrandInfo") = "15"
                        Case Else
                            Row.Item("SortNMBrandInfo") = "16"
                    End Select
                Case "GBS"
                    Select Case Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND).ToString
                        Case "GBS-SVC"
                            Row.Item("SortNMBrandInfo") = "17"
                        Case Else
                            Row.Item("SortNMBrandInfo") = "18"
                    End Select
                Case "IGF"
                    Select Case Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND).ToString
                        Case "IGF(中古)"
                            Row.Item("SortNMBrandInfo") = "19"
                        Case "IGF(金利)"
                            Row.Item("SortNMBrandInfo") = "20"
                        Case Else
                            Row.Item("SortNMBrandInfo") = "21"
                    End Select
                Case "VLS"
                    Select Case Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND).ToString
                        Case "IASC"
                            Row.Item("SortNMBrandInfo") = "22"
                        Case "IASC(SPOT)"
                            Row.Item("SortNMBrandInfo") = "23"
                        Case Else
                            Row.Item("SortNMBrandInfo") = "24"
                    End Select
                Case Else
                    Row.Item("SortNMBrandInfo") = "25"
            End Select

            '規定の製品以外が名称順に並ぶよう、コードの後ろに名称を付与
            Row.Item("SortNMBrandInfo") = Row.Item("SortNMBrandInfo") &
                                          Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BU).ToString &
                                          Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND).ToString
        Next

        ''ソート実行
        Dim tempView As DataView = New DataView(OutIGFDataTable)
        Dim tempTable As DataTable
        Dim rtnTable As New PSExcelDataTable
        tempView.Sort = "SortNMNewOrDel" & " , " &
                        "SortNMBrandInfo" & CommonConstant.STR_COMMA &
                        "SortNMInstDay" & CommonConstant.STR_COMMA &
                        "SortNMExcelRow" &
                        CommonConstant.SQL_STR_ASC

        ''ソート後の値をテーブルに格納する。
        tempTable = tempView.ToTable()
        For Each row As DataRow In tempTable.Select
            rtnTable.ImportRow(row)
        Next

        Return rtnTable

    End Function

    ''' <summary>
    ''' 概 要：IGFファイル出力用の集計行をセット
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetSummaryRow(ByRef OutIGFDataTable As PSExcelDataTable)

        ''KeyBreak条件
        ''新規削除
        Dim pre_SortNMNewOrDel
        Dim now_SortNMNewOrDel

        ''導入年月
        Dim pre_SortNMInstDay
        Dim now_SortNMInstDay

        ''Brand情報
        Dim pre_SortNMBrandInfo
        Dim now_SortNMBrandInfo

        ''1行もデータが存在しなければ処理終了
        If OutIGFDataTable.Rows.Count = 0 Then
            Exit Sub
        End If

        ''集計行作成のループ
        Dim isFirst As Boolean = True
        Dim isKeyBreak As Boolean
        Dim now_row As DataRow
        Dim pre_row As DataRow
        Dim copyTable As PSExcelDataTable = OutIGFDataTable.Copy
        For Each now_row In copyTable.Rows

            isKeyBreak = False

            ''Key値セット
            now_SortNMNewOrDel = now_row.Item("SortNMNewOrDel")
            now_SortNMInstDay = now_row.Item("SortNMInstDay")
            now_SortNMBrandInfo = now_row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BU) &
                                  now_row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND)

            ''初回のみの処理
            If isFirst Then
                pre_row = now_row
                pre_SortNMNewOrDel = now_row.Item("SortNMNewOrDel")
                pre_SortNMInstDay = now_row.Item("SortNMInstDay")
                pre_SortNMBrandInfo = now_row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BU) &
                                      now_row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND)

                isFirst = False
            End If

            ''KeyBreak
            ''①新規削除
            If pre_SortNMNewOrDel <> now_SortNMNewOrDel Then

                ''集計行作成
                InsertSummaryRow(OutIGFDataTable, pre_row, CELLVALUE_SummaryNM_InstDay)
                InsertSummaryRow(OutIGFDataTable, pre_row, CELLVALUE_SummaryNM_BrandInfo)
                InsertSummaryRow(OutIGFDataTable, pre_row, CELLVALUE_SummaryNM_NewOrDel)

                ''Key値セット
                isKeyBreak = True
                pre_SortNMBrandInfo = now_row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BU) &
                                      now_row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND)
                pre_SortNMInstDay = now_row.Item("SortNMInstDay")
                pre_SortNMNewOrDel = now_row.Item("SortNMNewOrDel")

                ''セット値の更新
                pre_row = now_row
                Continue For

            End If

            ''②Burand情報
            If pre_SortNMBrandInfo <> now_SortNMBrandInfo Then

                ''集計行作成
                InsertSummaryRow(OutIGFDataTable, pre_row, CELLVALUE_SummaryNM_InstDay)
                InsertSummaryRow(OutIGFDataTable, pre_row, CELLVALUE_SummaryNM_BrandInfo)

                ''Key値セット
                isKeyBreak = True
                pre_SortNMBrandInfo = now_row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BU) &
                                      now_row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND)
                pre_SortNMInstDay = now_row.Item("SortNMInstDay")

                ''セット値の更新
                pre_row = now_row
                Continue For

            End If

            ''③導入年月
            If pre_SortNMInstDay <> now_SortNMInstDay Then

                ''集計行作成
                InsertSummaryRow(OutIGFDataTable, pre_row, CELLVALUE_SummaryNM_InstDay)

                ''Key値セット
                isKeyBreak = True
                pre_SortNMInstDay = now_row.Item("SortNMInstDay")

                ''セット値の更新
                pre_row = now_row

                Continue For

            End If

        Next

        ''最後の集計行
        InsertSummaryRow(OutIGFDataTable, now_row, CELLVALUE_SummaryNM_InstDay)
        InsertSummaryRow(OutIGFDataTable, now_row, CELLVALUE_SummaryNM_BrandInfo)
        InsertSummaryRow(OutIGFDataTable, now_row, CELLVALUE_SummaryNM_NewOrDel)
        InsertSummaryRow(OutIGFDataTable, now_row, CELLVALUE_SummaryNM_ALLSUM)

    End Sub

    ''' <summary>
    ''' 概 要：IGFファイル出力用の集計行をセット
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InsertSummaryRow(ByRef OutIGFDataTable As PSExcelDataTable, _
                                 ByVal Row As DataRow, _
                                 ByVal summaryKB As String)

        ''集計行の追加
        Dim insRow As DataRow
        insRow = OutIGFDataTable.NewRow()

        ''ソート情報のセット(共通処理)
        ''※集計行が常に最後になるように、SortNMSummaryCategory以降はALL　"Z"をセット
        insRow.Item("SortNMNewOrDel") = Row.Item("SortNMNewOrDel")
        insRow.Item("SortNMQCOS") = Row.Item("SortNMQCOS")
        insRow.Item("SortNMInstDay") = Row.Item("SortNMInstDay")
        insRow.Item("SortNMBrandInfo") = Row.Item("SortNMBrandInfo")
        insRow.Item("SortNMSummaryCategory") = "ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ"
        insRow.Item("SortNMFILE_NAME") = "ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ"
        insRow.Item("SortNMFILE_NAME_SUFFIX") = "ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ"
        insRow.Item("SortNMFILE_NAME_SUFFIX_INTR") = "ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ"

        ''集計行の文言をセット
        Select Case summaryKB

            Case CELLVALUE_SummaryNM_BrandInfo
                ''BU,Brand合計
                If Row.Item("SortNMNewOrDel") = CELLVALUE_SortNMNewOrDel_DEL Then
                    insRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO) = "削除"
                Else
                    insRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO) = "追加"
                End If
                insRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BU)
                insRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND)

                insRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT) = "合計"
                insRow.Item("SummaryNM") = CELLVALUE_SummaryNM_BrandInfo

            Case CELLVALUE_SummaryNM_InstDay
                ''導入年月合計
                If Row.Item("SortNMNewOrDel") = CELLVALUE_SortNMNewOrDel_DEL Then
                    insRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO) = "削除"
                Else
                    insRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO) = "追加"
                End If
                insRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BU)
                insRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND)

                If IsDate(Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.INST_DATE)) = True Then
                    insRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR) = CDate(Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.INST_DATE)).ToString("yyyy/MM") & " 導入"
                Else
                    insRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.INST_DATE) & " 導入"
                End If
                insRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT) = "合計"
                insRow.Item("SummaryNM") = CELLVALUE_SummaryNM_InstDay

            Case CELLVALUE_SummaryNM_SortNMQCOS
                ''QCOS合計
                If Row.Item("SortNMNewOrDel") = CELLVALUE_SortNMNewOrDel_DEL Then
                    insRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO) = "削除"
                Else
                    insRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO) = "追加"
                End If
                insRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.INST_DATE) & " 導入"
                insRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX) = "QCOS製品"
                insRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT) = "合計"
                insRow.Item("SummaryNM") = CELLVALUE_SummaryNM_SortNMQCOS

            Case CELLVALUE_SummaryNM_NewOrDel
                ''新規/削除合計
                If Row.Item("SortNMNewOrDel") = CELLVALUE_SortNMNewOrDel_DEL Then
                    insRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO) = "削除"
                Else
                    insRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO) = "追加"
                End If
                insRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT) = "合計"
                insRow.Item("SummaryNM") = CELLVALUE_SummaryNM_NewOrDel

            Case CELLVALUE_SummaryNM_ALLSUM
                ''総合計
                insRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO) = "総合計"
                insRow.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT) = "合計"
                insRow.Item("SummaryNM") = CELLVALUE_SummaryNM_ALLSUM

        End Select

        ''集計行の追加
        OutIGFDataTable.Rows.Add(insRow)

    End Sub

    ''' <summary>
    ''' 概 要：集計行を含めたデータをソートする。
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function SortBySummaryRow(ByRef OutIGFDataTable As PSExcelDataTable) As PSExcelDataTable

        ''ソート実行
        Dim tempView As DataView = New DataView(OutIGFDataTable)
        Dim tempTable As DataTable
        Dim rtnTable As New PSExcelDataTable
        tempView.Sort = "SortNMNewOrDel" & " , " &
                        "SortNMBrandInfo" & CommonConstant.STR_COMMA &
                        "SortNMInstDay" & CommonConstant.STR_COMMA &
                        "SummaryNM" & CommonConstant.STR_COMMA &
                        "SortNMExcelRow" &
                        CommonConstant.SQL_STR_ASC

        ''ソート後の値をテーブルに格納する。
        tempTable = tempView.ToTable()
        Dim index As Integer = EXCEL_IGFDATA_OUTROW - 1
        For Each row As DataRow In tempTable.Select
            index = index + 1
            row.Item("OutExcelRow") = index
            rtnTable.ImportRow(row)
        Next


        Return rtnTable

    End Function


    ''' 概　要：新規/削除の集計式の作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetSummaryRowFomula(ByRef OutIGFDataTable As PSExcelDataTable)

        ''初期化
        Dim Fomula As SummaryRowFomula
        Dim strIndex As Integer     ''SubTotalの開始位置 
        Dim EndIndex As Integer     ''SubTotalの終了位置 

        ''==========================================
        ''					削除の処理
        ''==========================================
        Dim rows() As DataRow
        Dim filterDel As New StringBuilder
        filterDel.Append("SortNMNewOrDel")
        filterDel.Append(CommonConstant.SQL_STR_EQUAL)
        filterDel.Append(StringEdit.EncloseSingleQuotation(CELLVALUE_SortNMNewOrDel_Del))
        filterDel.Append(CommonConstant.SQL_STR_AND)
        filterDel.Append("SummaryNM")
        filterDel.Append(CommonConstant.SQL_STR_EQUAL)
        filterDel.Append(StringEdit.EncloseSingleQuotation(CELLVALUE_SummaryNM_NewOrDel))

        ''データを抽出		
        rows = OutIGFDataTable.Select(filterDel.Tostring)
        If rows.length > 0 Then

            ''開始位置、終了位置をセット
            ''※削除集計行の一つ上の行が集計のEND行
            strIndex = EXCEL_IGFDATA_OUTROW
            EndIndex = CInt(OutIGFDataTable.Select(filterDel.ToString)(0).Item("OutExcelRow")) - 1

            ''デフォルト式をセット
            ''期間合計
            Fomula.ListPrice = SUMMARYROW_FOMULA_SUMMARY_TERM
            Fomula.DPerAfter = SUMMARYROW_FOMULA_SUMMARY_TERM
            Fomula.DPerAfterrate = SUMMARYROW_FOMULA_SUMMARY_TERM
            Fomula.PRICE_CONT_TOTAL = SUMMARYROW_FOMULA_SUMMARY_TERM
            Fomula.PRICE_OO_CONT_TOTAL = SUMMARYROW_FOMULA_SUMMARY_TERM
            Fomula.IGF = SUMMARYROW_FOMULA_SUMMARY_TERM

            ''年度金額
            Fomula.PRICE_YEAR1 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR2 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR3 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR4 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR5 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR6 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR7 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR8 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR9 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR10 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR11 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR12 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR13 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR14 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR15 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR16 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR17 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR18 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR19 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR20 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_PAST_CONTRACT = SUMMARYROW_FOMULA_PRICE_YEAR

            ''月度金額
            Fomula.PRICE_YEAR1_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH

            ''開始、終了位置のセット
            ''期間合計
            Fomula.ListPrice = Fomula.ListPrice.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_IOC) & strIndex)
            Fomula.ListPrice = Fomula.ListPrice.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_IOC) & EndIndex)

            Fomula.DPerAfter = Fomula.DPerAfter.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_TOTAL_IOC) & strIndex)
            Fomula.DPerAfter = Fomula.DPerAfter.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_TOTAL_IOC) & EndIndex)

            Fomula.DPerAfterrate = Fomula.DPerAfterrate.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.IGF_AFTER) & strIndex)
            Fomula.DPerAfterrate = Fomula.DPerAfterrate.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.IGF_AFTER) & EndIndex)

            Fomula.IGF = Fomula.IGF.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.IGF_RATE) & strIndex)
            Fomula.IGF = Fomula.IGF.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.IGF_RATE) & EndIndex)

            Fomula.PRICE_CONT_TOTAL = Fomula.PRICE_CONT_TOTAL.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.CONTRACT_IN) & strIndex)
            Fomula.PRICE_CONT_TOTAL = Fomula.PRICE_CONT_TOTAL.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.CONTRACT_IN) & EndIndex)

            Fomula.PRICE_OO_CONT_TOTAL = Fomula.PRICE_OO_CONT_TOTAL.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.CONTRACT_OUT) & strIndex)
            Fomula.PRICE_OO_CONT_TOTAL = Fomula.PRICE_OO_CONT_TOTAL.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.CONTRACT_OUT) & EndIndex)


            ''年度金額
            Fomula.PRICE_YEAR1 = Fomula.PRICE_YEAR1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1) & strIndex)
            Fomula.PRICE_YEAR1 = Fomula.PRICE_YEAR1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1) & EndIndex)

            Fomula.PRICE_YEAR2 = Fomula.PRICE_YEAR2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2) & strIndex)
            Fomula.PRICE_YEAR2 = Fomula.PRICE_YEAR2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2) & EndIndex)

            Fomula.PRICE_YEAR3 = Fomula.PRICE_YEAR3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3) & strIndex)
            Fomula.PRICE_YEAR3 = Fomula.PRICE_YEAR3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3) & EndIndex)

            Fomula.PRICE_YEAR4 = Fomula.PRICE_YEAR4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4) & strIndex)
            Fomula.PRICE_YEAR4 = Fomula.PRICE_YEAR4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4) & EndIndex)

            Fomula.PRICE_YEAR5 = Fomula.PRICE_YEAR5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5) & strIndex)
            Fomula.PRICE_YEAR5 = Fomula.PRICE_YEAR5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5) & EndIndex)

            Fomula.PRICE_YEAR6 = Fomula.PRICE_YEAR6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6) & strIndex)
            Fomula.PRICE_YEAR6 = Fomula.PRICE_YEAR6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6) & EndIndex)

            Fomula.PRICE_YEAR7 = Fomula.PRICE_YEAR7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7) & strIndex)
            Fomula.PRICE_YEAR7 = Fomula.PRICE_YEAR7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7) & EndIndex)

            Fomula.PRICE_YEAR8 = Fomula.PRICE_YEAR8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8) & strIndex)
            Fomula.PRICE_YEAR8 = Fomula.PRICE_YEAR8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8) & EndIndex)

            Fomula.PRICE_YEAR9 = Fomula.PRICE_YEAR9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9) & strIndex)
            Fomula.PRICE_YEAR9 = Fomula.PRICE_YEAR9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9) & EndIndex)

            Fomula.PRICE_YEAR10 = Fomula.PRICE_YEAR10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10) & strIndex)
            Fomula.PRICE_YEAR10 = Fomula.PRICE_YEAR10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10) & EndIndex)

            Fomula.PRICE_YEAR11 = Fomula.PRICE_YEAR11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11) & strIndex)
            Fomula.PRICE_YEAR11 = Fomula.PRICE_YEAR11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11) & EndIndex)

            Fomula.PRICE_YEAR12 = Fomula.PRICE_YEAR12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12) & strIndex)
            Fomula.PRICE_YEAR12 = Fomula.PRICE_YEAR12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12) & EndIndex)

            Fomula.PRICE_YEAR13 = Fomula.PRICE_YEAR13.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13) & strIndex)
            Fomula.PRICE_YEAR13 = Fomula.PRICE_YEAR13.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13) & EndIndex)

            Fomula.PRICE_YEAR14 = Fomula.PRICE_YEAR13.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14) & strIndex)
            Fomula.PRICE_YEAR14 = Fomula.PRICE_YEAR13.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14) & EndIndex)

            Fomula.PRICE_YEAR15 = Fomula.PRICE_YEAR13.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15) & strIndex)
            Fomula.PRICE_YEAR15 = Fomula.PRICE_YEAR13.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15) & EndIndex)

            Fomula.PRICE_YEAR16 = Fomula.PRICE_YEAR13.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16) & strIndex)
            Fomula.PRICE_YEAR16 = Fomula.PRICE_YEAR13.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16) & EndIndex)

            Fomula.PRICE_YEAR17 = Fomula.PRICE_YEAR13.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17) & strIndex)
            Fomula.PRICE_YEAR17 = Fomula.PRICE_YEAR13.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17) & EndIndex)

            Fomula.PRICE_YEAR18 = Fomula.PRICE_YEAR13.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18) & strIndex)
            Fomula.PRICE_YEAR18 = Fomula.PRICE_YEAR13.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18) & EndIndex)

            Fomula.PRICE_YEAR19 = Fomula.PRICE_YEAR13.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19) & strIndex)
            Fomula.PRICE_YEAR19 = Fomula.PRICE_YEAR13.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19) & EndIndex)

            Fomula.PRICE_YEAR20 = Fomula.PRICE_YEAR13.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20) & strIndex)
            Fomula.PRICE_YEAR20 = Fomula.PRICE_YEAR13.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20) & EndIndex)

            Fomula.PRICE_PAST_CONTRACT = Fomula.PRICE_PAST_CONTRACT.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_PAST_CONTRACT) & strIndex)
            Fomula.PRICE_PAST_CONTRACT = Fomula.PRICE_PAST_CONTRACT.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_PAST_CONTRACT) & EndIndex)

            ''月度金額
            Fomula.PRICE_YEAR1_MONTH1 = Fomula.PRICE_YEAR1_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH1) & strIndex)
            Fomula.PRICE_YEAR1_MONTH1 = Fomula.PRICE_YEAR1_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH2 = Fomula.PRICE_YEAR1_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH2) & strIndex)
            Fomula.PRICE_YEAR1_MONTH2 = Fomula.PRICE_YEAR1_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH3 = Fomula.PRICE_YEAR1_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH3) & strIndex)
            Fomula.PRICE_YEAR1_MONTH3 = Fomula.PRICE_YEAR1_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH4 = Fomula.PRICE_YEAR1_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH4) & strIndex)
            Fomula.PRICE_YEAR1_MONTH4 = Fomula.PRICE_YEAR1_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH5 = Fomula.PRICE_YEAR1_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH5) & strIndex)
            Fomula.PRICE_YEAR1_MONTH5 = Fomula.PRICE_YEAR1_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH6 = Fomula.PRICE_YEAR1_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH6) & strIndex)
            Fomula.PRICE_YEAR1_MONTH6 = Fomula.PRICE_YEAR1_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH7 = Fomula.PRICE_YEAR1_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH7) & strIndex)
            Fomula.PRICE_YEAR1_MONTH7 = Fomula.PRICE_YEAR1_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH8 = Fomula.PRICE_YEAR1_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH8) & strIndex)
            Fomula.PRICE_YEAR1_MONTH8 = Fomula.PRICE_YEAR1_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH9 = Fomula.PRICE_YEAR1_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH9) & strIndex)
            Fomula.PRICE_YEAR1_MONTH9 = Fomula.PRICE_YEAR1_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH10 = Fomula.PRICE_YEAR1_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH10) & strIndex)
            Fomula.PRICE_YEAR1_MONTH10 = Fomula.PRICE_YEAR1_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH11 = Fomula.PRICE_YEAR1_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH11) & strIndex)
            Fomula.PRICE_YEAR1_MONTH11 = Fomula.PRICE_YEAR1_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH12 = Fomula.PRICE_YEAR1_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH12) & strIndex)
            Fomula.PRICE_YEAR1_MONTH12 = Fomula.PRICE_YEAR1_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH1 = Fomula.PRICE_YEAR2_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH1) & strIndex)
            Fomula.PRICE_YEAR2_MONTH1 = Fomula.PRICE_YEAR2_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH2 = Fomula.PRICE_YEAR2_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH2) & strIndex)
            Fomula.PRICE_YEAR2_MONTH2 = Fomula.PRICE_YEAR2_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH3 = Fomula.PRICE_YEAR2_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH3) & strIndex)
            Fomula.PRICE_YEAR2_MONTH3 = Fomula.PRICE_YEAR2_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH4 = Fomula.PRICE_YEAR2_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH4) & strIndex)
            Fomula.PRICE_YEAR2_MONTH4 = Fomula.PRICE_YEAR2_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH5 = Fomula.PRICE_YEAR2_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH5) & strIndex)
            Fomula.PRICE_YEAR2_MONTH5 = Fomula.PRICE_YEAR2_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH6 = Fomula.PRICE_YEAR2_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH6) & strIndex)
            Fomula.PRICE_YEAR2_MONTH6 = Fomula.PRICE_YEAR2_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH7 = Fomula.PRICE_YEAR2_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH7) & strIndex)
            Fomula.PRICE_YEAR2_MONTH7 = Fomula.PRICE_YEAR2_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH8 = Fomula.PRICE_YEAR2_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH8) & strIndex)
            Fomula.PRICE_YEAR2_MONTH8 = Fomula.PRICE_YEAR2_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH9 = Fomula.PRICE_YEAR2_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH9) & strIndex)
            Fomula.PRICE_YEAR2_MONTH9 = Fomula.PRICE_YEAR2_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH10 = Fomula.PRICE_YEAR2_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH10) & strIndex)
            Fomula.PRICE_YEAR2_MONTH10 = Fomula.PRICE_YEAR2_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH11 = Fomula.PRICE_YEAR2_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH11) & strIndex)
            Fomula.PRICE_YEAR2_MONTH11 = Fomula.PRICE_YEAR2_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH12 = Fomula.PRICE_YEAR2_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH12) & strIndex)
            Fomula.PRICE_YEAR2_MONTH12 = Fomula.PRICE_YEAR2_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH1 = Fomula.PRICE_YEAR3_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH1) & strIndex)
            Fomula.PRICE_YEAR3_MONTH1 = Fomula.PRICE_YEAR3_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH2 = Fomula.PRICE_YEAR3_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH2) & strIndex)
            Fomula.PRICE_YEAR3_MONTH2 = Fomula.PRICE_YEAR3_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH3 = Fomula.PRICE_YEAR3_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH3) & strIndex)
            Fomula.PRICE_YEAR3_MONTH3 = Fomula.PRICE_YEAR3_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH4 = Fomula.PRICE_YEAR3_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH4) & strIndex)
            Fomula.PRICE_YEAR3_MONTH4 = Fomula.PRICE_YEAR3_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH5 = Fomula.PRICE_YEAR3_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH5) & strIndex)
            Fomula.PRICE_YEAR3_MONTH5 = Fomula.PRICE_YEAR3_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH6 = Fomula.PRICE_YEAR3_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH6) & strIndex)
            Fomula.PRICE_YEAR3_MONTH6 = Fomula.PRICE_YEAR3_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH7 = Fomula.PRICE_YEAR3_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH7) & strIndex)
            Fomula.PRICE_YEAR3_MONTH7 = Fomula.PRICE_YEAR3_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH8 = Fomula.PRICE_YEAR3_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH8) & strIndex)
            Fomula.PRICE_YEAR3_MONTH8 = Fomula.PRICE_YEAR3_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH9 = Fomula.PRICE_YEAR3_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH9) & strIndex)
            Fomula.PRICE_YEAR3_MONTH9 = Fomula.PRICE_YEAR3_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH10 = Fomula.PRICE_YEAR3_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH10) & strIndex)
            Fomula.PRICE_YEAR3_MONTH10 = Fomula.PRICE_YEAR3_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH11 = Fomula.PRICE_YEAR3_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH11) & strIndex)
            Fomula.PRICE_YEAR3_MONTH11 = Fomula.PRICE_YEAR3_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH12 = Fomula.PRICE_YEAR3_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH12) & strIndex)
            Fomula.PRICE_YEAR3_MONTH12 = Fomula.PRICE_YEAR3_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH1 = Fomula.PRICE_YEAR4_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH1) & strIndex)
            Fomula.PRICE_YEAR4_MONTH1 = Fomula.PRICE_YEAR4_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH2 = Fomula.PRICE_YEAR4_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH2) & strIndex)
            Fomula.PRICE_YEAR4_MONTH2 = Fomula.PRICE_YEAR4_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH3 = Fomula.PRICE_YEAR4_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH3) & strIndex)
            Fomula.PRICE_YEAR4_MONTH3 = Fomula.PRICE_YEAR4_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH4 = Fomula.PRICE_YEAR4_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH4) & strIndex)
            Fomula.PRICE_YEAR4_MONTH4 = Fomula.PRICE_YEAR4_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH5 = Fomula.PRICE_YEAR4_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH5) & strIndex)
            Fomula.PRICE_YEAR4_MONTH5 = Fomula.PRICE_YEAR4_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH6 = Fomula.PRICE_YEAR4_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH6) & strIndex)
            Fomula.PRICE_YEAR4_MONTH6 = Fomula.PRICE_YEAR4_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH7 = Fomula.PRICE_YEAR4_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH7) & strIndex)
            Fomula.PRICE_YEAR4_MONTH7 = Fomula.PRICE_YEAR4_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH8 = Fomula.PRICE_YEAR4_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH8) & strIndex)
            Fomula.PRICE_YEAR4_MONTH8 = Fomula.PRICE_YEAR4_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH9 = Fomula.PRICE_YEAR4_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH9) & strIndex)
            Fomula.PRICE_YEAR4_MONTH9 = Fomula.PRICE_YEAR4_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH10 = Fomula.PRICE_YEAR4_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH10) & strIndex)
            Fomula.PRICE_YEAR4_MONTH10 = Fomula.PRICE_YEAR4_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH11 = Fomula.PRICE_YEAR4_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH11) & strIndex)
            Fomula.PRICE_YEAR4_MONTH11 = Fomula.PRICE_YEAR4_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH12 = Fomula.PRICE_YEAR4_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH12) & strIndex)
            Fomula.PRICE_YEAR4_MONTH12 = Fomula.PRICE_YEAR4_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH1 = Fomula.PRICE_YEAR5_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH1) & strIndex)
            Fomula.PRICE_YEAR5_MONTH1 = Fomula.PRICE_YEAR5_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH2 = Fomula.PRICE_YEAR5_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH2) & strIndex)
            Fomula.PRICE_YEAR5_MONTH2 = Fomula.PRICE_YEAR5_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH3 = Fomula.PRICE_YEAR5_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH3) & strIndex)
            Fomula.PRICE_YEAR5_MONTH3 = Fomula.PRICE_YEAR5_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH4 = Fomula.PRICE_YEAR5_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH4) & strIndex)
            Fomula.PRICE_YEAR5_MONTH4 = Fomula.PRICE_YEAR5_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH5 = Fomula.PRICE_YEAR5_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH5) & strIndex)
            Fomula.PRICE_YEAR5_MONTH5 = Fomula.PRICE_YEAR5_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH6 = Fomula.PRICE_YEAR5_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH6) & strIndex)
            Fomula.PRICE_YEAR5_MONTH6 = Fomula.PRICE_YEAR5_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH7 = Fomula.PRICE_YEAR5_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH7) & strIndex)
            Fomula.PRICE_YEAR5_MONTH7 = Fomula.PRICE_YEAR5_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH8 = Fomula.PRICE_YEAR5_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH8) & strIndex)
            Fomula.PRICE_YEAR5_MONTH8 = Fomula.PRICE_YEAR5_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH9 = Fomula.PRICE_YEAR5_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH9) & strIndex)
            Fomula.PRICE_YEAR5_MONTH9 = Fomula.PRICE_YEAR5_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH10 = Fomula.PRICE_YEAR5_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH10) & strIndex)
            Fomula.PRICE_YEAR5_MONTH10 = Fomula.PRICE_YEAR5_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH11 = Fomula.PRICE_YEAR5_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH11) & strIndex)
            Fomula.PRICE_YEAR5_MONTH11 = Fomula.PRICE_YEAR5_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH12 = Fomula.PRICE_YEAR5_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH12) & strIndex)
            Fomula.PRICE_YEAR5_MONTH12 = Fomula.PRICE_YEAR5_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH1 = Fomula.PRICE_YEAR6_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH1) & strIndex)
            Fomula.PRICE_YEAR6_MONTH1 = Fomula.PRICE_YEAR6_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH2 = Fomula.PRICE_YEAR6_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH2) & strIndex)
            Fomula.PRICE_YEAR6_MONTH2 = Fomula.PRICE_YEAR6_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH3 = Fomula.PRICE_YEAR6_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH3) & strIndex)
            Fomula.PRICE_YEAR6_MONTH3 = Fomula.PRICE_YEAR6_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH4 = Fomula.PRICE_YEAR6_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH4) & strIndex)
            Fomula.PRICE_YEAR6_MONTH4 = Fomula.PRICE_YEAR6_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH5 = Fomula.PRICE_YEAR6_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH5) & strIndex)
            Fomula.PRICE_YEAR6_MONTH5 = Fomula.PRICE_YEAR6_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH6 = Fomula.PRICE_YEAR6_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH6) & strIndex)
            Fomula.PRICE_YEAR6_MONTH6 = Fomula.PRICE_YEAR6_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH7 = Fomula.PRICE_YEAR6_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH7) & strIndex)
            Fomula.PRICE_YEAR6_MONTH7 = Fomula.PRICE_YEAR6_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH8 = Fomula.PRICE_YEAR6_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH8) & strIndex)
            Fomula.PRICE_YEAR6_MONTH8 = Fomula.PRICE_YEAR6_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH9 = Fomula.PRICE_YEAR6_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH9) & strIndex)
            Fomula.PRICE_YEAR6_MONTH9 = Fomula.PRICE_YEAR6_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH10 = Fomula.PRICE_YEAR6_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH10) & strIndex)
            Fomula.PRICE_YEAR6_MONTH10 = Fomula.PRICE_YEAR6_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH11 = Fomula.PRICE_YEAR6_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH11) & strIndex)
            Fomula.PRICE_YEAR6_MONTH11 = Fomula.PRICE_YEAR6_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH12 = Fomula.PRICE_YEAR6_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH12) & strIndex)
            Fomula.PRICE_YEAR6_MONTH12 = Fomula.PRICE_YEAR6_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH1 = Fomula.PRICE_YEAR7_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH1) & strIndex)
            Fomula.PRICE_YEAR7_MONTH1 = Fomula.PRICE_YEAR7_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH2 = Fomula.PRICE_YEAR7_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH2) & strIndex)
            Fomula.PRICE_YEAR7_MONTH2 = Fomula.PRICE_YEAR7_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH3 = Fomula.PRICE_YEAR7_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH3) & strIndex)
            Fomula.PRICE_YEAR7_MONTH3 = Fomula.PRICE_YEAR7_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH4 = Fomula.PRICE_YEAR7_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH4) & strIndex)
            Fomula.PRICE_YEAR7_MONTH4 = Fomula.PRICE_YEAR7_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH5 = Fomula.PRICE_YEAR7_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH5) & strIndex)
            Fomula.PRICE_YEAR7_MONTH5 = Fomula.PRICE_YEAR7_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH6 = Fomula.PRICE_YEAR7_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH6) & strIndex)
            Fomula.PRICE_YEAR7_MONTH6 = Fomula.PRICE_YEAR7_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH7 = Fomula.PRICE_YEAR7_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH7) & strIndex)
            Fomula.PRICE_YEAR7_MONTH7 = Fomula.PRICE_YEAR7_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH8 = Fomula.PRICE_YEAR7_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH8) & strIndex)
            Fomula.PRICE_YEAR7_MONTH8 = Fomula.PRICE_YEAR7_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH9 = Fomula.PRICE_YEAR7_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH9) & strIndex)
            Fomula.PRICE_YEAR7_MONTH9 = Fomula.PRICE_YEAR7_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH10 = Fomula.PRICE_YEAR7_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH10) & strIndex)
            Fomula.PRICE_YEAR7_MONTH10 = Fomula.PRICE_YEAR7_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH11 = Fomula.PRICE_YEAR7_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH11) & strIndex)
            Fomula.PRICE_YEAR7_MONTH11 = Fomula.PRICE_YEAR7_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH12 = Fomula.PRICE_YEAR7_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH12) & strIndex)
            Fomula.PRICE_YEAR7_MONTH12 = Fomula.PRICE_YEAR7_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH1 = Fomula.PRICE_YEAR8_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH1) & strIndex)
            Fomula.PRICE_YEAR8_MONTH1 = Fomula.PRICE_YEAR8_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH2 = Fomula.PRICE_YEAR8_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH2) & strIndex)
            Fomula.PRICE_YEAR8_MONTH2 = Fomula.PRICE_YEAR8_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH3 = Fomula.PRICE_YEAR8_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH3) & strIndex)
            Fomula.PRICE_YEAR8_MONTH3 = Fomula.PRICE_YEAR8_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH4 = Fomula.PRICE_YEAR8_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH4) & strIndex)
            Fomula.PRICE_YEAR8_MONTH4 = Fomula.PRICE_YEAR8_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH5 = Fomula.PRICE_YEAR8_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH5) & strIndex)
            Fomula.PRICE_YEAR8_MONTH5 = Fomula.PRICE_YEAR8_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH6 = Fomula.PRICE_YEAR8_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH6) & strIndex)
            Fomula.PRICE_YEAR8_MONTH6 = Fomula.PRICE_YEAR8_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH7 = Fomula.PRICE_YEAR8_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH7) & strIndex)
            Fomula.PRICE_YEAR8_MONTH7 = Fomula.PRICE_YEAR8_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH8 = Fomula.PRICE_YEAR8_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH8) & strIndex)
            Fomula.PRICE_YEAR8_MONTH8 = Fomula.PRICE_YEAR8_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH9 = Fomula.PRICE_YEAR8_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH9) & strIndex)
            Fomula.PRICE_YEAR8_MONTH9 = Fomula.PRICE_YEAR8_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH10 = Fomula.PRICE_YEAR8_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH10) & strIndex)
            Fomula.PRICE_YEAR8_MONTH10 = Fomula.PRICE_YEAR8_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH11 = Fomula.PRICE_YEAR8_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH11) & strIndex)
            Fomula.PRICE_YEAR8_MONTH11 = Fomula.PRICE_YEAR8_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH12 = Fomula.PRICE_YEAR8_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH12) & strIndex)
            Fomula.PRICE_YEAR8_MONTH12 = Fomula.PRICE_YEAR8_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH1 = Fomula.PRICE_YEAR9_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH1) & strIndex)
            Fomula.PRICE_YEAR9_MONTH1 = Fomula.PRICE_YEAR9_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH2 = Fomula.PRICE_YEAR9_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH2) & strIndex)
            Fomula.PRICE_YEAR9_MONTH2 = Fomula.PRICE_YEAR9_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH3 = Fomula.PRICE_YEAR9_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH3) & strIndex)
            Fomula.PRICE_YEAR9_MONTH3 = Fomula.PRICE_YEAR9_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH4 = Fomula.PRICE_YEAR9_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH4) & strIndex)
            Fomula.PRICE_YEAR9_MONTH4 = Fomula.PRICE_YEAR9_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH5 = Fomula.PRICE_YEAR9_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH5) & strIndex)
            Fomula.PRICE_YEAR9_MONTH5 = Fomula.PRICE_YEAR9_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH6 = Fomula.PRICE_YEAR9_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH6) & strIndex)
            Fomula.PRICE_YEAR9_MONTH6 = Fomula.PRICE_YEAR9_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH7 = Fomula.PRICE_YEAR9_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH7) & strIndex)
            Fomula.PRICE_YEAR9_MONTH7 = Fomula.PRICE_YEAR9_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH8 = Fomula.PRICE_YEAR9_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH8) & strIndex)
            Fomula.PRICE_YEAR9_MONTH8 = Fomula.PRICE_YEAR9_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH9 = Fomula.PRICE_YEAR9_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH9) & strIndex)
            Fomula.PRICE_YEAR9_MONTH9 = Fomula.PRICE_YEAR9_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH10 = Fomula.PRICE_YEAR9_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH10) & strIndex)
            Fomula.PRICE_YEAR9_MONTH10 = Fomula.PRICE_YEAR9_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH11 = Fomula.PRICE_YEAR9_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH11) & strIndex)
            Fomula.PRICE_YEAR9_MONTH11 = Fomula.PRICE_YEAR9_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH12 = Fomula.PRICE_YEAR9_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH12) & strIndex)
            Fomula.PRICE_YEAR9_MONTH12 = Fomula.PRICE_YEAR9_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH1 = Fomula.PRICE_YEAR10_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH1) & strIndex)
            Fomula.PRICE_YEAR10_MONTH1 = Fomula.PRICE_YEAR10_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH2 = Fomula.PRICE_YEAR10_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH2) & strIndex)
            Fomula.PRICE_YEAR10_MONTH2 = Fomula.PRICE_YEAR10_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH3 = Fomula.PRICE_YEAR10_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH3) & strIndex)
            Fomula.PRICE_YEAR10_MONTH3 = Fomula.PRICE_YEAR10_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH4 = Fomula.PRICE_YEAR10_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH4) & strIndex)
            Fomula.PRICE_YEAR10_MONTH4 = Fomula.PRICE_YEAR10_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH5 = Fomula.PRICE_YEAR10_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH5) & strIndex)
            Fomula.PRICE_YEAR10_MONTH5 = Fomula.PRICE_YEAR10_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH6 = Fomula.PRICE_YEAR10_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH6) & strIndex)
            Fomula.PRICE_YEAR10_MONTH6 = Fomula.PRICE_YEAR10_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH7 = Fomula.PRICE_YEAR10_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH7) & strIndex)
            Fomula.PRICE_YEAR10_MONTH7 = Fomula.PRICE_YEAR10_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH8 = Fomula.PRICE_YEAR10_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH8) & strIndex)
            Fomula.PRICE_YEAR10_MONTH8 = Fomula.PRICE_YEAR10_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH9 = Fomula.PRICE_YEAR10_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH9) & strIndex)
            Fomula.PRICE_YEAR10_MONTH9 = Fomula.PRICE_YEAR10_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH10 = Fomula.PRICE_YEAR10_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH10) & strIndex)
            Fomula.PRICE_YEAR10_MONTH10 = Fomula.PRICE_YEAR10_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH11 = Fomula.PRICE_YEAR10_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH11) & strIndex)
            Fomula.PRICE_YEAR10_MONTH11 = Fomula.PRICE_YEAR10_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH12 = Fomula.PRICE_YEAR10_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH12) & strIndex)
            Fomula.PRICE_YEAR10_MONTH12 = Fomula.PRICE_YEAR10_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH1 = Fomula.PRICE_YEAR11_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH1) & strIndex)
            Fomula.PRICE_YEAR11_MONTH1 = Fomula.PRICE_YEAR11_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH2 = Fomula.PRICE_YEAR11_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH2) & strIndex)
            Fomula.PRICE_YEAR11_MONTH2 = Fomula.PRICE_YEAR11_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH3 = Fomula.PRICE_YEAR11_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH3) & strIndex)
            Fomula.PRICE_YEAR11_MONTH3 = Fomula.PRICE_YEAR11_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH4 = Fomula.PRICE_YEAR11_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH4) & strIndex)
            Fomula.PRICE_YEAR11_MONTH4 = Fomula.PRICE_YEAR11_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH5 = Fomula.PRICE_YEAR11_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH5) & strIndex)
            Fomula.PRICE_YEAR11_MONTH5 = Fomula.PRICE_YEAR11_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH6 = Fomula.PRICE_YEAR11_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH6) & strIndex)
            Fomula.PRICE_YEAR11_MONTH6 = Fomula.PRICE_YEAR11_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH7 = Fomula.PRICE_YEAR11_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH7) & strIndex)
            Fomula.PRICE_YEAR11_MONTH7 = Fomula.PRICE_YEAR11_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH8 = Fomula.PRICE_YEAR11_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH8) & strIndex)
            Fomula.PRICE_YEAR11_MONTH8 = Fomula.PRICE_YEAR11_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH9 = Fomula.PRICE_YEAR11_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH9) & strIndex)
            Fomula.PRICE_YEAR11_MONTH9 = Fomula.PRICE_YEAR11_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH10 = Fomula.PRICE_YEAR11_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH10) & strIndex)
            Fomula.PRICE_YEAR11_MONTH10 = Fomula.PRICE_YEAR11_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH11 = Fomula.PRICE_YEAR11_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH11) & strIndex)
            Fomula.PRICE_YEAR11_MONTH11 = Fomula.PRICE_YEAR11_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH12 = Fomula.PRICE_YEAR11_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH12) & strIndex)
            Fomula.PRICE_YEAR11_MONTH12 = Fomula.PRICE_YEAR11_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH1 = Fomula.PRICE_YEAR12_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH1) & strIndex)
            Fomula.PRICE_YEAR12_MONTH1 = Fomula.PRICE_YEAR12_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH2 = Fomula.PRICE_YEAR12_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH2) & strIndex)
            Fomula.PRICE_YEAR12_MONTH2 = Fomula.PRICE_YEAR12_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH3 = Fomula.PRICE_YEAR12_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH3) & strIndex)
            Fomula.PRICE_YEAR12_MONTH3 = Fomula.PRICE_YEAR12_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH4 = Fomula.PRICE_YEAR12_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH4) & strIndex)
            Fomula.PRICE_YEAR12_MONTH4 = Fomula.PRICE_YEAR12_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH5 = Fomula.PRICE_YEAR12_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH5) & strIndex)
            Fomula.PRICE_YEAR12_MONTH5 = Fomula.PRICE_YEAR12_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH6 = Fomula.PRICE_YEAR12_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH6) & strIndex)
            Fomula.PRICE_YEAR12_MONTH6 = Fomula.PRICE_YEAR12_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH7 = Fomula.PRICE_YEAR12_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH7) & strIndex)
            Fomula.PRICE_YEAR12_MONTH7 = Fomula.PRICE_YEAR12_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH8 = Fomula.PRICE_YEAR12_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH8) & strIndex)
            Fomula.PRICE_YEAR12_MONTH8 = Fomula.PRICE_YEAR12_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH9 = Fomula.PRICE_YEAR12_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH9) & strIndex)
            Fomula.PRICE_YEAR12_MONTH9 = Fomula.PRICE_YEAR12_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH10 = Fomula.PRICE_YEAR12_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH10) & strIndex)
            Fomula.PRICE_YEAR12_MONTH10 = Fomula.PRICE_YEAR12_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH11 = Fomula.PRICE_YEAR12_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH11) & strIndex)
            Fomula.PRICE_YEAR12_MONTH11 = Fomula.PRICE_YEAR12_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH12 = Fomula.PRICE_YEAR12_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH12) & strIndex)
            Fomula.PRICE_YEAR12_MONTH12 = Fomula.PRICE_YEAR12_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR13_MONTH1 = Fomula.PRICE_YEAR13_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH1) & strIndex)
            Fomula.PRICE_YEAR13_MONTH1 = Fomula.PRICE_YEAR13_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR13_MONTH2 = Fomula.PRICE_YEAR14_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH2) & strIndex)
            Fomula.PRICE_YEAR13_MONTH2 = Fomula.PRICE_YEAR14_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR13_MONTH3 = Fomula.PRICE_YEAR13_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH3) & strIndex)
            Fomula.PRICE_YEAR13_MONTH3 = Fomula.PRICE_YEAR13_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR13_MONTH4 = Fomula.PRICE_YEAR13_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH4) & strIndex)
            Fomula.PRICE_YEAR13_MONTH4 = Fomula.PRICE_YEAR13_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR13_MONTH5 = Fomula.PRICE_YEAR13_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH5) & strIndex)
            Fomula.PRICE_YEAR13_MONTH5 = Fomula.PRICE_YEAR13_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR13_MONTH6 = Fomula.PRICE_YEAR13_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH6) & strIndex)
            Fomula.PRICE_YEAR13_MONTH6 = Fomula.PRICE_YEAR13_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR13_MONTH7 = Fomula.PRICE_YEAR13_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH7) & strIndex)
            Fomula.PRICE_YEAR13_MONTH7 = Fomula.PRICE_YEAR13_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR13_MONTH8 = Fomula.PRICE_YEAR13_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH8) & strIndex)
            Fomula.PRICE_YEAR13_MONTH8 = Fomula.PRICE_YEAR13_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR13_MONTH9 = Fomula.PRICE_YEAR13_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH9) & strIndex)
            Fomula.PRICE_YEAR13_MONTH9 = Fomula.PRICE_YEAR13_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR13_MONTH10 = Fomula.PRICE_YEAR13_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH10) & strIndex)
            Fomula.PRICE_YEAR13_MONTH10 = Fomula.PRICE_YEAR13_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR13_MONTH11 = Fomula.PRICE_YEAR13_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH11) & strIndex)
            Fomula.PRICE_YEAR13_MONTH11 = Fomula.PRICE_YEAR13_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR13_MONTH12 = Fomula.PRICE_YEAR13_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH12) & strIndex)
            Fomula.PRICE_YEAR13_MONTH12 = Fomula.PRICE_YEAR13_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR14_MONTH1 = Fomula.PRICE_YEAR14_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH1) & strIndex)
            Fomula.PRICE_YEAR14_MONTH1 = Fomula.PRICE_YEAR14_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR14_MONTH2 = Fomula.PRICE_YEAR14_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH2) & strIndex)
            Fomula.PRICE_YEAR14_MONTH2 = Fomula.PRICE_YEAR14_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR14_MONTH3 = Fomula.PRICE_YEAR14_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH3) & strIndex)
            Fomula.PRICE_YEAR14_MONTH3 = Fomula.PRICE_YEAR14_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR14_MONTH4 = Fomula.PRICE_YEAR14_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH4) & strIndex)
            Fomula.PRICE_YEAR14_MONTH4 = Fomula.PRICE_YEAR14_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR14_MONTH5 = Fomula.PRICE_YEAR14_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH5) & strIndex)
            Fomula.PRICE_YEAR14_MONTH5 = Fomula.PRICE_YEAR14_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR14_MONTH6 = Fomula.PRICE_YEAR14_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH6) & strIndex)
            Fomula.PRICE_YEAR14_MONTH6 = Fomula.PRICE_YEAR14_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR14_MONTH7 = Fomula.PRICE_YEAR14_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH7) & strIndex)
            Fomula.PRICE_YEAR14_MONTH7 = Fomula.PRICE_YEAR14_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR14_MONTH8 = Fomula.PRICE_YEAR14_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH8) & strIndex)
            Fomula.PRICE_YEAR14_MONTH8 = Fomula.PRICE_YEAR14_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR14_MONTH9 = Fomula.PRICE_YEAR14_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH9) & strIndex)
            Fomula.PRICE_YEAR14_MONTH9 = Fomula.PRICE_YEAR14_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR14_MONTH10 = Fomula.PRICE_YEAR14_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH10) & strIndex)
            Fomula.PRICE_YEAR14_MONTH10 = Fomula.PRICE_YEAR14_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR14_MONTH11 = Fomula.PRICE_YEAR14_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH11) & strIndex)
            Fomula.PRICE_YEAR14_MONTH11 = Fomula.PRICE_YEAR14_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR14_MONTH12 = Fomula.PRICE_YEAR14_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH12) & strIndex)
            Fomula.PRICE_YEAR14_MONTH12 = Fomula.PRICE_YEAR14_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR15_MONTH1 = Fomula.PRICE_YEAR15_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH1) & strIndex)
            Fomula.PRICE_YEAR15_MONTH1 = Fomula.PRICE_YEAR15_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR15_MONTH2 = Fomula.PRICE_YEAR15_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH2) & strIndex)
            Fomula.PRICE_YEAR15_MONTH2 = Fomula.PRICE_YEAR15_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR15_MONTH3 = Fomula.PRICE_YEAR15_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH3) & strIndex)
            Fomula.PRICE_YEAR15_MONTH3 = Fomula.PRICE_YEAR15_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR15_MONTH4 = Fomula.PRICE_YEAR15_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH4) & strIndex)
            Fomula.PRICE_YEAR15_MONTH4 = Fomula.PRICE_YEAR15_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR15_MONTH5 = Fomula.PRICE_YEAR15_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH5) & strIndex)
            Fomula.PRICE_YEAR15_MONTH5 = Fomula.PRICE_YEAR15_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR15_MONTH6 = Fomula.PRICE_YEAR15_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH6) & strIndex)
            Fomula.PRICE_YEAR15_MONTH6 = Fomula.PRICE_YEAR15_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR15_MONTH7 = Fomula.PRICE_YEAR15_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH7) & strIndex)
            Fomula.PRICE_YEAR15_MONTH7 = Fomula.PRICE_YEAR15_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR15_MONTH8 = Fomula.PRICE_YEAR15_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH8) & strIndex)
            Fomula.PRICE_YEAR15_MONTH8 = Fomula.PRICE_YEAR15_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR15_MONTH9 = Fomula.PRICE_YEAR15_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH9) & strIndex)
            Fomula.PRICE_YEAR15_MONTH9 = Fomula.PRICE_YEAR15_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR15_MONTH10 = Fomula.PRICE_YEAR15_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH10) & strIndex)
            Fomula.PRICE_YEAR15_MONTH10 = Fomula.PRICE_YEAR15_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR15_MONTH11 = Fomula.PRICE_YEAR15_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH11) & strIndex)
            Fomula.PRICE_YEAR15_MONTH11 = Fomula.PRICE_YEAR15_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR15_MONTH12 = Fomula.PRICE_YEAR15_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH12) & strIndex)
            Fomula.PRICE_YEAR15_MONTH12 = Fomula.PRICE_YEAR15_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR16_MONTH1 = Fomula.PRICE_YEAR16_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH1) & strIndex)
            Fomula.PRICE_YEAR16_MONTH1 = Fomula.PRICE_YEAR16_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR16_MONTH2 = Fomula.PRICE_YEAR16_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH2) & strIndex)
            Fomula.PRICE_YEAR16_MONTH2 = Fomula.PRICE_YEAR16_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR16_MONTH3 = Fomula.PRICE_YEAR16_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH3) & strIndex)
            Fomula.PRICE_YEAR16_MONTH3 = Fomula.PRICE_YEAR16_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR16_MONTH4 = Fomula.PRICE_YEAR16_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH4) & strIndex)
            Fomula.PRICE_YEAR16_MONTH4 = Fomula.PRICE_YEAR16_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR16_MONTH5 = Fomula.PRICE_YEAR16_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH5) & strIndex)
            Fomula.PRICE_YEAR16_MONTH5 = Fomula.PRICE_YEAR16_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR16_MONTH6 = Fomula.PRICE_YEAR16_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH6) & strIndex)
            Fomula.PRICE_YEAR16_MONTH6 = Fomula.PRICE_YEAR16_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR16_MONTH7 = Fomula.PRICE_YEAR16_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH7) & strIndex)
            Fomula.PRICE_YEAR16_MONTH7 = Fomula.PRICE_YEAR16_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR16_MONTH8 = Fomula.PRICE_YEAR16_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH8) & strIndex)
            Fomula.PRICE_YEAR16_MONTH8 = Fomula.PRICE_YEAR16_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR16_MONTH9 = Fomula.PRICE_YEAR16_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH9) & strIndex)
            Fomula.PRICE_YEAR16_MONTH9 = Fomula.PRICE_YEAR16_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR16_MONTH10 = Fomula.PRICE_YEAR16_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH10) & strIndex)
            Fomula.PRICE_YEAR16_MONTH10 = Fomula.PRICE_YEAR16_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR16_MONTH11 = Fomula.PRICE_YEAR16_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH11) & strIndex)
            Fomula.PRICE_YEAR16_MONTH11 = Fomula.PRICE_YEAR16_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR16_MONTH12 = Fomula.PRICE_YEAR16_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH12) & strIndex)
            Fomula.PRICE_YEAR16_MONTH12 = Fomula.PRICE_YEAR16_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR17_MONTH1 = Fomula.PRICE_YEAR17_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH1) & strIndex)
            Fomula.PRICE_YEAR17_MONTH1 = Fomula.PRICE_YEAR17_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR17_MONTH2 = Fomula.PRICE_YEAR17_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH2) & strIndex)
            Fomula.PRICE_YEAR17_MONTH2 = Fomula.PRICE_YEAR17_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR17_MONTH3 = Fomula.PRICE_YEAR17_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH3) & strIndex)
            Fomula.PRICE_YEAR17_MONTH3 = Fomula.PRICE_YEAR17_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR17_MONTH4 = Fomula.PRICE_YEAR17_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH4) & strIndex)
            Fomula.PRICE_YEAR17_MONTH4 = Fomula.PRICE_YEAR17_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR17_MONTH5 = Fomula.PRICE_YEAR17_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH5) & strIndex)
            Fomula.PRICE_YEAR17_MONTH5 = Fomula.PRICE_YEAR17_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR17_MONTH6 = Fomula.PRICE_YEAR17_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH6) & strIndex)
            Fomula.PRICE_YEAR17_MONTH6 = Fomula.PRICE_YEAR17_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR17_MONTH7 = Fomula.PRICE_YEAR17_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH7) & strIndex)
            Fomula.PRICE_YEAR17_MONTH7 = Fomula.PRICE_YEAR17_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR17_MONTH8 = Fomula.PRICE_YEAR17_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH8) & strIndex)
            Fomula.PRICE_YEAR17_MONTH8 = Fomula.PRICE_YEAR17_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR17_MONTH9 = Fomula.PRICE_YEAR17_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH9) & strIndex)
            Fomula.PRICE_YEAR17_MONTH9 = Fomula.PRICE_YEAR17_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR17_MONTH10 = Fomula.PRICE_YEAR17_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH10) & strIndex)
            Fomula.PRICE_YEAR17_MONTH10 = Fomula.PRICE_YEAR17_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR17_MONTH11 = Fomula.PRICE_YEAR17_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH11) & strIndex)
            Fomula.PRICE_YEAR17_MONTH11 = Fomula.PRICE_YEAR17_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR17_MONTH12 = Fomula.PRICE_YEAR17_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH12) & strIndex)
            Fomula.PRICE_YEAR17_MONTH12 = Fomula.PRICE_YEAR17_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR18_MONTH1 = Fomula.PRICE_YEAR18_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH1) & strIndex)
            Fomula.PRICE_YEAR18_MONTH1 = Fomula.PRICE_YEAR18_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR18_MONTH2 = Fomula.PRICE_YEAR18_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH2) & strIndex)
            Fomula.PRICE_YEAR18_MONTH2 = Fomula.PRICE_YEAR18_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR18_MONTH3 = Fomula.PRICE_YEAR18_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH3) & strIndex)
            Fomula.PRICE_YEAR18_MONTH3 = Fomula.PRICE_YEAR18_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR18_MONTH4 = Fomula.PRICE_YEAR18_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH4) & strIndex)
            Fomula.PRICE_YEAR18_MONTH4 = Fomula.PRICE_YEAR18_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR18_MONTH5 = Fomula.PRICE_YEAR18_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH5) & strIndex)
            Fomula.PRICE_YEAR18_MONTH5 = Fomula.PRICE_YEAR18_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR18_MONTH6 = Fomula.PRICE_YEAR18_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH6) & strIndex)
            Fomula.PRICE_YEAR18_MONTH6 = Fomula.PRICE_YEAR18_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR18_MONTH7 = Fomula.PRICE_YEAR18_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH7) & strIndex)
            Fomula.PRICE_YEAR18_MONTH7 = Fomula.PRICE_YEAR18_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR18_MONTH8 = Fomula.PRICE_YEAR18_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH8) & strIndex)
            Fomula.PRICE_YEAR18_MONTH8 = Fomula.PRICE_YEAR18_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR18_MONTH9 = Fomula.PRICE_YEAR18_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH9) & strIndex)
            Fomula.PRICE_YEAR18_MONTH9 = Fomula.PRICE_YEAR18_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR18_MONTH10 = Fomula.PRICE_YEAR18_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH10) & strIndex)
            Fomula.PRICE_YEAR18_MONTH10 = Fomula.PRICE_YEAR18_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR18_MONTH11 = Fomula.PRICE_YEAR18_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH11) & strIndex)
            Fomula.PRICE_YEAR18_MONTH11 = Fomula.PRICE_YEAR18_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR18_MONTH12 = Fomula.PRICE_YEAR18_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH12) & strIndex)
            Fomula.PRICE_YEAR18_MONTH12 = Fomula.PRICE_YEAR18_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR19_MONTH1 = Fomula.PRICE_YEAR19_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH1) & strIndex)
            Fomula.PRICE_YEAR19_MONTH1 = Fomula.PRICE_YEAR19_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR19_MONTH2 = Fomula.PRICE_YEAR19_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH2) & strIndex)
            Fomula.PRICE_YEAR19_MONTH2 = Fomula.PRICE_YEAR19_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR19_MONTH3 = Fomula.PRICE_YEAR19_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH3) & strIndex)
            Fomula.PRICE_YEAR19_MONTH3 = Fomula.PRICE_YEAR19_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR19_MONTH4 = Fomula.PRICE_YEAR19_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH4) & strIndex)
            Fomula.PRICE_YEAR19_MONTH4 = Fomula.PRICE_YEAR19_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR19_MONTH5 = Fomula.PRICE_YEAR19_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH5) & strIndex)
            Fomula.PRICE_YEAR19_MONTH5 = Fomula.PRICE_YEAR19_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR19_MONTH6 = Fomula.PRICE_YEAR19_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH6) & strIndex)
            Fomula.PRICE_YEAR19_MONTH6 = Fomula.PRICE_YEAR19_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR19_MONTH7 = Fomula.PRICE_YEAR19_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH7) & strIndex)
            Fomula.PRICE_YEAR19_MONTH7 = Fomula.PRICE_YEAR19_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR19_MONTH8 = Fomula.PRICE_YEAR19_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH8) & strIndex)
            Fomula.PRICE_YEAR19_MONTH8 = Fomula.PRICE_YEAR19_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR19_MONTH9 = Fomula.PRICE_YEAR19_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH9) & strIndex)
            Fomula.PRICE_YEAR19_MONTH9 = Fomula.PRICE_YEAR19_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR19_MONTH10 = Fomula.PRICE_YEAR19_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH10) & strIndex)
            Fomula.PRICE_YEAR19_MONTH10 = Fomula.PRICE_YEAR19_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR19_MONTH11 = Fomula.PRICE_YEAR19_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH11) & strIndex)
            Fomula.PRICE_YEAR19_MONTH11 = Fomula.PRICE_YEAR19_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR19_MONTH12 = Fomula.PRICE_YEAR19_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH12) & strIndex)
            Fomula.PRICE_YEAR19_MONTH12 = Fomula.PRICE_YEAR19_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR20_MONTH1 = Fomula.PRICE_YEAR20_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH1) & strIndex)
            Fomula.PRICE_YEAR20_MONTH1 = Fomula.PRICE_YEAR20_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR20_MONTH2 = Fomula.PRICE_YEAR20_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH2) & strIndex)
            Fomula.PRICE_YEAR20_MONTH2 = Fomula.PRICE_YEAR20_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR20_MONTH3 = Fomula.PRICE_YEAR20_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH3) & strIndex)
            Fomula.PRICE_YEAR20_MONTH3 = Fomula.PRICE_YEAR20_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR20_MONTH4 = Fomula.PRICE_YEAR20_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH4) & strIndex)
            Fomula.PRICE_YEAR20_MONTH4 = Fomula.PRICE_YEAR20_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR20_MONTH5 = Fomula.PRICE_YEAR20_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH5) & strIndex)
            Fomula.PRICE_YEAR20_MONTH5 = Fomula.PRICE_YEAR20_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR20_MONTH6 = Fomula.PRICE_YEAR20_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH6) & strIndex)
            Fomula.PRICE_YEAR20_MONTH6 = Fomula.PRICE_YEAR20_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR20_MONTH7 = Fomula.PRICE_YEAR20_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH7) & strIndex)
            Fomula.PRICE_YEAR20_MONTH7 = Fomula.PRICE_YEAR20_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR20_MONTH8 = Fomula.PRICE_YEAR20_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH8) & strIndex)
            Fomula.PRICE_YEAR20_MONTH8 = Fomula.PRICE_YEAR20_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR20_MONTH9 = Fomula.PRICE_YEAR20_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH9) & strIndex)
            Fomula.PRICE_YEAR20_MONTH9 = Fomula.PRICE_YEAR20_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR20_MONTH10 = Fomula.PRICE_YEAR20_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH10) & strIndex)
            Fomula.PRICE_YEAR20_MONTH10 = Fomula.PRICE_YEAR20_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR20_MONTH11 = Fomula.PRICE_YEAR20_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH11) & strIndex)
            Fomula.PRICE_YEAR20_MONTH11 = Fomula.PRICE_YEAR20_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR20_MONTH12 = Fomula.PRICE_YEAR20_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH12) & strIndex)
            Fomula.PRICE_YEAR20_MONTH12 = Fomula.PRICE_YEAR20_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH12) & EndIndex)

            ''式のセット
            ''期間合計
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_IOC) = Fomula.ListPrice
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_TOTAL_IOC) = Fomula.DPerAfter
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.COST_TOTAL_IOC) = Fomula.DPerAfterrate
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT_IN) = Fomula.PRICE_CONT_TOTAL
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT_OUT) = Fomula.PRICE_OO_CONT_TOTAL
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1) = Fomula.IGF

            ''年度金額
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1 + 1) = Fomula.PRICE_YEAR1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2 + 1) = Fomula.PRICE_YEAR2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3 + 1) = Fomula.PRICE_YEAR3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4 + 1) = Fomula.PRICE_YEAR4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5 + 1) = Fomula.PRICE_YEAR5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6 + 1) = Fomula.PRICE_YEAR6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7 + 1) = Fomula.PRICE_YEAR7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8 + 1) = Fomula.PRICE_YEAR8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9 + 1) = Fomula.PRICE_YEAR9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10 + 1) = Fomula.PRICE_YEAR10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11 + 1) = Fomula.PRICE_YEAR11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12 + 1) = Fomula.PRICE_YEAR12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13 + 1) = Fomula.PRICE_YEAR13
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14 + 1) = Fomula.PRICE_YEAR14
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15 + 1) = Fomula.PRICE_YEAR15
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16 + 1) = Fomula.PRICE_YEAR16
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17 + 1) = Fomula.PRICE_YEAR17
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18 + 1) = Fomula.PRICE_YEAR18
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19 + 1) = Fomula.PRICE_YEAR19
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20 + 1) = Fomula.PRICE_YEAR20
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL + 1) = Fomula.PRICE_PAST_CONTRACT

            ''月度金額
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1 + 1) = Fomula.PRICE_YEAR1_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH2 + 1) = Fomula.PRICE_YEAR1_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH3 + 1) = Fomula.PRICE_YEAR1_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH4 + 1) = Fomula.PRICE_YEAR1_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH5 + 1) = Fomula.PRICE_YEAR1_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH6 + 1) = Fomula.PRICE_YEAR1_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH7 + 1) = Fomula.PRICE_YEAR1_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH8 + 1) = Fomula.PRICE_YEAR1_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH9 + 1) = Fomula.PRICE_YEAR1_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH10 + 1) = Fomula.PRICE_YEAR1_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH11 + 1) = Fomula.PRICE_YEAR1_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH12 + 1) = Fomula.PRICE_YEAR1_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH1 + 1) = Fomula.PRICE_YEAR2_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH2 + 1) = Fomula.PRICE_YEAR2_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH3 + 1) = Fomula.PRICE_YEAR2_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH4 + 1) = Fomula.PRICE_YEAR2_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH5 + 1) = Fomula.PRICE_YEAR2_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH6 + 1) = Fomula.PRICE_YEAR2_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH7 + 1) = Fomula.PRICE_YEAR2_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH8 + 1) = Fomula.PRICE_YEAR2_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH9 + 1) = Fomula.PRICE_YEAR2_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH10 + 1) = Fomula.PRICE_YEAR2_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH11 + 1) = Fomula.PRICE_YEAR2_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH12 + 1) = Fomula.PRICE_YEAR2_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH1 + 1) = Fomula.PRICE_YEAR3_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH2 + 1) = Fomula.PRICE_YEAR3_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH3 + 1) = Fomula.PRICE_YEAR3_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH4 + 1) = Fomula.PRICE_YEAR3_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH5 + 1) = Fomula.PRICE_YEAR3_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH6 + 1) = Fomula.PRICE_YEAR3_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH7 + 1) = Fomula.PRICE_YEAR3_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH8 + 1) = Fomula.PRICE_YEAR3_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH9 + 1) = Fomula.PRICE_YEAR3_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH10 + 1) = Fomula.PRICE_YEAR3_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH11 + 1) = Fomula.PRICE_YEAR3_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH12 + 1) = Fomula.PRICE_YEAR3_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH1 + 1) = Fomula.PRICE_YEAR4_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH2 + 1) = Fomula.PRICE_YEAR4_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH3 + 1) = Fomula.PRICE_YEAR4_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH4 + 1) = Fomula.PRICE_YEAR4_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH5 + 1) = Fomula.PRICE_YEAR4_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH6 + 1) = Fomula.PRICE_YEAR4_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH7 + 1) = Fomula.PRICE_YEAR4_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH8 + 1) = Fomula.PRICE_YEAR4_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH9 + 1) = Fomula.PRICE_YEAR4_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH10 + 1) = Fomula.PRICE_YEAR4_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH11 + 1) = Fomula.PRICE_YEAR4_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH12 + 1) = Fomula.PRICE_YEAR4_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH1 + 1) = Fomula.PRICE_YEAR5_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH2 + 1) = Fomula.PRICE_YEAR5_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH3 + 1) = Fomula.PRICE_YEAR5_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH4 + 1) = Fomula.PRICE_YEAR5_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH5 + 1) = Fomula.PRICE_YEAR5_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH6 + 1) = Fomula.PRICE_YEAR5_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH7 + 1) = Fomula.PRICE_YEAR5_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH8 + 1) = Fomula.PRICE_YEAR5_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH9 + 1) = Fomula.PRICE_YEAR5_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH10 + 1) = Fomula.PRICE_YEAR5_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH11 + 1) = Fomula.PRICE_YEAR5_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH12 + 1) = Fomula.PRICE_YEAR5_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH1 + 1) = Fomula.PRICE_YEAR6_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH2 + 1) = Fomula.PRICE_YEAR6_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH3 + 1) = Fomula.PRICE_YEAR6_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH4 + 1) = Fomula.PRICE_YEAR6_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH5 + 1) = Fomula.PRICE_YEAR6_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH6 + 1) = Fomula.PRICE_YEAR6_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH7 + 1) = Fomula.PRICE_YEAR6_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH8 + 1) = Fomula.PRICE_YEAR6_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH9 + 1) = Fomula.PRICE_YEAR6_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH10 + 1) = Fomula.PRICE_YEAR6_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH11 + 1) = Fomula.PRICE_YEAR6_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH12 + 1) = Fomula.PRICE_YEAR6_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH1 + 1) = Fomula.PRICE_YEAR7_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH2 + 1) = Fomula.PRICE_YEAR7_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH3 + 1) = Fomula.PRICE_YEAR7_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH4 + 1) = Fomula.PRICE_YEAR7_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH5 + 1) = Fomula.PRICE_YEAR7_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH6 + 1) = Fomula.PRICE_YEAR7_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH7 + 1) = Fomula.PRICE_YEAR7_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH8 + 1) = Fomula.PRICE_YEAR7_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH9 + 1) = Fomula.PRICE_YEAR7_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH10 + 1) = Fomula.PRICE_YEAR7_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH11 + 1) = Fomula.PRICE_YEAR7_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH12 + 1) = Fomula.PRICE_YEAR7_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH1 + 1) = Fomula.PRICE_YEAR8_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH2 + 1) = Fomula.PRICE_YEAR8_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH3 + 1) = Fomula.PRICE_YEAR8_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH4 + 1) = Fomula.PRICE_YEAR8_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH5 + 1) = Fomula.PRICE_YEAR8_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH6 + 1) = Fomula.PRICE_YEAR8_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH7 + 1) = Fomula.PRICE_YEAR8_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH8 + 1) = Fomula.PRICE_YEAR8_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH9 + 1) = Fomula.PRICE_YEAR8_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH10 + 1) = Fomula.PRICE_YEAR8_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH11 + 1) = Fomula.PRICE_YEAR8_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH12 + 1) = Fomula.PRICE_YEAR8_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH1 + 1) = Fomula.PRICE_YEAR9_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH2 + 1) = Fomula.PRICE_YEAR9_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH3 + 1) = Fomula.PRICE_YEAR9_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH4 + 1) = Fomula.PRICE_YEAR9_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH5 + 1) = Fomula.PRICE_YEAR9_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH6 + 1) = Fomula.PRICE_YEAR9_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH7 + 1) = Fomula.PRICE_YEAR9_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH8 + 1) = Fomula.PRICE_YEAR9_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH9 + 1) = Fomula.PRICE_YEAR9_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH10 + 1) = Fomula.PRICE_YEAR9_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH11 + 1) = Fomula.PRICE_YEAR9_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH12 + 1) = Fomula.PRICE_YEAR9_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH1 + 1) = Fomula.PRICE_YEAR10_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH2 + 1) = Fomula.PRICE_YEAR10_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH3 + 1) = Fomula.PRICE_YEAR10_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH4 + 1) = Fomula.PRICE_YEAR10_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH5 + 1) = Fomula.PRICE_YEAR10_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH6 + 1) = Fomula.PRICE_YEAR10_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH7 + 1) = Fomula.PRICE_YEAR10_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH8 + 1) = Fomula.PRICE_YEAR10_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH9 + 1) = Fomula.PRICE_YEAR10_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH10 + 1) = Fomula.PRICE_YEAR10_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH11 + 1) = Fomula.PRICE_YEAR10_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH12 + 1) = Fomula.PRICE_YEAR10_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH1 + 1) = Fomula.PRICE_YEAR11_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH2 + 1) = Fomula.PRICE_YEAR11_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH3 + 1) = Fomula.PRICE_YEAR11_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH4 + 1) = Fomula.PRICE_YEAR11_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH5 + 1) = Fomula.PRICE_YEAR11_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH6 + 1) = Fomula.PRICE_YEAR11_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH7 + 1) = Fomula.PRICE_YEAR11_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH8 + 1) = Fomula.PRICE_YEAR11_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH9 + 1) = Fomula.PRICE_YEAR11_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH10 + 1) = Fomula.PRICE_YEAR11_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH11 + 1) = Fomula.PRICE_YEAR11_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH12 + 1) = Fomula.PRICE_YEAR11_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH1 + 1) = Fomula.PRICE_YEAR12_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH2 + 1) = Fomula.PRICE_YEAR12_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH3 + 1) = Fomula.PRICE_YEAR12_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH4 + 1) = Fomula.PRICE_YEAR12_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH5 + 1) = Fomula.PRICE_YEAR12_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH6 + 1) = Fomula.PRICE_YEAR12_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH7 + 1) = Fomula.PRICE_YEAR12_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH8 + 1) = Fomula.PRICE_YEAR12_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH9 + 1) = Fomula.PRICE_YEAR12_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH10 + 1) = Fomula.PRICE_YEAR12_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH11 + 1) = Fomula.PRICE_YEAR12_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH12 + 1) = Fomula.PRICE_YEAR12_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH1 + 1) = Fomula.PRICE_YEAR13_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH2 + 1) = Fomula.PRICE_YEAR13_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH3 + 1) = Fomula.PRICE_YEAR13_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH4 + 1) = Fomula.PRICE_YEAR13_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH5 + 1) = Fomula.PRICE_YEAR13_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH6 + 1) = Fomula.PRICE_YEAR13_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH7 + 1) = Fomula.PRICE_YEAR13_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH8 + 1) = Fomula.PRICE_YEAR13_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH9 + 1) = Fomula.PRICE_YEAR13_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH10 + 1) = Fomula.PRICE_YEAR13_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH11 + 1) = Fomula.PRICE_YEAR13_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH12 + 1) = Fomula.PRICE_YEAR13_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH1 + 1) = Fomula.PRICE_YEAR14_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH2 + 1) = Fomula.PRICE_YEAR14_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH3 + 1) = Fomula.PRICE_YEAR14_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH4 + 1) = Fomula.PRICE_YEAR14_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH5 + 1) = Fomula.PRICE_YEAR14_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH6 + 1) = Fomula.PRICE_YEAR14_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH7 + 1) = Fomula.PRICE_YEAR14_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH8 + 1) = Fomula.PRICE_YEAR14_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH9 + 1) = Fomula.PRICE_YEAR14_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH10 + 1) = Fomula.PRICE_YEAR14_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH11 + 1) = Fomula.PRICE_YEAR14_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH12 + 1) = Fomula.PRICE_YEAR14_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH1 + 1) = Fomula.PRICE_YEAR15_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH2 + 1) = Fomula.PRICE_YEAR15_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH3 + 1) = Fomula.PRICE_YEAR15_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH4 + 1) = Fomula.PRICE_YEAR15_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH5 + 1) = Fomula.PRICE_YEAR15_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH6 + 1) = Fomula.PRICE_YEAR15_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH7 + 1) = Fomula.PRICE_YEAR15_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH8 + 1) = Fomula.PRICE_YEAR15_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH9 + 1) = Fomula.PRICE_YEAR15_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH10 + 1) = Fomula.PRICE_YEAR15_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH11 + 1) = Fomula.PRICE_YEAR15_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH12 + 1) = Fomula.PRICE_YEAR15_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH1 + 1) = Fomula.PRICE_YEAR16_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH2 + 1) = Fomula.PRICE_YEAR16_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH3 + 1) = Fomula.PRICE_YEAR16_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH4 + 1) = Fomula.PRICE_YEAR16_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH5 + 1) = Fomula.PRICE_YEAR16_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH6 + 1) = Fomula.PRICE_YEAR16_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH7 + 1) = Fomula.PRICE_YEAR16_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH8 + 1) = Fomula.PRICE_YEAR16_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH9 + 1) = Fomula.PRICE_YEAR16_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH10 + 1) = Fomula.PRICE_YEAR16_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH11 + 1) = Fomula.PRICE_YEAR16_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH12 + 1) = Fomula.PRICE_YEAR16_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH1 + 1) = Fomula.PRICE_YEAR17_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH2 + 1) = Fomula.PRICE_YEAR17_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH3 + 1) = Fomula.PRICE_YEAR17_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH4 + 1) = Fomula.PRICE_YEAR17_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH5 + 1) = Fomula.PRICE_YEAR17_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH6 + 1) = Fomula.PRICE_YEAR17_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH7 + 1) = Fomula.PRICE_YEAR17_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH8 + 1) = Fomula.PRICE_YEAR17_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH9 + 1) = Fomula.PRICE_YEAR17_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH10 + 1) = Fomula.PRICE_YEAR17_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH11 + 1) = Fomula.PRICE_YEAR17_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH12 + 1) = Fomula.PRICE_YEAR17_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH1 + 1) = Fomula.PRICE_YEAR18_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH2 + 1) = Fomula.PRICE_YEAR18_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH3 + 1) = Fomula.PRICE_YEAR18_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH4 + 1) = Fomula.PRICE_YEAR18_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH5 + 1) = Fomula.PRICE_YEAR18_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH6 + 1) = Fomula.PRICE_YEAR18_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH7 + 1) = Fomula.PRICE_YEAR18_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH8 + 1) = Fomula.PRICE_YEAR18_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH9 + 1) = Fomula.PRICE_YEAR18_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH10 + 1) = Fomula.PRICE_YEAR18_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH11 + 1) = Fomula.PRICE_YEAR18_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH12 + 1) = Fomula.PRICE_YEAR18_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH1 + 1) = Fomula.PRICE_YEAR19_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH2 + 1) = Fomula.PRICE_YEAR19_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH3 + 1) = Fomula.PRICE_YEAR19_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH4 + 1) = Fomula.PRICE_YEAR19_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH5 + 1) = Fomula.PRICE_YEAR19_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH6 + 1) = Fomula.PRICE_YEAR19_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH7 + 1) = Fomula.PRICE_YEAR19_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH8 + 1) = Fomula.PRICE_YEAR19_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH9 + 1) = Fomula.PRICE_YEAR19_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH10 + 1) = Fomula.PRICE_YEAR19_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH11 + 1) = Fomula.PRICE_YEAR19_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH12 + 1) = Fomula.PRICE_YEAR19_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH1 + 1) = Fomula.PRICE_YEAR20_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH2 + 1) = Fomula.PRICE_YEAR20_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH3 + 1) = Fomula.PRICE_YEAR20_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH4 + 1) = Fomula.PRICE_YEAR20_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH5 + 1) = Fomula.PRICE_YEAR20_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH6 + 1) = Fomula.PRICE_YEAR20_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH7 + 1) = Fomula.PRICE_YEAR20_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH8 + 1) = Fomula.PRICE_YEAR20_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH9 + 1) = Fomula.PRICE_YEAR20_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH10 + 1) = Fomula.PRICE_YEAR20_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH11 + 1) = Fomula.PRICE_YEAR20_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12 + 1) = Fomula.PRICE_YEAR20_MONTH12

        End If

        ''==========================================
        ''					新規の処理
        ''==========================================
        Dim filterNew As New StringBuilder
        filterNew.Append("SortNMNewOrDel")
        filterNew.Append(CommonConstant.SQL_STR_EQUAL)
        filterNew.Append(StringEdit.EncloseSingleQuotation(CELLVALUE_SortNMNewOrDel_NEW))
        filterNew.Append(CommonConstant.SQL_STR_AND)
        filterNew.Append("SummaryNM")
        filterNew.Append(CommonConstant.SQL_STR_EQUAL)
        filterNew.Append(StringEdit.EncloseSingleQuotation(CELLVALUE_SummaryNM_NewOrDel))

        ''データを抽出		
        rows = OutIGFDataTable.Select(filterNew.Tostring)
        If rows.length > 0 Then

            ''開始位置、終了位置をセット
            '' ※削除集計行の一つ上の行が集計のSTR行
            '' ※新規集計行の一つ上の行が集計のEND行
            If OutIGFDataTable.Select(filterDel.ToString).Length > 0 Then
                strIndex = CInt(OutIGFDataTable.Select(filterDel.ToString)(0).Item("OutExcelRow")) + 1
            Else
                strIndex = EXCEL_IGFDATA_OUTROW
            End If
            EndIndex = CInt(OutIGFDataTable.Select(filterNew.ToString)(0).Item("OutExcelRow")) - 1

            ''デフォルト式をセット
            Fomula.ListPrice = SUMMARYROW_FOMULA_SUMMARY_TERM
            Fomula.DPerAfter = SUMMARYROW_FOMULA_SUMMARY_TERM
            Fomula.DPerAfterrate = SUMMARYROW_FOMULA_SUMMARY_TERM
            Fomula.PRICE_CONT_TOTAL = SUMMARYROW_FOMULA_SUMMARY_TERM
            Fomula.PRICE_OO_CONT_TOTAL = SUMMARYROW_FOMULA_SUMMARY_TERM
            Fomula.IGF = SUMMARYROW_FOMULA_SUMMARY_TERM

            ''年度金額
            Fomula.PRICE_YEAR1 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR2 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR3 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR4 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR5 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR6 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR7 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR8 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR9 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR10 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR11 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR12 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR13 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR14 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR15 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR16 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR17 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR18 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR19 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR20 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_PAST_CONTRACT = SUMMARYROW_FOMULA_PRICE_YEAR

            ''月度金額
            Fomula.PRICE_YEAR1_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH

            ''開始、終了位置のセット
            ''期間合計
            Fomula.ListPrice = Fomula.ListPrice.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_IOC) & strIndex)
            Fomula.ListPrice = Fomula.ListPrice.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_IOC) & EndIndex)

            Fomula.DPerAfter = Fomula.DPerAfter.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_TOTAL_IOC) & strIndex)
            Fomula.DPerAfter = Fomula.DPerAfter.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_TOTAL_IOC) & EndIndex)

            Fomula.DPerAfterrate = Fomula.DPerAfterrate.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.IGF_AFTER) & strIndex)
            Fomula.DPerAfterrate = Fomula.DPerAfterrate.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.IGF_AFTER) & EndIndex)

            Fomula.IGF = Fomula.IGF.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.IGF_RATE) & strIndex)
            Fomula.IGF = Fomula.IGF.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.IGF_RATE) & EndIndex)

            Fomula.PRICE_CONT_TOTAL = Fomula.PRICE_CONT_TOTAL.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.CONTRACT_IN) & strIndex)
            Fomula.PRICE_CONT_TOTAL = Fomula.PRICE_CONT_TOTAL.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.CONTRACT_IN) & EndIndex)

            Fomula.PRICE_OO_CONT_TOTAL = Fomula.PRICE_OO_CONT_TOTAL.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.CONTRACT_OUT) & strIndex)
            Fomula.PRICE_OO_CONT_TOTAL = Fomula.PRICE_OO_CONT_TOTAL.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.CONTRACT_OUT) & EndIndex)


            ''年度金額
            Fomula.PRICE_YEAR1 = Fomula.PRICE_YEAR1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1) & strIndex)
            Fomula.PRICE_YEAR1 = Fomula.PRICE_YEAR1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1) & EndIndex)

            Fomula.PRICE_YEAR2 = Fomula.PRICE_YEAR2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2) & strIndex)
            Fomula.PRICE_YEAR2 = Fomula.PRICE_YEAR2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2) & EndIndex)

            Fomula.PRICE_YEAR3 = Fomula.PRICE_YEAR3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3) & strIndex)
            Fomula.PRICE_YEAR3 = Fomula.PRICE_YEAR3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3) & EndIndex)

            Fomula.PRICE_YEAR4 = Fomula.PRICE_YEAR4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4) & strIndex)
            Fomula.PRICE_YEAR4 = Fomula.PRICE_YEAR4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4) & EndIndex)

            Fomula.PRICE_YEAR5 = Fomula.PRICE_YEAR5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5) & strIndex)
            Fomula.PRICE_YEAR5 = Fomula.PRICE_YEAR5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5) & EndIndex)

            Fomula.PRICE_YEAR6 = Fomula.PRICE_YEAR6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6) & strIndex)
            Fomula.PRICE_YEAR6 = Fomula.PRICE_YEAR6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6) & EndIndex)

            Fomula.PRICE_YEAR7 = Fomula.PRICE_YEAR7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7) & strIndex)
            Fomula.PRICE_YEAR7 = Fomula.PRICE_YEAR7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7) & EndIndex)

            Fomula.PRICE_YEAR8 = Fomula.PRICE_YEAR8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8) & strIndex)
            Fomula.PRICE_YEAR8 = Fomula.PRICE_YEAR8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8) & EndIndex)

            Fomula.PRICE_YEAR9 = Fomula.PRICE_YEAR9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9) & strIndex)
            Fomula.PRICE_YEAR9 = Fomula.PRICE_YEAR9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9) & EndIndex)

            Fomula.PRICE_YEAR10 = Fomula.PRICE_YEAR10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10) & strIndex)
            Fomula.PRICE_YEAR10 = Fomula.PRICE_YEAR10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10) & EndIndex)

            Fomula.PRICE_YEAR11 = Fomula.PRICE_YEAR11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11) & strIndex)
            Fomula.PRICE_YEAR11 = Fomula.PRICE_YEAR11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11) & EndIndex)

            Fomula.PRICE_YEAR12 = Fomula.PRICE_YEAR12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12) & strIndex)
            Fomula.PRICE_YEAR12 = Fomula.PRICE_YEAR12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12) & EndIndex)

            Fomula.PRICE_YEAR13 = Fomula.PRICE_YEAR13.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13) & strIndex)
            Fomula.PRICE_YEAR13 = Fomula.PRICE_YEAR13.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13) & EndIndex)

            Fomula.PRICE_YEAR14 = Fomula.PRICE_YEAR14.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14) & strIndex)
            Fomula.PRICE_YEAR14 = Fomula.PRICE_YEAR14.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14) & EndIndex)

            Fomula.PRICE_YEAR15 = Fomula.PRICE_YEAR15.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15) & strIndex)
            Fomula.PRICE_YEAR15 = Fomula.PRICE_YEAR15.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15) & EndIndex)

            Fomula.PRICE_YEAR16 = Fomula.PRICE_YEAR16.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16) & strIndex)
            Fomula.PRICE_YEAR16 = Fomula.PRICE_YEAR16.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16) & EndIndex)

            Fomula.PRICE_YEAR17 = Fomula.PRICE_YEAR17.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17) & strIndex)
            Fomula.PRICE_YEAR17 = Fomula.PRICE_YEAR17.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17) & EndIndex)

            Fomula.PRICE_YEAR18 = Fomula.PRICE_YEAR18.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18) & strIndex)
            Fomula.PRICE_YEAR18 = Fomula.PRICE_YEAR18.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18) & EndIndex)

            Fomula.PRICE_YEAR19 = Fomula.PRICE_YEAR19.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19) & strIndex)
            Fomula.PRICE_YEAR19 = Fomula.PRICE_YEAR19.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19) & EndIndex)

            Fomula.PRICE_YEAR20 = Fomula.PRICE_YEAR20.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20) & strIndex)
            Fomula.PRICE_YEAR20 = Fomula.PRICE_YEAR20.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20) & EndIndex)

            Fomula.PRICE_PAST_CONTRACT = Fomula.PRICE_PAST_CONTRACT.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_PAST_CONTRACT) & strIndex)
            Fomula.PRICE_PAST_CONTRACT = Fomula.PRICE_PAST_CONTRACT.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_PAST_CONTRACT) & EndIndex)

            ''月度金額
            Fomula.PRICE_YEAR1_MONTH1 = Fomula.PRICE_YEAR1_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH1) & strIndex)
            Fomula.PRICE_YEAR1_MONTH1 = Fomula.PRICE_YEAR1_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH2 = Fomula.PRICE_YEAR1_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH2) & strIndex)
            Fomula.PRICE_YEAR1_MONTH2 = Fomula.PRICE_YEAR1_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH3 = Fomula.PRICE_YEAR1_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH3) & strIndex)
            Fomula.PRICE_YEAR1_MONTH3 = Fomula.PRICE_YEAR1_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH4 = Fomula.PRICE_YEAR1_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH4) & strIndex)
            Fomula.PRICE_YEAR1_MONTH4 = Fomula.PRICE_YEAR1_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH5 = Fomula.PRICE_YEAR1_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH5) & strIndex)
            Fomula.PRICE_YEAR1_MONTH5 = Fomula.PRICE_YEAR1_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH6 = Fomula.PRICE_YEAR1_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH6) & strIndex)
            Fomula.PRICE_YEAR1_MONTH6 = Fomula.PRICE_YEAR1_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH7 = Fomula.PRICE_YEAR1_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH7) & strIndex)
            Fomula.PRICE_YEAR1_MONTH7 = Fomula.PRICE_YEAR1_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH8 = Fomula.PRICE_YEAR1_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH8) & strIndex)
            Fomula.PRICE_YEAR1_MONTH8 = Fomula.PRICE_YEAR1_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH9 = Fomula.PRICE_YEAR1_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH9) & strIndex)
            Fomula.PRICE_YEAR1_MONTH9 = Fomula.PRICE_YEAR1_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH10 = Fomula.PRICE_YEAR1_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH10) & strIndex)
            Fomula.PRICE_YEAR1_MONTH10 = Fomula.PRICE_YEAR1_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH11 = Fomula.PRICE_YEAR1_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH11) & strIndex)
            Fomula.PRICE_YEAR1_MONTH11 = Fomula.PRICE_YEAR1_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH12 = Fomula.PRICE_YEAR1_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH12) & strIndex)
            Fomula.PRICE_YEAR1_MONTH12 = Fomula.PRICE_YEAR1_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH1 = Fomula.PRICE_YEAR2_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH1) & strIndex)
            Fomula.PRICE_YEAR2_MONTH1 = Fomula.PRICE_YEAR2_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH2 = Fomula.PRICE_YEAR2_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH2) & strIndex)
            Fomula.PRICE_YEAR2_MONTH2 = Fomula.PRICE_YEAR2_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH3 = Fomula.PRICE_YEAR2_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH3) & strIndex)
            Fomula.PRICE_YEAR2_MONTH3 = Fomula.PRICE_YEAR2_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH4 = Fomula.PRICE_YEAR2_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH4) & strIndex)
            Fomula.PRICE_YEAR2_MONTH4 = Fomula.PRICE_YEAR2_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH5 = Fomula.PRICE_YEAR2_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH5) & strIndex)
            Fomula.PRICE_YEAR2_MONTH5 = Fomula.PRICE_YEAR2_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH6 = Fomula.PRICE_YEAR2_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH6) & strIndex)
            Fomula.PRICE_YEAR2_MONTH6 = Fomula.PRICE_YEAR2_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH7 = Fomula.PRICE_YEAR2_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH7) & strIndex)
            Fomula.PRICE_YEAR2_MONTH7 = Fomula.PRICE_YEAR2_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH8 = Fomula.PRICE_YEAR2_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH8) & strIndex)
            Fomula.PRICE_YEAR2_MONTH8 = Fomula.PRICE_YEAR2_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH9 = Fomula.PRICE_YEAR2_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH9) & strIndex)
            Fomula.PRICE_YEAR2_MONTH9 = Fomula.PRICE_YEAR2_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH10 = Fomula.PRICE_YEAR2_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH10) & strIndex)
            Fomula.PRICE_YEAR2_MONTH10 = Fomula.PRICE_YEAR2_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH11 = Fomula.PRICE_YEAR2_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH11) & strIndex)
            Fomula.PRICE_YEAR2_MONTH11 = Fomula.PRICE_YEAR2_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH12 = Fomula.PRICE_YEAR2_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH12) & strIndex)
            Fomula.PRICE_YEAR2_MONTH12 = Fomula.PRICE_YEAR2_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH1 = Fomula.PRICE_YEAR3_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH1) & strIndex)
            Fomula.PRICE_YEAR3_MONTH1 = Fomula.PRICE_YEAR3_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH2 = Fomula.PRICE_YEAR3_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH2) & strIndex)
            Fomula.PRICE_YEAR3_MONTH2 = Fomula.PRICE_YEAR3_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH3 = Fomula.PRICE_YEAR3_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH3) & strIndex)
            Fomula.PRICE_YEAR3_MONTH3 = Fomula.PRICE_YEAR3_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH4 = Fomula.PRICE_YEAR3_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH4) & strIndex)
            Fomula.PRICE_YEAR3_MONTH4 = Fomula.PRICE_YEAR3_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH5 = Fomula.PRICE_YEAR3_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH5) & strIndex)
            Fomula.PRICE_YEAR3_MONTH5 = Fomula.PRICE_YEAR3_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH6 = Fomula.PRICE_YEAR3_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH6) & strIndex)
            Fomula.PRICE_YEAR3_MONTH6 = Fomula.PRICE_YEAR3_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH7 = Fomula.PRICE_YEAR3_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH7) & strIndex)
            Fomula.PRICE_YEAR3_MONTH7 = Fomula.PRICE_YEAR3_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH8 = Fomula.PRICE_YEAR3_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH8) & strIndex)
            Fomula.PRICE_YEAR3_MONTH8 = Fomula.PRICE_YEAR3_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH9 = Fomula.PRICE_YEAR3_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH9) & strIndex)
            Fomula.PRICE_YEAR3_MONTH9 = Fomula.PRICE_YEAR3_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH10 = Fomula.PRICE_YEAR3_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH10) & strIndex)
            Fomula.PRICE_YEAR3_MONTH10 = Fomula.PRICE_YEAR3_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH11 = Fomula.PRICE_YEAR3_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH11) & strIndex)
            Fomula.PRICE_YEAR3_MONTH11 = Fomula.PRICE_YEAR3_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH12 = Fomula.PRICE_YEAR3_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH12) & strIndex)
            Fomula.PRICE_YEAR3_MONTH12 = Fomula.PRICE_YEAR3_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH1 = Fomula.PRICE_YEAR4_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH1) & strIndex)
            Fomula.PRICE_YEAR4_MONTH1 = Fomula.PRICE_YEAR4_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH2 = Fomula.PRICE_YEAR4_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH2) & strIndex)
            Fomula.PRICE_YEAR4_MONTH2 = Fomula.PRICE_YEAR4_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH3 = Fomula.PRICE_YEAR4_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH3) & strIndex)
            Fomula.PRICE_YEAR4_MONTH3 = Fomula.PRICE_YEAR4_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH4 = Fomula.PRICE_YEAR4_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH4) & strIndex)
            Fomula.PRICE_YEAR4_MONTH4 = Fomula.PRICE_YEAR4_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH5 = Fomula.PRICE_YEAR4_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH5) & strIndex)
            Fomula.PRICE_YEAR4_MONTH5 = Fomula.PRICE_YEAR4_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH6 = Fomula.PRICE_YEAR4_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH6) & strIndex)
            Fomula.PRICE_YEAR4_MONTH6 = Fomula.PRICE_YEAR4_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH7 = Fomula.PRICE_YEAR4_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH7) & strIndex)
            Fomula.PRICE_YEAR4_MONTH7 = Fomula.PRICE_YEAR4_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH8 = Fomula.PRICE_YEAR4_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH8) & strIndex)
            Fomula.PRICE_YEAR4_MONTH8 = Fomula.PRICE_YEAR4_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH9 = Fomula.PRICE_YEAR4_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH9) & strIndex)
            Fomula.PRICE_YEAR4_MONTH9 = Fomula.PRICE_YEAR4_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH10 = Fomula.PRICE_YEAR4_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH10) & strIndex)
            Fomula.PRICE_YEAR4_MONTH10 = Fomula.PRICE_YEAR4_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH11 = Fomula.PRICE_YEAR4_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH11) & strIndex)
            Fomula.PRICE_YEAR4_MONTH11 = Fomula.PRICE_YEAR4_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH12 = Fomula.PRICE_YEAR4_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH12) & strIndex)
            Fomula.PRICE_YEAR4_MONTH12 = Fomula.PRICE_YEAR4_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH1 = Fomula.PRICE_YEAR5_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH1) & strIndex)
            Fomula.PRICE_YEAR5_MONTH1 = Fomula.PRICE_YEAR5_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH2 = Fomula.PRICE_YEAR5_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH2) & strIndex)
            Fomula.PRICE_YEAR5_MONTH2 = Fomula.PRICE_YEAR5_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH3 = Fomula.PRICE_YEAR5_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH3) & strIndex)
            Fomula.PRICE_YEAR5_MONTH3 = Fomula.PRICE_YEAR5_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH4 = Fomula.PRICE_YEAR5_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH4) & strIndex)
            Fomula.PRICE_YEAR5_MONTH4 = Fomula.PRICE_YEAR5_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH5 = Fomula.PRICE_YEAR5_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH5) & strIndex)
            Fomula.PRICE_YEAR5_MONTH5 = Fomula.PRICE_YEAR5_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH6 = Fomula.PRICE_YEAR5_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH6) & strIndex)
            Fomula.PRICE_YEAR5_MONTH6 = Fomula.PRICE_YEAR5_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH7 = Fomula.PRICE_YEAR5_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH7) & strIndex)
            Fomula.PRICE_YEAR5_MONTH7 = Fomula.PRICE_YEAR5_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH8 = Fomula.PRICE_YEAR5_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH8) & strIndex)
            Fomula.PRICE_YEAR5_MONTH8 = Fomula.PRICE_YEAR5_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH9 = Fomula.PRICE_YEAR5_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH9) & strIndex)
            Fomula.PRICE_YEAR5_MONTH9 = Fomula.PRICE_YEAR5_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH10 = Fomula.PRICE_YEAR5_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH10) & strIndex)
            Fomula.PRICE_YEAR5_MONTH10 = Fomula.PRICE_YEAR5_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH11 = Fomula.PRICE_YEAR5_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH11) & strIndex)
            Fomula.PRICE_YEAR5_MONTH11 = Fomula.PRICE_YEAR5_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH12 = Fomula.PRICE_YEAR5_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH12) & strIndex)
            Fomula.PRICE_YEAR5_MONTH12 = Fomula.PRICE_YEAR5_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH1 = Fomula.PRICE_YEAR6_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH1) & strIndex)
            Fomula.PRICE_YEAR6_MONTH1 = Fomula.PRICE_YEAR6_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH2 = Fomula.PRICE_YEAR6_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH2) & strIndex)
            Fomula.PRICE_YEAR6_MONTH2 = Fomula.PRICE_YEAR6_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH3 = Fomula.PRICE_YEAR6_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH3) & strIndex)
            Fomula.PRICE_YEAR6_MONTH3 = Fomula.PRICE_YEAR6_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH4 = Fomula.PRICE_YEAR6_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH4) & strIndex)
            Fomula.PRICE_YEAR6_MONTH4 = Fomula.PRICE_YEAR6_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH5 = Fomula.PRICE_YEAR6_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH5) & strIndex)
            Fomula.PRICE_YEAR6_MONTH5 = Fomula.PRICE_YEAR6_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH6 = Fomula.PRICE_YEAR6_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH6) & strIndex)
            Fomula.PRICE_YEAR6_MONTH6 = Fomula.PRICE_YEAR6_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH7 = Fomula.PRICE_YEAR6_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH7) & strIndex)
            Fomula.PRICE_YEAR6_MONTH7 = Fomula.PRICE_YEAR6_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH8 = Fomula.PRICE_YEAR6_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH8) & strIndex)
            Fomula.PRICE_YEAR6_MONTH8 = Fomula.PRICE_YEAR6_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH9 = Fomula.PRICE_YEAR6_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH9) & strIndex)
            Fomula.PRICE_YEAR6_MONTH9 = Fomula.PRICE_YEAR6_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH10 = Fomula.PRICE_YEAR6_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH10) & strIndex)
            Fomula.PRICE_YEAR6_MONTH10 = Fomula.PRICE_YEAR6_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH11 = Fomula.PRICE_YEAR6_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH11) & strIndex)
            Fomula.PRICE_YEAR6_MONTH11 = Fomula.PRICE_YEAR6_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH12 = Fomula.PRICE_YEAR6_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH12) & strIndex)
            Fomula.PRICE_YEAR6_MONTH12 = Fomula.PRICE_YEAR6_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH1 = Fomula.PRICE_YEAR7_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH1) & strIndex)
            Fomula.PRICE_YEAR7_MONTH1 = Fomula.PRICE_YEAR7_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH2 = Fomula.PRICE_YEAR7_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH2) & strIndex)
            Fomula.PRICE_YEAR7_MONTH2 = Fomula.PRICE_YEAR7_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH3 = Fomula.PRICE_YEAR7_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH3) & strIndex)
            Fomula.PRICE_YEAR7_MONTH3 = Fomula.PRICE_YEAR7_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH4 = Fomula.PRICE_YEAR7_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH4) & strIndex)
            Fomula.PRICE_YEAR7_MONTH4 = Fomula.PRICE_YEAR7_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH5 = Fomula.PRICE_YEAR7_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH5) & strIndex)
            Fomula.PRICE_YEAR7_MONTH5 = Fomula.PRICE_YEAR7_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH6 = Fomula.PRICE_YEAR7_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH6) & strIndex)
            Fomula.PRICE_YEAR7_MONTH6 = Fomula.PRICE_YEAR7_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH7 = Fomula.PRICE_YEAR7_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH7) & strIndex)
            Fomula.PRICE_YEAR7_MONTH7 = Fomula.PRICE_YEAR7_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH8 = Fomula.PRICE_YEAR7_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH8) & strIndex)
            Fomula.PRICE_YEAR7_MONTH8 = Fomula.PRICE_YEAR7_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH9 = Fomula.PRICE_YEAR7_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH9) & strIndex)
            Fomula.PRICE_YEAR7_MONTH9 = Fomula.PRICE_YEAR7_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH10 = Fomula.PRICE_YEAR7_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH10) & strIndex)
            Fomula.PRICE_YEAR7_MONTH10 = Fomula.PRICE_YEAR7_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH11 = Fomula.PRICE_YEAR7_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH11) & strIndex)
            Fomula.PRICE_YEAR7_MONTH11 = Fomula.PRICE_YEAR7_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH12 = Fomula.PRICE_YEAR7_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH12) & strIndex)
            Fomula.PRICE_YEAR7_MONTH12 = Fomula.PRICE_YEAR7_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH1 = Fomula.PRICE_YEAR8_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH1) & strIndex)
            Fomula.PRICE_YEAR8_MONTH1 = Fomula.PRICE_YEAR8_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH2 = Fomula.PRICE_YEAR8_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH2) & strIndex)
            Fomula.PRICE_YEAR8_MONTH2 = Fomula.PRICE_YEAR8_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH3 = Fomula.PRICE_YEAR8_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH3) & strIndex)
            Fomula.PRICE_YEAR8_MONTH3 = Fomula.PRICE_YEAR8_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH4 = Fomula.PRICE_YEAR8_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH4) & strIndex)
            Fomula.PRICE_YEAR8_MONTH4 = Fomula.PRICE_YEAR8_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH5 = Fomula.PRICE_YEAR8_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH5) & strIndex)
            Fomula.PRICE_YEAR8_MONTH5 = Fomula.PRICE_YEAR8_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH6 = Fomula.PRICE_YEAR8_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH6) & strIndex)
            Fomula.PRICE_YEAR8_MONTH6 = Fomula.PRICE_YEAR8_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH7 = Fomula.PRICE_YEAR8_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH7) & strIndex)
            Fomula.PRICE_YEAR8_MONTH7 = Fomula.PRICE_YEAR8_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH8 = Fomula.PRICE_YEAR8_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH8) & strIndex)
            Fomula.PRICE_YEAR8_MONTH8 = Fomula.PRICE_YEAR8_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH9 = Fomula.PRICE_YEAR8_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH9) & strIndex)
            Fomula.PRICE_YEAR8_MONTH9 = Fomula.PRICE_YEAR8_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH10 = Fomula.PRICE_YEAR8_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH10) & strIndex)
            Fomula.PRICE_YEAR8_MONTH10 = Fomula.PRICE_YEAR8_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH11 = Fomula.PRICE_YEAR8_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH11) & strIndex)
            Fomula.PRICE_YEAR8_MONTH11 = Fomula.PRICE_YEAR8_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH12 = Fomula.PRICE_YEAR8_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH12) & strIndex)
            Fomula.PRICE_YEAR8_MONTH12 = Fomula.PRICE_YEAR8_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH1 = Fomula.PRICE_YEAR9_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH1) & strIndex)
            Fomula.PRICE_YEAR9_MONTH1 = Fomula.PRICE_YEAR9_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH2 = Fomula.PRICE_YEAR9_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH2) & strIndex)
            Fomula.PRICE_YEAR9_MONTH2 = Fomula.PRICE_YEAR9_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH3 = Fomula.PRICE_YEAR9_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH3) & strIndex)
            Fomula.PRICE_YEAR9_MONTH3 = Fomula.PRICE_YEAR9_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH4 = Fomula.PRICE_YEAR9_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH4) & strIndex)
            Fomula.PRICE_YEAR9_MONTH4 = Fomula.PRICE_YEAR9_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH5 = Fomula.PRICE_YEAR9_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH5) & strIndex)
            Fomula.PRICE_YEAR9_MONTH5 = Fomula.PRICE_YEAR9_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH6 = Fomula.PRICE_YEAR9_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH6) & strIndex)
            Fomula.PRICE_YEAR9_MONTH6 = Fomula.PRICE_YEAR9_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH7 = Fomula.PRICE_YEAR9_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH7) & strIndex)
            Fomula.PRICE_YEAR9_MONTH7 = Fomula.PRICE_YEAR9_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH8 = Fomula.PRICE_YEAR9_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH8) & strIndex)
            Fomula.PRICE_YEAR9_MONTH8 = Fomula.PRICE_YEAR9_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH9 = Fomula.PRICE_YEAR9_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH9) & strIndex)
            Fomula.PRICE_YEAR9_MONTH9 = Fomula.PRICE_YEAR9_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH10 = Fomula.PRICE_YEAR9_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH10) & strIndex)
            Fomula.PRICE_YEAR9_MONTH10 = Fomula.PRICE_YEAR9_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH11 = Fomula.PRICE_YEAR9_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH11) & strIndex)
            Fomula.PRICE_YEAR9_MONTH11 = Fomula.PRICE_YEAR9_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH12 = Fomula.PRICE_YEAR9_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH12) & strIndex)
            Fomula.PRICE_YEAR9_MONTH12 = Fomula.PRICE_YEAR9_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH1 = Fomula.PRICE_YEAR10_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH1) & strIndex)
            Fomula.PRICE_YEAR10_MONTH1 = Fomula.PRICE_YEAR10_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH2 = Fomula.PRICE_YEAR10_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH2) & strIndex)
            Fomula.PRICE_YEAR10_MONTH2 = Fomula.PRICE_YEAR10_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH3 = Fomula.PRICE_YEAR10_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH3) & strIndex)
            Fomula.PRICE_YEAR10_MONTH3 = Fomula.PRICE_YEAR10_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH4 = Fomula.PRICE_YEAR10_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH4) & strIndex)
            Fomula.PRICE_YEAR10_MONTH4 = Fomula.PRICE_YEAR10_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH5 = Fomula.PRICE_YEAR10_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH5) & strIndex)
            Fomula.PRICE_YEAR10_MONTH5 = Fomula.PRICE_YEAR10_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH6 = Fomula.PRICE_YEAR10_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH6) & strIndex)
            Fomula.PRICE_YEAR10_MONTH6 = Fomula.PRICE_YEAR10_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH7 = Fomula.PRICE_YEAR10_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH7) & strIndex)
            Fomula.PRICE_YEAR10_MONTH7 = Fomula.PRICE_YEAR10_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH8 = Fomula.PRICE_YEAR10_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH8) & strIndex)
            Fomula.PRICE_YEAR10_MONTH8 = Fomula.PRICE_YEAR10_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH9 = Fomula.PRICE_YEAR10_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH9) & strIndex)
            Fomula.PRICE_YEAR10_MONTH9 = Fomula.PRICE_YEAR10_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH10 = Fomula.PRICE_YEAR10_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH10) & strIndex)
            Fomula.PRICE_YEAR10_MONTH10 = Fomula.PRICE_YEAR10_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH11 = Fomula.PRICE_YEAR10_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH11) & strIndex)
            Fomula.PRICE_YEAR10_MONTH11 = Fomula.PRICE_YEAR10_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH12 = Fomula.PRICE_YEAR10_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH12) & strIndex)
            Fomula.PRICE_YEAR10_MONTH12 = Fomula.PRICE_YEAR10_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH1 = Fomula.PRICE_YEAR11_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH1) & strIndex)
            Fomula.PRICE_YEAR11_MONTH1 = Fomula.PRICE_YEAR11_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH2 = Fomula.PRICE_YEAR11_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH2) & strIndex)
            Fomula.PRICE_YEAR11_MONTH2 = Fomula.PRICE_YEAR11_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH3 = Fomula.PRICE_YEAR11_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH3) & strIndex)
            Fomula.PRICE_YEAR11_MONTH3 = Fomula.PRICE_YEAR11_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH4 = Fomula.PRICE_YEAR11_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH4) & strIndex)
            Fomula.PRICE_YEAR11_MONTH4 = Fomula.PRICE_YEAR11_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH5 = Fomula.PRICE_YEAR11_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH5) & strIndex)
            Fomula.PRICE_YEAR11_MONTH5 = Fomula.PRICE_YEAR11_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH6 = Fomula.PRICE_YEAR11_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH6) & strIndex)
            Fomula.PRICE_YEAR11_MONTH6 = Fomula.PRICE_YEAR11_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH7 = Fomula.PRICE_YEAR11_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH7) & strIndex)
            Fomula.PRICE_YEAR11_MONTH7 = Fomula.PRICE_YEAR11_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH8 = Fomula.PRICE_YEAR11_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH8) & strIndex)
            Fomula.PRICE_YEAR11_MONTH8 = Fomula.PRICE_YEAR11_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH9 = Fomula.PRICE_YEAR11_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH9) & strIndex)
            Fomula.PRICE_YEAR11_MONTH9 = Fomula.PRICE_YEAR11_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH10 = Fomula.PRICE_YEAR11_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH10) & strIndex)
            Fomula.PRICE_YEAR11_MONTH10 = Fomula.PRICE_YEAR11_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH11 = Fomula.PRICE_YEAR11_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH11) & strIndex)
            Fomula.PRICE_YEAR11_MONTH11 = Fomula.PRICE_YEAR11_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH12 = Fomula.PRICE_YEAR11_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH12) & strIndex)
            Fomula.PRICE_YEAR11_MONTH12 = Fomula.PRICE_YEAR11_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH1 = Fomula.PRICE_YEAR12_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH1) & strIndex)
            Fomula.PRICE_YEAR12_MONTH1 = Fomula.PRICE_YEAR12_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH2 = Fomula.PRICE_YEAR12_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH2) & strIndex)
            Fomula.PRICE_YEAR12_MONTH2 = Fomula.PRICE_YEAR12_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH3 = Fomula.PRICE_YEAR12_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH3) & strIndex)
            Fomula.PRICE_YEAR12_MONTH3 = Fomula.PRICE_YEAR12_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH4 = Fomula.PRICE_YEAR12_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH4) & strIndex)
            Fomula.PRICE_YEAR12_MONTH4 = Fomula.PRICE_YEAR12_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH5 = Fomula.PRICE_YEAR12_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH5) & strIndex)
            Fomula.PRICE_YEAR12_MONTH5 = Fomula.PRICE_YEAR12_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH6 = Fomula.PRICE_YEAR12_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH6) & strIndex)
            Fomula.PRICE_YEAR12_MONTH6 = Fomula.PRICE_YEAR12_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH7 = Fomula.PRICE_YEAR12_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH7) & strIndex)
            Fomula.PRICE_YEAR12_MONTH7 = Fomula.PRICE_YEAR12_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH8 = Fomula.PRICE_YEAR12_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH8) & strIndex)
            Fomula.PRICE_YEAR12_MONTH8 = Fomula.PRICE_YEAR12_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH9 = Fomula.PRICE_YEAR12_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH9) & strIndex)
            Fomula.PRICE_YEAR12_MONTH9 = Fomula.PRICE_YEAR12_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH10 = Fomula.PRICE_YEAR12_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH10) & strIndex)
            Fomula.PRICE_YEAR12_MONTH10 = Fomula.PRICE_YEAR12_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH11 = Fomula.PRICE_YEAR12_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH11) & strIndex)
            Fomula.PRICE_YEAR12_MONTH11 = Fomula.PRICE_YEAR12_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH12 = Fomula.PRICE_YEAR12_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH12) & strIndex)
            Fomula.PRICE_YEAR12_MONTH12 = Fomula.PRICE_YEAR12_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR13_MONTH1 = Fomula.PRICE_YEAR13_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH1) & strIndex)
            Fomula.PRICE_YEAR13_MONTH1 = Fomula.PRICE_YEAR13_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH1) & EndIndex)
            Fomula.PRICE_YEAR13_MONTH2 = Fomula.PRICE_YEAR13_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH2) & strIndex)
            Fomula.PRICE_YEAR13_MONTH2 = Fomula.PRICE_YEAR13_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH2) & EndIndex)
            Fomula.PRICE_YEAR13_MONTH3 = Fomula.PRICE_YEAR13_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH3) & strIndex)
            Fomula.PRICE_YEAR13_MONTH3 = Fomula.PRICE_YEAR13_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH3) & EndIndex)
            Fomula.PRICE_YEAR13_MONTH4 = Fomula.PRICE_YEAR13_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH4) & strIndex)
            Fomula.PRICE_YEAR13_MONTH4 = Fomula.PRICE_YEAR13_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH4) & EndIndex)
            Fomula.PRICE_YEAR13_MONTH5 = Fomula.PRICE_YEAR13_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH5) & strIndex)
            Fomula.PRICE_YEAR13_MONTH5 = Fomula.PRICE_YEAR13_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH5) & EndIndex)
            Fomula.PRICE_YEAR13_MONTH6 = Fomula.PRICE_YEAR13_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH6) & strIndex)
            Fomula.PRICE_YEAR13_MONTH6 = Fomula.PRICE_YEAR13_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH6) & EndIndex)
            Fomula.PRICE_YEAR13_MONTH7 = Fomula.PRICE_YEAR13_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH7) & strIndex)
            Fomula.PRICE_YEAR13_MONTH7 = Fomula.PRICE_YEAR13_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH7) & EndIndex)
            Fomula.PRICE_YEAR13_MONTH8 = Fomula.PRICE_YEAR13_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH8) & strIndex)
            Fomula.PRICE_YEAR13_MONTH8 = Fomula.PRICE_YEAR13_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH8) & EndIndex)
            Fomula.PRICE_YEAR13_MONTH9 = Fomula.PRICE_YEAR13_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH9) & strIndex)
            Fomula.PRICE_YEAR13_MONTH9 = Fomula.PRICE_YEAR13_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH9) & EndIndex)
            Fomula.PRICE_YEAR13_MONTH10 = Fomula.PRICE_YEAR13_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH10) & strIndex)
            Fomula.PRICE_YEAR13_MONTH10 = Fomula.PRICE_YEAR13_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH10) & EndIndex)
            Fomula.PRICE_YEAR13_MONTH11 = Fomula.PRICE_YEAR13_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH11) & strIndex)
            Fomula.PRICE_YEAR13_MONTH11 = Fomula.PRICE_YEAR13_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH11) & EndIndex)
            Fomula.PRICE_YEAR13_MONTH12 = Fomula.PRICE_YEAR13_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH12) & strIndex)
            Fomula.PRICE_YEAR13_MONTH12 = Fomula.PRICE_YEAR13_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR14_MONTH1 = Fomula.PRICE_YEAR14_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH1) & strIndex)
            Fomula.PRICE_YEAR14_MONTH1 = Fomula.PRICE_YEAR14_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH1) & EndIndex)
            Fomula.PRICE_YEAR14_MONTH2 = Fomula.PRICE_YEAR14_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH2) & strIndex)
            Fomula.PRICE_YEAR14_MONTH2 = Fomula.PRICE_YEAR14_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH2) & EndIndex)
            Fomula.PRICE_YEAR14_MONTH3 = Fomula.PRICE_YEAR14_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH3) & strIndex)
            Fomula.PRICE_YEAR14_MONTH3 = Fomula.PRICE_YEAR14_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH3) & EndIndex)
            Fomula.PRICE_YEAR14_MONTH4 = Fomula.PRICE_YEAR14_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH4) & strIndex)
            Fomula.PRICE_YEAR14_MONTH4 = Fomula.PRICE_YEAR14_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH4) & EndIndex)
            Fomula.PRICE_YEAR14_MONTH5 = Fomula.PRICE_YEAR14_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH5) & strIndex)
            Fomula.PRICE_YEAR14_MONTH5 = Fomula.PRICE_YEAR14_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH5) & EndIndex)
            Fomula.PRICE_YEAR14_MONTH6 = Fomula.PRICE_YEAR14_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH6) & strIndex)
            Fomula.PRICE_YEAR14_MONTH6 = Fomula.PRICE_YEAR14_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH6) & EndIndex)
            Fomula.PRICE_YEAR14_MONTH7 = Fomula.PRICE_YEAR14_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH7) & strIndex)
            Fomula.PRICE_YEAR14_MONTH7 = Fomula.PRICE_YEAR14_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH7) & EndIndex)
            Fomula.PRICE_YEAR14_MONTH8 = Fomula.PRICE_YEAR14_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH8) & strIndex)
            Fomula.PRICE_YEAR14_MONTH8 = Fomula.PRICE_YEAR14_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH8) & EndIndex)
            Fomula.PRICE_YEAR14_MONTH9 = Fomula.PRICE_YEAR14_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH9) & strIndex)
            Fomula.PRICE_YEAR14_MONTH9 = Fomula.PRICE_YEAR14_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH9) & EndIndex)
            Fomula.PRICE_YEAR14_MONTH10 = Fomula.PRICE_YEAR14_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH10) & strIndex)
            Fomula.PRICE_YEAR14_MONTH10 = Fomula.PRICE_YEAR14_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH10) & EndIndex)
            Fomula.PRICE_YEAR14_MONTH11 = Fomula.PRICE_YEAR14_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH11) & strIndex)
            Fomula.PRICE_YEAR14_MONTH11 = Fomula.PRICE_YEAR14_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH11) & EndIndex)
            Fomula.PRICE_YEAR14_MONTH12 = Fomula.PRICE_YEAR14_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH12) & strIndex)
            Fomula.PRICE_YEAR14_MONTH12 = Fomula.PRICE_YEAR14_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR15_MONTH1 = Fomula.PRICE_YEAR15_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH1) & strIndex)
            Fomula.PRICE_YEAR15_MONTH1 = Fomula.PRICE_YEAR15_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH1) & EndIndex)
            Fomula.PRICE_YEAR15_MONTH2 = Fomula.PRICE_YEAR15_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH2) & strIndex)
            Fomula.PRICE_YEAR15_MONTH2 = Fomula.PRICE_YEAR15_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH2) & EndIndex)
            Fomula.PRICE_YEAR15_MONTH3 = Fomula.PRICE_YEAR15_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH3) & strIndex)
            Fomula.PRICE_YEAR15_MONTH3 = Fomula.PRICE_YEAR15_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH3) & EndIndex)
            Fomula.PRICE_YEAR15_MONTH4 = Fomula.PRICE_YEAR15_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH4) & strIndex)
            Fomula.PRICE_YEAR15_MONTH4 = Fomula.PRICE_YEAR15_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH4) & EndIndex)
            Fomula.PRICE_YEAR15_MONTH5 = Fomula.PRICE_YEAR15_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH5) & strIndex)
            Fomula.PRICE_YEAR15_MONTH5 = Fomula.PRICE_YEAR15_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH5) & EndIndex)
            Fomula.PRICE_YEAR15_MONTH6 = Fomula.PRICE_YEAR15_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH6) & strIndex)
            Fomula.PRICE_YEAR15_MONTH6 = Fomula.PRICE_YEAR15_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH6) & EndIndex)
            Fomula.PRICE_YEAR15_MONTH7 = Fomula.PRICE_YEAR15_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH7) & strIndex)
            Fomula.PRICE_YEAR15_MONTH7 = Fomula.PRICE_YEAR15_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH7) & EndIndex)
            Fomula.PRICE_YEAR15_MONTH8 = Fomula.PRICE_YEAR15_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH8) & strIndex)
            Fomula.PRICE_YEAR15_MONTH8 = Fomula.PRICE_YEAR15_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH8) & EndIndex)
            Fomula.PRICE_YEAR15_MONTH9 = Fomula.PRICE_YEAR15_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH9) & strIndex)
            Fomula.PRICE_YEAR15_MONTH9 = Fomula.PRICE_YEAR15_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH9) & EndIndex)
            Fomula.PRICE_YEAR15_MONTH10 = Fomula.PRICE_YEAR15_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH10) & strIndex)
            Fomula.PRICE_YEAR15_MONTH10 = Fomula.PRICE_YEAR15_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH10) & EndIndex)
            Fomula.PRICE_YEAR15_MONTH11 = Fomula.PRICE_YEAR15_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH11) & strIndex)
            Fomula.PRICE_YEAR15_MONTH11 = Fomula.PRICE_YEAR15_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH11) & EndIndex)
            Fomula.PRICE_YEAR15_MONTH12 = Fomula.PRICE_YEAR15_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH12) & strIndex)
            Fomula.PRICE_YEAR15_MONTH12 = Fomula.PRICE_YEAR15_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR16_MONTH1 = Fomula.PRICE_YEAR16_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH1) & strIndex)
            Fomula.PRICE_YEAR16_MONTH1 = Fomula.PRICE_YEAR16_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH1) & EndIndex)
            Fomula.PRICE_YEAR16_MONTH2 = Fomula.PRICE_YEAR16_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH2) & strIndex)
            Fomula.PRICE_YEAR16_MONTH2 = Fomula.PRICE_YEAR16_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH2) & EndIndex)
            Fomula.PRICE_YEAR16_MONTH3 = Fomula.PRICE_YEAR16_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH3) & strIndex)
            Fomula.PRICE_YEAR16_MONTH3 = Fomula.PRICE_YEAR16_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH3) & EndIndex)
            Fomula.PRICE_YEAR16_MONTH4 = Fomula.PRICE_YEAR16_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH4) & strIndex)
            Fomula.PRICE_YEAR16_MONTH4 = Fomula.PRICE_YEAR16_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH4) & EndIndex)
            Fomula.PRICE_YEAR16_MONTH5 = Fomula.PRICE_YEAR16_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH5) & strIndex)
            Fomula.PRICE_YEAR16_MONTH5 = Fomula.PRICE_YEAR16_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH5) & EndIndex)
            Fomula.PRICE_YEAR16_MONTH6 = Fomula.PRICE_YEAR16_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH6) & strIndex)
            Fomula.PRICE_YEAR16_MONTH6 = Fomula.PRICE_YEAR16_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH6) & EndIndex)
            Fomula.PRICE_YEAR16_MONTH7 = Fomula.PRICE_YEAR16_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH7) & strIndex)
            Fomula.PRICE_YEAR16_MONTH7 = Fomula.PRICE_YEAR16_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH7) & EndIndex)
            Fomula.PRICE_YEAR16_MONTH8 = Fomula.PRICE_YEAR16_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH8) & strIndex)
            Fomula.PRICE_YEAR16_MONTH8 = Fomula.PRICE_YEAR16_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH8) & EndIndex)
            Fomula.PRICE_YEAR16_MONTH9 = Fomula.PRICE_YEAR16_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH9) & strIndex)
            Fomula.PRICE_YEAR16_MONTH9 = Fomula.PRICE_YEAR16_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH9) & EndIndex)
            Fomula.PRICE_YEAR16_MONTH10 = Fomula.PRICE_YEAR16_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH10) & strIndex)
            Fomula.PRICE_YEAR16_MONTH10 = Fomula.PRICE_YEAR16_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH10) & EndIndex)
            Fomula.PRICE_YEAR16_MONTH11 = Fomula.PRICE_YEAR16_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH11) & strIndex)
            Fomula.PRICE_YEAR16_MONTH11 = Fomula.PRICE_YEAR16_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH11) & EndIndex)
            Fomula.PRICE_YEAR16_MONTH12 = Fomula.PRICE_YEAR16_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH12) & strIndex)
            Fomula.PRICE_YEAR16_MONTH12 = Fomula.PRICE_YEAR16_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR17_MONTH1 = Fomula.PRICE_YEAR17_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH1) & strIndex)
            Fomula.PRICE_YEAR17_MONTH1 = Fomula.PRICE_YEAR17_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH1) & EndIndex)
            Fomula.PRICE_YEAR17_MONTH2 = Fomula.PRICE_YEAR17_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH2) & strIndex)
            Fomula.PRICE_YEAR17_MONTH2 = Fomula.PRICE_YEAR17_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH2) & EndIndex)
            Fomula.PRICE_YEAR17_MONTH3 = Fomula.PRICE_YEAR17_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH3) & strIndex)
            Fomula.PRICE_YEAR17_MONTH3 = Fomula.PRICE_YEAR17_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH3) & EndIndex)
            Fomula.PRICE_YEAR17_MONTH4 = Fomula.PRICE_YEAR17_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH4) & strIndex)
            Fomula.PRICE_YEAR17_MONTH4 = Fomula.PRICE_YEAR17_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH4) & EndIndex)
            Fomula.PRICE_YEAR17_MONTH5 = Fomula.PRICE_YEAR17_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH5) & strIndex)
            Fomula.PRICE_YEAR17_MONTH5 = Fomula.PRICE_YEAR17_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH5) & EndIndex)
            Fomula.PRICE_YEAR17_MONTH6 = Fomula.PRICE_YEAR17_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH6) & strIndex)
            Fomula.PRICE_YEAR17_MONTH6 = Fomula.PRICE_YEAR17_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH6) & EndIndex)
            Fomula.PRICE_YEAR17_MONTH7 = Fomula.PRICE_YEAR17_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH7) & strIndex)
            Fomula.PRICE_YEAR17_MONTH7 = Fomula.PRICE_YEAR17_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH7) & EndIndex)
            Fomula.PRICE_YEAR17_MONTH8 = Fomula.PRICE_YEAR17_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH8) & strIndex)
            Fomula.PRICE_YEAR17_MONTH8 = Fomula.PRICE_YEAR17_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH8) & EndIndex)
            Fomula.PRICE_YEAR17_MONTH9 = Fomula.PRICE_YEAR17_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH9) & strIndex)
            Fomula.PRICE_YEAR17_MONTH9 = Fomula.PRICE_YEAR17_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH9) & EndIndex)
            Fomula.PRICE_YEAR17_MONTH10 = Fomula.PRICE_YEAR17_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH10) & strIndex)
            Fomula.PRICE_YEAR17_MONTH10 = Fomula.PRICE_YEAR17_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH10) & EndIndex)
            Fomula.PRICE_YEAR17_MONTH11 = Fomula.PRICE_YEAR17_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH11) & strIndex)
            Fomula.PRICE_YEAR17_MONTH11 = Fomula.PRICE_YEAR17_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH11) & EndIndex)
            Fomula.PRICE_YEAR17_MONTH12 = Fomula.PRICE_YEAR17_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH12) & strIndex)
            Fomula.PRICE_YEAR17_MONTH12 = Fomula.PRICE_YEAR17_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR18_MONTH1 = Fomula.PRICE_YEAR18_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH1) & strIndex)
            Fomula.PRICE_YEAR18_MONTH1 = Fomula.PRICE_YEAR18_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH1) & EndIndex)
            Fomula.PRICE_YEAR18_MONTH2 = Fomula.PRICE_YEAR18_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH2) & strIndex)
            Fomula.PRICE_YEAR18_MONTH2 = Fomula.PRICE_YEAR18_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH2) & EndIndex)
            Fomula.PRICE_YEAR18_MONTH3 = Fomula.PRICE_YEAR18_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH3) & strIndex)
            Fomula.PRICE_YEAR18_MONTH3 = Fomula.PRICE_YEAR18_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH3) & EndIndex)
            Fomula.PRICE_YEAR18_MONTH4 = Fomula.PRICE_YEAR18_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH4) & strIndex)
            Fomula.PRICE_YEAR18_MONTH4 = Fomula.PRICE_YEAR18_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH4) & EndIndex)
            Fomula.PRICE_YEAR18_MONTH5 = Fomula.PRICE_YEAR18_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH5) & strIndex)
            Fomula.PRICE_YEAR18_MONTH5 = Fomula.PRICE_YEAR18_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH5) & EndIndex)
            Fomula.PRICE_YEAR18_MONTH6 = Fomula.PRICE_YEAR18_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH6) & strIndex)
            Fomula.PRICE_YEAR18_MONTH6 = Fomula.PRICE_YEAR18_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH6) & EndIndex)
            Fomula.PRICE_YEAR18_MONTH7 = Fomula.PRICE_YEAR18_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH7) & strIndex)
            Fomula.PRICE_YEAR18_MONTH7 = Fomula.PRICE_YEAR18_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH7) & EndIndex)
            Fomula.PRICE_YEAR18_MONTH8 = Fomula.PRICE_YEAR18_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH8) & strIndex)
            Fomula.PRICE_YEAR18_MONTH8 = Fomula.PRICE_YEAR18_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH8) & EndIndex)
            Fomula.PRICE_YEAR18_MONTH9 = Fomula.PRICE_YEAR18_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH9) & strIndex)
            Fomula.PRICE_YEAR18_MONTH9 = Fomula.PRICE_YEAR18_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH9) & EndIndex)
            Fomula.PRICE_YEAR18_MONTH10 = Fomula.PRICE_YEAR18_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH10) & strIndex)
            Fomula.PRICE_YEAR18_MONTH10 = Fomula.PRICE_YEAR18_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH10) & EndIndex)
            Fomula.PRICE_YEAR18_MONTH11 = Fomula.PRICE_YEAR18_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH11) & strIndex)
            Fomula.PRICE_YEAR18_MONTH11 = Fomula.PRICE_YEAR18_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH11) & EndIndex)
            Fomula.PRICE_YEAR18_MONTH12 = Fomula.PRICE_YEAR18_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH12) & strIndex)
            Fomula.PRICE_YEAR18_MONTH12 = Fomula.PRICE_YEAR18_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR19_MONTH1 = Fomula.PRICE_YEAR19_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH1) & strIndex)
            Fomula.PRICE_YEAR19_MONTH1 = Fomula.PRICE_YEAR19_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH1) & EndIndex)
            Fomula.PRICE_YEAR19_MONTH2 = Fomula.PRICE_YEAR19_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH2) & strIndex)
            Fomula.PRICE_YEAR19_MONTH2 = Fomula.PRICE_YEAR19_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH2) & EndIndex)
            Fomula.PRICE_YEAR19_MONTH3 = Fomula.PRICE_YEAR19_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH3) & strIndex)
            Fomula.PRICE_YEAR19_MONTH3 = Fomula.PRICE_YEAR19_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH3) & EndIndex)
            Fomula.PRICE_YEAR19_MONTH4 = Fomula.PRICE_YEAR19_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH4) & strIndex)
            Fomula.PRICE_YEAR19_MONTH4 = Fomula.PRICE_YEAR19_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH4) & EndIndex)
            Fomula.PRICE_YEAR19_MONTH5 = Fomula.PRICE_YEAR19_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH5) & strIndex)
            Fomula.PRICE_YEAR19_MONTH5 = Fomula.PRICE_YEAR19_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH5) & EndIndex)
            Fomula.PRICE_YEAR19_MONTH6 = Fomula.PRICE_YEAR19_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH6) & strIndex)
            Fomula.PRICE_YEAR19_MONTH6 = Fomula.PRICE_YEAR19_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH6) & EndIndex)
            Fomula.PRICE_YEAR19_MONTH7 = Fomula.PRICE_YEAR19_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH7) & strIndex)
            Fomula.PRICE_YEAR19_MONTH7 = Fomula.PRICE_YEAR19_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH7) & EndIndex)
            Fomula.PRICE_YEAR19_MONTH8 = Fomula.PRICE_YEAR19_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH8) & strIndex)
            Fomula.PRICE_YEAR19_MONTH8 = Fomula.PRICE_YEAR19_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH8) & EndIndex)
            Fomula.PRICE_YEAR19_MONTH9 = Fomula.PRICE_YEAR19_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH9) & strIndex)
            Fomula.PRICE_YEAR19_MONTH9 = Fomula.PRICE_YEAR19_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH9) & EndIndex)
            Fomula.PRICE_YEAR19_MONTH10 = Fomula.PRICE_YEAR19_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH10) & strIndex)
            Fomula.PRICE_YEAR19_MONTH10 = Fomula.PRICE_YEAR19_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH10) & EndIndex)
            Fomula.PRICE_YEAR19_MONTH11 = Fomula.PRICE_YEAR19_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH11) & strIndex)
            Fomula.PRICE_YEAR19_MONTH11 = Fomula.PRICE_YEAR19_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH11) & EndIndex)
            Fomula.PRICE_YEAR19_MONTH12 = Fomula.PRICE_YEAR19_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH12) & strIndex)
            Fomula.PRICE_YEAR19_MONTH12 = Fomula.PRICE_YEAR19_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR20_MONTH1 = Fomula.PRICE_YEAR20_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH1) & strIndex)
            Fomula.PRICE_YEAR20_MONTH1 = Fomula.PRICE_YEAR20_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH1) & EndIndex)
            Fomula.PRICE_YEAR20_MONTH2 = Fomula.PRICE_YEAR20_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH2) & strIndex)
            Fomula.PRICE_YEAR20_MONTH2 = Fomula.PRICE_YEAR20_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH2) & EndIndex)
            Fomula.PRICE_YEAR20_MONTH3 = Fomula.PRICE_YEAR20_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH3) & strIndex)
            Fomula.PRICE_YEAR20_MONTH3 = Fomula.PRICE_YEAR20_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH3) & EndIndex)
            Fomula.PRICE_YEAR20_MONTH4 = Fomula.PRICE_YEAR20_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH4) & strIndex)
            Fomula.PRICE_YEAR20_MONTH4 = Fomula.PRICE_YEAR20_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH4) & EndIndex)
            Fomula.PRICE_YEAR20_MONTH5 = Fomula.PRICE_YEAR20_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH5) & strIndex)
            Fomula.PRICE_YEAR20_MONTH5 = Fomula.PRICE_YEAR20_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH5) & EndIndex)
            Fomula.PRICE_YEAR20_MONTH6 = Fomula.PRICE_YEAR20_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH6) & strIndex)
            Fomula.PRICE_YEAR20_MONTH6 = Fomula.PRICE_YEAR20_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH6) & EndIndex)
            Fomula.PRICE_YEAR20_MONTH7 = Fomula.PRICE_YEAR20_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH7) & strIndex)
            Fomula.PRICE_YEAR20_MONTH7 = Fomula.PRICE_YEAR20_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH7) & EndIndex)
            Fomula.PRICE_YEAR20_MONTH8 = Fomula.PRICE_YEAR20_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH8) & strIndex)
            Fomula.PRICE_YEAR20_MONTH8 = Fomula.PRICE_YEAR20_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH8) & EndIndex)
            Fomula.PRICE_YEAR20_MONTH9 = Fomula.PRICE_YEAR20_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH9) & strIndex)
            Fomula.PRICE_YEAR20_MONTH9 = Fomula.PRICE_YEAR20_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH9) & EndIndex)
            Fomula.PRICE_YEAR20_MONTH10 = Fomula.PRICE_YEAR20_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH10) & strIndex)
            Fomula.PRICE_YEAR20_MONTH10 = Fomula.PRICE_YEAR20_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH10) & EndIndex)
            Fomula.PRICE_YEAR20_MONTH11 = Fomula.PRICE_YEAR20_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH11) & strIndex)
            Fomula.PRICE_YEAR20_MONTH11 = Fomula.PRICE_YEAR20_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH11) & EndIndex)
            Fomula.PRICE_YEAR20_MONTH12 = Fomula.PRICE_YEAR20_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH12) & strIndex)
            Fomula.PRICE_YEAR20_MONTH12 = Fomula.PRICE_YEAR20_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH12) & EndIndex)

            ''式のセット
            ''期間合計
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_IOC) = Fomula.ListPrice
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_TOTAL_IOC) = Fomula.DPerAfter
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.COST_TOTAL_IOC) = Fomula.DPerAfterrate
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT_IN) = Fomula.PRICE_CONT_TOTAL
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT_OUT) = Fomula.PRICE_OO_CONT_TOTAL
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1) = Fomula.IGF

            ''年度金額
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1 + 1) = Fomula.PRICE_YEAR1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2 + 1) = Fomula.PRICE_YEAR2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3 + 1) = Fomula.PRICE_YEAR3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4 + 1) = Fomula.PRICE_YEAR4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5 + 1) = Fomula.PRICE_YEAR5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6 + 1) = Fomula.PRICE_YEAR6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7 + 1) = Fomula.PRICE_YEAR7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8 + 1) = Fomula.PRICE_YEAR8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9 + 1) = Fomula.PRICE_YEAR9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10 + 1) = Fomula.PRICE_YEAR10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11 + 1) = Fomula.PRICE_YEAR11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12 + 1) = Fomula.PRICE_YEAR12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13 + 1) = Fomula.PRICE_YEAR13
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14 + 1) = Fomula.PRICE_YEAR14
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15 + 1) = Fomula.PRICE_YEAR15
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16 + 1) = Fomula.PRICE_YEAR16
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17 + 1) = Fomula.PRICE_YEAR17
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18 + 1) = Fomula.PRICE_YEAR18
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19 + 1) = Fomula.PRICE_YEAR19
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20 + 1) = Fomula.PRICE_YEAR20
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL + 1) = Fomula.PRICE_PAST_CONTRACT

            ''月度金額
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1 + 1) = Fomula.PRICE_YEAR1_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH2 + 1) = Fomula.PRICE_YEAR1_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH3 + 1) = Fomula.PRICE_YEAR1_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH4 + 1) = Fomula.PRICE_YEAR1_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH5 + 1) = Fomula.PRICE_YEAR1_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH6 + 1) = Fomula.PRICE_YEAR1_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH7 + 1) = Fomula.PRICE_YEAR1_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH8 + 1) = Fomula.PRICE_YEAR1_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH9 + 1) = Fomula.PRICE_YEAR1_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH10 + 1) = Fomula.PRICE_YEAR1_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH11 + 1) = Fomula.PRICE_YEAR1_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH12 + 1) = Fomula.PRICE_YEAR1_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH1 + 1) = Fomula.PRICE_YEAR2_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH2 + 1) = Fomula.PRICE_YEAR2_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH3 + 1) = Fomula.PRICE_YEAR2_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH4 + 1) = Fomula.PRICE_YEAR2_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH5 + 1) = Fomula.PRICE_YEAR2_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH6 + 1) = Fomula.PRICE_YEAR2_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH7 + 1) = Fomula.PRICE_YEAR2_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH8 + 1) = Fomula.PRICE_YEAR2_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH9 + 1) = Fomula.PRICE_YEAR2_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH10 + 1) = Fomula.PRICE_YEAR2_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH11 + 1) = Fomula.PRICE_YEAR2_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH12 + 1) = Fomula.PRICE_YEAR2_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH1 + 1) = Fomula.PRICE_YEAR3_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH2 + 1) = Fomula.PRICE_YEAR3_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH3 + 1) = Fomula.PRICE_YEAR3_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH4 + 1) = Fomula.PRICE_YEAR3_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH5 + 1) = Fomula.PRICE_YEAR3_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH6 + 1) = Fomula.PRICE_YEAR3_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH7 + 1) = Fomula.PRICE_YEAR3_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH8 + 1) = Fomula.PRICE_YEAR3_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH9 + 1) = Fomula.PRICE_YEAR3_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH10 + 1) = Fomula.PRICE_YEAR3_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH11 + 1) = Fomula.PRICE_YEAR3_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH12 + 1) = Fomula.PRICE_YEAR3_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH1 + 1) = Fomula.PRICE_YEAR4_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH2 + 1) = Fomula.PRICE_YEAR4_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH3 + 1) = Fomula.PRICE_YEAR4_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH4 + 1) = Fomula.PRICE_YEAR4_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH5 + 1) = Fomula.PRICE_YEAR4_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH6 + 1) = Fomula.PRICE_YEAR4_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH7 + 1) = Fomula.PRICE_YEAR4_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH8 + 1) = Fomula.PRICE_YEAR4_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH9 + 1) = Fomula.PRICE_YEAR4_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH10 + 1) = Fomula.PRICE_YEAR4_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH11 + 1) = Fomula.PRICE_YEAR4_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH12 + 1) = Fomula.PRICE_YEAR4_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH1 + 1) = Fomula.PRICE_YEAR5_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH2 + 1) = Fomula.PRICE_YEAR5_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH3 + 1) = Fomula.PRICE_YEAR5_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH4 + 1) = Fomula.PRICE_YEAR5_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH5 + 1) = Fomula.PRICE_YEAR5_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH6 + 1) = Fomula.PRICE_YEAR5_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH7 + 1) = Fomula.PRICE_YEAR5_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH8 + 1) = Fomula.PRICE_YEAR5_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH9 + 1) = Fomula.PRICE_YEAR5_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH10 + 1) = Fomula.PRICE_YEAR5_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH11 + 1) = Fomula.PRICE_YEAR5_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH12 + 1) = Fomula.PRICE_YEAR5_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH1 + 1) = Fomula.PRICE_YEAR6_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH2 + 1) = Fomula.PRICE_YEAR6_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH3 + 1) = Fomula.PRICE_YEAR6_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH4 + 1) = Fomula.PRICE_YEAR6_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH5 + 1) = Fomula.PRICE_YEAR6_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH6 + 1) = Fomula.PRICE_YEAR6_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH7 + 1) = Fomula.PRICE_YEAR6_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH8 + 1) = Fomula.PRICE_YEAR6_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH9 + 1) = Fomula.PRICE_YEAR6_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH10 + 1) = Fomula.PRICE_YEAR6_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH11 + 1) = Fomula.PRICE_YEAR6_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH12 + 1) = Fomula.PRICE_YEAR6_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH1 + 1) = Fomula.PRICE_YEAR7_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH2 + 1) = Fomula.PRICE_YEAR7_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH3 + 1) = Fomula.PRICE_YEAR7_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH4 + 1) = Fomula.PRICE_YEAR7_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH5 + 1) = Fomula.PRICE_YEAR7_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH6 + 1) = Fomula.PRICE_YEAR7_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH7 + 1) = Fomula.PRICE_YEAR7_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH8 + 1) = Fomula.PRICE_YEAR7_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH9 + 1) = Fomula.PRICE_YEAR7_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH10 + 1) = Fomula.PRICE_YEAR7_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH11 + 1) = Fomula.PRICE_YEAR7_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH12 + 1) = Fomula.PRICE_YEAR7_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH1 + 1) = Fomula.PRICE_YEAR8_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH2 + 1) = Fomula.PRICE_YEAR8_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH3 + 1) = Fomula.PRICE_YEAR8_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH4 + 1) = Fomula.PRICE_YEAR8_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH5 + 1) = Fomula.PRICE_YEAR8_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH6 + 1) = Fomula.PRICE_YEAR8_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH7 + 1) = Fomula.PRICE_YEAR8_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH8 + 1) = Fomula.PRICE_YEAR8_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH9 + 1) = Fomula.PRICE_YEAR8_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH10 + 1) = Fomula.PRICE_YEAR8_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH11 + 1) = Fomula.PRICE_YEAR8_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH12 + 1) = Fomula.PRICE_YEAR8_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH1 + 1) = Fomula.PRICE_YEAR9_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH2 + 1) = Fomula.PRICE_YEAR9_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH3 + 1) = Fomula.PRICE_YEAR9_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH4 + 1) = Fomula.PRICE_YEAR9_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH5 + 1) = Fomula.PRICE_YEAR9_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH6 + 1) = Fomula.PRICE_YEAR9_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH7 + 1) = Fomula.PRICE_YEAR9_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH8 + 1) = Fomula.PRICE_YEAR9_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH9 + 1) = Fomula.PRICE_YEAR9_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH10 + 1) = Fomula.PRICE_YEAR9_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH11 + 1) = Fomula.PRICE_YEAR9_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH12 + 1) = Fomula.PRICE_YEAR9_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH1 + 1) = Fomula.PRICE_YEAR10_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH2 + 1) = Fomula.PRICE_YEAR10_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH3 + 1) = Fomula.PRICE_YEAR10_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH4 + 1) = Fomula.PRICE_YEAR10_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH5 + 1) = Fomula.PRICE_YEAR10_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH6 + 1) = Fomula.PRICE_YEAR10_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH7 + 1) = Fomula.PRICE_YEAR10_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH8 + 1) = Fomula.PRICE_YEAR10_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH9 + 1) = Fomula.PRICE_YEAR10_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH10 + 1) = Fomula.PRICE_YEAR10_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH11 + 1) = Fomula.PRICE_YEAR10_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH12 + 1) = Fomula.PRICE_YEAR10_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH1 + 1) = Fomula.PRICE_YEAR11_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH2 + 1) = Fomula.PRICE_YEAR11_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH3 + 1) = Fomula.PRICE_YEAR11_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH4 + 1) = Fomula.PRICE_YEAR11_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH5 + 1) = Fomula.PRICE_YEAR11_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH6 + 1) = Fomula.PRICE_YEAR11_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH7 + 1) = Fomula.PRICE_YEAR11_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH8 + 1) = Fomula.PRICE_YEAR11_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH9 + 1) = Fomula.PRICE_YEAR11_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH10 + 1) = Fomula.PRICE_YEAR11_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH11 + 1) = Fomula.PRICE_YEAR11_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH12 + 1) = Fomula.PRICE_YEAR11_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH1 + 1) = Fomula.PRICE_YEAR12_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH2 + 1) = Fomula.PRICE_YEAR12_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH3 + 1) = Fomula.PRICE_YEAR12_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH4 + 1) = Fomula.PRICE_YEAR12_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH5 + 1) = Fomula.PRICE_YEAR12_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH6 + 1) = Fomula.PRICE_YEAR12_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH7 + 1) = Fomula.PRICE_YEAR12_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH8 + 1) = Fomula.PRICE_YEAR12_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH9 + 1) = Fomula.PRICE_YEAR12_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH10 + 1) = Fomula.PRICE_YEAR12_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH11 + 1) = Fomula.PRICE_YEAR12_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH12 + 1) = Fomula.PRICE_YEAR12_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH1 + 1) = Fomula.PRICE_YEAR13_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH2 + 1) = Fomula.PRICE_YEAR13_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH3 + 1) = Fomula.PRICE_YEAR13_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH4 + 1) = Fomula.PRICE_YEAR13_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH5 + 1) = Fomula.PRICE_YEAR13_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH6 + 1) = Fomula.PRICE_YEAR13_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH7 + 1) = Fomula.PRICE_YEAR13_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH8 + 1) = Fomula.PRICE_YEAR13_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH9 + 1) = Fomula.PRICE_YEAR13_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH10 + 1) = Fomula.PRICE_YEAR13_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH11 + 1) = Fomula.PRICE_YEAR13_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH12 + 1) = Fomula.PRICE_YEAR13_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH1 + 1) = Fomula.PRICE_YEAR14_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH2 + 1) = Fomula.PRICE_YEAR14_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH3 + 1) = Fomula.PRICE_YEAR14_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH4 + 1) = Fomula.PRICE_YEAR14_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH5 + 1) = Fomula.PRICE_YEAR14_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH6 + 1) = Fomula.PRICE_YEAR14_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH7 + 1) = Fomula.PRICE_YEAR14_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH8 + 1) = Fomula.PRICE_YEAR14_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH9 + 1) = Fomula.PRICE_YEAR14_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH10 + 1) = Fomula.PRICE_YEAR14_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH11 + 1) = Fomula.PRICE_YEAR14_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH12 + 1) = Fomula.PRICE_YEAR14_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH1 + 1) = Fomula.PRICE_YEAR15_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH2 + 1) = Fomula.PRICE_YEAR15_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH3 + 1) = Fomula.PRICE_YEAR15_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH4 + 1) = Fomula.PRICE_YEAR15_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH5 + 1) = Fomula.PRICE_YEAR15_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH6 + 1) = Fomula.PRICE_YEAR15_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH7 + 1) = Fomula.PRICE_YEAR15_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH8 + 1) = Fomula.PRICE_YEAR15_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH9 + 1) = Fomula.PRICE_YEAR15_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH10 + 1) = Fomula.PRICE_YEAR15_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH11 + 1) = Fomula.PRICE_YEAR15_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH12 + 1) = Fomula.PRICE_YEAR15_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH1 + 1) = Fomula.PRICE_YEAR16_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH2 + 1) = Fomula.PRICE_YEAR16_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH3 + 1) = Fomula.PRICE_YEAR16_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH4 + 1) = Fomula.PRICE_YEAR16_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH5 + 1) = Fomula.PRICE_YEAR16_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH6 + 1) = Fomula.PRICE_YEAR16_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH7 + 1) = Fomula.PRICE_YEAR16_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH8 + 1) = Fomula.PRICE_YEAR16_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH9 + 1) = Fomula.PRICE_YEAR16_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH10 + 1) = Fomula.PRICE_YEAR16_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH11 + 1) = Fomula.PRICE_YEAR16_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH12 + 1) = Fomula.PRICE_YEAR16_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH1 + 1) = Fomula.PRICE_YEAR17_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH2 + 1) = Fomula.PRICE_YEAR17_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH3 + 1) = Fomula.PRICE_YEAR17_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH4 + 1) = Fomula.PRICE_YEAR17_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH5 + 1) = Fomula.PRICE_YEAR17_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH6 + 1) = Fomula.PRICE_YEAR17_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH7 + 1) = Fomula.PRICE_YEAR17_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH8 + 1) = Fomula.PRICE_YEAR17_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH9 + 1) = Fomula.PRICE_YEAR17_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH10 + 1) = Fomula.PRICE_YEAR17_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH11 + 1) = Fomula.PRICE_YEAR17_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH12 + 1) = Fomula.PRICE_YEAR17_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH1 + 1) = Fomula.PRICE_YEAR18_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH2 + 1) = Fomula.PRICE_YEAR18_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH3 + 1) = Fomula.PRICE_YEAR18_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH4 + 1) = Fomula.PRICE_YEAR18_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH5 + 1) = Fomula.PRICE_YEAR18_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH6 + 1) = Fomula.PRICE_YEAR18_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH7 + 1) = Fomula.PRICE_YEAR18_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH8 + 1) = Fomula.PRICE_YEAR18_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH9 + 1) = Fomula.PRICE_YEAR18_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH10 + 1) = Fomula.PRICE_YEAR18_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH11 + 1) = Fomula.PRICE_YEAR18_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH12 + 1) = Fomula.PRICE_YEAR18_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH1 + 1) = Fomula.PRICE_YEAR19_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH2 + 1) = Fomula.PRICE_YEAR19_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH3 + 1) = Fomula.PRICE_YEAR19_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH4 + 1) = Fomula.PRICE_YEAR19_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH5 + 1) = Fomula.PRICE_YEAR19_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH6 + 1) = Fomula.PRICE_YEAR19_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH7 + 1) = Fomula.PRICE_YEAR19_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH8 + 1) = Fomula.PRICE_YEAR19_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH9 + 1) = Fomula.PRICE_YEAR19_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH10 + 1) = Fomula.PRICE_YEAR19_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH11 + 1) = Fomula.PRICE_YEAR19_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH12 + 1) = Fomula.PRICE_YEAR19_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH1 + 1) = Fomula.PRICE_YEAR20_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH2 + 1) = Fomula.PRICE_YEAR20_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH3 + 1) = Fomula.PRICE_YEAR20_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH4 + 1) = Fomula.PRICE_YEAR20_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH5 + 1) = Fomula.PRICE_YEAR20_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH6 + 1) = Fomula.PRICE_YEAR20_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH7 + 1) = Fomula.PRICE_YEAR20_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH8 + 1) = Fomula.PRICE_YEAR20_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH9 + 1) = Fomula.PRICE_YEAR20_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH10 + 1) = Fomula.PRICE_YEAR20_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH11 + 1) = Fomula.PRICE_YEAR20_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12 + 1) = Fomula.PRICE_YEAR20_MONTH12

        End If

    End Sub

    ''' 概　要：総合計の集計式の作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetAllSumSummaryRowFomula(ByRef OutIGFDataTable As PSExcelDataTable)

        ''初期化
        Dim Fomula As SummaryRowFomula
        Dim strIndex As Integer     ''SubTotalの開始位置 
        Dim EndIndex As Integer     ''SubTotalの終了位置 

        Dim rows() As DataRow
        Dim filterDel As New StringBuilder
        filterDel.Append("SummaryNM")
        filterDel.Append(CommonConstant.SQL_STR_EQUAL)
        filterDel.Append(StringEdit.EncloseSingleQuotation(CELLVALUE_SummaryNM_ALLSUM))

        ''データを抽出		
        rows = OutIGFDataTable.Select(filterDel.Tostring)
        If rows.length > 0 Then

            ''開始位置、終了位置をセット
            ''※削除集計行の一つ上の行が集計のEND行
            strIndex = EXCEL_IGFDATA_OUTROW
            EndIndex = CInt(OutIGFDataTable.Select(filterDel.ToString)(0).Item("OutExcelRow")) - 1

            ''デフォルト式をセット
            ''期間合計
            Fomula.ListPrice = SUMMARYROW_FOMULA_SUMMARY_TERM
            Fomula.DPerAfter = SUMMARYROW_FOMULA_SUMMARY_TERM
            Fomula.DPerAfterrate = SUMMARYROW_FOMULA_SUMMARY_TERM
            Fomula.PRICE_CONT_TOTAL = SUMMARYROW_FOMULA_SUMMARY_TERM
            Fomula.PRICE_OO_CONT_TOTAL = SUMMARYROW_FOMULA_SUMMARY_TERM
            Fomula.IGF = SUMMARYROW_FOMULA_SUMMARY_TERM

            ''年度金額
            Fomula.PRICE_YEAR1 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR2 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR3 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR4 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR5 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR6 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR7 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR8 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR9 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR10 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR11 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR12 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR13 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR14 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR15 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR16 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR17 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR18 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR19 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_YEAR20 = SUMMARYROW_FOMULA_PRICE_YEAR
            Fomula.PRICE_PAST_CONTRACT = SUMMARYROW_FOMULA_PRICE_YEAR

            ''月度金額
            Fomula.PRICE_YEAR1_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR1_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR2_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR3_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR4_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR5_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR6_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR7_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR8_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR9_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR10_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR11_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR12_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR13_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR14_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR15_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR16_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR17_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR18_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR19_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH1 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH2 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH3 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH4 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH5 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH6 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH7 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH8 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH9 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH10 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH11 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH
            Fomula.PRICE_YEAR20_MONTH12 = SUMMARYROW_FOMULA_PRICE_YEAR_MONTH

            ''開始、終了位置のセット
            ''期間合計
            Fomula.ListPrice = Fomula.ListPrice.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_IOC) & strIndex)
            Fomula.ListPrice = Fomula.ListPrice.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_IOC) & EndIndex)

            Fomula.DPerAfter = Fomula.DPerAfter.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_TOTAL_IOC) & strIndex)
            Fomula.DPerAfter = Fomula.DPerAfter.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_TOTAL_IOC) & EndIndex)

            Fomula.DPerAfterrate = Fomula.DPerAfterrate.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.IGF_AFTER) & strIndex)
            Fomula.DPerAfterrate = Fomula.DPerAfterrate.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.IGF_AFTER) & EndIndex)

            Fomula.IGF = Fomula.IGF.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.IGF_RATE) & strIndex)
            Fomula.IGF = Fomula.IGF.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.IGF_RATE) & EndIndex)

            Fomula.PRICE_CONT_TOTAL = Fomula.PRICE_CONT_TOTAL.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.CONTRACT_IN) & strIndex)
            Fomula.PRICE_CONT_TOTAL = Fomula.PRICE_CONT_TOTAL.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.CONTRACT_IN) & EndIndex)

            Fomula.PRICE_OO_CONT_TOTAL = Fomula.PRICE_OO_CONT_TOTAL.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.CONTRACT_OUT) & strIndex)
            Fomula.PRICE_OO_CONT_TOTAL = Fomula.PRICE_OO_CONT_TOTAL.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.CONTRACT_OUT) & EndIndex)


            ''年度金額
            Fomula.PRICE_YEAR1 = Fomula.PRICE_YEAR1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1) & strIndex)
            Fomula.PRICE_YEAR1 = Fomula.PRICE_YEAR1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1) & EndIndex)

            Fomula.PRICE_YEAR2 = Fomula.PRICE_YEAR2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2) & strIndex)
            Fomula.PRICE_YEAR2 = Fomula.PRICE_YEAR2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2) & EndIndex)

            Fomula.PRICE_YEAR3 = Fomula.PRICE_YEAR3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3) & strIndex)
            Fomula.PRICE_YEAR3 = Fomula.PRICE_YEAR3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3) & EndIndex)

            Fomula.PRICE_YEAR4 = Fomula.PRICE_YEAR4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4) & strIndex)
            Fomula.PRICE_YEAR4 = Fomula.PRICE_YEAR4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4) & EndIndex)

            Fomula.PRICE_YEAR5 = Fomula.PRICE_YEAR5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5) & strIndex)
            Fomula.PRICE_YEAR5 = Fomula.PRICE_YEAR5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5) & EndIndex)

            Fomula.PRICE_YEAR6 = Fomula.PRICE_YEAR6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6) & strIndex)
            Fomula.PRICE_YEAR6 = Fomula.PRICE_YEAR6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6) & EndIndex)

            Fomula.PRICE_YEAR7 = Fomula.PRICE_YEAR7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7) & strIndex)
            Fomula.PRICE_YEAR7 = Fomula.PRICE_YEAR7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7) & EndIndex)

            Fomula.PRICE_YEAR8 = Fomula.PRICE_YEAR8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8) & strIndex)
            Fomula.PRICE_YEAR8 = Fomula.PRICE_YEAR8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8) & EndIndex)

            Fomula.PRICE_YEAR9 = Fomula.PRICE_YEAR9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9) & strIndex)
            Fomula.PRICE_YEAR9 = Fomula.PRICE_YEAR9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9) & EndIndex)

            Fomula.PRICE_YEAR10 = Fomula.PRICE_YEAR10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10) & strIndex)
            Fomula.PRICE_YEAR10 = Fomula.PRICE_YEAR10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10) & EndIndex)

            Fomula.PRICE_YEAR11 = Fomula.PRICE_YEAR11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11) & strIndex)
            Fomula.PRICE_YEAR11 = Fomula.PRICE_YEAR11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11) & EndIndex)

            Fomula.PRICE_YEAR12 = Fomula.PRICE_YEAR12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12) & strIndex)
            Fomula.PRICE_YEAR12 = Fomula.PRICE_YEAR12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12) & EndIndex)

            Fomula.PRICE_YEAR13 = Fomula.PRICE_YEAR13.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13) & strIndex)
            Fomula.PRICE_YEAR13 = Fomula.PRICE_YEAR13.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13) & EndIndex)

            Fomula.PRICE_YEAR14 = Fomula.PRICE_YEAR14.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14) & strIndex)
            Fomula.PRICE_YEAR14 = Fomula.PRICE_YEAR14.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14) & EndIndex)

            Fomula.PRICE_YEAR15 = Fomula.PRICE_YEAR15.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15) & strIndex)
            Fomula.PRICE_YEAR15 = Fomula.PRICE_YEAR15.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15) & EndIndex)

            Fomula.PRICE_YEAR16 = Fomula.PRICE_YEAR16.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16) & strIndex)
            Fomula.PRICE_YEAR16 = Fomula.PRICE_YEAR16.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16) & EndIndex)

            Fomula.PRICE_YEAR17 = Fomula.PRICE_YEAR17.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17) & strIndex)
            Fomula.PRICE_YEAR17 = Fomula.PRICE_YEAR17.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17) & EndIndex)

            Fomula.PRICE_YEAR18 = Fomula.PRICE_YEAR18.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18) & strIndex)
            Fomula.PRICE_YEAR18 = Fomula.PRICE_YEAR18.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18) & EndIndex)

            Fomula.PRICE_YEAR19 = Fomula.PRICE_YEAR19.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19) & strIndex)
            Fomula.PRICE_YEAR19 = Fomula.PRICE_YEAR19.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19) & EndIndex)

            Fomula.PRICE_YEAR20 = Fomula.PRICE_YEAR20.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20) & strIndex)
            Fomula.PRICE_YEAR20 = Fomula.PRICE_YEAR20.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20) & EndIndex)

            Fomula.PRICE_PAST_CONTRACT = Fomula.PRICE_PAST_CONTRACT.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_PAST_CONTRACT) & strIndex)
            Fomula.PRICE_PAST_CONTRACT = Fomula.PRICE_PAST_CONTRACT.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_PAST_CONTRACT) & EndIndex)

            ''月度金額
            Fomula.PRICE_YEAR1_MONTH1 = Fomula.PRICE_YEAR1_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH1) & strIndex)
            Fomula.PRICE_YEAR1_MONTH1 = Fomula.PRICE_YEAR1_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH2 = Fomula.PRICE_YEAR1_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH2) & strIndex)
            Fomula.PRICE_YEAR1_MONTH2 = Fomula.PRICE_YEAR1_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH3 = Fomula.PRICE_YEAR1_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH3) & strIndex)
            Fomula.PRICE_YEAR1_MONTH3 = Fomula.PRICE_YEAR1_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH4 = Fomula.PRICE_YEAR1_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH4) & strIndex)
            Fomula.PRICE_YEAR1_MONTH4 = Fomula.PRICE_YEAR1_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH5 = Fomula.PRICE_YEAR1_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH5) & strIndex)
            Fomula.PRICE_YEAR1_MONTH5 = Fomula.PRICE_YEAR1_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH6 = Fomula.PRICE_YEAR1_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH6) & strIndex)
            Fomula.PRICE_YEAR1_MONTH6 = Fomula.PRICE_YEAR1_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH7 = Fomula.PRICE_YEAR1_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH7) & strIndex)
            Fomula.PRICE_YEAR1_MONTH7 = Fomula.PRICE_YEAR1_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH8 = Fomula.PRICE_YEAR1_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH8) & strIndex)
            Fomula.PRICE_YEAR1_MONTH8 = Fomula.PRICE_YEAR1_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH9 = Fomula.PRICE_YEAR1_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH9) & strIndex)
            Fomula.PRICE_YEAR1_MONTH9 = Fomula.PRICE_YEAR1_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH10 = Fomula.PRICE_YEAR1_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH10) & strIndex)
            Fomula.PRICE_YEAR1_MONTH10 = Fomula.PRICE_YEAR1_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH11 = Fomula.PRICE_YEAR1_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH11) & strIndex)
            Fomula.PRICE_YEAR1_MONTH11 = Fomula.PRICE_YEAR1_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR1_MONTH12 = Fomula.PRICE_YEAR1_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH12) & strIndex)
            Fomula.PRICE_YEAR1_MONTH12 = Fomula.PRICE_YEAR1_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH1 = Fomula.PRICE_YEAR2_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH1) & strIndex)
            Fomula.PRICE_YEAR2_MONTH1 = Fomula.PRICE_YEAR2_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH2 = Fomula.PRICE_YEAR2_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH2) & strIndex)
            Fomula.PRICE_YEAR2_MONTH2 = Fomula.PRICE_YEAR2_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH3 = Fomula.PRICE_YEAR2_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH3) & strIndex)
            Fomula.PRICE_YEAR2_MONTH3 = Fomula.PRICE_YEAR2_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH4 = Fomula.PRICE_YEAR2_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH4) & strIndex)
            Fomula.PRICE_YEAR2_MONTH4 = Fomula.PRICE_YEAR2_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH5 = Fomula.PRICE_YEAR2_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH5) & strIndex)
            Fomula.PRICE_YEAR2_MONTH5 = Fomula.PRICE_YEAR2_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH6 = Fomula.PRICE_YEAR2_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH6) & strIndex)
            Fomula.PRICE_YEAR2_MONTH6 = Fomula.PRICE_YEAR2_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH7 = Fomula.PRICE_YEAR2_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH7) & strIndex)
            Fomula.PRICE_YEAR2_MONTH7 = Fomula.PRICE_YEAR2_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH8 = Fomula.PRICE_YEAR2_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH8) & strIndex)
            Fomula.PRICE_YEAR2_MONTH8 = Fomula.PRICE_YEAR2_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH9 = Fomula.PRICE_YEAR2_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH9) & strIndex)
            Fomula.PRICE_YEAR2_MONTH9 = Fomula.PRICE_YEAR2_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH10 = Fomula.PRICE_YEAR2_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH10) & strIndex)
            Fomula.PRICE_YEAR2_MONTH10 = Fomula.PRICE_YEAR2_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH11 = Fomula.PRICE_YEAR2_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH11) & strIndex)
            Fomula.PRICE_YEAR2_MONTH11 = Fomula.PRICE_YEAR2_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR2_MONTH12 = Fomula.PRICE_YEAR2_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH12) & strIndex)
            Fomula.PRICE_YEAR2_MONTH12 = Fomula.PRICE_YEAR2_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH1 = Fomula.PRICE_YEAR3_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH1) & strIndex)
            Fomula.PRICE_YEAR3_MONTH1 = Fomula.PRICE_YEAR3_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH2 = Fomula.PRICE_YEAR3_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH2) & strIndex)
            Fomula.PRICE_YEAR3_MONTH2 = Fomula.PRICE_YEAR3_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH3 = Fomula.PRICE_YEAR3_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH3) & strIndex)
            Fomula.PRICE_YEAR3_MONTH3 = Fomula.PRICE_YEAR3_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH4 = Fomula.PRICE_YEAR3_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH4) & strIndex)
            Fomula.PRICE_YEAR3_MONTH4 = Fomula.PRICE_YEAR3_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH5 = Fomula.PRICE_YEAR3_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH5) & strIndex)
            Fomula.PRICE_YEAR3_MONTH5 = Fomula.PRICE_YEAR3_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH6 = Fomula.PRICE_YEAR3_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH6) & strIndex)
            Fomula.PRICE_YEAR3_MONTH6 = Fomula.PRICE_YEAR3_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH7 = Fomula.PRICE_YEAR3_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH7) & strIndex)
            Fomula.PRICE_YEAR3_MONTH7 = Fomula.PRICE_YEAR3_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH8 = Fomula.PRICE_YEAR3_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH8) & strIndex)
            Fomula.PRICE_YEAR3_MONTH8 = Fomula.PRICE_YEAR3_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH9 = Fomula.PRICE_YEAR3_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH9) & strIndex)
            Fomula.PRICE_YEAR3_MONTH9 = Fomula.PRICE_YEAR3_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH10 = Fomula.PRICE_YEAR3_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH10) & strIndex)
            Fomula.PRICE_YEAR3_MONTH10 = Fomula.PRICE_YEAR3_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH11 = Fomula.PRICE_YEAR3_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH11) & strIndex)
            Fomula.PRICE_YEAR3_MONTH11 = Fomula.PRICE_YEAR3_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR3_MONTH12 = Fomula.PRICE_YEAR3_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH12) & strIndex)
            Fomula.PRICE_YEAR3_MONTH12 = Fomula.PRICE_YEAR3_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH1 = Fomula.PRICE_YEAR4_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH1) & strIndex)
            Fomula.PRICE_YEAR4_MONTH1 = Fomula.PRICE_YEAR4_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH2 = Fomula.PRICE_YEAR4_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH2) & strIndex)
            Fomula.PRICE_YEAR4_MONTH2 = Fomula.PRICE_YEAR4_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH3 = Fomula.PRICE_YEAR4_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH3) & strIndex)
            Fomula.PRICE_YEAR4_MONTH3 = Fomula.PRICE_YEAR4_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH4 = Fomula.PRICE_YEAR4_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH4) & strIndex)
            Fomula.PRICE_YEAR4_MONTH4 = Fomula.PRICE_YEAR4_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH5 = Fomula.PRICE_YEAR4_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH5) & strIndex)
            Fomula.PRICE_YEAR4_MONTH5 = Fomula.PRICE_YEAR4_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH6 = Fomula.PRICE_YEAR4_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH6) & strIndex)
            Fomula.PRICE_YEAR4_MONTH6 = Fomula.PRICE_YEAR4_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH7 = Fomula.PRICE_YEAR4_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH7) & strIndex)
            Fomula.PRICE_YEAR4_MONTH7 = Fomula.PRICE_YEAR4_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH8 = Fomula.PRICE_YEAR4_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH8) & strIndex)
            Fomula.PRICE_YEAR4_MONTH8 = Fomula.PRICE_YEAR4_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH9 = Fomula.PRICE_YEAR4_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH9) & strIndex)
            Fomula.PRICE_YEAR4_MONTH9 = Fomula.PRICE_YEAR4_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH10 = Fomula.PRICE_YEAR4_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH10) & strIndex)
            Fomula.PRICE_YEAR4_MONTH10 = Fomula.PRICE_YEAR4_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH11 = Fomula.PRICE_YEAR4_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH11) & strIndex)
            Fomula.PRICE_YEAR4_MONTH11 = Fomula.PRICE_YEAR4_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR4_MONTH12 = Fomula.PRICE_YEAR4_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH12) & strIndex)
            Fomula.PRICE_YEAR4_MONTH12 = Fomula.PRICE_YEAR4_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH1 = Fomula.PRICE_YEAR5_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH1) & strIndex)
            Fomula.PRICE_YEAR5_MONTH1 = Fomula.PRICE_YEAR5_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH2 = Fomula.PRICE_YEAR5_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH2) & strIndex)
            Fomula.PRICE_YEAR5_MONTH2 = Fomula.PRICE_YEAR5_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH3 = Fomula.PRICE_YEAR5_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH3) & strIndex)
            Fomula.PRICE_YEAR5_MONTH3 = Fomula.PRICE_YEAR5_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH4 = Fomula.PRICE_YEAR5_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH4) & strIndex)
            Fomula.PRICE_YEAR5_MONTH4 = Fomula.PRICE_YEAR5_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH5 = Fomula.PRICE_YEAR5_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH5) & strIndex)
            Fomula.PRICE_YEAR5_MONTH5 = Fomula.PRICE_YEAR5_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH6 = Fomula.PRICE_YEAR5_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH6) & strIndex)
            Fomula.PRICE_YEAR5_MONTH6 = Fomula.PRICE_YEAR5_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH7 = Fomula.PRICE_YEAR5_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH7) & strIndex)
            Fomula.PRICE_YEAR5_MONTH7 = Fomula.PRICE_YEAR5_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH8 = Fomula.PRICE_YEAR5_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH8) & strIndex)
            Fomula.PRICE_YEAR5_MONTH8 = Fomula.PRICE_YEAR5_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH9 = Fomula.PRICE_YEAR5_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH9) & strIndex)
            Fomula.PRICE_YEAR5_MONTH9 = Fomula.PRICE_YEAR5_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH10 = Fomula.PRICE_YEAR5_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH10) & strIndex)
            Fomula.PRICE_YEAR5_MONTH10 = Fomula.PRICE_YEAR5_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH11 = Fomula.PRICE_YEAR5_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH11) & strIndex)
            Fomula.PRICE_YEAR5_MONTH11 = Fomula.PRICE_YEAR5_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR5_MONTH12 = Fomula.PRICE_YEAR5_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH12) & strIndex)
            Fomula.PRICE_YEAR5_MONTH12 = Fomula.PRICE_YEAR5_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH1 = Fomula.PRICE_YEAR6_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH1) & strIndex)
            Fomula.PRICE_YEAR6_MONTH1 = Fomula.PRICE_YEAR6_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH2 = Fomula.PRICE_YEAR6_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH2) & strIndex)
            Fomula.PRICE_YEAR6_MONTH2 = Fomula.PRICE_YEAR6_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH3 = Fomula.PRICE_YEAR6_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH3) & strIndex)
            Fomula.PRICE_YEAR6_MONTH3 = Fomula.PRICE_YEAR6_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH4 = Fomula.PRICE_YEAR6_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH4) & strIndex)
            Fomula.PRICE_YEAR6_MONTH4 = Fomula.PRICE_YEAR6_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH5 = Fomula.PRICE_YEAR6_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH5) & strIndex)
            Fomula.PRICE_YEAR6_MONTH5 = Fomula.PRICE_YEAR6_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH6 = Fomula.PRICE_YEAR6_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH6) & strIndex)
            Fomula.PRICE_YEAR6_MONTH6 = Fomula.PRICE_YEAR6_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH7 = Fomula.PRICE_YEAR6_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH7) & strIndex)
            Fomula.PRICE_YEAR6_MONTH7 = Fomula.PRICE_YEAR6_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH8 = Fomula.PRICE_YEAR6_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH8) & strIndex)
            Fomula.PRICE_YEAR6_MONTH8 = Fomula.PRICE_YEAR6_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH9 = Fomula.PRICE_YEAR6_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH9) & strIndex)
            Fomula.PRICE_YEAR6_MONTH9 = Fomula.PRICE_YEAR6_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH10 = Fomula.PRICE_YEAR6_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH10) & strIndex)
            Fomula.PRICE_YEAR6_MONTH10 = Fomula.PRICE_YEAR6_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH11 = Fomula.PRICE_YEAR6_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH11) & strIndex)
            Fomula.PRICE_YEAR6_MONTH11 = Fomula.PRICE_YEAR6_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR6_MONTH12 = Fomula.PRICE_YEAR6_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH12) & strIndex)
            Fomula.PRICE_YEAR6_MONTH12 = Fomula.PRICE_YEAR6_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH1 = Fomula.PRICE_YEAR7_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH1) & strIndex)
            Fomula.PRICE_YEAR7_MONTH1 = Fomula.PRICE_YEAR7_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH2 = Fomula.PRICE_YEAR7_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH2) & strIndex)
            Fomula.PRICE_YEAR7_MONTH2 = Fomula.PRICE_YEAR7_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH3 = Fomula.PRICE_YEAR7_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH3) & strIndex)
            Fomula.PRICE_YEAR7_MONTH3 = Fomula.PRICE_YEAR7_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH4 = Fomula.PRICE_YEAR7_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH4) & strIndex)
            Fomula.PRICE_YEAR7_MONTH4 = Fomula.PRICE_YEAR7_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH5 = Fomula.PRICE_YEAR7_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH5) & strIndex)
            Fomula.PRICE_YEAR7_MONTH5 = Fomula.PRICE_YEAR7_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH6 = Fomula.PRICE_YEAR7_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH6) & strIndex)
            Fomula.PRICE_YEAR7_MONTH6 = Fomula.PRICE_YEAR7_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH7 = Fomula.PRICE_YEAR7_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH7) & strIndex)
            Fomula.PRICE_YEAR7_MONTH7 = Fomula.PRICE_YEAR7_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH8 = Fomula.PRICE_YEAR7_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH8) & strIndex)
            Fomula.PRICE_YEAR7_MONTH8 = Fomula.PRICE_YEAR7_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH9 = Fomula.PRICE_YEAR7_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH9) & strIndex)
            Fomula.PRICE_YEAR7_MONTH9 = Fomula.PRICE_YEAR7_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH10 = Fomula.PRICE_YEAR7_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH10) & strIndex)
            Fomula.PRICE_YEAR7_MONTH10 = Fomula.PRICE_YEAR7_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH11 = Fomula.PRICE_YEAR7_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH11) & strIndex)
            Fomula.PRICE_YEAR7_MONTH11 = Fomula.PRICE_YEAR7_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR7_MONTH12 = Fomula.PRICE_YEAR7_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH12) & strIndex)
            Fomula.PRICE_YEAR7_MONTH12 = Fomula.PRICE_YEAR7_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH1 = Fomula.PRICE_YEAR8_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH1) & strIndex)
            Fomula.PRICE_YEAR8_MONTH1 = Fomula.PRICE_YEAR8_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH2 = Fomula.PRICE_YEAR8_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH2) & strIndex)
            Fomula.PRICE_YEAR8_MONTH2 = Fomula.PRICE_YEAR8_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH3 = Fomula.PRICE_YEAR8_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH3) & strIndex)
            Fomula.PRICE_YEAR8_MONTH3 = Fomula.PRICE_YEAR8_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH4 = Fomula.PRICE_YEAR8_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH4) & strIndex)
            Fomula.PRICE_YEAR8_MONTH4 = Fomula.PRICE_YEAR8_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH5 = Fomula.PRICE_YEAR8_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH5) & strIndex)
            Fomula.PRICE_YEAR8_MONTH5 = Fomula.PRICE_YEAR8_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH6 = Fomula.PRICE_YEAR8_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH6) & strIndex)
            Fomula.PRICE_YEAR8_MONTH6 = Fomula.PRICE_YEAR8_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH7 = Fomula.PRICE_YEAR8_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH7) & strIndex)
            Fomula.PRICE_YEAR8_MONTH7 = Fomula.PRICE_YEAR8_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH8 = Fomula.PRICE_YEAR8_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH8) & strIndex)
            Fomula.PRICE_YEAR8_MONTH8 = Fomula.PRICE_YEAR8_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH9 = Fomula.PRICE_YEAR8_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH9) & strIndex)
            Fomula.PRICE_YEAR8_MONTH9 = Fomula.PRICE_YEAR8_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH10 = Fomula.PRICE_YEAR8_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH10) & strIndex)
            Fomula.PRICE_YEAR8_MONTH10 = Fomula.PRICE_YEAR8_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH11 = Fomula.PRICE_YEAR8_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH11) & strIndex)
            Fomula.PRICE_YEAR8_MONTH11 = Fomula.PRICE_YEAR8_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR8_MONTH12 = Fomula.PRICE_YEAR8_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH12) & strIndex)
            Fomula.PRICE_YEAR8_MONTH12 = Fomula.PRICE_YEAR8_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH1 = Fomula.PRICE_YEAR9_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH1) & strIndex)
            Fomula.PRICE_YEAR9_MONTH1 = Fomula.PRICE_YEAR9_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH2 = Fomula.PRICE_YEAR9_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH2) & strIndex)
            Fomula.PRICE_YEAR9_MONTH2 = Fomula.PRICE_YEAR9_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH3 = Fomula.PRICE_YEAR9_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH3) & strIndex)
            Fomula.PRICE_YEAR9_MONTH3 = Fomula.PRICE_YEAR9_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH4 = Fomula.PRICE_YEAR9_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH4) & strIndex)
            Fomula.PRICE_YEAR9_MONTH4 = Fomula.PRICE_YEAR9_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH5 = Fomula.PRICE_YEAR9_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH5) & strIndex)
            Fomula.PRICE_YEAR9_MONTH5 = Fomula.PRICE_YEAR9_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH6 = Fomula.PRICE_YEAR9_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH6) & strIndex)
            Fomula.PRICE_YEAR9_MONTH6 = Fomula.PRICE_YEAR9_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH7 = Fomula.PRICE_YEAR9_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH7) & strIndex)
            Fomula.PRICE_YEAR9_MONTH7 = Fomula.PRICE_YEAR9_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH8 = Fomula.PRICE_YEAR9_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH8) & strIndex)
            Fomula.PRICE_YEAR9_MONTH8 = Fomula.PRICE_YEAR9_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH9 = Fomula.PRICE_YEAR9_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH9) & strIndex)
            Fomula.PRICE_YEAR9_MONTH9 = Fomula.PRICE_YEAR9_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH10 = Fomula.PRICE_YEAR9_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH10) & strIndex)
            Fomula.PRICE_YEAR9_MONTH10 = Fomula.PRICE_YEAR9_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH11 = Fomula.PRICE_YEAR9_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH11) & strIndex)
            Fomula.PRICE_YEAR9_MONTH11 = Fomula.PRICE_YEAR9_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR9_MONTH12 = Fomula.PRICE_YEAR9_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH12) & strIndex)
            Fomula.PRICE_YEAR9_MONTH12 = Fomula.PRICE_YEAR9_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH1 = Fomula.PRICE_YEAR10_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH1) & strIndex)
            Fomula.PRICE_YEAR10_MONTH1 = Fomula.PRICE_YEAR10_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH2 = Fomula.PRICE_YEAR10_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH2) & strIndex)
            Fomula.PRICE_YEAR10_MONTH2 = Fomula.PRICE_YEAR10_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH3 = Fomula.PRICE_YEAR10_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH3) & strIndex)
            Fomula.PRICE_YEAR10_MONTH3 = Fomula.PRICE_YEAR10_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH4 = Fomula.PRICE_YEAR10_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH4) & strIndex)
            Fomula.PRICE_YEAR10_MONTH4 = Fomula.PRICE_YEAR10_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH5 = Fomula.PRICE_YEAR10_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH5) & strIndex)
            Fomula.PRICE_YEAR10_MONTH5 = Fomula.PRICE_YEAR10_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH6 = Fomula.PRICE_YEAR10_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH6) & strIndex)
            Fomula.PRICE_YEAR10_MONTH6 = Fomula.PRICE_YEAR10_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH7 = Fomula.PRICE_YEAR10_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH7) & strIndex)
            Fomula.PRICE_YEAR10_MONTH7 = Fomula.PRICE_YEAR10_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH8 = Fomula.PRICE_YEAR10_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH8) & strIndex)
            Fomula.PRICE_YEAR10_MONTH8 = Fomula.PRICE_YEAR10_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH9 = Fomula.PRICE_YEAR10_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH9) & strIndex)
            Fomula.PRICE_YEAR10_MONTH9 = Fomula.PRICE_YEAR10_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH10 = Fomula.PRICE_YEAR10_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH10) & strIndex)
            Fomula.PRICE_YEAR10_MONTH10 = Fomula.PRICE_YEAR10_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH11 = Fomula.PRICE_YEAR10_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH11) & strIndex)
            Fomula.PRICE_YEAR10_MONTH11 = Fomula.PRICE_YEAR10_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR10_MONTH12 = Fomula.PRICE_YEAR10_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH12) & strIndex)
            Fomula.PRICE_YEAR10_MONTH12 = Fomula.PRICE_YEAR10_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH1 = Fomula.PRICE_YEAR11_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH1) & strIndex)
            Fomula.PRICE_YEAR11_MONTH1 = Fomula.PRICE_YEAR11_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH2 = Fomula.PRICE_YEAR11_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH2) & strIndex)
            Fomula.PRICE_YEAR11_MONTH2 = Fomula.PRICE_YEAR11_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH3 = Fomula.PRICE_YEAR11_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH3) & strIndex)
            Fomula.PRICE_YEAR11_MONTH3 = Fomula.PRICE_YEAR11_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH4 = Fomula.PRICE_YEAR11_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH4) & strIndex)
            Fomula.PRICE_YEAR11_MONTH4 = Fomula.PRICE_YEAR11_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH5 = Fomula.PRICE_YEAR11_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH5) & strIndex)
            Fomula.PRICE_YEAR11_MONTH5 = Fomula.PRICE_YEAR11_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH6 = Fomula.PRICE_YEAR11_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH6) & strIndex)
            Fomula.PRICE_YEAR11_MONTH6 = Fomula.PRICE_YEAR11_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH7 = Fomula.PRICE_YEAR11_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH7) & strIndex)
            Fomula.PRICE_YEAR11_MONTH7 = Fomula.PRICE_YEAR11_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH8 = Fomula.PRICE_YEAR11_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH8) & strIndex)
            Fomula.PRICE_YEAR11_MONTH8 = Fomula.PRICE_YEAR11_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH9 = Fomula.PRICE_YEAR11_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH9) & strIndex)
            Fomula.PRICE_YEAR11_MONTH9 = Fomula.PRICE_YEAR11_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH10 = Fomula.PRICE_YEAR11_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH10) & strIndex)
            Fomula.PRICE_YEAR11_MONTH10 = Fomula.PRICE_YEAR11_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH11 = Fomula.PRICE_YEAR11_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH11) & strIndex)
            Fomula.PRICE_YEAR11_MONTH11 = Fomula.PRICE_YEAR11_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR11_MONTH12 = Fomula.PRICE_YEAR11_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH12) & strIndex)
            Fomula.PRICE_YEAR11_MONTH12 = Fomula.PRICE_YEAR11_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH1 = Fomula.PRICE_YEAR12_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH1) & strIndex)
            Fomula.PRICE_YEAR12_MONTH1 = Fomula.PRICE_YEAR12_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH1) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH2 = Fomula.PRICE_YEAR12_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH2) & strIndex)
            Fomula.PRICE_YEAR12_MONTH2 = Fomula.PRICE_YEAR12_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH2) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH3 = Fomula.PRICE_YEAR12_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH3) & strIndex)
            Fomula.PRICE_YEAR12_MONTH3 = Fomula.PRICE_YEAR12_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH3) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH4 = Fomula.PRICE_YEAR12_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH4) & strIndex)
            Fomula.PRICE_YEAR12_MONTH4 = Fomula.PRICE_YEAR12_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH4) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH5 = Fomula.PRICE_YEAR12_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH5) & strIndex)
            Fomula.PRICE_YEAR12_MONTH5 = Fomula.PRICE_YEAR12_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH5) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH6 = Fomula.PRICE_YEAR12_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH6) & strIndex)
            Fomula.PRICE_YEAR12_MONTH6 = Fomula.PRICE_YEAR12_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH6) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH7 = Fomula.PRICE_YEAR12_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH7) & strIndex)
            Fomula.PRICE_YEAR12_MONTH7 = Fomula.PRICE_YEAR12_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH7) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH8 = Fomula.PRICE_YEAR12_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH8) & strIndex)
            Fomula.PRICE_YEAR12_MONTH8 = Fomula.PRICE_YEAR12_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH8) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH9 = Fomula.PRICE_YEAR12_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH9) & strIndex)
            Fomula.PRICE_YEAR12_MONTH9 = Fomula.PRICE_YEAR12_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH9) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH10 = Fomula.PRICE_YEAR12_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH10) & strIndex)
            Fomula.PRICE_YEAR12_MONTH10 = Fomula.PRICE_YEAR12_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH10) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH11 = Fomula.PRICE_YEAR12_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH11) & strIndex)
            Fomula.PRICE_YEAR12_MONTH11 = Fomula.PRICE_YEAR12_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH11) & EndIndex)

            Fomula.PRICE_YEAR12_MONTH12 = Fomula.PRICE_YEAR12_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH12) & strIndex)
            Fomula.PRICE_YEAR12_MONTH12 = Fomula.PRICE_YEAR12_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR13_MONTH1 = Fomula.PRICE_YEAR13_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH1) & strIndex)
            Fomula.PRICE_YEAR13_MONTH1 = Fomula.PRICE_YEAR13_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH1) & EndIndex)
            Fomula.PRICE_YEAR13_MONTH2 = Fomula.PRICE_YEAR13_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH2) & strIndex)
            Fomula.PRICE_YEAR13_MONTH2 = Fomula.PRICE_YEAR13_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH2) & EndIndex)
            Fomula.PRICE_YEAR13_MONTH3 = Fomula.PRICE_YEAR13_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH3) & strIndex)
            Fomula.PRICE_YEAR13_MONTH3 = Fomula.PRICE_YEAR13_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH3) & EndIndex)
            Fomula.PRICE_YEAR13_MONTH4 = Fomula.PRICE_YEAR13_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH4) & strIndex)
            Fomula.PRICE_YEAR13_MONTH4 = Fomula.PRICE_YEAR13_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH4) & EndIndex)
            Fomula.PRICE_YEAR13_MONTH5 = Fomula.PRICE_YEAR13_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH5) & strIndex)
            Fomula.PRICE_YEAR13_MONTH5 = Fomula.PRICE_YEAR13_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH5) & EndIndex)
            Fomula.PRICE_YEAR13_MONTH6 = Fomula.PRICE_YEAR13_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH6) & strIndex)
            Fomula.PRICE_YEAR13_MONTH6 = Fomula.PRICE_YEAR13_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH6) & EndIndex)
            Fomula.PRICE_YEAR13_MONTH7 = Fomula.PRICE_YEAR13_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH7) & strIndex)
            Fomula.PRICE_YEAR13_MONTH7 = Fomula.PRICE_YEAR13_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH7) & EndIndex)
            Fomula.PRICE_YEAR13_MONTH8 = Fomula.PRICE_YEAR13_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH8) & strIndex)
            Fomula.PRICE_YEAR13_MONTH8 = Fomula.PRICE_YEAR13_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH8) & EndIndex)
            Fomula.PRICE_YEAR13_MONTH9 = Fomula.PRICE_YEAR13_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH9) & strIndex)
            Fomula.PRICE_YEAR13_MONTH9 = Fomula.PRICE_YEAR13_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH9) & EndIndex)
            Fomula.PRICE_YEAR13_MONTH10 = Fomula.PRICE_YEAR13_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH10) & strIndex)
            Fomula.PRICE_YEAR13_MONTH10 = Fomula.PRICE_YEAR13_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH10) & EndIndex)
            Fomula.PRICE_YEAR13_MONTH11 = Fomula.PRICE_YEAR13_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH11) & strIndex)
            Fomula.PRICE_YEAR13_MONTH11 = Fomula.PRICE_YEAR13_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH11) & EndIndex)
            Fomula.PRICE_YEAR13_MONTH12 = Fomula.PRICE_YEAR13_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH12) & strIndex)
            Fomula.PRICE_YEAR13_MONTH12 = Fomula.PRICE_YEAR13_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR14_MONTH1 = Fomula.PRICE_YEAR14_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH1) & strIndex)
            Fomula.PRICE_YEAR14_MONTH1 = Fomula.PRICE_YEAR14_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH1) & EndIndex)
            Fomula.PRICE_YEAR14_MONTH2 = Fomula.PRICE_YEAR14_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH2) & strIndex)
            Fomula.PRICE_YEAR14_MONTH2 = Fomula.PRICE_YEAR14_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH2) & EndIndex)
            Fomula.PRICE_YEAR14_MONTH3 = Fomula.PRICE_YEAR14_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH3) & strIndex)
            Fomula.PRICE_YEAR14_MONTH3 = Fomula.PRICE_YEAR14_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH3) & EndIndex)
            Fomula.PRICE_YEAR14_MONTH4 = Fomula.PRICE_YEAR14_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH4) & strIndex)
            Fomula.PRICE_YEAR14_MONTH4 = Fomula.PRICE_YEAR14_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH4) & EndIndex)
            Fomula.PRICE_YEAR14_MONTH5 = Fomula.PRICE_YEAR14_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH5) & strIndex)
            Fomula.PRICE_YEAR14_MONTH5 = Fomula.PRICE_YEAR14_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH5) & EndIndex)
            Fomula.PRICE_YEAR14_MONTH6 = Fomula.PRICE_YEAR14_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH6) & strIndex)
            Fomula.PRICE_YEAR14_MONTH6 = Fomula.PRICE_YEAR14_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH6) & EndIndex)
            Fomula.PRICE_YEAR14_MONTH7 = Fomula.PRICE_YEAR14_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH7) & strIndex)
            Fomula.PRICE_YEAR14_MONTH7 = Fomula.PRICE_YEAR14_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH7) & EndIndex)
            Fomula.PRICE_YEAR14_MONTH8 = Fomula.PRICE_YEAR14_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH8) & strIndex)
            Fomula.PRICE_YEAR14_MONTH8 = Fomula.PRICE_YEAR14_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH8) & EndIndex)
            Fomula.PRICE_YEAR14_MONTH9 = Fomula.PRICE_YEAR14_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH9) & strIndex)
            Fomula.PRICE_YEAR14_MONTH9 = Fomula.PRICE_YEAR14_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH9) & EndIndex)
            Fomula.PRICE_YEAR14_MONTH10 = Fomula.PRICE_YEAR14_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH10) & strIndex)
            Fomula.PRICE_YEAR14_MONTH10 = Fomula.PRICE_YEAR14_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH10) & EndIndex)
            Fomula.PRICE_YEAR14_MONTH11 = Fomula.PRICE_YEAR14_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH11) & strIndex)
            Fomula.PRICE_YEAR14_MONTH11 = Fomula.PRICE_YEAR14_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH11) & EndIndex)
            Fomula.PRICE_YEAR14_MONTH12 = Fomula.PRICE_YEAR14_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH12) & strIndex)
            Fomula.PRICE_YEAR14_MONTH12 = Fomula.PRICE_YEAR14_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR15_MONTH1 = Fomula.PRICE_YEAR15_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH1) & strIndex)
            Fomula.PRICE_YEAR15_MONTH1 = Fomula.PRICE_YEAR15_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH1) & EndIndex)
            Fomula.PRICE_YEAR15_MONTH2 = Fomula.PRICE_YEAR15_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH2) & strIndex)
            Fomula.PRICE_YEAR15_MONTH2 = Fomula.PRICE_YEAR15_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH2) & EndIndex)
            Fomula.PRICE_YEAR15_MONTH3 = Fomula.PRICE_YEAR15_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH3) & strIndex)
            Fomula.PRICE_YEAR15_MONTH3 = Fomula.PRICE_YEAR15_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH3) & EndIndex)
            Fomula.PRICE_YEAR15_MONTH4 = Fomula.PRICE_YEAR15_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH4) & strIndex)
            Fomula.PRICE_YEAR15_MONTH4 = Fomula.PRICE_YEAR15_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH4) & EndIndex)
            Fomula.PRICE_YEAR15_MONTH5 = Fomula.PRICE_YEAR15_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH5) & strIndex)
            Fomula.PRICE_YEAR15_MONTH5 = Fomula.PRICE_YEAR15_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH5) & EndIndex)
            Fomula.PRICE_YEAR15_MONTH6 = Fomula.PRICE_YEAR15_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH6) & strIndex)
            Fomula.PRICE_YEAR15_MONTH6 = Fomula.PRICE_YEAR15_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH6) & EndIndex)
            Fomula.PRICE_YEAR15_MONTH7 = Fomula.PRICE_YEAR15_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH7) & strIndex)
            Fomula.PRICE_YEAR15_MONTH7 = Fomula.PRICE_YEAR15_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH7) & EndIndex)
            Fomula.PRICE_YEAR15_MONTH8 = Fomula.PRICE_YEAR15_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH8) & strIndex)
            Fomula.PRICE_YEAR15_MONTH8 = Fomula.PRICE_YEAR15_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH8) & EndIndex)
            Fomula.PRICE_YEAR15_MONTH9 = Fomula.PRICE_YEAR15_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH9) & strIndex)
            Fomula.PRICE_YEAR15_MONTH9 = Fomula.PRICE_YEAR15_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH9) & EndIndex)
            Fomula.PRICE_YEAR15_MONTH10 = Fomula.PRICE_YEAR15_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH10) & strIndex)
            Fomula.PRICE_YEAR15_MONTH10 = Fomula.PRICE_YEAR15_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH10) & EndIndex)
            Fomula.PRICE_YEAR15_MONTH11 = Fomula.PRICE_YEAR15_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH11) & strIndex)
            Fomula.PRICE_YEAR15_MONTH11 = Fomula.PRICE_YEAR15_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH11) & EndIndex)
            Fomula.PRICE_YEAR15_MONTH12 = Fomula.PRICE_YEAR15_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH12) & strIndex)
            Fomula.PRICE_YEAR15_MONTH12 = Fomula.PRICE_YEAR15_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR16_MONTH1 = Fomula.PRICE_YEAR16_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH1) & strIndex)
            Fomula.PRICE_YEAR16_MONTH1 = Fomula.PRICE_YEAR16_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH1) & EndIndex)
            Fomula.PRICE_YEAR16_MONTH2 = Fomula.PRICE_YEAR16_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH2) & strIndex)
            Fomula.PRICE_YEAR16_MONTH2 = Fomula.PRICE_YEAR16_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH2) & EndIndex)
            Fomula.PRICE_YEAR16_MONTH3 = Fomula.PRICE_YEAR16_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH3) & strIndex)
            Fomula.PRICE_YEAR16_MONTH3 = Fomula.PRICE_YEAR16_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH3) & EndIndex)
            Fomula.PRICE_YEAR16_MONTH4 = Fomula.PRICE_YEAR16_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH4) & strIndex)
            Fomula.PRICE_YEAR16_MONTH4 = Fomula.PRICE_YEAR16_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH4) & EndIndex)
            Fomula.PRICE_YEAR16_MONTH5 = Fomula.PRICE_YEAR16_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH5) & strIndex)
            Fomula.PRICE_YEAR16_MONTH5 = Fomula.PRICE_YEAR16_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH5) & EndIndex)
            Fomula.PRICE_YEAR16_MONTH6 = Fomula.PRICE_YEAR16_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH6) & strIndex)
            Fomula.PRICE_YEAR16_MONTH6 = Fomula.PRICE_YEAR16_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH6) & EndIndex)
            Fomula.PRICE_YEAR16_MONTH7 = Fomula.PRICE_YEAR16_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH7) & strIndex)
            Fomula.PRICE_YEAR16_MONTH7 = Fomula.PRICE_YEAR16_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH7) & EndIndex)
            Fomula.PRICE_YEAR16_MONTH8 = Fomula.PRICE_YEAR16_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH8) & strIndex)
            Fomula.PRICE_YEAR16_MONTH8 = Fomula.PRICE_YEAR16_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH8) & EndIndex)
            Fomula.PRICE_YEAR16_MONTH9 = Fomula.PRICE_YEAR16_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH9) & strIndex)
            Fomula.PRICE_YEAR16_MONTH9 = Fomula.PRICE_YEAR16_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH9) & EndIndex)
            Fomula.PRICE_YEAR16_MONTH10 = Fomula.PRICE_YEAR16_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH10) & strIndex)
            Fomula.PRICE_YEAR16_MONTH10 = Fomula.PRICE_YEAR16_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH10) & EndIndex)
            Fomula.PRICE_YEAR16_MONTH11 = Fomula.PRICE_YEAR16_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH11) & strIndex)
            Fomula.PRICE_YEAR16_MONTH11 = Fomula.PRICE_YEAR16_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH11) & EndIndex)
            Fomula.PRICE_YEAR16_MONTH12 = Fomula.PRICE_YEAR16_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH12) & strIndex)
            Fomula.PRICE_YEAR16_MONTH12 = Fomula.PRICE_YEAR16_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR17_MONTH1 = Fomula.PRICE_YEAR17_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH1) & strIndex)
            Fomula.PRICE_YEAR17_MONTH1 = Fomula.PRICE_YEAR17_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH1) & EndIndex)
            Fomula.PRICE_YEAR17_MONTH2 = Fomula.PRICE_YEAR17_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH2) & strIndex)
            Fomula.PRICE_YEAR17_MONTH2 = Fomula.PRICE_YEAR17_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH2) & EndIndex)
            Fomula.PRICE_YEAR17_MONTH3 = Fomula.PRICE_YEAR17_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH3) & strIndex)
            Fomula.PRICE_YEAR17_MONTH3 = Fomula.PRICE_YEAR17_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH3) & EndIndex)
            Fomula.PRICE_YEAR17_MONTH4 = Fomula.PRICE_YEAR17_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH4) & strIndex)
            Fomula.PRICE_YEAR17_MONTH4 = Fomula.PRICE_YEAR17_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH4) & EndIndex)
            Fomula.PRICE_YEAR17_MONTH5 = Fomula.PRICE_YEAR17_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH5) & strIndex)
            Fomula.PRICE_YEAR17_MONTH5 = Fomula.PRICE_YEAR17_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH5) & EndIndex)
            Fomula.PRICE_YEAR17_MONTH6 = Fomula.PRICE_YEAR17_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH6) & strIndex)
            Fomula.PRICE_YEAR17_MONTH6 = Fomula.PRICE_YEAR17_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH6) & EndIndex)
            Fomula.PRICE_YEAR17_MONTH7 = Fomula.PRICE_YEAR17_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH7) & strIndex)
            Fomula.PRICE_YEAR17_MONTH7 = Fomula.PRICE_YEAR17_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH7) & EndIndex)
            Fomula.PRICE_YEAR17_MONTH8 = Fomula.PRICE_YEAR17_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH8) & strIndex)
            Fomula.PRICE_YEAR17_MONTH8 = Fomula.PRICE_YEAR17_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH8) & EndIndex)
            Fomula.PRICE_YEAR17_MONTH9 = Fomula.PRICE_YEAR17_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH9) & strIndex)
            Fomula.PRICE_YEAR17_MONTH9 = Fomula.PRICE_YEAR17_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH9) & EndIndex)
            Fomula.PRICE_YEAR17_MONTH10 = Fomula.PRICE_YEAR17_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH10) & strIndex)
            Fomula.PRICE_YEAR17_MONTH10 = Fomula.PRICE_YEAR17_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH10) & EndIndex)
            Fomula.PRICE_YEAR17_MONTH11 = Fomula.PRICE_YEAR17_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH11) & strIndex)
            Fomula.PRICE_YEAR17_MONTH11 = Fomula.PRICE_YEAR17_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH11) & EndIndex)
            Fomula.PRICE_YEAR17_MONTH12 = Fomula.PRICE_YEAR17_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH12) & strIndex)
            Fomula.PRICE_YEAR17_MONTH12 = Fomula.PRICE_YEAR17_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR18_MONTH1 = Fomula.PRICE_YEAR18_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH1) & strIndex)
            Fomula.PRICE_YEAR18_MONTH1 = Fomula.PRICE_YEAR18_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH1) & EndIndex)
            Fomula.PRICE_YEAR18_MONTH2 = Fomula.PRICE_YEAR18_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH2) & strIndex)
            Fomula.PRICE_YEAR18_MONTH2 = Fomula.PRICE_YEAR18_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH2) & EndIndex)
            Fomula.PRICE_YEAR18_MONTH3 = Fomula.PRICE_YEAR18_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH3) & strIndex)
            Fomula.PRICE_YEAR18_MONTH3 = Fomula.PRICE_YEAR18_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH3) & EndIndex)
            Fomula.PRICE_YEAR18_MONTH4 = Fomula.PRICE_YEAR18_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH4) & strIndex)
            Fomula.PRICE_YEAR18_MONTH4 = Fomula.PRICE_YEAR18_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH4) & EndIndex)
            Fomula.PRICE_YEAR18_MONTH5 = Fomula.PRICE_YEAR18_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH5) & strIndex)
            Fomula.PRICE_YEAR18_MONTH5 = Fomula.PRICE_YEAR18_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH5) & EndIndex)
            Fomula.PRICE_YEAR18_MONTH6 = Fomula.PRICE_YEAR18_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH6) & strIndex)
            Fomula.PRICE_YEAR18_MONTH6 = Fomula.PRICE_YEAR18_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH6) & EndIndex)
            Fomula.PRICE_YEAR18_MONTH7 = Fomula.PRICE_YEAR18_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH7) & strIndex)
            Fomula.PRICE_YEAR18_MONTH7 = Fomula.PRICE_YEAR18_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH7) & EndIndex)
            Fomula.PRICE_YEAR18_MONTH8 = Fomula.PRICE_YEAR18_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH8) & strIndex)
            Fomula.PRICE_YEAR18_MONTH8 = Fomula.PRICE_YEAR18_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH8) & EndIndex)
            Fomula.PRICE_YEAR18_MONTH9 = Fomula.PRICE_YEAR18_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH9) & strIndex)
            Fomula.PRICE_YEAR18_MONTH9 = Fomula.PRICE_YEAR18_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH9) & EndIndex)
            Fomula.PRICE_YEAR18_MONTH10 = Fomula.PRICE_YEAR18_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH10) & strIndex)
            Fomula.PRICE_YEAR18_MONTH10 = Fomula.PRICE_YEAR18_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH10) & EndIndex)
            Fomula.PRICE_YEAR18_MONTH11 = Fomula.PRICE_YEAR18_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH11) & strIndex)
            Fomula.PRICE_YEAR18_MONTH11 = Fomula.PRICE_YEAR18_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH11) & EndIndex)
            Fomula.PRICE_YEAR18_MONTH12 = Fomula.PRICE_YEAR18_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH12) & strIndex)
            Fomula.PRICE_YEAR18_MONTH12 = Fomula.PRICE_YEAR18_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR19_MONTH1 = Fomula.PRICE_YEAR19_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH1) & strIndex)
            Fomula.PRICE_YEAR19_MONTH1 = Fomula.PRICE_YEAR19_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH1) & EndIndex)
            Fomula.PRICE_YEAR19_MONTH2 = Fomula.PRICE_YEAR19_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH2) & strIndex)
            Fomula.PRICE_YEAR19_MONTH2 = Fomula.PRICE_YEAR19_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH2) & EndIndex)
            Fomula.PRICE_YEAR19_MONTH3 = Fomula.PRICE_YEAR19_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH3) & strIndex)
            Fomula.PRICE_YEAR19_MONTH3 = Fomula.PRICE_YEAR19_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH3) & EndIndex)
            Fomula.PRICE_YEAR19_MONTH4 = Fomula.PRICE_YEAR19_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH4) & strIndex)
            Fomula.PRICE_YEAR19_MONTH4 = Fomula.PRICE_YEAR19_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH4) & EndIndex)
            Fomula.PRICE_YEAR19_MONTH5 = Fomula.PRICE_YEAR19_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH5) & strIndex)
            Fomula.PRICE_YEAR19_MONTH5 = Fomula.PRICE_YEAR19_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH5) & EndIndex)
            Fomula.PRICE_YEAR19_MONTH6 = Fomula.PRICE_YEAR19_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH6) & strIndex)
            Fomula.PRICE_YEAR19_MONTH6 = Fomula.PRICE_YEAR19_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH6) & EndIndex)
            Fomula.PRICE_YEAR19_MONTH7 = Fomula.PRICE_YEAR19_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH7) & strIndex)
            Fomula.PRICE_YEAR19_MONTH7 = Fomula.PRICE_YEAR19_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH7) & EndIndex)
            Fomula.PRICE_YEAR19_MONTH8 = Fomula.PRICE_YEAR19_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH8) & strIndex)
            Fomula.PRICE_YEAR19_MONTH8 = Fomula.PRICE_YEAR19_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH8) & EndIndex)
            Fomula.PRICE_YEAR19_MONTH9 = Fomula.PRICE_YEAR19_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH9) & strIndex)
            Fomula.PRICE_YEAR19_MONTH9 = Fomula.PRICE_YEAR19_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH9) & EndIndex)
            Fomula.PRICE_YEAR19_MONTH10 = Fomula.PRICE_YEAR19_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH10) & strIndex)
            Fomula.PRICE_YEAR19_MONTH10 = Fomula.PRICE_YEAR19_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH10) & EndIndex)
            Fomula.PRICE_YEAR19_MONTH11 = Fomula.PRICE_YEAR19_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH11) & strIndex)
            Fomula.PRICE_YEAR19_MONTH11 = Fomula.PRICE_YEAR19_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH11) & EndIndex)
            Fomula.PRICE_YEAR19_MONTH12 = Fomula.PRICE_YEAR19_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH12) & strIndex)
            Fomula.PRICE_YEAR19_MONTH12 = Fomula.PRICE_YEAR19_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH12) & EndIndex)

            Fomula.PRICE_YEAR20_MONTH1 = Fomula.PRICE_YEAR20_MONTH1.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH1) & strIndex)
            Fomula.PRICE_YEAR20_MONTH1 = Fomula.PRICE_YEAR20_MONTH1.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH1) & EndIndex)
            Fomula.PRICE_YEAR20_MONTH2 = Fomula.PRICE_YEAR20_MONTH2.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH2) & strIndex)
            Fomula.PRICE_YEAR20_MONTH2 = Fomula.PRICE_YEAR20_MONTH2.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH2) & EndIndex)
            Fomula.PRICE_YEAR20_MONTH3 = Fomula.PRICE_YEAR20_MONTH3.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH3) & strIndex)
            Fomula.PRICE_YEAR20_MONTH3 = Fomula.PRICE_YEAR20_MONTH3.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH3) & EndIndex)
            Fomula.PRICE_YEAR20_MONTH4 = Fomula.PRICE_YEAR20_MONTH4.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH4) & strIndex)
            Fomula.PRICE_YEAR20_MONTH4 = Fomula.PRICE_YEAR20_MONTH4.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH4) & EndIndex)
            Fomula.PRICE_YEAR20_MONTH5 = Fomula.PRICE_YEAR20_MONTH5.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH5) & strIndex)
            Fomula.PRICE_YEAR20_MONTH5 = Fomula.PRICE_YEAR20_MONTH5.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH5) & EndIndex)
            Fomula.PRICE_YEAR20_MONTH6 = Fomula.PRICE_YEAR20_MONTH6.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH6) & strIndex)
            Fomula.PRICE_YEAR20_MONTH6 = Fomula.PRICE_YEAR20_MONTH6.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH6) & EndIndex)
            Fomula.PRICE_YEAR20_MONTH7 = Fomula.PRICE_YEAR20_MONTH7.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH7) & strIndex)
            Fomula.PRICE_YEAR20_MONTH7 = Fomula.PRICE_YEAR20_MONTH7.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH7) & EndIndex)
            Fomula.PRICE_YEAR20_MONTH8 = Fomula.PRICE_YEAR20_MONTH8.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH8) & strIndex)
            Fomula.PRICE_YEAR20_MONTH8 = Fomula.PRICE_YEAR20_MONTH8.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH8) & EndIndex)
            Fomula.PRICE_YEAR20_MONTH9 = Fomula.PRICE_YEAR20_MONTH9.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH9) & strIndex)
            Fomula.PRICE_YEAR20_MONTH9 = Fomula.PRICE_YEAR20_MONTH9.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH9) & EndIndex)
            Fomula.PRICE_YEAR20_MONTH10 = Fomula.PRICE_YEAR20_MONTH10.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH10) & strIndex)
            Fomula.PRICE_YEAR20_MONTH10 = Fomula.PRICE_YEAR20_MONTH10.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH10) & EndIndex)
            Fomula.PRICE_YEAR20_MONTH11 = Fomula.PRICE_YEAR20_MONTH11.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH11) & strIndex)
            Fomula.PRICE_YEAR20_MONTH11 = Fomula.PRICE_YEAR20_MONTH11.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH11) & EndIndex)
            Fomula.PRICE_YEAR20_MONTH12 = Fomula.PRICE_YEAR20_MONTH12.Replace("@STR", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH12) & strIndex)
            Fomula.PRICE_YEAR20_MONTH12 = Fomula.PRICE_YEAR20_MONTH12.Replace("@END", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH12) & EndIndex)

            ''式をセット
            ''期間合計
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_IOC) = Fomula.ListPrice
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_TOTAL_IOC) = Fomula.DPerAfter
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.COST_TOTAL_IOC) = Fomula.DPerAfterrate
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT_IN) = Fomula.PRICE_CONT_TOTAL
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT_OUT) = Fomula.PRICE_OO_CONT_TOTAL
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1) = Fomula.IGF

            ''年度金額
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1 + 1) = Fomula.PRICE_YEAR1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2 + 1) = Fomula.PRICE_YEAR2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3 + 1) = Fomula.PRICE_YEAR3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4 + 1) = Fomula.PRICE_YEAR4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5 + 1) = Fomula.PRICE_YEAR5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6 + 1) = Fomula.PRICE_YEAR6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7 + 1) = Fomula.PRICE_YEAR7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8 + 1) = Fomula.PRICE_YEAR8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9 + 1) = Fomula.PRICE_YEAR9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10 + 1) = Fomula.PRICE_YEAR10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11 + 1) = Fomula.PRICE_YEAR11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12 + 1) = Fomula.PRICE_YEAR12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13 + 1) = Fomula.PRICE_YEAR13
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14 + 1) = Fomula.PRICE_YEAR14
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15 + 1) = Fomula.PRICE_YEAR15
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16 + 1) = Fomula.PRICE_YEAR16
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17 + 1) = Fomula.PRICE_YEAR17
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18 + 1) = Fomula.PRICE_YEAR18
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19 + 1) = Fomula.PRICE_YEAR19
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20 + 1) = Fomula.PRICE_YEAR20
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL + 1) = Fomula.PRICE_PAST_CONTRACT

            ''月度金額
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1 + 1) = Fomula.PRICE_YEAR1_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH2 + 1) = Fomula.PRICE_YEAR1_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH3 + 1) = Fomula.PRICE_YEAR1_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH4 + 1) = Fomula.PRICE_YEAR1_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH5 + 1) = Fomula.PRICE_YEAR1_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH6 + 1) = Fomula.PRICE_YEAR1_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH7 + 1) = Fomula.PRICE_YEAR1_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH8 + 1) = Fomula.PRICE_YEAR1_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH9 + 1) = Fomula.PRICE_YEAR1_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH10 + 1) = Fomula.PRICE_YEAR1_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH11 + 1) = Fomula.PRICE_YEAR1_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH12 + 1) = Fomula.PRICE_YEAR1_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH1 + 1) = Fomula.PRICE_YEAR2_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH2 + 1) = Fomula.PRICE_YEAR2_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH3 + 1) = Fomula.PRICE_YEAR2_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH4 + 1) = Fomula.PRICE_YEAR2_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH5 + 1) = Fomula.PRICE_YEAR2_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH6 + 1) = Fomula.PRICE_YEAR2_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH7 + 1) = Fomula.PRICE_YEAR2_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH8 + 1) = Fomula.PRICE_YEAR2_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH9 + 1) = Fomula.PRICE_YEAR2_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH10 + 1) = Fomula.PRICE_YEAR2_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH11 + 1) = Fomula.PRICE_YEAR2_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH12 + 1) = Fomula.PRICE_YEAR2_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH1 + 1) = Fomula.PRICE_YEAR3_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH2 + 1) = Fomula.PRICE_YEAR3_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH3 + 1) = Fomula.PRICE_YEAR3_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH4 + 1) = Fomula.PRICE_YEAR3_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH5 + 1) = Fomula.PRICE_YEAR3_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH6 + 1) = Fomula.PRICE_YEAR3_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH7 + 1) = Fomula.PRICE_YEAR3_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH8 + 1) = Fomula.PRICE_YEAR3_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH9 + 1) = Fomula.PRICE_YEAR3_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH10 + 1) = Fomula.PRICE_YEAR3_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH11 + 1) = Fomula.PRICE_YEAR3_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH12 + 1) = Fomula.PRICE_YEAR3_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH1 + 1) = Fomula.PRICE_YEAR4_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH2 + 1) = Fomula.PRICE_YEAR4_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH3 + 1) = Fomula.PRICE_YEAR4_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH4 + 1) = Fomula.PRICE_YEAR4_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH5 + 1) = Fomula.PRICE_YEAR4_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH6 + 1) = Fomula.PRICE_YEAR4_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH7 + 1) = Fomula.PRICE_YEAR4_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH8 + 1) = Fomula.PRICE_YEAR4_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH9 + 1) = Fomula.PRICE_YEAR4_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH10 + 1) = Fomula.PRICE_YEAR4_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH11 + 1) = Fomula.PRICE_YEAR4_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH12 + 1) = Fomula.PRICE_YEAR4_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH1 + 1) = Fomula.PRICE_YEAR5_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH2 + 1) = Fomula.PRICE_YEAR5_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH3 + 1) = Fomula.PRICE_YEAR5_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH4 + 1) = Fomula.PRICE_YEAR5_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH5 + 1) = Fomula.PRICE_YEAR5_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH6 + 1) = Fomula.PRICE_YEAR5_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH7 + 1) = Fomula.PRICE_YEAR5_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH8 + 1) = Fomula.PRICE_YEAR5_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH9 + 1) = Fomula.PRICE_YEAR5_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH10 + 1) = Fomula.PRICE_YEAR5_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH11 + 1) = Fomula.PRICE_YEAR5_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH12 + 1) = Fomula.PRICE_YEAR5_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH1 + 1) = Fomula.PRICE_YEAR6_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH2 + 1) = Fomula.PRICE_YEAR6_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH3 + 1) = Fomula.PRICE_YEAR6_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH4 + 1) = Fomula.PRICE_YEAR6_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH5 + 1) = Fomula.PRICE_YEAR6_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH6 + 1) = Fomula.PRICE_YEAR6_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH7 + 1) = Fomula.PRICE_YEAR6_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH8 + 1) = Fomula.PRICE_YEAR6_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH9 + 1) = Fomula.PRICE_YEAR6_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH10 + 1) = Fomula.PRICE_YEAR6_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH11 + 1) = Fomula.PRICE_YEAR6_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH12 + 1) = Fomula.PRICE_YEAR6_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH1 + 1) = Fomula.PRICE_YEAR7_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH2 + 1) = Fomula.PRICE_YEAR7_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH3 + 1) = Fomula.PRICE_YEAR7_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH4 + 1) = Fomula.PRICE_YEAR7_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH5 + 1) = Fomula.PRICE_YEAR7_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH6 + 1) = Fomula.PRICE_YEAR7_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH7 + 1) = Fomula.PRICE_YEAR7_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH8 + 1) = Fomula.PRICE_YEAR7_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH9 + 1) = Fomula.PRICE_YEAR7_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH10 + 1) = Fomula.PRICE_YEAR7_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH11 + 1) = Fomula.PRICE_YEAR7_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH12 + 1) = Fomula.PRICE_YEAR7_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH1 + 1) = Fomula.PRICE_YEAR8_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH2 + 1) = Fomula.PRICE_YEAR8_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH3 + 1) = Fomula.PRICE_YEAR8_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH4 + 1) = Fomula.PRICE_YEAR8_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH5 + 1) = Fomula.PRICE_YEAR8_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH6 + 1) = Fomula.PRICE_YEAR8_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH7 + 1) = Fomula.PRICE_YEAR8_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH8 + 1) = Fomula.PRICE_YEAR8_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH9 + 1) = Fomula.PRICE_YEAR8_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH10 + 1) = Fomula.PRICE_YEAR8_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH11 + 1) = Fomula.PRICE_YEAR8_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH12 + 1) = Fomula.PRICE_YEAR8_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH1 + 1) = Fomula.PRICE_YEAR9_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH2 + 1) = Fomula.PRICE_YEAR9_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH3 + 1) = Fomula.PRICE_YEAR9_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH4 + 1) = Fomula.PRICE_YEAR9_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH5 + 1) = Fomula.PRICE_YEAR9_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH6 + 1) = Fomula.PRICE_YEAR9_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH7 + 1) = Fomula.PRICE_YEAR9_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH8 + 1) = Fomula.PRICE_YEAR9_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH9 + 1) = Fomula.PRICE_YEAR9_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH10 + 1) = Fomula.PRICE_YEAR9_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH11 + 1) = Fomula.PRICE_YEAR9_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH12 + 1) = Fomula.PRICE_YEAR9_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH1 + 1) = Fomula.PRICE_YEAR10_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH2 + 1) = Fomula.PRICE_YEAR10_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH3 + 1) = Fomula.PRICE_YEAR10_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH4 + 1) = Fomula.PRICE_YEAR10_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH5 + 1) = Fomula.PRICE_YEAR10_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH6 + 1) = Fomula.PRICE_YEAR10_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH7 + 1) = Fomula.PRICE_YEAR10_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH8 + 1) = Fomula.PRICE_YEAR10_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH9 + 1) = Fomula.PRICE_YEAR10_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH10 + 1) = Fomula.PRICE_YEAR10_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH11 + 1) = Fomula.PRICE_YEAR10_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH12 + 1) = Fomula.PRICE_YEAR10_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH1 + 1) = Fomula.PRICE_YEAR11_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH2 + 1) = Fomula.PRICE_YEAR11_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH3 + 1) = Fomula.PRICE_YEAR11_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH4 + 1) = Fomula.PRICE_YEAR11_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH5 + 1) = Fomula.PRICE_YEAR11_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH6 + 1) = Fomula.PRICE_YEAR11_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH7 + 1) = Fomula.PRICE_YEAR11_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH8 + 1) = Fomula.PRICE_YEAR11_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH9 + 1) = Fomula.PRICE_YEAR11_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH10 + 1) = Fomula.PRICE_YEAR11_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH11 + 1) = Fomula.PRICE_YEAR11_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH12 + 1) = Fomula.PRICE_YEAR11_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH1 + 1) = Fomula.PRICE_YEAR12_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH2 + 1) = Fomula.PRICE_YEAR12_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH3 + 1) = Fomula.PRICE_YEAR12_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH4 + 1) = Fomula.PRICE_YEAR12_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH5 + 1) = Fomula.PRICE_YEAR12_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH6 + 1) = Fomula.PRICE_YEAR12_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH7 + 1) = Fomula.PRICE_YEAR12_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH8 + 1) = Fomula.PRICE_YEAR12_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH9 + 1) = Fomula.PRICE_YEAR12_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH10 + 1) = Fomula.PRICE_YEAR12_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH11 + 1) = Fomula.PRICE_YEAR12_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH12 + 1) = Fomula.PRICE_YEAR12_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH1 + 1) = Fomula.PRICE_YEAR13_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH2 + 1) = Fomula.PRICE_YEAR13_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH3 + 1) = Fomula.PRICE_YEAR13_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH4 + 1) = Fomula.PRICE_YEAR13_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH5 + 1) = Fomula.PRICE_YEAR13_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH6 + 1) = Fomula.PRICE_YEAR13_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH7 + 1) = Fomula.PRICE_YEAR13_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH8 + 1) = Fomula.PRICE_YEAR13_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH9 + 1) = Fomula.PRICE_YEAR13_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH10 + 1) = Fomula.PRICE_YEAR13_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH11 + 1) = Fomula.PRICE_YEAR13_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH12 + 1) = Fomula.PRICE_YEAR13_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH1 + 1) = Fomula.PRICE_YEAR14_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH2 + 1) = Fomula.PRICE_YEAR14_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH3 + 1) = Fomula.PRICE_YEAR14_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH4 + 1) = Fomula.PRICE_YEAR14_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH5 + 1) = Fomula.PRICE_YEAR14_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH6 + 1) = Fomula.PRICE_YEAR14_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH7 + 1) = Fomula.PRICE_YEAR14_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH8 + 1) = Fomula.PRICE_YEAR14_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH9 + 1) = Fomula.PRICE_YEAR14_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH10 + 1) = Fomula.PRICE_YEAR14_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH11 + 1) = Fomula.PRICE_YEAR14_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH12 + 1) = Fomula.PRICE_YEAR14_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH1 + 1) = Fomula.PRICE_YEAR15_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH2 + 1) = Fomula.PRICE_YEAR15_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH3 + 1) = Fomula.PRICE_YEAR15_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH4 + 1) = Fomula.PRICE_YEAR15_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH5 + 1) = Fomula.PRICE_YEAR15_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH6 + 1) = Fomula.PRICE_YEAR15_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH7 + 1) = Fomula.PRICE_YEAR15_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH8 + 1) = Fomula.PRICE_YEAR15_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH9 + 1) = Fomula.PRICE_YEAR15_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH10 + 1) = Fomula.PRICE_YEAR15_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH11 + 1) = Fomula.PRICE_YEAR15_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH12 + 1) = Fomula.PRICE_YEAR15_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH1 + 1) = Fomula.PRICE_YEAR16_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH2 + 1) = Fomula.PRICE_YEAR16_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH3 + 1) = Fomula.PRICE_YEAR16_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH4 + 1) = Fomula.PRICE_YEAR16_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH5 + 1) = Fomula.PRICE_YEAR16_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH6 + 1) = Fomula.PRICE_YEAR16_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH7 + 1) = Fomula.PRICE_YEAR16_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH8 + 1) = Fomula.PRICE_YEAR16_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH9 + 1) = Fomula.PRICE_YEAR16_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH10 + 1) = Fomula.PRICE_YEAR16_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH11 + 1) = Fomula.PRICE_YEAR16_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH12 + 1) = Fomula.PRICE_YEAR16_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH1 + 1) = Fomula.PRICE_YEAR17_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH2 + 1) = Fomula.PRICE_YEAR17_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH3 + 1) = Fomula.PRICE_YEAR17_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH4 + 1) = Fomula.PRICE_YEAR17_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH5 + 1) = Fomula.PRICE_YEAR17_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH6 + 1) = Fomula.PRICE_YEAR17_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH7 + 1) = Fomula.PRICE_YEAR17_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH8 + 1) = Fomula.PRICE_YEAR17_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH9 + 1) = Fomula.PRICE_YEAR17_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH10 + 1) = Fomula.PRICE_YEAR17_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH11 + 1) = Fomula.PRICE_YEAR17_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH12 + 1) = Fomula.PRICE_YEAR17_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH1 + 1) = Fomula.PRICE_YEAR18_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH2 + 1) = Fomula.PRICE_YEAR18_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH3 + 1) = Fomula.PRICE_YEAR18_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH4 + 1) = Fomula.PRICE_YEAR18_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH5 + 1) = Fomula.PRICE_YEAR18_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH6 + 1) = Fomula.PRICE_YEAR18_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH7 + 1) = Fomula.PRICE_YEAR18_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH8 + 1) = Fomula.PRICE_YEAR18_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH9 + 1) = Fomula.PRICE_YEAR18_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH10 + 1) = Fomula.PRICE_YEAR18_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH11 + 1) = Fomula.PRICE_YEAR18_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH12 + 1) = Fomula.PRICE_YEAR18_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH1 + 1) = Fomula.PRICE_YEAR19_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH2 + 1) = Fomula.PRICE_YEAR19_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH3 + 1) = Fomula.PRICE_YEAR19_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH4 + 1) = Fomula.PRICE_YEAR19_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH5 + 1) = Fomula.PRICE_YEAR19_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH6 + 1) = Fomula.PRICE_YEAR19_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH7 + 1) = Fomula.PRICE_YEAR19_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH8 + 1) = Fomula.PRICE_YEAR19_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH9 + 1) = Fomula.PRICE_YEAR19_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH10 + 1) = Fomula.PRICE_YEAR19_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH11 + 1) = Fomula.PRICE_YEAR19_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH12 + 1) = Fomula.PRICE_YEAR19_MONTH12
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH1 + 1) = Fomula.PRICE_YEAR20_MONTH1
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH2 + 1) = Fomula.PRICE_YEAR20_MONTH2
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH3 + 1) = Fomula.PRICE_YEAR20_MONTH3
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH4 + 1) = Fomula.PRICE_YEAR20_MONTH4
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH5 + 1) = Fomula.PRICE_YEAR20_MONTH5
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH6 + 1) = Fomula.PRICE_YEAR20_MONTH6
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH7 + 1) = Fomula.PRICE_YEAR20_MONTH7
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH8 + 1) = Fomula.PRICE_YEAR20_MONTH8
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH9 + 1) = Fomula.PRICE_YEAR20_MONTH9
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH10 + 1) = Fomula.PRICE_YEAR20_MONTH10
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH11 + 1) = Fomula.PRICE_YEAR20_MONTH11
            rows(0).Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12 + 1) = Fomula.PRICE_YEAR20_MONTH12
        End If


    End Sub


    ''' <summary>
    ''' 概　要：IGF金利行の作成処理（追加分、削除分）
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetIGFInterestrate(ByRef OutIGFDataTable As PSExcelDataTable,
                                   ByVal strContractNo As String)

        Try

            Dim isAddRow As Boolean = False         ''IGF行(追加行)を作成するかどうか
            Dim isDelRow As Boolean = False         ''IGF行(削除行)を作成するかどうか
            Dim loopCount As Integer = 0            ''作成するIGF行数(追加/削除でMax2行)

            ''IGF金利行（追加分の作成）		
            Dim fQtyPlus As New StringBuilder
            fQtyPlus.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.QTY)
            fQtyPlus.Append(CommonConstant.SQL_STR_NOT)
            fQtyPlus.Append(CommonConstant.SQL_STR_LIKE)
            fQtyPlus.Append(StringEdit.EncloseSingleQuotation("-*"))

            ''追加分の作成flgを立てる
            If OutIGFDataTable.Select(fQtyPlus.ToString).Length > 0 Then
                loopCount = loopCount + 1
                isAddRow = True
            End If

            ''IGF金利行（削除の作成）		
            Dim fQtyMinus As New StringBuilder
            fQtyMinus.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.QTY)
            fQtyMinus.Append(CommonConstant.SQL_STR_LIKE)
            fQtyMinus.Append(StringEdit.EncloseSingleQuotation("-*"))

            ''削除分の作成flgを立てる
            If OutIGFDataTable.Select(fQtyMinus.ToString).Length > 0 Then
                loopCount = loopCount + 1
                isDelRow = True
            End If

            ''追加/削除のデータを書き込み
            Dim row As DataRow
            For i As Integer = 1 To loopCount

                row = OutIGFDataTable.NewRow()

                ''追加分の処理
                If isAddRow Then

                    Dim filter As New StringBuilder
                    ''新規の集計行取得
                    filter.Append("SummaryNM")
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(CELLVALUE_SummaryNM_NewOrDel))
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append("SortNMNewOrDel")
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(CELLVALUE_SortNMNewOrDel_NEW))

                    '展開金額
                    row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_TO_SPLIT) = SUMMARYROW_FOMULA_PRICE_TO_SPLIT.Replace("@", CInt(OutIGFDataTable.Select(filter.ToString)(0).Item("OutExcelRow")))
                    row.Item("SummaryNM") = CELLVALUE_SummaryNM_IGFINSROW

                    'START 変更管理#27（1285固定COST%の定期メンテナンス対応）　2016/04 ueda
                    'GP%の設定
                    row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH) = InterestrateGpGet()
                    'END 変更管理#27（1285固定COST%の定期メンテナンス対応）　2016/04 ueda

                    '行追加
                    OutIGFDataTable.Rows.Add(row)

                    isAddRow = False
                    Continue For

                End If

                ''--------------------------------------------------------
                ''                      削除分の処理
                ''--------------------------------------------------------
                If isDelRow Then

                    Dim filter As New StringBuilder

                    ''削除の集計行取得
                    filter.Append("SummaryNM")
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(CELLVALUE_SummaryNM_NewOrDel))
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append("SortNMNewOrDel")
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(CELLVALUE_SortNMNewOrDel_DEL))

                    '展開金額
                    row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_TO_SPLIT) = SUMMARYROW_FOMULA_PRICE_TO_SPLIT.Replace("@", CInt(OutIGFDataTable.Select(filter.ToString)(0).Item("OutExcelRow")))
                    row.Item("SummaryNM") = CELLVALUE_SummaryNM_IGFDELROW

                    'START 変更管理#27（1285固定COST%の定期メンテナンス対応）　2016/04 ueda
                    'GP%の設定
                    row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH) = InterestrateGpGet()
                    'END 変更管理#27（1285固定COST%の定期メンテナンス対応）　2016/04 ueda

                    '行追加
                    OutIGFDataTable.Rows.Add(row)

                    Continue For
                End If
            Next

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    ''※レスポンス向上のため、値を纏めて張り付ける仕様とする。
    ''  概要：SetExcelRowValue で貼り付け用のデータを取得
    ''　　　　InsertExcelRow　 で書式の設定を行う。
    ''
    ''※項目の開始行をEXCEL_PAYMENTLINEDATE_OUTROW　⇒　EXCEL_IGFDATA_OUTROW　へ置き換える。
    ''　修正箇所多数のため、Str/Endコメントは省略
    ''' <summary>
    ''' 概　要：IGF依頼後シートの作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub OutIGFResultSheet(ByRef xlIGFResultSheet As Excel.Worksheet, _
                                  ByVal OutIGFDataTable As PSExcelDataTable)

        ''契約書別紙B　記載用のExcel式
        Dim FORMULA_LEASE As String = "=SUM(Row6:Row@)".Replace("Row", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_LEASE))
        Dim FORMULA_FINANCE As String = "=SUM(Row6:Row@)".Replace("Row", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_FINANCE))
        Dim FORMULA_LEASE_Normal As String = ("=IF(Row1@ = " & """" & "ﾘｰｽ" & """" & ",SUM(" & "INDIRECT(ADDRESS(@,Row2 +((YEAR(WS1!$G$7) - WS1!$H$7) * 12 + Month(WS1!$G$7))) & " & """" & ":" & """" & " & ADDRESS(@,Row2 +(WS1!$I$7 - WS1!$H$7 + 1) * 12 - 1))),0)").Replace("Row1", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.IGF_CONT_FORM)).Replace("Row2", ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH1)
        Dim FORMULA_FINANCE_Normal As String = ("=IF(Row1@ = " & """" & "ﾌｧｲﾅﾝｽ" & """" & ",SUM(" & "INDIRECT(ADDRESS(@,Row2 +((YEAR(WS1!$G$7) - WS1!$H$7) * 12 + Month(WS1!$G$7))) & " & """" & ":" & """" & " & ADDRESS(@,Row2 +(WS1!$I$7 - WS1!$H$7 + 1) * 12 - 1))),0)").Replace("Row1", ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.IGF_CONT_FORM)).Replace("Row2", ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH1)

        Dim xlInRange As Excel.Range
        Dim xlInterior As Excel.Interior
        Dim index As Integer = EXCEL_IGFDATA_OUTROW - 1
        Try
            ''Template行の一括貼り付け(出力対象行を取得)
            Dim filter As New StringBuilder
            filter.Append("SummaryNM")
            filter.Append(" IN ")
            filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            filter.Append(StringEdit.EncloseSingleQuotation(CELLVALUE_SummaryNM_Normal))
            filter.Append(CommonConstant.STR_COMMA)
            filter.Append(StringEdit.EncloseSingleQuotation(CELLVALUE_SummaryNM_BrandInfo))
            filter.Append(CommonConstant.STR_COMMA)
            filter.Append(StringEdit.EncloseSingleQuotation(CELLVALUE_SummaryNM_InstDay))
            filter.Append(CommonConstant.STR_COMMA)
            filter.Append(StringEdit.EncloseSingleQuotation(CELLVALUE_SummaryNM_SortNMQCOS))
            filter.Append(CommonConstant.STR_COMMA)
            filter.Append(StringEdit.EncloseSingleQuotation(CELLVALUE_SummaryNM_NewOrDel))
            filter.Append(CommonConstant.STR_COMMA)
            filter.Append(StringEdit.EncloseSingleQuotation(CELLVALUE_SummaryNM_ALLSUM))
            filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

            ''Insert処理
            Call InsertRow(xlIGFResultSheet, OutIGFDataTable.Select(filter.ToString).Length + EXCEL_IGFDATA_OUTROW - 1)

            ''貼り付け処理
            Call GetExcelFomula(xlIGFResultSheet, OutIGFDataTable.Select(filter.ToString).Length + EXCEL_IGFDATA_OUTROW - 1)

            ''以下、各集計行の集計位置を格納
            Dim groupIndex As GrIndex
            groupIndex = SetGroupIndex(groupIndex, "Init", EXCEL_IGFDATA_OUTROW)

            ''貼り付ける値を格納する
            Dim formulaValue(,) As Object           ''テンプレート行の年額/月額式
            Dim pasteValue(,) As Object
            ReDim pasteValue(OutIGFDataTable.Select(filter.ToString).Length, _
                             ExcelWrite.IGFColumn.PRICE_FINANCE - 1)
            Dim pasteValue2() As Object
            ReDim pasteValue2(ExcelWrite.IGFColumn.PRICE_FINANCE - 1)
            Dim wCol As Integer

            xlInRange = xlIGFResultSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.LOCK_FLAG) & 6 & _
                                               ":" & _
                                               ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_FINANCE) & 6)

            formulaValue = xlInRange.FormulaR1C1

            ''※ファイル名が変わったら背景色を変える。
            Dim isFirst As Boolean = True
            Dim beforeFileNm As String
            Dim nowFileNm As String

            '集計対象行範囲保存変数
            Dim StartRow1 As Integer = 0
            Dim EndRow1 As Integer = 0
            Dim StartRow2 As Integer = 0
            Dim EndRow2 As Integer = 0
            Dim StartRow3 As Integer = 0
            Dim EndRow3 As Integer = 0
            Dim RR As Integer = 9

            For Each Row As DataRow In OutIGFDataTable.Rows

                RR = RR + 1

                ''修正行の種類に応じてExcelRow書式と値をセットする。
                Select Case Row.Item("SummaryNM").ToString

                    Case CELLVALUE_SummaryNM_Normal

                        ''通常行（月度金額以外）
                        index = index + 1
                        Call SetExcelRowValueNormal(index - EXCEL_IGFDATA_OUTROW, pasteValue, Row)

                        ''通常行（月度金額/Excel式）
                        xlInRange = xlIGFResultSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH1) & index & _
                                                           ":" & _
                                                           ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH12) & index)

                        Call SetExcelRowValueNormalYEAR_MONTH(index - EXCEL_IGFDATA_OUTROW, pasteValue, formulaValue, Row)

                        ''契約書別紙Bの小計
                        pasteValue(index - EXCEL_IGFDATA_OUTROW, ExcelWrite.IGFColumn.PRICE_LEASE - 1) = FORMULA_LEASE_Normal.Replace("@", index)
                        pasteValue(index - EXCEL_IGFDATA_OUTROW, ExcelWrite.IGFColumn.PRICE_FINANCE - 1) = FORMULA_FINANCE_Normal.Replace("@", index)

                        ''※ファイル名が変わったら背景色を変える。
                        nowFileNm = pasteValue(index - EXCEL_IGFDATA_OUTROW, ExcelWrite.IGFColumn.FILE_NAME - 1)
                        If isFirst = True Then
                            isFirst = False
                            xlInRange = xlIGFResultSheet.Cells(index, ExcelWrite.IGFColumn.FILE_NAME)
                            xlInterior = xlInRange.Interior
                            xlInterior.Color = RGB(0, 176, 240)
                        End If
                        If nowFileNm <> beforeFileNm Then
                            beforeFileNm = nowFileNm
                            xlInRange = xlIGFResultSheet.Cells(index, ExcelWrite.IGFColumn.FILE_NAME)
                            xlInterior = xlInRange.Interior
                            xlInterior.Color = RGB(0, 176, 240)
                        End If

                        '集計対象行範囲の保存
                        If StartRow1 = 0 Then
                            StartRow1 = RR
                        End If
                        If StartRow2 = 0 Then
                            StartRow2 = RR
                        End If
                        If StartRow3 = 0 Then
                            StartRow3 = RR
                        End If
                        EndRow1 = RR
                        EndRow2 = RR
                        EndRow3 = RR

                    Case CELLVALUE_SummaryNM_BrandInfo

                        ''※ファイル名が変わったら背景色を変える。
                        isFirst = True

                        ''Burand集計行
                        index = index + 1

                        ''値のセット
                        Call SetExcelRowValueBrandInfo(index - EXCEL_IGFDATA_OUTROW, pasteValue, Row)

                        ''書式のセット
                        xlInRange = xlIGFResultSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.LOCK_FLAG) & index & _
                                                           ":" & _
                                                           ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH12) & index)
                        Call InsertExcelRowBrandInfo(xlInRange, Row)

                        ''グループ化
                        xlInRange = xlIGFResultSheet.Rows(groupIndex.BrandInfo & ":" & index - 1)
                        xlInRange.Group()
                        groupIndex = SetGroupIndex(groupIndex, CELLVALUE_SummaryNM_BrandInfo, index)

                        ''契約書別紙Bの小計
                        pasteValue(index - EXCEL_IGFDATA_OUTROW, ExcelWrite.IGFColumn.PRICE_LEASE - 1) = ""
                        pasteValue(index - EXCEL_IGFDATA_OUTROW, ExcelWrite.IGFColumn.PRICE_FINANCE - 1) = ""

                        '集計式のセット
                        Call setSummaryFormula(pasteValue, index, StartRow1, EndRow1)
                        '集計行初期化
                        StartRow1 = 0
                        EndRow1 = 0

                    Case CELLVALUE_SummaryNM_SortNMQCOS

                        ''※ファイル名が変わったら背景色を変える。
                        isFirst = True

                        ''QCOS集計行
                        index = index + 1

                        ''値のセット
                        Call SetExcelRowValueQCOS(index - EXCEL_IGFDATA_OUTROW, pasteValue, Row)

                        ''書式のセット
                        xlInRange = xlIGFResultSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.LOCK_FLAG) & index & _
                                                           ":" & _
                                                           ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH12) & index)
                        Call InsertExcelRowQCOS(xlInRange, Row)

                        ''グループ化
                        xlInRange = xlIGFResultSheet.Rows(groupIndex.QCOS & ":" & index - 1)
                        xlInRange.Group()
                        groupIndex = SetGroupIndex(groupIndex, CELLVALUE_SummaryNM_SortNMQCOS, index)

                        ''契約書別紙Bの小計
                        pasteValue(index - EXCEL_IGFDATA_OUTROW, ExcelWrite.IGFColumn.PRICE_LEASE - 1) = ""
                        pasteValue(index - EXCEL_IGFDATA_OUTROW, ExcelWrite.IGFColumn.PRICE_FINANCE - 1) = ""

                    Case CELLVALUE_SummaryNM_InstDay

                        ''※ファイル名が変わったら背景色を変える。
                        isFirst = True

                        ''導入年月集計行
                        index = index + 1

                        ''値のセット
                        Call SetExcelRowValueInstDay(index - EXCEL_IGFDATA_OUTROW, pasteValue, Row)

                        ''書式のセット
                        xlInRange = xlIGFResultSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.LOCK_FLAG) & index & _
                                                           ":" & _
                                                           ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH12) & index)
                        Call InsertExcelRowInstDay(xlInRange, Row)

                        ''グループ化
                        xlInRange = xlIGFResultSheet.Rows(groupIndex.InstDay & ":" & index - 1)
                        xlInRange.Group()
                        groupIndex = SetGroupIndex(groupIndex, CELLVALUE_SummaryNM_InstDay, index)

                        ''契約書別紙Bの小計
                        pasteValue(index - EXCEL_IGFDATA_OUTROW, ExcelWrite.IGFColumn.PRICE_LEASE - 1) = ""
                        pasteValue(index - EXCEL_IGFDATA_OUTROW, ExcelWrite.IGFColumn.PRICE_FINANCE - 1) = ""

                        '集計式のセット
                        Call setSummaryFormula(pasteValue, index, StartRow2, EndRow2)
                        '集計行初期化
                        StartRow2 = 0
                        EndRow2 = 0

                    Case CELLVALUE_SummaryNM_NewOrDel

                        ''※ファイル名が変わったら背景色を変える。
                        isFirst = True

                        ''新規/削除行
                        index = index + 1

                        ''値のセット
                        Call SetExcelRowValueNewOrDel(index - EXCEL_IGFDATA_OUTROW, pasteValue, Row)

                        ''書式のセット
                        xlInRange = xlIGFResultSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.LOCK_FLAG) & index & _
                                                           ":" & _
                                                           ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH12) & index)
                        Call InsertExcelRowNewOrDel(xlInRange, Row, IGFSHEETNM_RESULT)

                        ''グループ化
                        xlInRange = xlIGFResultSheet.Rows(groupIndex.NewOrDel & ":" & index - 1)
                        xlInRange.Group()
                        groupIndex = SetGroupIndex(groupIndex, CELLVALUE_SummaryNM_NewOrDel, index)

                        ''契約書別紙Bの小計
                        pasteValue(index - EXCEL_IGFDATA_OUTROW, ExcelWrite.IGFColumn.PRICE_LEASE - 1) = ""
                        pasteValue(index - EXCEL_IGFDATA_OUTROW, ExcelWrite.IGFColumn.PRICE_FINANCE - 1) = ""

                        '集計式のセット 
                        Call setSummaryFormula(pasteValue, index, StartRow3, EndRow3)
                        '集計行初期化
                        StartRow3 = 0
                        EndRow3 = 0

                    Case CELLVALUE_SummaryNM_ALLSUM

                        ''※ファイル名が変わったら背景色を変える。
                        isFirst = True

                        ''総合合計
                        index = index + 1

                        ''値のセット
                        Call SetExcelRowValueALLSUM(index - EXCEL_IGFDATA_OUTROW, pasteValue, Row)

                        ''書式のセット
                        xlInRange = xlIGFResultSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.LOCK_FLAG) & index & _
                                                           ":" & _
                                                           ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH12) & index)
                        Call InsertExcelRowALLSUM(xlInRange, Row)

                        ''契約書別紙Bの小計
                        pasteValue(index - EXCEL_IGFDATA_OUTROW, ExcelWrite.IGFColumn.PRICE_LEASE - 1) = ""
                        pasteValue(index - EXCEL_IGFDATA_OUTROW, ExcelWrite.IGFColumn.PRICE_FINANCE - 1) = ""

                End Select

                '2次元配列を１次元にコピー
                For wCol = ExcelWrite.IGFColumn.LOCK_FLAG - 1 To ExcelWrite.IGFColumn.PRICE_FINANCE - 1
                    pasteValue2(wCol) = pasteValue(index - EXCEL_IGFDATA_OUTROW, wCol)
                Next
                '配列（行単位）をExcelに貼り付け
                xlInRange = xlIGFResultSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.LOCK_FLAG) & index & _
                                                   ":" & _
                                                   ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_FINANCE) & index)
                xlInRange.Formula = pasteValue2

            Next

            ''IGF金利行の処理
            Dim IGFfilter As New StringBuilder
            IGFfilter.Append("SummaryNM")
            IGFfilter.Append(" IN ")
            IGFfilter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            IGFfilter.Append(StringEdit.EncloseSingleQuotation(CELLVALUE_SummaryNM_IGFINSROW))
            IGFfilter.Append(CommonConstant.STR_COMMA)
            IGFfilter.Append(StringEdit.EncloseSingleQuotation(CELLVALUE_SummaryNM_IGFDELROW))
            IGFfilter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
            For Each Row As DataRow In OutIGFDataTable.Select(IGFfilter.ToString)

                ''IGF金利行の式の書き込み
                If Row.Item("SummaryNM") = CELLVALUE_SummaryNM_IGFDELROW Then

                    ''削除
                    xlInRange = xlIGFResultSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.LOCK_FLAG) & index + 3 & _
                                                       ":" & _
                                                       ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH12) & index + 3)
                    Call InsertExcelRowIGF(xlInRange, Row)

                Else

                    ''追加
                    xlInRange = xlIGFResultSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.LOCK_FLAG) & index + 4 & _
                                                       ":" & _
                                                       ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH12) & index + 4)
                    Call InsertExcelRowIGF(xlInRange, Row)

                End If
            Next

            ''契約書別紙Bの金額セット
            xlInRange = xlIGFResultSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.FILE_NAME) & index + 8)
            xlInRange.Formula = FORMULA_LEASE.Replace("@", index)
            xlInRange = xlIGFResultSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.FILE_NAME) & index + 9)
            xlInRange.Formula = FORMULA_FINANCE.Replace("@", index)


            '展開期間に応じて不要部分を畳む
            Dim int1 As Integer
            Dim ii As Integer
            Dim jj As Integer
            Dim FromYear As Integer
            Dim FromMonth As Integer
            Dim xlColumn As Excel.Range
            Dim xlColumns As Excel.Range
            Dim xlCell As Excel.Range
            Dim xlCells As Excel.Range
            Dim strMsg As String = ""

            '展開期間取得
            int1 = CommonVariable.PaymentPeriod     'getDeploymentPeriod()

            '月額・年額エリア表記変更
            If int1 < 20 Then
                '表記年数別値取得
                Select Case int1
                    Case 1
                        '月額表記削除開始セル設定
                        FromMonth = ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH1
                        '年額表記非表示開始セル設定
                        FromYear = ExcelWrite.IGFColumn.PRICE_YEAR2
                    Case 2
                        '月額表記削除開始セル設定
                        FromMonth = ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH1
                        '年額表記非表示開始セル設定
                        FromYear = ExcelWrite.IGFColumn.PRICE_YEAR3
                    Case 3
                        '月額表記削除開始セル設定
                        FromMonth = ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH1
                        '年額表記非表示開始セル設定
                        FromYear = ExcelWrite.IGFColumn.PRICE_YEAR4
                    Case 4
                        '月額表記削除開始セル設定
                        FromMonth = ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH1
                        '年額表記非表示開始セル設定
                        FromYear = ExcelWrite.IGFColumn.PRICE_YEAR5
                    Case 5
                        '月額表記削除開始セル設定
                        FromMonth = ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH1
                        '年額表記非表示開始セル設定
                        FromYear = ExcelWrite.IGFColumn.PRICE_YEAR6
                    Case 6
                        '月額表記削除開始セル設定
                        FromMonth = ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH1
                        '年額表記非表示開始セル設定
                        FromYear = ExcelWrite.IGFColumn.PRICE_YEAR7
                    Case 7
                        '月額表記削除開始セル設定
                        FromMonth = ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH1
                        '年額表記非表示開始セル設定
                        FromYear = ExcelWrite.IGFColumn.PRICE_YEAR8
                    Case 8
                        '月額表記削除開始セル設定
                        FromMonth = ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH1
                        '年額表記非表示開始セル設定
                        FromYear = ExcelWrite.IGFColumn.PRICE_YEAR9
                    Case 9
                        '月額表記削除開始セル設定
                        FromMonth = ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH1
                        '年額表記非表示開始セル設定
                        FromYear = ExcelWrite.IGFColumn.PRICE_YEAR10
                    Case 10
                        '月額表記削除開始セル設定
                        FromMonth = ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH1
                        '年額表記非表示開始セル設定
                        FromYear = ExcelWrite.IGFColumn.PRICE_YEAR11
                    Case 11
                        '月額表記削除開始セル設定
                        FromMonth = ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH1
                        '年額表記非表示開始セル設定
                        FromYear = ExcelWrite.IGFColumn.PRICE_YEAR12
                    Case 12
                        '月額表記削除開始セル設定
                        FromMonth = ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH1
                        '年額表記非表示開始セル設定
                        FromYear = ExcelWrite.IGFColumn.PRICE_YEAR13
                    Case 13
                        '月額表記削除開始セル設定
                        FromMonth = ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH1
                        '年額表記非表示開始セル設定
                        FromYear = ExcelWrite.IGFColumn.PRICE_YEAR14
                    Case 14
                        '月額表記削除開始セル設定
                        FromMonth = ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH1
                        '年額表記非表示開始セル設定
                        FromYear = ExcelWrite.IGFColumn.PRICE_YEAR15
                    Case 15
                        '月額表記削除開始セル設定
                        FromMonth = ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH1
                        '年額表記非表示開始セル設定
                        FromYear = ExcelWrite.IGFColumn.PRICE_YEAR16
                    Case 16
                        '月額表記削除開始セル設定
                        FromMonth = ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH1
                        '年額表記非表示開始セル設定
                        FromYear = ExcelWrite.IGFColumn.PRICE_YEAR17
                    Case 17
                        '月額表記削除開始セル設定
                        FromMonth = ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH1
                        '年額表記非表示開始セル設定
                        FromYear = ExcelWrite.IGFColumn.PRICE_YEAR18
                    Case 18
                        '月額表記削除開始セル設定
                        FromMonth = ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH1
                        '年額表記非表示開始セル設定
                        FromYear = ExcelWrite.IGFColumn.PRICE_YEAR19
                    Case 19
                        '月額表記削除開始セル設定
                        FromMonth = ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH1
                        '年額表記非表示開始セル設定
                        FromYear = ExcelWrite.IGFColumn.PRICE_YEAR20
                End Select

                xlColumns = xlIGFResultSheet.Columns
                xlCells = xlIGFResultSheet.Cells

                '年額表記をグループ化
                For ii = ExcelWrite.IGFColumn.PRICE_YEAR20 To FromYear Step -1
                    '範囲内の値を０クリアする
                    For jj = EXCEL_IGFDATA_OUTROW To index      '行ループ
                        xlCell = DirectCast(xlCells.Item(jj, ExcelWrite.IGFColumn.LINE_NO), Excel.Range)
                        If IsNumeric(xlCell.Value) Then         'LINE_NOが数値→有効明細行
                            xlCell = DirectCast(xlCells.Item(jj, ii), Excel.Range)
                            xlCell.Value = 0                        '値クリア
                        End If
                    Next
                    '列をグループ化して隠す
                    xlColumn = DirectCast(xlColumns.Item(ii), Excel.Range)
                    xlColumn.Group()
                    xlColumn.Hidden = True
                Next
                '月額表記を削除
                For ii = ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH12 To FromMonth Step -1
                    xlColumn = DirectCast(xlColumns.Item(ii), Excel.Range)
                    xlColumn.Delete()
                Next
            End If

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlInterior, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlInRange, ExcelObjRelease.OBJECT_NOTHING)

        End Try

    End Sub

    ''' <summary>
    ''' 概　要：IGF依頼後シートに行の挿入処理
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InsertRow(ByRef xlIGFResultSheet As Excel.Worksheet,
                          ByVal Count As Integer)

        Dim xlRange As Excel.Range
        Try
            Dim insertArea As String

            insertArea = EXCEL_IGFDATA_OUTROW & _
                ":" & _
                Count

            xlRange = xlIGFResultSheet.Range(insertArea)

            ''行の挿入処理
            xlRange.Insert(Shift:=Excel.XlInsertShiftDirection.xlShiftDown)

        Catch ex As Exception
            Throw ex
        Finally
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try

    End Sub

    ''' <summary>
    ''' 概　要：IGF依頼前シートのTemplate行を一括貼り付け
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetExcelFomula(ByVal sheet As Excel.Worksheet, _
                               ByVal count As Integer)

        Dim fomulaRow As Excel.Range
        Dim ParstRow As Excel.Range

        Try
            ''テンプレ行のコピー
            fomulaRow = sheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.LOCK_FLAG) & "6" & _
                                    ":" & _
                                    ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH12) & "6")
            fomulaRow.Copy()

            ''貼り付け
            ParstRow = sheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.LOCK_FLAG) & EXCEL_IGFDATA_OUTROW &
                                   ":" &
                                   ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH12) & count)

            ParstRow.PasteSpecial()

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(fomulaRow, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(ParstRow, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try

    End Sub

    ''' <summary>
    ''' 概　要：通常行の値を配列に格納する
    ''' 説　明：※IGFファイル作成時のレスポンスアップのため
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetExcelRowValueNormal(ByVal index As Integer, _
                                       ByRef pasteValue(,) As Object, _
                                       ByRef Row As DataRow)

        Try

            ''=====================================================================
            ''              テンプレート式以外の箇所に値をセットする。
            ''=====================================================================
            ''ﾛｯｸFLG
            pasteValue(index, ExcelWrite.IGFColumn.LOCK_FLAG - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG)

            ''有効/無効
            pasteValue(index, ExcelWrite.IGFColumn.VALID_FLAG - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG)

            ''NO
            pasteValue(index, ExcelWrite.IGFColumn.LINE_NO - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO)

            ''ﾌｧｲﾙ名
            pasteValue(index, ExcelWrite.IGFColumn.FILE_NAME - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME)

            ''ﾌｧｲﾙ名Suffix
            pasteValue(index, ExcelWrite.IGFColumn.FILE_NAME_SUFFIX - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX)

            ''ﾌｧｲﾙ内Suffix
            pasteValue(index, ExcelWrite.IGFColumn.FILE_NAME_SUFFIX_INTR - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR)

            ''契約順番
            pasteValue(index, ExcelWrite.IGFColumn.CONTRACT - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT)

            ''案件番号
            pasteValue(index, ExcelWrite.IGFColumn.PROJ_ID - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROJ_ID)

            ''契約通番
            pasteValue(index, ExcelWrite.IGFColumn.CONTRACT_SEQ - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT_SEQ)

            ''新規/既存
            pasteValue(index, ExcelWrite.IGFColumn.NEW_EXIST - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.NEW_EXIST)

            ''お客様集計ｶﾃｺﾞﾘ
            pasteValue(index, ExcelWrite.IGFColumn.CUST_CATEGORY - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CUST_CATEGORY)

            ''実行通知書_発行予定日
            pasteValue(index, ExcelWrite.IGFColumn.LETTER_PLAN_DATE - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LETTER_PLAN_DATE)

            ''実行通知書_受領日
            pasteValue(index, ExcelWrite.IGFColumn.LETTER_ACCEPT_DATE - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LETTER_ACCEPT_DATE)

            ''発注完了日
            pasteValue(index, ExcelWrite.IGFColumn.ORDER_DATE - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.ORDER_DATE)

            ''実行通知書番号
            pasteValue(index, ExcelWrite.IGFColumn.LETTER_ID - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LETTER_ID)

            ''Brand Category_BU
            pasteValue(index, ExcelWrite.IGFColumn.BU - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BU)

            ''Brand Category_Brand
            pasteValue(index, ExcelWrite.IGFColumn.BRAND - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND)

            ''Brand Category_ｻﾏﾘｰ用ｶﾃｺﾞﾘ
            pasteValue(index, ExcelWrite.IGFColumn.SUM_CATEGORY - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.SUM_CATEGORY)

            ''Brand Category_SubBrand
            pasteValue(index, ExcelWrite.IGFColumn.BRAND_SUB - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND_SUB)

            ''Brand Category_Option1
            pasteValue(index, ExcelWrite.IGFColumn.OP1 - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.OP1)

            ''Brand承認_起票番号
            pasteValue(index, ExcelWrite.IGFColumn.BRAND_AP_FORM - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_FORM)

            ''Brand承認_申請番号
            pasteValue(index, ExcelWrite.IGFColumn.BRAND_AP_REQ - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_REQ)

            ''Brand承認_承認番号
            pasteValue(index, ExcelWrite.IGFColumn.BRAND_AP_CONF - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_CONF)

            ''入力項目ﾊﾟﾀｰﾝ SEQ
            pasteValue(index, ExcelWrite.IGFColumn.PATTERN_CD - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD)

            ''入力項目ﾊﾟﾀｰﾝ
            pasteValue(index, ExcelWrite.IGFColumn.PATTERN - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN)

            ''ﾊﾟﾀｰﾝ別入力項目_項目１
            pasteValue(index, ExcelWrite.IGFColumn.PROD_ITEM01 - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01)

            ''ﾊﾟﾀｰﾝ別入力項目_項目２
            pasteValue(index, ExcelWrite.IGFColumn.PROD_ITEM02 - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02)

            ''ﾊﾟﾀｰﾝ別入力項目_項目３
            pasteValue(index, ExcelWrite.IGFColumn.PROD_ITEM03 - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03)

            ''ﾊﾟﾀｰﾝ別入力項目_項目４
            pasteValue(index, ExcelWrite.IGFColumn.PROD_ITEM04 - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM04)

            ''ﾊﾟﾀｰﾝ別入力項目_項目５
            pasteValue(index, ExcelWrite.IGFColumn.PROD_ITEM05 - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM05)
            ''ﾊﾟﾀｰﾝ別入力項目_項目１０
            pasteValue(index, ExcelWrite.IGFColumn.PROD_ORIGIN_INFO - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10)
            ''ﾊﾟﾀｰﾝ別入力項目_項目１１
            pasteValue(index, ExcelWrite.IGFColumn.PROD_ITEM11 - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11)

            ''ﾊﾟﾀｰﾝ別入力項目_項目１２
            pasteValue(index, ExcelWrite.IGFColumn.PROD_ITEM12 - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12)

            ''ﾊﾟﾀｰﾝ別入力項目_項目１３
            pasteValue(index, ExcelWrite.IGFColumn.PROD_ITEM13 - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM13)

            ''ﾊﾟﾀｰﾝ別入力項目_項目１４
            pasteValue(index, ExcelWrite.IGFColumn.PROD_ITEM14 - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM14)

            ''ﾊﾟﾀｰﾝ別入力項目_項目１５
            pasteValue(index, ExcelWrite.IGFColumn.PROD_ITEM15 - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM15)

            ''ﾊﾟﾀｰﾝ別入力項目_項目１６
            pasteValue(index, ExcelWrite.IGFColumn.PROD_ITEM16 - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM16)

            ''ﾊﾟﾀｰﾝ別入力項目_項目１７
            pasteValue(index, ExcelWrite.IGFColumn.PROD_ITEM17 - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM17)

            ''ﾊﾟﾀｰﾝ別入力項目_項目１８
            pasteValue(index, ExcelWrite.IGFColumn.PROD_ITEM18 - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM18)

            ''ﾊﾟﾀｰﾝ別入力項目_項目１９
            pasteValue(index, ExcelWrite.IGFColumn.PROD_ITEM19 - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM19)

            ''ﾊﾟﾀｰﾝ別入力項目_項目２０
            pasteValue(index, ExcelWrite.IGFColumn.PROD_ITEM20 - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM20)

            'START 変更管理#??（1346 e-PricerValidation対応）　2016/01 sugo
            ' ''ﾊﾟﾀｰﾝ別入力項目_項目２１
            'pasteValue(index, ExcelWrite.IGFColumn.PROD_ITEM21 - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM21)
            'END   変更管理#??（1346 e-PricerValidation対応）　2016/01 sugo

            ''ﾊﾟﾀｰﾝ別入力項目_項目２２
            pasteValue(index, ExcelWrite.IGFColumn.PROD_ITEM22 - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM22)

            ''ﾊﾟﾀｰﾝ別入力項目_項目２３
            pasteValue(index, ExcelWrite.IGFColumn.PROD_ITEM23 - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM23)

            ''ﾊﾟﾀｰﾝ別入力項目_項目２４
            pasteValue(index, ExcelWrite.IGFColumn.PROD_ITEM24 - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM24)

            ''製品･ｻｰﾋﾞｽ廃止発表日
            pasteValue(index, ExcelWrite.IGFColumn.WD_ANNT_DATE - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.WD_ANNT_DATE)

            ''製品･ｻｰﾋﾞｽ廃止予定
            pasteValue(index, ExcelWrite.IGFColumn.WD_DATE - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.WD_DATE)

            ''価格改定予定日
            pasteValue(index, ExcelWrite.IGFColumn.PRICE_CHG_DATE - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_CHG_DATE)

            ''数量
            pasteValue(index, ExcelWrite.IGFColumn.QTY - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.QTY)

            ''導入_年月
            pasteValue(index, ExcelWrite.IGFColumn.INST_DATE - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.INST_DATE)

            ''請求開始_年月
            pasteValue(index, ExcelWrite.IGFColumn.PAY_START_DATE - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE)

            ''請求終了_年月
            pasteValue(index, ExcelWrite.IGFColumn.PAY_END_DATE - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE)

            ''支払方法
            pasteValue(index, ExcelWrite.IGFColumn.PAY_METHOD - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD)

            ''定額BID
            pasteValue(index, ExcelWrite.IGFColumn.BID_FLAG - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BID_FLAG)

            ''IGF_対象
            pasteValue(index, ExcelWrite.IGFColumn.IGF_APPLIED - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_APPLIED)

            ''IGF契約番号
            pasteValue(index, ExcelWrite.IGFColumn.IGF_CONT_NO - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_NO)

            ''IGF契約形態
            pasteValue(index, ExcelWrite.IGFColumn.IGF_CONT_FORM - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_FORM)

            ''IGF物件管理
            pasteValue(index, ExcelWrite.IGFColumn.IGF_CONT_MANAGMENT - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_MANAGMENT)

            Dim strActDay As String
            Dim dateActDay As Date
            strActDay = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.INST_DATE)

            If IsDate(strActDay) = True Then

                ''日付関数で導入年月の1ヶ月後を取得
                dateActDay = strActDay
                dateActDay = dateActDay.AddMonths(1)

                ''実行日_年月
                pasteValue(index, ExcelWrite.IGFColumn.ACT_START_DATE - 1) = dateActDay.Year & "/" & dateActDay.Month & "/01"

            Else
                ''実行日_年月
                pasteValue(index, ExcelWrite.IGFColumn.ACT_START_DATE - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.INST_DATE)

            End If

            ''IGF契約開始年月
            pasteValue(index, ExcelWrite.IGFColumn.IGF_START_DATE - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_START_DATE)

            ''IGF契約終了年月
            pasteValue(index, ExcelWrite.IGFColumn.IGF_END_DATE - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_END_DATE)

            ''IGF_IOC料率
            pasteValue(index, ExcelWrite.IGFColumn.IGF_RATE_IOC - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_RATE_IOC)

            ''Listprice(単価)_提案時
            pasteValue(index, ExcelWrite.IGFColumn.LIST_PRICE_PROPOSAL - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL)

            ''Listprice(単価)_ﾘﾌﾚｯｼｭ後
            pasteValue(index, ExcelWrite.IGFColumn.LIST_PRICE_REFLESH - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH)

            ''Listprice(合計)_提案時	
            pasteValue(index, ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_PROPOSAL - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_PROPOSAL)

            ''Listprice(合計)_ﾘﾌﾚｯｼｭ後	
            pasteValue(index, ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_REFLESH - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH)

            ''IOC D%
            pasteValue(index, ExcelWrite.IGFColumn.DP_IOC - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.DP_IOC)

            ''IOC単価
            pasteValue(index, ExcelWrite.IGFColumn.PRICE_UNIT_IOC - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC)

            'START 変更管理#??（1346 e-PricerValidation対応）　2016/01 sugo
            ''Offering Price 単価Validation後
            pasteValue(index, ExcelWrite.IGFColumn.PRICE_UNIT_IOC_VAL - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC_VAL)
            'END   変更管理#??（1346 e-PricerValidation対応）　2016/01 sugo

            ''IOC合計
            pasteValue(index, ExcelWrite.IGFColumn.PRICE_QTY_IOC - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC)

            ''展開金額
            pasteValue(index, ExcelWrite.IGFColumn.PRICE_TO_SPLIT - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_TO_SPLIT)

            ''過去の契約金額合計
            pasteValue(index, ExcelWrite.IGFColumn.PRICE_PAST_CONTRACT - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL)

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' 概　要：通常行の値書込(月度金額を除く)
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InsertExcelRowNormal(ByRef xlInRange As Excel.Range,
                                     ByVal Row As DataRow)

        Try

            ''=====================================================================
            ''              テンプレート式以外の箇所に値をセットする。
            ''=====================================================================
            ''ﾛｯｸFLG
            xlInRange(1, ExcelWrite.IGFColumn.LOCK_FLAG).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG)

            ''有効/無効
            xlInRange(1, ExcelWrite.IGFColumn.VALID_FLAG).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG)

            ''NO
            xlInRange(1, ExcelWrite.IGFColumn.LINE_NO).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO)

            ''ﾌｧｲﾙ名
            xlInRange(1, ExcelWrite.IGFColumn.FILE_NAME).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME)

            ''ﾌｧｲﾙ名Suffix
            xlInRange(1, ExcelWrite.IGFColumn.FILE_NAME_SUFFIX).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX)

            ''ﾌｧｲﾙ内Suffix
            xlInRange(1, ExcelWrite.IGFColumn.FILE_NAME_SUFFIX_INTR).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR)

            ''契約順番
            xlInRange(1, ExcelWrite.IGFColumn.CONTRACT).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT)

            ''案件番号
            xlInRange(1, ExcelWrite.IGFColumn.PROJ_ID).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROJ_ID)

            ''契約通番
            xlInRange(1, ExcelWrite.IGFColumn.CONTRACT_SEQ).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT_SEQ)

            ''Brand Category_BU
            xlInRange(1, ExcelWrite.IGFColumn.BU).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BU)

            ''Brand Category_Brand
            xlInRange(1, ExcelWrite.IGFColumn.BRAND).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND)

            ''Brand Category_ｻﾏﾘｰ用ｶﾃｺﾞﾘ
            xlInRange(1, ExcelWrite.IGFColumn.SUM_CATEGORY).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.SUM_CATEGORY)

            ''Brand Category_SubBrand
            xlInRange(1, ExcelWrite.IGFColumn.BRAND_SUB).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND_SUB)

            ''入力項目ﾊﾟﾀｰﾝ SEQ
            xlInRange(1, ExcelWrite.IGFColumn.PATTERN_CD).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD)

            ''入力項目ﾊﾟﾀｰﾝ
            xlInRange(1, ExcelWrite.IGFColumn.PATTERN).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN)

            ''ﾊﾟﾀｰﾝ別入力項目_項目１
            xlInRange(1, ExcelWrite.IGFColumn.PROD_ITEM01).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01)

            ''ﾊﾟﾀｰﾝ別入力項目_項目２
            xlInRange(1, ExcelWrite.IGFColumn.PROD_ITEM02).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02)

            ''ﾊﾟﾀｰﾝ別入力項目_項目３
            xlInRange(1, ExcelWrite.IGFColumn.PROD_ITEM03).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03)

            ''ﾊﾟﾀｰﾝ別入力項目_項目４
            xlInRange(1, ExcelWrite.IGFColumn.PROD_ITEM04).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM04)

            'ﾊﾟﾀｰﾝ別入力項目_項目５
            xlInRange(1, ExcelWrite.IGFColumn.PROD_ITEM05).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM05)

            ''数量
            xlInRange(1, ExcelWrite.IGFColumn.QTY).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.QTY)

            ''導入_年月
            xlInRange(1, ExcelWrite.IGFColumn.INST_DATE).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.INST_DATE)

            ''請求開始_年月
            xlInRange(1, ExcelWrite.IGFColumn.PAY_START_DATE).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE)

            ''請求終了_年月
            xlInRange(1, ExcelWrite.IGFColumn.PAY_END_DATE).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE)

            ''支払方法
            xlInRange(1, ExcelWrite.IGFColumn.PAY_METHOD).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD)

            ''IGF_対象
            xlInRange(1, ExcelWrite.IGFColumn.IGF_APPLIED).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_APPLIED)

            ''IGF契約番号
            xlInRange(1, ExcelWrite.IGFColumn.IGF_CONT_NO).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_NO)

            ''IGF契約形態
            xlInRange(1, ExcelWrite.IGFColumn.IGF_CONT_FORM).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_FORM)

            ''IGF物件管理
            xlInRange(1, ExcelWrite.IGFColumn.IGF_CONT_MANAGMENT).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_MANAGMENT)

            ''IGF契約開始年月
            xlInRange(1, ExcelWrite.IGFColumn.IGF_START_DATE).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE)

            ''IGF契約終了年月
            xlInRange(1, ExcelWrite.IGFColumn.IGF_END_DATE).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE)

            ''IGF_IOC料率
            xlInRange(1, ExcelWrite.IGFColumn.IGF_RATE_IOC).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_RATE_IOC)

            ''Listprice(単価)_提案時
            xlInRange(1, ExcelWrite.IGFColumn.LIST_PRICE_PROPOSAL).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL)

            ''Listprice(単価)_ﾘﾌﾚｯｼｭ後
            xlInRange(1, ExcelWrite.IGFColumn.LIST_PRICE_REFLESH).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH)

            ''Listprice(合計)_提案時	
            xlInRange(1, ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_PROPOSAL).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_PROPOSAL)

            ''Listprice(合計)_ﾘﾌﾚｯｼｭ後	
            xlInRange(1, ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_REFLESH).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH)

            ''IOC D%
            xlInRange(1, ExcelWrite.IGFColumn.DP_IOC).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.DP_IOC)

            ''IOC単価
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_UNIT_IOC).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC)

            'START 変更管理#??（1346 e-PricerValidation対応）　2016/01 sugo
            ''Offering Price 単価Validation後
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_UNIT_IOC_VAL).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC_VAL)
            'END   変更管理#??（1346 e-PricerValidation対応）　2016/01 sugo

            ''IOC合計
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_QTY_IOC).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC)

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' 概　要：通常行の値書込（月度金額のみ）
    ''' 説　明：※普通に1セルづつ書き込むとレスポンスが極端に落ちるため、Objに格納してから出力
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetExcelRowValueNormalYEAR_MONTH(ByRef Index As Integer,
                                                 ByRef pasteValue(,) As Object, _
                                                 ByRef tmpFormula(,) As Object, _
                                                 ByVal Row As DataRow)

        Dim Idx As Integer
        Try

            ''=====================================================================
            ''      月額以外のTmplate行の式をセット
            ''=====================================================================
            Dim fomulaIdx As Integer
            For fomulaIdx = 1 To ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH1 - 1
                If tmpFormula(1, fomulaIdx).ToString.Length > 1 AndAlso _
                    tmpFormula(1, fomulaIdx).ToString.Substring(0, 1) = "=" Then
                    pasteValue(Index, fomulaIdx - 1) = tmpFormula(1, fomulaIdx)
                End If
                ''Chisの対応
                If fomulaIdx = ExcelWrite.IGFColumn.PRICE_UNIT_IOC Then
                    Dim patternCD As String
                    patternCD = ExcelWrite.GetPatternCD(Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD), _
                                                        Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN))
                    If Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM05) = "CHIS" And _
                       (patternCD = CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_BOX Or patternCD = CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_MES) Then
                        pasteValue(Index, fomulaIdx - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC)
                    End If
                End If

                ''Payment展開に応じて、展開金額を式/値を切替
                If fomulaIdx = ExcelWrite.IGFColumn.PRICE_TO_SPLIT Then
                    If Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_FLAG) = ExcelWrite.Payflg_Value Then
                        pasteValue(Index, fomulaIdx - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_TO_SPLIT)
                    End If
                End If

                ''Payment展開Flgの変換
                If fomulaIdx = ExcelWrite.IGFColumn.CALCULATION Then
                    pasteValue(Index, fomulaIdx - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_FLAG)
                End If
            Next

            ''=====================================================================
            ''      Payment展開FLGに応じて月額の式or値切替
            ''=====================================================================
            Dim setIdx As Integer
            Select Case Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_FLAG)
                Case ExcelWrite.Payflg_Irregular
                    ''不規則
                    For Idx = ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH1 To _
                              ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH12

                        ''RowはPaymentデータのため、PaymentデータのIdxで項目を取得
                        setIdx = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1 + _
                                 Idx - ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH1
                        pasteValue(Index, Idx - 1) = Row("CellNM" & setIdx)
                    Next

                Case ExcelWrite.Payflg_Fomula, _
                     ExcelWrite.Payflg_Value

                    ''不規則以外
                    For Idx = ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH1 To _
                              ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH12

                        pasteValue(Index, Idx - 1) = tmpFormula(1, Idx)
                    Next
            End Select

        Catch ex As Exception
            Throw ex

        End Try

    End Sub

    ''' <summary>
    ''' 概　要：通常行の値書込（月度金額のみ）
    ''' 説　明：※普通に1セルづつ書き込むとレスポンスが極端に落ちるため、Objに格納してから出力
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InsertExcelRowNormalYEAR_MONTH(ByRef xlInRange As Excel.Range,
                                               ByVal Row As DataRow,
                                               ByVal sheetNm As String)

        Try
            ''=====================================================================
            ''      Payment.Xlsに値がIGF番号が入力されていれば、値をセット
            ''      削除行（Qty < 0）は値をセット
            ''=====================================================================
            Dim obj(0, 144) As Object
            Dim strCount As Integer = ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH1

            ''数量をセット
            Dim qty As Integer
            If IsNumeric(Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.QTY)) Then
                qty = CInt(Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.QTY))
            Else
                qty = 0
            End If
            If Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_NO).ToString.Trim() <> "" Or
                qty < 0 Then

                ''年度1_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1)

                ''年度1_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH2)

                ''年度1_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH3)

                ''年度1_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH4)

                ''年度1_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH5)

                ''年度1_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH6)

                ''年度1_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH7)

                ''年度1_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH8)

                ''年度1_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH9)

                ''年度1_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH10)

                ''年度1_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH11)

                ''年度1_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH12)

                ''年度2_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH1)

                ''年度2_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH2)

                ''年度2_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH3)

                ''年度2_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH4)

                ''年度2_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH5)

                ''年度2_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH6)

                ''年度2_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH7)

                ''年度2_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH8)

                ''年度2_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH9)

                ''年度2_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH10)

                ''年度2_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH11)

                ''年度2_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH12)

                ''年度3_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH1)

                ''年度3_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH2)

                ''年度3_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH3)

                ''年度3_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH4)

                ''年度3_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH5)

                ''年度3_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH6)

                ''年度3_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH7)

                ''年度3_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH8)

                ''年度3_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH9)

                ''年度3_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH10)

                ''年度3_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH11)

                ''年度3_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH12)

                ''年度4_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH1)

                ''年度4_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH2)

                ''年度4_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH3)

                ''年度4_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH4)

                ''年度4_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH5)

                ''年度4_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH6)

                ''年度4_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH7)

                ''年度4_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH8)

                ''年度4_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH9)

                ''年度4_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH10)

                ''年度4_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH11)

                ''年度4_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH12)

                ''年度5_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH1)

                ''年度5_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH2)

                ''年度5_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH3)

                ''年度5_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH4)

                ''年度5_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH5)

                ''年度5_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH6)

                ''年度5_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH7)

                ''年度5_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH8)

                ''年度5_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH9)

                ''年度5_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH10)

                ''年度5_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH11)

                ''年度5_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH12)

                ''年度6_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH1)

                ''年度6_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH2)

                ''年度6_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH3)

                ''年度6_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH4)

                ''年度6_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH5)

                ''年度6_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH6)

                ''年度6_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH7)

                ''年度6_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH8)

                ''年度6_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH9)

                ''年度6_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH10)

                ''年度6_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH11)

                ''年度6_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH12)

                ''年度7_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH1)

                ''年度7_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH2)

                ''年度7_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH3)

                ''年度7_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH4)

                ''年度7_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH5)

                ''年度7_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH6)

                ''年度7_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH7)

                ''年度7_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH8)

                ''年度7_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH9)

                ''年度7_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH10)

                ''年度7_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH11)

                ''年度7_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH12)

                ''年度8_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH1)

                ''年度8_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH2)

                ''年度8_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH3)

                ''年度8_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH4)

                ''年度8_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH5)

                ''年度8_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH6)

                ''年度8_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH7)

                ''年度8_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH8)

                ''年度8_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH9)

                ''年度8_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH10)

                ''年度8_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH11)

                ''年度8_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH12)

                ''年度9_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH1)

                ''年度9_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH2)

                ''年度9_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH3)

                ''年度9_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH4)

                ''年度9_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH5)

                ''年度9_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH6)

                ''年度9_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH7)

                ''年度9_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH8)

                ''年度9_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH9)

                ''年度9_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH10)

                ''年度9_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH11)

                ''年度9_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH12)

                ''年度10_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH1)

                ''年度10_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH2)

                ''年度10_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH3)

                ''年度10_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH4)

                ''年度10_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH5)

                ''年度10_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH6)

                ''年度10_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH7)

                ''年度10_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH8)

                ''年度10_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH9)

                ''年度10_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH10)

                ''年度10_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH11)

                ''年度10_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH12)

                ''年度11_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH1)

                ''年度11_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH2)

                ''年度11_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH3)

                ''年度11_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH4)

                ''年度11_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH5)

                ''年度11_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH6)

                ''年度11_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH7)

                ''年度11_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH8)

                ''年度11_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH9)

                ''年度11_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH10)

                ''年度11_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH11)

                ''年度11_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH12)

                ''年度12_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH1)

                ''年度12_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH2)

                ''年度12_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH3)

                ''年度12_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH4)

                ''年度12_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH5)

                ''年度12_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH6)

                ''年度12_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH7)

                ''年度12_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH8)

                ''年度12_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH9)

                ''年度12_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH10)

                ''年度12_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH11)

                ''年度12_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH12)

                ''年度13_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH1)

                ''年度13_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH2)

                ''年度13_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH3)

                ''年度13_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH4)

                ''年度13_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH5)

                ''年度13_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH6)

                ''年度13_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH7)

                ''年度13_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH8)

                ''年度13_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH9)

                ''年度13_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH10)

                ''年度13_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH11)

                ''年度13_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH12)

                ''年度14_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH1)

                ''年度14_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH2)

                ''年度14_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH3)

                ''年度14_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH4)

                ''年度14_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH5)

                ''年度14_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH6)

                ''年度14_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH7)

                ''年度14_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH8)

                ''年度14_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH9)

                ''年度14_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH10)

                ''年度14_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH11)

                ''年度14_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH12)

                ''年度15_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH1)

                ''年度15_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH2)

                ''年度15_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH3)

                ''年度15_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH4)

                ''年度15_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH5)

                ''年度15_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH6)

                ''年度15_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH7)

                ''年度15_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH8)

                ''年度15_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH9)

                ''年度15_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH10)

                ''年度15_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH11)

                ''年度15_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH12)

                ''年度16_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH1)

                ''年度16_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH2)

                ''年度16_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH3)

                ''年度16_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH4)

                ''年度16_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH5)

                ''年度16_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH6)

                ''年度16_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH7)

                ''年度16_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH8)

                ''年度16_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH9)

                ''年度16_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH10)

                ''年度16_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH11)

                ''年度16_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH12)

                ''年度17_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH1)

                ''年度17_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH2)

                ''年度17_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH3)

                ''年度17_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH4)

                ''年度17_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH5)

                ''年度17_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH6)

                ''年度17_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH7)

                ''年度17_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH8)

                ''年度17_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH9)

                ''年度17_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH10)

                ''年度17_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH11)

                ''年度17_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH12)

                ''年度18_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH1)

                ''年度18_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH2)

                ''年度18_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH3)

                ''年度18_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH4)

                ''年度18_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH5)

                ''年度18_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH6)

                ''年度18_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH7)

                ''年度18_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH8)

                ''年度18_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH9)

                ''年度18_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH10)

                ''年度19_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH11)

                ''年度19_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH12)

                ''年度19_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH1)

                ''年度19_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH2)

                ''年度19_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH3)

                ''年度19_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH4)

                ''年度19_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH5)

                ''年度19_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH6)

                ''年度19_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH7)

                ''年度19_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH8)

                ''年度19_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH9)

                ''年度19_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH10)

                ''年度19_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH11)

                ''年度19_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH12)

                ''年度20_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH1)

                ''年度20_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH2)

                ''年度20_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH3)

                ''年度20_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH4)

                ''年度20_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH5)

                ''年度20_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH6)

                ''年度20_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH7)

                ''年度20_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH8)

                ''年度20_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH9)

                ''年度20_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH10)

                ''年度20_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH11)

                ''年度20_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12)

                'Excel2013対応 2014/11/28 H.Tozu End

                xlInRange.Value = obj

                Exit Sub

            End If

            ''=====================================================================
            ''   条件②：以下の値の場合、月度情報を値でセットする
            ''			 ・IGF契約番号に値が入っていない
            ''			 ・支払方法が変則
            ''			 ・依頼前シート
            ''=====================================================================
            If Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_NO).ToString.Trim() = "" And
                Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD).ToString.Trim() = "変則" And
                sheetNm = IGFSHEETNM_ORDER Then

                ''年度1_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1)

                ''年度1_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH2)

                ''年度1_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH3)

                ''年度1_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH4)

                ''年度1_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH5)

                ''年度1_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH6)

                ''年度1_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH7)

                ''年度1_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH8)

                ''年度1_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH9)

                ''年度1_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH10)

                ''年度1_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH11)

                ''年度1_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH12)

                ''年度2_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH1)

                ''年度2_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH2)

                ''年度2_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH3)

                ''年度2_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH4)

                ''年度2_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH5)

                ''年度2_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH6)

                ''年度2_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH7)

                ''年度2_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH8)

                ''年度2_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH9)

                ''年度2_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH10)

                ''年度2_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH11)

                ''年度2_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH12)

                ''年度3_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH1)

                ''年度3_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH2)

                ''年度3_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH3)

                ''年度3_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH4)

                ''年度3_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH5)

                ''年度3_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH6)

                ''年度3_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH7)

                ''年度3_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH8)

                ''年度3_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH9)

                ''年度3_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH10)

                ''年度3_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH11)

                ''年度3_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH12)

                ''年度4_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH1)

                ''年度4_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH2)

                ''年度4_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH3)

                ''年度4_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH4)

                ''年度4_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH5)

                ''年度4_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH6)

                ''年度4_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH7)

                ''年度4_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH8)

                ''年度4_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH9)

                ''年度4_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH10)

                ''年度4_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH11)

                ''年度4_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH12)

                ''年度5_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH1)

                ''年度5_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH2)

                ''年度5_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH3)

                ''年度5_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH4)

                ''年度5_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH5)

                ''年度5_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH6)

                ''年度5_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH7)

                ''年度5_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH8)

                ''年度5_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH9)

                ''年度5_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH10)

                ''年度5_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH11)

                ''年度5_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH12)

                ''年度6_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH1)

                ''年度6_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH2)

                ''年度6_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH3)

                ''年度6_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH4)

                ''年度6_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH5)

                ''年度6_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH6)

                ''年度6_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH7)

                ''年度6_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH8)

                ''年度6_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH9)

                ''年度6_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH10)

                ''年度6_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH11)

                ''年度6_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH12)

                ''年度7_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH1)

                ''年度7_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH2)

                ''年度7_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH3)

                ''年度7_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH4)

                ''年度7_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH5)

                ''年度7_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH6)

                ''年度7_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH7)

                ''年度7_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH8)

                ''年度7_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH9)

                ''年度7_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH10)

                ''年度7_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH11)

                ''年度7_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH12)

                ''年度8_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH1)

                ''年度8_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH2)

                ''年度8_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH3)

                ''年度8_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH4)

                ''年度8_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH5)

                ''年度8_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH6)

                ''年度8_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH7)

                ''年度8_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH8)

                ''年度8_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH9)

                ''年度8_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH10)

                ''年度8_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH11)

                ''年度8_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH12)

                ''年度9_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH1)

                ''年度9_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH2)

                ''年度9_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH3)

                ''年度9_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH4)

                ''年度9_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH5)

                ''年度9_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH6)

                ''年度9_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH7)

                ''年度9_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH8)

                ''年度9_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH9)

                ''年度9_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH10)

                ''年度9_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH11)

                ''年度9_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH12)

                ''年度10_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH1)

                ''年度10_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH2)

                ''年度10_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH3)

                ''年度10_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH4)

                ''年度10_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH5)

                ''年度10_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH6)

                ''年度10_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH7)

                ''年度10_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH8)

                ''年度10_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH9)

                ''年度10_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH10)

                ''年度10_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH11)

                ''年度10_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH12)

                ''年度11_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH1)

                ''年度11_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH2)

                ''年度11_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH3)

                ''年度11_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH4)

                ''年度11_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH5)

                ''年度11_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH6)

                ''年度11_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH7)

                ''年度11_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH8)

                ''年度11_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH9)

                ''年度11_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH10)

                ''年度11_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH11)

                ''年度11_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH12)

                ''年度12_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH1)

                ''年度12_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH2)

                ''年度12_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH3)

                ''年度12_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH4)

                ''年度12_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH5)

                ''年度12_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH6)

                ''年度12_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH7)

                ''年度12_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH8)

                ''年度12_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH9)

                ''年度12_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH10)

                ''年度12_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH11)

                ''年度12_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH12)

                'Excel2013対応 2014/11/28 H.Tozu Str
                ''年度13_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH1)

                ''年度13_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH2)

                ''年度13_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH3)

                ''年度13_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH4)

                ''年度13_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH5)

                ''年度13_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH6)

                ''年度13_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH7)

                ''年度13_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH8)

                ''年度13_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH9)

                ''年度13_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH10)

                ''年度13_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH11)

                ''年度13_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH12)

                ''年度14_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH1)

                ''年度14_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH2)

                ''年度14_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH3)

                ''年度14_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH4)

                ''年度14_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH5)

                ''年度14_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH6)

                ''年度14_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH7)

                ''年度14_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH8)

                ''年度14_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH9)

                ''年度14_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH10)

                ''年度14_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH11)

                ''年度14_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH12)

                ''年度15_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH1)

                ''年度15_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH2)

                ''年度15_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH3)

                ''年度15_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH4)

                ''年度15_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH5)

                ''年度15_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH6)

                ''年度15_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH7)

                ''年度15_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH8)

                ''年度15_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH9)

                ''年度15_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH10)

                ''年度15_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH11)

                ''年度15_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH12)

                ''年度16_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH1)

                ''年度16_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH2)

                ''年度16_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH3)

                ''年度16_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH4)

                ''年度16_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH5)

                ''年度16_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH6)

                ''年度16_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH7)

                ''年度16_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH8)

                ''年度16_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH9)

                ''年度16_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH10)

                ''年度16_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH11)

                ''年度16_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH12)

                ''年度17_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH1)

                ''年度17_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH2)

                ''年度17_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH3)

                ''年度17_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH4)

                ''年度17_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH5)

                ''年度17_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH6)

                ''年度17_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH7)

                ''年度17_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH8)

                ''年度17_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH9)

                ''年度17_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH10)

                ''年度17_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH11)

                ''年度17_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH12)

                ''年度18_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH1)

                ''年度18_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH2)

                ''年度18_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH3)

                ''年度18_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH4)

                ''年度18_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH5)

                ''年度18_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH6)

                ''年度18_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH7)

                ''年度18_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH8)

                ''年度18_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH9)

                ''年度18_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH10)

                ''年度18_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH11)

                ''年度18_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH12)

                ''年度19_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH1)

                ''年度19_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH2)

                ''年度19_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH3)

                ''年度19_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH4)

                ''年度19_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH5)

                ''年度19_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH6)

                ''年度19_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH7)

                ''年度19_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH8)

                ''年度19_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH9)

                ''年度19_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH10)

                ''年度19_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH11)

                ''年度19_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH12)

                ''年度20_月度情報1
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH1 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH1)

                ''年度20_月度情報2
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH2 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH2)

                ''年度20_月度情報3
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH3 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH3)

                ''年度20_月度情報4
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH4 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH4)

                ''年度20_月度情報5
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH5 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH5)

                ''年度20_月度情報6
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH6 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH6)

                ''年度20_月度情報7
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH7 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH7)

                ''年度20_月度情報8
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH8 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH8)

                ''年度20_月度情報9
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH9 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH9)

                ''年度20_月度情報10
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH10 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH10)

                ''年度20_月度情報11
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH11 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH11)

                ''年度20_月度情報12
                obj(0, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH12 - strCount) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12)

                xlInRange.Value = obj

                Exit Sub

            End If

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' 概　要：BU集計行の値をセット
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetExcelRowValueBrandInfo(ByVal index As Integer, _
                                          ByRef pasteValue(,) As Object, _
                                          ByRef Row As DataRow)

        Try
            ''                                  以下、値のセット
            ''---------------------------------------------------------------------------------------------
            ''NO
            pasteValue(index, ExcelWrite.IGFColumn.LINE_NO - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO)

            ''ﾌｧｲﾙ名
            pasteValue(index, ExcelWrite.IGFColumn.FILE_NAME - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME)

            ''ﾌｧｲﾙ名Suffix
            pasteValue(index, ExcelWrite.IGFColumn.FILE_NAME_SUFFIX - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX)

            ''ﾌｧｲﾙ内Suffix
            pasteValue(index, ExcelWrite.IGFColumn.FILE_NAME_SUFFIX_INTR - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR)

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' 概　要：Bu,Brand集計の出力
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InsertExcelRowBrandInfo(ByRef xlInRange As Excel.Range,
                                        ByVal Row As DataRow)


        ''=======================================================
        ''					行の書式を設定する。	
        ''=======================================================
        Dim XlInterior As Excel.Interior
        Dim XlFont As Excel.Font
        Dim XlBorder As Excel.Border
        Dim XlFormatConditions As Excel.FormatConditions
        Dim XlValidation As Excel.Validation

        Try

            ''Excel式を削除する
            xlInRange.Value = ""

            ''入力規則を削除する
            XlValidation = xlInRange.Validation
            XlValidation.Delete()

            ''①背景色（黄色） 
            XlInterior = xlInRange.Interior
            XlInterior.ColorIndex = 19

            ''②太字
            XlFont = xlInRange.Font
            XlFont.Bold = True

            ''③罫線
            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlDiagonalDown)
            XlBorder.LineStyle = Excel.Constants.xlNone

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlDiagonalUp)
            XlBorder.LineStyle = Excel.Constants.xlNone

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlEdgeLeft)
            XlBorder.LineStyle = Excel.XlLineStyle.xlContinuous

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlEdgeTop)
            XlBorder.LineStyle = Excel.XlLineStyle.xlContinuous

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlEdgeBottom)
            XlBorder.LineStyle = Excel.XlLineStyle.xlContinuous

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlEdgeRight)
            XlBorder.LineStyle = Excel.XlLineStyle.xlContinuous

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlInsideVertical)
            XlBorder.LineStyle = Excel.Constants.xlNone

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlInsideHorizontal)
            XlBorder.LineStyle = Excel.Constants.xlNone

            ''④条件付書式の削除
            XlFormatConditions = xlInRange.FormatConditions
            XlFormatConditions.Delete()

        Catch ex As Exception
            Throw ex
        Finally
            ExcelObjRelease.ReleaseExcelObj(XlValidation, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(XlInterior, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(XlFont, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(XlBorder, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(XlFormatConditions, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try
    End Sub

    ''' <summary>
    ''' 概　要：導入年月集計行の値をセット
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetExcelRowValueInstDay(ByVal index As Integer, _
                                        ByRef pasteValue(,) As Object, _
                                        ByRef Row As DataRow)

        Try
            ''                                  以下、値のセット
            ''---------------------------------------------------------------------------------------------
            ''NO
            pasteValue(index, ExcelWrite.IGFColumn.LINE_NO) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO)

            ''ﾌｧｲﾙ名
            pasteValue(index, ExcelWrite.IGFColumn.FILE_NAME) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME)

            ''ﾌｧｲﾙ名Suffix
            pasteValue(index, ExcelWrite.IGFColumn.FILE_NAME_SUFFIX) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX)

            ''ﾌｧｲﾙ内Suffix
            pasteValue(index, ExcelWrite.IGFColumn.FILE_NAME_SUFFIX_INTR) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR)

        Catch ex As Exception
            Throw ex
        End Try

    End Sub
    ''yuji IGFﾌｧｲﾙ計算式対応 End

    ''' <summary>
    ''' 概　要：導入年月日集計の出力
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InsertExcelRowInstDay(ByRef xlInRange As Excel.Range,
                                      ByVal Row As DataRow)

        ''=======================================================
        ''					行の書式を設定する。	
        ''=======================================================
        Dim XlInterior As Excel.Interior
        Dim XlFont As Excel.Font
        Dim XlBorder As Excel.Border
        Dim XlFormatConditions As Excel.FormatConditions
        Dim XlValidation As Excel.Validation

        Try

            ''Excel式を削除する
            xlInRange.Value = ""

            ''入力規則を削除する
            XlValidation = xlInRange.Validation
            XlValidation.Delete()

            ''①背景色（薄い水色） 
            XlInterior = xlInRange.Interior
            XlInterior.ColorIndex = 34

            ''②太字
            XlFont = xlInRange.Font
            XlFont.Bold = True

            ''③罫線
            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlDiagonalDown)
            XlBorder.LineStyle = Excel.Constants.xlNone

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlDiagonalUp)
            XlBorder.LineStyle = Excel.Constants.xlNone

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlEdgeLeft)
            XlBorder.LineStyle = Excel.XlLineStyle.xlContinuous

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlEdgeTop)
            XlBorder.LineStyle = Excel.XlLineStyle.xlContinuous

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlEdgeBottom)
            XlBorder.LineStyle = Excel.XlLineStyle.xlContinuous

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlEdgeRight)
            XlBorder.LineStyle = Excel.XlLineStyle.xlContinuous

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlInsideVertical)
            XlBorder.LineStyle = Excel.Constants.xlNone

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlInsideHorizontal)
            XlBorder.LineStyle = Excel.Constants.xlNone

            ''④条件付書式の削除
            XlFormatConditions = xlInRange.FormatConditions
            XlFormatConditions.Delete()

        Catch ex As Exception
            Throw ex
        Finally
            ExcelObjRelease.ReleaseExcelObj(XlValidation, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(XlInterior, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(XlFont, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(XlBorder, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(XlFormatConditions, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try

    End Sub

    ''' <summary>
    ''' 概　要：QCOS集計行の値をセット
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetExcelRowValueQCOS(ByVal index As Integer, _
                                     ByRef pasteValue(,) As Object, _
                                     ByRef Row As DataRow)

        Try
            ''                                  以下、値のセット
            ''---------------------------------------------------------------------------------------------
            ''NO
            pasteValue(index, ExcelWrite.IGFColumn.LINE_NO - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO)

            ''ﾌｧｲﾙ名
            pasteValue(index, ExcelWrite.IGFColumn.FILE_NAME - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME)

            ''ﾌｧｲﾙ名Suffix
            pasteValue(index, ExcelWrite.IGFColumn.FILE_NAME_SUFFIX - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX)

            ''ﾌｧｲﾙ内Suffix
            pasteValue(index, ExcelWrite.IGFColumn.FILE_NAME_SUFFIX_INTR - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR)

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' 概　要：QCOS集計の出力
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InsertExcelRowQCOS(ByRef xlInRange As Excel.Range,
                                   ByVal Row As DataRow)


        ''=======================================================
        ''					行の書式を設定する。	
        ''=======================================================
        Dim XlInterior As Excel.Interior
        Dim XlFont As Excel.Font
        Dim XlBorder As Excel.Border
        Dim XlFormatConditions As Excel.FormatConditions
        Dim XlValidation As Excel.Validation

        Try

            ''Excel式を削除する
            xlInRange.Value = ""

            ''入力規則を削除する
            XlValidation = xlInRange.Validation
            XlValidation.Delete()

            ''①背景色（薄い黄色） 
            XlInterior = xlInRange.Interior
            XlInterior.ColorIndex = 6

            ''②太字
            XlFont = xlInRange.Font
            XlFont.Bold = True

            ''③罫線
            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlDiagonalDown)
            XlBorder.LineStyle = Excel.Constants.xlNone

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlDiagonalUp)
            XlBorder.LineStyle = Excel.Constants.xlNone

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlEdgeLeft)
            XlBorder.LineStyle = Excel.XlLineStyle.xlContinuous

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlEdgeTop)
            XlBorder.LineStyle = Excel.XlLineStyle.xlContinuous

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlEdgeBottom)
            XlBorder.LineStyle = Excel.XlLineStyle.xlContinuous

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlEdgeRight)
            XlBorder.LineStyle = Excel.XlLineStyle.xlContinuous

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlInsideVertical)
            XlBorder.LineStyle = Excel.Constants.xlNone

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlInsideHorizontal)
            XlBorder.LineStyle = Excel.Constants.xlNone

            ''④条件付書式の削除
            XlFormatConditions = xlInRange.FormatConditions
            XlFormatConditions.Delete()

        Catch ex As Exception
            Throw ex
        Finally
            ExcelObjRelease.ReleaseExcelObj(XlValidation, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(XlInterior, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(XlFont, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(XlBorder, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(XlFormatConditions, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try

    End Sub

    ''' <summary>
    ''' 概　要：導入年月集計行の値をセット
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetExcelRowValueNewOrDel(ByVal index As Integer, _
                                         ByRef pasteValue(,) As Object, _
                                         ByRef Row As DataRow)

        Try
            ''                                  以下、値のセット
            ''---------------------------------------------------------------------------------------------
            ''NO
            pasteValue(index, ExcelWrite.IGFColumn.LINE_NO - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO)

            ''ﾌｧｲﾙ名
            pasteValue(index, ExcelWrite.IGFColumn.FILE_NAME - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME)

            ''ﾌｧｲﾙ名Suffix
            pasteValue(index, ExcelWrite.IGFColumn.FILE_NAME_SUFFIX - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX)

            ''ﾌｧｲﾙ内Suffix
            pasteValue(index, ExcelWrite.IGFColumn.FILE_NAME_SUFFIX_INTR - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR)

            ''契約順番
            pasteValue(index, ExcelWrite.IGFColumn.CONTRACT - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT)

            ''Listprice_期間合計
            pasteValue(index, ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_IOC - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_IOC)

            ''D%適用後_期間合計
            pasteValue(index, ExcelWrite.IGFColumn.PRICE_TOTAL_IOC - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_TOTAL_IOC)

            ''IGF適用後
            pasteValue(index, ExcelWrite.IGFColumn.IGF_AFTER - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.COST_TOTAL_IOC)

            ''契約期間内
            pasteValue(index, ExcelWrite.IGFColumn.CONTRACT_IN - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT_IN)

            ''契約期間外
            pasteValue(index, ExcelWrite.IGFColumn.CONTRACT_OUT - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT_OUT)

            ''IGF金利
            pasteValue(index, ExcelWrite.IGFColumn.IGF_RATE - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1)

            ''年度/月額
            Dim Idx As Integer
            Dim setIdx As Integer       ''年額/月額の項目ループに使用
            For Idx = ExcelWrite.IGFColumn.PRICE_YEAR1 To _
                      ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH12
                setIdx = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1 + 1 + (Idx - ExcelWrite.IGFColumn.PRICE_YEAR1)
                pasteValue(index, Idx - 1) = Row.Item("CellNM" & setIdx)
            Next

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' 概　要：新規/削除集計の出力
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InsertExcelRowNewOrDel(ByRef xlInRange As Excel.Range,
                                       ByVal Row As DataRow,
                                       ByVal outSheetNm As String)

        ''=======================================================
        ''					行の書式を設定する。	
        ''=======================================================
        Dim XlInterior As Excel.Interior
        Dim XlFont As Excel.Font
        Dim XlBorder As Excel.Border
        Dim XlFormatConditions As Excel.FormatConditions
        Dim XlValidation As Excel.Validation

        Try

            ''Excel式を削除する
            xlInRange.Value = ""

            ''入力規則を削除する
            XlValidation = xlInRange.Validation
            XlValidation.Delete()

            ''①背景色（薄い紫） 
            XlInterior = xlInRange.Interior
            XlInterior.ColorIndex = 47

            ''②太字
            XlFont = xlInRange.Font
            XlFont.Bold = True

            ''③罫線
            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlDiagonalDown)
            XlBorder.LineStyle = Excel.Constants.xlNone

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlDiagonalUp)
            XlBorder.LineStyle = Excel.Constants.xlNone

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlEdgeLeft)
            XlBorder.LineStyle = Excel.XlLineStyle.xlContinuous

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlEdgeTop)
            XlBorder.LineStyle = Excel.XlLineStyle.xlContinuous

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlEdgeBottom)
            XlBorder.LineStyle = Excel.XlLineStyle.xlContinuous

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlEdgeRight)
            XlBorder.LineStyle = Excel.XlLineStyle.xlContinuous

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlInsideVertical)
            XlBorder.LineStyle = Excel.Constants.xlNone

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlInsideHorizontal)
            XlBorder.LineStyle = Excel.Constants.xlNone

            ''④条件付書式の削除
            XlFormatConditions = xlInRange.FormatConditions
            XlFormatConditions.Delete()

        Catch ex As Exception
            Throw ex
        Finally
            ExcelObjRelease.ReleaseExcelObj(XlValidation, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(XlInterior, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(XlFont, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(XlBorder, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(XlFormatConditions, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try

    End Sub

    ''' <summary>
    ''' 概　要：総合計行の値をセット
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetExcelRowValueALLSUM(ByVal index As Integer, _
                                       ByRef pasteValue(,) As Object, _
                                       ByRef Row As DataRow)

        Try
            ''                                  以下、値のセット
            ''---------------------------------------------------------------------------------------------
            ''NO
            pasteValue(index, ExcelWrite.IGFColumn.LINE_NO - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO)

            ''ﾌｧｲﾙ名
            pasteValue(index, ExcelWrite.IGFColumn.FILE_NAME - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME)

            ''ﾌｧｲﾙ名Suffix
            pasteValue(index, ExcelWrite.IGFColumn.FILE_NAME_SUFFIX - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX)

            ''ﾌｧｲﾙ内Suffix
            pasteValue(index, ExcelWrite.IGFColumn.FILE_NAME_SUFFIX_INTR - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR)

            ''契約順番
            pasteValue(index, ExcelWrite.IGFColumn.CONTRACT - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT)

            ''Listprice_期間合計
            pasteValue(index, ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_IOC - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_IOC)

            ''D%適用後_期間合計
            pasteValue(index, ExcelWrite.IGFColumn.PRICE_TOTAL_IOC - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_TOTAL_IOC)

            ''IGF適用後
            pasteValue(index, ExcelWrite.IGFColumn.IGF_AFTER - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.COST_TOTAL_IOC)

            ''契約期間内
            pasteValue(index, ExcelWrite.IGFColumn.CONTRACT_IN - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT_IN)

            ''契約期間外
            pasteValue(index, ExcelWrite.IGFColumn.CONTRACT_OUT - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT_OUT)

            ''IGF金利
            pasteValue(index, ExcelWrite.IGFColumn.IGF_RATE - 1) = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1)

            ''年度/月額
            Dim Idx As Integer
            Dim setIdx As Integer       ''年額/月額の項目ループに使用
            For Idx = ExcelWrite.IGFColumn.PRICE_YEAR1 To _
                      ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH12
                setIdx = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1 + 1 + (Idx - ExcelWrite.IGFColumn.PRICE_YEAR1)
                pasteValue(index, Idx - 1) = Row.Item("CellNM" & setIdx)
            Next

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' 概　要：総合計集計の出力
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InsertExcelRowALLSUM(ByRef xlInRange As Excel.Range,
                                     ByVal Row As DataRow)


        ''=======================================================
        ''					行の書式を設定する。	
        ''=======================================================
        Dim XlInterior As Excel.Interior
        Dim XlFont As Excel.Font
        Dim XlBorder As Excel.Border
        Dim XlFormatConditions As Excel.FormatConditions
        Dim XlValidation As Excel.Validation

        Try

            ''Excel式を削除する
            xlInRange.Value = ""

            ''入力規則を削除する
            XlValidation = xlInRange.Validation
            XlValidation.Delete()

            ''①背景色（濃い紫） 
            XlInterior = xlInRange.Interior
            XlInterior.ColorIndex = 39

            ''②太字
            XlFont = xlInRange.Font
            XlFont.Bold = True

            ''③罫線
            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlDiagonalDown)
            XlBorder.LineStyle = Excel.Constants.xlNone

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlDiagonalUp)
            XlBorder.LineStyle = Excel.Constants.xlNone

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlEdgeLeft)
            XlBorder.LineStyle = Excel.XlLineStyle.xlContinuous

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlEdgeTop)
            XlBorder.LineStyle = Excel.XlLineStyle.xlContinuous

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlEdgeBottom)
            XlBorder.LineStyle = Excel.XlLineStyle.xlContinuous

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlEdgeRight)
            XlBorder.LineStyle = Excel.XlLineStyle.xlContinuous

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlInsideVertical)
            XlBorder.LineStyle = Excel.Constants.xlNone

            XlBorder = xlInRange.Borders(Excel.XlBordersIndex.xlInsideHorizontal)
            XlBorder.LineStyle = Excel.Constants.xlNone

            ''④条件付書式の削除
            XlFormatConditions = xlInRange.FormatConditions
            XlFormatConditions.Delete()

            ''=======================================================
            ''					行の値を書き込む
            ''=======================================================
            ''NO
            xlInRange(1, ExcelWrite.IGFColumn.LINE_NO).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO)

            ''ﾌｧｲﾙ名
            xlInRange(1, ExcelWrite.IGFColumn.FILE_NAME).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME)

            ''ﾌｧｲﾙ名Suffix
            xlInRange(1, ExcelWrite.IGFColumn.FILE_NAME_SUFFIX).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX)

            ''ﾌｧｲﾙ内Suffix
            xlInRange(1, ExcelWrite.IGFColumn.FILE_NAME_SUFFIX_INTR).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR)

            ''契約順番
            xlInRange(1, ExcelWrite.IGFColumn.CONTRACT).Value = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT)

            ''====================================================================
            ''                  期間合計の集計値をExcel式でセット
            ''====================================================================
            ''Listprice_期間合計
            xlInRange(1, ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_IOC).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_IOC)

            ''D%適用後_期間合計
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_TOTAL_IOC).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_TOTAL_IOC)

            ''IGF適用後
            xlInRange(1, ExcelWrite.IGFColumn.IGF_AFTER).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.COST_TOTAL_IOC)

            ''契約期間内
            xlInRange(1, ExcelWrite.IGFColumn.CONTRACT_IN).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT_IN)

            ''契約期間外
            xlInRange(1, ExcelWrite.IGFColumn.CONTRACT_OUT).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT_OUT)

            ''IGF金利
            xlInRange(1, ExcelWrite.IGFColumn.IGF_RATE).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1)

            ''年度金額
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR1).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR2).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR3).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR4).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR5).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR6).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR7).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR8).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR9).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR10).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR11).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR12).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12 + 1)

            ''月度金額
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH1).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH2).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH2 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH3).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH3 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH4).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH4 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH5).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH5 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH6).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH6 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH7).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH7 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH8).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH8 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH9).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH9 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH10).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH10 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH11).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH11 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH12).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH12 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH1).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH1 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH2).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH2 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH3).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH3 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH4).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH4 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH5).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH5 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH6).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH6 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH7).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH7 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH8).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH8 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH9).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH9 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH10).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH10 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH11).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH11 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR2_MONTH12).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH12 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH1).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH1 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH2).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH2 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH3).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH3 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH4).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH4 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH5).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH5 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH6).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH6 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH7).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH7 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH8).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH8 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH9).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH9 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH10).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH10 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH11).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH11 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR3_MONTH12).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH12 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH1).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH1 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH2).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH2 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH3).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH3 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH4).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH4 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH5).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH5 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH6).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH6 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH7).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH7 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH8).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH8 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH9).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH9 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH10).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH10 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH11).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH11 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR4_MONTH12).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH12 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH1).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH1 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH2).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH2 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH3).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH3 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH4).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH4 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH5).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH5 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH6).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH6 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH7).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH7 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH8).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH8 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH9).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH9 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH10).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH10 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH11).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH11 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR5_MONTH12).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH12 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH1).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH1 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH2).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH2 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH3).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH3 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH4).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH4 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH5).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH5 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH6).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH6 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH7).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH7 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH8).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH8 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH9).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH9 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH10).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH10 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH11).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH11 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR6_MONTH12).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH12 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH1).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH1 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH2).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH2 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH3).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH3 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH4).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH4 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH5).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH5 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH6).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH6 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH7).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH7 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH8).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH8 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH9).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH9 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH10).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH10 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH11).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH11 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR7_MONTH12).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH12 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH1).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH1 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH2).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH2 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH3).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH3 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH4).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH4 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH5).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH5 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH6).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH6 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH7).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH7 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH8).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH8 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH9).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH9 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH10).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH10 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH11).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH11 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR8_MONTH12).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH12 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH1).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH1 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH2).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH2 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH3).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH3 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH4).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH4 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH5).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH5 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH6).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH6 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH7).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH7 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH8).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH8 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH9).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH9 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH10).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH10 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH11).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH11 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR9_MONTH12).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH12 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH1).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH1 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH2).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH2 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH3).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH3 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH4).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH4 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH5).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH5 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH6).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH6 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH7).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH7 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH8).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH8 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH9).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH9 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH10).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH10 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH11).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH11 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR10_MONTH12).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH12 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH1).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH1 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH2).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH2 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH3).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH3 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH4).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH4 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH5).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH5 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH6).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH6 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH7).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH7 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH8).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH8 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH9).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH9 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH10).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH10 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH11).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH11 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR11_MONTH12).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH12 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH1).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH1 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH2).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH2 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH3).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH3 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH4).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH4 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH5).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH5 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH6).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH6 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH7).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH7 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH8).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH8 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH9).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH9 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH10).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH10 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH11).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH11 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR12_MONTH12).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH12 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH1).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH1 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH2).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH2 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH3).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH3 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH4).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH4 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH5).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH5 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH6).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH6 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH7).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH7 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH8).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH8 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH9).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH9 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH10).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH10 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH11).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH11 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR13_MONTH12).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH12 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH1).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH1 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH2).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH2 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH3).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH3 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH4).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH4 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH5).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH5 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH6).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH6 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH7).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH7 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH8).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH8 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH9).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH9 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH10).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH10 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH11).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH11 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR14_MONTH12).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH12 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH1).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH1 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH2).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH2 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH3).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH3 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH4).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH4 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH5).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH5 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH6).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH6 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH7).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH7 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH8).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH8 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH9).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH9 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH10).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH10 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH11).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH11 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR15_MONTH12).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH12 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH1).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH1 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH2).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH2 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH3).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH3 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH4).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH4 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH5).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH5 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH6).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH6 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH7).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH7 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH8).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH8 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH9).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH9 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH10).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH10 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH11).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH11 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR16_MONTH12).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH12 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH1).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH1 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH2).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH2 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH3).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH3 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH4).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH4 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH5).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH5 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH6).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH6 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH7).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH7 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH8).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH8 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH9).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH9 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH10).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH10 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH11).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH11 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR17_MONTH12).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH12 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH1).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH1 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH2).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH2 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH3).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH3 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH4).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH4 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH5).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH5 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH6).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH6 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH7).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH7 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH8).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH8 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH9).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH9 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH10).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH10 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH11).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH11 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR18_MONTH12).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH12 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH1).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH1 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH2).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH2 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH3).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH3 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH4).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH4 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH5).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH5 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH6).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH6 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH7).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH7 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH8).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH8 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH9).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH9 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH10).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH10 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH11).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH11 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR19_MONTH12).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH12 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH1).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH1 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH2).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH2 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH3).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH3 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH4).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH4 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH5).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH5 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH6).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH6 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH7).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH7 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH8).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH8 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH9).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH9 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH10).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH10 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH11).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH11 + 1)
            xlInRange(1, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH12).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12 + 1)

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(XlInterior, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(XlFont, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(XlBorder, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(XlFormatConditions, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try

    End Sub

    ''' <summary>
    ''' 概　要：IGF集計行の出力
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InsertExcelRowIGF(ByRef xlInRange As Excel.Range,
                                  ByVal Row As DataRow)

        Try

            ''=======================================================
            ''					行の式を書き込む
            ''=======================================================
            ''展開金額
            xlInRange(1, ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_IOC).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_TO_SPLIT)

            'START 変更管理#27（1285固定COST%の定期メンテナンス対応）　2016/04 ueda
            ''GP%
            xlInRange(1, ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_PROPOSAL).Formula = Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH)
            'END 変更管理#27（1285固定COST%の定期メンテナンス対応）　2016/04 ueda

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    ''※依頼前シートを削除
    ''' <summary>
    ''' 概　要：基本契約期間とExcel開始年の書き込み
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetExcelStrRow(ByRef xlIGFResultSheet As Excel.Worksheet)

        Dim xlRange As Excel.Range
        Dim ExcelStrYM As String                ''Excel開始年月
        Dim ExcelStrYear As String              ''Excel開始年
        Dim PayStrYM As String                  ''契約開始年月
        Dim PayEndYM As String                  ''契約終了年月

        Try

            Dim strMsg As String = ""
            Dim wc As New WebDb.WebDbCommon
            Dim ContractBaseTable As New M_CONTRACT_BASETable
            Dim blnRet As Boolean

            '認証設定
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW

            '契約基本情報取得
            blnRet = wc.GetContractBaseData(CommonVariable.CPNO, ContractBaseTable, strMsg)
            If blnRet = False Then
                Throw New Exception(strMsg)
                Exit Sub
            End If

            ''契約開始/終了年月、Excel開始年を取得
            If ContractBaseTable.Rows.Count > 0 Then
                ExcelStrYM = ExcelWrite.changeDBNullToString(ContractBaseTable.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_EXCEL_START))
                If ExcelStrYM.Length >= 4 Then
                    ExcelStrYear = ExcelStrYM.Substring(0, 4)
                    PayStrYM = ExcelWrite.changeDBNullToString(ContractBaseTable.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_START_YEAR)) &
                               "/" &
                               ExcelWrite.changeDBNullToString(ContractBaseTable.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_START_MONTH))

                    PayEndYM = ExcelWrite.changeDBNullToString(ContractBaseTable.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_END_YEAR)) &
                               "/" &
                               ExcelWrite.changeDBNullToString(ContractBaseTable.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_END_MONTH))
                Else
                    ExcelStrYear = ""
                    PayStrYM = ""
                    PayEndYM = ""
                End If
            Else
                ''値が取得できなければ終了
                ''※特にエラーメッセージ、後続の処理のStop等は行わない。
                Exit Sub
            End If

            ''Excel開始年のセット
            xlRange = xlIGFResultSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH1) & "8")
            xlRange.Value = ExcelStrYear
            'START 変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            'END   変更管理#3?（Excel.exeの解放対応)　2017/01 sugo

            ''基本契約期間のセット
            ''※依頼後シートのみセット
            xlRange = xlIGFResultSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.FILE_NAME) & "22")
            xlRange.Value = PayStrYM
            'START 変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            'END   変更管理#3?（Excel.exeの解放対応)　2017/01 sugo

            xlRange = xlIGFResultSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.FILE_NAME) & "23")
            xlRange.Value = PayEndYM
            'START 変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            'END   変更管理#3?（Excel.exeの解放対応)　2017/01 sugo

            xlRange = xlIGFResultSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.IGFColumn.FILE_NAME_SUFFIX) & "2")
            xlRange.Value = CommonVariable.CPNO
            'START 変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            'END   変更管理#3?（Excel.exeの解放対応)　2017/01 sugo

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' 概 要：個別PS.Xlsから不要なIGF行の削除
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub DelIGFRow(ByRef xlOBAMAPSSheet As Excel.Worksheet,
                          ByVal contractno As String)

        Dim xlRow As Excel.Range
        Dim xlRange As Excel.Range
        Dim isEof As Boolean = False

        Try

            For i As Integer = EXCEL_PAYMENTLINEDATE_OUTROW To EXCEL_MAX_ROW

                xlRow = xlOBAMAPSSheet.Rows(i)

                ''EOF条件：NO列 = NULL
                xlRange = xlOBAMAPSSheet.Cells(i, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)
                If ExcelWrite.changeDBNullToString(xlRange.Value) = "" Then
                    Exit For
                End If

                ''以下、除外条件
                xlRange = xlOBAMAPSSheet.Cells(i, ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG)
                If ExcelWrite.changeDBNullToString(xlRange.Value) <> "" Then
                    Continue For
                End If

                xlRange = xlOBAMAPSSheet.Cells(i, ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG)
                If ExcelWrite.changeDBNullToString(xlRange.Value) = "N" Then
                    Continue For
                End If

                ''同一の契約順番でかつ、IGF金利行は行削除
                Dim changePatternCd As String
                Dim patternCd As String
                Dim patternNM As String
                patternCd = ExcelWrite.changeDBNullToString(xlOBAMAPSSheet.Cells(i, ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD).value)
                patternNM = ExcelWrite.changeDBNullToString(xlOBAMAPSSheet.Cells(i, ExcelWrite.ExcelPaymentLineColumn.PATTERN).value)
                changePatternCd = ExcelWrite.GetPatternCD(patternCd, _
                                                          patternNM)

                ''IGF金利行の判定
                xlRange = xlOBAMAPSSheet.Cells(i, ExcelWrite.ExcelPaymentLineColumn.CONTRACT)
                If IsNumeric(xlRange.Value) = True AndAlso
                   CInt(xlRange.Value) = CInt(contractno) And
                   changePatternCd = "29" Then

                    ''行の削除
                    xlRow.Delete(Shift:=Excel.XlDeleteShiftDirection.xlShiftUp)

                    ''行を飛ばさないように、デクリメント
                    i = i - 1

                End If

            Next

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlRow, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' 概 要：IGF.Xlsのデータを取得
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetIGFDataTable(ByRef xlIGFResultSheet As Excel.Worksheet) As IGFDataTable

        ''戻り値
        Dim rtnTable As New IGFDataTable
        Dim area As String
        Dim row As DataRow
        Dim xlRange As Excel.Range
        Dim isEof As Boolean = False
        Dim EXCEL_IGF_LINE_RANGE As String = "A@:MB@"
        Dim MyArray(1, ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH12) As Object

        Try
            For i As Integer = EXCEL_IGFDATA_OUTROW To EXCEL_MAX_ROW

                ''Eof条件：No列に「追加分金利」が文言があり
                xlRange = xlIGFResultSheet.Cells(i, ExcelWrite.IGFColumn.LINE_NO)
                If ExcelWrite.changeDBNullToString(xlRange.Value) = "追加分金利" Then
                    isEof = True
                End If

                ''No列が空白なら、値を読み飛ばす
                ''※IGF金利行とそれ以外の列間のスペースを読み飛ばすため。
                If ExcelWrite.changeDBNullToString(xlRange.Value) = "" Then

                    Continue For

                End If

                ''データのセット
                row = rtnTable.NewRow

                MyArray = xlIGFResultSheet.Range(EXCEL_IGF_LINE_RANGE.Replace("@", i.ToString)).Value
                For j As Integer = 1 To ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH12
                    row("CellNM" & j) = ExcelWrite.changeDBNullToString(MyArray(1, j))
                Next

                ''Excelの行位置をセット
                row.Item("ExcelRow") = i
                rtnTable.Rows.Add(row)

                If isEof Then
                    Return rtnTable
                    Exit Function
                End If
            Next

            Return rtnTable

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Function

    ''' <summary>
    ''' 概 要：IGFデータより、集計行を削除
    ''' 説 明：
    ''' </summary>    
    ''' <remarks></remarks>
    Private Function DelIGFSummaryRow(ByRef IGFDateTable As IGFDataTable) As IGFDataTable

        Dim rtnTable As IGFDataTable
        rtnTable = IGFDateTable.Copy

        Dim delRows() As DataRow
        delRows = rtnTable.Select("")
        For Each delRow As DataRow In delRows

            ''集計行の判定
            If IsNumeric(delRow.Item("CellNM" & ExcelWrite.IGFColumn.LINE_NO)) = False Then

                ''IGF金利行は削除しない
                If delRow.Item("CellNM" & ExcelWrite.IGFColumn.LINE_NO) = "削除分金利" Then
                    Continue For
                End If
                If delRow.Item("CellNM" & ExcelWrite.IGFColumn.LINE_NO) = "追加分金利" Then
                    Continue For
                End If

                ''集計行を削除する。
                delRow.Delete()

            End If
        Next

        Return rtnTable

    End Function


    ''' <summary>
    ''' 概 要：IGF情報とPS情報を比較し、反映できるデータと反映できないデータを分離
    ''' 説 明：
    ''' </summary>    
    ''' <remarks></remarks>
    Private Sub GetOutPSData(ByVal IGFDateTable As IGFDataTable, _
                             ByVal PSDateTable As PSExcelDataTable, _
                             ByRef OutPSDataTable As IGFDataTable, _
                             ByRef NGPSDataTable As IGFDataTable, _
                             ByRef countOutputRow As Integer)

        ''初期化
        countOutputRow = 0
        Dim rtnPSDataTable As New IGFDataTable
        Dim rtnNGPSDataTable As New IGFDataTable

        Dim filter As New StringBuilder
        Dim insRow As DataRow
        For Each row As DataRow In IGFDateTable.Rows

            ''IGFの場合、判定条件が異なる
            Dim isImport As Boolean = True
            If row.Item("CellNM" & ExcelWrite.IGFColumn.LINE_NO) = "削除分金利" Or _
               row.Item("CellNM" & ExcelWrite.IGFColumn.LINE_NO) = "追加分金利" Then

                If isImport Then
                    ''一致情報として扱う。
                    countOutputRow = countOutputRow + 1
                    Continue For
                Else
                    ''不致情報の追加
                    rtnNGPSDataTable.ImportRow(row)
                    Continue For
                End If

            End If

            ''一致条件
            filter.Remove(0, filter.Length)
            filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.IGFColumn.LINE_NO)))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.IGFColumn.PATTERN_CD)))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.IGFColumn.PATTERN)))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.IGFColumn.PROD_ITEM01)))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_IOC)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(row.Item("CellNM" & ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_IOC)))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_APPLIED)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation("Y"))


            ''コメント行は出力しない。
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG)
            filter.Append(CommonConstant.SQL_STR_NOT)
            filter.Append(CommonConstant.SQL_STR_IN)
            filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            filter.Append(StringEdit.EncloseSingleQuotation("C"))
            filter.Append(CommonConstant.STR_COMMA)
            filter.Append(StringEdit.EncloseSingleQuotation("N"))
            filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

            ''一致するPS情報が存在するか判定
            Dim rows() As DataRow
            rows = PSDateTable.Select(filter.ToString)
            If rows.Length > 0 Then
                ''一致情報の追加
                row.Item("OutPSExcelRow") = rows(0).Item("ExcelRow")       ''Paymentの反映先の情報をセット
                rtnPSDataTable.ImportRow(row)
                countOutputRow = countOutputRow + 1

            Else

                ''不致情報の追加
                rtnNGPSDataTable.ImportRow(row)

            End If

        Next

        ''戻り値
        OutPSDataTable = rtnPSDataTable
        NGPSDataTable = rtnNGPSDataTable

    End Sub

    ''' <summary>
    ''' 概 要：IGFの取込み失敗情報をIGF申請ファイルに書き込む
    ''' 説 明：
    ''' </summary>    
    ''' <remarks></remarks>
    Private Sub SetNGIGFData(ByRef xlIGFResultSheet As Excel.Worksheet, _
                             ByVal NGIGFDataTable As IGFDataTable)

        Dim xlRange As Excel.Range
        Dim outMessage As String                        ''エラーメッセージ
        Try

            ''取込み失敗情報をIGF申請ファイルの最後列に書き込む
            For Each row As DataRow In NGIGFDataTable.Rows

                ''メッセージ作成
                outMessage = ""
                If row.Item("CellNM" & ExcelWrite.IGFColumn.LINE_NO) = "削除分金利" Or _
                   row.Item("CellNM" & ExcelWrite.IGFColumn.LINE_NO) = "追加分金利" Then

                    ''IGF金利の取込み失敗用のメッセージ
                    outMessage = outMessage & "IGF金利行の取込が失敗しました。"
                    outMessage = outMessage & "金利行のNetSpread,IIRを入力してください。"

                Else

                    ''IGF金利行以外のメッセージ
                    outMessage = outMessage & "行番" & row.Item("CellNm" & ExcelWrite.IGFColumn.LINE_NO) & "の取込が失敗しました。"
                    outMessage = outMessage & "NO、入力ﾊﾟﾀｰﾝNO、入力ﾊﾟﾀｰﾝ名称、項目1、期間合計Listprice、IGF依頼FLG=Y に一致するデータがありません。"

                End If

                ''メッセージの出力
                xlRange = xlIGFResultSheet.Cells(row.Item("ExcelRow"), _
                                                 GetIGFColIdxMonthlyEnd(enmIGFColIdxType.TypeErrInfo))
                xlRange.Value = outMessage

            Next

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try

    End Sub


    ''' <summary>
    ''' 概 要：IGF申請書ファイルの値をPayment.Xlsへ反映する。
    ''' 説 明：※IGF金利行は後続のInsertIGFRow処理で作成する。
    ''' </summary>    
    ''' <remarks></remarks>
    Private Sub SetIGFData(ByRef xlOBAMAPSSheet As Excel.Worksheet, _
                           ByVal OutPSDataTable As IGFDataTable)

        Dim xlRange As Excel.Range
        Try

            ''Psへデータの書き込み
            For Each row As DataRow In OutPSDataTable.Rows

                ''IGF金利行は除く
                If row.Item(ExcelWrite.IGFColumn.LINE_NO) = "削除分金利" Then
                    Continue For
                End If
                If row.Item(ExcelWrite.IGFColumn.LINE_NO) = "追加分金利" Then
                    Continue For
                End If

                ''========================================
                ''	     以下、値の書き込み（上書き）
                ''========================================

                Dim OBJ1(0, 4) As Object
                Dim OBJ2(0, 3) As Object

                ''Payment展開
                OBJ2(0, 2) = row.Item("CellNM" & ExcelWrite.IGFColumn.CALCULATION)

                ''IGF契約番号
                If row.Item("CellNM" & ExcelWrite.IGFColumn.IGF_CONT_NO).ToString.Trim = "" Then
                    OBJ1(0, 0) = ""
                Else
                    OBJ1(0, 0) = row.Item("CellNM" & ExcelWrite.IGFColumn.IGF_CONT_NO)
                End If

                ''IGF_IOC料率
                OBJ1(0, 3) = row.Item("CellNM" & ExcelWrite.IGFColumn.IGF_RATE_IOC)

                ''IGF契約形態
                OBJ1(0, 1) = row.Item("CellNM" & ExcelWrite.IGFColumn.IGF_CONT_FORM)

                ''IGF物件管理
                OBJ1(0, 2) = row.Item("CellNM" & ExcelWrite.IGFColumn.IGF_CONT_MANAGMENT)

                xlRange = xlOBAMAPSSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_NO) & _
                                               row.Item("OutPSExcelRow") & ":" & _
                                               ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.IGF_RATE_IOC) & _
                                               row.Item("OutPSExcelRow"))
                xlRange.Value = OBJ1

                ''展開金額
                Select Case row.Item("CellNM" & ExcelWrite.IGFColumn.CALCULATION)
                    Case "固定"
                        xlRange = xlOBAMAPSSheet.Cells(row.Item("OutPSExcelRow"), _
                                                       ExcelWrite.ExcelPaymentLineColumn.PRICE_TO_SPLIT)
                        xlRange.Value = row.Item("CellNM" & ExcelWrite.IGFColumn.PRICE_TO_SPLIT)
                    Case Else
                        ''固定値以外はﾃﾝﾌﾟﾚ行の式
                End Select

                ''※IGF開始/終了年月も取込用の項目として追加する。
                OBJ2(0, 0) = row.Item("CellNM" & ExcelWrite.IGFColumn.IGF_START_DATE)
                OBJ2(0, 1) = row.Item("CellNM" & ExcelWrite.IGFColumn.IGF_END_DATE)

                xlRange = xlOBAMAPSSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.IGF_START_DATE) & _
                                               row.Item("OutPSExcelRow") & ":" & _
                                               ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PAY_FLAG) & _
                                               row.Item("OutPSExcelRow"))
                xlRange.Value = OBJ2

                ''月次金額はObj変数に格納してから一括貼り付け
                ''※1Cellづつ値を書き込むと極端にレスポンスが低下するため。
                ''ﾃﾝﾌﾟﾚ修正対応 Str
                Select Case row.Item("CellNM" & ExcelWrite.IGFColumn.CALCULATION)
                    Case "変則"
                        Dim strIndex As Integer = ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH1
                        Dim obj(0, GetIGFColIdxMonthlyEnd(enmIGFColIdxType.TypeMontlyEnd) - strIndex)
                        For i As Integer = 0 To (GetIGFColIdxMonthlyEnd(enmIGFColIdxType.TypeMontlyEnd) - strIndex)
                            obj(0, i) = row.Item("CellNM" & i + strIndex)
                        Next

                        ''貼り付け
                        Dim area As String
                        area = ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1) & "@" & ":" & _
                               ExcelWrite.chgExcelColumnIdxToChar(GetIGFColIdxMonthlyEnd(enmIGFColIdxType.TypePSMontlyEnd)) & "@"
                        xlRange = xlOBAMAPSSheet.Range(area.Replace("@", row.Item("OutPSExcelRow")))
                        xlRange.Value = obj
                End Select
            Next

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub


    ''' <summary>
    ''' 概 要：IGF金利行の挿入
    ''' 説 明：
    ''' </summary>    
    ''' <remarks></remarks>
    Private Sub InsertIGFRow(ByRef xlApp As Excel.Application, _
                             ByRef xlOBAMAPSSheet As Excel.Worksheet, _
                             ByRef xlDummySheet As Excel.Worksheet, _
                             ByVal OutPSDataTable As IGFDataTable, _
                             ByVal contractNo As Integer, _
                             ByVal InsIndex As Integer)

        Dim MaxLineSeq As String = "00000"
        Dim xlRange As Excel.Range
        Dim xlCopyRange As Excel.Range                  ''IGF金利行のテンプレート行
        Dim defaultDate As IGFDefaultDate

        Try

            ''DummyシートからIGF金利行のテンプレ行を変数に格納
            For i As Integer = EXCEL_PAYMENTLINEDATE_OUTROW To EXCEL_MAX_ROW

                ''ﾊﾟﾀｰﾝ NO = 29なら、IGF行
                xlRange = xlDummySheet.Cells(i, ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD)
                If ExcelWrite.changeDBNullToString(xlRange.Value) = "29" Then

                    ''IGF行の格納
                    xlCopyRange = xlDummySheet.Rows(i)
                    Exit For

                End If
            Next

            ''====================================================
            ''				IGFファイルのInsert処理
            ''====================================================
            Dim InsertIndex As Integer
            InsertIndex = InsIndex + EXCEL_PAYMENTLINEDATE_OUTROW

            ''----------------------------------------------------
            ''			①IGF行の削除行の処理
            ''----------------------------------------------------
            Dim filterDel As New StringBuilder
            filterDel.Append("CellNM" & ExcelWrite.IGFColumn.LINE_NO)
            filterDel.Append(CommonConstant.SQL_STR_EQUAL)
            filterDel.Append(StringEdit.EncloseSingleQuotation("削除分金利"))
            filterDel.Append(CommonConstant.SQL_STR_AND)
            filterDel.Append("CellNM" & ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_IOC)
            filterDel.Append(CommonConstant.SQL_STR_NOT_EQUAL)
            filterDel.Append(StringEdit.EncloseSingleQuotation(""))

            For Each row As DataRow In OutPSDataTable.Select(filterDel.ToString)

                ''IGFテンプレート行コピペ
                xlApp.DisplayAlerts = False
                xlCopyRange.Copy()
                xlRange = xlOBAMAPSSheet.Rows(InsertIndex)
                xlRange.PasteSpecial()

                ''値のセット
                ''契約順番
                xlRange = xlOBAMAPSSheet.Cells(InsertIndex, ExcelWrite.ExcelPaymentLineColumn.CONTRACT)
                xlRange.Value = contractNo

                ''NO　※IGF金利行のLineNoを「99998」ではなく、作成中のLinnoの連番とする。
                xlRange = xlOBAMAPSSheet.Cells(InsertIndex, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)
                MaxLineSeq = CStr((GetMaxLineNoSeq(xlOBAMAPSSheet, InsertIndex) + 1)).PadLeft(5, "0")
                xlRange.Value = (contractNo & MaxLineSeq).ToString.PadLeft(8, "0")

                ''数量
                xlRange = xlOBAMAPSSheet.Cells(InsertIndex, ExcelWrite.ExcelPaymentLineColumn.QTY)
                xlRange.Value = -1

                ''パターン名称
                xlRange = xlOBAMAPSSheet.Cells(InsertIndex, ExcelWrite.ExcelPaymentLineColumn.PATTERN)
                xlRange.Value = "IGF(金利) 削除ﾃﾞｰﾀ"

                ''COST単価
                ''NET Spread or IIR 未入力なら、Cost単価を0とする。
                xlRange = xlOBAMAPSSheet.Cells(InsertIndex, ExcelWrite.ExcelPaymentLineColumn.COST)
                If row.Item("CellNM" & ExcelWrite.IGFColumn.DP_IOC) = "" Then
                    xlRange.Value = 0
                Else
                    If IsNumeric(row.Item("CellNM" & ExcelWrite.IGFColumn.PRICE_QTY_IOC)) Then
                        xlRange.Value = Math.Abs(CDec(row.Item("CellNM" & ExcelWrite.IGFColumn.PRICE_QTY_IOC)))
                    Else
                        xlRange.Value = row.Item("CellNM" & ExcelWrite.IGFColumn.PRICE_QTY_IOC)
                    End If
                End If

                ''ListPrice単価(提案時)
                xlRange = xlOBAMAPSSheet.Cells(InsertIndex, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL)
                If IsNumeric(row.Item("CellNM" & ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_IOC)) = True Then
                    xlRange.Value = Math.Abs(CDec(row.Item("CellNM" & ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_IOC)))
                Else
                    xlRange.Value = row.Item("CellNM" & ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_IOC)
                End If

                ''ListPrice単価(ﾘﾌﾚｯｼｭ)
                xlRange = xlOBAMAPSSheet.Cells(InsertIndex, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH)
                If IsNumeric(row.Item("CellNM" & ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_IOC)) = True Then
                    xlRange.Value = Math.Abs(CDec(row.Item("CellNM" & ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_IOC)))
                Else
                    xlRange.Value = row.Item("CellNM" & ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_IOC)
                End If

                ''Payment展開
                xlRange = xlOBAMAPSSheet.Cells(InsertIndex, ExcelWrite.ExcelPaymentLineColumn.PAY_FLAG)
                xlRange.Value = "変則"

                ''                          日付の初期値ｾｯﾄ
                ''-----------------------------------------------------------------------------
                defaultDate = GetIGFMaxDate(False, OutPSDataTable)
                ''導入年月
                xlRange = xlOBAMAPSSheet.Cells(InsertIndex, ExcelWrite.ExcelPaymentLineColumn.INST_DATE)
                xlRange.Value = defaultDate.INST_DATE
                ''元本計算・開始年月
                xlRange = xlOBAMAPSSheet.Cells(InsertIndex, ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE)
                xlRange.Value = defaultDate.PAY_START_DATE
                ''元本計算・終了年月
                xlRange = xlOBAMAPSSheet.Cells(InsertIndex, ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE)
                xlRange.Value = defaultDate.PAY_END_DATE
                ''IGF計算・開始年月
                xlRange = xlOBAMAPSSheet.Cells(InsertIndex, ExcelWrite.ExcelPaymentLineColumn.IGF_START_DATE)
                xlRange.Value = defaultDate.IGF_START_DATE
                ''IGF計算・終了年月      
                xlRange = xlOBAMAPSSheet.Cells(InsertIndex, ExcelWrite.ExcelPaymentLineColumn.IGF_END_DATE)
                xlRange.Value = defaultDate.IGF_END_DATE

                InsertIndex = InsertIndex + 1

            Next

            ''----------------------------------------------------
            ''			②IGF行の追加行の処理
            ''----------------------------------------------------
            Dim filterNew As New StringBuilder
            filterNew.Append("CellNM" & ExcelWrite.IGFColumn.LINE_NO)
            filterNew.Append(CommonConstant.SQL_STR_EQUAL)
            filterNew.Append(StringEdit.EncloseSingleQuotation("追加分金利"))
            filterNew.Append(CommonConstant.SQL_STR_AND)
            filterNew.Append("CellNM" & ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_IOC)
            filterNew.Append(CommonConstant.SQL_STR_NOT_EQUAL)
            filterNew.Append(StringEdit.EncloseSingleQuotation(""))
            For Each row As DataRow In OutPSDataTable.Select(filterNew.ToString)

                ''IGFテンプレート行コピペ
                xlApp.DisplayAlerts = False
                xlCopyRange.Copy()
                xlRange = xlOBAMAPSSheet.Rows(InsertIndex)
                xlRange.PasteSpecial()

                ''値のセット
                ''契約順番
                xlRange = xlOBAMAPSSheet.Cells(InsertIndex, ExcelWrite.ExcelPaymentLineColumn.CONTRACT)
                xlRange.Value = contractNo

                ''NO　※IGF金利行のLineNoを「固定値」ではなく、作成中のLinnoの連番とする。
                xlRange = xlOBAMAPSSheet.Cells(InsertIndex, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)
                MaxLineSeq = CStr((GetMaxLineNoSeq(xlOBAMAPSSheet, InsertIndex) + 1)).PadLeft(5, "0")
                xlRange.Value = (contractNo & MaxLineSeq).ToString.PadLeft(8, "0")

                ''数量
                xlRange = xlOBAMAPSSheet.Cells(InsertIndex, ExcelWrite.ExcelPaymentLineColumn.QTY)
                xlRange.Value = 1

                ''COST単価
                ''NET Spread or IIR 未入力なら、Cost単価を0とする。
                xlRange = xlOBAMAPSSheet.Cells(InsertIndex, ExcelWrite.ExcelPaymentLineColumn.COST)
                If row.Item("CellNM" & ExcelWrite.IGFColumn.DP_IOC) = "" Then
                    xlRange.Value = 0
                Else
                    If IsNumeric(row.Item("CellNM" & ExcelWrite.IGFColumn.PRICE_QTY_IOC)) Then
                        xlRange.Value = Math.Abs(CDec(row.Item("CellNM" & ExcelWrite.IGFColumn.PRICE_QTY_IOC)))
                    Else
                        xlRange.Value = row.Item("CellNM" & ExcelWrite.IGFColumn.PRICE_QTY_IOC)
                    End If
                End If
                ''ListPrice単価(提案時)
                xlRange = xlOBAMAPSSheet.Cells(InsertIndex, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL)
                If IsNumeric(row.Item("CellNM" & ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_IOC)) = True Then
                    xlRange.Value = Math.Abs(CDec(row.Item("CellNM" & ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_IOC)))
                Else
                    xlRange.Value = row.Item("CellNM" & ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_IOC)
                End If

                ''ListPrice単価(ﾘﾌﾚｯｼｭ)
                xlRange = xlOBAMAPSSheet.Cells(InsertIndex, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH)
                If IsNumeric(row.Item("CellNM" & ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_IOC)) = True Then
                    xlRange.Value = Math.Abs(CDec(row.Item("CellNM" & ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_IOC)))
                Else
                    xlRange.Value = row.Item("CellNM" & ExcelWrite.IGFColumn.LIST_PRICE_TOTAL_IOC)
                End If

                ''Payment展開
                xlRange = xlOBAMAPSSheet.Cells(InsertIndex, ExcelWrite.ExcelPaymentLineColumn.PAY_FLAG)
                xlRange.Value = "変則"

                ''                          日付の初期値ｾｯﾄ
                ''-----------------------------------------------------------------------------
                defaultDate = GetIGFMaxDate(True, OutPSDataTable)
                ''導入年月
                xlRange = xlOBAMAPSSheet.Cells(InsertIndex, ExcelWrite.ExcelPaymentLineColumn.INST_DATE)
                xlRange.Value = defaultDate.INST_DATE
                ''元本計算・開始年月
                xlRange = xlOBAMAPSSheet.Cells(InsertIndex, ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE)
                xlRange.Value = defaultDate.PAY_START_DATE
                ''元本計算・終了年月
                xlRange = xlOBAMAPSSheet.Cells(InsertIndex, ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE)
                xlRange.Value = defaultDate.PAY_END_DATE
                ''IGF計算・開始年月
                xlRange = xlOBAMAPSSheet.Cells(InsertIndex, ExcelWrite.ExcelPaymentLineColumn.IGF_START_DATE)
                xlRange.Value = defaultDate.IGF_START_DATE
                ''IGF計算・終了年月      
                xlRange = xlOBAMAPSSheet.Cells(InsertIndex, ExcelWrite.ExcelPaymentLineColumn.IGF_END_DATE)
                xlRange.Value = defaultDate.IGF_END_DATE

                InsertIndex = InsertIndex + 1

            Next

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCopyRange, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub


    ''' <summary>
    ''' 概 要：行のグループ化の開始位置をセット
    ''' 説 明：
    ''' </summary>    
    ''' <remarks></remarks>
    Private Function SetGroupIndex(ByVal groupIndex As GrIndex,
                                   ByVal SummaryNM As String,
                                   ByVal index As Integer) As GrIndex

        ''戻り値
        Dim rtnIndex As GrIndex
        rtnIndex = groupIndex

        Select Case SummaryNM
            Case CELLVALUE_SummaryNM_InstDay
                rtnIndex.InstDay = index + 1

            Case CELLVALUE_SummaryNM_BrandInfo
                rtnIndex.InstDay = index + 1
                rtnIndex.BrandInfo = index + 1

            Case CELLVALUE_SummaryNM_SortNMQCOS
                rtnIndex.BrandInfo = index + 1
                rtnIndex.InstDay = index + 1
                rtnIndex.QCOS = index + 1

            Case CELLVALUE_SummaryNM_NewOrDel

                rtnIndex.BrandInfo = index + 1
                rtnIndex.InstDay = index + 1
                rtnIndex.QCOS = index + 1
                rtnIndex.NewOrDel = index + 1

            Case Else
                rtnIndex.BrandInfo = EXCEL_IGFDATA_OUTROW
                rtnIndex.InstDay = EXCEL_IGFDATA_OUTROW
                rtnIndex.QCOS = EXCEL_IGFDATA_OUTROW
                rtnIndex.NewOrDel = EXCEL_IGFDATA_OUTROW
                rtnIndex.ALLSUM = EXCEL_IGFDATA_OUTROW
        End Select

        Return rtnIndex

    End Function


    ''' <summary>
    ''' 概 要：Brandのソート順を取得
    ''' 説 明：
    ''' </summary>    
    ''' <remarks></remarks>
    Private Function GetBrandInfoSort(ByVal Row As DataRow) As String

        ''初期化
        GetBrandInfoSort = "99"

        Select Case Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BU).ToString
            Case "STG"
                Select Case Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND).ToString
                    Case "HW"
                        GetBrandInfoSort = "01"
                    Case "HW BRAND SW"
                        GetBrandInfoSort = "02"
                    Case "HW BRAND SWMA"
                        GetBrandInfoSort = "03"
                    Case "HW brand SVC"
                        GetBrandInfoSort = "04"
                    Case Else
                        GetBrandInfoSort = "05"
                End Select
            Case "SWG"
                Select Case Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND).ToString
                    Case "ESW"
                        GetBrandInfoSort = "06"
                    Case "SW Brand SW"
                        GetBrandInfoSort = "07"
                    Case "SW Brand SWMA"
                        GetBrandInfoSort = "08"
                    Case "PA-Media"
                        GetBrandInfoSort = "09"
                    Case "PA-License"
                        GetBrandInfoSort = "10"
                    Case "PA-S&S"
                        GetBrandInfoSort = "11"
                    Case "SW Brand Service"
                        GetBrandInfoSort = "12"
                    Case Else
                        GetBrandInfoSort = "13"
                End Select
            Case "GTS"
                Select Case Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND).ToString
                    Case "GTS-MTS"
                        GetBrandInfoSort = "14"
                    Case "GTS-ITS"
                        GetBrandInfoSort = "15"
                    Case Else
                        GetBrandInfoSort = "16"
                End Select
            Case "GBS"
                Select Case Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND).ToString
                    Case "GBS-SVC"
                        GetBrandInfoSort = "17"
                    Case Else
                        GetBrandInfoSort = "18"
                End Select
            Case "IGF"
                Select Case Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND).ToString
                    Case "IGF(中古)"
                        GetBrandInfoSort = "19"
                    Case "IGF(金利)"
                        GetBrandInfoSort = "20"
                    Case Else
                        GetBrandInfoSort = "21"
                End Select
            Case "VLS"
                Select Case Row.Item("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND).ToString
                    Case "IASC"
                        GetBrandInfoSort = "22"
                    Case "IASC(SPOT)"
                        GetBrandInfoSort = "23"
                    Case Else
                        GetBrandInfoSort = "24"
                End Select
            Case Else
                GetBrandInfoSort = "25"
        End Select
    End Function

    ''' <summary>
    ''' 概 要：IGF出力対象のSQLを取得
    ''' 説 明：
    ''' </summary>    
    ''' <remarks></remarks>
    Private Function GetOutIGFSQL() As String

        ''初期化
        GetOutIGFSQL = ""

        Dim filter As New StringBuilder
        filter.Append("SummaryNM")
        filter.Append(" IN ")
        filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        filter.Append(StringEdit.EncloseSingleQuotation(CELLVALUE_SummaryNM_Normal))
        filter.Append(CommonConstant.STR_COMMA)
        filter.Append(StringEdit.EncloseSingleQuotation(CELLVALUE_SummaryNM_BrandInfo))
        filter.Append(CommonConstant.STR_COMMA)
        filter.Append(StringEdit.EncloseSingleQuotation(CELLVALUE_SummaryNM_InstDay))
        filter.Append(CommonConstant.STR_COMMA)
        filter.Append(StringEdit.EncloseSingleQuotation(CELLVALUE_SummaryNM_SortNMQCOS))
        filter.Append(CommonConstant.STR_COMMA)
        filter.Append(StringEdit.EncloseSingleQuotation(CELLVALUE_SummaryNM_NewOrDel))
        filter.Append(CommonConstant.STR_COMMA)
        filter.Append(StringEdit.EncloseSingleQuotation(CELLVALUE_SummaryNM_ALLSUM))
        filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

        Return filter.ToString

    End Function

    ''' <summary>
    ''' 概 要：名前の定義の削除
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub DelExcelNames(ByRef xlApp As Excel.Application)

        Dim nameIdx As Integer           ''名前の定義ループ関数
        Dim nameMax As Integer           ''名前の定義のMax数 
        Dim NGIdx As Integer             ''削除しない名前の定義のループ関数
        Dim isMatch As Boolean
        'START 変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
        Dim xlNames As Excel.Names       ''Excelの名前の定義
        'END   変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
        Dim xlName As Excel.Name         ''Excelの名前の定義
        Dim notDelNames(6) As String     ''削除対象外の名前の定義

        Try
            ''削除対象外の名前をセット
            notDelNames(0) = "_FilterDatabase"      ''Excel自動生成:ｵｰﾄﾌｨﾙﾀの範囲
            notDelNames(1) = "Print_Area"           ''Excel自動生成:印刷の範囲
            notDelNames(2) = "契約開始"             ''ユーザ定義：
            notDelNames(3) = "契約終了"             ''ユーザ定義：
            notDelNames(4) = "年月"                 ''ユーザ定義：入力規則で使用
            notDelNames(5) = "Payment展開"          ''ユーザ定義：入力規則で使用
            notDelNames(6) = "IGF契約形態"          ''ユーザ定義：入力規則で使用

            'START 変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
            xlNames = xlApp.Names
            nameMax = xlNames.Count
            'nameMax = xlApp.Names.Count
            'END   変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
            For nameIdx = nameMax To 1 Step -1

                ''削除対象の名前の定義を設定
                isMatch = False
                'START 変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
                xlName = xlNames.Item(nameIdx)
                'xlName = xlApp.Names.Item(nameIdx)
                'END   変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
                For NGIdx = 0 To UBound(notDelNames)
                    If xlName.Name.ToString.IndexOf(notDelNames(NGIdx)) <> -1 Then
                        If (xlName.RefersTo.ToString.IndexOf("依頼後!") <> -1 Or xlName.RefersTo.ToString.IndexOf("リスト!") <> -1) Then
                            isMatch = True
                            Exit For
                        End If
                    End If
                Next
                ''名前の定義を削除
                If isMatch = False Then
                    Call xlName.Delete()
                End If
                'START 変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
                ExcelObjRelease.ReleaseExcelObj(xlName, ExcelObjRelease.OBJECT_NOTHING)
                'END   変更管理#3?（Excel.exeの解放対応)　2017/01 sugo

            Next
            'START 変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
            ExcelObjRelease.ReleaseExcelObj(xlNames, ExcelObjRelease.OBJECT_NOTHING)
            'END   変更管理#3?（Excel.exeの解放対応)　2017/01 sugo

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlName, ExcelObjRelease.OBJECT_NOTHING)
            'START 変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
            ExcelObjRelease.ReleaseExcelObj(xlNames, ExcelObjRelease.OBJECT_NOTHING)
            'END   変更管理#3?（Excel.exeの解放対応)　2017/01 sugo
            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' 概 要：入力結果OKかどうか判定する。
    ''' 説 明：
    ''' </summary>
    ''' <param name="xlIGFResultSheet"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function ChkXlsInputErr(ByRef xlIGFResultSheet As Excel.Worksheet) As String

        ''初期化
        ChkXlsInputErr = ""

        Const Chk_OK As String = "チェック結果:OK"
        Const Chk_ItemExists As String = "チェック済み"
        Dim xlRange As Excel.Range
        Try
            ''D3セルに「チェック済み」の文言チェック
            xlRange = xlIGFResultSheet.Range("D3")
            If xlRange.Value <> Chk_ItemExists Then
                ChkXlsInputErr = FileReader.GetMessage("MSG_0355")
                Exit Function
            End If

            ''E3セルが「チェック結果:OK」かチェック
            xlRange = xlIGFResultSheet.Range("E3")
            If xlRange.Value <> Chk_OK Then
                ChkXlsInputErr = FileReader.GetMessage("MSG_0356")
                Exit Function
            End If

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Function

    ''' <summary>
    '''概  要：OBAMA-PSｼｰﾄから、LinnoのMaxのSEQ番号を取得する。
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetMaxLineNoSeq(ByRef xlOBAMAPSSheet As Excel.Worksheet, _
                                     ByVal InsIndex As Integer) As Integer

        ''初期化
        Dim rtnValue As Integer = 0
        GetMaxLineNoSeq = rtnValue

        Dim seqNo As Integer
        Dim tmpSeqNo As String              ''一時変数：Cellの値を格納
        Dim tmpLockFlg As String            ''一時変数：Cellの値を格納
        Dim xlCell As Excel.Range
        Try

            ''PaymentSheetから、LinnoSeq番号が最大の値を検索する。
            For Idx As Integer = Me.EXCEL_PAYMENTLINEDATE_OUTROW To InsIndex

                ''契約順番が一致するかどうか判定する。
                xlCell = xlOBAMAPSSheet.Cells(Idx, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)
                tmpSeqNo = xlCell.Value
                xlCell = xlOBAMAPSSheet.Cells(Idx, ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG)
                tmpLockFlg = xlCell.Value
                If IsNumeric(tmpSeqNo) = True AndAlso _
                   tmpLockFlg <> "C" Then

                    ''LinnoからSeq部分を取り出す。
                    tmpSeqNo = tmpSeqNo.PadLeft(8, "0").Substring(3, 5)

                    ''MaxのSeqより値が大きければ、値を入替
                    If CInt(tmpSeqNo) > rtnValue Then
                        rtnValue = CInt(tmpSeqNo)
                    End If

                End If
            Next
            Return rtnValue

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Function

    ''' <summary>
    ''' 概 要：IGF金利行の初期日付
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetIGFMaxDate(ByVal IsAdd As Boolean, _
                                   ByRef OutPSDataTable As DataTable) As IGFDefaultDate

        ''戻り値
        Dim rtnValue As IGFDefaultDate

        ''IGF情報抽出条件
        Dim filter As New StringBuilder
        filter.Append("CellNM" & ExcelWrite.IGFColumn.LINE_NO)
        filter.Append(CommonConstant.SQL_STR_NOT_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation("削除分金利"))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append("CellNM" & ExcelWrite.IGFColumn.LINE_NO)
        filter.Append(CommonConstant.SQL_STR_NOT_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation("追加分金利"))
        filter.Append(CommonConstant.SQL_STR_AND)
        If IsAdd = True Then
            filter.Append("CellNM" & ExcelWrite.IGFColumn.QTY)
            filter.Append(CommonConstant.SQL_STR_NOT)
            filter.Append(CommonConstant.SQL_STR_LIKE)
            filter.Append(StringEdit.EncloseSingleQuotation("-*"))
        Else
            filter.Append("CellNM" & ExcelWrite.IGFColumn.QTY)
            filter.Append(CommonConstant.SQL_STR_LIKE)
            filter.Append(StringEdit.EncloseSingleQuotation("-*"))
        End If

        ''Max日付取得
        Dim tmpIGFDefaultDate As IGFDefaultDate
        For Each tmpRow As DataRow In OutPSDataTable.Select(filter.ToString)

            ''導入年月
            If IsDate(tmpRow.Item("CellNM" & ExcelWrite.IGFColumn.INST_DATE)) = True Then
                tmpIGFDefaultDate.INST_DATE = tmpRow.Item("CellNM" & ExcelWrite.IGFColumn.INST_DATE)
            Else
                tmpIGFDefaultDate.INST_DATE = ""
            End If
            If IsNothing(rtnValue.INST_DATE) = True Or _
                rtnValue.INST_DATE > tmpIGFDefaultDate.INST_DATE Then
                rtnValue.INST_DATE = tmpIGFDefaultDate.INST_DATE
            End If
            ''元本計算・開始年月
            If IsDate(tmpRow.Item("CellNM" & ExcelWrite.IGFColumn.PAY_START_DATE)) = True Then
                tmpIGFDefaultDate.PAY_START_DATE = tmpRow.Item("CellNM" & ExcelWrite.IGFColumn.PAY_START_DATE)
            Else
                tmpIGFDefaultDate.PAY_START_DATE = ""
            End If
            If IsNothing(rtnValue.PAY_START_DATE) = True Or _
                rtnValue.PAY_START_DATE > tmpIGFDefaultDate.PAY_START_DATE Then
                rtnValue.PAY_START_DATE = tmpIGFDefaultDate.PAY_START_DATE
            End If
            ''元本計算・終了年月
            If IsDate(tmpRow.Item("CellNM" & ExcelWrite.IGFColumn.PAY_END_DATE)) = True Then
                tmpIGFDefaultDate.PAY_END_DATE = tmpRow.Item("CellNM" & ExcelWrite.IGFColumn.PAY_END_DATE)
            Else
                tmpIGFDefaultDate.PAY_END_DATE = ""
            End If
            If IsNothing(rtnValue.PAY_END_DATE) = True Or _
                rtnValue.PAY_END_DATE < tmpIGFDefaultDate.PAY_END_DATE Then
                rtnValue.PAY_END_DATE = tmpIGFDefaultDate.PAY_END_DATE
            End If
            ''IGF計算・開始年月
            If IsDate(tmpRow.Item("CellNM" & ExcelWrite.IGFColumn.IGF_START_DATE)) = True Then
                tmpIGFDefaultDate.IGF_START_DATE = tmpRow.Item("CellNM" & ExcelWrite.IGFColumn.IGF_START_DATE)
            Else
                tmpIGFDefaultDate.IGF_START_DATE = ""
            End If
            If IsNothing(rtnValue.IGF_START_DATE) = True Or _
               rtnValue.IGF_START_DATE > tmpIGFDefaultDate.IGF_START_DATE Then
                rtnValue.IGF_START_DATE = tmpIGFDefaultDate.IGF_START_DATE
            End If
            ''IGF計算・終了年月
            If IsDate(tmpRow.Item("CellNM" & ExcelWrite.IGFColumn.IGF_END_DATE)) = True Then
                tmpIGFDefaultDate.IGF_END_DATE = tmpRow.Item("CellNM" & ExcelWrite.IGFColumn.IGF_END_DATE)
            Else
                tmpIGFDefaultDate.IGF_END_DATE = ""
            End If
            If IsNothing(rtnValue.IGF_END_DATE) = True Or _
               rtnValue.IGF_END_DATE < tmpIGFDefaultDate.IGF_END_DATE Then
                rtnValue.IGF_END_DATE = tmpIGFDefaultDate.IGF_END_DATE
            End If
        Next

        ''戻り値
        GetIGFMaxDate = rtnValue

    End Function

    ''' <summary>
    ''' 概 要：BU/Brand集計行に式をセットする
    ''' 説 明：index:集計行、StartRow:集計対象明細の開始行、EndRow:集計対象明細の終了行
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub setSummaryFormula(ByRef pasteValue(,) As Object, _
                                  ByVal index As Integer, _
                                  ByVal StartRow As Integer, _
                                  ByVal EndRow As Integer)

        Dim CC As Integer
        Dim Columns() As String = {"BV", "BW", "BX", "BY", "BZ", _
                                   "CA", "CB", "CC", "CD", "CE", "CF", "CG", "CH", "CI", "CJ", "CK", "CL", "CM", "CN", "CO", "CP", "CQ", "CR", "CS", "CT", "CU", "CV", "CW", "CX", "CY", "CZ", _
                                   "DA", "DB", "DC", "DD", "DE", "DF", "DG", "DH", "DI", "DJ", "DK", "DL", "DM", "DN", "DO", "DP", "DQ", "DR", "DS", "DT", "DU", "DV", "DW", "DX", "DY", "DZ", _
                                   "EA", "EB", "EC", "ED", "EE", "EF", "EG", "EH", "EI", "EJ", "EK", "EL", "EM", "EN", "EO", "EP", "EQ", "ER", "ES", "ET", "EU", "EV", "EW", "EX", "EY", "EZ", _
                                   "FA", "FB", "FC", "FD", "FE", "FF", "FG", "FH", "FI", "FJ", "FK", "FL", "FM", "FN", "FO", "FP", "FQ", "FR", "FS", "FT", "FU", "FV", "FW", "FX", "FY", "FZ", _
                                   "GA", "GB", "GC", "GD", "GE", "GF", "GG", "GH", "GI", "GJ", "GK", "GL", "GM", "GN", "GO", "GP", "GQ", "GR", "GS", "GT", "GU", "GV", "GW", "GX", "GY", "GZ", _
                                   "HA", "HB", "HC", "HD", "HE", "HF", "HG", "HH", "HI", "HJ", "HK", "HL", "HM", "HN", "HO", "HP", "HQ", "HR", "HS", "HT", "HU", "HV", "HW", "HX", "HY", "HZ", _
                                   "IA", "IB", "IC", "ID", "IE", "IF", "IG", "IH", "II", "IJ", "IK", "IL", "IM", "IN", "IO", "IP", "IQ", "IR", "IS", "IT", "IU", "IV", "IW", "IX", "IY", "IZ", _
                                   "JA", "JB", "JC", "JD", "JE", "JF", "JG", "JH", "JI", "JJ", "JK", "JL", "JM", "JN", "JO", "JP", "JQ", "JR", "JS", "JT", "JU", "JV", "JW", "JX", "JY", "JZ", _
                                   "KA", "KB", "KC", "KD", "KE", "KF", "KG", "KH", "KI", "KJ", "KK", "KL", "KM", "KN", "KO", "KP", "KQ", "KR", "KS", "KT", "KU", "KV", "KW", "KX", "KY", "KZ", _
                                   "LA", "LB", "LC", "LD", "LE", "LF", "LG", "LH", "LI", "LJ", "LK", "LL", "LM", "LN", "LO", "LP", "LQ", "LR", "LS", "LT", "LU", "LV", "LW", "LX", "LY", "LZ", _
                                   "MA", "MB"}

        For CC = 0 To 266
            pasteValue(index - EXCEL_IGFDATA_OUTROW, ExcelWrite.IGFColumn.PRICE_TO_SPLIT + CC) = "=SUBTOTAL(9," & Columns(CC) & StartRow & ":" & Columns(CC) & EndRow & ")"
        Next

    End Sub

    ''' <summary>
    ''' Payment展開期間取得処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Function getDeploymentPeriod() As Integer
        Dim wc As New WebDb.WebDbCommon
        Dim blnRet As Boolean
        Dim strDP As String() = {"", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K"}
        Dim str1 As String
        Dim int1 As Integer
        Dim ii As Integer
        Dim ContractBaseTable As New M_CONTRACT_BASETable
        Dim strMsg As String = ""

        Try
            getDeploymentPeriod = 20

            '認証設定
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW
            '契約基本情報取得
            blnRet = wc.GetContractBaseData(CommonVariable.CPNO, ContractBaseTable, strMsg)
            If blnRet = False Then
                Exit Function
            End If
            str1 = CommonVariable.PaymentPeriod
            MsgBox(str1)
            'PA_ANV_DATEの１文字目切り出し
            str1 = Mid(ContractBaseTable.Rows(0).Item(ContractBaseTable.COLUMN_NAME_PA_ANV_DATE), 1, 1)

            '１文字目をIndexに変換
            int1 = 0
            For ii = 0 To 20
                If str1 = strDP(ii) Then
                    int1 = ii
                End If
            Next
            If int1 = 0 Then
                int1 = 20
            End If
            getDeploymentPeriod = int1
            Exit Function

        Catch ex As Exception
            Throw ex

        End Try

    End Function

    ''' <summary>
    ''' 概 要：IGF申請書ファイルの処理モードをデータに応じて変換する。
    ''' 説 明：※データによって処理モードを変更する。
    ''' </summary>    
    ''' <remarks></remarks>
    Private Sub ConvertIGFData(ByVal IGFFilePath As String, _
                               ByRef OutPSDataTable As IGFDataTable, _
                               ByRef Msg As String)
        ''IGFファイル
        Dim xlApp As New Excel.Application
        Dim xlIGFBook As Excel.Workbook
        Dim xlIGFIraigoSheet As Excel.Worksheet
        Dim xlIGFWs1Sheet As Excel.Worksheet
        Dim xlCell As Excel.Range

        Const CELL_EXCELSTARTYEAR As String = "H7"
        Const CELL_EXCELENDYEAR As String = "I7"

        Dim wPeriod As Long         '展開期間終了IDX
        Dim fUpd As Boolean         '変更フラグ

        Dim wYear As Long
        Dim wSYear As String
        Dim wEYear As String
        Dim StartDate As String     '支払開始月
        Dim EndDate As String       '支払終了月
        Dim curTen As Long          '展開金額
        Dim curOfP As Long          'OfferingPrice
        Dim curPer As Double        'IGF料率

        Dim Months(ExcelWrite.IGFColumn.PRICE_YEAR20_MONTH12) As String
        Dim ii As Integer

        Try
            'START 変更管理#36（Excel365対応)　2017/01 sugo
            xlApp.EnableEvents = False
            xlApp.DisplayAlerts = False
            'END   変更管理#36（Excel365対応)　2017/01 sugo

            ''IGF.Xlsのシートの取得
            xlIGFBook = xlApp.Workbooks.Open(IGFFilePath)
            xlIGFIraigoSheet = xlIGFBook.Worksheets("依頼後")
            xlIGFWs1Sheet = xlIGFBook.Worksheets("WS1")

            'WS1シートの日付を取得
            'Payment展開開始年月
            xlCell = xlIGFWs1Sheet.Range(CELL_EXCELSTARTYEAR)
            wSYear = String.Format(xlCell.Value, "yyyy")
            'Payment展開終了年月
            xlCell = xlIGFWs1Sheet.Range(CELL_EXCELENDYEAR)
            wEYear = String.Format(xlCell.Value, "yyyy")

            '展開終了カラム算出
            wYear = Val(wEYear) - Val(wSYear) + 1
            wPeriod = ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH1 + wYear * 12 - 1

            '依頼後シートの年月部分を取得(比較用年月文字列として)
            For ii = ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH1 To wPeriod
                xlCell = xlIGFIraigoSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ii) & 9)
                Months(ii) = xlCell.Value
            Next

            ''========================================
            ''読込IGFデータの展開モードを変換
            ''========================================
            For Each row As DataRow In OutPSDataTable.Rows

                ''IGF金利行は除く
                If row.Item(ExcelWrite.IGFColumn.LINE_NO) = "削除分金利" Then
                    Continue For
                End If
                If row.Item(ExcelWrite.IGFColumn.LINE_NO) = "追加分金利" Then
                    Continue For
                End If

                fUpd = False

                'IGF支払期間を取得
                StartDate = Left(String.Format(row.Item("CellNM" & ExcelWrite.IGFColumn.IGF_START_DATE).ToString, "yyyy/MM/dd"), 10)
                EndDate = Left(String.Format(row.Item("CellNM" & ExcelWrite.IGFColumn.IGF_END_DATE).ToString, "yyyy/MM/dd"), 10)

                '展開金額
                curTen = Val(row.Item("CellNM" & ExcelWrite.IGFColumn.PRICE_TO_SPLIT).ToString)
                'IGF料率
                curPer = Val(row.Item("CellNM" & ExcelWrite.IGFColumn.IGF_RATE_IOC).ToString)
                'OfferingPrice
                curOfP = Val(row.Item("CellNM" & ExcelWrite.IGFColumn.PRICE_TOTAL_IOC).ToString)

                ''========================================
                ''以下、入力値に従って展開モードを修正
                ''========================================
                'チェック1:支払期間以外にデータ入力がある→変則に変更
                For ii = ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH1 To wPeriod
                    If Months(ii) < StartDate Or _
                       Months(ii) > EndDate Then
                        If row.Item("CellNM" & ii).ToString <> "" And _
                            row.Item("CellNM" & ii).ToString <> "0" Then
                            '期間外エリアに入力あり
                            ''MsgBox("支払期間外に入力: (" & row.Item("CellNM" & ExcelWrite.IGFColumn.FILE_NAME_SUFFIX_INTR) & ":" & ii & ") " & row.Item("CellNM" & ii).ToString) 'For DEBUG
                            row.Item("CellNM" & ExcelWrite.IGFColumn.CALCULATION) = "変則"
                            fUpd = True
                            Exit For
                        End If
                    End If
                Next

                'チェック2:支払期間の入力値が同一値でない→変則に変更
                If fUpd = False Then
                    Dim wCur As Long
                    For ii = ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH1 To wPeriod
                        If Months(ii) >= StartDate And _
                           Months(ii) <= EndDate Then
                            '開始月：比較値取得
                            If Months(ii) = StartDate Then
                                wCur = Val(row.Item("CellNM" & ii).ToString)
                            End If

                            If Val(row.Item("CellNM" & ii).ToString) <> wCur Then
                                '異なる金額が入力されている
                                ''MsgBox("金額が異なる: (" & row.Item("CellNM" & ExcelWrite.IGFColumn.FILE_NAME_SUFFIX_INTR) & ":" & ii & ") " & row.Item("CellNM" & ii).ToString & "<->" & wCur) 'For DEBUG
                                row.Item("CellNM" & ExcelWrite.IGFColumn.CALCULATION) = "変則"
                                fUpd = True
                                Exit For
                            End If
                        End If
                    Next
                End If

                'チェック4:支払期間の入力値が計算値と異なる→固定に変更
                If fUpd = False Then
                    Dim wCur As Long
                    For ii = ExcelWrite.IGFColumn.PRICE_YEAR1_MONTH1 To wPeriod
                        If Months(ii) >= StartDate And _
                           Months(ii) <= EndDate Then
                            '開始月：比較値取得
                            If Months(ii) = StartDate Then
                                wCur = Val(row.Item("CellNM" & ii).ToString)
                            End If

                            If xlApp.WorksheetFunction.RoundUp(curOfP * curPer, -1) <> wCur Then
                                '展開金額と異なる金額が入力されている
                                row.Item("CellNM" & ExcelWrite.IGFColumn.CALCULATION) = "固定"
                                row.Item("CellNM" & ExcelWrite.IGFColumn.PRICE_TO_SPLIT) = wCur
                                fUpd = True
                            End If
                            Exit For
                        End If
                    Next
                End If

                'チェック5:どのチェックにも引っかからない場合→標準とする
                If fUpd = False Then
                    row.Item("CellNM" & ExcelWrite.IGFColumn.CALCULATION) = ""
                End If
            Next

        Catch ex As Exception
            Throw ex

        Finally
            'START 変更管理#36（Excel365対応)　2017/01 sugo
            'xlApp.EnableEvents = True
            'xlApp.DisplayAlerts = True
            'END   変更管理#36（Excel365対応)　2017/01 sugo
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlIGFIraigoSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlIGFWs1Sheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlIGFBook) = False Then
                xlIGFBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlIGFBook, ExcelObjRelease.OBJECT_NOTHING)
            'START 変更管理#36（Excel365対応)　2017/01 sugo
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            'END   変更管理#36（Excel365対応)　2017/01 sugo
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try
    End Sub
    'START 変更管理#27（1285固定COST%の定期メンテナンス対応）　2016/04 ueda
    ''' <summary>
    ''' 概 要：Master.accdbからIGF金利のCostを取得し、GP%を計算する
    ''' 説 明：
    ''' </summary>
    ''' <param name="CPNO">CPNO</param>
    ''' <remarks></remarks>
    Private Function InterestrateGpGet() As String

        Dim mdc As New MasterMdbControl
        Dim dbCon As OleDbConnection
        Dim odc As New OleDbCode
        Dim dbTable As DataTable
        Dim ii As Integer
        Dim Rows As DataRow
        Dim GetGp As String

        '認証設定
        dbCon = mdc.GetOleDBConnection(CommonVariable.MdbPW)
        'dbCon = mdc.GetOleDBConnection()

        'CODEテーブル取得
        dbTable = odc.SelectDataTable(dbCon, "Cost")

        '取得内容チェック
        If dbTable.Rows.Count = 0 Then
            InterestrateGpGet = 0     '登録なしの場合は0をセット
        Else
            Dim filterSel As New StringBuilder

            'IGF金利のCost検索
            filterSel.Append("ItemCode")
            filterSel.Append(CommonConstant.SQL_STR_EQUAL)
            filterSel.Append(StringEdit.EncloseSingleQuotation("29"))

            If dbTable.Select(filterSel.ToString).Length = 0 Then
                InterestrateGpGet = ""
            Else
                For Each Rows In dbTable.Select(filterSel.ToString)
                    GetGp = ExcelWrite.changeDBNullToString(Rows.Item("ItemValue"))
                    InterestrateGpGet = 1 - (GetGp * 0.01)
                    Exit Function
                Next
            End If
        End If

        dbCon.Close()

    End Function
    'END 変更管理#27（1285固定COST%の定期メンテナンス対応）　2016/04 ueda

#End Region

End Class
