﻿Imports System.IO
Imports System.Text
Imports System.Data.OleDb
'Imports Shell32
Imports Microsoft.Office.Interop
Imports MUSE.Utility
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.OioBamaCommmon
Imports MUSE.Utility.UserMessageBox
Imports MUSE.WinUI.OioBamaCommmon
Imports MUSE.Utility.XmlClass.SheetFoumulate
Imports MUSE.Utility.UserDataTable.Master
Imports MUSE.Utility.XmlClass.Parameter

Public Class Frm_Menu

#Region "メンバ変数"
    Private _authority As String
    Private _cpno As Integer
    Private _contractNo As Integer
    Private _customerName As String

    ''処理中ダイアログ表示用
    Private Const STR_CREATING As String = "処理中・・・"
    Private Const STR_MESSAGE_CREATE_FILE As String = "ファイルを処理中です。"

#End Region

#Region "プロパティ"
    Public Property CPNO() As Integer
        Set(ByVal value As Integer)
            Me._cpno = value
        End Set
        Get
            Return Me._cpno
        End Get
    End Property

    Public Property CONTRACTNO() As Integer
        Set(ByVal value As Integer)
            Me._contractNo = value
        End Set
        Get
            Return Me._contractNo
        End Get
    End Property

    Public Property CUSTOMERNAME() As String
        Set(ByVal value As String)
            Me._customerName = value
        End Set
        Get
            Return Me._customerName
        End Get
    End Property
#End Region

#Region "イベント処理"
    Public Sub New()
        InitializeComponent()
        Me._authority = CommonVariable.AUTHORITY
    End Sub

    ''' <summary>
    ''' 集計及び台帳作成を押したとき
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Btn_DataOutput_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_DataOutput.Click
        Me.Hide()
        Dim frm2 As New Frm_DataOutput()
        frm2.ShowDialog()
        Me.Close()
    End Sub

    ''' <summary>
    ''' 契約情報画面に戻るを押したとき
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub UCnt_Btn00013_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UCnt_Btn00013.Click
        Me.Hide()
        Dim frm3 As New Frm_ContractInfo
        frm3.ShowDialog()
        Me.Close()
    End Sub

    ''' <summary>
    ''' 案件情報登録を押したとき
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Btn_RegistPlan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_RegistPlan.Click
        Me.Hide()
        Dim frm9 As New Frm_NewPlan
        frm9.ShowDialog()
        Me.Close()
    End Sub

    ''' <summary>
    ''' エクスポート/インポートを押したとき
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Btn_ExpImp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_ExpImp.Click
        Me.Hide()
        Dim frm4 As New Frm_NewImportExport(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
        frm4.ShowDialog()
        Me.Close()
    End Sub

    ''' <summary>
    ''' PMO管理を押したとき
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Btn_PmoManage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_PmoManage.Click

        'MasterMDB存在チェック
        Dim ofm As New OioFileManage
        Dim strErrMsg As String
        If ofm.CheckExistsMdb(OioFileManage.enmMdbType.Master, CommonVariable.MdbPW, strErrMsg) = False Then
            Call MuseMessageBox.ShowError(strErrMsg, Me.Text)
            Exit Sub
        End If

        Me.Hide()
        Dim frm As New Frm_NewPmoManage
        frm.ShowDialog()
        Me.Close()
    End Sub


    ''' <summary>
    ''' 構成情報読込を押したとき
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Btn_ReadStructInf_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_ReadStructInf.Click


        ''ファイルのチェックロジック
        Dim ofm As New OioFileManage
        Dim PSFilePath As String
        PSFilePath = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
        PSFilePath = PSFilePath & ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)

        ''①ファイルの存在チェック
        If File.Exists(PSFilePath) = False Then
            Call MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0326"), Me.Text)
            Exit Sub
        End If

        ''②個別PSがOPENしているか判定
        If ofm.ChkOpenedExcelFile(PSFilePath) = False Then
            Call MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0280") & vbCrLf & vbCrLf _
                                          & "ファイル名：" & Path.GetFileName(PSFilePath), Me.Text)
            Exit Sub
        End If
        Me.Hide()

        Dim psline As New OioProject
        If GetPSLineInfo(psline) = True Then
            Dim frm5 As New Frm_Oio(psline)
            frm5.ShowDialog()
            If frm5.DialogResult = DialogResult.Cancel Then
                Me.Close()
            Else
                Me.Show()
            End If
        End If

    End Sub

    Private Sub UCnt_Btn00012_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UCnt_Btn00012.Click
        Me.Close()
    End Sub


    Private Sub Form7_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Call SetCmboContractNo()
        cboContractNo.Text = CommonVariable.CONTRACTNO.ToString.PadLeft(3, "0c") & " " & CommonVariable.CONTRACTNONAME.ToString.Replace("&", "&&")

        _authority = CommonVariable.AUTHORITY
        lblCPNO.Text = CommonVariable.CUSTOMERNAME.Replace("&", "&&") + "(" + CommonVariable.CPNO.ToString() + ")"
        lblContractName.Text = CommonVariable.CONTRACTNONAME.ToString.Replace("&", "&&")

        Me.Btn_PaymentEditing.Enabled = Autority.ChkEnableAuthority(_authority, Me.Name, Me.Btn_PaymentEditing.Name)
        Me.Btn_ReadStructInf.Enabled = Autority.ChkEnableAuthority(_authority, Me.Name, Me.Btn_ReadStructInf.Name)
        Me.Btn_ExpImp.Enabled = Autority.ChkEnableAuthority(_authority, Me.Name, Me.Btn_ExpImp.Name)
        Me.Btn_DataOutput.Enabled = Autority.ChkEnableAuthority(_authority, Me.Name, Me.Btn_DataOutput.Name)
        Me.Btn_RegistPlan.Enabled = Autority.ChkEnableAuthority(_authority, Me.Name, Me.Btn_RegistPlan.Name)
        Me.Btn_PmoManage.Enabled = Autority.ChkEnableAuthority(_authority, Me.Name, Me.Btn_PmoManage.Name)
        Me.Btn_DspFrmTmp.Enabled = Autority.ChkEnableAuthority(_authority, Me.Name, Me.Btn_DspFrmTmp.Name)


        Dim ExcelExportFileDirPath As String = ""
        Dim CsvExportFileDirPath As String = ""
        System.Environment.CurrentDirectory = Application.StartupPath

        ''Excelのエクスポートファイルのフォルダ位置
        ExcelExportFileDirPath = System.IO.Path.GetFullPath("../Excel")
        CsvExportFileDirPath = System.IO.Path.GetFullPath("../Csvtemp")
        Dim ExcelOutPath As String = ExcelExportFileDirPath & "\" & CommonVariable.CPNO.PadLeft(8, "0c") _
                                     & "_" & CommonVariable.CONTRACTNO.ToString.PadLeft(3, "0c")

        Dim CsvOutPath As String = CsvExportFileDirPath & "\" & CommonVariable.CPNO.PadLeft(8, "0c") _
                                     & "_" & CommonVariable.CONTRACTNO.ToString.PadLeft(3, "0c")
        ''Excel出力先フォルダの存在チェック
        If Directory.Exists(ExcelOutPath) = False Then
            'フォルダが存在しない場合は作成
            Directory.CreateDirectory(ExcelOutPath)
        End If

        If Directory.Exists(CsvOutPath) = False Then
            'フォルダが存在しない場合は作成
            Directory.CreateDirectory(CsvOutPath)
        End If


        ''契約済みMDB情報の取得
        Dim ofm As New OioFileManage
        Dim ContractMdbPath As String
        ContractMdbPath = ofm.GetDataKeepMDBPath(CommonVariable.CPNO)        ''契約締結済MDBのパス　※Loadイベントのみセット

        ''契約済みMDB情報の取得
        Dim MaxPSCount As Integer
        Dim MaxDetailCount As Integer
        Dim strErrMsg As String
        If ofm.CheckExistsMdb(OioFileManage.enmMdbType.TempMdb, CommonVariable.MdbPW, strErrMsg, CommonVariable.CPNO) = False Then
            ''画面_MDB情報表示
            lblPSCreateTime.Text = "契約締結済みMDBが存在しません。"
            lblDetailCreateTime.Text = "契約締結済みMDBが存在しません。"
            lblPSMDBCount.Text = ""
            lblDetailMDBCount.Text = ""
            lblPSMDBCount.Visible = False
            lblDetailMDBCount.Visible = False
        Else
            ''画面_MDB情報表示
            Call GetMaxMdbCount(MaxPSCount, MaxDetailCount)
            lblPSCreateTime.Text = System.IO.File.GetLastWriteTime(ContractMdbPath)
            lblDetailCreateTime.Text = System.IO.File.GetLastWriteTime(ContractMdbPath)
            lblPSMDBCount.Text = MaxPSCount.ToString("###,###,##0") & "件"
            lblDetailMDBCount.Text = MaxDetailCount.ToString("###,###,##0") & "件"
            lblPSMDBCount.Visible = True
            lblDetailMDBCount.Visible = True
        End If

        ''JRIのみ、契約統合処理ﾎﾞﾀﾝを有効にする。
        If ChkTmpContractDate(CommonVariable.CPNO) = True Then
            Me.Btn_DspFrmTmp.Visible = True
        Else
            Me.Btn_DspFrmTmp.Visible = False
        End If
        Me.Text = CommonVariable.OBAMATITLE

    End Sub


    ''' <summary>
    ''' 機能：PaymentSheet編集ボタン押下時の処理
    ''' 説明：※VerUp処理と、BookOpen時のマクロの処理は後回し。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Btn_PaymentEditing_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_PaymentEditing.Click

        ''Excel変数宣言
        Dim app As Excel.Application
        Dim workbook As Excel.Workbook
        Dim blnRet As Boolean

        '処理中ダイアログ定義
        Dim waitDialog As New Frm_WaitDialog
        Dim WorkSheet As Excel.Worksheet

        Try

            ''Localの「Tmplate/Xml」を最新にする。
            Dim msg As String
            Dim ofm As New OioFileManage
            If ofm.CopyGSATmpFile(OioFileManage.enmTmpFileType.Payment, msg) = False Then
                Call MuseMessageBox.ShowError(msg, Me.Text)
                Exit Sub
            End If
            If ofm.CopyGSATmpFile(OioFileManage.enmTmpFileType.ExcelVersionInfo, msg) = False Then
                Call MuseMessageBox.ShowError(msg, Me.Text)
                Exit Sub
            End If

            'EXCELのバージョンアップ処理
            Dim evu As New ExcelVersionUp
            Dim frmWait As New Frm_WaitDialog
            Dim strExcelFileName As String = ""
            blnRet = evu.CheckExcelVersion(frmWait, strExcelFileName)
            frmWait.Close()
            If blnRet = False Then
                If File.Exists(strExcelFileName) = True Then
                    File.Delete(strExcelFileName)
                End If
                Exit Sub
            End If

            '処理中ダイアログ表示
            waitDialog.Text = STR_CREATING
            waitDialog.lbl_Message.Text = STR_MESSAGE_CREATE_FILE
            waitDialog.Pic_Excel.Visible = True
            waitDialog.ProgressMin = 0
            waitDialog.ProgressMax = 7
            waitDialog.ProgressStep = 1
            waitDialog.ProgressValue = 0
            waitDialog.Show()
            waitDialog.Refresh()

            ''ファイル名の取得
            Dim fileNM As String
            Dim fileManage As New OioFileManage
            fileNM = fileManage.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            fileNM = fileNM & fileManage.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)

            ''個別PSの存在チェック
            If File.Exists(fileNM) = False Then
                waitDialog.Close()
                Call MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0326"), Me.Text)
                Exit Sub
            End If

            ''個別PSのOPENチェック
            If fileManage.ChkOpenedExcelFile(fileNM) = False Then
                waitDialog.Close()
                Call MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0325") & vbCrLf & vbCrLf _
                                              & "ファイル名：" & Path.GetFileName(fileNM), Me.Text)
                Exit Sub
            End If

            ''ExcelのOPEN処理
            app = New Excel.Application
            app.Visible = True
            app.DisplayAlerts = False
            app.EnableEvents = False
            workbook = app.Workbooks.Open(fileNM)
            WorkSheet = workbook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)

            'Book内のマクロを実行
            '※後回し。マクロが完成したら実装する。
            Call Me.ExcelMacroKick(app, WorkSheet, workbook.Name)

            ''Bookの保存
            workbook.Save()

        Catch ex As Exception

            If workbook IsNot Nothing Then
                workbook.Close()
                workbook = Nothing
            End If
            MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0210"), Me.Text)

        Finally

            ''例外処理が発生しなかった場合のみフォームを削除
            If waitDialog.Created Then
                waitDialog.Close()
            End If
            ExcelObjRelease.ReleaseExcelObj(WorkSheet, ExcelObjRelease.OBJECT_NOT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(workbook, ExcelObjRelease.OBJECT_NOT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(app, ExcelObjRelease.OBJECT_NOT_NOTHING)

            GC.Collect()
        End Try

    End Sub

    ''' <summary>
    '''概  要：PSファイルのOpen時、Bookのマクロをキックする。
    '''説  明：※マクロの処理が作成されて時点でコメントアウトをはずす。
    ''' </summary>
    Private Sub ExcelMacroKick(ByRef App As Excel.Application, _
                               ByRef WorkSheet As Excel.Worksheet, _
                               ByVal BookNM As String)

        Try
            'Book内のマクロを実行
            Dim ResultT As String = DirectCast(App.Run("'" & BookNM & "'!VBCall", ExcelWrite.VBActNMList.PS編集, CommonVariable.USERID, CommonVariable.USERPW), String)

        Catch ex As Exception
            Throw ex
        End Try

    End Sub


    ''' <summary>
    ''' 機能：契約統合/削除画面の表示
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Btn_DspFrmTmp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_DspFrmTmp.Click

        Me.Visible = False
        Dim frmTmpContractUnification As New Frm_TmpContractUnification("Menu")
        Call frmTmpContractUnification.ShowDialog()

        ''JRI画面にて押下した終了ﾎﾞﾀﾝに応じて処理を行う。
        If frmTmpContractUnification.Rtn_ContractFrmBtn = True Then
            Me.Visible = True

        ElseIf frmTmpContractUnification.Rtn_LogOutBtn = True Then
            ''Login画面へﾎﾞﾀﾝ
            Me.Close()

        End If

    End Sub

    ''' <summary>
    ''' 機能：契約順番選択
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub cboContractNo_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboContractNo.SelectedIndexChanged

        Dim strWork As String
        strWork = cboContractNo.Text.Substring(0, 3)
        CommonVariable.CONTRACTNO = strWork
        strWork = cboContractNo.Text.Substring(4)
        lblContractName.Text = strWork
        CommonVariable.CONTRACTNONAME = strWork

        ''フォルダ作成
        Dim ofm As New OioFileManage
        Dim blnTmpContract As Boolean = False
        If ChkTmpContractDate(CommonVariable.CPNO) = True Then
            blnTmpContract = True
        End If
        Call ofm.CreateFrm_ContractInfoCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, blnTmpContract)

    End Sub

#End Region

#Region "プライベートメソッド"

    ''' <summary>
    ''' 機能：行チェック
    ''' 説明：行番、ファイル名、契約順番、案件番号のいずれかにデータあるかチェックする
    ''' 　　　True：ある　False：ない
    ''' </summary>
    ''' <param name="intIndex"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckRowItem(ByVal intIndex As Integer, ByVal ExcelCellInfo() As Object) As Integer

        CheckRowItem = False

        Try
            '行番、ファイル名、契約順番、案件番号が共に空文字の場合、データ無しとみなす
            If IsNothing(ExcelCellInfo(4)) = True And _
                IsNothing(ExcelCellInfo(5)) = True And _
                IsNothing(ExcelCellInfo(8)) = True And _
                IsNothing(ExcelCellInfo(11)) = True Then
                Exit Function
            End If
        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical)
        End Try

        CheckRowItem = True

    End Function


    Private Sub UCnt_Btn00011_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UCnt_Btn00011.Click
        ''Explorer表示
        Dim ofm As New OioFileManage
        If ofm.DispExplorer(CommonConstant.FOLDERNAME_EXCEL, CommonVariable.CPNO, CommonVariable.CONTRACTNO) = False Then
            MsgBox(FileReader.GetMessage("MSG_0208"), MsgBoxStyle.Exclamation, "")
        End If
    End Sub

    ''' <summary>
    ''' 機　能：メニュー起動時、CPNOがJRI対象か判定する。
    ''' 説　明：※仮契約統合/削除 ﾎﾞﾀﾝの表示判定に使用する。
    ''' </summary>
    ''' <remarks></remarks>
    Private Function ChkTmpContractDate(ByVal Cpno As String)

        Dim wc As New WebDb.WebDbCommon
        Dim blnRet As Boolean
        Dim strMsg As String = ""
        Dim dt As New M_CONTRACT_BASETable
        Dim strWhere As String

        ChkTmpContractDate = False

        Try
            '認証設定
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW

            '契約基本情報取得
            blnRet = wc.GetContractBaseData(CommonVariable.CPNO, dt, strMsg)
            If blnRet = False Then
                MsgBox(strMsg, MsgBoxStyle.Critical, "ChkTmpContractDate")
                Exit Function
            End If
            'フィルター
            strWhere = M_CONTRACT_BASETable.COLUMN_NAME_UNIFICATION_PATERN & "='01'"
            Dim rows() As DataRow
            rows = dt.Select(strWhere)
            'データ有無判定
            If rows.Length > 0 Then
                ChkTmpContractDate = True
            End If

        Catch ex As Exception
            Throw ex

        End Try


    End Function

    ''' <summary>
    ''' 機　能：契約締結済みMDBからPaymentと詳細の件数を取得する。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetMaxMdbCount(ByRef PSMaxCount As Integer, _
                               ByRef DetailMaxCount As Integer)

        ''初期化
        Dim rtnPSCount As Integer = 0
        Dim rtnDetailCount As Integer = 0
        PSMaxCount = rtnPSCount
        DetailMaxCount = rtnDetailCount

        ''接続情報設定
        Dim con As New OleDbConnection
        Dim dr As OleDbDataReader
        Dim cmd As New OleDbCommand()
        Try

            ''接続情報設定
            Dim mmc As New MasterMdbControl
            con = mmc.GetOleTmpDBConnection(CommonVariable.CPNO, CommonVariable.MdbPW)

            ''              ▼以下、Paymentの件数を取得する。
            ''-------------------------------------------------------------
            ''SQL文取得
            Dim sqlPS As New StringBuilder
            sqlPS.Append(CommonConstant.SQL_STR_SELECT)
            sqlPS.Append(CommonConstant.SQL_STR_COUNT)
            sqlPS.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            sqlPS.Append("ID")
            sqlPS.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
            sqlPS.Append(CommonConstant.SQL_STR_FROM)
            sqlPS.Append("PaymentTBL1")
            cmd.Connection = con
            cmd.CommandText = sqlPS.ToString

            ''ﾃﾞｰﾀ件数を取得
            dr = cmd.ExecuteReader()
            If dr.Read() = True Then
                rtnPSCount = dr.Item(0)
            End If
            dr.Close()

            ''              ▼以下、詳細の件数を取得する。
            ''-------------------------------------------------------------
            ''SQL文取得
            Dim sqlDetail As New StringBuilder
            sqlDetail.Append(CommonConstant.SQL_STR_SELECT)
            sqlDetail.Append(CommonConstant.SQL_STR_COUNT)
            sqlDetail.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            sqlDetail.Append("DETAIL_ID")
            sqlDetail.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
            sqlDetail.Append(CommonConstant.SQL_STR_FROM)
            sqlDetail.Append("PaymentDetailTBL")
            cmd.Connection = con
            cmd.CommandText = sqlDetail.ToString

            ''ﾃﾞｰﾀ件数を取得
            dr = cmd.ExecuteReader()
            If dr.Read() = True Then
                rtnDetailCount = dr.Item(0)
            End If
            dr.Close()
            con.Close()

            ''戻り値をセットする
            PSMaxCount = rtnPSCount
            DetailMaxCount = rtnDetailCount

        Catch ex As Exception
            ''Throw ex

        Finally
            ''MDBのConnectionを削除
            If IsNothing(dr) = False AndAlso _
               dr.IsClosed = False Then
                dr.Close()
            End If
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' 機能：契約順番コンボボックス設定
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function SetCmboContractNo() As Boolean

        Dim wc As New WebDb.WebDbCommon
        Dim blnRet As Boolean
        Dim strMsg As String = ""
        Dim strWhere As String
        Dim dt As New M_CONTRACT_DETAILTable
        Dim strWork As String
        Dim strOrderBy As String

        SetCmboContractNo = False

        Try
            '認証設定
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW

            '契約基本情報取得
            blnRet = wc.GetContractDetailData(CommonVariable.CPNO, dt, strMsg)
            If blnRet = False Then
                MsgBox(strMsg, MsgBoxStyle.Critical, "SetCmboContractNo")
                Exit Function
            End If

            'フィルター
            strWhere = "STATUS='0' OR STATUS='3'"
            dt.Columns.Add("s" & M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_NO, _
                           System.Type.GetType("System.Int32"), _
                           "Convert(@Name, 'System.Int32')".Replace("@Name", M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_NO))
            strOrderBy = "s" & M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_NO
            For Each row As DataRow In dt.Select(strWhere, strOrderBy)
                strWork = row.Item(M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_NO).ToString.PadLeft(3, "0c") & " " & _
                            ExcelWrite.changeDBNullToString(row.Item(M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_NO_NAME)).Replace("&", "&&")
                cboContractNo.Items.Add(strWork)
            Next

            SetCmboContractNo = True
        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "SetCmboContractNo")

        End Try


    End Function


    ''' <summary>
    ''' 概 要：構成画面へ渡す情報をセット
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetPSLineInfo(ByRef PSLine As OioProject) As Boolean

        ''初期化
        GetPSLineInfo = False

        Dim wc As New WebDb.WebDbCommon
        Dim blnRet As Boolean
        Dim strMsg As String = ""
        Dim tbl As New M_CONTRACT_BASETable
        Try
            ''N行情報初期値取得
            '認証設定
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW

            '契約基本情報取得
            blnRet = wc.GetContractBaseData(CommonVariable.CPNO, tbl, strMsg)
            If blnRet = False Then
                MsgBox(strMsg, MsgBoxStyle.Critical, "GetPSLineInfo")
                Exit Function
            End If


            ''値ｾｯﾄ
            Dim row As DataRow
            Dim tmpValue As String
            Dim defolutValue As String
            defolutValue = Now.ToString("yyyy/MM")
            PSLine.isNLine = False
            PSLine.Enable = "N"
            PSLine.PsFilePath = CheckPsFile()
            PSLine.FileName = "構成取込_@YYMMDD_HHMMSS.csv".Replace("@YYMMDD_HHMMSS", Now.ToString("yyyyMMdd_HHmmss"))
            PSLine.PlanNo = ""
            If tbl.Rows.Count = 0 Then
                PSLine.IntroductYM = Now.ToString("yyyy/MM")
                PSLine.PayStartTime = Now.ToString("yyyy/MM")
                PSLine.PayEndTime = Now.ToString("yyyy/MM")
            Else
                ''導入/請求開始年月
                row = tbl.Rows(0)
                tmpValue = row.Item(M_CONTRACT_BASETable.COLUMN_NAME_START_YEAR) & "/" & _
                           row.Item(M_CONTRACT_BASETable.COLUMN_NAME_START_MONTH)
                If IsDate(tmpValue) = True Then
                    PSLine.IntroductYM = CDate(tmpValue).AddMonths(-1).ToString("yyyy/MM")
                    PSLine.PayStartTime = tmpValue
                Else
                    tmpValue = defolutValue
                    PSLine.IntroductYM = defolutValue
                    PSLine.PayStartTime = defolutValue
                End If

                ''請求終了年月
                tmpValue = row.Item(M_CONTRACT_BASETable.COLUMN_NAME_END_YEAR) & "/" & _
                           row.Item(M_CONTRACT_BASETable.COLUMN_NAME_END_MONTH)
                If IsDate(tmpValue) = True Then
                    PSLine.PayEndTime = tmpValue
                    '1647 不備修正str
                    PSLine.InitPayEndTime = tmpValue
                    '1647 不備修正end
                Else
                    tmpValue = defolutValue
                    PSLine.PayEndTime = tmpValue
                End If
            End If

            GetPSLineInfo = True
        Catch ex As Exception
            Call MsgBox(ex.Message, MsgBoxStyle.Critical)

        End Try

    End Function

    ''' <summary>
    ''' 機能：PSファイル存在チェック
    ''' 説明：最新のPSが任意のフォルダに存在するかチェックする
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckPsFile() As String

        Dim strFileName As String = ""

        CheckPsFile = ""

        Try
            ''修正前の契約順番の取得

            ''ファイル名の取得
            Dim fileManage As New OioFileManage
            strFileName = fileManage.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO).ToString
            strFileName = strFileName & fileManage.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)

            'ファイル存在チェック
            Dim blnRet As Boolean
            blnRet = File.Exists(strFileName)
            If blnRet = False Then
                Exit Function
            End If

        Catch ex As Exception
            MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0210"), Me.Text)

        End Try

        CheckPsFile = strFileName

    End Function


#End Region

End Class