﻿Imports System.IO
Imports System.Text
Imports System.Data.OleDb
Imports Microsoft.Office.Interop
Imports MUSE.Utility
Imports MUSE.Utility.OioBamaCommmon
Imports MUSE.Utility.SharedClass

Public Class PsSplit

#Region "Const"

    '------------------------------------------
    'Excel関連
    '------------------------------------------
    Private Const EXCEL_MAX_ROW As Integer = 1048576      'EXCELの最終行

    Private Const STR_BUY As String = "購入"
    Private Const STR_HOSYU As String = "保守"

#End Region

#Region "Inner Class"

    'Paymentデータ
    Private Class PSExcelDataTable
        Inherits DataTable

        Public Sub New()

            Me.TableName = "PSExcelDataTable"

            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LINE_NO, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.ST_COST, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.ST_APPROVAL, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROJ_ID, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT_SEQ, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.NEW_EXIST, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CUST_CATEGORY, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LETTER_PLAN_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LETTER_ACCEPT_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.ORDER_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LETTER_ID, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.ORDERCODE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BU, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.SUM_CATEGORY, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND_SUB, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.OP1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.OP2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND_SIZE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.NON_SBO, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.POSTSCRIPT, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.TOPACS_CPNO, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_FORM, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_REQ, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_CONF, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PATTERN, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM04, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM05, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM06, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM07, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM08, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM09, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM13, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM14, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM15, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM16, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM17, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM18, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM19, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM20, Type.GetType("System.String"))
            'START 変更管理#??（1346 e-PricerValidation対応）　2016/01 sugo
            'Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM21, Type.GetType("System.String"))
            'END   変更管理#??（1346 e-PricerValidation対応）　2016/01 sugo
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM22, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM23, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM24, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.WD_ANNT_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.WD_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_CHG_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.QTY, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.INST_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_START_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_END_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.BID_FLAG, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_MONTHS, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_VALIDATION, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_APPLIED, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_NO, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_FORM, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_MANAGMENT, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.IGF_RATE_IOC, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_PROPOSAL, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.DP_IOC, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC, Type.GetType("System.String"))
            'START 変更管理#??（1346 e-PricerValidation対応）　2016/01 sugo
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC_VAL, Type.GetType("System.String"))
            'END   変更管理#??（1346 e-PricerValidation対応）　2016/01 sugo
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.COST_RATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.COST, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.COST_TOTAL, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.COST_INPUT_DATE, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_TO_SPLIT, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_IOC, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_TOTAL_IOC, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.COST_TOTAL_IOC, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_TOTAL_IGF, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT_IN, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.CONTRACT_OUT, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_DEFF_IGF, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH12, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH1, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH3, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH4, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH5, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH6, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH7, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH8, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH9, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH10, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH11, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12, Type.GetType("System.String"))

            ''集計行の作成時：PRICE_YEAR20_MONTH12のSubTotalを格納
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12 + 1, Type.GetType("System.String"))

            ''以下、ソート順
            Me.Columns.Add("SortNMNewOrDel", Type.GetType("System.String"))
            Me.Columns.Add("SortNMQCOS", Type.GetType("System.String"))
            Me.Columns.Add("SortNMInstDay", Type.GetType("System.String"))
            Me.Columns.Add("SortNMSummaryCategory", Type.GetType("System.String"))
            Me.Columns.Add("SortNMBrandInfo", Type.GetType("System.String"))
            Me.Columns.Add("SortNMFILE_NAME", Type.GetType("System.String"))
            Me.Columns.Add("SortNMFILE_NAME_SUFFIX", Type.GetType("System.String"))
            Me.Columns.Add("SortNMFILE_NAME_SUFFIX_INTR", Type.GetType("System.String"))
            Me.Columns.Add("SortNMPatternCD", Type.GetType("System.String"))
            Me.Columns.Add("SortNMExcelRow", Type.GetType("System.String"))

            ''以下、集計行の区分
            Me.Columns.Add("SummaryNM", Type.GetType("System.String"))          ''0:通常　1:小分類　2中分類 3:大分類 ・・・・・・　N：分類

            ''以下、Excel行
            Me.Columns.Add("ExcelRow", Type.GetType("System.String"))
            Me.Columns.Add("OutExcelRow", Type.GetType("System.String"))      ''出力行位置：SubTotalの計算等に使用
            Me.Columns.Add("IGF_AFTER", Type.GetType("System.String"))        ''IGF適用後
            Me.Columns.Add("IGF_RATE", Type.GetType("System.String"))         ''IGF金利

        End Sub
    End Class

#End Region

#Region "変数"
    Private strFileNo As String = ""    '契約順番
#End Region


#Region "Public"


    ''' <summary>
    ''' 機能：Payment分割
    ''' </summary>
    ''' <param name="strPSFileName">PSファイル名</param>
    ''' <param name="strSplitFileName1">分割ファイル名１</param>
    ''' <param name="strSplitFileName2">分割ファイル名２</param>
    ''' <param name="strMsg">結果文字列</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function PsSplit(ByVal strPSFileName As String, _
                            ByRef strSplitFileName1 As String, _
                            ByRef strSplitFileName2 As String, _
                            ByRef strMsg As String) As Boolean

        Dim blnRet As Boolean
        Dim PsData As PSExcelDataTable = Nothing
        Dim ew As New ExcelWrite
        Dim xlApp As New Excel.Application
        Dim xlPsBook As Excel.Workbook
        Dim xlPsSheet As Excel.Worksheet
        Dim strFileName1 As String = ""
        Dim strFileName2 As String = ""

        Dim xlBook1 As Excel.Workbook
        Dim xlSheet1 As Excel.Worksheet
        Dim xlBook2 As Excel.Workbook
        Dim xlSheet2 As Excel.Worksheet
        Dim xlBook3 As Excel.Workbook
        Dim xlSheet3 As Excel.Worksheet
        Dim PsCount1 As Long
        Dim Total1 As Long
        Dim PsCount2 As Long
        Dim Total2 As Long
        Dim PsCount3 As Long
        Dim Total3 As Long
        Dim wRet As Boolean
        Dim fDelete As Boolean  '処理後ファイル削除フラグ

        PsSplit = False
        fDelete = False

        Try
            '------------------------------------------
            'Payment読込
            '------------------------------------------
            xlApp.EnableEvents = False
            xlPsBook = xlApp.Workbooks.Open(strPSFileName)
            xlPsSheet = xlPsBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)

            'Excelのオートフィルタを初期化
            Call ew.CrearAutoFilter(xlPsSheet)

            'Payment入力チェック
            blnRet = GetPsData(strPSFileName, xlPsSheet, PsData, strMsg)
            If blnRet = False Then
                Exit Function
            End If
            If PsData.Rows.Count = 0 Then
                PsSplit = True
                Exit Function
            End If

            ExcelObjRelease.ReleaseExcelObj(xlPsSheet, ExcelObjRelease.OBJECT_NOTHING)
            xlPsBook.Close(False)
            ExcelObjRelease.ReleaseExcelObj(xlPsBook, ExcelObjRelease.OBJECT_NOTHING)

            '------------------------------------------
            'フォルダ作成、テンプレートコピー
            '------------------------------------------
            blnRet = MakeFolderFileCopy(strPSFileName, _
                                        strFileName1, _
                                        strFileName2)
            If blnRet = False Then
                Exit Function
            End If

            '------------------------------------------
            'データ編集
            '------------------------------------------
            blnRet = EditData2(strPSFileName, strFileName1, strFileName2, PsData, xlApp)
            If blnRet = False Then
                Exit Function
            End If

            '------------------------------------------
            '件数・総額確認
            '------------------------------------------
            '購入Payment件数取得
            xlBook1 = xlApp.Workbooks.Open(strFileName1)
            xlSheet1 = xlBook1.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)
            wRet = GetPsCount(xlSheet1, PsCount1, Total1)
            '保守Payment件数取得
            xlBook2 = xlApp.Workbooks.Open(strFileName2)
            xlSheet2 = xlBook2.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)
            wRet = GetPsCount(xlSheet2, PsCount2, Total2)
            '元Payment件数取得
            xlBook3 = xlApp.Workbooks.Open(strPSFileName)
            xlSheet3 = xlBook3.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)
            wRet = GetPsCount(xlSheet3, PsCount3, Total3)

            If (PsCount3 <> (PsCount1 + PsCount2)) Or _
               (Total3 <> (Total1 + Total2)) Then
                strMsg = FileReader.GetMessage("MSG_0514")
                PsSplit = False
                'EXCEL削除フラグON
                fDelete = True
            Else
                PsSplit = True
            End If

        Catch ex As Exception
            strMsg = ex.Message.ToString & "(PsSplit)"

        Finally
            'START 変更管理#3?（ExcelのEventEnable対応)　2017/01 sugo
            'xlApp.EnableEvents = True
            'END   変更管理#3?（ExcelのEventEnable対応)　2017/01 sugo
            'エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlSheet3, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBook3) = False Then
                xlBook3.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook3, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet2, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBook2) = False Then
                xlBook2.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook2, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet1, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBook1) = False Then
                xlBook1.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook1, ExcelObjRelease.OBJECT_NOTHING)

            ExcelObjRelease.ReleaseExcelObj(xlPsSheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlPsBook) = False Then
                xlPsBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlPsBook, ExcelObjRelease.OBJECT_NOTHING)
            'START 変更管理#3?（ExcelのEventEnable対応)　2017/01 sugo
            xlApp.EnableEvents = True
            'END   変更管理#3?（ExcelのEventEnable対応)　2017/01 sugo
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            '件数不一致の場合、作成ファイルは削除
            If fDelete = True Then
                System.IO.File.Delete(strFileName1)
                System.IO.File.Delete(strFileName2)
            End If

        End Try

    End Function

#End Region

#Region "Private"

#Region "共通"
    ''' <summary>
    ''' 機能：Paymentデータ取得
    ''' </summary>
    ''' <param name="strPSFileName"></param>
    ''' <param name="xlSheet"></param>
    ''' <param name="PsData"></param>
    ''' <param name="msgStr"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetPsData(ByVal strPSFileName As String,
                               ByVal xlSheet As Excel.Worksheet,
                               ByRef PsData As PSExcelDataTable, _
                               ByRef msgStr As String) As Boolean

        Dim xlRange As Excel.Range
        Dim intRowCnt As Integer
        Dim intColIndex As Integer
        Dim strWork As String

        Dim int01 As Integer = 0        '"購入"入力数
        Dim int02 As Integer = 0        '"保守"入力数
        Dim intOther As Integer = 0     '以外入力数

        GetPsData = False

        Try
            PsData = New PSExcelDataTable

            For intRowCnt = ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW To EXCEL_MAX_ROW

                xlRange = xlSheet.Range(ExcelWrite.EXCEL_PAYMENT_LINE_RANGE.Replace("@", intRowCnt.ToString))

                'EOF判定
                If ExcelWrite.changeDBNullToString(xlRange(1, ExcelWrite.ExcelPaymentLineColumn.LINE_NO).Value) = "" Then
                    Exit For
                End If

                'Paymentの値をセットする
                Dim row As DataRow
                row = PsData.NewRow

                '契約順番
                If strFileNo = "" Then
                    strFileNo = ExcelWrite.changeDBNullToString(xlRange(1, ExcelWrite.ExcelPaymentLineColumn.CONTRACT).Value)
                End If

                '契約通番
                strWork = ExcelWrite.changeDBNullToString(xlRange(1, ExcelWrite.ExcelPaymentLineColumn.CONTRACT_SEQ).Value)

                If ExcelWrite.changeDBNullToString(xlRange(1, ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG).Value) = "" Then
                    Select Case strWork
                        Case STR_BUY        '購入件数
                            int01 = int01 + 1
                        Case STR_HOSYU      '保守件数
                            int02 = int02 + 1
                        Case Else           'その他件数
                            intOther = intOther + 1
                    End Select

                    PsData.Rows.Add(row)
                End If


                ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            Next

            If int01 = 0 Then
                '購入が１件も指定されていない
                msgStr = FileReader.GetMessage("MSG_0500")
            Else
                If int02 = 0 Then
                    '保守が１件も指定されていない
                    msgStr = FileReader.GetMessage("MSG_0501")
                Else
                    If intOther > 0 Then
                        '購入・保守以外の行がある
                        msgStr = FileReader.GetMessage("MSG_0502")
                    Else
                        'チェックOK
                        GetPsData = True
                    End If
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "GetPsData")

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Function

    ''' <summary>
    ''' 機能：Payment件数、総額取得
    ''' </summary>
    ''' <param name="strPSFileName"></param>
    ''' <param name="xlSheet"></param>
    ''' <param name="PsData"></param>
    ''' <param name="msgStr"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetPsCount(ByVal xlSheet As Excel.Worksheet,
                                ByRef PsCount As Long, _
                                ByRef cTotal As Long) As Boolean

        Dim xlRange As Excel.Range
        Dim intRowCnt As Integer
        Dim lngTotal As Long = 0

        GetPsCount = False
        PsCount = 0

        Try
            For intRowCnt = ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW To EXCEL_MAX_ROW

                xlRange = xlSheet.Range(ExcelWrite.EXCEL_PAYMENT_LINE_RANGE.Replace("@", intRowCnt.ToString))

                'EOF判定
                If ExcelWrite.changeDBNullToString(xlRange(1, ExcelWrite.ExcelPaymentLineColumn.LINE_NO).Value) = "" Then
                    Exit For
                End If

                If ExcelWrite.changeDBNullToString(xlRange(1, ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG).Value) = "" Then
                    '契約順番
                    lngTotal = lngTotal + Val(ExcelWrite.changeDBNullToString(xlRange(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_TOTAL_IGF).Value))
                    '件数カウント
                    PsCount = PsCount + 1
                End If

                ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            Next

            '戻り値セット
            ''PsCount = intRowCnt - ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW
            cTotal = lngTotal
            GetPsCount = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "GetPsCount")

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Function

#End Region

#Region "作成関連"
    ''' <summary>
    ''' 機能：フォルダ作成、PSブックコピー
    ''' </summary>
    ''' <param name="strPSFileName"></param>
    ''' <param name="strFileName1"></param>
    ''' <param name="strFileName2"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function MakeFolderFileCopy(ByVal strPSFileName As String, _
                                        ByRef strFileName1 As String, _
                                        ByRef strFilename2 As String) As Boolean

        Dim strFolder As String = ""
        Dim ofm As New OioFileManage
        Dim strSourceFile As String

        MakeFolderFileCopy = False

        Try
            '-----------------------------
            'フォルダ
            '-----------------------------
            strFolder = ofm.GetLocalOutputCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            If Directory.Exists(strFolder) = False Then
                Directory.CreateDirectory(strFolder)
            End If

            '-----------------------------
            'Paymentコピー
            '-----------------------------
            strFileName1 = strFolder & CommonVariable.CPNO & "_" & Format(Val(strFileNo), "000") & "_Payment_" & Now.ToString("yyyyMMdd_HHmmss") & ".xlsm"
            strFilename2 = strFolder & CommonVariable.CPNO & "_" & Format(Val(strFileNo) + 1, "000") & "_Payment_" & Now.ToString("yyyyMMdd_HHmmss") & ".xlsm"
            strSourceFile = ofm.GetLocalSLinlkTemplatePath

            File.Copy(strPSFileName, strFileName1)
            File.Copy(strPSFileName, strFilename2)

            MakeFolderFileCopy = True

        Catch ex As Exception
            Throw ex

        End Try

    End Function

    ''' <summary>
    ''' 機能：各分割ファイル内容編集
    ''' </summary>
    ''' <param name="strFileName1">購入ファイル名</param>
    ''' <param name="strFileName2">保守ファイル名</param>
    ''' <param name="PsData"></param>
    ''' <param name="xlApp"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function EditData2(ByVal PSFileName As String, _
                               ByVal strFileName1 As String, _
                               ByVal strFileName2 As String, _
                               ByVal PsData As PSExcelDataTable,
                               ByVal xlApp As Excel.Application) As Boolean

        Dim intCnt As Integer
        Dim strRange As String
        Dim xlBook As Excel.Workbook
        Dim xlBook1 As Excel.Workbook
        Dim xlBook2 As Excel.Workbook
        Dim xlSheet As Excel.Worksheet
        Dim xlSheet1 As Excel.Worksheet
        Dim xlSheet2 As Excel.Worksheet
        Dim xlDetailSheet As Excel.Worksheet = Nothing
        Dim xlDetailSheet1 As Excel.Worksheet = Nothing
        Dim xlDetailSheet2 As Excel.Worksheet = Nothing
        Dim xlCell As Excel.Range = Nothing
        Dim xlRange As Excel.Range

        Dim sFileName As String = ""
        Dim sSuffix As String = ""
        Dim sSuffixIntr As String = ""
        Dim sSeq As String = ""
        Dim sNO As String = ""
        Dim wNO As Integer = 0

        'キー情報保存・比較
        Dim wFileName() As String = Nothing
        Dim wSuffix() As String = Nothing
        Dim wSuffixIntr() As String = Nothing
        Dim wSeq() As String = Nothing
        Dim wFileName2() As String = Nothing
        Dim wSuffix2() As String = Nothing
        Dim wSuffixIntr2() As String = Nothing
        Dim wSeq2() As String = Nothing

        Dim ii As Integer = 0
        Dim fMatch As Boolean = False
        Dim Cnt As Long = 0
        Dim Cnt11 As Long = 0
        Dim Cnt22 As Long = 0
        Dim MaxRow As Long
        Dim MaxRow2 As Long

        Dim MyArray(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12) As Object
        Dim DataTable0(,) As Object

        EditData2 = False

        Try
            '-----------------------------
            'Paymentよりデータ取得
            '-----------------------------
            xlBook = xlApp.Workbooks.Open(PSFileName)
            xlSheet = xlBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)
            xlDetailSheet = xlBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)

            '最終行取得
            MaxRow = xlSheet.Range("C5").End(Excel.XlDirection.xlDown).Row

            ReDim DataTable0(MaxRow, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12)

            For i As Integer = ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW To MaxRow
                MyArray = xlSheet.Range(ExcelWrite.EXCEL_PAYMENT_LINE_RANGE.Replace("@", i.ToString)).Formula

                ''Paymentの値を各テーブルに振り分けてセットする
                If MyArray(1, ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG) = "" Then
                    Select Case MyArray(1, ExcelWrite.ExcelPaymentLineColumn.CONTRACT_SEQ)
                        Case STR_BUY
                            '購入
                            Cnt11 = Cnt11 + 1

                            'キー情報を保存 ======
                            'ファイル名
                            ReDim Preserve wFileName(Cnt11)
                            wFileName(Cnt11) = MyArray(1, ExcelWrite.ExcelPaymentLineColumn.FILE_NAME).ToString
                            'Suffix
                            ReDim Preserve wSuffix(Cnt11)
                            wSuffix(Cnt11) = MyArray(1, ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX).ToString
                            'Suffix連番
                            ReDim Preserve wSuffixIntr(Cnt11)
                            wSuffixIntr(Cnt11) = MyArray(1, ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR).ToString
                            '契約順番
                            ReDim Preserve wSeq(Cnt11)
                            wSeq(Cnt11) = MyArray(1, ExcelWrite.ExcelPaymentLineColumn.CONTRACT).ToString

                        Case STR_HOSYU
                            '保守
                            Cnt22 = Cnt22 + 1

                            'キー情報を保存 ======
                            ReDim Preserve wFileName2(Cnt22)
                            wFileName2(Cnt22) = MyArray(1, ExcelWrite.ExcelPaymentLineColumn.FILE_NAME).ToString
                            'Suffix
                            ReDim Preserve wSuffix2(Cnt22)
                            wSuffix2(Cnt22) = MyArray(1, ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX).ToString
                            'Suffix連番
                            ReDim Preserve wSuffixIntr2(Cnt22)
                            wSuffixIntr2(Cnt22) = MyArray(1, ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR).ToString
                            '契約順番
                            ReDim Preserve wSeq2(Cnt22)
                            wSeq2(Cnt22) = MyArray(1, ExcelWrite.ExcelPaymentLineColumn.CONTRACT).ToString
                    End Select
                End If

                Cnt = Cnt + 1

                '列情報を取得
                For j As Integer = ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG To ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12
                    DataTable0(Cnt, j) = MyArray(1, j)
                Next
            Next

            '-----------------------------
            '購入用ブック編集
            '-----------------------------
            xlBook1 = xlApp.Workbooks.Open(strFileName1)
            xlSheet1 = xlBook1.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)
            xlDetailSheet1 = xlBook1.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)

            '詳細シート処理 ==========================
            '最終行取得(詳細シート)
            For ii = ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW To EXCEL_MAX_ROW
                If Trim(xlDetailSheet1.Cells(ii, ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME).value) = "" And _
                   Trim(xlDetailSheet1.Cells(ii, ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX).value) = "" And _
                   Trim(xlDetailSheet1.Cells(ii, ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR).value) = "" And _
                   Trim(xlDetailSheet1.Cells(ii, ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT).value) = "" Then
                    Exit For
                End If
                MaxRow2 = ii
            Next

            For intCnt = MaxRow2 To ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW Step -1
                'キー情報を取得 ======
                'ファイル名
                strRange = ExcelWrite.ChgExcelRowNumberToChar(ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME) & intCnt
                sFileName = xlDetailSheet1.Range(strRange).Value
                'Suffix
                strRange = ExcelWrite.ChgExcelRowNumberToChar(ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX) & intCnt
                sSuffix = xlDetailSheet1.Range(strRange).Value
                'Suffix連番
                strRange = ExcelWrite.ChgExcelRowNumberToChar(ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR) & intCnt
                sSuffixIntr = xlDetailSheet1.Range(strRange).Value
                '契約順番
                strRange = ExcelWrite.ChgExcelRowNumberToChar(ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT) & intCnt
                sSeq = xlDetailSheet1.Range(strRange).Value

                fMatch = False
                'Payment保存行とキーを比較
                For ii = 1 To Cnt11
                    If wFileName(ii) = sFileName And _
                        wSuffix(ii) = sSuffix And _
                        wSuffixIntr(ii) = sSuffixIntr And _
                        wSeq(ii) = sSeq Then
                        'キーが一致
                        fMatch = True
                        Exit For
                    End If
                Next

                If fMatch = False Then  '一致行なし
                    '詳細の行を削除
                    xlDetailSheet1.Rows(intCnt).delete()
                End If
            Next

            '保守行を削除
            For i As Integer = Cnt To 1 Step -1
                ii = i + ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW - 1

                strRange = ExcelWrite.ChgExcelRowNumberToChar(ExcelWrite.ExcelPaymentLineColumn.CONTRACT_SEQ) & ii
                If xlSheet1.Range(strRange).Value = STR_HOSYU Then
                    xlSheet1.Range(ii & ":" & ii).Delete()
                End If

                strRange = ExcelWrite.ChgExcelRowNumberToChar(ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG) & ii
                If xlSheet1.Range(strRange).Value <> "" Then
                    xlSheet1.Range(ii & ":" & ii).Delete()
                End If
            Next

            'カーソルを左上に位置付ける
            xlDetailSheet1.Activate()
            xlCell = xlDetailSheet1.Range("A1")
            xlCell.Select()
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            xlSheet1.Activate()
            xlCell = xlSheet1.Range("A1")
            xlCell.Select()
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            xlBook1.Save()


            '-----------------------------
            '保守用ブック編集
            '-----------------------------
            xlBook2 = xlApp.Workbooks.Open(strFileName2)
            xlSheet2 = xlBook2.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)
            xlDetailSheet2 = xlBook2.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)

            wNO = 1

            'Paymentの全行を貼り付け
            For i As Integer = 1 To Cnt
                ii = i + ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW - 1

                '各カラムの値をセット
                For hh As Integer = ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG To ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12
                    MyArray(1, hh) = DataTable0(i, hh)

                    '契約順番を繰り上げる
                    If hh = ExcelWrite.ExcelPaymentLineColumn.CONTRACT Then
                        MyArray(1, hh) = Format(Val(strFileNo + 1))
                    End If
                    'LINENOを更新
                    If hh = ExcelWrite.ExcelPaymentLineColumn.CONTRACT_SEQ Then
                        If DataTable0(i, ExcelWrite.ExcelPaymentLineColumn.CONTRACT_SEQ) = STR_HOSYU Then
                            MyArray(1, ExcelWrite.ExcelPaymentLineColumn.LINE_NO) = Format(Val(strFileNo + 1), "000") & Format(wNO, "00000")
                            wNO = wNO + 1
                        End If
                    End If
                Next
                strRange = ExcelWrite.ChgExcelRowNumberToChar(ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG) & ii & ":" & _
                           ExcelWrite.ChgExcelRowNumberToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12) & ii
                xlSheet2.Range(strRange).Formula = MyArray
            Next

            '詳細シート処理 ==========================
            '最終行取得(詳細シート)
            For ii = ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW To EXCEL_MAX_ROW
                If Trim(xlDetailSheet2.Cells(ii, ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME).value) = "" And _
                   Trim(xlDetailSheet2.Cells(ii, ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX).value) = "" And _
                   Trim(xlDetailSheet2.Cells(ii, ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR).value) = "" And _
                   Trim(xlDetailSheet2.Cells(ii, ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT).value) = "" Then
                    Exit For
                End If
                MaxRow2 = ii
            Next

            For intCnt = MaxRow2 To ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW Step -1
                'キー情報を取得
                'ファイル名
                strRange = ExcelWrite.ChgExcelRowNumberToChar(ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME) & intCnt
                sFileName = xlDetailSheet2.Range(strRange).Value
                'Suffix
                strRange = ExcelWrite.ChgExcelRowNumberToChar(ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX) & intCnt
                sSuffix = xlDetailSheet2.Range(strRange).Value
                'Suffix連番
                strRange = ExcelWrite.ChgExcelRowNumberToChar(ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR) & intCnt
                sSuffixIntr = xlDetailSheet2.Range(strRange).Value
                '契約順番
                strRange = ExcelWrite.ChgExcelRowNumberToChar(ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT) & intCnt
                sSeq = xlDetailSheet2.Range(strRange).Value
                '契約順番を繰り上げる
                xlDetailSheet2.Range(strRange).Value = Format(Val(strFileNo) + 1)

                fMatch = False
                'Payment保存行とキーを比較
                For ii = 1 To Cnt22
                    If wFileName2(ii) = sFileName And _
                        wSuffix2(ii) = sSuffix And _
                        wSuffixIntr2(ii) = sSuffixIntr And _
                        wSeq2(ii) = sSeq Then
                        'キーが一致
                        fMatch = True
                        Exit For
                    End If
                Next

                If fMatch = False Then  '一致行なし
                    '詳細の行を削除
                    xlDetailSheet2.Rows(intCnt).delete()
                End If
            Next

            '購入行を削除
            For i As Integer = Cnt To 1 Step -1
                ii = i + ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW - 1

                strRange = ExcelWrite.ChgExcelRowNumberToChar(ExcelWrite.ExcelPaymentLineColumn.CONTRACT_SEQ) & ii
                If xlSheet2.Range(strRange).Value = STR_BUY Then
                    xlSheet2.Range(ii & ":" & ii).Delete()
                End If

                strRange = ExcelWrite.ChgExcelRowNumberToChar(ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG) & ii
                If xlSheet2.Range(strRange).Value <> "" Then
                    xlSheet2.Range(ii & ":" & ii).Delete()
                End If
            Next

            'カーソルを左上に位置付ける
            xlDetailSheet2.Activate()
            xlCell = xlDetailSheet2.Range("A1")
            xlCell.Select()
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            xlSheet2.Activate()
            xlCell = xlSheet2.Range("A1")
            xlCell.Select()
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            xlBook2.Save()

            EditData2 = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "EditData")

        Finally
            'エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlDetailSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet1, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlDetailSheet1, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet2, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlDetailSheet2, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBook) = False Then
                xlBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)

            If IsNothing(xlBook1) = False Then
                xlBook1.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook1, ExcelObjRelease.OBJECT_NOTHING)

            If IsNothing(xlBook2) = False Then
                xlBook2.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook2, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Function
#End Region

#End Region

End Class
