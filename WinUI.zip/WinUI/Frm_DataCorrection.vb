﻿Imports System.IO
Imports System.Text
Imports System.Data.OleDb
Imports MUSE.Utility
Imports MUSE.Utility.OioBamaCommmon
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.UserDataTable.Master
Imports MUSE.Utility.UserDataTable.Transaction
Imports MUSE.Utility.XmlClass.Parameter

Public Class Frm_DataCorrection

#Region "Constract"
    '処理区分
    Public Const PROC_ZSW As Integer = 0
    Public Const PROC_IGF As Integer = 1
    '1717 str
    Public Const PROC_CONFIG As Integer = 2
    '1717 end
#End Region

#Region "Enum"
    'zSWのｶﾗﾑ位置
    Private Enum COL_ZSW
        Cheked = 0
        FileName
        ProductNo
        ProductName
        QuoteNo
        PayStart
        PayEnd
        PayMetnod
        ListPrice
        System
        Serial
        Project
        SortNo
    End Enum

    'IGFのｶﾗﾑ位置
    Private Enum COL_IGF
        NO = 0
        InstDate
        PlanNo
        PlanName
        PayStart
        PayEnd
        Pattern
        IGF
        PatternCd
    End Enum

    '1717 str
    Private Enum COL_CONFIG
        NO = 0
        FileNm
        InstDate
        PayStart
        PayEnd
    End Enum
    '1717 end

#End Region

#Region "Variable"
    Private _Proc As Integer
    Private _oioProject() As OioProject
    Private _csvFileName As String
#End Region

#Region "Propety"

    '処理区分
    Public Property Proc As Integer
        Get
            Return _Proc
        End Get
        Set(ByVal value As Integer)
            _Proc = value
        End Set
    End Property

    'OioProject
    Public Property oioProject() As OioProject()
        Get
            Return _oioProject
        End Get
        Set(ByVal value() As OioProject)
            _oioProject = value
        End Set
    End Property

#End Region

#Region ""
    Private PaymentData As PaymentLineDataSet
#End Region

#Region "Events"

    ''' <summary>
    ''' 機能：フォームロード
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Frm_DataCorrection_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try
            Me.Text = CommonVariable.OBAMATITLE

            Select Case Me.Proc
                Case PROC_ZSW
                    '----------------------------
                    '処理区分がzSWの場合
                    '----------------------------
                    '表のデザインをセットする
                    Call FormLayoutZsw()
                    'データ表示
                    Call ShowZswData()

                Case PROC_IGF
                    '----------------------------
                    '処理区分がIGFの場合
                    '----------------------------
                    btnChkAll.Visible = False
                    lblQuoteNo.Visible = False
                    txtQuoteNo.Visible = False
                    btnReflection.Visible = False
                    '表のデザインをセットする
                    Call FormLayoutIGF()
                    'データ表示
                    Call ShowIgfData()
                    '1717 str
                Case PROC_CONFIG
                    '----------------------------
                    '処理区分がzSWの場合
                    '----------------------------
                    btnChkAll.Visible = False
                    lblQuoteNo.Visible = False
                    txtQuoteNo.Visible = False
                    btnReflection.Visible = False
                    '表のデザインをセットする
                    Call FormLayoutConfig()
                    'データ表示
                    Call ShowConfigData()
                    '1717 end

            End Select

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "")

        End Try

    End Sub

    ''' <summary>
    ''' 機能：承認番号反映ボタンクリック
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnReflection_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReflection.Click

        Try
            '反映
            For Each row As DataGridViewRow In dgvConfig.Rows
                If row.Cells(COL_ZSW.QuoteNo).Selected = True Then
                    row.Cells(COL_ZSW.QuoteNo).Value = txtQuoteNo.Text.Trim
                End If
            Next

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "承認番号反映")
        End Try

    End Sub

    ''' <summary>
    ''' 機能：OKボタンクリック
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click

        Dim blnRet As Boolean

        Try
            Select Case Me.Proc
                Case PROC_ZSW
                    '----------------------------
                    '処理区分がzSWの場合
                    '----------------------------
                    blnRet = OkZsw()

                Case PROC_IGF
                    '----------------------------
                    '処理区分がIGFの場合
                    '----------------------------
                    blnRet = OkIgf()
                    '1717 str
                Case PROC_CONFIG
                    '----------------------------
                    '処理区分がCONFIGの場合
                    '----------------------------
                    blnRet = OkConfig()
                    '1717 end

            End Select
            If blnRet = False Then
                Exit Sub
            End If

            Me.DialogResult = DialogResult.OK
            Me.Hide()

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "")
        End Try

    End Sub

    ''' <summary>
    ''' 機能：Cancelボタンクリック
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click

        '削除処理
        Call DeleteTempCsv()

        Me.DialogResult = DialogResult.Cancel
        Me.Hide()

    End Sub

    ''' <summary>
    ''' 機能：全選択ボタンクリック
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnChkAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnChkAll.Click

        Dim blnCheck As Boolean = True
        Dim strText As String

        If btnChkAll.Text = "全選択" Then
            blnCheck = True
            strText = "全解除"
        Else
            blnCheck = False
            strText = "全選択"
        End If

        Call SetAllCheck(blnCheck)

        btnChkAll.Text = strText

    End Sub

#End Region

#Region "Private"

#Region "zSW関連処理"
    ''' <summary>
    ''' 機能：zSWの表のレイアウト設定
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub FormLayoutZsw()

        Try
            '表のデザインをクリア
            dgvConfig.Columns.Clear()

            'チェックボックス
            Dim colCheck As New DataGridViewCheckBoxColumn
            colCheck.HeaderText = ""
            colCheck.Width = 30
            dgvConfig.Columns.Add(colCheck)
            'フィアル名
            Dim colFile As New DataGridViewTextBoxColumn
            colFile.HeaderText = "ファイル名"
            colFile.Width = 100
            colFile.ReadOnly = True
            dgvConfig.Columns.Add(colFile)
            '製品番号
            Dim colProductNo As New DataGridViewTextBoxColumn
            colProductNo.HeaderText = "製品番号"
            colProductNo.Width = 80
            colProductNo.ReadOnly = True
            dgvConfig.Columns.Add(colProductNo)
            '製品名
            Dim colProductName As New DataGridViewTextBoxColumn
            colProductName.HeaderText = "製品名"
            colProductName.Width = 200
            colProductName.ReadOnly = True
            dgvConfig.Columns.Add(colProductName)
            '承認番号
            Dim colQuoteNo As New DataGridViewTextBoxColumn
            colQuoteNo.HeaderText = "承認番号"
            colQuoteNo.Width = 80
            colQuoteNo.MaxInputLength = 180

            dgvConfig.Columns.Add(colQuoteNo)
            '請求開始年月
            Dim colPayStart As New CalendarColumn()
            colPayStart.HeaderText = "請求開始年月"
            colPayStart.Width = 110
            dgvConfig.Columns.Add(colPayStart)
            '請求終了年月
            Dim colPayEnd As New CalendarColumn()
            colPayEnd.HeaderText = "請求終了年月"
            colPayEnd.Width = 110
            dgvConfig.Columns.Add(colPayEnd)
            '支払方法
            Dim colPayMetod As New DataGridViewComboBoxColumn
            colPayMetod.HeaderText = "支払方法"
            colPayMetod.Width = 60
            colPayMetod.Items.Add("月額")
            colPayMetod.Items.Add("年額")
            colPayMetod.Items.Add("一括")
            dgvConfig.Columns.Add(colPayMetod)
            'ListPrice
            Dim colListPrice As New DataGridViewTextBoxColumn
            colListPrice.HeaderText = "ListPrice"
            colListPrice.Width = 80
            colListPrice.Name = "colListPrice"
            dgvConfig.Columns.Add(colListPrice)
            dgvConfig.Columns("colListPrice").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            'SYSTEM
            Dim colSystem As New DataGridViewTextBoxColumn
            colSystem.HeaderText = "SYSTEM"
            colSystem.Width = 100
            colSystem.ReadOnly = True
            dgvConfig.Columns.Add(colSystem)
            'SERIAL
            Dim colSerial As New DataGridViewTextBoxColumn
            colSerial.HeaderText = "ｼﾘｱﾙ"
            colSerial.Width = 100
            colSerial.ReadOnly = True
            dgvConfig.Columns.Add(colSerial)
            'Project
            Dim colProject As New DataGridViewTextBoxColumn
            colProject.HeaderText = "Project"
            colProject.Width = 100
            colProject.ReadOnly = True
            dgvConfig.Columns.Add(colProject)
            dgvConfig.Columns(COL_ZSW.Project).Visible = False
            'RecordNo
            Dim colRecordNo As New DataGridViewTextBoxColumn
            colRecordNo.HeaderText = "SortNo"
            colRecordNo.Width = 100
            colRecordNo.ReadOnly = True
            dgvConfig.Columns.Add(colRecordNo)
            dgvConfig.Columns(COL_ZSW.SortNo).Visible = False

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' 機能：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub ShowZswData()

        Dim strSystem As String = ""
        Dim strSerial As String = ""
        Dim strFileName As String = ""
        Dim strProductNo As String = ""
        Dim strProductName As String = ""
        Dim strPayMethod As String = ""
        Dim lngOrderPrice As Long = 0
        Dim lngBasePrice As Long = 0
        Dim lngProposedPrice As Long = 0
        Dim lngListPrice As Long = 0
        Dim strFilter As String = ""
        Dim strSort As String
        Dim dtPayStart As Date
        Dim dtPayEnd As Date
        Dim strSortNo As String
        Dim blnFistData As Boolean = True
        Dim blnOutDataFlg As Boolean = False
        Dim lngTotalListPrice As Long = 0

        Try
            dgvConfig.Rows.Clear()

            For intPro As Integer = 0 To (Me.oioProject.Length - 1)
                strSystem = ""
                strSerial = ""
                strFileName = ""
                strProductNo = ""
                strProductName = ""
                strPayMethod = ""
                dtPayStart = Date.Parse(Me.oioProject(intPro).PayStartTime)
                dtPayEnd = Date.Parse(Me.oioProject(intPro).PayEndTime)
                strSortNo = ""

                strSort = Zsw_ProductTable.COLUMN_NAME_FILE_NAME & "," &
                          Zsw_ProductTable.COLUMN_NAME_SYSTEM & "," &
                          Zsw_ProductTable.COLUMN_NAME_PRODCT_NO & "," &
                          Zsw_ProductTable.COLUMN_NAME_PRODCT_NAME & "," &
                          Zsw_ProductTable.COLUMN_NAME_SERIAL & "," &
                          Zsw_ProductTable.COLUMN_NAME_PAY_METHOD

                Debug.Print("ﾌｧｲﾙ名," &
                            "製品番号," &
                            "製品名," &
                            "支払方法," &
                            "OrderPrice," &
                            "BasePrice," &
                            "ProposedPrice," &
                            "SYSTEM," &
                            "ｼﾘｱﾙ")

                '------------------------------------------------------
                '(Order：あり、Base：あり)　or (Orderあり：、Base:なし)
                '------------------------------------------------------
                strFilter = Zsw_ProductTable.COLUMN_NAME_SYSTEM_KIND & "='" & Zsw_ProductTable.CD_SYSTEM_KIND_ORDER & "'" &
                            " and " & Zsw_ProductTable.COLUMN_NAME_OUT_FLG & "=''"
                For Each row As DataRow In oioProject(intPro).zswData.Select(strFilter, strSort)
                    With row
                        Debug.Print(.Item(Zsw_ProductTable.COLUMN_NAME_FILE_NAME) & "," &
                                    .Item(Zsw_ProductTable.COLUMN_NAME_PRODCT_NO) & "," &
                                    .Item(Zsw_ProductTable.COLUMN_NAME_PRODCT_NAME) & "," &
                                    .Item(Zsw_ProductTable.COLUMN_NAME_PAY_METHOD) & "," &
                                    .Item(Zsw_ProductTable.COLUMN_NAME_ORDERPRICE) & "," &
                                    .Item(Zsw_ProductTable.COLUMN_NAME_BASEPRICE) & "," &
                                    .Item(Zsw_ProductTable.COLUMN_NAME_PROPOSEDPRICE) & "," &
                                    .Item(Zsw_ProductTable.COLUMN_NAME_SYSTEM) & "," &
                                    .Item(Zsw_ProductTable.COLUMN_NAME_SERIAL)
                                    )

                        '同一キーのBaseが存在するかﾁｪｯｸ
                        strFileName = .Item(Zsw_ProductTable.COLUMN_NAME_FILE_NAME)
                        strProductNo = .Item(Zsw_ProductTable.COLUMN_NAME_PRODCT_NO)
                        strProductName = .Item(Zsw_ProductTable.COLUMN_NAME_PRODCT_NAME)
                        strPayMethod = .Item(Zsw_ProductTable.COLUMN_NAME_PAY_METHOD)
                        strSystem = .Item(Zsw_ProductTable.COLUMN_NAME_SYSTEM)
                        strSerial = .Item(Zsw_ProductTable.COLUMN_NAME_SERIAL)
                        strSerial = strSerial.Replace(":", "")

                        Dim rowBase() As DataRow
                        Dim strFilterBase As String
                        strFilterBase = Zsw_ProductTable.COLUMN_NAME_SYSTEM_KIND & "='" & Zsw_ProductTable.CD_SYSTEM_KIND_BASE & "'" &
                                        " and " & Zsw_ProductTable.COLUMN_NAME_FILE_NAME & "='" & strFileName & "'" &
                                        " and " & Zsw_ProductTable.COLUMN_NAME_PRODCT_NO & "='" & strProductNo & "'" &
                                        " and " & Zsw_ProductTable.COLUMN_NAME_PRODCT_NAME & "='" & strProductName & "'" &
                                        " and " & Zsw_ProductTable.COLUMN_NAME_PAY_METHOD & "='" & strPayMethod & "'" &
                                        " and " & Zsw_ProductTable.COLUMN_NAME_SYSTEM & "='" & strSystem & "'" &
                                        " and " & Zsw_ProductTable.COLUMN_NAME_SERIAL & "='" & strSerial & "'" &
                                        " and " & Zsw_ProductTable.COLUMN_NAME_OUT_FLG & "=''"
                        rowBase = oioProject(intPro).zswData.Select(strFilterBase)
                        lngListPrice = 0
                        If rowBase.Length > 0 Then
                            '同一キーが存在する場合
                            If strPayMethod = "一括" Then
                                '一括の場合、Oder TransactionのOrderPriceをセットする
                                lngListPrice = Long.Parse(ExcelWrite.changeDBNullToZero(.Item(Zsw_ProductTable.COLUMN_NAME_ORDERPRICE)))
                                strSortNo = intPro.ToString.PadLeft(5, "0") & .Item(Zsw_ProductTable.COLUMN_NAME_RECORD_NO).ToString.PadLeft(5, "0")
                            Else
                                '一括以外の場合、Base TransactionのProposedPriceをセットする
                                lngBasePrice = Long.Parse(rowBase(0)(Zsw_ProductTable.COLUMN_NAME_BASEPRICE))
                                lngProposedPrice = Long.Parse(rowBase(0)(Zsw_ProductTable.COLUMN_NAME_PROPOSEDPRICE))
                                If oioProject(intPro).zSW_NoChange = CommonConstant.ParamzSwType.CheckOFF Then
                                    If lngBasePrice <> lngProposedPrice Then
                                        lngListPrice = lngProposedPrice
                                        strSortNo = intPro.ToString.PadLeft(5, "0") & rowBase(0)(Zsw_ProductTable.COLUMN_NAME_RECORD_NO).ToString.PadLeft(5, "0")
                                    End If
                                Else
                                    lngListPrice = lngProposedPrice
                                    strSortNo = intPro.ToString.PadLeft(5, "0") & rowBase(0)(Zsw_ProductTable.COLUMN_NAME_RECORD_NO).ToString.PadLeft(5, "0")
                                End If
                                '1471 修正 end
                            End If
                            rowBase(0)(Zsw_ProductTable.COLUMN_NAME_OUT_FLG) = Zsw_ProductTable.CD_OUT_FLG_ON
                        Else
                            '同一キーが存在しない場合
                            lngListPrice = Long.Parse(.Item(Zsw_ProductTable.COLUMN_NAME_ORDERPRICE))
                            .Item(Zsw_ProductTable.COLUMN_NAME_OUT_FLG) = Zsw_ProductTable.CD_OUT_FLG_ON
                            strSortNo = intPro.ToString.PadLeft(5, "0") & .Item(Zsw_ProductTable.COLUMN_NAME_RECORD_NO).ToString.PadLeft(5, "0")
                        End If

                        If lngListPrice <> 0 Then
                            If strPayMethod = "一括" Then
                                dtPayEnd = dtPayStart
                            Else
                                dtPayEnd = Date.Parse(Me.oioProject(intPro).PayEndTime)
                            End If
                            dgvConfig.Rows.Add(
                                        True,
                                        strFileName,
                                        strProductNo,
                                        strProductName,
                                        "",
                                        dtPayStart,
                                        dtPayEnd,
                                        strPayMethod,
                                        lngListPrice.ToString,
                                        strSystem,
                                        strSerial,
                                        intPro,
                                        strSortNo)
                        End If
                    End With
                Next

                '------------------------------------------------------
                'Order：なし、Base：あり
                '------------------------------------------------------
                strSystem = ""
                strSerial = ""
                strFileName = ""
                strProductNo = ""
                strProductName = ""
                strPayMethod = ""
                strSortNo = ""
                lngListPrice = 0
                lngTotalListPrice = 0
                blnFistData = True
                blnOutDataFlg = False
                strFilter = Zsw_ProductTable.COLUMN_NAME_SYSTEM_KIND & "='" & Zsw_ProductTable.CD_SYSTEM_KIND_BASE & "'" &
                            " and " & Zsw_ProductTable.COLUMN_NAME_PROPOSEDPRICE & "<>'0'" &
                            " and " & Zsw_ProductTable.COLUMN_NAME_OUT_FLG & "=''"
                For Each row As DataRow In oioProject(intPro).zswData.Select(strFilter, strSort)
                    With row
                        If oioProject(intPro).zSW_NoChange = CommonConstant.ParamzSwType.CheckON Then
                            Debug.Print(.Item(Zsw_ProductTable.COLUMN_NAME_FILE_NAME) & "," &
                                        .Item(Zsw_ProductTable.COLUMN_NAME_PRODCT_NO) & "," &
                                        .Item(Zsw_ProductTable.COLUMN_NAME_PRODCT_NAME) & "," &
                                        .Item(Zsw_ProductTable.COLUMN_NAME_PAY_METHOD) & "," &
                                        .Item(Zsw_ProductTable.COLUMN_NAME_ORDERPRICE) & "," &
                                        .Item(Zsw_ProductTable.COLUMN_NAME_BASEPRICE) & "," &
                                        .Item(Zsw_ProductTable.COLUMN_NAME_PROPOSEDPRICE) & "," &
                                        .Item(Zsw_ProductTable.COLUMN_NAME_SYSTEM) & "," &
                                        .Item(Zsw_ProductTable.COLUMN_NAME_SERIAL)
                                        )

                            If blnFistData = False Then
                                '同一キー(空白以外のシリアル)の場合、ListPriceを合算する
                                If strSystem = .Item(Zsw_ProductTable.COLUMN_NAME_SYSTEM) And
                                    strFileName = .Item(Zsw_ProductTable.COLUMN_NAME_FILE_NAME) And
                                    strProductNo = .Item(Zsw_ProductTable.COLUMN_NAME_PRODCT_NO) And
                                    strProductName = .Item(Zsw_ProductTable.COLUMN_NAME_PRODCT_NAME) And
                                    strPayMethod = .Item(Zsw_ProductTable.COLUMN_NAME_PAY_METHOD) And
                                    strSerial <> "" And
                                    strSerial = .Item(Zsw_ProductTable.COLUMN_NAME_SERIAL) Then
                                    lngListPrice = lngListPrice + Long.Parse(.Item(Zsw_ProductTable.COLUMN_NAME_PROPOSEDPRICE))
                                    .Item(Zsw_ProductTable.COLUMN_NAME_OUT_FLG) = Zsw_ProductTable.CD_OUT_FLG_ON
                                Else
                                    If strPayMethod = "一括" Then
                                        dtPayEnd = dtPayStart
                                    Else
                                        dtPayEnd = Date.Parse(Me.oioProject(intPro).PayEndTime)
                                    End If
                                    dgvConfig.Rows.Add(
                                                True,
                                                strFileName,
                                                strProductNo,
                                                strProductName,
                                                "",
                                                dtPayStart,
                                                dtPayEnd,
                                                strPayMethod,
                                                lngListPrice.ToString,
                                                strSystem,
                                                strSerial,
                                                intPro,
                                                strSortNo)
                                    blnOutDataFlg = False
                                    lngListPrice = Long.Parse(.Item(Zsw_ProductTable.COLUMN_NAME_PROPOSEDPRICE))
                                End If
                            Else
                                lngListPrice = Long.Parse(.Item(Zsw_ProductTable.COLUMN_NAME_PROPOSEDPRICE))
                            End If
                            strFileName = .Item(Zsw_ProductTable.COLUMN_NAME_FILE_NAME)
                            strProductNo = .Item(Zsw_ProductTable.COLUMN_NAME_PRODCT_NO)
                            strProductName = .Item(Zsw_ProductTable.COLUMN_NAME_PRODCT_NAME)
                            strPayMethod = .Item(Zsw_ProductTable.COLUMN_NAME_PAY_METHOD)
                            strSystem = .Item(Zsw_ProductTable.COLUMN_NAME_SYSTEM)
                            strSerial = .Item(Zsw_ProductTable.COLUMN_NAME_SERIAL)
                            strSerial = strSerial.Replace(":", "")
                            strSortNo = intPro.ToString.PadLeft(5, "0") & .Item(Zsw_ProductTable.COLUMN_NAME_RECORD_NO).ToString.PadLeft(5, "0")
                            .Item(Zsw_ProductTable.COLUMN_NAME_OUT_FLG) = Zsw_ProductTable.CD_OUT_FLG_ON
                            blnFistData = False
                            blnOutDataFlg = True
                        End If
                    End With
                Next
                If blnOutDataFlg = True Then
                    If strPayMethod = "一括" Then
                        dtPayEnd = dtPayStart
                    Else
                        dtPayEnd = Date.Parse(Me.oioProject(intPro).PayEndTime)
                    End If
                    dgvConfig.Rows.Add(
                                True,
                                strFileName,
                                strProductNo,
                                strProductName,
                                "",
                                dtPayStart,
                                dtPayEnd,
                                strPayMethod,
                                lngListPrice.ToString,
                                strSystem,
                                strSerial,
                                intPro,
                                strSortNo)
                End If
            Next

            'ﾚｺｰﾄﾞNOでｿｰﾄする
            dgvConfig.Sort(dgvConfig.Columns(COL_ZSW.SortNo), System.ComponentModel.ListSortDirection.Ascending)

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' 機能：zSWのOKボタン処理
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function OkZsw() As Boolean

        Dim blnRet As Boolean
        Dim intPro As Integer

        OkZsw = False

        Try
            '入力チェック
            blnRet = CheckInputZSW()
            If blnRet = False Then
                Exit Function
            End If

            'PaymentZswTableに反映
            For Each dgvRow As DataGridViewRow In dgvConfig.Rows
                If dgvRow.Cells(COL_ZSW.Cheked).Value = True Then
                    intPro = dgvRow.Cells(COL_ZSW.Project).Value
                    Dim row As DataRow
                    row = Me.oioProject(intPro).PaymentZswData.NewRow
                    row.Item(PaymentLineZswTable.COLUMN_NAME_FILE_NAME) = dgvRow.Cells(COL_ZSW.FileName).Value
                    row.Item(PaymentLineZswTable.COLUMN_NAME_PRODCT_NO) = dgvRow.Cells(COL_ZSW.ProductNo).Value
                    row.Item(PaymentLineZswTable.COLUMN_NAME_PRODCT_NAME) = dgvRow.Cells(COL_ZSW.ProductName).Value
                    row.Item(PaymentLineZswTable.COLUMN_NAME_QUOTE_NO) = dgvRow.Cells(COL_ZSW.QuoteNo).Value
                    row.Item(PaymentLineZswTable.COLUMN_NAME_PAY_START) = dgvRow.Cells(COL_ZSW.PayStart).Value
                    row.Item(PaymentLineZswTable.COLUMN_NAME_PAY_END) = dgvRow.Cells(COL_ZSW.PayEnd).Value
                    row.Item(PaymentLineZswTable.COLUMN_NAME_PAY_METHOD) = dgvRow.Cells(COL_ZSW.PayMetnod).Value
                    row.Item(PaymentLineZswTable.COLUMN_NAME_LISTPRICE) = dgvRow.Cells(COL_ZSW.ListPrice).Value
                    Me.oioProject(intPro).PaymentZswData.Rows.Add(row)
                End If
            Next

            OkZsw = True

        Catch ex As Exception
            Throw ex

        End Try

    End Function

    ''' <summary>
    ''' 機能：zSWの入力チェック
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckInputZSW() As Boolean

        Dim blnCheked As Boolean
        Dim blnErrPayTerm As Boolean
        Dim blnErrListPrice As Boolean
        Dim dgvRow As DataGridViewRow
        Dim strErrMsg As String = ""

        CheckInputZSW = False

        Try
            '背景色初期化
            For Each dgvRow In dgvConfig.Rows
                For intColCnt As Integer = COL_ZSW.Cheked To COL_ZSW.Serial
                    dgvRow.Cells(intColCnt).Style.BackColor = SystemColors.Window
                Next
            Next

            'エラー箇所を背景色黄色で表示
            blnCheked = False
            blnErrPayTerm = False
            blnErrListPrice = False
            For Each dgvRow In dgvConfig.Rows
                If dgvRow.Cells(COL_ZSW.Cheked).Value = True Then
                    '請求開始終了日の逆転チェック
                    If dgvRow.Cells(COL_ZSW.PayStart).Value > dgvRow.Cells(COL_ZSW.PayEnd).Value Then
                        dgvRow.Cells(COL_ZSW.PayStart).Style.BackColor = Color.Yellow
                        dgvRow.Cells(COL_ZSW.PayEnd).Style.BackColor = Color.Yellow
                        blnErrPayTerm = True
                    End If

                    'ListPriceの数値チェック
                    If IsNumeric(dgvRow.Cells(COL_ZSW.ListPrice).Value) = False Then
                        dgvRow.Cells(COL_ZSW.ListPrice).Style.BackColor = Color.Yellow
                        blnErrListPrice = True
                    End If

                    '１つでもチェック有
                    blnCheked = True
                End If
            Next

            '全チェックなし
            If blnCheked = False Then
                For Each dgvRow In dgvConfig.Rows
                    dgvRow.Cells(COL_ZSW.Cheked).Style.BackColor = Color.Yellow
                Next
                strErrMsg = "チェックボックス、"
            End If
            If blnErrPayTerm = True Then
                strErrMsg = strErrMsg & "請求期間、"
            End If
            If blnErrListPrice = True Then
                strErrMsg = strErrMsg & "ListPrice、"
            End If
            If strErrMsg <> "" Then
                strErrMsg = strErrMsg.Substring(0, strErrMsg.Length - 1) & "が入力エラーです。"
                MsgBox(strErrMsg, MsgBoxStyle.Critical, "入力チェック")
                Exit Function
            End If

            CheckInputZSW = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "CheckInputZSW")

        End Try

    End Function

#End Region

#Region "IGF関連処理"
    ''' <summary>
    ''' 機能：IGFの表のレイアウト設定
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub FormLayoutIGF()

        Try
            '表のデザインをクリア
            dgvConfig.Columns.Clear()

            'NO
            Dim colNO As New DataGridViewTextBoxColumn
            colNO.HeaderText = "NO"
            colNO.Width = 40
            colNO.ReadOnly = True
            dgvConfig.Columns.Add(colNO)
            '導入年月
            Dim colInst As New DataGridViewTextBoxColumn
            colInst.HeaderText = "導入年月"
            '列幅変更 str
            'colInst.Width = 110
            colInst.Width = 80
            '列幅変更 end
            colInst.ReadOnly = True
            dgvConfig.Columns.Add(colInst)
            '案件番号
            Dim colPlanNo As New DataGridViewTextBoxColumn
            colPlanNo.HeaderText = "案件番号"
            '列幅変更 str
            'colPlanNo.Width = 100
            colPlanNo.Width = 80
            '列幅変更 end
            colPlanNo.ReadOnly = True
            dgvConfig.Columns.Add(colPlanNo)
            '案件名
            Dim colPlanName As New DataGridViewTextBoxColumn
            colPlanName.HeaderText = "案件名"
            '列幅変更 str
            'colPlanName.Width = 150
            colPlanName.Width = 180
            '列幅変更 end
            colPlanName.ReadOnly = True
            dgvConfig.Columns.Add(colPlanName)
            '請求開始年月
            Dim colPayStart As New DataGridViewTextBoxColumn
            colPayStart.HeaderText = "請求開始年月"
            colPayStart.Width = 110
            colPayStart.ReadOnly = True
            dgvConfig.Columns.Add(colPayStart)
            '請求終了年月
            Dim colPayEnd As New DataGridViewTextBoxColumn
            colPayEnd.HeaderText = "請求終了年月"
            colPayEnd.Width = 110
            colPayEnd.ReadOnly = True
            dgvConfig.Columns.Add(colPayEnd)
            'データ種類
            Dim colPattern As New DataGridViewTextBoxColumn
            colPattern.HeaderText = "データ種類"
            '列幅変更 str
            'colPattern.Width = 100
            colPattern.Width = 200
            '列幅変更 end
            colPattern.ReadOnly = True
            dgvConfig.Columns.Add(colPattern)
            'IGF対象
            Dim colIGF As New DataGridViewCheckBoxColumn
            colIGF.HeaderText = "IGF対象"
            colIGF.Width = 60
            dgvConfig.Columns.Add(colIGF)
            'データ種類
            Dim colPatternCd As New DataGridViewTextBoxColumn
            colPatternCd.HeaderText = "ﾊﾟﾀｰﾝNO"
            colPatternCd.Width = 100
            dgvConfig.Columns.Add(colPatternCd)
            dgvConfig.Columns(COL_IGF.PatternCd).Visible = False

        Catch ex As Exception
            Throw New Exception(ex.Message.ToString & "(FormLayoutIGF)")
        End Try

    End Sub

    ''' <summary>
    ''' 機能：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub ShowIgfData()

        Dim oe As New OutputExcel
        Dim strLine As String
        Dim strSplitData() As String
        Dim blnRet As Boolean
        Dim sr As StreamReader
        Dim strWork As String
        Dim intRow As Integer = 1
        Dim strSort As String

        Dim strPrjSeq As String = ""
        Dim strPatternCd As String = ""
        Dim strBrand As String = ""
        Dim strPlanNo As String
        Dim strPlanName As String
        Dim strInstDate As String
        Dim strPayStartDate As String
        Dim strPayEndDate As String
        Dim strDataKind As String

        Dim strPrevPrjSeq As String = ""
        Dim strPrevPatternCd As String = ""
        Dim strPrevBrand As String = ""

        Dim ofm As New OioFileManage
        Dim strPath As String
        Dim strCsvFileName() As String
        Dim PlanData As M_PLANTable

        Try
            PaymentData = New PaymentLineDataSet

            strPath = ofm.GetLocalOutputCsvTempCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            strCsvFileName = System.IO.Directory.GetFiles(strPath, "PS_" & "*" & ".csv", System.IO.SearchOption.TopDirectoryOnly)

            sr = New StreamReader(strCsvFileName(0), Encoding.GetEncoding("shift-jis"))
            While (sr.Peek() >= 0)
                strLine = sr.ReadLine

                'カンマ区切りのデータを分解する
                blnRet = oe.SplitData(strLine, strSplitData)
                If blnRet = False Then
                    Exit Sub
                End If

                ''データのセット
                Call SetPaymentData(strSplitData, intRow, PaymentData)

                intRow = intRow + 1
            End While
            sr.Close()

            '案件情報テーブル取得
            PlanData = GetPlanTable()

            strSort = PaymentLineDataSet.COLUMN_NAME_PROJECT_SEQ & "," &
                      PaymentLineDataSet.COLUMN_NAME_PATTERN_CD & "," &
                      PaymentLineDataSet.COLUMN_NAME_BRAND
            For Each row As DataRow In PaymentData.Select("", strSort)

                strPrjSeq = ExcelWrite.changeDBNullToString(row(PaymentLineDataSet.COLUMN_NAME_PROJECT_SEQ))
                strPatternCd = row(PaymentLineDataSet.COLUMN_NAME_PATTERN_CD)
                strBrand = ExcelWrite.changeDBNullToString(row(PaymentLineDataSet.COLUMN_NAME_BRAND))
                strPlanNo = ExcelWrite.changeDBNullToString(row(PaymentLineDataSet.COLUMN_NAME_PROJ_ID))
                strPlanName = GetPlanName(PlanData, strPlanNo)
                strInstDate = row(PaymentLineDataSet.COLUMN_NAME_INST_YEAR) & "年" & row(PaymentLineDataSet.COLUMN_NAME_INST_MONTH) & "月"
                If IsDate(strInstDate) = False Then
                    strInstDate = ""
                End If
                strPayStartDate = row(PaymentLineDataSet.COLUMN_NAME_PAY_START_YEAR) & "年" & row(PaymentLineDataSet.COLUMN_NAME_PAY_START_MONTH) & "月"
                If IsDate(strPayStartDate) = False Then
                    strPayStartDate = ""
                End If
                strPayEndDate = row(PaymentLineDataSet.COLUMN_NAME_PAY_END_YEAR) & "年" & row(PaymentLineDataSet.COLUMN_NAME_PAY_END_MONTH) & "月"
                If IsDate(strPayEndDate) = False Then
                    strPayEndDate = ""
                End If
                If strPatternCd = "11" Then
                    strDataKind = row(PaymentLineDataSet.COLUMN_NAME_BRAND)
                Else
                    strDataKind = row(PaymentLineDataSet.COLUMN_NAME_PATTERN)
                End If

                If strPrjSeq <> strPrevPrjSeq Or
                    strPatternCd <> strPrevPatternCd Or
                    strBrand <> strPrevBrand Then

                    dgvConfig.Rows.Add(
                                strPrjSeq,
                                strInstDate,
                                strPlanNo,
                                strPlanName,
                                strPayStartDate,
                                strPayEndDate,
                                strDataKind,
                                False,
                                strPatternCd)

                    strPrevPrjSeq = strPrjSeq
                    strPrevPatternCd = strPatternCd
                    strPrevBrand = strBrand
                End If
            Next

        Catch ex As Exception
            Throw New Exception(ex.Message.ToString & "(ShowIgfData)")

        End Try


    End Sub

    ''' <summary>
    ''' 機能：案件情報テーブル取得
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetPlanTable() As M_PLANTable


        Dim dt As New M_PLANTable
        Dim wc As New WebDb.WebDbCommon
        Dim blnRet As Boolean
        Dim strMsg As String

        Try
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW
            blnRet = wc.GetPlanData(CommonVariable.CPNO, dt, strMsg)
            If blnRet = False Then
                Throw New Exception(strMsg)
                Exit Function
            End If

            GetPlanTable = dt

        Catch ex As Exception
            Throw ex
        End Try

    End Function

    ''' <summary>
    ''' 機能：案件名取得
    ''' </summary>
    ''' <param name="PlanData"></param>
    ''' <param name="strPlanNo"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetPlanName(ByVal PlanData As M_PLANTable, ByVal strPlanNo As String) As String

        Dim strFilter As String
        Dim strLevelNo() As String
        Dim rows() As DataRow

        GetPlanName = ""

        Try
            strLevelNo = strPlanNo.Split(".")
            If strLevelNo.Length = 4 Then
                strFilter = "level1='" & strLevelNo(0) & "' and level2='" & strLevelNo(1) & "' and level3='" & strLevelNo(2) & "' and level4='" & strLevelNo(3) & "'"
                rows = PlanData.Select(strFilter)
                If rows.Length > 0 Then
                    GetPlanName = rows(0).Item(M_PLANTable.COLUMN_NAME_PLAN_NAME).ToString
                End If
            End If

        Catch ex As Exception
            Throw ex
        End Try

    End Function

    ''' <summary>
    ''' 機能：PaymnetのCSVﾃﾞｰﾀをDataTableにｾｯﾄする
    ''' </summary>
    ''' <param name="strSplitData"></param>
    ''' <param name="intRow"></param>
    ''' <param name="PaymentData"></param>
    ''' <remarks></remarks>
    Private Sub SetPaymentData(ByVal strSplitData() As String, ByVal intRow As Integer, ByRef PaymentData As PaymentLineDataSet)

        Dim strWork As String
        Dim row As DataRow

        Try
            row = PaymentData.NewRow

            '更新FLG
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG, strSplitData, PaymentLineDataSet.COLUMN_NAME_UPDATE_FLAG, row)
            'ﾛｯｸFLG
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG, strSplitData, PaymentLineDataSet.COLUMN_NAME_LOCK_FLAG, row)
            '有効/無効
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG, strSplitData, PaymentLineDataSet.COLUMN_NAME_VALID_FLAG, row)
            'NO
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.LINE_NO, strSplitData, PaymentLineDataSet.COLUMN_NAME_LINE_NO, row)
            'ﾌｧｲﾙ名
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.FILE_NAME, strSplitData, PaymentLineDataSet.COLUMN_NAME_FILE_NAME, row)
            'ﾌｧｲﾙ名Suffix
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX, strSplitData, PaymentLineDataSet.COLUMN_NAME_FILE_NAME_SUFFIX, row)
            'ﾌｧｲﾙ内Suffix
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR, strSplitData, PaymentLineDataSet.COLUMN_NAME_FILE_NAME_SUFFIX_INTR, row)
            '契約順番
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.CONTRACT, strSplitData, PaymentLineDataSet.COLUMN_NAME_CONTRACT, row)
            'COST開示
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.ST_COST, strSplitData, PaymentLineDataSet.COLUMN_NAME_ST_COST, row)
            'ｻﾏﾘｰ表示制御
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.ST_APPROVAL, strSplitData, PaymentLineDataSet.COLUMN_NAME_ST_APPROVAL, row)
            '案件番号
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PROJ_ID, strSplitData, PaymentLineDataSet.COLUMN_NAME_PROJ_ID, row)
            '契約通番
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.CONTRACT_SEQ, strSplitData, PaymentLineDataSet.COLUMN_NAME_CONTRACT_SEQ, row)
            '保守種別
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.NEW_EXIST, strSplitData, PaymentLineDataSet.COLUMN_NAME_NEW_EXIST, row)
            'お客様集計ｶﾃｺﾞﾘ
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.CUST_CATEGORY, strSplitData, PaymentLineDataSet.COLUMN_NAME_CUST_CATEGORY, row)
            '実行通知書_発行予定日
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.LETTER_PLAN_DATE, strSplitData, PaymentLineDataSet.COLUMN_NAME_LETTER_PLAN_DATE, row)
            '実行通知書_受領日
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.LETTER_ACCEPT_DATE, strSplitData, PaymentLineDataSet.COLUMN_NAME_LETTER_ACCEPT_DATE, row)
            '発注完了日
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.ORDER_DATE, strSplitData, PaymentLineDataSet.COLUMN_NAME_ORDER_DATE, row)
            '通知書番号
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.LETTER_ID, strSplitData, PaymentLineDataSet.COLUMN_NAME_LETTER_ID, row)
            '請求ｲﾆｼｬﾙ
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.ORDERCODE, strSplitData, PaymentLineDataSet.COLUMN_NAME_ORDERCODE, row)
            'Brand Category_BU
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.BU, strSplitData, PaymentLineDataSet.COLUMN_NAME_BU, row)
            'Brand Category_Brand
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.BRAND, strSplitData, PaymentLineDataSet.COLUMN_NAME_BRAND, row)
            'Brand Category_ｻﾏﾘｰ用ｶﾃｺﾞﾘ
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.SUM_CATEGORY, strSplitData, PaymentLineDataSet.COLUMN_NAME_SUM_CATEGORY, row)
            'Brand Category_SubBrand
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.BRAND_SUB, strSplitData, PaymentLineDataSet.COLUMN_NAME_BRAND_SUB, row)
            'Brand 特殊FC種別
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.OP1, strSplitData, PaymentLineDataSet.COLUMN_NAME_OP1, row)
            'Brand Category Option
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.OP2, strSplitData, PaymentLineDataSet.COLUMN_NAME_OP2, row)
            'Brand Category_製品Group
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.BRAND_SIZE, strSplitData, PaymentLineDataSet.COLUMN_NAME_BRAND_SIZE, row)
            'Brand Category_SBO制限
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.NON_SBO, strSplitData, PaymentLineDataSet.COLUMN_NAME_NON_SBO, row)
            'Brand Category_追記事項
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.POSTSCRIPT, strSplitData, PaymentLineDataSet.COLUMN_NAME_POSTSCRIPT, row)
            'Brand承認_TOPACS CPNO
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.TOPACS_CPNO, strSplitData, PaymentLineDataSet.COLUMN_NAME_TOPACS_CPNO, row)
            'Brand承認_起票番号
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_FORM, strSplitData, PaymentLineDataSet.COLUMN_NAME_BRAND_AP_FORM, row)
            'Brand承認_申請番号
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_REQ, strSplitData, PaymentLineDataSet.COLUMN_NAME_BRAND_AP_REQ, row)
            'Brand承認_承認番号
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_CONF, strSplitData, PaymentLineDataSet.COLUMN_NAME_BRAND_AP_CONF, row)
            '入力項目ﾊﾟﾀｰﾝ SEQ
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD, strSplitData, PaymentLineDataSet.COLUMN_NAME_PATTERN_CD, row)
            '入力項目ﾊﾟﾀｰﾝ
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PATTERN, strSplitData, PaymentLineDataSet.COLUMN_NAME_PATTERN, row)
            'ﾊﾟﾀｰﾝ別入力項目_項目１
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01, strSplitData, PaymentLineDataSet.COLUMN_NAME_PROD_ITEM01, row)
            'ﾊﾟﾀｰﾝ別入力項目_項目２
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02, strSplitData, PaymentLineDataSet.COLUMN_NAME_PROD_ITEM02, row)
            'ﾊﾟﾀｰﾝ別入力項目_項目３
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03, strSplitData, PaymentLineDataSet.COLUMN_NAME_PROD_ITEM03, row)
            'ﾊﾟﾀｰﾝ別入力項目_項目４
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM04, strSplitData, PaymentLineDataSet.COLUMN_NAME_PROD_ITEM04, row)
            'ﾊﾟﾀｰﾝ別入力項目_項目５
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM05, strSplitData, PaymentLineDataSet.COLUMN_NAME_PROD_ITEM05, row)
            'ﾊﾟﾀｰﾝ別入力項目_項目６
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM06, strSplitData, PaymentLineDataSet.COLUMN_NAME_PROD_ITEM06, row)
            'ﾊﾟﾀｰﾝ別入力項目_項目７
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM07, strSplitData, PaymentLineDataSet.COLUMN_NAME_PROD_ITEM07, row)
            'ﾊﾟﾀｰﾝ別入力項目_項目８
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM08, strSplitData, PaymentLineDataSet.COLUMN_NAME_PROD_ITEM08, row)
            'ﾊﾟﾀｰﾝ別入力項目_項目９
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM09, strSplitData, PaymentLineDataSet.COLUMN_NAME_PROD_ITEM09, row)
            'ﾊﾟﾀｰﾝ別入力項目_項目１０
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10, strSplitData, PaymentLineDataSet.COLUMN_NAME_PROD_ITEM10, row)
            'ﾊﾟﾀｰﾝ別入力項目_項目１１
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11, strSplitData, PaymentLineDataSet.COLUMN_NAME_PROD_ITEM11, row)
            'ﾊﾟﾀｰﾝ別入力項目_項目１２
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12, strSplitData, PaymentLineDataSet.COLUMN_NAME_PROD_ITEM12, row)
            'ﾊﾟﾀｰﾝ別入力項目_項目１３
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM13, strSplitData, PaymentLineDataSet.COLUMN_NAME_PROD_ITEM13, row)
            'ﾊﾟﾀｰﾝ別入力項目_項目１４
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM14, strSplitData, PaymentLineDataSet.COLUMN_NAME_PROD_ITEM14, row)
            'ﾊﾟﾀｰﾝ別入力項目_項目１５
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM15, strSplitData, PaymentLineDataSet.COLUMN_NAME_PROD_ITEM15, row)
            'ﾊﾟﾀｰﾝ別入力項目_項目１６
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM16, strSplitData, PaymentLineDataSet.COLUMN_NAME_PROD_ITEM16, row)
            'ﾊﾟﾀｰﾝ別入力項目_項目１７
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM17, strSplitData, PaymentLineDataSet.COLUMN_NAME_PROD_ITEM17, row)
            'ﾊﾟﾀｰﾝ別入力項目_項目１８
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM18, strSplitData, PaymentLineDataSet.COLUMN_NAME_PROD_ITEM18, row)
            'ﾊﾟﾀｰﾝ別入力項目_項目１９
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM19, strSplitData, PaymentLineDataSet.COLUMN_NAME_PROD_ITEM19, row)
            'ﾊﾟﾀｰﾝ別入力項目_項目２０
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM20, strSplitData, PaymentLineDataSet.COLUMN_NAME_PROD_ITEM20, row)
            'ﾊﾟﾀｰﾝ別入力項目_項目２２
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM22, strSplitData, PaymentLineDataSet.COLUMN_NAME_PROD_ITEM22, row)
            'ﾊﾟﾀｰﾝ別入力項目_項目２３
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM23, strSplitData, PaymentLineDataSet.COLUMN_NAME_PROD_ITEM23, row)
            'ﾊﾟﾀｰﾝ別入力項目_項目２４
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM24, strSplitData, PaymentLineDataSet.COLUMN_NAME_PROD_ITEM24, row)
            '製品･ｻｰﾋﾞｽ廃止発表日
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.WD_ANNT_DATE, strSplitData, PaymentLineDataSet.COLUMN_NAME_WD_ANNT_DATE, row)
            '製品･ｻｰﾋﾞｽ廃止予定
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.WD_DATE, strSplitData, PaymentLineDataSet.COLUMN_NAME_WD_DATE, row)
            '価格改定予定日
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PRICE_CHG_DATE, strSplitData, PaymentLineDataSet.COLUMN_NAME_PRICE_CHG_DATE, row)
            '数量
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.QTY, strSplitData, PaymentLineDataSet.COLUMN_NAME_QTY, row)
            '導入年月
            strWork = ExcelWrite.changeDBNullToString(strSplitData(ExcelWrite.ExcelPaymentLineColumn.INST_DATE - 1)) & "/1"
            If IsDate(strWork) = True Then
                row(PaymentLineDataSet.COLUMN_NAME_INST_YEAR) = Date.Parse(strWork).ToString("yyyy")
                row(PaymentLineDataSet.COLUMN_NAME_INST_MONTH) = Date.Parse(strWork).ToString("MM")
            End If
            '請求期間・開始年月
            strWork = ExcelWrite.changeDBNullToString(strSplitData(ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE - 1)) & "/1"
            If IsDate(strWork) = True Then
                row(PaymentLineDataSet.COLUMN_NAME_PAY_START_YEAR) = Date.Parse(strWork).ToString("yyyy")
                row(PaymentLineDataSet.COLUMN_NAME_PAY_START_MONTH) = Date.Parse(strWork).ToString("MM")
            End If
            '請求期間・終了年月
            strWork = ExcelWrite.changeDBNullToString(strSplitData(ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE - 1)) & "/1"
            If IsDate(strWork) = True Then
                row(PaymentLineDataSet.COLUMN_NAME_PAY_END_YEAR) = Date.Parse(strWork).ToString("yyyy")
                row(PaymentLineDataSet.COLUMN_NAME_PAY_END_MONTH) = Date.Parse(strWork).ToString("MM")
            End If

            '項目無=====================
            'IGF計算・開始年月
            'IGF計算・終了年月
            'Payment展開
            '定額BID
            '項目無=====================

            '請求期間
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PAY_MONTHS, strSplitData, PaymentLineDataSet.COLUMN_NAME_PAY_MONTHS, row)
            'Validation
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PAY_VALIDATION, strSplitData, PaymentLineDataSet.COLUMN_NAME_PAY_VALIDATION, row)
            '支払方法
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD, strSplitData, PaymentLineDataSet.COLUMN_NAME_PAY_METHOD, row)
            'IGF_対象
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.IGF_APPLIED, strSplitData, PaymentLineDataSet.COLUMN_NAME_IGF_APPLIED, row)
            'IGF契約番号
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_NO, strSplitData, PaymentLineDataSet.COLUMN_NAME_IGF_CONT_NO, row)
            'IGF契約形態
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_FORM, strSplitData, PaymentLineDataSet.COLUMN_NAME_IGF_CONT_FORM, row)
            'IGF契約物件管理
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_MANAGMENT, strSplitData, PaymentLineDataSet.COLUMN_NAME_IGF_CONT_MANAGMENT, row)
            'IGF_IOC料率
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.IGF_RATE_IOC, strSplitData, PaymentLineDataSet.COLUMN_NAME_IGF_RATE_IOC, row)
            'Listprice(単価)_提案時
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL, strSplitData, PaymentLineDataSet.COLUMN_NAME_LIST_PRICE_PROPOSAL, row)
            'Listprice(単価)_ﾘﾌﾚｯｼｭ後
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH, strSplitData, PaymentLineDataSet.COLUMN_NAME_LIST_PRICE_REFLESH, row)
            'Listprice(合計)_提案時	
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_PROPOSAL, strSplitData, PaymentLineDataSet.COLUMN_NAME_LIST_PRICE_TOTAL_PROPOSAL, row)
            'Listprice(合計)_ﾘﾌﾚｯｼｭ後	
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH, strSplitData, PaymentLineDataSet.COLUMN_NAME_LIST_PRICE_TOTAL_REFLESH, row)
            'IOC D%
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.DP_IOC, strSplitData, PaymentLineDataSet.COLUMN_NAME_DP_IOC, row)
            'Offering Price_単価Validation前
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC, strSplitData, PaymentLineDataSet.COLUMN_NAME_PRICE_UNIT_IOC, row)
            'Offering Price 単価Validation後
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC_VAL, strSplitData, PaymentLineDataSet.COLUMN_NAME_PRICE_UNIT_IOC_VAL, row)
            'Offering Price_小計
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC, strSplitData, PaymentLineDataSet.COLUMN_NAME_PRICE_QTY_IOC, row)
            'COST %
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.COST_RATE, strSplitData, PaymentLineDataSet.COLUMN_NAME_COST_RATE, row)
            'COST_単価
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.COST, strSplitData, PaymentLineDataSet.COLUMN_NAME_COST, row)
            'COST_合計
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.COST_TOTAL, strSplitData, PaymentLineDataSet.COLUMN_NAME_COST_TOTAL, row)
            'COST_入力日
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.COST_INPUT_DATE, strSplitData, PaymentLineDataSet.COLUMN_NAME_COST_INPUT_DATE, row)
            '展開金額
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PRICE_TO_SPLIT, strSplitData, PaymentLineDataSet.COLUMN_NAME_PRICE_TO_SPLIT, row)
            'Listprice_期間合計
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_IOC, strSplitData, PaymentLineDataSet.COLUMN_NAME_LIST_PRICE_TOTAL_IOC, row)
            'D%適用後_期間合計
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PRICE_TOTAL_IOC, strSplitData, PaymentLineDataSet.COLUMN_NAME_PRICE_TOTAL_IOC, row)
            'COST_期間合計
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.COST_TOTAL_IOC, strSplitData, PaymentLineDataSet.COLUMN_NAME_COST_TOTAL_IOC, row)
            '支払総額（金利込）
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PRICE_TOTAL_IGF, strSplitData, PaymentLineDataSet.COLUMN_NAME_PRICE_TOTAL_IGF, row)
            '支払総額（契約期間内）
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.CONTRACT_IN, strSplitData, PaymentLineDataSet.COLUMN_NAME_CONTRACT_IN, row)
            '支払総額（契約期間外）
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.CONTRACT_OUT, strSplitData, PaymentLineDataSet.COLUMN_NAME_CONTRACT_OUT, row)
            '金利合計
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PRICE_DEFF_IGF, strSplitData, PaymentLineDataSet.COLUMN_NAME_PRICE_DEFF_IGF, row)

            'プロジェクト毎のSEQ
            Call SetDataCsvToDatarow(ExcelWrite.ExcelPaymentLineColumn.PRICE_DEFF_IGF + 1, strSplitData, PaymentLineDataSet.COLUMN_NAME_PROJECT_SEQ, row)

            row(PaymentLineDataSet.COLUMN_NAME_LINE_SEQ) = intRow.ToString("00000")

            'PAの場合、Brandを設定
            If row(PaymentLineDataSet.COLUMN_NAME_PATTERN_CD) = "11" Then
                strWork = GetPaBrand(row(PaymentLineDataSet.COLUMN_NAME_PROD_ITEM01).ToString)
                row(PaymentLineDataSet.COLUMN_NAME_BRAND) = strWork
            End If

            PaymentData.Rows.Add(row)

        Catch ex As Exception
            Throw New Exception(ex.Message.ToString & "(SetPaymentData)")

        End Try

    End Sub

    ''' <summary>
    ''' 機能：該当ｶﾗﾑからﾃﾞｰﾀをｾｯﾄする
    ''' </summary>
    ''' <param name="intSrcColumn"></param>
    ''' <param name="strSrcData"></param>
    ''' <param name="strDestFieldName"></param>
    ''' <param name="row"></param>
    ''' <remarks></remarks>
    Private Sub SetDataCsvToDatarow(ByVal intSrcColumn As Integer, ByVal strSrcData() As String, ByVal strDestFieldName As String, ByRef row As DataRow)

        Dim strWork As String

        strWork = ExcelWrite.changeDBNullToString(strSrcData(intSrcColumn - 1))
        If strWork <> "" Then
            row(strDestFieldName) = strWork
        End If

    End Sub

    ''' <summary>
    ''' 機能：PAのBrandを取得
    ''' </summary>
    ''' <param name="strProductNo"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetPaBrand(ByVal strProductNo As String) As String

        Dim con As OleDbConnection
        Dim mmc As New MasterMdbControl
        Dim cmd As New OleDbCommand
        Dim dr As OleDbDataReader
        Dim strTypeCd As String
        Dim strMaskCd As String

        GetPaBrand = ""

        Try
            con = mmc.GetOleDBConnection(CommonVariable.MdbPW)
            cmd.CommandText = "SELECT PROD_TYPE_CD, LICENSE_MASK_CD FROM M_PA_MEDIA WHERE PARTNO='" & strProductNo & "'"
            cmd.Connection = con
            dr = cmd.ExecuteReader
            If dr.Read = True Then
                strTypeCd = ExcelWrite.changeDBNullToString(dr("PROD_TYPE_CD"))
                strMaskCd = ExcelWrite.changeDBNullToString(dr("LICENSE_MASK_CD"))

                Select Case strTypeCd
                    Case "01"
                        Select Case strMaskCd
                            Case "1"
                                GetPaBrand = "PA-License"
                            Case "2", "4"
                                GetPaBrand = "PA-S&S"
                            Case "64"
                                GetPaBrand = "OTHER"
                        End Select
                    Case "02", "03", "06"
                        GetPaBrand = "PA Media"
                End Select
            End If

            con.Close()

        Catch ex As Exception
            Throw ex
        End Try

    End Function


    ''' <summary>
    ''' 機能：IGFのOKボタン処理
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function OkIgf() As Boolean

        Dim strSelect As String
        Dim strPath As String
        Dim strFileName As String
        Dim intColCnt As Integer
        Dim strItem As String
        Dim strLine As String = ""
        Dim sw As StreamWriter
        Dim ofm As New OioFileManage
        Dim row As DataRow
        Dim strPrjSeq As String
        Dim strPatternCd As String
        Dim strBrand As String
        'Service Integrator取込不備対応 2018/10 Str
        Dim strPattern As String
        'Service Integrator取込不備対応 2018/10 End

        OkIgf = False

        Try
            'PaymentDataに反映
            For Each dgvRow As DataGridViewRow In dgvConfig.Rows
                If dgvRow.Cells(COL_IGF.IGF).Value = True Then
                    strPrjSeq = dgvRow.Cells(COL_IGF.NO).Value
                    strPatternCd = dgvRow.Cells(COL_IGF.PatternCd).Value
                    'Service Integrator取込不備対応 2018/10 Str
                    strPattern = dgvRow.Cells(COL_IGF.Pattern).Value
                    'Service Integrator取込不備対応 2018/10 End

                    'Service Integrator取込不備対応 2018/10 Str
                    If dgvRow.Cells(COL_IGF.PatternCd).Value = "11" Then
                        'Service Integrator取込不備対応 2018/10 End
                        strSelect = PaymentLineDataSet.COLUMN_NAME_PROJECT_SEQ & "='" & strPrjSeq & "'" &
                          " and " & PaymentLineDataSet.COLUMN_NAME_PATTERN_CD & "='" & strPatternCd & "'"
                        'Service Integrator取込不備対応 2018/10 Str
                    Else
                        strSelect = PaymentLineDataSet.COLUMN_NAME_PROJECT_SEQ & "='" & strPrjSeq & "'" &
                          " and " & PaymentLineDataSet.COLUMN_NAME_PATTERN_CD & "='" & strPatternCd & "'" & _
                          " and " & PaymentLineDataSet.COLUMN_NAME_PATTERN & "='" & strPattern & "'"
                    End If
                    'Service Integrator取込不備対応 2018/10 End

                    If strPatternCd = "11" Then
                        strBrand = dgvRow.Cells(COL_IGF.Pattern).Value
                        strSelect = strSelect & " and " & PaymentLineDataSet.COLUMN_NAME_BRAND & "='" & strBrand & "'"
                    End If
                    For Each row In PaymentData.Select(strSelect)
                        row(PaymentLineDataSet.COLUMN_NAME_IGF_APPLIED) = "Y"
                    Next
                End If
            Next

            'Brand削除
            strSelect = PaymentLineDataSet.COLUMN_NAME_PATTERN_CD & "='11'"
            For Each row In PaymentData.Select(strSelect)
                row(PaymentLineDataSet.COLUMN_NAME_BRAND) = ""
            Next

            'CSV出力
            strPath = ofm.GetLocalOutputCsvTempCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            strFileName = "PS_構成取込_" & Now.ToString("yyyyMMdd_HHmmss") & ".csv"
            sw = New StreamWriter(strPath & "\" & strFileName, False, System.Text.Encoding.GetEncoding("shift_jis"))

            For Each row In PaymentData.Select("", PaymentLineDataSet.COLUMN_NAME_LINE_SEQ)
                strLine = ""
                For intColCnt = (ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG - 1) To (ExcelWrite.ExcelPaymentLineColumn.PRICE_DEFF_IGF - 1)
                    strItem = GetPSDataSetColumnValByCsvIdx(row, intColCnt)
                    'カンマがある場合、ダブルクォテーションで括る
                    If strItem.IndexOf(",") >= 0 Then
                        strItem = """" & strItem & """"
                    End If
                    strLine = strLine & strItem & ","
                Next
                strLine = strLine.Substring(0, strLine.Length - 1)
                sw.WriteLine(strLine)
            Next
            sw.Close()

            'ファイル削除処理（PS_構成取込～）
            Call DeleteTempCsv(strFileName)

            OkIgf = True

        Catch ex As Exception
            Throw New Exception(ex.Message.ToString & "(OkIgf)")

        End Try

    End Function

    ''' <summary>
    ''' 機能：Csvの位置をKeyにPSDataSetの値を取得
    ''' </summary>
    ''' <param name="row"></param>
    ''' <param name="csvIdx"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetPSDataSetColumnValByCsvIdx(ByRef row As DataRow, _
                                                   ByVal csvIdx As Integer) As String

        ''初期化
        Dim rtnValue As String = ""

        GetPSDataSetColumnValByCsvIdx = rtnValue

        Select Case csvIdx + 1
            Case ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_UPDATE_FLAG))

            Case ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_LOCK_FLAG))

            Case ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_VALID_FLAG))

            Case ExcelWrite.ExcelPaymentLineColumn.LINE_NO
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_LINE_NO))

            Case ExcelWrite.ExcelPaymentLineColumn.FILE_NAME
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_FILE_NAME))

            Case ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_FILE_NAME_SUFFIX))

            Case ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_FILE_NAME_SUFFIX_INTR))

            Case ExcelWrite.ExcelPaymentLineColumn.CONTRACT
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_CONTRACT))

            Case ExcelWrite.ExcelPaymentLineColumn.ST_COST
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_ST_COST))

            Case ExcelWrite.ExcelPaymentLineColumn.ST_APPROVAL
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_ST_APPROVAL))

            Case ExcelWrite.ExcelPaymentLineColumn.PROJ_ID
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PROJ_ID))

            Case ExcelWrite.ExcelPaymentLineColumn.CONTRACT_SEQ
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_CONTRACT_SEQ))

            Case ExcelWrite.ExcelPaymentLineColumn.NEW_EXIST
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_NEW_EXIST))

            Case ExcelWrite.ExcelPaymentLineColumn.CUST_CATEGORY
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_CUST_CATEGORY))

            Case ExcelWrite.ExcelPaymentLineColumn.LETTER_PLAN_DATE
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_LETTER_PLAN_DATE))

            Case ExcelWrite.ExcelPaymentLineColumn.LETTER_ACCEPT_DATE
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_LETTER_ACCEPT_DATE))

            Case ExcelWrite.ExcelPaymentLineColumn.ORDER_DATE
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_ORDER_DATE))

            Case ExcelWrite.ExcelPaymentLineColumn.LETTER_ID
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_LETTER_ID))

            Case ExcelWrite.ExcelPaymentLineColumn.ORDERCODE
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_ORDERCODE))

            Case ExcelWrite.ExcelPaymentLineColumn.BU
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_BU))

            Case ExcelWrite.ExcelPaymentLineColumn.BRAND
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_BRAND))

            Case ExcelWrite.ExcelPaymentLineColumn.SUM_CATEGORY
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_SUM_CATEGORY))

            Case ExcelWrite.ExcelPaymentLineColumn.BRAND_SUB
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_BRAND_SUB))

            Case ExcelWrite.ExcelPaymentLineColumn.OP1
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_OP1))

            Case ExcelWrite.ExcelPaymentLineColumn.OP2
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_OP2))

            Case ExcelWrite.ExcelPaymentLineColumn.BRAND_SIZE
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_BRAND_SIZE))

            Case ExcelWrite.ExcelPaymentLineColumn.NON_SBO
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_NON_SBO))

            Case ExcelWrite.ExcelPaymentLineColumn.POSTSCRIPT
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_POSTSCRIPT))

            Case ExcelWrite.ExcelPaymentLineColumn.TOPACS_CPNO
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_TOPACS_CPNO))

            Case ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_FORM
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_BRAND_AP_FORM))

            Case ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_REQ
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_BRAND_AP_REQ))

            Case ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_CONF
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_BRAND_AP_CONF))

            Case ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PATTERN_CD))

            Case ExcelWrite.ExcelPaymentLineColumn.PATTERN
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PATTERN))

            Case ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PROD_ITEM01))

            Case ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PROD_ITEM02))

            Case ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PROD_ITEM03))

            Case ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM04
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PROD_ITEM04))

            Case ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM05
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PROD_ITEM05))

            Case ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM06
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PROD_ITEM06))

            Case ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM07
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PROD_ITEM07))

            Case ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM08
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PROD_ITEM08))

            Case ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM09
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PROD_ITEM09))

            Case ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PROD_ITEM10))

            Case ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PROD_ITEM11))

            Case ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PROD_ITEM12))

            Case ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM13
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PROD_ITEM13))

            Case ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM14
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PROD_ITEM14))

            Case ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM15
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PROD_ITEM15))

            Case ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM16
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PROD_ITEM16))

            Case ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM17
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PROD_ITEM17))

            Case ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM18
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PROD_ITEM18))

            Case ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM19
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PROD_ITEM19))

            Case ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM20
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PROD_ITEM20))

            Case ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM22
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PROD_ITEM22))

            Case ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM23
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PROD_ITEM23))

            Case ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM24
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PROD_ITEM24))

            Case ExcelWrite.ExcelPaymentLineColumn.WD_ANNT_DATE
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_WD_ANNT_DATE))

            Case ExcelWrite.ExcelPaymentLineColumn.WD_DATE
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_WD_DATE))

            Case ExcelWrite.ExcelPaymentLineColumn.PRICE_CHG_DATE
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PRICE_CHG_DATE))

            Case ExcelWrite.ExcelPaymentLineColumn.QTY
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_QTY))

            Case ExcelWrite.ExcelPaymentLineColumn.INST_DATE
                If ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_INST_YEAR)) = "" Or _
                   ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_INST_MONTH)) = "" Then
                    rtnValue = ""
                Else
                    rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_INST_YEAR)) & "/" & ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_INST_MONTH))
                End If

            Case ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE
                If ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PAY_START_YEAR)) = "" Or _
                   ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PAY_START_MONTH)) = "" Then
                    rtnValue = ""
                Else
                    rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PAY_START_YEAR)) & "/" & ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PAY_START_MONTH))
                End If

            Case ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE
                If ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PAY_END_YEAR)) = "" Or _
                   ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PAY_END_MONTH)) = "" Then
                    rtnValue = ""
                Else
                    rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PAY_END_YEAR)) & "/" & ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PAY_END_MONTH))
                End If

            Case ExcelWrite.ExcelPaymentLineColumn.IGF_START_DATE
                rtnValue = ""

            Case ExcelWrite.ExcelPaymentLineColumn.IGF_END_DATE
                rtnValue = ""

            Case ExcelWrite.ExcelPaymentLineColumn.PAY_FLAG
                rtnValue = ""

            Case ExcelWrite.ExcelPaymentLineColumn.BID_FLAG
                rtnValue = ""

            Case ExcelWrite.ExcelPaymentLineColumn.PAY_MONTHS
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PAY_MONTHS))

            Case ExcelWrite.ExcelPaymentLineColumn.PAY_VALIDATION
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PAY_VALIDATION))

            Case ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PAY_METHOD))

            Case ExcelWrite.ExcelPaymentLineColumn.IGF_APPLIED
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_IGF_APPLIED))

            Case ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_NO
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_IGF_CONT_NO))

            Case ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_FORM
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_IGF_CONT_FORM))

            Case ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_MANAGMENT
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_IGF_CONT_MANAGMENT))

            Case ExcelWrite.ExcelPaymentLineColumn.IGF_RATE_IOC
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_IGF_RATE_IOC))

            Case ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_LIST_PRICE_PROPOSAL))

            Case ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_LIST_PRICE_REFLESH))

            Case ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_PROPOSAL
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_LIST_PRICE_TOTAL_PROPOSAL))

            Case ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_LIST_PRICE_TOTAL_REFLESH))

            Case ExcelWrite.ExcelPaymentLineColumn.DP_IOC
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_DP_IOC))

            Case ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PRICE_UNIT_IOC))

            Case ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC_VAL
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PRICE_UNIT_IOC_VAL))

            Case ExcelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PRICE_QTY_IOC))

            Case ExcelWrite.ExcelPaymentLineColumn.COST_RATE
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_COST_RATE))

            Case ExcelWrite.ExcelPaymentLineColumn.COST
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_COST))

            Case ExcelWrite.ExcelPaymentLineColumn.COST_TOTAL
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_COST_TOTAL))

            Case ExcelWrite.ExcelPaymentLineColumn.COST_INPUT_DATE
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_COST_INPUT_DATE))

            Case ExcelWrite.ExcelPaymentLineColumn.PRICE_TO_SPLIT
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PRICE_TO_SPLIT))

            Case ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_IOC
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_LIST_PRICE_TOTAL_IOC))

            Case ExcelWrite.ExcelPaymentLineColumn.PRICE_TOTAL_IOC
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PRICE_TOTAL_IOC))

            Case ExcelWrite.ExcelPaymentLineColumn.COST_TOTAL_IOC
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_COST_TOTAL_IOC))

            Case ExcelWrite.ExcelPaymentLineColumn.PRICE_TOTAL_IGF
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PRICE_TOTAL_IGF))

            Case ExcelWrite.ExcelPaymentLineColumn.CONTRACT_IN
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_CONTRACT_IN))

            Case ExcelWrite.ExcelPaymentLineColumn.CONTRACT_OUT
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_CONTRACT_OUT))

            Case ExcelWrite.ExcelPaymentLineColumn.PRICE_DEFF_IGF
                rtnValue = ExcelWrite.changeDBNullToString(row.Item(PaymentLineDataSet.COLUMN_NAME_PRICE_DEFF_IGF))

        End Select

        ''戻り値
        Return rtnValue

    End Function

#End Region

    '1717 str

#Region "Config関連処理"
    ''' <summary>
    ''' 機能：Configの表のレイアウト設定
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub FormLayoutConfig()

        Try
            '表のデザインをクリア
            dgvConfig.Columns.Clear()

            'No
            Dim colNo As New DataGridViewTextBoxColumn
            colNo.HeaderText = "NO"
            colNo.Width = 30
            colNo.ReadOnly = True
            dgvConfig.Columns.Add(colNo)
            'ファイル名
            Dim colFile As New DataGridViewTextBoxColumn
            colFile.HeaderText = "ファイル名"
            colFile.Width = 500
            colFile.ReadOnly = True
            dgvConfig.Columns.Add(colFile)
            '出荷年月
            Dim colInstStart As New CalendarColumn()
            colInstStart.HeaderText = "出荷年月"
            colInstStart.Width = 110
            dgvConfig.Columns.Add(colInstStart)
            '請求開始年月
            Dim colPayStart As New CalendarColumn()
            colPayStart.HeaderText = "請求開始年月"
            colPayStart.Width = 110
            dgvConfig.Columns.Add(colPayStart)
            '請求終了年月
            Dim colPayEnd As New CalendarColumn()
            colPayEnd.HeaderText = "請求終了年月"
            colPayEnd.Width = 110
            dgvConfig.Columns.Add(colPayEnd)

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' 機能：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub ShowConfigData()

        Dim strFileName As String = ""
        Dim dtInstStart As Date
        Dim dtPayStart As Date
        Dim dtPayEnd As Date

        Dim SavFileName As String
        Dim SavPro As Integer

        Try
            dgvConfig.Rows.Clear()
            SavFileName = ""
            SavPro = -1

            'プロジェクト数分繰り返し
            For intPro As Integer = 0 To (Me.oioProject.Length - 1)

                dtInstStart = Date.Parse(Me.oioProject(intPro).Introduction)
                dtPayStart = Date.Parse(Me.oioProject(intPro).PayStartTime)
                dtPayEnd = Date.Parse(Me.oioProject(intPro).PayEndTime)

                'ConfigSystemTable数分繰り返し
                For Each row As DataRow In oioProject(intPro).configData.Tables("ConfigSystemTable").Select("")
                    With row

                        strFileName = .Item(ConfigSystemTable.COLUMN_NAME_CONFIG_NAME)

                        'プロジェクトNOとファイル名毎に出力
                        If intPro <> SavPro Or _
                           strFileName <> SavFileName Then

                            dgvConfig.Rows.Add(
                                        intPro,
                                        strFileName,
                                        dtInstStart,
                                        dtPayStart,
                                        dtPayEnd)
                        End If

                        SavPro = intPro
                        SavFileName = strFileName

                    End With
                Next
            Next

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' 機能：ConfigのOKボタン処理
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function OkConfig() As Boolean

        Dim blnRet As Boolean
        Dim intPro As Integer
        Dim strfilter As String
        Dim drCF As System.Data.DataRow

        OkConfig = False

        Try
            '入力チェック
            blnRet = CheckInputConfig()
            If blnRet = False Then
                Exit Function
            End If

            'ConfigSystemTableに反映(出荷年月、請求開始、請求終了をセット)
            '同一ProjectNo/Filenmを更新
            For Each dgvRow As DataGridViewRow In dgvConfig.Rows

                intPro = dgvRow.Cells(COL_CONFIG.NO).Value
                strfilter = "ConfigName='" & dgvRow.Cells(COL_CONFIG.FileNm).Value & "'"
                For Each drCF In Me.oioProject(intPro).configData.Tables("ConfigSystemTable").Select(strfilter)

                    drCF.Item(ConfigSystemTable.COLUMN_NAME_INSTDATE) = Format(dgvRow.Cells(COL_CONFIG.InstDate).Value, "yyyy/MM/dd")
                    drCF.Item(ConfigSystemTable.COLUMN_NAME_STARTDATE) = Format(dgvRow.Cells(COL_CONFIG.PayStart).Value, "yyyy/MM/dd")
                    drCF.Item(ConfigSystemTable.COLUMN_NAME_ENDDATE) = Format(dgvRow.Cells(COL_CONFIG.PayEnd).Value, "yyyy/MM/dd")

                    Me.oioProject(intPro).configData.Tables("ConfigSystemTable").AcceptChanges()
                Next
            Next

            OkConfig = True

        Catch ex As Exception
            Throw ex

        End Try

    End Function

    ''' <summary>
    ''' 機能：Configの入力チェック
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckInputConfig() As Boolean

        Dim blnErrPayTerm As Boolean
        Dim dgvRow As DataGridViewRow
        Dim strErrMsg As String = "入力内容に不備があります。"

        CheckInputConfig = False

        Try
            '背景色初期化
            For Each dgvRow In dgvConfig.Rows
                For intColCnt As Integer = COL_CONFIG.NO To COL_CONFIG.PayEnd
                    dgvRow.Cells(intColCnt).Style.BackColor = SystemColors.Window
                Next
            Next

            'エラー箇所を背景色黄色で表示
            blnErrPayTerm = False
            For Each dgvRow In dgvConfig.Rows

                '出荷年月と請求開始年月の逆転チェック
                If dgvRow.Cells(COL_CONFIG.InstDate).Value >= dgvRow.Cells(COL_CONFIG.PayStart).Value Then
                    dgvRow.Cells(COL_CONFIG.InstDate).Style.BackColor = Color.Yellow
                    dgvRow.Cells(COL_CONFIG.PayStart).Style.BackColor = Color.Yellow
                    blnErrPayTerm = True
                End If

                '請求開始年月と請求終了年月の逆転チェック
                If dgvRow.Cells(COL_CONFIG.PayStart).Value > dgvRow.Cells(COL_CONFIG.PayEnd).Value Then
                    dgvRow.Cells(COL_CONFIG.PayStart).Style.BackColor = Color.Yellow
                    dgvRow.Cells(COL_CONFIG.PayEnd).Style.BackColor = Color.Yellow
                    blnErrPayTerm = True
                End If

            Next

            If blnErrPayTerm = False Then
                CheckInputConfig = True
            Else
                MsgBox(strErrMsg, MsgBoxStyle.Critical, "入力チェック")
                Exit Function
            End If

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "CheckInputConfig")

        End Try

    End Function

#End Region

    '1717 end

#Region "共通処理"
    ''' <summary>
    ''' 機能：全チェック設定
    ''' </summary>
    ''' <param name="blnChecked"></param>
    ''' <remarks></remarks>
    Private Sub SetAllCheck(ByVal blnChecked As Boolean)

        Try
            For Each dgvRow As DataGridViewRow In dgvConfig.Rows
                dgvRow.Cells(COL_ZSW.Cheked).Value = blnChecked
            Next

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "SetAllCheck")

        End Try

    End Sub

    ''' <summary>
    ''' 機能：ファイル削除処理（PS_構成取込～）
    ''' </summary>
    ''' <param name="strNotDelFile"></param>
    ''' <remarks></remarks>
    Private Sub DeleteTempCsv(Optional ByVal strNotDelFile As String = "")

        Dim strFiles() As String
        Dim strFile As String
        Dim ofm As New OioFileManage
        Dim strPath As String

        Try
            strPath = ofm.GetLocalOutputCsvTempCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            strFiles = Directory.GetFiles(strPath, "PS_構成取込_*.csv")
            For Each strFile In strFiles
                If Path.GetFileName(strFile) <> strNotDelFile Then
                    File.Delete(strFile)
                End If
            Next

            If strNotDelFile = "" Then
                strFiles = Directory.GetFiles(strPath, "PSD_構成取込_*.csv")
                For Each strFile In strFiles
                    File.Delete(strFile)
                Next
            End If

        Catch ex As Exception
            Throw ex

        End Try

    End Sub

#End Region

#End Region

End Class