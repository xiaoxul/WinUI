﻿Imports System.IO
Public Class TestClass2
    Private pre_Time As DateTime
    Private now_Time As DateTime
    Sub New()
#If (Debug) Then
        pre_Time = Now
#End If
    End Sub

    Public Sub initPreTime()
#If (Debug) Then
        pre_Time = Now
#End If
    End Sub

    Public Function GetDeffTime() As String
#If (Debug) Then
        Dim timeSp As TimeSpan
        now_Time = Now
        timeSp = now_Time - pre_Time

        ''初期化
        pre_Time = Now

        Return timeSp.Seconds & "秒"
#End If
    End Function

    Public Function GetMDeffTime() As String
#If (Debug) Then
        Dim timeSp As TimeSpan
        now_Time = Now
        timeSp = now_Time - pre_Time

        ''初期化
        pre_Time = Now

        Return timeSp.Milliseconds & "ﾐﾘ秒"
#End If
    End Function


    Public Sub outTestLog(ByVal value As String)
#If (Debug) Then
        Dim writer As New System.IO.StreamWriter("C:\TestLog.txt", True, System.Text.Encoding.Default)
        writer.WriteLine(value)
        writer.Close()
#End If
    End Sub

    Public Sub outTestLog(ByVal filePath As String, ByVal value As String)
#If (Debug) Then
        Dim writer As New System.IO.StreamWriter(filePath, True, System.Text.Encoding.Default)
        writer.WriteLine(value)
        writer.Close()
#End If
    End Sub

    Public Sub OutDataTable(ByVal tableData As DataTable, _
                            Optional ByVal flg As Boolean = False)

#If (Debug) Then
        If flg Then
            Dim outstr As String = ""
            outTestLog("【以下、テーブル：" & tableData.TableName & "のデータ出力】")

            ''カラム名出力
            For columCount As Integer = 0 To tableData.Columns.Count - 1
                outstr = outstr & tableData.Columns(columCount).ColumnName.ToString.PadRight(30, " ")
                outstr = outstr & vbTab
            Next
            outTestLog(outstr)

            ''行ループ
            For rowCount As Integer = 0 To tableData.Rows.Count - 1
                outstr = ""
                For columCount As Integer = 0 To tableData.Columns.Count - 1
                    outstr = outstr & changeDBNullToString(tableData.Rows(rowCount).Item(columCount))
                    outstr = outstr & vbTab
                Next
                outTestLog(outstr)
            Next
        End If
#End If
    End Sub

    Public Sub OutDataTable(ByVal filePath As String, _
                            ByVal tableData As DataTable, _
                            Optional ByVal flg As Boolean = False)

#If (Debug) Then
        If flg Then
            Dim outstr As String = ""
            outTestLog("【以下、テーブル：" & tableData.TableName & "のデータ出力】")

            ''カラム名出力
            For columCount As Integer = 0 To tableData.Columns.Count - 1
                outstr = outstr & tableData.Columns(columCount).ColumnName.ToString.PadRight(30, " ")
                outstr = outstr & vbTab
            Next
            outTestLog(filePath, outstr)

            ''行ループ
            For rowCount As Integer = 0 To tableData.Rows.Count - 1
                outstr = ""
                For columCount As Integer = 0 To tableData.Columns.Count - 1
                    outstr = outstr & changeDBNullToString(tableData.Rows(rowCount).Item(columCount))
                    outstr = outstr & vbTab
                Next
                outTestLog(filePath, outstr)
            Next
        End If
#End If
    End Sub

    ''' <summary>
    ''' 機能：Nullチェック
    ''' 説明：値がNullの場合、空文字を返す
    ''' </summary>
    ''' <param name="Value"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function changeDBNullToString(ByVal Value As Object) As String
#If (Debug) Then
        If IsDBNull(Value) Or IsNothing(Value) Then
            Return ""
        Else
            Return Value.ToString
        End If
#End If
    End Function

End Class
