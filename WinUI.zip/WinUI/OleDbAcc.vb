﻿Imports System.Text
Imports System.Data.OleDb
Imports MUSE.Utility
Imports MUSE.Utility.XmlClass
Imports MUSE.Utility.OioBamaCommmon
Imports MUSE.Utility.XmlClass.ConnectionInfo
Imports MUSE.Utility.UserDataTable.Master

Namespace OleDbAcc

    Public Class OleDbCpnoBpt

        Public Shared Function getCpno(ByVal strCpno As String) As DataTable

            Dim strMsg As String = ""
            Dim blnRet As Boolean
            Dim wc As New WebDb.WebDbCommon
            Dim dt As New M_CONTRACT_BASETable

            Try
                '認証設定
                wc.IntraId = CommonVariable.USERID
                wc.IntraPass = CommonVariable.USERPW

                '契約基本情報取得
                blnRet = wc.GetContractBaseData(strCpno, dt, strMsg)
                If blnRet = False Then
                    Throw New Exception(strMsg)
                    Exit Function
                End If

                Return dt

            Catch ex As Exception
                Throw ex
            End Try

        End Function

        Public Shared Function getContract(ByVal strCpno As String) As DataTable

            Dim strMsg As String = ""
            Dim wc As New WebDb.WebDbCommon
            Dim blnRet As Boolean
            Dim dt As New M_CONTRACT_BASETable

            Try
                '認証設定
                wc.IntraId = CommonVariable.USERID
                wc.IntraPass = CommonVariable.USERPW

                '契約基本情報取得
                blnRet = wc.GetContractBaseData(strCpno, dt, strMsg)
                If blnRet = False Then
                    Throw New Exception(strMsg)
                    Exit Function
                End If

                Return dt

            Catch ex As Exception
                Throw ex
            End Try

        End Function

    End Class

End Namespace

