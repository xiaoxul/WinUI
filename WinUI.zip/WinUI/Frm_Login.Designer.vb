﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_Login
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Txb_UserID = New System.Windows.Forms.TextBox()
        Me.Txb_Password = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Btn_Login = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_End = New MUSE.UserControl.UCnt_Btn0001()
        Me.UCnt_Pal00011 = New MUSE.UserControl.UCnt_Pal0001()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnAsrAll = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnMnt = New MUSE.UserControl.UCnt_Btn0001()
        Me.rbMnt = New System.Windows.Forms.RadioButton()
        Me.rbDsl = New System.Windows.Forms.RadioButton()
        Me.rbDso = New System.Windows.Forms.RadioButton()
        Me.rbRed = New System.Windows.Forms.RadioButton()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(112, 90)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(69, 15)
        Me.Label1.TabIndex = 39
        Me.Label1.Text = "ユーザーID"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(112, 132)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 15)
        Me.Label2.TabIndex = 40
        Me.Label2.Text = "パスワード"
        '
        'Txb_UserID
        '
        Me.Txb_UserID.BackColor = System.Drawing.Color.Yellow
        Me.Txb_UserID.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Txb_UserID.Location = New System.Drawing.Point(195, 86)
        Me.Txb_UserID.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Txb_UserID.MaxLength = 50
        Me.Txb_UserID.Name = "Txb_UserID"
        Me.Txb_UserID.Size = New System.Drawing.Size(348, 22)
        Me.Txb_UserID.TabIndex = 0
        Me.Txb_UserID.Text = "@jp.ibm.com"
        '
        'Txb_Password
        '
        Me.Txb_Password.BackColor = System.Drawing.Color.Yellow
        Me.Txb_Password.Location = New System.Drawing.Point(195, 129)
        Me.Txb_Password.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Txb_Password.MaxLength = 50
        Me.Txb_Password.Name = "Txb_Password"
        Me.Txb_Password.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.Txb_Password.Size = New System.Drawing.Size(348, 22)
        Me.Txb_Password.TabIndex = 1
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(179, 168)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(379, 15)
        Me.Label3.TabIndex = 44
        Me.Label3.Text = "※OIO BAMA Clientを使用するにはユーザー登録が必要です。"
        '
        'Btn_Login
        '
        Me.Btn_Login.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Login.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Login.ForeColor = System.Drawing.Color.White
        Me.Btn_Login.Location = New System.Drawing.Point(16, 219)
        Me.Btn_Login.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Btn_Login.Name = "Btn_Login"
        Me.Btn_Login.Size = New System.Drawing.Size(160, 55)
        Me.Btn_Login.TabIndex = 2
        Me.Btn_Login.Text = "契約情報登録"
        Me.Btn_Login.UseVisualStyleBackColor = False
        '
        'Btn_End
        '
        Me.Btn_End.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_End.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_End.ForeColor = System.Drawing.Color.White
        Me.Btn_End.Location = New System.Drawing.Point(561, 219)
        Me.Btn_End.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Btn_End.Name = "Btn_End"
        Me.Btn_End.Size = New System.Drawing.Size(160, 55)
        Me.Btn_End.TabIndex = 5
        Me.Btn_End.Text = "終了"
        Me.Btn_End.UseVisualStyleBackColor = False
        '
        'UCnt_Pal00011
        '
        Me.UCnt_Pal00011.BackColor = System.Drawing.Color.Teal
        Me.UCnt_Pal00011.BackColro2 = System.Drawing.Color.PaleTurquoise
        Me.UCnt_Pal00011.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UCnt_Pal00011.ForeColor = System.Drawing.Color.White
        Me.UCnt_Pal00011.Location = New System.Drawing.Point(0, 1)
        Me.UCnt_Pal00011.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.UCnt_Pal00011.Name = "UCnt_Pal00011"
        Me.UCnt_Pal00011.Size = New System.Drawing.Size(739, 55)
        Me.UCnt_Pal00011.TabIndex = 32
        Me.UCnt_Pal00011.TitleText = "OIO BAMA Client ログイン           <<@@@>>"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(196, 188)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(334, 15)
        Me.Label4.TabIndex = 51
        Me.Label4.Text = "新規登録申請はOIOシステム管理者までお願いします。"
        '
        'btnAsrAll
        '
        Me.btnAsrAll.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnAsrAll.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btnAsrAll.ForeColor = System.Drawing.Color.White
        Me.btnAsrAll.Location = New System.Drawing.Point(377, 219)
        Me.btnAsrAll.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnAsrAll.Name = "btnAsrAll"
        Me.btnAsrAll.Size = New System.Drawing.Size(160, 55)
        Me.btnAsrAll.TabIndex = 4
        Me.btnAsrAll.Text = "一括処理"
        Me.btnAsrAll.UseVisualStyleBackColor = False
        '
        'btnMnt
        '
        Me.btnMnt.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnMnt.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btnMnt.ForeColor = System.Drawing.Color.White
        Me.btnMnt.Location = New System.Drawing.Point(199, 219)
        Me.btnMnt.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnMnt.Name = "btnMnt"
        Me.btnMnt.Size = New System.Drawing.Size(160, 55)
        Me.btnMnt.TabIndex = 3
        Me.btnMnt.Text = "マスタメンテ"
        Me.btnMnt.UseVisualStyleBackColor = False
        '
        'rbMnt
        '
        Me.rbMnt.AutoSize = True
        Me.rbMnt.Location = New System.Drawing.Point(604, 75)
        Me.rbMnt.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.rbMnt.Name = "rbMnt"
        Me.rbMnt.Size = New System.Drawing.Size(58, 19)
        Me.rbMnt.TabIndex = 6
        Me.rbMnt.TabStop = True
        Me.rbMnt.Text = "MNT"
        Me.rbMnt.UseVisualStyleBackColor = True
        '
        'rbDsl
        '
        Me.rbDsl.AutoSize = True
        Me.rbDsl.Location = New System.Drawing.Point(604, 102)
        Me.rbDsl.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.rbDsl.Name = "rbDsl"
        Me.rbDsl.Size = New System.Drawing.Size(55, 19)
        Me.rbDsl.TabIndex = 7
        Me.rbDsl.TabStop = True
        Me.rbDsl.Text = "DSL"
        Me.rbDsl.UseVisualStyleBackColor = True
        '
        'rbDso
        '
        Me.rbDso.AutoSize = True
        Me.rbDso.Checked = True
        Me.rbDso.Location = New System.Drawing.Point(604, 132)
        Me.rbDso.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.rbDso.Name = "rbDso"
        Me.rbDso.Size = New System.Drawing.Size(58, 19)
        Me.rbDso.TabIndex = 8
        Me.rbDso.TabStop = True
        Me.rbDso.Text = "DSO"
        Me.rbDso.UseVisualStyleBackColor = True
        '
        'rbRed
        '
        Me.rbRed.AutoSize = True
        Me.rbRed.Location = New System.Drawing.Point(604, 160)
        Me.rbRed.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.rbRed.Name = "rbRed"
        Me.rbRed.Size = New System.Drawing.Size(55, 19)
        Me.rbRed.TabIndex = 9
        Me.rbRed.TabStop = True
        Me.rbRed.Text = "RED"
        Me.rbRed.UseVisualStyleBackColor = True
        '
        'frm_Login
        '
        Me.AcceptButton = Me.Btn_Login
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(737, 289)
        Me.ControlBox = False
        Me.Controls.Add(Me.rbRed)
        Me.Controls.Add(Me.rbDso)
        Me.Controls.Add(Me.rbDsl)
        Me.Controls.Add(Me.rbMnt)
        Me.Controls.Add(Me.btnMnt)
        Me.Controls.Add(Me.btnAsrAll)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Txb_Password)
        Me.Controls.Add(Me.Txb_UserID)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Btn_Login)
        Me.Controls.Add(Me.Btn_End)
        Me.Controls.Add(Me.UCnt_Pal00011)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.MaximizeBox = False
        Me.Name = "frm_Login"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "OIO BAMA Client"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents UCnt_Pal00011 As MUSE.UserControl.UCnt_Pal0001
    Friend WithEvents Btn_End As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Login As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Txb_UserID As System.Windows.Forms.TextBox
    Friend WithEvents Txb_Password As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents btnAsrAll As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents btnMnt As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents rbMnt As System.Windows.Forms.RadioButton
    Friend WithEvents rbDsl As System.Windows.Forms.RadioButton
    Friend WithEvents rbDso As System.Windows.Forms.RadioButton
    Friend WithEvents rbRed As System.Windows.Forms.RadioButton
End Class
