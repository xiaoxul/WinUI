﻿Imports System.IO
Imports System.Text
Imports System.Runtime
Imports MUSE.WinUI.OleDbAcc.OleDbCpnoBpt
Imports Microsoft.Office.Interop
Imports MUSE.WinUI.OioBamaCommmon.OioExcelManage
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.OioBamaCommmon
Imports MUSE.WinUI.OioBamaCommmon
Imports MUSE.Utility.UserDataTable.Transaction
Imports MUSE.Utility.XmlClass.SheetFoumulate
Imports MUSE.Controller
Imports MUSE.Utility.UserDataTable.Master
Imports MUSE.Utility
Imports System.Data.OleDb
Imports MUSE.Utility.SharedClass.ExcelWrite
Imports System.Collections.Generic
Imports MUSE.DataAccess.OleDb

Public Class OutputExcel

#Region "定数"

    ''区切文字
    Private Const DELIMITA As String = ","
    Private IMPORTDIALOG_DEFULT_PATH As String = "../Csv1/"
    Private EXPORTDIALOG_DEFULT_PATH As String = "../Excel/"
    ''テンプレートExcelファイル名
    Private Const EXCEL_PAYMENTLINE_TEMPLETEFILENM As String = "PaymentLineSample.xlsm"
    Private Const EXCEL_PAYMENTLINEVALIDATIONLOG_TEMPLETEFILENM As String = "PaymentSheetValidationlog.xlsm"
    Private Const EXCEL_PAYMENTLINEREFERENCE_TEMPLETEFILENM As String = "PaymentSheetReference.xlsm"
    Private Const EXCEL_PAYMENTDETAILLINE_TEMPLETEFILENM As String = "PaymentLineDetailSample.xlsm"
    Private Const EXCEL_PAYMENTDETAILLINEVALIDATIONLOG_TEMPLETEFILENM As String = "PaymentDetailSheetValidationlog.xlsm"
    Private Const EXCEL_PAYMENTDETAILLINEREFERENCE_TEMPLETEFILENM As String = "PaymentDetailSheetReference.xlsm"

    Private Const EXCEL_PAYMENTLINEDATE_OUTCOLUM As String = "A@:IS@"
    Private Const EXCEL_PAYMENTLINEDATE_OUTROW As Integer = 7
    Private Const EXCEL_PAYMENTLINEDATE_ENDROW As Integer = 60000
    Private Const EXCEL_PS_Exc_OUTCOLUM As String = "A@:CR@"

    ''個別詳細
    Private Const EXCEL_PAYMENTLINEDETAILDATE_OUTCOLUM As String = "A@:Z@"
    Private Const EXCEL_PAYMENTLINEDETAILDATE_OUTROW As Integer = 6

    ''PaymentLineValidationlog
    Private Const EXCEL_PAYMENTLINEVALIDATIONLOGDATE_OUTCOLUM As String = "A@:N@"
    Private Const EXCEL_PAYMENTLINEVALIDATIONLOGDATE_OUTROW As Integer = 4

    ''個別詳細Validationlog
    Private Const EXCEL_PAYMENTLINEVALIDATIONLOGDETAILDATE_OUTCOLUM As String = "A@:N@"
    Private Const EXCEL_PAYMENTLINEVALIDATIONLOGDETAILDATE_OUTROW As Integer = 4

    'ワークシート
    'WS1
    Private Const EXCEL_PAYMENTLINEDATE_WS1 As Integer = 1
    'PaymentSheet
    Private Const EXCEL_PAYMENTLINEDATE_PAYMENTSHEET As Integer = 2

    'リストSheet
    Private Const EXCEL_PAYMENTLINEDATE_LISTSHEET As String = "リスト"
    Private Const EXCEL_PAYMENTLINEDATE_PAYMENTDETAILRESHEET As Integer = 2

    Private Const CD_RET_ERR_SYS As Integer = -1
    Private Const CD_RET_ERR_NO_EOF As Integer = -2
    Private Const CD_RET_ERR_UNMATCH_EOF As Integer = -3

    ''CSVファイルの行構成
    ''PaymentSheet
    Private Const CSV_PAYMENTLINE_CHECK_STRLINE As Integer = 1
    Private Const CSV_PAYMENTLINE_CHECK_ENDLINE As Integer = 4
    Private Const CSV_PAYMENTLINE_CHECK_FILENMROW As Integer = 1
    Private Const CSV_PAYMENTLINE_CHECK_ROWTITLEROW As Integer = 2
    Private Const CSV_PAYMENTLINE_CHECK_PAYMENTLINETITLEROW As Integer = 4
    Private Const CSV_PAYMENTLINE_CHECK_MPMAKEEXCHANGE As Integer = 2

    ''個別詳細
    Private Const CSV_PAYMENTLINEDETAIL_CHECK_STRLINE As Integer = 1
    Private Const CSV_PAYMENTLINEDETAIL_CHECK_ENDLINE As Integer = 3
    Private Const CSV_PAYMENTLINEDETAIL_CHECK_FILENMROW As Integer = 1
    Private Const CSV_PAYMENTLINEDETAIL_CHECK_CPNOROW As Integer = 2
    Private Const CSV_PAYMENTLINEDETAIL_CHECK_TITLEOROW As Integer = 3
    Private Const CSV_PAYMENTLINEDETAIL_CHECK_DATAROW As Integer = 3

    ''Validation Log（PaymentSheet/個別詳細共通）
    Private Const CSV_VALIDATIONLOG_CHECK_STRLINE As Integer = 1
    Private Const CSV_VALIDATIONLOG_CHECK_ENDLINE As Integer = 3
    Private Const CSV_VALIDATIONLOG_CHECK_FILENMROW As Integer = 1
    Private Const CSV_VALIDATIONLOG_CHECK_CPNOROW As Integer = 2
    Private Const CSV_VALIDATIONLOG_CHECK_TITLEROW As Integer = 3
    Private Const CSV_VALIDATIONLOG_CHECK_DATAROW As Integer = 3

    ''Payment Lineファイル　お客様情報タイトル    
    Private Const CSV_TITLE_CUSTINFO_CCPNO As String = "CPNO"
    Private Const CSV_TITLE_CUSTINFO_CUST_NAME As String = "CUST_NAME"
    Private Const CSV_TITLE_CUSTINFO_START_YEAR As String = "START_YEAR"
    Private Const CSV_TITLE_CUSTINFO_START_MONTH As String = "START_MONTH"
    Private Const CSV_TITLE_CUSTINFO_END_YEAR As String = "END_YEAR"
    Private Const CSV_TITLE_CUSTINFO_END_MONTH As String = "END_MONTH"
    Private Const CSV_TITLE_CUSTINFO_PA_ANV_DATE As String = "PA_ANV_DATE"
    Private Const CSV_TITLE_CUSTINFO_PA_LEVEL As String = "PA_LEVEL"
    Private Const CSV_TITLE_CUSTINFO_APPROVAL_DATE As String = "APPROVAL_DATE"
    Private Const CSV_TITLE_CUSTINFO_CONTRACT_DATE As String = "CONTRACT_DATE"

    ''Payment Lineファイル　Payment Line情報タイトル
    Private Const CSV_TITLE_PaymentLine_UPDATE_FLAG As String = "UPDATE_FLAG"
    Private Const CSV_TITLE_PaymentLine_LOCK_FLAG As String = "LOCK_FLAG"
    Private Const CSV_TITLE_PaymentLine_VALID_FLAG As String = "VALID_FLAG"
    Private Const CSV_TITLE_PaymentLine_LINE_NO As String = "LINE_NO"
    Private Const CSV_TITLE_PaymentLine_FILE_NAME As String = "FILE_NAME"
    Private Const CSV_TITLE_PaymentLine_FILE_NAME_SUFFIX As String = "FILE_NAME_SUFFIX"
    Private Const CSV_TITLE_PaymentLine_FILE_NAME_SUFFIX_INTR As String = "FILE_NAME_SUFFIX_INTR"
    Private Const CSV_TITLE_PaymentLine_CONTRACT As String = "CONTRACT"
    Private Const CSV_TITLE_PaymentLine_ST_COST As String = "ST_COST"
    Private Const CSV_TITLE_PaymentLine_ST_APPROVAL As String = "ST_APPROVAL"
    Private Const CSV_TITLE_PaymentLine_PROJ_ID As String = "PROJ_ID"
    Private Const CSV_TITLE_PaymentLine_CONTRACT_SEQ As String = "CONTRACT_SEQ"
    Private Const CSV_TITLE_PaymentLine_NEW_EXIST As String = "NEW_EXIST"
    Private Const CSV_TITLE_PaymentLine_INV_EXP As String = "INV_EXP"
    Private Const CSV_TITLE_PaymentLine_CUST_CATEGORY As String = "CUST_CATEGORY"
    Private Const CSV_TITLE_PaymentLine_LETTER_PLAN_DATE As String = "LETTER_PLAN_DATE"
    Private Const CSV_TITLE_PaymentLine_LETTER_ISSUE_DATE As String = "LETTER_ISSUE_DATE"
    Private Const CSV_TITLE_PaymentLine_LETTER_ACCEPT_DATE As String = "LETTER_ACCEPT_DATE"
    Private Const CSV_TITLE_PaymentLine_ORDER_DATE As String = "ORDER_DATE"
    Private Const CSV_TITLE_PaymentLine_LETTER_ID As String = "LETTER_ID"
    Private Const CSV_TITLE_PaymentLine_BILLING_CD As String = "BILLING_CD"
    Private Const CSV_TITLE_PaymentLine_BU As String = "BU"
    Private Const CSV_TITLE_PaymentLine_BRAND As String = "BRAND"
    Private Const CSV_TITLE_PaymentLine_SUM_CATEGORY As String = "SUM_CATEGORY"
    Private Const CSV_TITLE_PaymentLine_BRAND_SUB As String = "BRAND_SUB"
    Private Const CSV_TITLE_PaymentLine_OP1 As String = "OP1"
    Private Const CSV_TITLE_PaymentLine_OP2 As String = "OP2"
    Private Const CSV_TITLE_PaymentLine_SIZE As String = "SIZE"
    Private Const CSV_TITLE_PaymentLine_NON_SBO As String = "NON_SBO"
    Private Const CSV_TITLE_PaymentLine_ADDITION_ITEM As String = "ADDITION_ITEM"
    Private Const CSV_TITLE_PaymentLine_TOPACS_CPNO As String = "TOPACS_CPNO"
    Private Const CSV_TITLE_PaymentLine_BRAND_AP_FORM As String = "BRAND_AP_FORM"
    Private Const CSV_TITLE_PaymentLine_BRAND_AP_REQ As String = "BRAND_AP_REQ"
    Private Const CSV_TITLE_PaymentLine_BRAND_AP_CONF As String = "BRAND_AP_CONF"
    Private Const CSV_TITLE_PaymentLine_PATTERN_CD As String = "PATTERN_CD"
    Private Const CSV_TITLE_PaymentLine_PATTERN As String = "PATTERN"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM01 As String = "PROD_ITEM01"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM02 As String = "PROD_ITEM02"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM03 As String = "PROD_ITEM03"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM04 As String = "PROD_ITEM04"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM05 As String = "PROD_ITEM05"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM06 As String = "PROD_ITEM06"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM07 As String = "PROD_ITEM07"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM08 As String = "PROD_ITEM08"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM09 As String = "PROD_ITEM09"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM10 As String = "PROD_ITEM10"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM11 As String = "PROD_ITEM11"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM12 As String = "PROD_ITEM12"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM13 As String = "PROD_ITEM13"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM14 As String = "PROD_ITEM14"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM15 As String = "PROD_ITEM15"
    Private Const CSV_TITLE_PaymentLine_WD_ANNT_DATE As String = "WD_ANNT_DATE"
    Private Const CSV_TITLE_PaymentLine_WD_DATE As String = "WD_DATE"
    Private Const CSV_TITLE_PaymentLine_PRICE_CHG_DATE As String = "PRICE_CHG_DATE"
    Private Const CSV_TITLE_PaymentLine_QTY As String = "QTY"
    Private Const CSV_TITLE_PaymentLine_INST_YEAR As String = "INST_YEAR"
    Private Const CSV_TITLE_PaymentLine_INST_MONTH As String = "INST_MONTH"
    Private Const CSV_TITLE_PaymentLine_PAY_START_YEAR As String = "PAY_START_YEAR"
    Private Const CSV_TITLE_PaymentLine_PAY_START_MONTH As String = "PAY_START_MONTH"
    Private Const CSV_TITLE_PaymentLine_PAY_END_YEAR As String = "PAY_END_YEAR"
    Private Const CSV_TITLE_PaymentLine_PAY_END_MONTH As String = "PAY_END_MONTH"
    Private Const CSV_TITLE_PaymentLine_PAY_FLAG As String = "PAY_FLAG"                         ''変則Payment FLG
    Private Const CSV_TITLE_PaymentLine_BID_FLAG As String = "BID_FLAG"
    Private Const CSV_TITLE_PaymentLine_IGF_START_DATE As String = "IGF_START_DATE"             ''IGF適用後開始年月
    Private Const CSV_TITLE_PaymentLine_IGF_END_DATE As String = "IGF_END_DATE"                 ''IGF適用後終了年月
    Private Const CSV_TITLE_PaymentLine_PAY_MONTHS As String = "PAY_MONTHS"
    Private Const CSV_TITLE_PaymentLine_VALID_CTRL As String = "VALID_CTRL"
    Private Const CSV_TITLE_PaymentLine_PAY_METHOD As String = "PAY_METHOD"
    Private Const CSV_TITLE_PaymentLine_IGF_APPLIED As String = "IGF_APPLIED"
    Private Const CSV_TITLE_PaymentLine_IGF_CONT_NO As String = "IGF_CONT_NO"
    Private Const CSV_TITLE_PaymentLine_IGF_CONT_TYPE As String = "IGF_CONT_TYPE"
    Private Const CSV_TITLE_PaymentLine_IGF_PROPERTY As String = "IGF_PROPERTY"
    Private Const CSV_TITLE_PaymentLine_IGF_RATE_BAUCOC As String = "IGF_RATE_BAUCOC"
    Private Const CSV_TITLE_PaymentLine_IGF_RATE_IOC As String = "IGF_RATE_IOC"
    Private Const CSV_TITLE_PaymentLine_LIST_PRICE_PROPOSAL As String = "LIST_PRICE_PROPOSAL"
    Private Const CSV_TITLE_PaymentLine_LIST_PRICE As String = "LIST_PRICE"
    Private Const CSV_TITLE_PaymentLine_T_LIST_PRICE_PROPOSAL As String = "LIST_PRICE_TOTAL_PROPOSAL"
    Private Const CSV_TITLE_PaymentLine_T_LIST_PRICE As String = "LIST_PRICE_TOTAL"
    Private Const CSV_TITLE_PaymentLine_DP_BAU As String = "DP_BAU"
    Private Const CSV_TITLE_PaymentLine_DP_COC As String = "DP_COC"
    Private Const CSV_TITLE_PaymentLine_DP_IOC As String = "DP_IOC"
    Private Const CSV_TITLE_PaymentLine_PRICE_UNIT_BAU As String = "PRICE_UNIT_BAU"
    Private Const CSV_TITLE_PaymentLine_PRICE_QTY_BAU As String = "PRICE_QTY_BAU"
    Private Const CSV_TITLE_PaymentLine_PRICE_UNIT_COC As String = "PRICE_UNIT_COC"
    Private Const CSV_TITLE_PaymentLine_PRICE_QTY_COC As String = "PRICE_QTY_COC"
    Private Const CSV_TITLE_PaymentLine_PRICE_UNIT_IOC As String = "PRICE_UNIT_IOC"
    Private Const CSV_TITLE_PaymentLine_PRICE_QTY_IOC As String = "PRICE_QTY_IOC"
    Private Const CSV_TITLE_PaymentLine_COST_RATE As String = "COST_RATE"
    Private Const CSV_TITLE_PaymentLine_COST As String = "COST"
    Private Const CSV_TITLE_PaymentLine_COST_TOTAL As String = "COST_TOTAL"
    Private Const CSV_TITLE_PaymentLine_COST_INPUT_DATE As String = "COST_INPUT_DATE"
    Private Const CSV_TITLE_PaymentLine_TAX_RATE As String = "TAX_RATE"
    Private Const CSV_TITLE_PaymentLine_PRICE_TO_SPLIT As String = "PRICE_TO_SPLIT"
    Private Const CSV_TITLE_PaymentLine_LIST_PRICE_TOTAL_IOC As String = "LIST_PRICE_TOTAL_IOC"
    Private Const CSV_TITLE_PaymentLine_PRICE_TOTAL_IOC As String = "PRICE_TOTAL_IOC"
    Private Const CSV_TITLE_PaymentLine_COST_TOTAL_IOC As String = "COST_TOTAL_IOC"
    Private Const CSV_TITLE_PaymentLine_PRICE_IGF_TOTAL As String = "PRICE_IGF_TOTAL"
    Private Const CSV_TITLE_PaymentLine_PRICE_CONT_TOTAL As String = "PRICE_CONT_TOTAL"
    Private Const CSV_TITLE_PaymentLine_PRICE_OO_CONT_TOTAL As String = "PRICE_OO_CONT_TOTAL"
    Private Const CSV_TITLE_PaymentLine_IGF_DIF_INTEREST As String = "IGF_DIF_INTEREST"

    ''個別詳細の列タイトル
    Private Const CSV_TITLE_CUSTINFO_UPDATE_FLAG As String = "UPDATE_FLAG"
    Private Const CSV_TITLE_CUSTINFO_LOCK_FLAG As String = "LOCK_FLAG"
    Private Const CSV_TITLE_CUSTINFO_VALID_FLAG As String = "VALID_FLAG"
    Private Const CSV_TITLE_CUSTINFO_CONTRACT As String = "CONTRACT"
    Private Const CSV_TITLE_CUSTINFO_FILE_NAME As String = "FILE_NAME"
    Private Const CSV_TITLE_CUSTINFO_FILE_NAME_SUFFIX As String = "FILE_NAME_SUFFIX"
    Private Const CSV_TITLE_CUSTINFO_FILE_NAME_SUFFIX_INTR As String = "FILE_NAME_SUFFIX_INTR"
    Private Const CSV_TITLE_CUSTINFO_SEQ As String = "SEQ"
    Private Const CSV_TITLE_CUSTINFO_IDENTITY_FLAG As String = "IDENTITY_FLAG"
    Private Const CSV_TITLE_CUSTINFO_PROD_NO As String = "PROD_NO"
    Private Const CSV_TITLE_CUSTINFO_PROD_NAME As String = "PROD_NAME"
    Private Const CSV_TITLE_CUSTINFO_WD_ANNT_DATE As String = "WD_ANNT_DATE"
    Private Const CSV_TITLE_CUSTINFO_WD_DATE As String = "WD_DATE"
    Private Const CSV_TITLE_CUSTINFO_PRICE_CHG_DATE As String = "PRICE_CHG_DATE"
    Private Const CSV_TITLE_CUSTINFO_MES_CATEGORY As String = "MES_CATEGORY"
    Private Const CSV_TITLE_CUSTINFO_MES_GROUP As String = "MES_GROUP"
    Private Const CSV_TITLE_CUSTINFO_SPECIAL_FEATURE As String = "SPECIAL_FEATURE"
    Private Const CSV_TITLE_CUSTINFO_QTY As String = "QTY"
    Private Const CSV_TITLE_CUSTINFO_LIST_PRICE_PROPSAL As String = "LIST_PRICE_PROPOSAL"
    Private Const CSV_TITLE_CUSTINFO_LIST_PRICE As String = "LIST_PRICE"
    Private Const CSV_TITLE_CUSTINFO_T_LIST_PRICE_PROPOSAL As String = "LIST_PRICE_TOTAL_PROPOSAL"
    Private Const CSV_TITLE_CUSTINFO_T_LIST_PRICE As String = "LIST_PRICE_TOTAL"
    Private Const CSV_TITLE_CUSTINFO_COST_RATE As String = "COST_RATE"
    Private Const CSV_TITLE_CUSTINFO_COST As String = "COST"
    Private Const CSV_TITLE_CUSTINFO_COST_TOTAL As String = "COST_TOTAL"
    Private Const CSV_TITLE_CUSTINFO_COST_INPUT_DATE As String = "COST_INPUT_DATE"
    Private Const CSV_TITLE_HWMA_LIST_PRICE As String = "HWMA_LIST_PRICE"                       ''単価(MMMC)
    Private Const CSV_TITLE_HWMA_LIST_PRICE_TOTAL As String = "HWMA_LIST_PRICE_TOTAL"           ''合計(MMMC)
    Private Const CSV_TITLE_HOURLY_SCALE As String = "HOURLY_SCALE"                             ''時間帯掛け率
    Private Const CSV_TITLE_MA_EXT_SCALE As String = "MA_EXT_SCALE"                             ''延長掛率
    Private Const CSV_TITLE_DP As String = "DP"                                                 ''保守D%
    Private Const CSV_TITLE_HWMA_DP_LIST_PRICE As String = "HWMA_DP_LIST_PRICE"                 ''保守D%適用後_単価
    Private Const CSV_TITLE_HWMA_DP_LIST_PRICE_TOTAL As String = "HWMA_DP_LIST_PRICE_TOTAL"     ''保守D%適用後_合計

    ''PaymentSheetValidationlogのタイトル
    Private Const CSV_PAYMENTLINEVALIDATIONLOG_TITLE_RESULT As String = "RESULT"
    Private Const CSV_PAYMENTLINEVALIDATIONLOG_TITLE_CPNO As String = "CPNO"
    Private Const CSV_PAYMENTLINEVALIDATIONLOG_TITLE_CONTRACT As String = "CONTRACT"
    Private Const CSV_PAYMENTLINEVALIDATIONLOG_TITLE_FILE_NAME As String = "FILE_NAME"
    Private Const CSV_PAYMENTLINEVALIDATIONLOG_TITLE_FILE_NAME_SUFFIX As String = "FILE_NAME_SUFFIX"
    Private Const CSV_PAYMENTLINEVALIDATIONLOG_TITLE_FILE_NAME_SUFFIX_INTR As String = "FILE_NAME_SUFFIX_INTR"
    Private Const CSV_PAYMENTLINEVALIDATIONLOG_TITLE__LINE_NO As String = "LINE_NO"
    Private Const CSV_PAYMENTLINEVALIDATIONLOG_TITLE_SEQ As String = "SEQ"
    Private Const CSV_PAYMENTLINEVALIDATIONLOG_TITLE_ITEM As String = "ITEM"
    Private Const CSV_PAYMENTLINEVALIDATIONLOG_TITLE_VALID_ID As String = "VALID_ID"
    Private Const CSV_PAYMENTLINEVALIDATIONLOG_TITLE_DESCRIPTION As String = "DESCRIPTION"
    Private Const CSV_PAYMENTLINEVALIDATIONLOG_TITLE_VALUE_VALIDATED As String = "VALUE_VALIDATED"
    Private Const CSV_PAYMENTLINEVALIDATIONLOG_TITLE_VALUE_EXPECTED As String = "VALUE_EXPECTED"
    Private Const CSV_PAYMENTLINEVALIDATIONLOG_TITLE_RUN_STAMP As String = "RUN_STAMP"

    ''個別詳細Validationlogのタイトル
    Private Const CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_RESULT As String = "RESULT"
    Private Const CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_CPNO As String = "CPNO"
    Private Const CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_CONTRACT As String = "CONTRACT"
    Private Const CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_FILE_NAME As String = "FILE_NAME"
    Private Const CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_FILE_NAME_SUFFIX As String = "FILE_NAME_SUFFIX"
    Private Const CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_FILE_NAME_SUFFIX_INTR As String = "FILE_NAME_SUFFIX_INTR"
    Private Const CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE__LINE_NO As String = "LINE_NO"
    Private Const CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_SEQ As String = "SEQ"
    Private Const CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_ITEM As String = "ITEM"
    Private Const CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_VALID_ID As String = "VALID_ID"
    Private Const CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_DESCRIPTION As String = "DESCRIPTION"
    Private Const CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_VALUE_VALIDATED As String = "VALUE_VALIDATED"
    Private Const CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_VALUE_EXPECTED As String = "VALUE_EXPECTED"
    Private Const CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_RUN_STAMP As String = "RUN_STAMP"

    Public Const CD_PROC_OLD As Integer = 0
    Public Const CD_PROC_NEW As Integer = 1

    Public Enum eTemplatePtn
        PaymentSheet
        PaymentSheetValidation
        PaymentSheetReference
        Detail
        DetailValidation
        DetailReference
    End Enum

#End Region

#Region "変数"
    Private _CsvDirPath As String
    Private _ExcelFormatFileDirPath As String
    Private _ExcelExportFileDirPath As String
    Private _blnLockFlg As Boolean
    Private _CpNo As String
    Private _ContractNo As String
    ''Chis項目と、修正前の項目の対応表をセット
    Dim ChangePaymentLineColumn() As Integer

#End Region

#Region "プロパティ"
    Private Property CsvDirPath As String
        Get
            Return _CsvDirPath
        End Get
        Set(ByVal value As String)
            _CsvDirPath = value
        End Set
    End Property

    Private Property ExcelFormatFileDirPath As String
        Get
            Return _ExcelFormatFileDirPath
        End Get
        Set(ByVal value As String)
            _ExcelFormatFileDirPath = value
        End Set
    End Property

    Private Property ExcelExportFileDirPath As String
        Get
            Return _ExcelExportFileDirPath
        End Get
        Set(ByVal value As String)
            _ExcelExportFileDirPath = value
        End Set
    End Property

    Public Property CpNo As String
        Get
            Return _CpNo
        End Get
        Set(ByVal value As String)
            _CpNo = value
        End Set
    End Property
    Public Property ContractNo As String
        Get
            Return _ContractNo
        End Get
        Set(ByVal value As String)
            _ContractNo = value
        End Set
    End Property
#End Region

#Region "コンストラクタ"
    Sub New()
        ''CSVファイルのフォルダ位置
        System.Environment.CurrentDirectory = Application.StartupPath
        CsvDirPath = System.IO.Path.GetFullPath("../CSV")
        ''CSVフォーマットファイルのフォルダ位置
        ExcelFormatFileDirPath = System.IO.Path.GetFullPath("../Template")
        ''Excelのエクスポートファイルのフォルダ位置
        ExcelExportFileDirPath = System.IO.Path.GetFullPath("../Excel")
    End Sub
#End Region

#Region "パブリックメソッド"

    Public Function OptputExcelFromCsvValRef(ByVal intImportCd As Integer,
                                             ByVal strFileName As String,
                                             ByVal strCpno As String,
                                             ByVal strWorkCsvPath As String,
                                             ByVal intTextStartRow As Integer,
                                             ByVal strStartRange As String,
                                             ByRef OUTERR As OutputErrorList,
                                             ByRef OutPutFilePath As String,
                                             ByRef OutPutFileName As String,
                                             ByRef errCount As Integer) As Integer

        '初期化
        Dim intRetCnt As Integer = -1
        Dim blnRet As Boolean
        Dim strWorkCsvFileName As String
        Dim strMsg As String

        OptputExcelFromCsvValRef = -1

        Try

            '-------------------------------------------
            'ファイルの存在チェック
            '-------------------------------------------
            blnRet = CheckCsvFile(strFileName, OUTERR)
            If blnRet = False Then
                Exit Function
            End If

            '-------------------------------------------
            'フォーマットExcelファイルの存在チェック
            '-------------------------------------------
            blnRet = CheckTempleteFile(intImportCd, OUTERR)
            If blnRet = False Then
                Exit Function
            End If

            '-------------------------------------------
            'フォーマットExcelファイルのコピー
            '-------------------------------------------
            blnRet = CopyTemplateExcelFile(intImportCd, strFileName, OutPutFilePath, OutPutFileName, OUTERR, "")
            If blnRet = False Then
                Exit Function
            End If

            '-------------------------------------------
            'ファイルの構造チェック
            '-------------------------------------------
            Select Case intImportCd
                Case eTemplatePtn.PaymentSheetValidation
                    blnRet = CheckPaymentValidationLog(strFileName, strCpno, OUTERR)
                    strWorkCsvFileName = strWorkCsvPath & "WorkCsv_PsVal_" & Now.ToString("yyyyMMdd_HHmmss") & ".csv"
                Case eTemplatePtn.PaymentSheetReference
                    blnRet = CheckPaymentReference(strFileName, strCpno, OUTERR)
                    strWorkCsvFileName = strWorkCsvPath & "WorkCsv_PsRef_" & Now.ToString("yyyyMMdd_HHmmss") & ".csv"
                Case eTemplatePtn.DetailValidation
                    blnRet = CheckPaymentDetailValidationLog(strFileName, strCpno, OUTERR)
                    strWorkCsvFileName = strWorkCsvPath & "WorkCsv_PsdVal_" & Now.ToString("yyyyMMdd_HHmmss") & ".csv"
                Case eTemplatePtn.DetailReference
                    blnRet = CheckPaymentDetailReference(strFileName, strCpno, OUTERR)
                    strWorkCsvFileName = strWorkCsvPath & "WorkCsv_PsdRef_" & Now.ToString("yyyyMMdd_HHmmss") & ".csv"
            End Select
            If blnRet = False Then
                Exit Function
            End If

            '-------------------------------------------
            'EXCEL出力
            '-------------------------------------------
            errCount = 0
            intRetCnt = OptputExcelValRef(strFileName,
                                          OutPutFileName,
                                          strWorkCsvFileName,
                                          intTextStartRow,
                                          strStartRange,
                                          OUTERR,
                                          errCount)
            'ｴﾗｰﾒｯｾｰｼﾞ表示
            If intRetCnt = CD_RET_ERR_NO_EOF Or intRetCnt = CD_RET_ERR_UNMATCH_EOF Then
                Select Case intImportCd
                    Case eTemplatePtn.PaymentSheetValidation
                        If intRetCnt = CD_RET_ERR_NO_EOF Then
                            strMsg = FileReader.GetMessage("MSG_0240")
                        ElseIf intRetCnt = CD_RET_ERR_UNMATCH_EOF Then
                            strMsg = FileReader.GetMessage("MSG_0241")
                        End If
                    Case eTemplatePtn.PaymentSheetReference
                        If intRetCnt = CD_RET_ERR_NO_EOF Then
                            strMsg = FileReader.GetMessage("MSG_0243")
                        ElseIf intRetCnt = CD_RET_ERR_UNMATCH_EOF Then
                            strMsg = FileReader.GetMessage("MSG_0244")
                        End If
                    Case eTemplatePtn.DetailValidation
                        If intRetCnt = CD_RET_ERR_NO_EOF Then
                            strMsg = FileReader.GetMessage("MSG_0248")
                        ElseIf intRetCnt = CD_RET_ERR_UNMATCH_EOF Then
                            strMsg = FileReader.GetMessage("MSG_0249")
                        End If
                    Case eTemplatePtn.DetailReference
                        If intRetCnt = CD_RET_ERR_NO_EOF Then
                            strMsg = FileReader.GetMessage("MSG_0251")
                        ElseIf intRetCnt = CD_RET_ERR_UNMATCH_EOF Then
                            strMsg = FileReader.GetMessage("MSG_0252")
                        End If
                End Select
                MsgBox(strMsg, vbCritical, "Import")
            End If

            OptputExcelFromCsvValRef = intRetCnt

        Catch ex As Exception
            OUTERR.OutImportErrorList(ex.Message, "Import")
        End Try

    End Function

    ''' <summary>
    ''' 概　要：個別詳細/統合PS反映にて、Csvを読み込み、PaymentLineシートへ出力
    ''' 説　明：CsvTemp内のPayment csvを読みこんで出力する。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function OutPutExcelFromCsvTempPs(ByRef PSSheet As Excel.Worksheet, _
                                             ByRef OUTERR As OutputErrorList,
                                             ByVal strFileName() As String, _
                                             ByVal cntFileItem As Integer) As Integer

        Dim PaymentCount As Integer = 0
        Dim intMaxFileSeq As Integer = 0
        Try
            ''データテーブルの定義
            Dim exldatatable As New DataTable
            Dim csvdatatable As New DataTable
            Dim sortdatatable As New DataTable
            For cnt As Integer = 0 To 358
                exldatatable.Columns.Add("COL" + cnt.ToString(), Type.GetType("System.String"))
                csvdatatable.Columns.Add("COL" + cnt.ToString(), Type.GetType("System.String"))
                sortdatatable.Columns.Add("COL" + cnt.ToString(), Type.GetType("System.String"))
            Next

            ''Excelの行数をセット
            ''※N行削除のため、使用
            exldatatable.Columns.Add("ExcelRow", Type.GetType("System.String"))
            exldatatable.Columns.Add("FileNMWithoutExtension", Type.GetType("System.String"))

            exldatatable.Columns.Add("Sort_RefNLine", Type.GetType("System.String"))            ''Sort項目：紐づくN行が存在するかどうか？
            exldatatable.Columns.Add("Sort_CsvTmpNM", Type.GetType("System.String"))            ''Sort項目：CSVTmpファイル名
            exldatatable.Columns.Add("Sort_ISNLine", Type.GetType("System.String"))             ''Sort項目：N行名
            csvdatatable.Columns.Add("Sort_RefNLine", Type.GetType("System.String"))            ''Sort項目：紐づくN行が存在するかどうか？
            csvdatatable.Columns.Add("Sort_CsvTmpNM", Type.GetType("System.String"))            ''Sort項目：CSVTmpファイル名
            csvdatatable.Columns.Add("Sort_ISNLine", Type.GetType("System.String"))             ''Sort項目：N行名

            'ExcelのPSのデータをテーブルに格納する
            Dim maxLineNoes As New Dictionary(Of String, String)
            Dim excelPaymentLineCount As Integer
            Call GetPSData(PSSheet, _
                           exldatatable, _
                           maxLineNoes, _
                           intMaxFileSeq, _
                           excelPaymentLineCount)

            ''PaymentSheetCsvファイルの読込
            Dim i As Integer
            For i = 0 To cntFileItem - 1

                ''ファイルの存在チェック
                If CheckCsvFile(strFileName(i), OUTERR) = False Then
                    Return -1
                    Exit Function
                End If
                PaymentCount = PaymentCount + ReadCSV(strFileName(i), csvdatatable)

            Next

            ''Csvファイルと一致するN行の情報を追加する。
            Dim delPaymentRows() As Integer                     ''Paymentから削除するN行のExcel行の位置
            Call inportNLine(csvdatatable, exldatatable, intMaxFileSeq, delPaymentRows)

            '案件番号、有効無効FLG、ファイル名でソートする。
            Dim dvSort As DataView = New DataView(csvdatatable)
            dvSort.Sort = "Sort_RefNLine, Sort_CsvTmpNM, Sort_ISNLine, COL10, COL2, COL4 ASC"
            sortdatatable = dvSort.ToTable()

            '仮シリアル再採番
            sortdatatable = inportSeqNo(sortdatatable, intMaxFileSeq)

            '行番を振る
            sortdatatable = inportLineNo(sortdatatable, maxLineNoes, CommonVariable.CONTRACTNO.ToString.PadLeft(3, "0"))

            'Cost%を振る
            sortdatatable = inportCost(sortdatatable, maxLineNoes)

            ''取込前のExcelファイルのデータは上書きしない。
            Dim startOutputRow As Integer
            startOutputRow = excelPaymentLineCount - delPaymentRows.Length + ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW

            'Excelに書込む
            Call WriteExcel(PSSheet, _
                            sortdatatable, _
                            startOutputRow, _
                            delPaymentRows)

        Catch ex As Exception
            MsgBox(FileReader.GetMessage("MSG_0273"), MsgBoxStyle.Exclamation)
            OUTERR.OutputErrorList2(ex.Message, "BPMakeExchange")
            Return -1

        End Try
        Return PaymentCount

    End Function

    ''' <summary>
    ''' 機能：作業用CSVﾌｧｲﾙをPaymentに出力
    ''' </summary>
    ''' <param name="strCsvFileName">作業用CSVﾌｧｲﾙ名</param>
    ''' <param name="intOuntputCnt">ﾃﾞｰﾀ件数</param>
    ''' <param name="intPaymentPeriod">Payment展開期間</param>
    ''' <param name="xlSheet">ｼｰﾄｵﾌﾞｼﾞｪｸﾄ名</param>
    ''' <param name="OUTERR">ｴﾗｰｵﾌﾞｼﾞｪｸﾄ</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function OutputExcelPs(ByVal strCsvFileName As String,
                                  ByVal intOuntputCnt As Integer,
                                  ByVal intPaymentPeriod As Integer,
                                  ByRef xlSheet As Excel.Worksheet,
                                  ByRef OUTERR As OutputErrorList
                                  ) As Integer

        Const OUTPUT_DATA_COUNT As Integer = 50

        Dim xlCell As Excel.Range
        Dim xlRange As Excel.Range
        Dim xlEntireRow As Excel.Range
        Dim xlSRange1 As Excel.Range
        Dim xlSRange2 As Excel.Range
        Dim strRange As String
        Dim intSho As Integer
        Dim intAmari As Integer
        Dim intCnt As Integer
        Dim intShoCnt As Integer = 1
        Dim intY As Integer = 1

        OutputExcelPs = -1

        Try
            '==========================================================
            '罫線作成
            '==========================================================
            'Template行表示
            xlCell = xlSheet.Range("2:2")
            xlEntireRow = xlCell.EntireRow
            xlEntireRow.Hidden = False
            ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)
            xlCell.Copy()
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            Const COPY_TEMPLATE_ROW As Integer = 5000

            intSho = intOuntputCnt \ COPY_TEMPLATE_ROW
            intAmari = intOuntputCnt Mod COPY_TEMPLATE_ROW

            For intCnt = 1 To intSho
                strRange = (ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW).ToString() + (intCnt - 1) * COPY_TEMPLATE_ROW & ":" & (ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + intCnt * COPY_TEMPLATE_ROW - 1).ToString()
                xlRange = xlSheet.Range(strRange)
                xlRange.PasteSpecial()
                ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            Next
            If intAmari > 0 Then
                strRange = (ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW).ToString() + (intCnt - 1) * COPY_TEMPLATE_ROW & ":" & (ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + (intCnt - 1) * COPY_TEMPLATE_ROW + intAmari - 1).ToString()
                xlRange = xlSheet.Range(strRange)
                xlRange.PasteSpecial()
                ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            End If

            xlCell = xlSheet.Range("2:2")
            xlEntireRow = xlCell.EntireRow
            xlEntireRow.Hidden = True
            ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            '=====================================================
            'データ出力
            '=====================================================
            Dim arDataType(ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12 - 1) As Integer
            SetExcelDataTypePayment(arDataType)
            Call ExcelWrite.LoadCsvToExcel(strCsvFileName, 1, "Payment", "A6", xlSheet, arDataType)

            '==========================================================
            'ソート
            '==========================================================
            xlRange = xlSheet.Rows(ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW & ":" & EXCEL_PAYMENTLINEDATE_ENDROW)
            xlSRange1 = xlSheet.Cells(ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW, ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12 + 2)
            xlSRange2 = xlSheet.Cells(ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)
            Call xlRange.Sort(Key1:=xlSRange1, Key2:=xlSRange2, Orientation:=Excel.XlSortOrientation.xlSortColumns)
            xlRange = xlSheet.Columns(ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12 + 1)
            xlRange.Value = ""

            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)

            OutputExcelPs = intOuntputCnt

        Catch ex As Exception
            ''例外の処理
            OUTERR.OutImportErrorList(ex.Message, "Import")

        Finally
            'エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSRange2, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSRange1, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            ''ガベージコレクトの起動
            GC.Collect()

        End Try

    End Function

    ''' <summary>
    ''' 機能：作業用CSVﾌｧｲﾙを詳細に出力
    ''' </summary>
    ''' <param name="strCsvFileName">作業用ﾌｧｲﾙ名</param>
    ''' <param name="intOuntputCnt">ﾃﾞｰﾀ件数</param>
    ''' <param name="xlSheet">ｼｰﾄｵﾌﾞｼﾞｪｸﾄ</param>
    ''' <param name="OUTERR">ｴﾗｰｵﾌﾞｼﾞｪｸﾄ</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function OutputExcelPsd(ByVal strCsvFileName As String,
                                   ByVal intOuntputCnt As Integer,
                                   ByRef xlSheet As Excel.Worksheet,
                                   ByRef OUTERR As OutputErrorList
                                   ) As Integer

        Const OUTPUT_DATA_COUNT As Integer = 5000

        Dim intSho As Integer
        Dim intAmari As Integer
        Dim intCnt As Integer
        Dim xlRange As Excel.Range = Nothing
        Dim xlCell As Excel.Range
        Dim xlEntireRow As Excel.Range
        Dim strRange As String
        Dim intDataType() As Integer = {2, 2, 2, 1, 2, 1, 1, 1, 2, 2, 2, 5, 5, 5, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1}

        OutputExcelPsd = -1

        Try
            '==========================================================
            '罫線作成
            '==========================================================
            'Template行表示
            xlCell = xlSheet.Range("3:3")
            xlEntireRow = xlCell.EntireRow
            xlEntireRow.Hidden = False
            ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)
            xlCell.Copy()
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            Const COPY_TEMPLATE_ROW As Integer = 1000

            intSho = intOuntputCnt \ COPY_TEMPLATE_ROW
            intAmari = intOuntputCnt Mod COPY_TEMPLATE_ROW

            For intCnt = 1 To intSho
                strRange = (ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW).ToString() + (intCnt - 1) * COPY_TEMPLATE_ROW & ":" & (ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW + intCnt * COPY_TEMPLATE_ROW - 1).ToString()
                xlRange = xlSheet.Range(strRange)
                xlRange.PasteSpecial()
                ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            Next
            If intAmari > 0 Then
                strRange = (ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW).ToString() + (intCnt - 1) * COPY_TEMPLATE_ROW & ":" & (ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW + (intCnt - 1) * COPY_TEMPLATE_ROW + intAmari - 1).ToString()
                xlRange = xlSheet.Range(strRange)
                xlRange.PasteSpecial()
                ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            End If

            xlCell = xlSheet.Range("3:3")
            xlEntireRow = xlCell.EntireRow
            xlEntireRow.Hidden = True
            ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            '=====================================================
            'データ出力
            '=====================================================
            Call LoadCsvToExcel(strCsvFileName, 1, "詳細", "A7", xlSheet, intDataType)

            OutputExcelPsd = intOuntputCnt

        Catch ex As Exception
            ''例外の処理
            OUTERR.OutImportErrorList(ex.Message, "Import")

        Finally
            'エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            'ガベージコレクトの起動
            GC.Collect()

        End Try

    End Function

    ''' <summary>
    ''' 機能：PaymentCSVﾃﾞｰﾀを配列に格納
    ''' </summary>
    ''' <param name="intImportCd"></param>
    ''' <param name="strFileName"></param>
    ''' <param name="intPaymentPeriod"></param>
    ''' <param name="alPsCreating"></param>
    ''' <param name="alPsCreatingMdb"></param>
    ''' <param name="alPsCreated"></param>
    ''' <param name="errCount"></param>
    ''' <param name="OUTERR"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetPsCsvData(ByVal intImportCd As Integer,
                                  ByVal strFileName As String,
                                  ByVal intPaymentPeriod As Integer,
                                  ByRef alPsCreating As ArrayList,
                                  ByRef alPsCreatingMdb As ArrayList,
                                  ByRef alPsCreated As ArrayList,
                                  ByRef errCount As Integer,
                                  ByRef OUTERR As OutputErrorList) As Integer

        ''初期化
        GetPsCsvData = -1

        'ファイル操作
        Dim Reader As StreamReader
        Dim CsvCountALL As Integer      ''CSVの出力件数全て
        Dim CsvCount As Integer         ''CSVの件数のうち、個別PSに出力する件数のみカウント
        Dim StrLine As String
        Dim StrSplitLine() As String
        Dim strCpno As String = ""
        Dim strTemp() As String
        Dim con As OleDbConnection
        Dim mmc As New MasterMdbControl
        Dim objCreating() As Object
        Dim objCreatingMdb() As Object
        Dim objCreated() As Object

        Try
            'ファイルの存在チェック
            If CheckCsvFile(strFileName, OUTERR) = False Then
                Exit Function
            End If

            'ファイルの構造チェック(PaymentSheet)
            If CheckPaymentLine(strFileName, OUTERR) = False Then
                Exit Function
            End If

            con = mmc.GetOleDBConnection(CommonVariable.MdbPW)


            ''=====================================================
            ''					CSVﾌｧｲﾙの読込み準備			
            ''=====================================================
            ''ファイルオブジェクト作成
            Dim strOutFileName As String = Path.GetFileName(strFileName)
            Reader = New StreamReader(strFileName, Encoding.GetEncoding("shift-jis"))

            'PaymentLineの開始位置まで読込み
            Dim i As Integer = 0
            For i = 1 To CSV_PAYMENTLINE_CHECK_PAYMENTLINETITLEROW
                Call Reader.ReadLine()
            Next

            '=====================================================
            '		　　　　Excel出力に必要な基本情報の取得			
            '=====================================================
            'PaymentLineExcelに出力する式を取得
            Dim xmlPaymentLineFomulateInfo As PaymentLineFomulateInfo
            xmlPaymentLineFomulateInfo = ExcelWrite.GetPaymentExcelFomulate


            '契約基本情報のセット
            strCpno = CommonVariable.CPNO


            'Import用：QCOS HWMAの保証種類変換データテーブルの取得
            Dim control As New AdminControl
            Dim qcosWarrantytermCode As CodeTable
            qcosWarrantytermCode = control.GetCodeData(CommonConstant.CODE_CLASSCODE_QCOSWARRANTYTERM, CommonVariable.MdbPW)


            'Import用：BU、Brand変換テーブルの取得(ConvertClientValue)
            Dim clientValueTable As DataTable
            clientValueTable = GetClientValueTable()

            ''1555 ServicePac テーブルの取得 str
            Dim ServicePacTable As DataTable
            ServicePacTable = GetServicePacTable()
            ''1555 ServicePac テーブルの取得 end


            'ChisCsvとExcel項目の対応表を作成する。
            Call SetChangePaymentLineColumn()

            '==========================================================
            '				   CSVファイルの読込処理 ▼
            '==========================================================            
            Dim LOBNMUnMatchMessage As String                           ''CSVファイルのLOB名称が、MDBテーブルに存在するかどうか？
            Dim strRange As String
            CsvCountALL = 0
            CsvCount = 0
            Do
                Try
                    ''CSVの1行分のデータを読込み
                    StrLine = Reader.ReadLine()

                    ''Csvファイルが読み込めなくなったら処理を終了
                    If IsNothing(StrLine) Then
                        Exit Do
                    End If

                    ''CSVの1行分の情報を","を基準に配列に格納する。
                    Call SplitData(StrLine, StrSplitLine)

                    ''Eof行が存在しない場合
                    If IsNothing(StrLine) = True Then
                        OUTERR.OutImportErrorList(FileReader.GetMessage("MSG_0238"), "Import")
                        GetPsCsvData = -2
                        Exit Function
                    End If

                    ''Eof行(CSVファイルの最後の行にEOFと記載)の処理
                    If StrLine.IndexOf("EOF") = 0 Then
                        If CsvCountALL <> StrSplitLine(1) Then
                            OUTERR.OutImportErrorList(FileReader.GetMessage("MSG_0214"), "Import")
                            GetPsCsvData = -2
                            Exit Function
                        Else
                            Exit Do
                        End If
                    End If

                    CsvCountALL = CsvCountALL + 1

                    ''Csvの固定値"null"を0へ変換
                    Call ChangeCsvDataNullToZero(StrSplitLine)

                    '処理区分が作成中のみ且つ締結済みデータ(LOCK_FLAG='C')の場合、次データへ
                    If intImportCd = ImportCsv.CD_IMPORT_CSV Then
                        If (StrSplitLine(CsvPaymentLineColumn.LOCK_FLAG - 1) = "C" Or
                            StrSplitLine(CsvPaymentLineColumn.CONTRACT - 1) <> CommonVariable.CONTRACTNO.ToString) Then
                            Continue Do
                        End If
                    End If

                    '1700 str
                    If IsDate(StrSplitLine(CsvPaymentLineColumn.PROD_ITEM11 - 1)) = True Then
                        StrSplitLine(CsvPaymentLineColumn.PROD_ITEM11 - 1) = CDate(StrSplitLine(CsvPaymentLineColumn.PROD_ITEM11 - 1)).ToString("yyyy/MM/dd")
                    End If

                    If IsDate(StrSplitLine(CsvPaymentLineColumn.PROD_ITEM12 - 1)) = True Then
                        StrSplitLine(CsvPaymentLineColumn.PROD_ITEM12 - 1) = CDate(StrSplitLine(CsvPaymentLineColumn.PROD_ITEM12 - 1)).ToString("yyyy/MM/dd")
                    End If
                    '1700 ebd


                    Erase objCreating
                    Erase objCreatingMdb
                    Erase objCreated
                    LOBNMUnMatchMessage = ""

                    'セルに値を代入(作成中)
                    If intImportCd = ImportCsv.CD_IMPORT_CSV Or intImportCd = ImportCsv.CD_IMPORT_CSVMDB Then
                        If StrSplitLine(CsvPaymentLineColumn.CONTRACT - 1) = CommonVariable.CONTRACTNO Then
                            If StrSplitLine(CsvPaymentLineColumn.LOCK_FLAG - 1) = "P" Then
                                ''1555 ServicePac TBLの登録可能期限を廃止予定日にセット str
                                'objCreating = SetWriteExcelObjLineConclusion(StrSplitLine, qcosWarrantytermCode, clientValueTable)
                                objCreating = SetWriteExcelObjLineConclusion(StrSplitLine, qcosWarrantytermCode, clientValueTable, ServicePacTable)
                                ''1555 ServicePac TBLの登録可能期限を廃止予定日にセット end
                                ReDim Preserve objCreating(ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12)
                            ElseIf StrSplitLine(CsvPaymentLineColumn.LOCK_FLAG - 1) = "" Then
                                ''1555 ServicePac TBLの登録可能期限を廃止予定日にセット str
                                'objCreating = SetWriteExcelObjLine(con, StrSplitLine, qcosWarrantytermCode, clientValueTable, LOBNMUnMatchMessage)
                                objCreating = SetWriteExcelObjLine(con, StrSplitLine, qcosWarrantytermCode, clientValueTable, ServicePacTable, LOBNMUnMatchMessage)
                                ''1555 ServicePac TBLの登録可能期限を廃止予定日にセット end
                                ReDim Preserve objCreating(ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12)
                            End If
                        End If
                    End If

                    'セルに値を代入(MDB)
                    If intImportCd = ImportCsv.CD_IMPORT_MDB Or intImportCd = ImportCsv.CD_IMPORT_CSVMDB Then
                        If StrSplitLine(CsvPaymentLineColumn.LOCK_FLAG - 1) = "C" Then
                            '契約済
                            ''1555 ServicePac TBLの登録可能期限を廃止予定日にセット str
                            'objCreated = SetWriteExcelObjLineConclusion(StrSplitLine, qcosWarrantytermCode, clientValueTable)
                            objCreated = SetWriteExcelObjLineConclusion(StrSplitLine, qcosWarrantytermCode, clientValueTable, ServicePacTable)
                            ''1555 ServicePac TBLの登録可能期限を廃止予定日にセット end
                            ReDim Preserve objCreated(ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12)
                        ElseIf StrSplitLine(CsvPaymentLineColumn.LOCK_FLAG - 1) = "P" Then
                            '未契約済
                            ''1555 ServicePac TBLの登録可能期限を廃止予定日にセット str
                            'objCreatingMdb = SetWriteExcelObjLineConclusion(StrSplitLine, qcosWarrantytermCode, clientValueTable)
                            objCreatingMdb = SetWriteExcelObjLineConclusion(StrSplitLine, qcosWarrantytermCode, clientValueTable, ServicePacTable)
                            ''1555 ServicePac TBLの登録可能期限を廃止予定日にセット end
                            ReDim Preserve objCreatingMdb(ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12)
                        End If
                    End If

                    'CSVのLOB名称にMDBの値がマッチしない場合、価格計画確認用にログを出力する。
                    If LOBNMUnMatchMessage <> "" Then
                        OUTERR.OutImportErrorList(LOBNMUnMatchMessage, "Import", ExcelWrite.changeDBNullToString(StrSplitLine(CsvPaymentLineColumn.LINE_NO - 1)))
                    End If

                    'Excel式をセット
                    If intImportCd = ImportCsv.CD_IMPORT_CSV Or intImportCd = ImportCsv.CD_IMPORT_CSVMDB Then
                        If StrSplitLine(CsvPaymentLineColumn.CONTRACT - 1) = CommonVariable.CONTRACTNO Then
                            ''※締結済み、価格承認済みは、CSVの値をそのままセット
                            If StrSplitLine(CsvPaymentLineColumn.LOCK_FLAG - 1) <> "C" And
                               StrSplitLine(CsvPaymentLineColumn.LOCK_FLAG - 1) <> "P" Then
                                Call ExcelWrite.SetPaymentExcelFomulateForObj(xmlPaymentLineFomulateInfo, -1, ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + CsvCount, objCreating, StrSplitLine)
                            End If
                        End If
                    End If

                    'Excel出力用配列から、Nothin、Nullを除外
                    Call SetPsData(objCreating)
                    Call SetPsData(objCreatingMdb)
                    Call SetPsData(objCreated)

                    'Payment展開期間の値設定
                    For intYearCnt As Integer = 1 To 20
                        If intYearCnt > intPaymentPeriod Then
                            '作成中
                            If Not objCreating Is Nothing Then
                                '年額展開金額
                                objCreating(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1 + (intYearCnt - 1) - 1) = "0"
                                '月額展開金額
                                For intMonthCnt As Integer = 1 To 12
                                    objCreating(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1 + ((intYearCnt - 1) * 12 + intMonthCnt - 1) - 1) = "0"
                                Next
                            End If

                            '未契約済
                            If Not objCreatingMdb Is Nothing Then
                                '年額展開金額
                                objCreatingMdb(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1 + (intYearCnt - 1) - 1) = "0"
                                '月額展開金額
                                For intMonthCnt As Integer = 1 To 12
                                    objCreatingMdb(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1 + ((intYearCnt - 1) * 12 + intMonthCnt - 1) - 1) = "0"
                                Next
                            End If

                            '契約済
                            If Not objCreated Is Nothing Then
                                '年額展開金額
                                objCreated(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1 + (intYearCnt - 1) - 1) = "0"
                                '月額展開金額
                                For intMonthCnt As Integer = 1 To 12
                                    objCreated(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1 + ((intYearCnt - 1) * 12 + intMonthCnt - 1) - 1) = "0"
                                Next
                            End If
                        End If
                    Next

                    If intImportCd = ImportCsv.CD_IMPORT_CSV Or intImportCd = ImportCsv.CD_IMPORT_CSVMDB Then
                        If Not objCreating Is Nothing Then
                            'Sort順設定
                            objCreating(objCreating.Length - 1) = "2"
                            '作成中ﾃﾞｰﾀをセット
                            Call alPsCreating.Add(objCreating)
                            CsvCount = CsvCount + 1
                        End If
                    End If

                    If intImportCd = ImportCsv.CD_IMPORT_MDB Or intImportCd = ImportCsv.CD_IMPORT_CSVMDB Then
                        If Not objCreatingMdb Is Nothing Then
                            'Sort順設定
                            objCreatingMdb(objCreatingMdb.Length - 1) = "2"
                            '作成中ﾃﾞｰﾀをセット
                            Call alPsCreatingMdb.Add(objCreatingMdb)
                        End If
                        If Not objCreated Is Nothing Then
                            'Sort順設定
                            objCreated(objCreated.Length - 1) = "1"
                            '締結済ﾃﾞｰﾀをセット
                            Call alPsCreated.Add(objCreated)
                        End If
                    End If

                Catch ex As Exception

                    ''取込エラー件数の更新
                    ''※取込エラーが1件以上あれば、処理終了時にログを参照するように通知する。
                    errCount = errCount + 1
                    OUTERR.OutImportErrorList(ex.Message, "Import", ExcelWrite.changeDBNullToString(StrSplitLine(CsvPaymentLineColumn.LINE_NO - 1)))

                End Try

            Loop

            GetPsCsvData = CsvCount

        Catch ex As Exception

            ''例外の処理
            OUTERR.OutImportErrorList(ex.Message, "Import")
            Return -1

        Finally

            ''ファイルオブジェクトの解放
            If IsNothing(Reader) = False Then
                Reader = Nothing
            End If

            If IsNothing(con) = False AndAlso _
               con.State = ConnectionState.Open Then
                Call con.Close()
            End If


            ''ガベージコレクトの起動
            GC.Collect()

        End Try

    End Function

    ''' <summary>
    ''' 機能：詳細CSVﾃﾞｰﾀを配列に格納
    ''' </summary>
    ''' <param name="intImportCd"></param>
    ''' <param name="strFileName"></param>
    ''' <param name="strCpno"></param>
    ''' <param name="alPsdCreating"></param>
    ''' <param name="alPsdCreatingMdb"></param>
    ''' <param name="alPsdCreated"></param>
    ''' <param name="errCount"></param>
    ''' <param name="OUTERR"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetPsdCsvData(ByVal intImportCd As Integer,
                                  ByVal strFileName As String,
                                  ByVal strCpno As String,
                                  ByRef alPsdCreating As ArrayList,
                                  ByRef alPsdCreatingMdb As ArrayList,
                                  ByRef alPsdCreated As ArrayList,
                                  ByRef errCount As Integer,
                                  ByRef OUTERR As OutputErrorList) As Integer

        ''ファイル操作
        Dim Reader As StreamReader
        Dim CsvCount As Integer
        Dim StrLine As String
        Dim StrSplitLine() As String
        Dim OutCount As Integer = 0             ''Excelに出力する件数
        Dim NormalFomula As PaymentLineDetailFomulateInfo       ''通常行のExcel式
        Dim RowValue(,) As Object
        Dim summaryRowList As New ArrayList
        Dim SummaryFomula As New PaymentLineDetailFomulateInfo
        Dim objCreating() As Object         '作成中
        Dim objCreatingMdb() As Object      '未契約済MDB
        Dim objCreated() As Object          '契約済MDB

        GetPsdCsvData = -1

        Try
            ''ファイルの存在チェック
            If CheckCsvFile(strFileName, OUTERR) = False Then
                Exit Function
            End If

            ''ファイルの構造チェック
            '個別詳細
            If CheckPaymentDetailLine(strFileName, strCpno, OUTERR) = False Then
                Exit Function
            End If

            ''ファイルオブジェクト作成
            Reader = New StreamReader(strFileName, Encoding.GetEncoding("shift-jis"))

            ''Excelのﾃﾝﾌﾟﾚｰﾄ行の式を取得　※通常行/サマリ行
            NormalFomula = ExcelWrite.GetDetailExcelFomulate
            SummaryFomula = ExcelWrite.GetDetailSummaryExcelFomulate

            ''PaymentLineの開始位置まで読込み
            For i As Integer = 1 To CSV_PAYMENTLINEDETAIL_CHECK_DATAROW
                Call Reader.ReadLine()
            Next

            ''CSVファイルの読込処理
            Dim tmpDetailLinkDate As ExcelWrite.DetailLinkInfo      ''1行分の値：DetailLinkDate 
            Do
                Try

                    StrLine = Reader.ReadLine()
                    If IsNothing(StrLine) Then
                        '無限ループ防止（読み込めなくなったらループ抜ける）
                        Exit Do
                    End If

                    'カンマ区切りのデータを分解する
                    Call SplitData(StrLine, StrSplitLine)

                    'Csvの数字項目の"null"を0へ変換する。
                    Call ChangeDetailCsvDataNullToZero(StrSplitLine)

                    ''Eof行が存在しない場合
                    If IsNothing(StrLine) = True Then
                        MsgBox(FileReader.GetMessage("MSG_0260"), vbCritical, "Import")
                        Exit Function
                    End If

                    ''Eof行の処理
                    If StrLine.IndexOf("EOF") = 0 Then
                        ''Eof行に記載された行数とExcelへ出力された行数の比較
                        If CsvCount <> StrSplitLine(1) Then
                            MsgBox(FileReader.GetMessage("MSG_0246"), vbCritical, "Import")
                            Exit Function
                        Else
                            Exit Do
                        End If
                    End If

                    CsvCount = CsvCount + 1

                    If intImportCd = ImportCsv.CD_IMPORT_CSV And
                        (StrSplitLine(CsvPaymentLineDetailColumn.LOCK_FLAG - 1) = "C" Or
                         StrSplitLine(CsvPaymentLineDetailColumn.CONTRACT - 1) <> CommonVariable.CONTRACTNO.ToString) Then
                        Continue Do
                    End If

                    Erase objCreating
                    Erase objCreatingMdb
                    Erase objCreated

                    'セルに値を代入(作成中)
                    If intImportCd = ImportCsv.CD_IMPORT_CSV Or intImportCd = ImportCsv.CD_IMPORT_CSVMDB Then
                        If StrSplitLine(ExcelWrite.CsvPaymentLineDetailColumn.LOCK_FLAG - 1) <> "C" And
                            StrSplitLine(ExcelWrite.CsvPaymentLineDetailColumn.CONTRACT - 1) = CommonVariable.CONTRACTNO Then
                            objCreating = GetWriteObjLine(StrSplitLine)
                            ReDim Preserve objCreating(ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE - 1)
                            'Excel出力用オブジェクトから、Nothin、Nullを除外
                            For j As Integer = 0 To objCreating.Length - 1
                                objCreating(j) = changeDBNullToString(objCreating(j))
                            Next
                        End If
                    End If
                    'セルに値を代入(MDB)
                    If intImportCd = ImportCsv.CD_IMPORT_MDB Or intImportCd = ImportCsv.CD_IMPORT_CSVMDB Then
                        If StrSplitLine(ExcelWrite.CsvPaymentLineDetailColumn.LOCK_FLAG - 1) = "C" Then
                            '契約済
                            objCreated = GetConWriteObjLine(StrSplitLine)
                            ReDim Preserve objCreated(ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE - 1)
                            'Excel出力用オブジェクトから、Nothin、Nullを除外
                            For j As Integer = 0 To objCreated.Length - 1
                                objCreated(j) = changeDBNullToString(objCreated(j))
                            Next
                        ElseIf StrSplitLine(ExcelWrite.CsvPaymentLineDetailColumn.LOCK_FLAG - 1) = "P" Then
                            '未契約済
                            objCreatingMdb = GetConWriteObjLine(StrSplitLine)
                            ReDim Preserve objCreatingMdb(ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE - 1)
                            'Excel出力用オブジェクトから、Nothin、Nullを除外
                            For j As Integer = 0 To objCreatingMdb.Length - 1
                                objCreatingMdb(j) = changeDBNullToString(objCreatingMdb(j))
                            Next
                        End If
                    End If

                    'Excel式をセット
                    If intImportCd = ImportCsv.CD_IMPORT_CSV Or intImportCd = ImportCsv.CD_IMPORT_CSVMDB Then
                        If StrSplitLine(ExcelWrite.CsvPaymentLineDetailColumn.CONTRACT - 1) = CommonVariable.CONTRACTNO Then
                            If StrSplitLine(ExcelWrite.CsvPaymentLineDetailColumn.LOCK_FLAG - 1) <> "C" Then
                                If StrSplitLine(ExcelWrite.CsvPaymentLineDetailColumn.IDENTITY_FLAG - 1) = "S" Then
                                    ExcelWrite.SetPaymentDetailExcelFomulateForObj2(SummaryFomula, -1, ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW + OutCount, objCreating)
                                Else
                                    ExcelWrite.SetPaymentDetailExcelFomulateForObj2(NormalFomula, -1, ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW + OutCount, objCreating)
                                End If
                            End If
                        End If
                    End If

                    If intImportCd = ImportCsv.CD_IMPORT_CSV Or intImportCd = ImportCsv.CD_IMPORT_CSVMDB Then
                        If Not objCreating Is Nothing Then
                            '作成中ﾃﾞｰﾀをセット
                            Call alPsdCreating.Add(objCreating)
                        End If
                    End If

                    If intImportCd = ImportCsv.CD_IMPORT_MDB Or intImportCd = ImportCsv.CD_IMPORT_CSVMDB Then
                        If Not objCreatingMdb Is Nothing Then
                            '作成中ﾃﾞｰﾀをセット
                            Call alPsdCreatingMdb.Add(objCreatingMdb)
                        End If
                        If Not objCreated Is Nothing Then
                            '締結済ﾃﾞｰﾀをセット
                            Call alPsdCreated.Add(objCreated)
                        End If
                    End If

                Catch ex As Exception
                    ''取込エラー件数の更新
                    ''※取込エラーが1件以上あれば、処理終了時にログを参照するように通知する。
                    errCount = errCount + 1
                    OUTERR.OutImportErrorListDetail(ex.Message, _
                                                    "Import", _
                                                    ExcelWrite.changeDBNullToString(StrSplitLine(CsvPaymentLineDetailColumn.FILE_NAME - 1)), _
                                                    ExcelWrite.changeDBNullToString(StrSplitLine(CsvPaymentLineDetailColumn.FILE_NAME_SUFFIX - 1)), _
                                                    ExcelWrite.changeDBNullToString(StrSplitLine(CsvPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR - 1)), _
                                                    ExcelWrite.changeDBNullToString(StrSplitLine(CsvPaymentLineDetailColumn.SEQ - 1)))
                End Try

                If (intImportCd = ImportCsv.CD_IMPORT_CSV Or intImportCd = ImportCsv.CD_IMPORT_CSVMDB) And
                    StrSplitLine(ExcelWrite.CsvPaymentLineDetailColumn.LOCK_FLAG - 1) <> "C" And
                    StrSplitLine(ExcelWrite.CsvPaymentLineDetailColumn.CONTRACT - 1) = CommonVariable.CONTRACTNO.ToString Then
                    ''サマリ行の位置をセット
                    If StrSplitLine(ExcelWrite.CsvPaymentLineDetailColumn.IDENTITY_FLAG - 1) = "S" Then
                        Call summaryRowList.Add(OutCount)
                    End If
                    OutCount = OutCount + 1
                End If
            Loop

            'サマリ行の式をセット
            If summaryRowList.Count > 0 Then
                Call SetSummaryTmplateRow(alPsdCreating, summaryRowList, SummaryFomula, OutCount)
            End If

            GetPsdCsvData = OutCount

        Catch ex As Exception

            ''例外の処理
            OUTERR.OutImportErrorList(ex.Message, "Import", ExcelWrite.changeDBNullToString(StrSplitLine(CsvPaymentLineColumn.LINE_NO - 1)))
            Return -1

        Finally
            ''ファイルオブジェクトの解放
            If IsNothing(Reader) = False Then
                Reader = Nothing
            End If

            ''ガベージコレクトの起動
            GC.Collect()

        End Try


    End Function

    ''' <summary>
    ''' 機能：作業用ﾌｧｲﾙ作成
    ''' </summary>
    ''' <param name="arData">出力ﾃﾞｰﾀ</param>
    ''' <param name="strFileName">作業用ﾌｧｲﾙ名</param>
    ''' <remarks></remarks>
    Public Sub arDataToCsv(ByVal arData As ArrayList, ByVal strFileName As String)

        Dim sw As StreamWriter
        Dim intRowCnt As Integer
        Dim intFldCnt As Integer
        Dim strLine As String
        Dim obj() As Object
        Dim strWork As String

        Try
            sw = New StreamWriter(strFileName, False, System.Text.Encoding.Default)
            For intRowCnt = 0 To (arData.Count - 1)
                Erase obj
                obj = DirectCast(arData(intRowCnt), Object())
                strLine = ""
                For intFldCnt = 0 To (obj.Length - 1)
                    strWork = obj(intFldCnt)
                    strWork = strWork.Replace("""", """""")
                    strLine = strLine & """" & strWork & ""","
                Next
                sw.WriteLine(strLine)
            Next
            sw.Close()

        Catch ex As Exception
            MsgBox(ex.Message.ToString & "(arDataToCsv)", MsgBoxStyle.Critical)
        End Try

    End Sub

#End Region

#Region "プライベートメソッド"

    '--------------------------------------------------------
    'メソッド名：GetParsentFormat
    '概    要  ：パーセント表示
    '説    明  ：00.000の形で出力する。
    '引    数  ：value = 抽出対象月月
    '戻 り 値  ：GetMMFormat = MM(String)
    '--------------------------------------------------------
    Private Function GetParsentFormat(ByVal value As Object) As Object
        GetParsentFormat = ""
        GetParsentFormat = CDbl(value).ToString("#0.000000000000000")

        Return GetParsentFormat

    End Function

    '--------------------------------------------------------
    'メソッド名：CheckCsvFile
    '概    要  ：画面でチェックしたファイルが存在するかどうかをチェック
    '説    明  ：画面でチェックしたファイルが存在するかどうかをチェック
    '引    数  ：frm =  ExcelSample画面のフォームオブジェクト
    '戻 り 値  ：CheckTempleteFile = Boolean(チェックがOKかどうか？)
    '--------------------------------------------------------
    Private Function CheckCsvFile(ByVal strFileName As String, _
                                  ByRef OUTERR As OutputErrorList) As Boolean

        CheckCsvFile = True

        ''PaymentSheetの処理
        If strFileName.Trim.Length <> 0 Then
            If File.Exists(strFileName) = False Then
                'エラーログ初期設定
                OUTERR.OutImportErrorList(FileReader.GetMessage("MSG_0220"), "Import")
                CheckCsvFile = False
            End If
        End If

    End Function

    '--------------------------------------------------------
    'メソッド名：CheckTempleteFile
    '概    要  ：既定のフォルダにExcelのTempleteファイルが存在するかどうかのチェックを行う。
    '説    明  ：既定のフォルダにExcelのTempleteファイルが存在するかどうかのチェックを行う。
    '引    数  ：frm =  ExcelSample画面のフォームオブジェクト
    '戻 り 値  ：CheckTempleteFile = Boolean(チェックがOKかどうか？)
    '--------------------------------------------------------
    Public Function CheckTempleteFile(ByVal cdTemplatePtn As Integer, _
                                       ByRef OUTERR As OutputErrorList) As Boolean

        CheckTempleteFile = True

        Select Case cdTemplatePtn
            Case eTemplatePtn.PaymentSheet
                ''PaymentSheet
                If File.Exists(ExcelFormatFileDirPath & "\" & EXCEL_PAYMENTLINE_TEMPLETEFILENM) = False Then
                    OUTERR.OutImportErrorList(FileReader.GetMessage("MSG_0221") & "パス：" & ExcelFormatFileDirPath & "\" & EXCEL_PAYMENTLINE_TEMPLETEFILENM, "Import")
                    CheckTempleteFile = False
                End If
            Case eTemplatePtn.PaymentSheetValidation
                ''PaymentValidation
                If File.Exists(ExcelFormatFileDirPath & "\" & EXCEL_PAYMENTLINEVALIDATIONLOG_TEMPLETEFILENM) = False Then
                    OUTERR.OutImportErrorList(FileReader.GetMessage("MSG_0221") & "パス：" & ExcelFormatFileDirPath & "\" & EXCEL_PAYMENTLINEVALIDATIONLOG_TEMPLETEFILENM, "Import")
                    CheckTempleteFile = False
                End If
            Case eTemplatePtn.PaymentSheetReference
                If File.Exists(ExcelFormatFileDirPath & "\" & EXCEL_PAYMENTLINEREFERENCE_TEMPLETEFILENM) = False Then
                    OUTERR.OutImportErrorList(FileReader.GetMessage("MSG_0221") & "パス：" & ExcelFormatFileDirPath & "\" & EXCEL_PAYMENTLINEREFERENCE_TEMPLETEFILENM, "Import")
                    CheckTempleteFile = False
                End If
            Case eTemplatePtn.Detail
                ''個別詳細
                If File.Exists(ExcelFormatFileDirPath & "\" & EXCEL_PAYMENTLINE_TEMPLETEFILENM) = False Then
                    OUTERR.OutImportErrorList(FileReader.GetMessage("MSG_0221") & "パス：" & ExcelFormatFileDirPath & "\" & EXCEL_PAYMENTLINE_TEMPLETEFILENM, "Import")
                    CheckTempleteFile = False
                End If
            Case eTemplatePtn.DetailValidation
                ''個別詳細Validation
                If File.Exists(ExcelFormatFileDirPath & "\" & EXCEL_PAYMENTDETAILLINEVALIDATIONLOG_TEMPLETEFILENM) = False Then
                    OUTERR.OutImportErrorList(FileReader.GetMessage("MSG_0221") & "パス：" & ExcelFormatFileDirPath & "\" & EXCEL_PAYMENTDETAILLINEVALIDATIONLOG_TEMPLETEFILENM, "Import")
                    CheckTempleteFile = False
                End If
            Case eTemplatePtn.DetailReference

                If File.Exists(ExcelFormatFileDirPath & "\" & EXCEL_PAYMENTDETAILLINEREFERENCE_TEMPLETEFILENM) = False Then
                    OUTERR.OutImportErrorList(FileReader.GetMessage("MSG_0221") & "パス：" & ExcelFormatFileDirPath & "\" & EXCEL_PAYMENTDETAILLINEREFERENCE_TEMPLETEFILENM, "Import")
                    CheckTempleteFile = False
                End If
        End Select

    End Function


    '--------------------------------------------------------
    'メソッド名：CopyTemplateExcelFile
    '概    要  ：既定のフォルダにExcelのTempleteファイルのコピーを行う。
    '説    明  ：既定のフォルダにExcelのTempleteファイルのコピーを行う。
    '引    数  ：app = Excelアプリケーション
    '            frm =  ExcelSample画面のフォームオブジェクト
    '戻 り 値  ：CheckTempleteFile = Boolean(チェックがOKかどうか？)
    '--------------------------------------------------------
    Public Function CopyTemplateExcelFile(ByVal cdTemplatePtn As Integer,
                                           ByVal strFileName As String,
                                           ByRef OutPutFilePath As String,
                                           ByRef OutPutFileName As String,
                                           ByRef OUTERR As OutputErrorList,
                                           ByVal createTime As String,
                                           Optional ByVal importKB As String = "") As Boolean

        ''初期化
        CopyTemplateExcelFile = True

        Try
            Dim ofm As New OioFileManage
            Dim outExcelDir As String = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            Dim inTemplateDir As String = ofm.GetLocalTemplateFolder()

            ''Excel出力先フォルダが存在しなければ作成する。
            Call ofm.CreateLocalCsv1Folder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)

            ''各種ファイル名を取得
            Select Case cdTemplatePtn
                Case eTemplatePtn.PaymentSheet
                    OutPutFileName = ofm.GetNewPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO, createTime)

                    ''テンプレートのコピー
                    FileCopy(inTemplateDir & EXCEL_PAYMENTLINE_TEMPLETEFILENM, _
                             outExcelDir & OutPutFileName)

                Case eTemplatePtn.PaymentSheetValidation
                    'CPNO_契約順番_Payment_ValidationLog_YYYYMMDD_HHMMSS.xls
                    OutPutFileName = CommonVariable.CPNO.ToString.PadLeft(6, "0") & "_" & _
                                     CommonVariable.CONTRACTNO.ToString.PadLeft(3, "0") & _
                                     "_Payment_ValidationLog_" & _
                                     Now.ToString("yyyyMMdd_HHmmss") & _
                                     ".xlsm"

                    ''テンプレートのコピー
                    FileCopy(inTemplateDir & EXCEL_PAYMENTLINEVALIDATIONLOG_TEMPLETEFILENM, _
                             outExcelDir & OutPutFileName)

                Case eTemplatePtn.PaymentSheetReference
                    'CPNO_契約順番_Payment_RefreshLog_YYYYMMDD_HHMMSS.xls
                    OutPutFileName = CommonVariable.CPNO.ToString.PadLeft(6, "0") & "_" & _
                                     CommonVariable.CONTRACTNO.ToString.PadLeft(3, "0") & _
                                     "_Payment_RefreshLog_" & _
                                     Now.ToString("yyyyMMdd_HHmmss") & _
                                     ".xlsm"

                    ''テンプレートのコピー
                    FileCopy(inTemplateDir & EXCEL_PAYMENTLINEREFERENCE_TEMPLETEFILENM, _
                             outExcelDir & OutPutFileName)

                Case eTemplatePtn.Detail
                    OutPutFileName = ofm.GetNewPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO, createTime)

                Case eTemplatePtn.DetailValidation
                    'CPNO_契約順番_PaymentDetail_ValidationLog_YYYYMMDD_HHMMSS.xls
                    OutPutFileName = CommonVariable.CPNO.ToString.PadLeft(6, "0") & "_" & _
                                   CommonVariable.CONTRACTNO.ToString.PadLeft(3, "0") & _
                                   "_PaymentDetail_ValidationLog_" & _
                                   Now.ToString("yyyyMMdd_HHmmss") & _
                                   ".xlsm"
                    ''テンプレートのコピー
                    FileCopy(inTemplateDir & EXCEL_PAYMENTDETAILLINEVALIDATIONLOG_TEMPLETEFILENM, _
                             outExcelDir & OutPutFileName)

                Case eTemplatePtn.DetailReference
                    'CPNO_契約順番_PaymentDetail_RefreshLog_YYYYMMDD_HHMMSS.xls
                    OutPutFileName = CommonVariable.CPNO.ToString.PadLeft(6, "0") & "_" & _
                                     CommonVariable.CONTRACTNO.ToString.PadLeft(3, "0") & _
                                     "_PaymentDetail_RefreshLog_" & _
                                     Now.ToString("yyyyMMdd_HHmmss") & _
                                     ".xlsm"

                    ''テンプレートのコピー
                    FileCopy(inTemplateDir & EXCEL_PAYMENTDETAILLINEREFERENCE_TEMPLETEFILENM, _
                             outExcelDir & OutPutFileName)

            End Select

            ''出力先パスを取得
            OutPutFilePath = outExcelDir & OutPutFileName

        Catch ex As Exception
            OUTERR.OutImportErrorList(ex.Message, "Import")
            CopyTemplateExcelFile = False
        End Try

    End Function

    '--------------------------------------------------------
    'メソッド名：CheckPaymentLine
    '概    要  ：PaymentSheetCsvのファイルの構造をチェックする。
    '説    明  ：PaymentSheetCsvのファイルの構造をチェックする。
    '引    数  ：
    '戻 り 値  ：CheckPaymentLine = Boolean(チェックがOKかどうか？)
    '--------------------------------------------------------
    Private Function CheckPaymentLine(ByVal strFileName As String, _
                                      ByRef OUTERR As OutputErrorList) As Boolean

        Dim Reader As StreamReader
        Dim strRead As String
        Dim strTemp() As String

        CheckPaymentLine = True
        Reader = Nothing
        strRead = ""

        Try
            Dim strInPaymentSheet As String
            strTemp = strFileName.Split("\")
            strInPaymentSheet = strTemp(strTemp.Length - 1).ToString

            Reader = New StreamReader(strFileName, Encoding.GetEncoding("shift-jis"))
            Dim i As Integer = 0
            For i = CSV_PAYMENTLINE_CHECK_STRLINE To CSV_PAYMENTLINE_CHECK_ENDLINE
                strRead = Reader.ReadLine

                ''ファイルの構造をチェック
                Select Case i
                    Case CSV_PAYMENTLINE_CHECK_FILENMROW
                        ''ファイル名のチェック
                        If Trim(strRead) <> strInPaymentSheet Then
                            OUTERR.OutputErrorList(FileReader.GetMessage("MSG_0222") & vbCrLf _
                                   & "パス:" & CsvDirPath & "\" & strInPaymentSheet, "Import")
                            CheckPaymentLine = False
                        End If

                    Case CSV_PAYMENTLINE_CHECK_ROWTITLEROW
                        ''タイトルのチェック
                        If strRead <> CSV_TITLE_CUSTINFO_CCPNO & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_CUST_NAME & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_START_YEAR & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_START_MONTH & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_END_YEAR & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_END_MONTH & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_PA_ANV_DATE & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_PA_LEVEL & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_APPROVAL_DATE & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_CONTRACT_DATE Then
                            If strRead <> CSV_TITLE_CUSTINFO_CCPNO & DELIMITA _
                                                 & CSV_TITLE_CUSTINFO_CUST_NAME & DELIMITA _
                                                 & CSV_TITLE_CUSTINFO_START_YEAR & DELIMITA _
                                                 & CSV_TITLE_CUSTINFO_START_MONTH & DELIMITA _
                                                 & CSV_TITLE_CUSTINFO_END_YEAR & DELIMITA _
                                                 & CSV_TITLE_CUSTINFO_END_MONTH & DELIMITA _
                                                 & CSV_TITLE_CUSTINFO_PA_ANV_DATE & DELIMITA _
                                                 & CSV_TITLE_CUSTINFO_PA_LEVEL Then
                                OUTERR.OutputErrorList(FileReader.GetMessage("MSG_0223") & vbCrLf _
                                       & "パス:" & CsvDirPath & "\" & strInPaymentSheet, "Import")
                                CheckPaymentLine = False
                            Else
                                Continue For
                            End If
                            OUTERR.OutputErrorList(FileReader.GetMessage("MSG_0223") & vbCrLf _
                                   & "パス:" & CsvDirPath & "\" & strInPaymentSheet, "Import")
                            CheckPaymentLine = False
                        End If

                    Case CSV_PAYMENTLINE_CHECK_PAYMENTLINETITLEROW
                        ''PaymentLineタイトルチェック
                        Dim strTitle As String
                        strTitle = CSV_TITLE_PaymentLine_UPDATE_FLAG & DELIMITA _
                            & CSV_TITLE_PaymentLine_LOCK_FLAG & DELIMITA _
                            & CSV_TITLE_PaymentLine_VALID_FLAG & DELIMITA _
                            & CSV_TITLE_PaymentLine_LINE_NO & DELIMITA _
                            & CSV_TITLE_PaymentLine_FILE_NAME & DELIMITA _
                            & CSV_TITLE_PaymentLine_FILE_NAME_SUFFIX & DELIMITA _
                            & CSV_TITLE_PaymentLine_FILE_NAME_SUFFIX_INTR & DELIMITA _
                            & CSV_TITLE_PaymentLine_CONTRACT & DELIMITA _
                            & CSV_TITLE_PaymentLine_ST_COST & DELIMITA _
                            & CSV_TITLE_PaymentLine_ST_APPROVAL & DELIMITA _
                            & CSV_TITLE_PaymentLine_PROJ_ID & DELIMITA _
                            & CSV_TITLE_PaymentLine_CONTRACT_SEQ & DELIMITA _
                            & CSV_TITLE_PaymentLine_NEW_EXIST & DELIMITA _
                            & CSV_TITLE_PaymentLine_INV_EXP & DELIMITA _
                            & CSV_TITLE_PaymentLine_CUST_CATEGORY & DELIMITA _
                            & CSV_TITLE_PaymentLine_LETTER_PLAN_DATE & DELIMITA _
                            & CSV_TITLE_PaymentLine_LETTER_ISSUE_DATE & DELIMITA _
                            & CSV_TITLE_PaymentLine_LETTER_ACCEPT_DATE & DELIMITA _
                            & CSV_TITLE_PaymentLine_ORDER_DATE & DELIMITA _
                            & CSV_TITLE_PaymentLine_LETTER_ID & DELIMITA _
                            & CSV_TITLE_PaymentLine_BILLING_CD & DELIMITA _
                            & CSV_TITLE_PaymentLine_BU & DELIMITA _
                            & CSV_TITLE_PaymentLine_BRAND & DELIMITA _
                            & CSV_TITLE_PaymentLine_SUM_CATEGORY & DELIMITA _
                            & CSV_TITLE_PaymentLine_BRAND_SUB & DELIMITA _
                            & CSV_TITLE_PaymentLine_OP1 & DELIMITA _
                            & CSV_TITLE_PaymentLine_OP2 & DELIMITA _
                            & CSV_TITLE_PaymentLine_SIZE & DELIMITA _
                            & CSV_TITLE_PaymentLine_NON_SBO & DELIMITA _
                            & CSV_TITLE_PaymentLine_ADDITION_ITEM & DELIMITA _
                            & CSV_TITLE_PaymentLine_TOPACS_CPNO & DELIMITA _
                            & CSV_TITLE_PaymentLine_BRAND_AP_FORM & DELIMITA _
                            & CSV_TITLE_PaymentLine_BRAND_AP_REQ & DELIMITA _
                            & CSV_TITLE_PaymentLine_BRAND_AP_CONF & DELIMITA _
                            & CSV_TITLE_PaymentLine_PATTERN_CD & DELIMITA _
                            & CSV_TITLE_PaymentLine_PATTERN & DELIMITA _
                            & CSV_TITLE_PaymentLine_PROD_ITEM01 & DELIMITA _
                            & CSV_TITLE_PaymentLine_PROD_ITEM02 & DELIMITA _
                            & CSV_TITLE_PaymentLine_PROD_ITEM03 & DELIMITA _
                            & CSV_TITLE_PaymentLine_PROD_ITEM04 & DELIMITA _
                            & CSV_TITLE_PaymentLine_PROD_ITEM05 & DELIMITA _
                            & CSV_TITLE_PaymentLine_PROD_ITEM06 & DELIMITA _
                            & CSV_TITLE_PaymentLine_PROD_ITEM07 & DELIMITA _
                            & CSV_TITLE_PaymentLine_PROD_ITEM08 & DELIMITA _
                            & CSV_TITLE_PaymentLine_PROD_ITEM09 & DELIMITA _
                            & CSV_TITLE_PaymentLine_PROD_ITEM10 & DELIMITA _
                            & CSV_TITLE_PaymentLine_PROD_ITEM11 & DELIMITA _
                            & CSV_TITLE_PaymentLine_PROD_ITEM12 & DELIMITA _
                            & CSV_TITLE_PaymentLine_PROD_ITEM13 & DELIMITA _
                            & CSV_TITLE_PaymentLine_PROD_ITEM14 & DELIMITA _
                            & CSV_TITLE_PaymentLine_PROD_ITEM15 & DELIMITA _
                            & CSV_TITLE_PaymentLine_WD_ANNT_DATE & DELIMITA _
                            & CSV_TITLE_PaymentLine_WD_DATE & DELIMITA _
                            & CSV_TITLE_PaymentLine_PRICE_CHG_DATE & DELIMITA _
                            & CSV_TITLE_PaymentLine_QTY & DELIMITA _
                            & CSV_TITLE_PaymentLine_INST_YEAR & DELIMITA _
                            & CSV_TITLE_PaymentLine_INST_MONTH & DELIMITA _
                            & CSV_TITLE_PaymentLine_PAY_START_YEAR & DELIMITA _
                            & CSV_TITLE_PaymentLine_PAY_START_MONTH & DELIMITA _
                            & CSV_TITLE_PaymentLine_PAY_END_YEAR & DELIMITA _
                            & CSV_TITLE_PaymentLine_PAY_END_MONTH & DELIMITA _
                            & CSV_TITLE_PaymentLine_PAY_FLAG & DELIMITA _
                            & CSV_TITLE_PaymentLine_BID_FLAG & DELIMITA _
                            & CSV_TITLE_PaymentLine_IGF_START_DATE & DELIMITA _
                            & CSV_TITLE_PaymentLine_IGF_END_DATE & DELIMITA _
                            & CSV_TITLE_PaymentLine_PAY_MONTHS & DELIMITA _
                            & CSV_TITLE_PaymentLine_VALID_CTRL & DELIMITA _
                            & CSV_TITLE_PaymentLine_PAY_METHOD & DELIMITA _
                            & CSV_TITLE_PaymentLine_IGF_APPLIED & DELIMITA _
                            & CSV_TITLE_PaymentLine_IGF_CONT_NO & DELIMITA _
                            & CSV_TITLE_PaymentLine_IGF_CONT_TYPE & DELIMITA _
                            & CSV_TITLE_PaymentLine_IGF_PROPERTY & DELIMITA _
                            & CSV_TITLE_PaymentLine_IGF_RATE_BAUCOC & DELIMITA _
                            & CSV_TITLE_PaymentLine_IGF_RATE_IOC & DELIMITA _
                            & CSV_TITLE_PaymentLine_LIST_PRICE_PROPOSAL & DELIMITA _
                            & CSV_TITLE_PaymentLine_LIST_PRICE & DELIMITA _
                            & CSV_TITLE_PaymentLine_T_LIST_PRICE_PROPOSAL & DELIMITA _
                            & CSV_TITLE_PaymentLine_T_LIST_PRICE & DELIMITA _
                            & CSV_TITLE_PaymentLine_DP_BAU & DELIMITA _
                            & CSV_TITLE_PaymentLine_DP_COC & DELIMITA _
                            & CSV_TITLE_PaymentLine_DP_IOC & DELIMITA _
                            & CSV_TITLE_PaymentLine_PRICE_UNIT_BAU & DELIMITA _
                            & CSV_TITLE_PaymentLine_PRICE_QTY_BAU & DELIMITA _
                            & CSV_TITLE_PaymentLine_PRICE_UNIT_COC & DELIMITA _
                            & CSV_TITLE_PaymentLine_PRICE_QTY_COC & DELIMITA _
                            & CSV_TITLE_PaymentLine_PRICE_UNIT_IOC & DELIMITA _
                            & CSV_TITLE_PaymentLine_PRICE_QTY_IOC & DELIMITA _
                            & CSV_TITLE_PaymentLine_COST_RATE & DELIMITA _
                            & CSV_TITLE_PaymentLine_COST & DELIMITA _
                            & CSV_TITLE_PaymentLine_COST_TOTAL & DELIMITA _
                            & CSV_TITLE_PaymentLine_COST_INPUT_DATE & DELIMITA _
                            & CSV_TITLE_PaymentLine_TAX_RATE & DELIMITA _
                            & CSV_TITLE_PaymentLine_PRICE_TO_SPLIT & DELIMITA _
                            & CSV_TITLE_PaymentLine_LIST_PRICE_TOTAL_IOC & DELIMITA _
                            & CSV_TITLE_PaymentLine_PRICE_TOTAL_IOC & DELIMITA _
                            & CSV_TITLE_PaymentLine_COST_TOTAL_IOC & DELIMITA _
                            & CSV_TITLE_PaymentLine_PRICE_IGF_TOTAL & DELIMITA _
                            & CSV_TITLE_PaymentLine_PRICE_CONT_TOTAL & DELIMITA _
                            & CSV_TITLE_PaymentLine_PRICE_OO_CONT_TOTAL & DELIMITA _
                            & CSV_TITLE_PaymentLine_IGF_DIF_INTEREST
                        If strRead.IndexOf(strTitle) = -1 Then

                            OUTERR.OutputErrorList(FileReader.GetMessage("MSG_0259") & vbCrLf _
                                   & "パス:" & CsvDirPath & "\" & strInPaymentSheet, "Import")
                            CheckPaymentLine = False
                        End If
                End Select
            Next

        Catch ex As Exception
            ''例外の処理
            OUTERR.OutImportErrorList(ex.Message, "Import")
            CheckPaymentLine = False
        Finally
            ''ファイルオブジェクトの解放
            If IsNothing(Reader) = False Then
                Reader = Nothing
            End If
            GC.Collect()
        End Try

    End Function

    '--------------------------------------------------------
    'メソッド名：CheckPaymentValidationLog
    '概    要  ：PaymentSheetValidationLogCsvファイルの構造をチェックする。
    '説    明  ：PaymentSheetValidationLogCsvファイルの構造をチェックする。
    '引    数  ：
    '戻 り 値  ：CheckPaymentValidationLog = Boolean(チェックがOKかどうか？)
    '--------------------------------------------------------
    Private Function CheckPaymentValidationLog(ByVal strFileName As String,
                                               ByVal strCpNo As String,
                                               ByRef OUTERR As OutputErrorList) As Boolean

        Dim Reader As StreamReader
        Dim strRead As String
        Dim strTemp() As String
        Dim strInPaymentSheet As String

        CheckPaymentValidationLog = True

        strRead = ""
        Reader = Nothing
        strTemp = strFileName.Split("\")
        strInPaymentSheet = strTemp(strTemp.Length - 1).ToString

        Try
            Dim i As Integer = 0
            Reader = New StreamReader(strFileName, Encoding.GetEncoding("shift-jis"))
            For i = CSV_VALIDATIONLOG_CHECK_STRLINE To CSV_VALIDATIONLOG_CHECK_ENDLINE

                strRead = Reader.ReadLine

                ''ファイル構造のチェック
                Select Case i

                    Case CSV_VALIDATIONLOG_CHECK_FILENMROW
                        ''ファイル名のチェック
                        If Trim(strRead) <> strInPaymentSheet Then
                            OUTERR.OutputErrorList(FileReader.GetMessage("MSG_0224") & "パス:" & CsvDirPath & "\" & strInPaymentSheet, "Import")
                            CheckPaymentValidationLog = False
                        End If

                    Case CSV_VALIDATIONLOG_CHECK_CPNOROW
                        ''CPNOのチェック
                        If Trim(strRead) <> Trim(strCpNo) Then
                            OUTERR.OutputErrorList(FileReader.GetMessage("MSG_0225") & "パス:" & CsvDirPath & "\" & strInPaymentSheet, "Import")
                            CheckPaymentValidationLog = False
                        End If

                    Case CSV_VALIDATIONLOG_CHECK_TITLEROW
                        ''タイトルのチェック
                        If strRead <> _
                               CSV_PAYMENTLINEVALIDATIONLOG_TITLE_RESULT & DELIMITA _
                             & CSV_PAYMENTLINEVALIDATIONLOG_TITLE_CPNO & DELIMITA _
                             & CSV_PAYMENTLINEVALIDATIONLOG_TITLE_CONTRACT & DELIMITA _
                             & CSV_PAYMENTLINEVALIDATIONLOG_TITLE_FILE_NAME & DELIMITA _
                             & CSV_PAYMENTLINEVALIDATIONLOG_TITLE_FILE_NAME_SUFFIX & DELIMITA _
                             & CSV_PAYMENTLINEVALIDATIONLOG_TITLE_FILE_NAME_SUFFIX_INTR & DELIMITA _
                             & CSV_PAYMENTLINEVALIDATIONLOG_TITLE__LINE_NO & DELIMITA _
                             & CSV_PAYMENTLINEVALIDATIONLOG_TITLE_SEQ & DELIMITA _
                             & CSV_PAYMENTLINEVALIDATIONLOG_TITLE_ITEM & DELIMITA _
                             & CSV_PAYMENTLINEVALIDATIONLOG_TITLE_VALID_ID & DELIMITA _
                             & CSV_PAYMENTLINEVALIDATIONLOG_TITLE_DESCRIPTION & DELIMITA _
                             & CSV_PAYMENTLINEVALIDATIONLOG_TITLE_VALUE_VALIDATED & DELIMITA _
                             & CSV_PAYMENTLINEVALIDATIONLOG_TITLE_VALUE_EXPECTED & DELIMITA _
                             & CSV_PAYMENTLINEVALIDATIONLOG_TITLE_RUN_STAMP Then

                            OUTERR.OutputErrorList(FileReader.GetMessage("MSG_0226") & "パス:" & CsvDirPath & "\" & strInPaymentSheet, "Import")
                            CheckPaymentValidationLog = False
                        End If

                End Select
            Next

        Catch ex As Exception
            ''例外処理
            OUTERR.OutputErrorList(ex.Message, "Import")
            CheckPaymentValidationLog = False
        Finally
            ''ファイルオブジェクトの解放
            If IsNothing(Reader) = False Then
                Reader = Nothing
            End If
            GC.Collect()
        End Try
    End Function

    '--------------------------------------------------------
    'メソッド名：CheckPaymentReference
    '概    要  ：PaymentSheetReferenceCsvファイルの構造をチェックする。
    '説    明  ：PaymentSheetReferenceCsvファイルの構造をチェックする。
    '引    数  ：
    '戻 り 値  ：CheckPaymentReference = Boolean(チェックがOKかどうか？)
    '--------------------------------------------------------
    Private Function CheckPaymentReference(ByVal strFileName As String,
                                           ByVal strCpNo As String,
                                           ByRef OUTERR As OutputErrorList) As Boolean

        Dim Reader As StreamReader
        Dim strRead As String
        Dim strTemp() As String

        CheckPaymentReference = True

        strRead = ""
        Reader = Nothing

        Try
            Dim strInPaymentSheet As String
            strTemp = strFileName.Split("\")
            strInPaymentSheet = strTemp(strTemp.Length - 1).ToString
            Dim i As Integer = 0
            Reader = New StreamReader(strFileName, Encoding.GetEncoding("shift-jis"))
            For i = CSV_VALIDATIONLOG_CHECK_STRLINE To CSV_VALIDATIONLOG_CHECK_ENDLINE
                strRead = Reader.ReadLine
                ''ファイル構造のチェック
                Select Case i
                    Case CSV_VALIDATIONLOG_CHECK_FILENMROW
                        ''ファイル名のチェック
                        If Trim(strRead) <> strInPaymentSheet Then
                            OUTERR.OutputErrorList(FileReader.GetMessage("MSG_0227") & "パス:" & CsvDirPath & "\" & strInPaymentSheet, "Import")
                            CheckPaymentReference = False
                        End If

                    Case CSV_VALIDATIONLOG_CHECK_CPNOROW
                        ''CPNOのチェック
                        If Trim(strRead) <> Trim(strCpNo) Then
                            OUTERR.OutputErrorList(FileReader.GetMessage("MSG_0228") & "パス:" & CsvDirPath & "\" & strInPaymentSheet, "Import")
                            CheckPaymentReference = False
                        End If

                    Case CSV_VALIDATIONLOG_CHECK_TITLEROW
                        ''タイトルのチェック
                        If strRead <> _
                               CSV_PAYMENTLINEVALIDATIONLOG_TITLE_RESULT & DELIMITA _
                             & CSV_PAYMENTLINEVALIDATIONLOG_TITLE_CPNO & DELIMITA _
                             & CSV_PAYMENTLINEVALIDATIONLOG_TITLE_CONTRACT & DELIMITA _
                             & CSV_PAYMENTLINEVALIDATIONLOG_TITLE_FILE_NAME & DELIMITA _
                             & CSV_PAYMENTLINEVALIDATIONLOG_TITLE_FILE_NAME_SUFFIX & DELIMITA _
                             & CSV_PAYMENTLINEVALIDATIONLOG_TITLE_FILE_NAME_SUFFIX_INTR & DELIMITA _
                             & CSV_PAYMENTLINEVALIDATIONLOG_TITLE__LINE_NO & DELIMITA _
                             & CSV_PAYMENTLINEVALIDATIONLOG_TITLE_SEQ & DELIMITA _
                             & CSV_PAYMENTLINEVALIDATIONLOG_TITLE_ITEM & DELIMITA _
                             & CSV_PAYMENTLINEVALIDATIONLOG_TITLE_VALID_ID & DELIMITA _
                             & CSV_PAYMENTLINEVALIDATIONLOG_TITLE_DESCRIPTION & DELIMITA _
                             & CSV_PAYMENTLINEVALIDATIONLOG_TITLE_VALUE_VALIDATED & DELIMITA _
                             & CSV_PAYMENTLINEVALIDATIONLOG_TITLE_VALUE_EXPECTED & DELIMITA _
                             & CSV_PAYMENTLINEVALIDATIONLOG_TITLE_RUN_STAMP Then
                            OUTERR.OutputErrorList(FileReader.GetMessage("MSG_0229") & "パス:" & CsvDirPath & "\" & strInPaymentSheet, "Import")
                            CheckPaymentReference = False
                        End If

                End Select
            Next

        Catch ex As Exception
            ''例外処理
            OUTERR.OutputErrorList(ex.Message, "Import")
            CheckPaymentReference = False
        Finally
            ''ファイルオブジェクトの解放
            If IsNothing(Reader) = False Then
                Reader = Nothing
            End If
            GC.Collect()
        End Try
    End Function


    '--------------------------------------------------------
    'メソッド名：CheckPaymentDetailLine
    '概    要  ：個別詳細Csvファイルの構造をチェックする。
    '説    明  ：個別詳細Csvファイルの構造をチェックする。
    '引    数  ：
    '戻 り 値  ：CheckPaymentDetailLine = Boolean(チェックがOKかどうか？)
    '--------------------------------------------------------
    Private Function CheckPaymentDetailLine(ByVal strFileName As String,
                                            ByVal strCpNo As String,
                                            ByRef OUTERR As OutputErrorList) As Boolean

        Dim Reader As StreamReader
        Dim strRead As String = ""
        Reader = Nothing
        CheckPaymentDetailLine = True

        Try
            Dim strTemp() As String
            Dim strInPaymentSheet As String
            strTemp = strFileName.Split("\")
            strInPaymentSheet = strTemp(strTemp.Length - 1).ToString
            Reader = New StreamReader(strFileName, Encoding.GetEncoding("shift-jis"))
            Dim i As Integer = 0
            For i = CSV_PAYMENTLINEDETAIL_CHECK_STRLINE To CSV_PAYMENTLINEDETAIL_CHECK_ENDLINE

                strRead = Reader.ReadLine

                ''ファイルの構造をチェック
                Select Case i

                    Case CSV_PAYMENTLINEDETAIL_CHECK_FILENMROW
                        ''ファイル名のチェック
                        If Trim(strRead) <> strInPaymentSheet Then
                            OUTERR.OutputErrorList(FileReader.GetMessage("MSG_0230") & "パス:" & strFileName, "Import")
                            CheckPaymentDetailLine = False
                        End If

                    Case CSV_PAYMENTLINEDETAIL_CHECK_CPNOROW
                        ''CPNOのチェック
                        If Trim(strRead) <> Trim(strCpNo) Then
                            OUTERR.OutputErrorList(FileReader.GetMessage("MSG_0231") & "パス:" & strFileName, "Import")
                            CheckPaymentDetailLine = False
                        End If

                    Case CSV_PAYMENTLINEDETAIL_CHECK_TITLEOROW

                        If strRead <> CSV_TITLE_CUSTINFO_UPDATE_FLAG & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_LOCK_FLAG & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_VALID_FLAG & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_CONTRACT & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_FILE_NAME & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_FILE_NAME_SUFFIX & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_FILE_NAME_SUFFIX_INTR & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_SEQ & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_IDENTITY_FLAG & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_PROD_NO & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_PROD_NAME & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_WD_ANNT_DATE & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_WD_DATE & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_PRICE_CHG_DATE & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_MES_CATEGORY & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_MES_GROUP & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_SPECIAL_FEATURE & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_QTY & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_LIST_PRICE_PROPSAL & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_LIST_PRICE & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_T_LIST_PRICE_PROPOSAL & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_T_LIST_PRICE & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_COST_RATE & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_COST & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_COST_TOTAL & DELIMITA _
                                             & CSV_TITLE_CUSTINFO_COST_INPUT_DATE & DELIMITA _
                                             & CSV_TITLE_HWMA_LIST_PRICE & DELIMITA _
                                             & CSV_TITLE_HWMA_LIST_PRICE_TOTAL & DELIMITA _
                                             & CSV_TITLE_HOURLY_SCALE & DELIMITA _
                                             & CSV_TITLE_MA_EXT_SCALE & DELIMITA _
                                             & CSV_TITLE_DP & DELIMITA _
                                             & CSV_TITLE_HWMA_DP_LIST_PRICE & DELIMITA _
                                             & CSV_TITLE_HWMA_DP_LIST_PRICE_TOTAL Then

                            CheckPaymentDetailLine = False
                            MsgBox("個別詳細CSVファイルの顧客情報タイトルが間違えています。" & vbCrLf _
                                   & "パス:" & strFileName _
                                   , MsgBoxStyle.Critical, )
                        End If

                End Select
            Next

        Catch ex As Exception
            ''例外処理
            OUTERR.OutputErrorList(ex.Message, "Import")
            CheckPaymentDetailLine = False
        Finally
            ''ファイルオブジェクトの解放
            If IsNothing(Reader) = False Then
                Reader = Nothing
            End If

            GC.Collect()
        End Try

    End Function

    '--------------------------------------------------------
    'メソッド名：CheckPaymentDetailValidationLog
    '概    要  ：PaymentDetailSheetValidationLogCsvファイルの構造をチェックする。
    '説    明  ：PaymentDetailSheetValidationLogCsvファイルの構造をチェックする。
    '引    数  ：
    '戻 り 値  ：CheckPaymentDetailValidationLog = Boolean(チェックがOKかどうか？)
    '--------------------------------------------------------
    Private Function CheckPaymentDetailValidationLog(ByVal strFileName As String,
                                                     ByVal strCpNo As String,
                                                     ByRef OUTERR As OutputErrorList) As Boolean

        Dim Reader As StreamReader
        Dim strRead As String

        CheckPaymentDetailValidationLog = True

        Reader = Nothing
        strRead = ""

        Try
            Dim strTemp() As String
            Dim strInPaymentSheet As String
            strTemp = strFileName.Split("\")
            strInPaymentSheet = strTemp(strTemp.Length - 1).ToString
            Dim i As Integer = 0
            Reader = New StreamReader(strFileName, Encoding.GetEncoding("shift-jis"))
            For i = CSV_VALIDATIONLOG_CHECK_STRLINE To CSV_VALIDATIONLOG_CHECK_ENDLINE

                strRead = Reader.ReadLine

                ''ファイル構造のチェック
                Select Case i

                    Case CSV_VALIDATIONLOG_CHECK_FILENMROW
                        ''ファイル名のチェック
                        If Trim(strRead) <> strInPaymentSheet Then
                            OUTERR.OutputErrorList(FileReader.GetMessage("MSG_0232") & "パス:" & strFileName, "Import")
                            CheckPaymentDetailValidationLog = False

                        End If

                    Case CSV_VALIDATIONLOG_CHECK_CPNOROW
                        ''CPNOのチェック
                        If Trim(strRead) <> Trim(strCpNo) Then
                            OUTERR.OutputErrorList(FileReader.GetMessage("MSG_0233") & "パス:" & strFileName, "Import")
                            CheckPaymentDetailValidationLog = False
                        End If

                    Case CSV_VALIDATIONLOG_CHECK_TITLEROW
                        ''タイトルのチェック
                        If strRead <> _
                               CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_RESULT & DELIMITA _
                             & CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_CPNO & DELIMITA _
                             & CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_CONTRACT & DELIMITA _
                             & CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_FILE_NAME & DELIMITA _
                             & CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_FILE_NAME_SUFFIX & DELIMITA _
                             & CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_FILE_NAME_SUFFIX_INTR & DELIMITA _
                             & CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE__LINE_NO & DELIMITA _
                             & CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_SEQ & DELIMITA _
                             & CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_ITEM & DELIMITA _
                             & CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_VALID_ID & DELIMITA _
                             & CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_DESCRIPTION & DELIMITA _
                             & CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_VALUE_VALIDATED & DELIMITA _
                             & CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_VALUE_EXPECTED & DELIMITA _
                             & CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_RUN_STAMP Then

                            OUTERR.OutputErrorList(FileReader.GetMessage("MSG_0234") & "パス:" & strFileName, "Import")
                            CheckPaymentDetailValidationLog = False
                        End If

                End Select
            Next

        Catch ex As Exception
            ''例外処理
            OUTERR.OutputErrorList(ex.Message, "Import")
            CheckPaymentDetailValidationLog = False

        Finally
            ''ファイルオブジェクトの解放
            If IsNothing(Reader) = False Then
                Reader = Nothing
            End If
            GC.Collect()
        End Try

    End Function

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="strFileName"></param>
    ''' <param name="strCpNo"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckPaymentDetailReference(ByVal strFileName As String,
                                                 ByVal strCpNo As String,
                                                 ByRef OUTERR As OutputErrorList) As Boolean

        Dim Reader As StreamReader
        Dim strRead As String

        CheckPaymentDetailReference = True

        Reader = Nothing
        strRead = ""


        Try
            Dim strTemp() As String
            Dim strInPaymentSheet As String
            strTemp = strFileName.Split("\")
            strInPaymentSheet = strTemp(strTemp.Length - 1).ToString
            Dim i As Integer = 0
            Reader = New StreamReader(strFileName, Encoding.GetEncoding("shift-jis"))
            For i = CSV_VALIDATIONLOG_CHECK_STRLINE To CSV_VALIDATIONLOG_CHECK_ENDLINE

                strRead = Reader.ReadLine

                ''ファイル構造のチェック
                Select Case i

                    Case CSV_VALIDATIONLOG_CHECK_FILENMROW
                        ''ファイル名のチェック
                        If Trim(strRead) <> strInPaymentSheet Then

                            OUTERR.OutputErrorList(FileReader.GetMessage("MSG_0235") & "パス:" & strFileName, "Import")
                            CheckPaymentDetailReference = False
                        End If

                    Case CSV_VALIDATIONLOG_CHECK_CPNOROW
                        ''CPNOのチェック
                        If Trim(strRead) <> Trim(strCpNo) Then

                            OUTERR.OutputErrorList(FileReader.GetMessage("MSG_0236") & "パス:" & strFileName, "Import")
                            CheckPaymentDetailReference = False

                        End If

                    Case CSV_VALIDATIONLOG_CHECK_TITLEROW
                        ''タイトルのチェック
                        If strRead <> _
                               CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_RESULT & DELIMITA _
                             & CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_CPNO & DELIMITA _
                             & CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_CONTRACT & DELIMITA _
                             & CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_FILE_NAME & DELIMITA _
                             & CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_FILE_NAME_SUFFIX & DELIMITA _
                             & CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_FILE_NAME_SUFFIX_INTR & DELIMITA _
                             & CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE__LINE_NO & DELIMITA _
                             & CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_SEQ & DELIMITA _
                             & CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_ITEM & DELIMITA _
                             & CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_VALID_ID & DELIMITA _
                             & CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_DESCRIPTION & DELIMITA _
                             & CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_VALUE_VALIDATED & DELIMITA _
                             & CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_VALUE_EXPECTED & DELIMITA _
                             & CSV_PAYMENTLINEDETAILVALIDATIONLOG_TITLE_RUN_STAMP Then

                            OUTERR.OutputErrorList(FileReader.GetMessage("MSG_0237") & "パス:" & strFileName, "Import")
                            CheckPaymentDetailReference = False
                        End If

                End Select
            Next

        Catch ex As Exception
            ''例外処理
            OUTERR.OutputErrorList(ex.Message, "Import")
            CheckPaymentDetailReference = False

        Finally
            ''ファイルオブジェクトの解放
            If IsNothing(Reader) = False Then
                Reader = Nothing
            End If
            GC.Collect()
        End Try

    End Function

    ''' <summary>
    ''' 機能：サマリ行の式をセット
    ''' </summary>
    ''' <param name="alPsdCreating">詳細ﾃﾞｰﾀ</param>
    ''' <param name="summaryList">ｻﾏﾘｰ行</param>
    ''' <param name="SummaryFomula">ｻﾏﾘｰ式</param>
    ''' <param name="OutCount">ｻﾏﾘｰ件数</param>
    ''' <remarks></remarks>
    Private Sub SetSummaryTmplateRow(ByVal alPsdCreating As ArrayList,
                                     ByVal summaryList As ArrayList,
                                     ByVal SummaryFomula As PaymentLineDetailFomulateInfo,
                                     ByVal OutCount As Integer)


        Dim intIdxStart As Integer
        Dim intIdxEnd As Integer
        'Dim obj() As Object

        Try
            For idx As Integer = 1 To summaryList.Count
                'Summary式をセット
                If idx <> summaryList.Count Then
                    intIdxStart = summaryList(idx - 1) + 1 + ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW
                    intIdxEnd = summaryList(idx) - 1 + ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW
                Else
                    intIdxStart = summaryList(idx - 1) + 1 + ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW
                    intIdxEnd = ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW + OutCount - 1
                End If

                'Listprice(合計)_提案時
                alPsdCreating(summaryList(idx - 1))(ExcelWrite.ExcelPaymentLineDetailColumn.LIST_PRICE_TOTAL_PROPOSAL - 1) =
                                        SummaryFomula.LIST_PRICE_TOTAL_PROPOSAL.ToString _
                                                                               .Replace("@1", intIdxStart) _
                                                                               .Replace("@2", intIdxEnd)

                'Listprice(合計)_ﾘﾌﾚｯｼｭ後
                alPsdCreating(summaryList(idx - 1))(ExcelWrite.ExcelPaymentLineDetailColumn.LIST_PRICE_TOTAL - 1) =
                                        SummaryFomula.LIST_PRICE_TOTAL.ToString _
                                                                      .Replace("@1", intIdxStart) _
                                                                      .Replace("@2", intIdxEnd)

                'COST_合計
                alPsdCreating(summaryList(idx - 1))(ExcelWrite.ExcelPaymentLineDetailColumn.COST_TOTAL - 1) =
                                        SummaryFomula.COST_TOTAL.ToString _
                                                                .Replace("@1", intIdxStart) _
                                                                .Replace("@2", intIdxEnd)

                '合計(MMMC)
                alPsdCreating(summaryList(idx - 1))(ExcelWrite.ExcelPaymentLineDetailColumn.HWMA_LIST_PRICE_TOTAL - 1) =
                                        SummaryFomula.LIST_PRICE_TOTAL_MMC.ToString _
                                                                          .Replace("@1", intIdxStart) _
                                                                          .Replace("@2", intIdxEnd)

            Next

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    ''' <summary>
    '''概  要：詳細出力用の配列を取得する。
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetWriteObjLine(ByVal StrSplitLine) As Object()

        ''戻り値のセット
        Dim rtnValue(ExcelWrite.CsvPaymentLineDetailColumn.HWMA_DP_LIST_PRICE_TOTAL - 1) As Object

        ''値を整形する。
        For k As Integer = ExcelWrite.CsvPaymentLineDetailColumn.UPDATE_FLAG To _
                           ExcelWrite.CsvPaymentLineDetailColumn.HWMA_DP_LIST_PRICE_TOTAL

            Select Case k
                Case 1
                    '無条件でブランクをセットする
                    rtnValue(k - 1) = StrSplitLine(k - 1)

                Case ExcelWrite.CsvPaymentLineDetailColumn.QTY_INTEGER, _
                     ExcelWrite.CsvPaymentLineDetailColumn.LIST_PRICE_PROPOSAL, _
                     ExcelWrite.CsvPaymentLineDetailColumn.LIST_PRICE, _
                     ExcelWrite.CsvPaymentLineDetailColumn.HWMA_LIST_PRICE

                    '数字項目のため、数字にして表示する
                    If StrSplitLine(k - 1).ToString().Length > 0 Then
                        Dim convNum As Long = 0
                        convNum = Convert.ToInt64(StrSplitLine(k - 1).ToString)
                        rtnValue(k - 1) = convNum
                    Else
                        rtnValue(k - 1) = StrSplitLine(k - 1)
                    End If

                Case 21
                    Continue For
                Case 22
                    Continue For

                Case ExcelWrite.CsvPaymentLineDetailColumn.COST_RATE, _
                     ExcelWrite.CsvPaymentLineDetailColumn.HOURLY_SCALE, _
                     ExcelWrite.CsvPaymentLineDetailColumn.MA_EXT_SCALE, _
                     ExcelWrite.CsvPaymentLineDetailColumn.DP

                    '%表示にするために100分の１にする
                    If StrSplitLine(k - 1).ToString().Length > 0 Then
                        StrSplitLine(k - 1) = GetParsentFormat(Convert.ToDecimal(StrSplitLine(k - 1).ToString) / 100)
                    End If
                    rtnValue(k - 1) = StrSplitLine(k - 1)
                Case 25
                    Continue For
                Case Else
                    rtnValue(k - 1) = StrSplitLine(k - 1)
            End Select
        Next
        Return rtnValue

    End Function


    ''' <summary>
    '''概  要：詳細出力用の配列を取得する。
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Public Function GetConWriteObjLine(ByVal StrSplitLine() As String, Optional ByVal intProcCd As Integer = CD_PROC_NEW) As Object()
        Dim intEnd As Integer

        intEnd = ExcelWrite.CsvPaymentLineDetailColumn.HWMA_DP_LIST_PRICE_TOTAL
        Dim rtnValue(intEnd - 1) As Object

        ''値を整形
        For k As Integer = ExcelWrite.CsvPaymentLineDetailColumn.UPDATE_FLAG To intEnd
            Select Case k
                Case ExcelWrite.CsvPaymentLineDetailColumn.QTY_INTEGER, _
                     ExcelWrite.CsvPaymentLineDetailColumn.LIST_PRICE_PROPOSAL, _
                     ExcelWrite.CsvPaymentLineDetailColumn.LIST_PRICE, _
                     ExcelWrite.CsvPaymentLineDetailColumn.LIST_PRICE_TOTAL_PROPOSAL, _
                     ExcelWrite.CsvPaymentLineDetailColumn.LIST_PRICE_TOTAL, _
                     ExcelWrite.CsvPaymentLineDetailColumn.COST, _
                     ExcelWrite.CsvPaymentLineDetailColumn.COST_TOTAL, _
                     ExcelWrite.CsvPaymentLineDetailColumn.HWMA_LIST_PRICE, _
                     ExcelWrite.CsvPaymentLineDetailColumn.HWMA_LIST_PRICE_TOTAL, _
                     ExcelWrite.CsvPaymentLineDetailColumn.HWMA_DP_LIST_PRICE, _
                     ExcelWrite.CsvPaymentLineDetailColumn.HWMA_DP_LIST_PRICE_TOTAL

                    '数字項目
                    If StrSplitLine(k - 1).ToString().Length > 0 Then
                        Dim convNum As Long = 0
                        convNum = Convert.ToInt64(StrSplitLine(k - 1).ToString)
                        rtnValue(k - 1) = convNum
                    Else
                        rtnValue(k - 1) = StrSplitLine(k - 1)
                    End If

                Case ExcelWrite.CsvPaymentLineDetailColumn.COST_RATE, _
                     ExcelWrite.CsvPaymentLineDetailColumn.HOURLY_SCALE, _
                     ExcelWrite.CsvPaymentLineDetailColumn.MA_EXT_SCALE, _
                     ExcelWrite.CsvPaymentLineDetailColumn.DP

                    '%項目
                    If StrSplitLine(k - 1).ToString().Length > 0 Then
                        StrSplitLine(k - 1) = GetParsentFormat(Convert.ToDecimal(StrSplitLine(k - 1).ToString) / 100)
                    End If
                    rtnValue(k - 1) = StrSplitLine(k - 1)

                Case Else
                    rtnValue(k - 1) = StrSplitLine(k - 1)
            End Select
        Next

        Return rtnValue

    End Function


    ''※PSBookと詳細Bookの統合にしたがって、以下処理を修正。
    '' ・BookのOpen処理を重複させないために、WorkSheetは引数で受け取る。
    '' ・BookのOpen処理に必要だった引数/処理は削除。
    '' ・OUTERRは呼び出し元で定義したものを引数で受け取る。
    ''' <summary>
    ''' 機　能：ExcelのPSのデータをテーブルに格納する
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetPSData(ByRef PsSheet As Excel.Worksheet, _
                          ByRef exldatatable As DataTable, _
                          ByRef maxLineNoes As Dictionary(Of String, String), _
                          ByRef intMaxFileSeq As Integer, _
                          ByRef excelPaymentLineCount As String)

        'Excelオブジェクト
        Dim xlCell As Excel.Range
        Dim ExcelCellInfo(1, 357) As Object
        Try
            intMaxFileSeq = 0
            Dim strFileSeq As String
            Dim i As Integer = 0
            Dim j As Integer = 0
            excelPaymentLineCount = 0
            i = ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW
            Do
                ''Excel１行分の値を配列にセット
                xlCell = PsSheet.Range("A" & i & ":" & "MT" & i)
                ExcelCellInfo = xlCell.Value

                'Eofの判定
                If ExcelWrite.changeDBNullToString(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)) = "" Then
                    Exit Do
                End If

                ''配列情報をDataRowにセット。
                Dim OutRow1 As DataRow
                OutRow1 = exldatatable.NewRow
                For j = 0 To 357
                    OutRow1(j) = ExcelCellInfo(1, j + 1)
                Next
                ''Excelの行番号を取得
                OutRow1.Item("ExcelRow") = i

                '仮シリアル最大番判定
                ''※有効無効Flg = Xのﾃﾞｰﾀのみ有効
                If IsNothing(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG)) = False Then
                    If ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG) = "X" Then

                        ''                  ▼項目3/5/6から、最大の仮ｼﾘｱﾙSeqを取得
                        ''--------------------------------------------------------------------------
                        ''項目3
                        If IsNothing(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02)) = False Then
                            If ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02).ToString.IndexOf("@H") > -1 Then
                                strFileSeq = ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02).ToString.Substring(5, 3)
                                If intMaxFileSeq < CInt(strFileSeq) Then
                                    intMaxFileSeq = CInt(strFileSeq)
                                End If
                            End If
                        End If

                        ''項目5
                        If IsNothing(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02)) = False Then
                            If ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02).ToString.IndexOf("@H") > -1 Then
                                strFileSeq = ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02).ToString.Substring(5, 3)

                                If intMaxFileSeq < CInt(strFileSeq) Then
                                    intMaxFileSeq = CInt(strFileSeq)
                                End If
                            End If
                        End If

                        ''項目6
                        If IsNothing(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02)) = False Then
                            If ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02).ToString.IndexOf("@H") > -1 Then
                                strFileSeq = ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02).ToString.Substring(5, 3)
                                If intMaxFileSeq < CInt(strFileSeq) Then
                                    intMaxFileSeq = CInt(strFileSeq)
                                End If
                            End If
                        End If
                    End If
                End If

                ''LineNoの最大行番の判定
                ''契約順番をKeyにMaxのLinNoを取得する。
                Dim contractNo As String
                contractNo = ExcelCellInfo(1, ExcelPaymentLineColumn.CONTRACT).ToString
                If maxLineNoes.ContainsKey(contractNo) = False Then
                    maxLineNoes.Add(contractNo, CInt(ExcelCellInfo(1, ExcelPaymentLineColumn.LINE_NO).ToString) Mod 100000)
                Else
                    If maxLineNoes(contractNo) <= CInt(ExcelCellInfo(1, ExcelPaymentLineColumn.LINE_NO).ToString) Mod 100000 Then
                        maxLineNoes(contractNo) = CInt(ExcelCellInfo(1, ExcelPaymentLineColumn.LINE_NO).ToString) Mod 100000
                    End If
                End If

                ''Excelの行数をカウント
                excelPaymentLineCount = excelPaymentLineCount + 1

                ''拡張子なしのファイル名を取得
                ''契約締結済みはWindowsOSで使用できないﾌｧｲﾙ名がセットされる可能性があるため、以下の処理をセット
                If ExcelWrite.changeDBNullToString(ExcelCellInfo(1, ExcelPaymentLineColumn.VALID_FLAG)) <> "N" Then
                    OutRow1("FileNMWithoutExtension") = ""
                Else
                    If (IsNothing(ExcelCellInfo(1, ExcelPaymentLineColumn.LOCK_FLAG)) = False AndAlso CStr(ExcelCellInfo(1, ExcelPaymentLineColumn.LOCK_FLAG)) = "C") Then
                        OutRow1("FileNMWithoutExtension") = ""
                    Else
                        OutRow1("FileNMWithoutExtension") = Path.GetFileNameWithoutExtension(ExcelCellInfo(1, ExcelPaymentLineColumn.FILE_NAME))
                    End If
                End If

                ''%項目はExcelセット時に÷100を行うため、Excelの情報取得時に×100をして調整する。
                Call ChangeExcelParcentFormatToCSV(OutRow1(ExcelWrite.ExcelPaymentLineColumn.IGF_RATE_IOC - 1))
                Call ChangeExcelParcentFormatToCSV(OutRow1(ExcelWrite.ExcelPaymentLineColumn.DP_IOC - 1))
                Call ChangeExcelParcentFormatToCSV(OutRow1(ExcelWrite.ExcelPaymentLineColumn.COST_RATE - 1))

                ''行のセット
                exldatatable.Rows.Add(OutRow1)

                i = i + 1
            Loop

        Catch ex As Exception

            ''エラーログ書込
            Throw ex

        Finally

            ''エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            ''ガベージコレクトの起動
            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    '''概    要：Xlsファイルから、Csv構成情報と一致するN行情報を抽出する。
    '''説    明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub inportNLine(ByRef csvdatatable As DataTable,
                            ByVal exldatatable As DataTable,
                            ByVal intMaxFileSeq As Integer,
                            ByRef delPaymentRows() As Integer)


        Dim index As Integer = -1
        ReDim Preserve delPaymentRows(index)
        Dim isNLine As Boolean

        ''Csvファイルの値を全件検索
        Dim searchFileNm As String
        Dim excelFilter As New StringBuilder
        For Each csvRow As DataRow In csvdatatable.Select("")

            searchFileNm = ""
            searchFileNm = Path.GetFileNameWithoutExtension(Mid(csvRow.Item("COL" & ExcelPaymentLineColumn.PROD_ITEM10 - 1), 4, csvRow.Item("COL" & ExcelPaymentLineColumn.PROD_ITEM10 - 1).ToString.Length - 4))

            ''抽出条件 ：有効無効 = N行 and 項目1～9に一致するファイル名が存在するか。
            excelFilter.Remove(0, excelFilter.Length)
            excelFilter.Append("COL" & ExcelPaymentLineColumn.VALID_FLAG - 1)
            excelFilter.Append(CommonConstant.SQL_STR_EQUAL)
            excelFilter.Append(StringEdit.EncloseSingleQuotation("N"))
            excelFilter.Append(CommonConstant.SQL_STR_AND)

            ''Excel_ファイル名(拡張子なし)と、Csv_項目10(拡張子なし)を比較
            excelFilter.Append("FileNMWithoutExtension")
            excelFilter.Append(CommonConstant.SQL_STR_EQUAL)
            excelFilter.Append(StringEdit.EncloseSingleQuotation(searchFileNm))

            isNLine = False

            ''Excelデータの抽出
            ''※最初に抽出したN行のデータを正とする。		
            For Each excelRow As DataRow In exldatatable.Select(excelFilter.ToString)

                isNLine = True

                ''N行が既にセットされているか判定
                If Array.IndexOf(delPaymentRows, CInt(excelRow.Item("ExcelRow"))) = -1 Then

                    ''削除対象のN行データのセット
                    index = index + 1
                    ReDim Preserve delPaymentRows(index)
                    delPaymentRows(index) = excelRow.Item("ExcelRow")

                    ''N行データの抽出
                    Dim addRow As DataRow
                    addRow = csvdatatable.NewRow

                    ''N行データのコピー
                    For i As Integer = 0 To excelRow.ItemArray.Length - 3
                        addRow.Item(i) = excelRow.Item(i)
                    Next

                    addRow("Sort_RefNLine") = "00"
                    addRow("Sort_CsvTmpNM") = csvRow("Sort_CsvTmpNM")
                    addRow("Sort_ISNLine") = "00"

                    ''N行の挿入
                    csvdatatable.Rows.Add(addRow)

                End If

                Exit For

            Next
            If isNLine = True Then
                csvRow("Sort_RefNLine") = "00"
            End If
        Next

        ''削除対象データをソート
        Call Array.Sort(delPaymentRows)

    End Sub


    ''' <summary>
    ''' 機　能：CSVファイルを読込む
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function ReadCSV(ByVal strFileName As String, ByRef wkdatatable As DataTable) As Integer

        Dim Reader As StreamReader
        Dim CsvCount As Integer
        Dim StrLine As String
        Dim StrSplitLine() As String

        Reader = Nothing

        'エラーログ初期設定
        Dim OUTERR As New OutputErrorList
        OUTERR.CpNo = Me.CpNo
        OUTERR.ContractNo = Me.ContractNo

        Try
            Reader = New StreamReader(strFileName, Encoding.GetEncoding("shift-jis"))
            Dim strOutFileName As String = Path.GetFileName(strFileName)

            ''CSVファイルの読込処理
            CsvCount = 0
            Do

                StrLine = Reader.ReadLine()
                If IsNothing(StrLine) Then
                    '無限ループ防止（読み込めなくなったらループ抜ける）
                    Exit Do
                End If

                'カンマ区切りのデータを分解する
                Call SplitData(StrLine, StrSplitLine)

                '項目10にファイル名+シーケンス出力
                StrSplitLine(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10 - 1) = Path.GetFileName(strFileName) + "-" + String.Format("{0:D3}", CsvCount + 1)

                ''Eof行が存在しない場合
                If IsNothing(StrLine) = True Then

                    OUTERR.OutputErrorList2(FileReader.GetMessage("MSG_0238") & "パス：" & CsvDirPath & "\" & strOutFileName, "BPMakeExchange", CsvCount)
                    Exit Function
                End If

                ''Eof行の処理
                If StrLine.IndexOf("EOF") = 0 Then

                    ''Eof行に記載された行数とExcelへ出力された行数の比較
                    If CsvCount <> StrSplitLine(1) Then

                        'Dim OUTERR As New OutputErrorList
                        OUTERR.OutputErrorList2(FileReader.GetMessage("MSG_0214") & vbCrLf & _
                                               "パス：" & CsvDirPath & "\" & strOutFileName, "BPMakeExchange", CsvCount)

                        Exit Function
                    Else
                        Exit Do
                    End If
                End If

                Dim OutRow2 As DataRow
                OutRow2 = wkdatatable.NewRow
                Dim j As Integer
                For j = 0 To StrSplitLine.Length - 1
                    OutRow2(j) = StrSplitLine(j)
                Next

                OutRow2("Sort_RefNLine") = "01"
                OutRow2("Sort_CsvTmpNM") = Path.GetFileNameWithoutExtension(strFileName)
                OutRow2("Sort_ISNLine") = "01"

                wkdatatable.Rows.Add(OutRow2)

                CsvCount = CsvCount + 1
            Loop

            ReadCSV = CsvCount
        Catch ex As Exception
            OUTERR.OutputErrorList2(ex.Message, "BPMakeExchange")
        Finally
            ''ファイルオブジェクトの解放
            If IsNothing(Reader) = False Then
                Reader.Close()
                Reader = Nothing
            End If

            OUTERR = Nothing

            ''ガベージコレクトの起動
            GC.Collect()
        End Try

    End Function

    ''※WorkBookSaveの重複を防ぐために、WorkSheetを引数で受け取る。
    ''※BookOpenに必要な引数を削除する。
    ''' <summary>
    ''' 機　能：Excelに書込み
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub WriteExcel(ByRef xlSheet As Excel.Worksheet, _
                           ByRef sortdatatable As DataTable,
                           ByVal startOutputRow As Integer,
                           ByVal delPaymentRows() As Integer)

        Dim CsvCount As Integer = 0
        Dim xlCell As Excel.Range
        Dim xlRange As Excel.Range
        Dim xlEntireRow As Excel.Range
        Dim ExcelCellInfo(1, 357) As Object
        Dim strRange As String
        Dim xmlPaymentLineFomulateInfo As PaymentLineFomulateInfo

        ''EXCELオブジェクトの初期化
        xlCell = Nothing
        xlRange = Nothing
        xlEntireRow = Nothing

        ''ファイルの読込み
        Try


            ''N行の削除
            ''※N行はExcelファイルから一度削除後、構成情報CSVデータと共に最後の行に出力される。
            Call DeleteNLine(xlSheet, delPaymentRows)

            '--------------------------------------------------------------
            'ﾃﾝﾌﾟﾚｰﾄ行をコピペする。
            '--------------------------------------------------------------
            '先頭行を下にコピー
            xlCell = xlSheet.Range("2:2")
            xlEntireRow = xlCell.EntireRow
            xlEntireRow.Hidden = False
            ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            '繰り返し
            Const DIVISION_LINES As Long = 500
            Dim intRecordCnt As Integer = sortdatatable.Rows.Count
            Dim lngSho As Integer = intRecordCnt \ DIVISION_LINES
            Dim lngAmari As Integer = intRecordCnt Mod DIVISION_LINES
            Dim lngCnt As Long

            For lngCnt = 1 To lngSho
                xlCell = xlSheet.Range("2:2")
                xlCell.Copy()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                strRange = (startOutputRow + (lngCnt - 1) * DIVISION_LINES).ToString() & ":" & (startOutputRow + lngCnt * DIVISION_LINES - 1).ToString()
                xlCell = xlSheet.Range(strRange)
                xlCell.Insert()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            Next
            If lngAmari > 0 Then
                xlCell = xlSheet.Range("2:2")
                xlCell.Copy()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                strRange = (startOutputRow + (lngSho * DIVISION_LINES)).ToString() & ":" & (startOutputRow + (lngSho * DIVISION_LINES + lngAmari) - 1).ToString()
                xlCell = xlSheet.Range(strRange)
                xlCell.Insert()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            End If

            'ﾃﾝﾌﾟﾚｰﾄ行隠し
            xlCell = xlSheet.Range("2:2")
            xlEntireRow = xlCell.EntireRow
            xlEntireRow.Hidden = True
            ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            '--------------------------------------------------------------
            'データがなくなるまで繰り返す（行）
            '--------------------------------------------------------------
            'PaymentLineExcelに出力する式を取得
            xmlPaymentLineFomulateInfo = ExcelWrite.GetPaymentExcelFomulate

            Dim outputrow As DataRow
            For Each outputrow In sortdatatable.Rows

                ''ﾃﾞｰﾀ出力用の配列をセットする。
                Dim Outputstring As String()
                ReDim Outputstring(outputrow.ItemArray.Length - 1)
                For k As Integer = 0 To outputrow.ItemArray.Length - 1
                    Outputstring(k) = changeDBNullToString(outputrow.Item(k))
                Next

                '項目入れ替え
                Call ReplaceItem(Outputstring)

                ''PS1行分データを出力
                Call SetPSSheetCellValue(xlSheet, Outputstring, CsvCount, startOutputRow, xmlPaymentLineFomulateInfo)
                CsvCount = CsvCount + 1
            Next

            '年額/月額を縮小
            Call ExcelWrite.CreatePaymentPeriod(xlSheet,
                                                ExcelWrite.ChgExcelRowNumberToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1),
                                                CommonVariable.PaymentPeriod)


            'Req.1723 Isat年額取込仕様変更 2019/03 Str
            '最終行取得
            intRecordCnt = xlSheet.Cells(xlSheet.Rows.Count, ExcelPaymentLineColumn.LINE_NO).End(Excel.XlDirection.xlUp).Row

            '読込時ブランクがあった行に色を付ける
            For lngCnt = ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW To intRecordCnt
                If xlSheet.Cells(lngCnt, ExcelPaymentLineColumn.PROD_ITEM22).value = "BLANK ISAT" Then
                    xlSheet.Cells(lngCnt, ExcelPaymentLineColumn.PROD_ITEM01).interior.color = RGB(255, 255, 0)
                    xlSheet.Cells(lngCnt, ExcelPaymentLineColumn.PROD_ITEM11).interior.color = RGB(255, 255, 0)
                    xlSheet.Cells(lngCnt, ExcelPaymentLineColumn.PROD_ITEM12).interior.color = RGB(255, 255, 0)
                    xlSheet.Cells(lngCnt, ExcelPaymentLineColumn.INST_DATE).interior.color = RGB(255, 255, 0)
                    xlSheet.Cells(lngCnt, ExcelPaymentLineColumn.PAY_START_DATE).interior.color = RGB(255, 255, 0)
                    xlSheet.Cells(lngCnt, ExcelPaymentLineColumn.PAY_END_DATE).interior.color = RGB(255, 255, 0)

                    '項目22は初期化
                    xlSheet.Cells(lngCnt, ExcelPaymentLineColumn.PROD_ITEM22).value = ""
                End If
            Next
            'Req.1723 Isat年額取込仕様変更 2019/03 End

        Catch ex As Exception
            ''エラーが発生したら、呼び出し元でメッセージを表示
            Throw ex

        Finally
            ''エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            ''ガベージコレクトの起動
            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' 機　能：詳細ｼｰﾄに1CSVﾌｧｲﾙ分の情報を書込
    ''' 説　明：
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function OutPutExcelPaymentDetailSheet_Temp(ByRef DetailSheet As Excel.Worksheet, _
                                                       ByRef OUTERR As OutputErrorList, _
                                                       ByVal strFileNameList() As String) As Integer

        ''初期化
        OutPutExcelPaymentDetailSheet_Temp = -1

        ''Excelオブジェクト
        Dim xlCell As Excel.Range
        Dim xlRange As Excel.Range
        Dim xlEntireRow As Excel.Range

        ''ﾃﾞｰﾀﾃｰﾌﾞﾙ
        Dim csvDatatable As New DataTable
        Dim excelDatatable As New DataTable

        Try
            ''データテーブルを定義する。
            For cnt As Integer = ExcelWrite.ExcelPaymentLineDetailColumn.UPDATE_FLAG - 1 To _
                                 ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE - 1
                excelDatatable.Columns.Add(cnt, Type.GetType("System.String"))
                csvDatatable.Columns.Add(cnt, Type.GetType("System.String"))
            Next
            ''S行の計算式に使用。
            ''S行のBox/Featureが何件かチェック　0:Box/Feature　N:Box/Feature有
            csvDatatable.Columns.Add("ChildCount", Type.GetType("System.String"))

            ''                          ▼以下、Excel読込処理
            ''-------------------------------------------------------------------------
            Dim excelDetailEofLine As Integer
            Call GetExcelDetailData(DetailSheet, excelDatatable)                             ''詳細シート：値をテーブルに格納
            excelDetailEofLine = excelDatatable.Rows.Count + EXCEL_PAYMENTLINEDATE_OUTROW    ''詳細シート：EOF行を取得

            ''                          ▼以下、CSV読込処理
            ''-------------------------------------------------------------------------
            For Each DetailPath As String In strFileNameList

                ''CsvTableに値をセット
                Call SetDetailCsvData(csvDatatable, OUTERR, DetailPath)

            Next

            ''                          ▼以下、Excel書込処理
            ''-------------------------------------------------------------------------
            ''ﾃﾝﾌﾟﾚ行の一括コピペ
            Call CopyDetailTmpRow(DetailSheet, _
                                  csvDatatable, _
                                  excelDetailEofLine)

            ' ''ﾃﾝﾌﾟﾚ行のExcel式を取得
            Dim formula_NormalRow() As String
            Dim formula_SummaryRow() As String
            formula_NormalRow = GetDetailFormula_NormalRow(DetailSheet)
            formula_SummaryRow = GetDetailFormula_SummaryRow(DetailSheet)

            ''詳細シートの書込
            Dim idx As Integer = -1
            Dim outArea As String
            Dim outLine(ExcelWrite.CsvPaymentLineDetailColumn.HWMA_DP_LIST_PRICE_TOTAL - 1) As Object
            For Each outputRow As DataRow In csvDatatable.Select()

                idx = idx + 1

                ''1行分の値を配列にセット
                If outputRow.Item(ExcelWrite.CsvPaymentLineDetailColumn.IDENTITY_FLAG - 1) <> "S" Then
                    outLine = GetNormalDetailLine(outputRow, formula_NormalRow)
                Else
                    outLine = GetSummaryDetailLine(excelDetailEofLine + idx, outputRow, formula_SummaryRow)
                End If

                ''1行分の値を書込む
                outArea = ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineDetailColumn.UPDATE_FLAG) & excelDetailEofLine + idx & ":" & _
                          ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE) & excelDetailEofLine + idx
                xlRange = DetailSheet.Range(outArea)
                xlRange.Formula = outLine
                ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)

            Next

            ''データ0件は正常終了とする。
            If idx = -1 Then
                idx = 0
            Else
                idx = idx + 1
            End If
            Return idx

        Catch ex As Exception
            Call MsgBox(FileReader.GetMessage("MSG_0273"), MsgBoxStyle.Exclamation)
            Call OUTERR.OutputErrorList(ex.Message, "BPMakeExchange")
            Return -1

        Finally
            ''エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            ''ガベージコレクトの起動
            GC.Collect()

        End Try

    End Function

    ''' <summary>
    ''' 機　能：1行分の詳細シートに出力情報を取得
    ''' 説　明：※通常行の処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetNormalDetailLine(ByRef outputRow As DataRow, _
                                         ByVal formula_NormalRow() As String) As Object()

        ''初期化
        Dim rtnValue(ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE - 1) As Object
        GetNormalDetailLine = rtnValue

        ''各項目のフォーマットをセットする。
        For Idx As Integer = 0 To ExcelWrite.CsvPaymentLineDetailColumn.MA_EXT_SCALE - 1
            Select Case Idx
                Case ExcelWrite.CsvPaymentLineDetailColumn.UPDATE_FLAG - 1
                    rtnValue(Idx) = ""

                Case ExcelWrite.CsvPaymentLineDetailColumn.LIST_PRICE_TOTAL_PROPOSAL - 1, _
                        ExcelWrite.CsvPaymentLineDetailColumn.LIST_PRICE_TOTAL - 1, _
                        ExcelWrite.CsvPaymentLineDetailColumn.COST_TOTAL - 1

                    rtnValue(Idx) = formula_NormalRow(Idx)

                Case ExcelWrite.CsvPaymentLineDetailColumn.QTY_INTEGER - 1, _
                     ExcelWrite.CsvPaymentLineDetailColumn.LIST_PRICE_PROPOSAL - 1, _
                     ExcelWrite.CsvPaymentLineDetailColumn.LIST_PRICE - 1

                    '数字項目のため、数字にして表示する
                    If IsNumeric(outputRow.Item(Idx)) = True Then
                        rtnValue(Idx) = Convert.ToInt32(outputRow.Item(Idx))
                    Else
                        rtnValue(Idx) = outputRow.Item(Idx)
                    End If

                Case ExcelWrite.CsvPaymentLineDetailColumn.COST_RATE - 1
                    '%項目のため、書式を整える。
                    If outputRow.Item(Idx).ToString().Length > 0 Then
                        rtnValue(Idx) = StringEdit.GetTrancatePercentageValue(outputRow.Item(Idx))
                    End If

                Case ExcelWrite.CsvPaymentLineDetailColumn.LIST_PRICE_TOTAL_PROPOSAL - 1, _
                     ExcelWrite.CsvPaymentLineDetailColumn.LIST_PRICE_TOTAL - 1, _
                     ExcelWrite.CsvPaymentLineDetailColumn.COST_TOTAL - 1, _
                     ExcelWrite.CsvPaymentLineDetailColumn.HWMA_LIST_PRICE_TOTAL - 1

                    ''Excel計算式をセット
                    rtnValue(Idx) = formula_NormalRow(Idx)

                Case Else
                    rtnValue(Idx) = outputRow.Item(Idx)
            End Select
        Next
        Return rtnValue

    End Function

    ''' <summary>
    ''' 機　能：1行分の詳細シートに出力情報を取得
    ''' 説　明：※集計行の処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSummaryDetailLine(ByVal excelRow As Integer, _
                                          ByRef outputRow As DataRow, _
                                          ByVal formula_SummaryRow() As String) As Object()

        ''初期化
        Dim rtnValue(ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE - 1) As Object

        GetSummaryDetailLine = rtnValue

        ''各項目のフォーマットをセットする。
        Dim at_1 As Integer             ''Sum式で使用：@1の置換文字として使用
        Dim at_2 As Integer             ''Sum式で使用：@2の置換文字として使用
        For Idx As Integer = 0 To ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE - 1
            Select Case Idx
                Case ExcelWrite.ExcelPaymentLineDetailColumn.UPDATE_FLAG - 1
                    rtnValue(Idx) = ""

                Case ExcelWrite.ExcelPaymentLineDetailColumn.QTY_INTEGER - 1

                    '数字項目のため、数字にして表示する
                    If IsNumeric(outputRow.Item(Idx)) = True Then
                        rtnValue(Idx) = Convert.ToInt64(outputRow.Item(Idx))
                    Else
                        rtnValue(Idx) = outputRow.Item(Idx)
                    End If

                Case ExcelWrite.ExcelPaymentLineDetailColumn.COST_RATE - 1
                    '％項目
                    If outputRow.Item(Idx).ToString.Length > 0 Then
                        rtnValue(Idx) = StringEdit.GetTrancatePercentageValue(outputRow.Item(Idx))
                    End If

                Case ExcelWrite.ExcelPaymentLineDetailColumn.LIST_PRICE_PROPOSAL - 1, _
                     ExcelWrite.ExcelPaymentLineDetailColumn.LIST_PRICE - 1, _
                     ExcelWrite.ExcelPaymentLineDetailColumn.COST - 1, _
                     ExcelWrite.ExcelPaymentLineDetailColumn.HWMA_LIST_PRICE - 1
                    'Excel式
                    rtnValue(Idx) = formula_SummaryRow(Idx)

                Case ExcelWrite.ExcelPaymentLineDetailColumn.LIST_PRICE_TOTAL_PROPOSAL - 1, _
                     ExcelWrite.ExcelPaymentLineDetailColumn.LIST_PRICE_TOTAL - 1, _
                     ExcelWrite.ExcelPaymentLineDetailColumn.COST_TOTAL - 1, _
                     ExcelWrite.ExcelPaymentLineDetailColumn.HWMA_LIST_PRICE_TOTAL - 1

                    ''Excel式:Sum式の"@1"と"@2"に集計範囲をセット
                    at_1 = excelRow + 1
                    at_2 = excelRow + CInt(outputRow.Item("ChildCount"))
                    rtnValue(Idx) = formula_SummaryRow(Idx).Replace("@1", at_1) _
                                                           .Replace("@2", at_2)
                Case Else
                    rtnValue(Idx) = outputRow.Item(Idx)
            End Select
        Next
        Return rtnValue

    End Function

    ''' <summary>
    '''概  要：詳細シートの情報をﾃﾞｰﾀﾃｰﾌﾞﾙにセットする。
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetExcelDetailData(ByRef DetailSheet As Excel.Worksheet, _
                                   ByRef excelDatatable As DataTable)

        Dim OutRow As DataRow
        Dim xlCell As Excel.Range
        Dim ExcelCellInfo(1, 33) As Object
        Try
            ''個別詳細ファイルの情報をデータテーブルへ退避
            Dim i As Integer = EXCEL_PAYMENTLINEDATE_OUTROW
            Do
                ''1行分の情報を配列にセット
                xlCell = DetailSheet.Range("A" & i & ":" & "AG" & i)
                ExcelCellInfo = xlCell.Value

                ''EOF判定　
                If ExcelWrite.changeDBNullToString(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME)) = "" AndAlso _
                   ExcelWrite.changeDBNullToString(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineDetailColumn.PROD_NO)) = "" Then
                    Exit Do
                End If

                ''セルの値をセット
                OutRow = excelDatatable.NewRow
                For j As Integer = ExcelWrite.ExcelPaymentLineDetailColumn.UPDATE_FLAG - 1 To _
                                   ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE - 1
                    OutRow(j) = ExcelCellInfo(1, j + 1)
                Next
                Call excelDatatable.Rows.Add(OutRow)
                i = i + 1
            Loop

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            ''ガベージコレクトの起動
            GC.Collect()
        End Try

    End Sub

    ''' <summary>
    '''概  要：詳細Csvの情報をﾃﾞｰﾀﾃｰﾌﾞﾙにセットする。
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetDetailCsvData(ByRef csvDatatable As DataTable, _
                                 ByRef OUTERR As OutputErrorList, _
                                 ByVal DetailPath As String)

        ''Csvファイルの読込準備
        Dim Reader As StreamReader
        Reader = New StreamReader(DetailPath, Encoding.GetEncoding("shift-jis"))

        ''Csvファイルの値をDataTableへセット
        Dim summaryIdx As Integer
        Dim summaryChild As Integer

        Dim intCsvLineCnt As Integer
        Dim isErr As Boolean = False
        Dim OutRow As DataRow
        Dim csvLine As String
        Dim csvSplitLine() As String
        Do
            Try
                ''件数
                intCsvLineCnt = intCsvLineCnt + 1

                ''Csv1行分の値を読込
                csvLine = Reader.ReadLine()

                ''Eof行の処理
                If IsNothing(csvLine) = True Then
                    Exit Do
                End If

                'カンマ区切りのデータを分解する
                Call SplitData(csvLine, csvSplitLine)

                ''CsvTableに値をセット
                OutRow = csvDatatable.NewRow
                For j As Integer = 0 To ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE - 1
                    OutRow(j) = csvSplitLine(j)
                Next
                csvDatatable.Rows.Add(OutRow)

                ''S行のBox/Feature件数の判定　※Sum関数で使用。
                If OutRow(ExcelWrite.CsvPaymentLineDetailColumn.IDENTITY_FLAG - 1) = "S" Then
                    If intCsvLineCnt <> 1 Then
                        csvDatatable.Rows(summaryIdx).Item("ChildCount") = summaryChild
                    End If
                    summaryIdx = csvDatatable.Rows.Count - 1
                    summaryChild = 0
                Else
                    summaryChild = summaryChild + 1
                End If

            Catch ex As Exception
                OUTERR.OutputErrorList2(ex.Message, "Import", intCsvLineCnt.ToString)

            End Try
        Loop

        If intCsvLineCnt > 1 Then
            csvDatatable.Rows(summaryIdx).Item("ChildCount") = summaryChild
        End If

        ''ファイルオブジェクトの解放
        If IsNothing(Reader) = False Then
            Reader.Close()
            Reader = Nothing
        End If

    End Sub

    ''' <summary>
    ''' 機　能：詳細ｼｰﾄにﾃﾝﾌﾟﾚ行をコピペする。
    ''' 説　明：
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Sub CopyDetailTmpRow(ByRef DetailSheet As Excel.Worksheet, _
                                 ByRef csvDatatable As DataTable, _
                                 ByVal detailEof As Integer)

        ''定数
        Const Idx_TmpNormalRow As Integer = 3
        Const Idx_TmpSummaryRow As Integer = 2

        Dim xlPasteRow As Excel.Range               ''貼付行
        Dim xlTmpNormalRow As Excel.Range           ''テンプレ行：通常行
        Dim xlTmpSummaryRow As Excel.Range          ''テンプレ行：Summary行
        Dim xlEntireRow As Excel.Range

        Try

            ''ﾃﾝﾌﾟﾚ行のセット            
            xlTmpNormalRow = DetailSheet.Range(Idx_TmpNormalRow.ToString & ":" & Idx_TmpNormalRow.ToString)
            xlTmpSummaryRow = DetailSheet.Range(Idx_TmpSummaryRow.ToString & ":" & Idx_TmpSummaryRow.ToString)

            ''ﾃﾝﾌﾟﾚ行表示
            xlEntireRow = xlTmpNormalRow.EntireRow
            xlEntireRow.Hidden = False
            ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)
            xlEntireRow = xlTmpSummaryRow.EntireRow
            xlEntireRow.Hidden = False
            ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)


            ''テンプレ行のコピペ
            For Idx As Integer = 1 To csvDatatable.Rows.Count

                ''サマリ行　or　通常行 判定
                xlPasteRow = DetailSheet.Range((detailEof + Idx - 1).ToString & ":" & (detailEof + Idx - 1).ToString)
                If csvDatatable.Rows(Idx - 1).Item(ExcelWrite.CsvPaymentLineDetailColumn.IDENTITY_FLAG - 1) <> "S" Then
                    Call xlTmpNormalRow.Copy()
                    Call xlPasteRow.PasteSpecial()
                Else
                    Call xlTmpSummaryRow.Copy()
                    Call xlPasteRow.PasteSpecial()
                End If
                ExcelObjRelease.ReleaseExcelObj(xlPasteRow, ExcelObjRelease.OBJECT_NOTHING)
            Next

            ''ﾃﾝﾌﾟﾚ行非表示
            xlEntireRow = xlTmpNormalRow.EntireRow
            xlEntireRow.Hidden = True
            ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)
            xlEntireRow = xlTmpSummaryRow.EntireRow
            xlEntireRow.Hidden = True
            ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)

        Catch ex As Exception
            Throw ex

        Finally
            ''エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlPasteRow, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlTmpNormalRow, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlTmpSummaryRow, ExcelObjRelease.OBJECT_NOTHING)

            ''ガベージコレクトの起動
            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' 機　能：詳細ｼｰﾄのﾃﾝﾌﾟﾚ行の式を取得
    ''' 説　明：※通常行
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetDetailFormula_NormalRow(ByRef DetailSheet As Excel.Worksheet) As String()

        ''定数
        Const Idx_TmpNormalRow As Integer = 3

        ''初期化
        Dim rtnValue(ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE - 1) As String

        GetDetailFormula_NormalRow = rtnValue

        ''ﾃﾝﾌﾟﾚ行の計算式を取得する。        
        Dim tmpLine(,) As Object
        Dim xlTmpRow As Excel.Range
        Try

            ''Tmplate行のExcel式を取得
            xlTmpRow = DetailSheet.Range(Idx_TmpNormalRow.ToString & ":" & Idx_TmpNormalRow.ToString)
            tmpLine = xlTmpRow.FormulaR1C1

            ''戻り値にｾｯﾄする。
            For Idx As Integer = ExcelWrite.ExcelPaymentLineDetailColumn.UPDATE_FLAG To _
                                 ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE

                If tmpLine(1, Idx).IndexOf("=") = -1 Then
                    rtnValue(Idx - 1) = ""
                Else
                    rtnValue(Idx - 1) = tmpLine(1, Idx)
                End If
            Next
            GetDetailFormula_NormalRow = rtnValue

        Catch ex As Exception
            Throw ex

        Finally
            ''エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlTmpRow, ExcelObjRelease.OBJECT_NOTHING)

            ''ガベージコレクトの起動
            GC.Collect()

        End Try

    End Function

    ''' <summary>
    ''' 機　能：詳細ｼｰﾄのﾃﾝﾌﾟﾚ行の式を取得
    ''' 説　明：※集計行
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetDetailFormula_SummaryRow(ByRef DetailSheet As Excel.Worksheet) As String()

        ''定数
        Const Idx_TmpSummaryRow As Integer = 2

        ''初期化
        Dim rtnValue(ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE - 1) As String

        GetDetailFormula_SummaryRow = rtnValue

        ''ﾃﾝﾌﾟﾚ行の計算式を取得する。        
        Dim tmpLine(,) As Object
        Dim xlTmpRow As Excel.Range
        Try

            ''Tmplate行のExcel式を取得
            xlTmpRow = DetailSheet.Range(Idx_TmpSummaryRow.ToString & ":" & Idx_TmpSummaryRow.ToString)
            tmpLine = xlTmpRow.FormulaR1C1

            ''戻り値にｾｯﾄする。
            For Idx As Integer = ExcelWrite.ExcelPaymentLineDetailColumn.UPDATE_FLAG To _
                                 ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE

                If tmpLine(1, Idx).IndexOf("=") = -1 Then
                    rtnValue(Idx - 1) = ""
                Else
                    rtnValue(Idx - 1) = tmpLine(1, Idx)
                End If
            Next
            GetDetailFormula_SummaryRow = rtnValue

        Catch ex As Exception
            Throw ex

        Finally
            ''エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlTmpRow, ExcelObjRelease.OBJECT_NOTHING)

            ''ガベージコレクトの起動
            GC.Collect()

        End Try

    End Function

    ''' <summary>
    ''' 機　能：仮シリアル再採番
    ''' 説　明：
    ''' </summary>
    ''' <param name="Principal"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function inportSeqNo(ByVal Principal As DataTable, ByVal intMaxFileSeq As Integer) As DataTable

        Dim refData As DataTable
        Dim temprow As DataRow
        Dim intSeqNo As Integer = intMaxFileSeq
        Dim strSerial As String = ""
        Dim strColName As String = ""
        Dim strCol43 As String = ""
        Dim strWork As String = ""

        refData = Principal.Copy

        '項目１０（ファイル名）でソートする
        For Each temprow In refData.Select("", "COL" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10 - 1)
            If temprow.Item("COL" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03 - 1).ToString.IndexOf("@H") > -1 Then
                '項目３
                strSerial = temprow.Item("COL" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03 - 1).ToString
                strColName = "COL" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03 - 1

            ElseIf temprow.Item("COL" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM05 - 1).ToString.IndexOf("@H") > -1 Then
                '項目５
                strSerial = temprow.Item("COL" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM05 - 1).ToString
                strColName = "COL" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM05 - 1

            ElseIf temprow.Item("COL" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM06 - 1).ToString.IndexOf("@H") > -1 Then
                '項目６
                strSerial = temprow.Item("COL" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM06 - 1).ToString
                strColName = "COL" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM06 - 1
            End If

            '仮シリアル対象判定
            If strColName <> "" Then
                '項目１０のSEQ付きファイル名をファイル名（拡張子なし）文字列を取得する
                strWork = temprow.Item("COL" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10 - 1)
                strWork = strWork.Substring(0, strWork.Length - "_999".Length)              ''末尾の「-xxx」を除いた値で比較する。

                '１つ前のデータとファイル名（拡張子なし）と比較する
                If strCol43 <> strWork Then
                    'ファイル名退避
                    strCol43 = strWork
                    'SEQインクリメント
                    intSeqNo = intSeqNo + 1
                End If

                '再採番した値をセットする
                temprow.Item(strColName) = strSerial.Substring(0, 5) & Format(intSeqNo, "000") & strSerial.Substring(8, 4)
                strColName = ""
            End If

        Next
        Return refData

    End Function

    ''' <summary>
    ''' 機　能：行番号の採番
    ''' 説　明：
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function inportLineNo(ByVal sortdatatable As DataTable,
                                  ByVal maxLineNo As Dictionary(Of String, String),
                                  ByVal strContract As String) As DataTable

        ''テーブルのコピー
        Dim rtnTable As DataTable
        rtnTable = sortdatatable.Copy

        ''行番のセット
        Dim SetLineNo As String
        Dim ContractNo As String
        For i As Integer = 0 To sortdatatable.Rows.Count - 1
            ContractNo = CInt(rtnTable.Rows(i).Item("COL" & CsvPaymentLineColumn.CONTRACT - 1))

            ''PaymentSheetXlsの契約順番毎のMax行番号を元に連番
            If maxLineNo.ContainsKey(ContractNo) Then
                maxLineNo(ContractNo) = CInt(maxLineNo(ContractNo)) + 1
                SetLineNo = ContractNo.PadLeft(3, "0c") & maxLineNo(ContractNo).PadLeft(5, "0")
            Else
                maxLineNo.Add(ContractNo, "1")
                SetLineNo = ContractNo.PadLeft(3, "0c") & maxLineNo(ContractNo).PadLeft(5, "0")
            End If
            rtnTable.Rows(i).Item("COL" & CsvPaymentLineColumn.LINE_NO - 1) = SetLineNo

        Next

        Return rtnTable

    End Function

    ''' <summary>
    ''' 機　能：Costの設定
    ''' 説　明：Master.accdbのCODEテーブルからCost情報を取得し、DataTableにセットする
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function inportCost(ByVal sortdatatable As DataTable,
                                  ByVal maxLineNo As Dictionary(Of String, String)) As DataTable

        ''MasterMdb取得用
        Dim mdc As New MasterMdbControl
        Dim dbCon As OleDbConnection
        Dim odc As New OleDbCode
        Dim dbTable As DataTable
        Dim ii As Integer
        Dim Rows1 As DataRow
        Dim Rows2 As DataRow
        Dim GetCost As String
        Dim Cost_MVMS As String
        Dim Cost_CISCOMA As String

        '認証設定
        dbCon = mdc.GetOleDBConnection(CommonVariable.MdbPW)

        'CODEテーブル取得
        dbTable = odc.SelectDataTable(dbCon, "Cost")

        '取得内容チェック
        If dbTable.Rows.Count = 0 Then
            Exit Function
        Else
            Dim filterSel1 As New StringBuilder
            Dim filterSel2 As New StringBuilder

            'MVMSのCost検索
            filterSel1.Append("ItemCode")
            filterSel1.Append(CommonConstant.SQL_STR_EQUAL)
            filterSel1.Append(StringEdit.EncloseSingleQuotation("20"))

            '登録なしの場合は空白をセット
            If dbTable.Select(filterSel1.ToString).Length = 0 Then
                Cost_MVMS = ""
            Else
                For Each Rows1 In dbTable.Select(filterSel1.ToString)
                    Cost_MVMS = ExcelWrite.changeDBNullToString(Rows1.Item("ItemValue"))
                    Exit For
                Next
            End If

            'CISCO保守のCost検索
            filterSel2.Append("ItemCode")
            filterSel2.Append(CommonConstant.SQL_STR_EQUAL)
            filterSel2.Append(StringEdit.EncloseSingleQuotation("21"))

            '登録なしの場合は空白をセット
            If dbTable.Select(filterSel2.ToString).Length = 0 Then
                Cost_CISCOMA = ""
            Else
                For Each Rows2 In dbTable.Select(filterSel2.ToString)
                    Cost_CISCOMA = ExcelWrite.changeDBNullToString(Rows2.Item("ItemValue"))
                    Exit For
                Next
            End If

        End If

        dbCon.Close()

        ''テーブルのコピー
        Dim rtnTable As DataTable
        rtnTable = sortdatatable.Copy

        ''Costのセット
        Dim SetLineNo As String
        Dim PatternNo As String
        For i As Integer = 0 To sortdatatable.Rows.Count - 1


            PatternNo = CInt(rtnTable.Rows(i).Item("COL" & ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD - 1))

            ''PaymentSheetXlsの契約順番毎のMax行番号を元に連番
            Select Case PatternNo
                Case 20
                    rtnTable.Rows(i).Item("COL" & ExcelWrite.ExcelPaymentLineColumn.COST_RATE - 1) = Cost_MVMS
                Case 21
                    rtnTable.Rows(i).Item("COL" & ExcelWrite.ExcelPaymentLineColumn.COST_RATE - 1) = Cost_CISCOMA
            End Select

        Next

        Return rtnTable

    End Function

    ''' <summary>
    ''' 機能：Nullチェック
    ''' 説明：値がNullの場合、空文字を返す
    ''' </summary>
    ''' <param name="Value"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function changeDBNullToString(ByVal Value As Object) As String
        If IsDBNull(Value) Or IsNothing(Value) Then
            Return ""
        Else
            Return Value.ToString
        End If
    End Function

    ''' <summary>
    ''' 機　能：カンマ区切りのデータを分解する
    ''' 説　明：ダブルクォーテーション中のカンマも対応する
    ''' </summary>
    ''' <param name="strData">元データ</param>
    ''' <param name="strSplitData">分解後データ</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function SplitData(ByVal strData As String, ByRef strSplitData() As String) As Boolean

        Dim strSplitDelemita() As String        '
        Dim intCnt As Integer                   '
        Dim intIndex As Integer = 0             '
        Dim strWork As String                   '
        Dim intNextDataCtn As Integer           '
        Dim intStartCnt As Integer              '
        Dim intStepCnt As Integer               '
        Dim strComcatData As String             '
        Dim blnComcatData As Boolean            '

        SplitData = False

        '２個続きのダブルクォートを１つに変換する
        strWork = strData.Replace(Chr(34) & Chr(34), Chr(34))
        'カンマ区切りを分解する
        strSplitDelemita = strWork.Split(DELIMITA)

        '分解したデータをチェックする
        For intCnt = 0 To strSplitDelemita.Length - 1
            '両端にダブルクォーテーションがあるか
            If Left(LTrim(strSplitDelemita(intCnt)), 1) = Chr(34) Then
                '右端にダブルクォーテーションが出るまで繰り返す
                intStartCnt = intCnt
                intStepCnt = 0
                strComcatData = ""
                blnComcatData = False
                For intNextDataCtn = intStartCnt To (strSplitDelemita.Length - 1)
                    '次のデータがまだあるか
                    If intNextDataCtn <= (strSplitDelemita.Length - 1) Then
                        '右端にダブルクォーテーションがあるか
                        If Right(RTrim(strSplitDelemita(intNextDataCtn)), 1) = Chr(34) Then
                            '現データ＋結合データ＋カンマ＋次データを結合する
                            If intNextDataCtn = intStartCnt Then
                                strWork = strSplitDelemita(intCnt)
                                intCnt = intCnt + intStepCnt
                            Else
                                strWork = strSplitDelemita(intCnt) & strComcatData & DELIMITA & strSplitDelemita(intNextDataCtn)
                                intCnt = intCnt + intStepCnt + 1
                            End If
                            ReDim Preserve strSplitData(intIndex)
                            '両端のダウブルクォート削除
                            strSplitData(intIndex) = strWork.Substring(1, strWork.Length - 2)
                            intIndex = intIndex + 1
                            blnComcatData = True
                            Exit For
                        Else
                            If intNextDataCtn <> intStartCnt Then
                                strComcatData = strComcatData & DELIMITA & strSplitDelemita(intNextDataCtn)
                                intStepCnt = intStepCnt + 1
                            End If
                        End If
                    End If
                Next

                '右端にデータがなかった場合、通常データとして扱う
                If blnComcatData = False Then
                    ReDim Preserve strSplitData(intIndex)
                    strSplitData(intIndex) = strSplitDelemita(intCnt)
                    intIndex = intIndex + 1
                End If
            Else
                'ダブルクォーテーションがない場合
                ReDim Preserve strSplitData(intIndex)
                strSplitData(intIndex) = strSplitDelemita(intCnt)
                intIndex = intIndex + 1
            End If
        Next

        SplitData = True

    End Function

    ''' <summary>
    ''' 機　能：Excelの％項目をCSVのフォーマットへ変換する。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub ChangeExcelParcentFormatToCSV(ByRef obj As Object)

        ''初期化
        Dim rtnValue As Object
        rtnValue = 0

        If IsNumeric(obj) = True Then
            rtnValue = CDbl(obj) * 100
        End If

        obj = rtnValue

    End Sub

    '--------------------------------------------------------
    '概    要  ：ImportCsvファイルのBrand情報をサマリカテゴリへセットsる
    '説    明  ：
    '--------------------------------------------------------
    Private Function SetCsvBrandCategory(ByVal StrSplitLine() As String) As StringBuilder

        Dim sbBrandCat As New StringBuilder

        ''=================================================
        ''以下、ｻﾏﾘｰ用ｶﾃｺﾞﾘの作成ロジック
        ''=================================================		

        ''SubBrandが入力されているかどうか？
        If IsNothing(StrSplitLine(ExcelWrite.CsvPaymentLineColumn.BRAND_SUB - 1)) OrElse
            StrSplitLine(ExcelWrite.CsvPaymentLineColumn.BRAND_SUB - 1).ToString.Equals(String.Empty) Then

            ''新規/既存の判定			
            If Not IsNothing(StrSplitLine(ExcelWrite.CsvPaymentLineColumn.PATTERN_CD - 1)) AndAlso
                StrSplitLine(ExcelWrite.CsvPaymentLineColumn.PATTERN_CD - 1).ToString.Length > 0 Then

                Dim newExist As String = ""
                Select Case StrSplitLine(ExcelWrite.CsvPaymentLineColumn.PATTERN_CD - 1)
                    Case "15",
                         "16",
                         "17",
                         "18",
                         "19"

                        newExist = StrSplitLine(ExcelWrite.CsvPaymentLineColumn.NEW_EXIST - 1) & " "
                End Select

                sbBrandCat.Append(newExist)
            End If

            ''BUのセット
            If Not IsNothing(StrSplitLine(ExcelWrite.CsvPaymentLineColumn.BU - 1)) AndAlso StrSplitLine(ExcelWrite.CsvPaymentLineColumn.BU - 1).ToString.Length > 0 Then
                sbBrandCat.Append(StrSplitLine(ExcelWrite.CsvPaymentLineColumn.BU - 1).ToString)
            End If

            ''Brandのセット
            If Not IsNothing(StrSplitLine(ExcelWrite.CsvPaymentLineColumn.BRAND - 1)) AndAlso StrSplitLine(ExcelWrite.CsvPaymentLineColumn.BRAND - 1).ToString.Length > 0 Then
                If sbBrandCat.Length > 0 Then
                    sbBrandCat.Append(" ")
                End If
                sbBrandCat.Append(StrSplitLine(ExcelWrite.CsvPaymentLineColumn.BRAND - 1).ToString)
            End If
        Else

            ''新規/既存の判定
            If Not IsNothing(StrSplitLine(ExcelWrite.CsvPaymentLineColumn.PATTERN_CD - 1)) AndAlso
              StrSplitLine(ExcelWrite.CsvPaymentLineColumn.PATTERN_CD - 1).ToString.Length > 0 Then
                Dim newExist As String = ""
                Select Case StrSplitLine(ExcelWrite.CsvPaymentLineColumn.PATTERN_CD - 1)
                    Case "15",
                         "16",
                         "17",
                         "18",
                         "19"

                        newExist = StrSplitLine(ExcelWrite.CsvPaymentLineColumn.NEW_EXIST) & " "
                End Select

                sbBrandCat.Append(newExist)
            End If

            ''Sub Brandのセット
            If Not IsNothing(StrSplitLine(ExcelWrite.CsvPaymentLineColumn.BRAND_SUB - 1)) AndAlso StrSplitLine(ExcelWrite.CsvPaymentLineColumn.BRAND_SUB - 1).ToString.Length > 0 Then
                sbBrandCat.Append(StrSplitLine(ExcelWrite.CsvPaymentLineColumn.BRAND_SUB - 1).ToString)
            End If

            ''Option1のセット
            If Not IsNothing(StrSplitLine(ExcelWrite.CsvPaymentLineColumn.OP1 - 1)) AndAlso StrSplitLine(ExcelWrite.CsvPaymentLineColumn.OP1 - 1).ToString.Length > 0 Then
                If sbBrandCat.Length > 0 Then
                    sbBrandCat.Append(" ")
                End If
                sbBrandCat.Append(StrSplitLine(ExcelWrite.CsvPaymentLineColumn.OP1 - 1).ToString)
            End If

            ''Option2のセット
            If Not IsNothing(StrSplitLine(ExcelWrite.CsvPaymentLineColumn.OP2 - 1)) AndAlso StrSplitLine(ExcelWrite.CsvPaymentLineColumn.OP2 - 1).ToString.Length > 0 Then
                If sbBrandCat.Length > 0 Then
                    sbBrandCat.Append(" ")
                End If
                sbBrandCat.Append(StrSplitLine(ExcelWrite.CsvPaymentLineColumn.OP2 - 1).ToString)
            End If

            ''Sizeのセット
            If Not IsNothing(StrSplitLine(ExcelWrite.CsvPaymentLineColumn.BRAND_SIZE - 1)) AndAlso StrSplitLine(ExcelWrite.CsvPaymentLineColumn.BRAND_SIZE - 1).ToString.Length > 0 Then
                If sbBrandCat.Length > 0 Then
                    sbBrandCat.Append(" ")
                End If
                sbBrandCat.Append(StrSplitLine(ExcelWrite.CsvPaymentLineColumn.BRAND_SIZE - 1).ToString)
            End If

            ''SBO制限
            If Not IsNothing(StrSplitLine(ExcelWrite.CsvPaymentLineColumn.NON_SBO - 1)) AndAlso StrSplitLine(ExcelWrite.CsvPaymentLineColumn.NON_SBO - 1).ToString.Length > 0 Then
                If sbBrandCat.Length > 0 Then
                    sbBrandCat.Append(" ")
                End If
                sbBrandCat.Append(StrSplitLine(ExcelWrite.CsvPaymentLineColumn.NON_SBO - 1).ToString)
            End If

        End If

        Return sbBrandCat

    End Function


    '--------------------------------------------------------
    'メソッド名：GetBuBrandInfo
    '概    要  ：LOB名称が一致するConvertClientValueテーブルのBUとBrandを取得
    '説    明  ：※該当するデータが存在しなければ処理を行わない。
    '--------------------------------------------------------
    Private Function GetBuBrandInfo(ByVal ConvertClientValueData As DataTable,
                                    ByRef lobNm As String,
                                    ByVal lockFlg As String,
                                    ByRef aftBu As String,
                                    ByRef brand As String,
                                    ByRef patternCd As String,
                                    ByRef patternNm As String) As Boolean

        GetBuBrandInfo = True

        ''価格承認済み or 契約締結済みはBrand情報を更新しない。
        If lockFlg = "C" Or lockFlg = "N" Then
            Exit Function
        End If

        ''以下のElse句以外のパターンコードのみPaymentSheetのBU、Brand名称を変更する。
        Select Case patternCd
            Case CommonConstant.PATTERNCD_TYPE_IBM_HW_AAS_BOX
            Case CommonConstant.PATTERNCD_TYPE_IBM_HW_AAS_MES
            Case CommonConstant.PATTERNCD_TYPE_IBM_HW_QCOS
            Case CommonConstant.PATTERNCD_TYPE_HWBrandSW_AAS
            Case CommonConstant.PATTERNCD_TYPE_HWBrandSW_QCOS
            Case CommonConstant.PATTERNCD_TYPE_HWBrandSWMA_AAS
            Case CommonConstant.PATTERNCD_TYPE_HWBrandSWMA_QCOS
            Case CommonConstant.PATTERNCD_TYPE_SWBrandSW
            Case CommonConstant.PATTERNCD_TYPE_SWBrandSWMA
            Case CommonConstant.PATTERNCD_TYPE_PA
            Case Else
                Exit Function
        End Select

        ''抽出条件
        Dim filter As New StringBuilder
        filter.Append(ConvertClientValueTable.COLUMN_NAME_ServerValue)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(lobNm))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(ConvertClientValueTable.COLUMN_NAME_ClassCode)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(ConvertClientValueTable.CLASSCODE_IMPORTBRANDNAME))

        ''マッチしない場合、Log出力用にFalseを返す。
        If ConvertClientValueData.Select(filter.ToString).Length < 1 Then
            GetBuBrandInfo = False
            Exit Function
        End If

        ''LOB名称と一致する変換テーブルの値を取得
        For Each row As DataRow In ConvertClientValueData.Select(filter.ToString)
            ''PS項目追加対応 Str
            lobNm = changeDBNullToString(row.Item(ConvertClientValueTable.COLUMN_NAME_ClientValue))
            ''PS項目追加対応 End
            aftBu = changeDBNullToString(row.Item(ConvertClientValueTable.COLUMN_NAME_Option1))

            ''特殊ケース　
            ''※BUの変更によって、パターンNoとBrandの変更可能な場合、パターン、パターン名称、Brandを変換
            Call ChangeBrandInfo(patternCd, aftBu, brand, patternNm)

        Next

    End Function

    ''1555 ServicePac TBLから廃止予定日を取得 str
    '--------------------------------------------------------
    'メソッド名：GetServicePacInfo
    '概    要  ：項目1と項目3を元にServicePac TBLの RegistrationTerm を取得
    '説    明  ：※該当するデータが存在しなければCSVデータの値をセット
    '--------------------------------------------------------
    Private Function GetServicePacInfo(ByVal ServicePacData As DataTable,
                                       ByRef ITEM01 As String,
                                       ByVal ITEM03 As String,
                                       ByVal WDDATE As String) As String

        GetServicePacInfo = WDDATE

        Dim type As String
        Dim model As String
        type = Left(ITEM03, 4)
        model = Right(ITEM03, 3)

        ''抽出条件
        Dim filter As New StringBuilder
        filter.Append(ServicePacTable.COLUMN_NAME_SVCPAC_NO)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(ITEM01))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(ServicePacTable.COLUMN_NAME_MACHINETYPE)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(type))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(ServicePacTable.COLUMN_NAME_MODEL)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(model))

        ''マッチしない場合、Log出力用にFalseを返す。
        If ServicePacData.Select(filter.ToString).Length >= 1 Then
            For Each row As DataRow In ServicePacData.Select(filter.ToString)
                GetServicePacInfo = changeDBNullToString(row.Item(ServicePacTable.COLUMN_NAME_REGISTRATION_TERM))
            Next
        End If

    End Function
    ''1555 ServicePac TBLから廃止予定日を取得 end

    '--------------------------------------------------------
    'メソッド名：ChangeBrandInfo
    '概    要  ：特殊ケース
    '            ※BUの変更により、パターンCD,パターン名称、ブランド名称等が確定するデータは、変換する。
    '説    明  ：
    '--------------------------------------------------------
    Private Sub ChangeBrandInfo(ByRef patternCd As String,
                                ByVal aftBu As String,
                                ByRef brand As String,
                                ByRef patternNm As String)

        ''BUが決定すればBrand等が確定できる入力パターンをSelect
        Select Case patternCd
            Case CommonConstant.PATTERNCD_TYPE_HWBrandSW_AAS

                If aftBu = CommonConstant.BUNM_SWG Then

                    patternCd = CommonConstant.PATTERNCD_TYPE_SWBrandSW
                    patternNm = CommonConstant.PATTERNNM_SWBrandSW
                    brand = CommonConstant.BRANDNM_SW_BRAND_SW

                End If

            Case CommonConstant.PATTERNCD_TYPE_HWBrandSWMA_AAS

                If aftBu = CommonConstant.BUNM_SWG Then

                    patternCd = CommonConstant.PATTERNCD_TYPE_SWBrandSWMA
                    patternNm = CommonConstant.PATTERNNM_SWBrandSWMA
                    brand = CommonConstant.BRANDNM_SW_BRAND_SWMA

                End If

            Case CommonConstant.PATTERNCD_TYPE_SWBrandSW

                If aftBu = CommonConstant.BUNM_STG Then

                    patternCd = CommonConstant.PATTERNCD_TYPE_HWBrandSW_AAS
                    patternNm = CommonConstant.PATTERNNM_HWBrandSW_AAS
                    brand = CommonConstant.BRANDNM_HW_BRAND_SW

                End If

            Case CommonConstant.PATTERNCD_TYPE_SWBrandSWMA

                If aftBu = CommonConstant.BUNM_STG Then

                    patternCd = CommonConstant.PATTERNCD_TYPE_HWBrandSWMA_AAS
                    patternNm = CommonConstant.PATTERNNM_HWBrandSWMA_AAS
                    brand = CommonConstant.BRANDNM_HW_BRAND_SWMA

                End If

        End Select

    End Sub

    '--------------------------------------------------------
    '概    要  ：HWMAの保証種類を、Excel用に変換する
    '説    明  ：
    '--------------------------------------------------------
    Private Function GetQcosWarrantytermName(ByVal item7 As Object,
                                             ByVal ConvertClientValueData As DataTable) As String

        GetQcosWarrantytermName = item7

        ''保障種類のサーバーでの名称ををCodeデータから検索する
        Dim filter As New StringBuilder
        filter.Append(ConvertClientValueTable.COLUMN_NAME_ClassCode)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(ConvertClientValueTable.CLASSCODE_IMPORTQCOSWARRANTYTERMNAME))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(ConvertClientValueTable.COLUMN_NAME_ServerValue)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(item7))

        Dim selectRow As DataRow
        For Each selectRow In ConvertClientValueData.Select(filter.ToString)
            GetQcosWarrantytermName = selectRow(ConvertClientValueTable.COLUMN_NAME_ClientValue)
        Next

    End Function


    '--------------------------------------------------------
    '概    要  ：PALevelを、Excel用に変換する
    '説    明  ：
    '--------------------------------------------------------
    Private Function GetPALevelName(ByVal item3 As Object,
                                    ByVal ConvertClientValueData As DataTable) As String

        GetPALevelName = item3

        ''PALevelの名称をConvertClientValueデータから検索する
        Dim filter As New StringBuilder
        filter.Append(ConvertClientValueTable.COLUMN_NAME_ClassCode)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(ConvertClientValueTable.CLASSCODE_IMPORTPALEVELNAME))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(ConvertClientValueTable.COLUMN_NAME_ServerValue)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(item3))

        Dim selectRow As DataRow
        For Each selectRow In ConvertClientValueData.Select(filter.ToString)
            GetPALevelName = selectRow(ConvertClientValueTable.COLUMN_NAME_ClientValue)
        Next

    End Function


    '--------------------------------------------------------
    '概    要  ：CSVの1行データを値をExcel出力用に加工する。
    '説    明  ：
    '--------------------------------------------------------
    ''1555 ServicePac TBLの登録可能期限を廃止予定日にセット str
    'Private Function SetWriteExcelObjLine(ByRef con As OleDbConnection, _
    '                                      ByVal StrSplitLine() As String,
    '                                      ByVal qcosWarrantytermCode As DataTable,
    '                                      ByVal clientValueTable As DataTable,
    '                                      ByRef LOBNMUnMatchMessage As String) As Object()
    Private Function SetWriteExcelObjLine(ByRef con As OleDbConnection, _
                                          ByVal StrSplitLine() As String,
                                          ByVal qcosWarrantytermCode As DataTable,
                                          ByVal clientValueTable As DataTable,
                                          ByVal ServicePacTable As DataTable,
                                          ByRef LOBNMUnMatchMessage As String) As Object()
        ''1555 ServicePac TBLの登録可能期限を廃止予定日にセット end

        Dim rtnValue(CsvPaymentLineColumn.PRICE_YEAR20_MONTH12 - 1) As Object
        SetWriteExcelObjLine = rtnValue
        Dim tmpWriteObjLine(CsvPaymentLineColumn.PRICE_YEAR20_MONTH12 - 1) As Object
        Dim strWork As String

        ''Bu,BrandをLOBコードをKeyに取得
        Dim bu As String = StrSplitLine(CsvPaymentLineColumn.BU - 1)

        ''特殊ケース
        ''※Bu情報の変更により、パターン名称と、Brandの変更が判別できるもののみ値をセット
        ''※LOB名称 = 空白の場合、判定ロジックを行わない。
        Dim brand As String = StrSplitLine(CsvPaymentLineColumn.BRAND - 1)
        Dim patternCd As String = ExcelWrite.GetPatternCD(StrSplitLine(CsvPaymentLineColumn.PATTERN_CD - 1), StrSplitLine(CsvPaymentLineColumn.PATTERN - 1))
        Dim patternNm As String = StrSplitLine(CsvPaymentLineColumn.PATTERN - 1)

        'Req.1656 パターン名称補正 2018/09 Str
        Dim wQTY As String = StrSplitLine(CsvPaymentLineColumn.QTY - 1)
        'Req.1656 パターン名称補正 2018/09 End
        'Req.1656 パターン名称補正 2018/10 Str
        Dim wItem01 As String = StrSplitLine(CsvPaymentLineColumn.PROD_ITEM01 - 1)
        'Req.1656 パターン名称補正 2018/10 End

        Dim subBrand As String = StrSplitLine(CsvPaymentLineColumn.BRAND_SUB - 1)
        If subBrand.Trim <> "" Then

            If GetBuBrandInfo(clientValueTable, subBrand, StrSplitLine(CsvPaymentLineColumn.LOCK_FLAG - 1), bu, brand, patternCd, patternNm) = False Then
                ''LOBコードのUnMatchエラーメッセージをセット
                LOBNMUnMatchMessage = LOBNMUnMatchMessage & FileReader.GetMessage("MSG_0277") & StrSplitLine(CsvPaymentLineColumn.BRAND_SUB - 1)
            Else
                LOBNMUnMatchMessage = ""
            End If
        End If

        ''1555 ServicePac TBLの登録可能期限を廃止予定日にセット str
        Dim ITEM01 As String = StrSplitLine(CsvPaymentLineColumn.PROD_ITEM01 - 1)
        Dim ITEM03 As String = StrSplitLine(CsvPaymentLineColumn.PROD_ITEM03 - 1)
        Dim WDDATE As String = StrSplitLine(CsvPaymentLineColumn.WD_DATE - 1)
        Dim RegistrationTerm As String

        If patternCd = CommonConstant.PATTERNCD_TYPE_HWServicePac  Then
            ''LOBコードのUnMatchエラーメッセージをセット
            RegistrationTerm = GetServicePacInfo(ServicePacTable, ITEM01, ITEM03, WDDATE)
        End If
        ''1555 ServicePac TBLの登録可能期限を廃止予定日にセット end

        Dim nonvpa As String
        Dim maintePrice As Double
        Dim IsMaPrice As Boolean = False
        Dim IsExcMaPrice As Boolean = False
        If patternCd = CommonConstant.PATTERNCD_TYPE_IBM_HWMA_QCOS And _
           StrSplitLine(CsvPaymentLineColumn.PAY_VALIDATION - 1) <> "N" And _
           StrSplitLine(CsvPaymentLineColumn.PROD_ITEM05 - 1) = "CHIS" Then

            IsMaPrice = GetNewMAMaintePrice(con, Trim(StrSplitLine(CsvPaymentLineColumn.PROD_ITEM01 - 1)), maintePrice, nonvpa)

            IsExcMaPrice = IsMaPrice
            ''ListPriceのみは標準保証金額を更新しない。
            If StrSplitLine(CsvPaymentLineColumn.PAY_VALIDATION - 1) = "L" Or _
               StrSplitLine(CsvPaymentLineColumn.PAY_VALIDATION - 1) = "P" Then
                If IsNumeric(StrSplitLine(CsvPaymentLineColumn.PROD_ITEM13 - 1)) = True Then
                    maintePrice = StrSplitLine(CsvPaymentLineColumn.PROD_ITEM13 - 1)
                Else
                    IsExcMaPrice = False
                End If
            End If
        End If

        Try

            ''=====================================================================
            ''					Csvデータを整形する。
            ''=====================================================================
            For n As Integer = CsvPaymentLineColumn.UPDATE_FLAG To _
                               CsvPaymentLineColumn.PRICE_YEAR20_MONTH12
                Select Case n
                    Case CsvPaymentLineColumn.UPDATE_FLAG

                        '無条件でブランクをセットする
                        Continue For

                    Case CsvPaymentLineColumn.LINE_NO,
                         CsvPaymentLineColumn.CONTRACT,
                         CsvPaymentLineColumn.QTY,
                         CsvPaymentLineColumn.LIST_PRICE_PROPOSAL,
                         CsvPaymentLineColumn.LIST_PRICE_REFLESH

                        '数字項目のため、数字にして表示する
                        If StrSplitLine(n - 1).ToString().Length > 0 Then
                            Dim convNum As Long = 0
                            convNum = Convert.ToInt64(StrSplitLine(n - 1).ToString)
                            tmpWriteObjLine(n - 1) = convNum
                        Else
                            tmpWriteObjLine(n - 1) = StrSplitLine(n - 1)
                        End If

                    Case CsvPaymentLineColumn.INST_YEAR,
                        CsvPaymentLineColumn.INST_MONTH,
                        CsvPaymentLineColumn.PAY_START_YEAR,
                        CsvPaymentLineColumn.PAY_START_MONTH,
                        CsvPaymentLineColumn.PAY_END_YEAR,
                        CsvPaymentLineColumn.PAY_END_MONTH
                        If n = CsvPaymentLineColumn.INST_YEAR Or
                            n = CsvPaymentLineColumn.PAY_START_YEAR Or
                            n = CsvPaymentLineColumn.PAY_END_YEAR Then
                            strWork = StrSplitLine(n - 1).ToString & "/" & StrSplitLine(n).ToString & "/01"
                            If IsDate(strWork) = True Then
                                tmpWriteObjLine(n - 1) = CDate(strWork).ToString("yyyy/MM/dd")
                            Else
                                tmpWriteObjLine(n - 1) = ""
                            End If
                        End If

                    Case CsvPaymentLineColumn.PAY_MONTHS,
                         CsvPaymentLineColumn.LIST_PRICE_TOTAL_PROPOSAL,
                         CsvPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH,
                         CsvPaymentLineColumn.PRICE_UNIT_IOC,
                         CsvPaymentLineColumn.PRICE_QTY_IOC,
                         CsvPaymentLineColumn.COST_TOTAL,
                         CsvPaymentLineColumn.LIST_PRICE_TOTAL_IOC,
                         CsvPaymentLineColumn.PRICE_TOTAL_IOC,
                         CsvPaymentLineColumn.PRICE_TOTAL_IGF,
                         CsvPaymentLineColumn.CONTRACT_IN,
                         CsvPaymentLineColumn.CONTRACT_OUT,
                         CsvPaymentLineColumn.PRICE_DEFF_IGF

                        ''Excel式のため、値をセットしない
                        Continue For

                    Case CsvPaymentLineColumn.IGF_RATE_IOC,
                         CsvPaymentLineColumn.DP_IOC,
                         CsvPaymentLineColumn.COST_RATE

                        '%表示にするために100分の１にする
                        If StrSplitLine(n - 1).ToString().Length > 0 Then
                            StrSplitLine(n - 1) = GetParsentFormat(Convert.ToDecimal(StrSplitLine(n - 1).ToString) / 100)
                        End If
                        tmpWriteObjLine(n - 1) = StrSplitLine(n - 1)

                    Case CsvPaymentLineColumn.BU
                        ''BU,BrandはサーバーのSubBrand名から、判定する。
                        tmpWriteObjLine(CsvPaymentLineColumn.BU - 1) = bu

                    Case CsvPaymentLineColumn.BRAND
                        tmpWriteObjLine(CsvPaymentLineColumn.BRAND - 1) = brand

                    Case CsvPaymentLineColumn.BRAND_SUB
                        tmpWriteObjLine(CsvPaymentLineColumn.BRAND_SUB - 1) = subBrand

                    Case CsvPaymentLineColumn.PATTERN_CD
                        tmpWriteObjLine(CsvPaymentLineColumn.PATTERN_CD - 1) = patternCd

                    Case CsvPaymentLineColumn.PATTERN
                        'Req.1656 パターン名称補正 2018/09 Str
                        'tmpWriteObjLine(CsvPaymentLineColumn.PATTERN - 1) = patternNm
                        'Req.1656 パターン名称補正 2018/10 Str
                        'tmpWriteObjLine(CsvPaymentLineColumn.PATTERN - 1) = GetPatternNm(patternCd, patternNm, wQTY)
                        tmpWriteObjLine(CsvPaymentLineColumn.PATTERN - 1) = GetPatternNm(patternCd, patternNm, wQTY, wItem01)
                        'Req.1656 パターン名称補正 2018/10 End
                        'Req.1656 パターン名称補正 2018/09 End

                    Case CsvPaymentLineColumn.PROD_ITEM03

                        tmpWriteObjLine(n - 1) = StrSplitLine(n - 1).ToString()

                        ''PAかどうか判定
                        If ExcelWrite.GetPatternCD(StrSplitLine(CsvPaymentLineColumn.PATTERN_CD - 1).ToString(), StrSplitLine(CsvPaymentLineColumn.PATTERN - 1).ToString()) = "11" Then
                            ''PAレベルをサーバー用の表記からクライアント表記へ変換
                            tmpWriteObjLine(n - 1) = GetPALevelName(StrSplitLine(CsvPaymentLineColumn.PROD_ITEM03 - 1), clientValueTable)

                        End If

                    Case CsvPaymentLineColumn.PROD_ITEM07
                        ''HWMAかどうか判定
                        If ExcelWrite.GetPatternCD(StrSplitLine(CsvPaymentLineColumn.PATTERN_CD - 1).ToString(), StrSplitLine(CsvPaymentLineColumn.PATTERN - 1).ToString()) = "3" Or
                           ExcelWrite.GetPatternCD(StrSplitLine(CsvPaymentLineColumn.PATTERN_CD - 1).ToString(), StrSplitLine(CsvPaymentLineColumn.PATTERN - 1).ToString()) = "15" Or
                           ExcelWrite.GetPatternCD(StrSplitLine(CsvPaymentLineColumn.PATTERN_CD - 1).ToString(), StrSplitLine(CsvPaymentLineColumn.PATTERN - 1).ToString()) = "16" Or
                           ExcelWrite.GetPatternCD(StrSplitLine(CsvPaymentLineColumn.PATTERN_CD - 1).ToString(), StrSplitLine(CsvPaymentLineColumn.PATTERN - 1).ToString()) = "17" Then

                            ''サーバー表記からクライアント表記へ切り替え
                            If IsMaPrice = True Then
                                tmpWriteObjLine(n - 1) = GetQcosWarrantytermName(nonvpa, clientValueTable)
                            Else
                                tmpWriteObjLine(n - 1) = GetQcosWarrantytermName(StrSplitLine(n - 1), clientValueTable)
                            End If
                        Else
                            tmpWriteObjLine(n - 1) = StrSplitLine(n - 1)
                        End If

                    Case CsvPaymentLineColumn.PROD_ITEM13

                        If IsExcMaPrice = True Then
                            tmpWriteObjLine(n - 1) = maintePrice
                        Else
                            tmpWriteObjLine(n - 1) = StrSplitLine(n - 1)
                        End If

                    Case CsvPaymentLineColumn.PRICE_TO_SPLIT
                        ''パターンコード29はcsvの展開金額をセット
                        If patternCd = "29" Or _
                           ExcelWrite.changeDBNullToString(StrSplitLine(CsvPaymentLineColumn.PAY_FLAG - 1)) = "固定" Then
                            Dim convNum As Long = 0
                            If IsNumeric(StrSplitLine(CsvPaymentLineColumn.PRICE_TO_SPLIT - 1)) Then
                                convNum = Convert.ToInt64(StrSplitLine(CsvPaymentLineColumn.PRICE_TO_SPLIT - 1))
                                tmpWriteObjLine(CsvPaymentLineColumn.PRICE_TO_SPLIT - 1) = convNum
                            Else
                                tmpWriteObjLine(CsvPaymentLineColumn.PRICE_TO_SPLIT - 1) = ExcelWrite.changeDBNullToString(StrSplitLine(CsvPaymentLineColumn.PRICE_TO_SPLIT - 1))
                            End If
                        End If
                    Case CsvPaymentLineColumn.PRICE_YEAR1 To CsvPaymentLineColumn.PRICE_YEAR20_MONTH12
                        '月次展開にCSVの内容を代入
                        tmpWriteObjLine(n - 1) = StrSplitLine(n - 1)
                        ''1555 ServicePac TBLの登録可能期限を廃止予定日にセット str
                    Case CsvPaymentLineColumn.WD_DATE
                        If patternCd = CommonConstant.PATTERNCD_TYPE_HWServicePac Then
                            tmpWriteObjLine(n - 1) = RegistrationTerm
                        Else
                            tmpWriteObjLine(n - 1) = StrSplitLine(n - 1)
                        End If
                        ''1555 ServicePac TBLの登録可能期限を廃止予定日にセット end
                    Case Else
                        tmpWriteObjLine(n - 1) = StrSplitLine(n - 1)
                End Select
            Next

            ''=====================================================================
            ''					　　Csvデータの位置を変更する。
            ''=====================================================================
            Select Case patternCd
                Case CommonConstant.PATTERNCD_TYPE_IBM_HW_AAS_BOX,
                     CommonConstant.PATTERNCD_TYPE_IBM_HW_AAS_MES,
                     CommonConstant.PATTERNCD_TYPE_IBM_HW_QCOS,
                     CommonConstant.PATTERNCD_TYPE_HWBrandSW_AAS,
                     CommonConstant.PATTERNCD_TYPE_HWBrandSW_QCOS,
                     CommonConstant.PATTERNCD_TYPE_HWBrandSWMA_AAS,
                     CommonConstant.PATTERNCD_TYPE_HWBrandSWMA_QCOS,
                     CommonConstant.PATTERNCD_TYPE_SWBrandSW,
                     CommonConstant.PATTERNCD_TYPE_SWBrandSWMA,
                     CommonConstant.PATTERNCD_TYPE_VLS,
                     CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_BOX,
                     CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_MES,
                     CommonConstant.PATTERNCD_TYPE_IBM_HWMA_QCOS,
                     CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_WarrantyOP,
                     CommonConstant.PATTERNCD_TYPE_IBM_HWMA_QCOS_WarrantyOP
                    Dim Item2 As String = ExcelWrite.changeDBNullToString(StrSplitLine(CsvPaymentLineColumn.PROD_ITEM02 - 1))
                    tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM02 - 1) = tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM03 - 1)
                    tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM03 - 1) = Item2
                Case CommonConstant.PATTERNCD_TYPE_PA
                    Dim Item6 As String = ExcelWrite.changeDBNullToString(StrSplitLine(CsvPaymentLineColumn.PROD_ITEM06 - 1))
                    tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM06 - 1) = tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM05 - 1)
                    tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM05 - 1) = tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM04 - 1)
                    tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM04 - 1) = tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM03 - 1)
                    tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM03 - 1) = tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM02 - 1)
                    tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM02 - 1) = Item6
                Case CommonConstant.PATTERNCD_TYPE_HWServicePac,
                     CommonConstant.PATTERNCD_TYPE_SWServicePac
                    Dim Item5 As String = ExcelWrite.changeDBNullToString(StrSplitLine(CsvPaymentLineColumn.PROD_ITEM05 - 1))
                    tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM05 - 1) = tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM04 - 1)
                    tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM04 - 1) = tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM03 - 1)
                    tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM03 - 1) = tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM02 - 1)
                    tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM02 - 1) = Item5
            End Select

            ''※現状、PaymentのCsvファイルの項目数は増減しても、Excel上の項目数を据え置きの対応にしている。
            ''　なので、若干関数ヘッダによるレスポンス低下が見込まれるが、一時的な処理として変換関数をかませる。
            ''　⇒Excel上の項目数が一致した場合、以下の関数をコメントアウトする。
            rtnValue = ChangeChisExcelItem(tmpWriteObjLine)
            Return rtnValue

        Catch ex As Exception
            Throw ex
        End Try


    End Function


    '--------------------------------------------------------
    '概    要  ：CSVの1行データを値をExcel出力用に加工する。
    '			 ※(契約締結済み、価格承認済み用)
    '説    明  ：
    '--------------------------------------------------------
    ''1555 ServicePac TBLの登録可能期限を廃止予定日にセット str
    'Public Function SetWriteExcelObjLineConclusion(ByVal StrSplitLine() As String,
    '                                               ByVal qcosWarrantytermCode As DataTable,
    '                                               ByVal clientValueTable As DataTable) As Object()
    Public Function SetWriteExcelObjLineConclusion(ByVal StrSplitLine() As String,
                                                   ByVal qcosWarrantytermCode As DataTable,
                                                   ByVal clientValueTable As DataTable,
                                                   ByVal ServicePacTable As DataTable) As Object()
        ''1555 ServicePac TBLの登録可能期限を廃止予定日にセット end

        Dim rtnValue(CsvPaymentLineColumn.PRICE_YEAR20_MONTH12 - 1) As Object               ''戻り値(Excelに出力する項目を保持)
        SetWriteExcelObjLineConclusion = rtnValue
        Dim tmpWriteObjLine(CsvPaymentLineColumn.PRICE_YEAR20_MONTH12 - 1) As Object    ''Chis対応後のCSVﾃﾞｰﾀを保持
        Dim strWork As String

        ''1555 ServicePac TBLの登録可能期限を廃止予定日にセット str
        Dim patternCd As String = ExcelWrite.GetPatternCD(StrSplitLine(CsvPaymentLineColumn.PATTERN_CD - 1), StrSplitLine(CsvPaymentLineColumn.PATTERN - 1))
        Dim ITEM01 As String = StrSplitLine(CsvPaymentLineColumn.PROD_ITEM01 - 1)
        Dim ITEM03 As String = StrSplitLine(CsvPaymentLineColumn.PROD_ITEM03 - 1)
        Dim WDDATE As String = StrSplitLine(CsvPaymentLineColumn.WD_DATE - 1)
        Dim RegistrationTerm As String

        If patternCd = CommonConstant.PATTERNCD_TYPE_HWServicePac Then
            ''LOBコードのUnMatchエラーメッセージをセット
            RegistrationTerm = GetServicePacInfo(ServicePacTable, ITEM01, ITEM03, WDDATE)
        End If
        ''1555 ServicePac TBLの登録可能期限を廃止予定日にセット end


        Try
            ''=====================================================================
            ''					　　CsvデータをExcel出力用に整形する。
            ''=====================================================================
            'セルに値を代入
            For n As Integer = CsvPaymentLineColumn.UPDATE_FLAG To _
                               CsvPaymentLineColumn.PRICE_YEAR20_MONTH12
                Select Case n
                    Case CsvPaymentLineColumn.UPDATE_FLAG

                        '無条件でブランクをセットする
                        Continue For

                    Case CsvPaymentLineColumn.LINE_NO,
                         CsvPaymentLineColumn.CONTRACT, _
                         CsvPaymentLineColumn.QTY, _
                         CsvPaymentLineColumn.LIST_PRICE_PROPOSAL, _
                         CsvPaymentLineColumn.LIST_PRICE_REFLESH

                        '数字項目のため、数字にして表示する
                        If StrSplitLine(n - 1).ToString().Length > 0 Then
                            Dim convNum As Long = 0
                            convNum = Convert.ToInt64(StrSplitLine(n - 1).ToString)
                            tmpWriteObjLine(n - 1) = convNum
                        Else
                            tmpWriteObjLine(n - 1) = StrSplitLine(n - 1)
                        End If

                    Case CsvPaymentLineColumn.INST_YEAR,
                        CsvPaymentLineColumn.INST_MONTH,
                        CsvPaymentLineColumn.PAY_START_YEAR,
                        CsvPaymentLineColumn.PAY_START_MONTH,
                        CsvPaymentLineColumn.PAY_END_YEAR,
                        CsvPaymentLineColumn.PAY_END_MONTH
                        If n = CsvPaymentLineColumn.INST_YEAR Or
                            n = CsvPaymentLineColumn.PAY_START_YEAR Or
                            n = CsvPaymentLineColumn.PAY_END_YEAR Then
                            strWork = StrSplitLine(n - 1).ToString & "/" & StrSplitLine(n).ToString & "/01"
                            If IsDate(strWork) = True Then
                                tmpWriteObjLine(n - 1) = CDate(strWork).ToString("yyyy/MM/dd")
                            Else
                                tmpWriteObjLine(n - 1) = ""
                            End If
                        End If

                    Case CsvPaymentLineColumn.IGF_RATE_IOC, _
                         CsvPaymentLineColumn.DP_IOC, _
                         CsvPaymentLineColumn.COST_RATE

                        '%表示にするために100分の１にする
                        If StrSplitLine(n - 1).ToString().Length > 0 Then
                            StrSplitLine(n - 1) = GetParsentFormat(Convert.ToDecimal(StrSplitLine(n - 1).ToString) / 100)
                        End If
                        tmpWriteObjLine(n - 1) = StrSplitLine(n - 1)

                    Case CsvPaymentLineColumn.PROD_ITEM03

                        ''PAかどうか判定
                        tmpWriteObjLine(n - 1) = StrSplitLine(n - 1).ToString()
                        If ExcelWrite.GetPatternCD(StrSplitLine(CsvPaymentLineColumn.PATTERN_CD - 1).ToString(), StrSplitLine(CsvPaymentLineColumn.PATTERN - 1).ToString()) = "11" Then
                            ''PAレベルをサーバー用の表記からクライアント表記へ変換
                            tmpWriteObjLine(n - 1) = GetPALevelName(StrSplitLine(CsvPaymentLineColumn.PROD_ITEM03 - 1), clientValueTable)
                        End If

                    Case CsvPaymentLineColumn.PROD_ITEM07

                        ''HWMAかどうか判定
                        If GetPatternCD(StrSplitLine(CsvPaymentLineColumn.PATTERN_CD - 1).ToString(), StrSplitLine(CsvPaymentLineColumn.PATTERN - 1).ToString()) = "15" Or
                           GetPatternCD(StrSplitLine(CsvPaymentLineColumn.PATTERN_CD - 1).ToString(), StrSplitLine(CsvPaymentLineColumn.PATTERN - 1).ToString()) = "16" Or
                           GetPatternCD(StrSplitLine(CsvPaymentLineColumn.PATTERN_CD - 1).ToString(), StrSplitLine(CsvPaymentLineColumn.PATTERN - 1).ToString()) = "17" Then

                            ''サーバー表記からクライアント表記へ切り替え
                            tmpWriteObjLine(n - 1) = GetQcosWarrantytermName(StrSplitLine(n - 1), clientValueTable)
                        Else
                            tmpWriteObjLine(n - 1) = StrSplitLine(n - 1)
                        End If

                    Case CsvPaymentLineColumn.PRICE_YEAR1_MONTH1 To CsvPaymentLineColumn.PRICE_YEAR20_MONTH12

                        'CSVの内容を代入
                        If IsNumeric(StrSplitLine(n - 1)) = True Then
                            tmpWriteObjLine(n - 1) = StrSplitLine(n - 1)
                        Else
                            tmpWriteObjLine(n - 1) = "0"
                        End If

                        ''1555 ServicePac TBLの登録可能期限を廃止予定日にセット str
                    Case CsvPaymentLineColumn.WD_DATE
                        If patternCd = CommonConstant.PATTERNCD_TYPE_HWServicePac Then
                            tmpWriteObjLine(n - 1) = RegistrationTerm
                        Else
                            tmpWriteObjLine(n - 1) = StrSplitLine(n - 1)
                        End If
                        ''1555 ServicePac TBLの登録可能期限を廃止予定日にセット end

                    Case Else
                        tmpWriteObjLine(n - 1) = StrSplitLine(n - 1)
                End Select
            Next

            ''=====================================================================
            ''					　　Csvデータの位置を変更する。
            ''=====================================================================
            ''1555 ServicePac TBLの登録可能期限を廃止予定日にセット str
            'Dim patternCd As String = ExcelWrite.GetPatternCD(StrSplitLine(CsvPaymentLineColumn.PATTERN_CD - 1), StrSplitLine(CsvPaymentLineColumn.PATTERN - 1))
            ''1555 ServicePac TBLの登録可能期限を廃止予定日にセット end
            Select Case patternCd
                Case CommonConstant.PATTERNCD_TYPE_IBM_HW_AAS_BOX,
                     CommonConstant.PATTERNCD_TYPE_IBM_HW_AAS_MES,
                     CommonConstant.PATTERNCD_TYPE_IBM_HW_QCOS,
                     CommonConstant.PATTERNCD_TYPE_HWBrandSW_AAS,
                     CommonConstant.PATTERNCD_TYPE_HWBrandSW_QCOS,
                     CommonConstant.PATTERNCD_TYPE_HWBrandSWMA_AAS,
                     CommonConstant.PATTERNCD_TYPE_HWBrandSWMA_QCOS,
                     CommonConstant.PATTERNCD_TYPE_SWBrandSW,
                     CommonConstant.PATTERNCD_TYPE_SWBrandSWMA,
                     CommonConstant.PATTERNCD_TYPE_VLS,
                     CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_BOX,
                     CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_MES,
                     CommonConstant.PATTERNCD_TYPE_IBM_HWMA_QCOS,
                     CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_WarrantyOP,
                     CommonConstant.PATTERNCD_TYPE_IBM_HWMA_QCOS_WarrantyOP
                    Dim Item2 As String = ExcelWrite.changeDBNullToString(StrSplitLine(CsvPaymentLineColumn.PROD_ITEM02 - 1))
                    tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM02 - 1) = tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM03 - 1)
                    tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM03 - 1) = Item2
                Case CommonConstant.PATTERNCD_TYPE_PA
                    Dim Item6 As String = ExcelWrite.changeDBNullToString(StrSplitLine(CsvPaymentLineColumn.PROD_ITEM06 - 1))
                    tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM06 - 1) = tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM05 - 1)
                    tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM05 - 1) = tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM04 - 1)
                    tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM04 - 1) = tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM03 - 1)
                    tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM03 - 1) = tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM02 - 1)
                    tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM02 - 1) = Item6
                Case CommonConstant.PATTERNCD_TYPE_HWServicePac,
                     CommonConstant.PATTERNCD_TYPE_SWServicePac
                    Dim Item5 As String = ExcelWrite.changeDBNullToString(StrSplitLine(CsvPaymentLineColumn.PROD_ITEM05 - 1))
                    tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM05 - 1) = tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM04 - 1)
                    tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM04 - 1) = tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM03 - 1)
                    tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM03 - 1) = tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM02 - 1)
                    tmpWriteObjLine(CsvPaymentLineColumn.PROD_ITEM02 - 1) = Item5
            End Select

            ''※現状、PaymentのCsvファイルの項目数は増減しても、Excel上の項目数を据え置きの対応にしている。
            ''　なので、若干関数ヘッダによるレスポンス低下が見込まれるが、一時的な処理として変換関数をかませる。
            ''　⇒Excel上の項目数が一致した場合、以下の関数をコメントアウトする。
            rtnValue = ChangeChisExcelItem(tmpWriteObjLine)
            Return rtnValue

        Catch ex As Exception
            Throw ex
        End Try

    End Function

    Public Function SetWriteExcelObjLineConclusionVerUp(ByVal StrSplitLine() As String,
                                                        ByVal qcosWarrantytermCode As DataTable,
                                                        ByVal clientValueTable As DataTable) As Object()

        Dim rtnValue(ExcelPaymentLineColumn.PRICE_YEAR12_MONTH12 - 1) As Object     ''戻り値(Excelに出力する項目を保持)
        Dim tmpWriteObjLine(OldDbPsColumn.PRICE_YEAR12_MONTH12 - 1) As Object       ''Chis対応後のCSVﾃﾞｰﾀを保持

        SetWriteExcelObjLineConclusionVerUp = rtnValue

        Try
            ''=====================================================================
            ''					　　CsvデータをExcel出力用に整形する。
            ''=====================================================================
            'セルに値を代入
            For n As Integer = OldDbPsColumn.UPDATE_FLAG To _
                               OldDbPsColumn.PRICE_YEAR12_MONTH12
                Select Case n
                    Case OldDbPsColumn.UPDATE_FLAG

                        '無条件でブランクをセットする
                        Continue For

                    Case OldDbPsColumn.LINE_NO,
                         OldDbPsColumn.CONTRACT, _
                         OldDbPsColumn.QTY, _
                         OldDbPsColumn.INST_YEAR, _
                         OldDbPsColumn.INST_MONTH, _
                         OldDbPsColumn.PAY_START_YEAR, _
                         OldDbPsColumn.PAY_START_MONTH, _
                         OldDbPsColumn.PAY_END_YEAR, _
                         OldDbPsColumn.PAY_END_MONTH, _
                         OldDbPsColumn.LIST_PRICE_PROPOSAL, _
                         OldDbPsColumn.LIST_PRICE_REFLESH

                        '数字項目のため、数字にして表示する
                        If StrSplitLine(n - 1).ToString().Length > 0 Then
                            Dim convNum As Long = 0
                            convNum = Convert.ToInt64(StrSplitLine(n - 1).ToString)
                            tmpWriteObjLine(n - 1) = convNum
                        Else
                            tmpWriteObjLine(n - 1) = StrSplitLine(n - 1)
                        End If

                    Case OldDbPsColumn.IGF_RATE_BAUCOC, _
                         OldDbPsColumn.IGF_RATE_IOC, _
                         OldDbPsColumn.DP_BAU, _
                         OldDbPsColumn.DP_COC, _
                         OldDbPsColumn.DP_IOC, _
                         OldDbPsColumn.COST_RATE

                        '%表示にするために100分の１にする
                        If StrSplitLine(n - 1).ToString().Length > 0 Then
                            StrSplitLine(n - 1) = GetParsentFormat(Convert.ToDecimal(StrSplitLine(n - 1).ToString) / 100)
                        End If
                        tmpWriteObjLine(n - 1) = StrSplitLine(n - 1)

                    Case OldDbPsColumn.PROD_ITEM03

                        ''PAかどうか判定
                        tmpWriteObjLine(n - 1) = StrSplitLine(n - 1).ToString()
                        If ExcelWrite.GetPatternCD(StrSplitLine(OldDbPsColumn.PATTERN_CD - 1).ToString(), StrSplitLine(OldDbPsColumn.PATTERN - 1).ToString()) = "11" Then
                            ''PAレベルをサーバー用の表記からクライアント表記へ変換
                            tmpWriteObjLine(n - 1) = GetPALevelName(StrSplitLine(OldDbPsColumn.PROD_ITEM03 - 1), clientValueTable)
                        End If

                    Case OldDbPsColumn.PROD_ITEM07

                        ''HWMAかどうか判定
                        If GetPatternCD(StrSplitLine(OldDbPsColumn.PATTERN_CD - 1).ToString(), StrSplitLine(OldDbPsColumn.PATTERN - 1).ToString()) = "15" Or
                           GetPatternCD(StrSplitLine(OldDbPsColumn.PATTERN_CD - 1).ToString(), StrSplitLine(OldDbPsColumn.PATTERN - 1).ToString()) = "16" Or
                           GetPatternCD(StrSplitLine(OldDbPsColumn.PATTERN_CD - 1).ToString(), StrSplitLine(OldDbPsColumn.PATTERN - 1).ToString()) = "17" Then

                            ''サーバー表記からクライアント表記へ切り替え
                            tmpWriteObjLine(n - 1) = GetQcosWarrantytermName(StrSplitLine(n - 1), clientValueTable)
                        Else
                            tmpWriteObjLine(n - 1) = StrSplitLine(n - 1)
                        End If

                    Case OldDbPsColumn.TAX_RATE

                        ''消費税はデフォルト5%
                        tmpWriteObjLine(n - 1) = 0.05

                    Case OldDbPsColumn.PRICE_YEAR1_MONTH1 To OldDbPsColumn.PRICE_YEAR12_MONTH12

                        'CSVの内容を代入
                        If IsNumeric(StrSplitLine(n - 1)) = True Then
                            tmpWriteObjLine(n - 1) = StrSplitLine(n - 1)
                        Else
                            tmpWriteObjLine(n - 1) = "0"
                        End If

                    Case Else
                        tmpWriteObjLine(n - 1) = StrSplitLine(n - 1)
                End Select
            Next

            ''=====================================================================
            ''					　　Csvデータの位置を変更する。
            ''=====================================================================
            Dim patternCd As String = ExcelWrite.GetPatternCD(StrSplitLine(OldDbPsColumn.PATTERN_CD - 1), StrSplitLine(OldDbPsColumn.PATTERN - 1))
            Select Case patternCd
                Case CommonConstant.PATTERNCD_TYPE_IBM_HW_AAS_BOX,
                     CommonConstant.PATTERNCD_TYPE_IBM_HW_AAS_MES,
                     CommonConstant.PATTERNCD_TYPE_IBM_HW_QCOS,
                     CommonConstant.PATTERNCD_TYPE_HWBrandSW_AAS,
                     CommonConstant.PATTERNCD_TYPE_HWBrandSW_QCOS,
                     CommonConstant.PATTERNCD_TYPE_HWBrandSWMA_AAS,
                     CommonConstant.PATTERNCD_TYPE_HWBrandSWMA_QCOS,
                     CommonConstant.PATTERNCD_TYPE_SWBrandSW,
                     CommonConstant.PATTERNCD_TYPE_SWBrandSWMA,
                     CommonConstant.PATTERNCD_TYPE_VLS,
                     CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_BOX,
                     CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_MES,
                     CommonConstant.PATTERNCD_TYPE_IBM_HWMA_QCOS,
                     CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_WarrantyOP,
                     CommonConstant.PATTERNCD_TYPE_IBM_HWMA_QCOS_WarrantyOP
                    Dim Item2 As String = ExcelWrite.changeDBNullToString(StrSplitLine(OldDbPsColumn.PROD_ITEM02 - 1))
                    tmpWriteObjLine(OldDbPsColumn.PROD_ITEM02 - 1) = tmpWriteObjLine(OldDbPsColumn.PROD_ITEM03 - 1)
                    tmpWriteObjLine(OldDbPsColumn.PROD_ITEM03 - 1) = Item2
                Case CommonConstant.PATTERNCD_TYPE_PA
                    Dim Item6 As String = ExcelWrite.changeDBNullToString(StrSplitLine(OldDbPsColumn.PROD_ITEM06 - 1))
                    tmpWriteObjLine(OldDbPsColumn.PROD_ITEM06 - 1) = tmpWriteObjLine(OldDbPsColumn.PROD_ITEM05 - 1)
                    tmpWriteObjLine(OldDbPsColumn.PROD_ITEM05 - 1) = tmpWriteObjLine(OldDbPsColumn.PROD_ITEM04 - 1)
                    tmpWriteObjLine(OldDbPsColumn.PROD_ITEM04 - 1) = tmpWriteObjLine(OldDbPsColumn.PROD_ITEM03 - 1)
                    tmpWriteObjLine(OldDbPsColumn.PROD_ITEM03 - 1) = tmpWriteObjLine(OldDbPsColumn.PROD_ITEM02 - 1)
                    tmpWriteObjLine(OldDbPsColumn.PROD_ITEM02 - 1) = Item6
                Case CommonConstant.PATTERNCD_TYPE_HWServicePac,
                     CommonConstant.PATTERNCD_TYPE_SWServicePac
                    Dim Item5 As String = ExcelWrite.changeDBNullToString(StrSplitLine(OldDbPsColumn.PROD_ITEM05 - 1))
                    tmpWriteObjLine(OldDbPsColumn.PROD_ITEM05 - 1) = tmpWriteObjLine(OldDbPsColumn.PROD_ITEM04 - 1)
                    tmpWriteObjLine(OldDbPsColumn.PROD_ITEM04 - 1) = tmpWriteObjLine(OldDbPsColumn.PROD_ITEM03 - 1)
                    tmpWriteObjLine(OldDbPsColumn.PROD_ITEM03 - 1) = tmpWriteObjLine(OldDbPsColumn.PROD_ITEM02 - 1)
                    tmpWriteObjLine(OldDbPsColumn.PROD_ITEM02 - 1) = Item5
            End Select

            ''※現状、PaymentのCsvファイルの項目数は増減しても、Excel上の項目数を据え置きの対応にしている。
            ''　なので、若干関数ヘッダによるレスポンス低下が見込まれるが、一時的な処理として変換関数をかませる。
            ''　⇒Excel上の項目数が一致した場合、以下の関数をコメントアウトする。
            rtnValue = ChangeExcelItemVerUp(tmpWriteObjLine)

            Return rtnValue

        Catch ex As Exception
            Throw ex
        End Try

    End Function

    ''' <summary>
    '''概  要：Chis対応用のCSVの項目の並びをExcel上の項目のならびに変換する。
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function ChangeChisExcelItem(ByRef tmpWriteObjLine() As Object) As Object()

        '戻り値
        Dim rtnValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12 - 1) As Object

        'Chis対応用のCSVの項目の並びをExcel上の項目のならびに変換する。
        For Idx As Integer = ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG - 1 To _
                             ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12 - 1

            rtnValue(Idx) = tmpWriteObjLine((Me.ChangePaymentLineColumn(Idx + 1) - 1))
        Next

        Return rtnValue

    End Function

    ''' <summary>
    '''概  要：CSVの項目の並びをExcel上の項目のならびに変換する。(バージョンアップ用)
    ''' </summary>
    ''' <param name="tmpWriteObjLine"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ChangeExcelItemVerUp(ByRef tmpWriteObjLine() As Object) As Object()

        ''戻り値
        Dim rtnValue(ExcelWrite.OldExcelPsColumn.PRICE_YEAR12_MONTH12 - 1) As Object

        Return rtnValue

    End Function

    ''' <summary>
    '''概  要：Chis項目と、修正前の項目の対応表をセット
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub SetChangePaymentLineColumn()

        ''相対月はCSV定義より削除されているため、除外
        Dim setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12) As Integer
        setValue(ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG) = ExcelWrite.CsvPaymentLineColumn.UPDATE_FLAG                              ''更新FLG           
        setValue(ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG) = ExcelWrite.CsvPaymentLineColumn.LOCK_FLAG                                  ''ﾛｯｸFLG
        setValue(ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG) = ExcelWrite.CsvPaymentLineColumn.VALID_FLAG                                ''有効/無効
        setValue(ExcelWrite.ExcelPaymentLineColumn.LINE_NO) = ExcelWrite.CsvPaymentLineColumn.LINE_NO                                      ''NO
        setValue(ExcelWrite.ExcelPaymentLineColumn.FILE_NAME) = ExcelWrite.CsvPaymentLineColumn.FILE_NAME                                  ''ﾌｧｲﾙ名
        setValue(ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX) = ExcelWrite.CsvPaymentLineColumn.FILE_NAME_SUFFIX                    ''ﾌｧｲﾙ名Suffix
        setValue(ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR) = ExcelWrite.CsvPaymentLineColumn.FILE_NAME_SUFFIX_INTR          ''ﾌｧｲﾙ内Suffix
        setValue(ExcelWrite.ExcelPaymentLineColumn.CONTRACT) = ExcelWrite.CsvPaymentLineColumn.CONTRACT                                    ''契約順番
        setValue(ExcelWrite.ExcelPaymentLineColumn.ST_COST) = ExcelWrite.CsvPaymentLineColumn.ST_COST                                      ''COST_開示依頼
        setValue(ExcelWrite.ExcelPaymentLineColumn.ST_APPROVAL) = ExcelWrite.CsvPaymentLineColumn.ST_APPROVAL                              ''価格承認_申請依頼
        setValue(ExcelWrite.ExcelPaymentLineColumn.PROJ_ID) = ExcelWrite.CsvPaymentLineColumn.PROJ_ID                                      ''案件番号
        setValue(ExcelWrite.ExcelPaymentLineColumn.CONTRACT_SEQ) = ExcelWrite.CsvPaymentLineColumn.CONTRACT_SEQ                            ''契約通番
        setValue(ExcelWrite.ExcelPaymentLineColumn.NEW_EXIST) = ExcelWrite.CsvPaymentLineColumn.NEW_EXIST                                  ''新規/既存
        setValue(ExcelWrite.ExcelPaymentLineColumn.CUST_CATEGORY) = ExcelWrite.CsvPaymentLineColumn.CUST_CATEGORY                          ''お客様集計ｶﾃｺﾞﾘ
        setValue(ExcelWrite.ExcelPaymentLineColumn.LETTER_PLAN_DATE) = ExcelWrite.CsvPaymentLineColumn.LETTER_PLAN_DATE                    ''実行通知書_発行予定日
        setValue(ExcelWrite.ExcelPaymentLineColumn.LETTER_ACCEPT_DATE) = ExcelWrite.CsvPaymentLineColumn.LETTER_ACCEPT_DATE                ''実行通知書_受領日
        setValue(ExcelWrite.ExcelPaymentLineColumn.ORDER_DATE) = ExcelWrite.CsvPaymentLineColumn.ORDER_DATE                                ''発注完了日
        setValue(ExcelWrite.ExcelPaymentLineColumn.LETTER_ID) = ExcelWrite.CsvPaymentLineColumn.LETTER_ID                                  ''実行通知書番号
        setValue(ExcelWrite.ExcelPaymentLineColumn.ORDERCODE) = ExcelWrite.CsvPaymentLineColumn.ORDERCODE                                  ''請求コード
        setValue(ExcelWrite.ExcelPaymentLineColumn.BU) = ExcelWrite.CsvPaymentLineColumn.BU                                                ''Brand Category_BU
        setValue(ExcelWrite.ExcelPaymentLineColumn.BRAND) = ExcelWrite.CsvPaymentLineColumn.BRAND                                          ''Brand Category_Brand
        setValue(ExcelWrite.ExcelPaymentLineColumn.SUM_CATEGORY) = ExcelWrite.CsvPaymentLineColumn.SUM_CATEGORY                            ''Brand Category_ｻﾏﾘｰ用ｶﾃｺﾞﾘ
        setValue(ExcelWrite.ExcelPaymentLineColumn.BRAND_SUB) = ExcelWrite.CsvPaymentLineColumn.BRAND_SUB                                  ''Brand Category_SubBrand
        setValue(ExcelWrite.ExcelPaymentLineColumn.OP1) = ExcelWrite.CsvPaymentLineColumn.OP1                                              ''Brand Category_Option1
        setValue(ExcelWrite.ExcelPaymentLineColumn.OP2) = ExcelWrite.CsvPaymentLineColumn.OP2                                              ''Brand Category_Option2
        setValue(ExcelWrite.ExcelPaymentLineColumn.BRAND_SIZE) = ExcelWrite.CsvPaymentLineColumn.BRAND_SIZE                                ''Brand Category_Size
        setValue(ExcelWrite.ExcelPaymentLineColumn.NON_SBO) = ExcelWrite.CsvPaymentLineColumn.NON_SBO                                      ''Brand Category_SBO制限
        setValue(ExcelWrite.ExcelPaymentLineColumn.POSTSCRIPT) = ExcelWrite.CsvPaymentLineColumn.POSTSCRIPT                                ''Brand Category_追記事項
        setValue(ExcelWrite.ExcelPaymentLineColumn.TOPACS_CPNO) = ExcelWrite.CsvPaymentLineColumn.TOPACS_CPNO                              ''Brand承認_TOPACS CPNO
        setValue(ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_FORM) = ExcelWrite.CsvPaymentLineColumn.BRAND_AP_FORM                          ''Brand承認_起票番号
        setValue(ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_REQ) = ExcelWrite.CsvPaymentLineColumn.BRAND_AP_REQ                            ''Brand承認_申請番号
        setValue(ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_CONF) = ExcelWrite.CsvPaymentLineColumn.BRAND_AP_CONF                          ''Brand承認_承認番号
        setValue(ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD) = ExcelWrite.CsvPaymentLineColumn.PATTERN_CD                                ''入力項目ﾊﾟﾀｰﾝ SEQ
        setValue(ExcelWrite.ExcelPaymentLineColumn.PATTERN) = ExcelWrite.CsvPaymentLineColumn.PATTERN                                      ''入力項目ﾊﾟﾀｰﾝ
        setValue(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01) = ExcelWrite.CsvPaymentLineColumn.PROD_ITEM01                              ''ﾊﾟﾀｰﾝ別入力項目_項目１
        setValue(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02) = ExcelWrite.CsvPaymentLineColumn.PROD_ITEM02                              ''ﾊﾟﾀｰﾝ別入力項目_項目２
        setValue(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03) = ExcelWrite.CsvPaymentLineColumn.PROD_ITEM03                              ''ﾊﾟﾀｰﾝ別入力項目_項目３
        setValue(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM04) = ExcelWrite.CsvPaymentLineColumn.PROD_ITEM04                              ''ﾊﾟﾀｰﾝ別入力項目_項目４
        setValue(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM05) = ExcelWrite.CsvPaymentLineColumn.PROD_ITEM05                              ''ﾊﾟﾀｰﾝ別入力項目_項目５
        setValue(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM06) = ExcelWrite.CsvPaymentLineColumn.PROD_ITEM06                              ''ﾊﾟﾀｰﾝ別入力項目_項目６
        setValue(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM07) = ExcelWrite.CsvPaymentLineColumn.PROD_ITEM07                              ''ﾊﾟﾀｰﾝ別入力項目_項目７
        setValue(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM08) = ExcelWrite.CsvPaymentLineColumn.PROD_ITEM08                              ''ﾊﾟﾀｰﾝ別入力項目_項目８
        setValue(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM09) = ExcelWrite.CsvPaymentLineColumn.PROD_ITEM09                              ''ﾊﾟﾀｰﾝ別入力項目_項目９
        setValue(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10) = ExcelWrite.CsvPaymentLineColumn.PROD_ITEM10                              ''ﾊﾟﾀｰﾝ別入力項目_項目１０
        setValue(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11) = ExcelWrite.CsvPaymentLineColumn.PROD_ITEM11                              ''ﾊﾟﾀｰﾝ別入力項目_項目１１
        setValue(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12) = ExcelWrite.CsvPaymentLineColumn.PROD_ITEM12                              ''ﾊﾟﾀｰﾝ別入力項目_項目１２
        setValue(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM13) = ExcelWrite.CsvPaymentLineColumn.PROD_ITEM13                              ''ﾊﾟﾀｰﾝ別入力項目_項目１３
        setValue(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM14) = ExcelWrite.CsvPaymentLineColumn.PROD_ITEM14                              ''ﾊﾟﾀｰﾝ別入力項目_項目１４
        setValue(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM15) = ExcelWrite.CsvPaymentLineColumn.PROD_ITEM15                              ''ﾊﾟﾀｰﾝ別入力項目_項目１５
        setValue(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM16) = ExcelWrite.CsvPaymentLineColumn.INV_EXP                                  ''ﾊﾟﾀｰﾝ別入力項目_項目１６
        setValue(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM17) = ExcelWrite.CsvPaymentLineColumn.LETTER_ISSUE_DATE                        ''ﾊﾟﾀｰﾝ別入力項目_項目１７
        setValue(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM18) = ExcelWrite.CsvPaymentLineColumn.IGF_RATE_BAUCOC                          ''ﾊﾟﾀｰﾝ別入力項目_項目１８
        setValue(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM19) = ExcelWrite.CsvPaymentLineColumn.DP_BAU                                   ''ﾊﾟﾀｰﾝ別入力項目_項目１９
        setValue(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM20) = ExcelWrite.CsvPaymentLineColumn.DP_COC                                   ''ﾊﾟﾀｰﾝ別入力項目_項目２０
        setValue(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM22) = ExcelWrite.CsvPaymentLineColumn.PRICE_QTY_BAU                            ''ﾊﾟﾀｰﾝ別入力項目_項目２２
        setValue(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM23) = ExcelWrite.CsvPaymentLineColumn.PRICE_UNIT_COC                           ''ﾊﾟﾀｰﾝ別入力項目_項目２３
        setValue(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM24) = ExcelWrite.CsvPaymentLineColumn.PRICE_QTY_COC                            ''ﾊﾟﾀｰﾝ別入力項目_項目２４
        setValue(ExcelWrite.ExcelPaymentLineColumn.WD_ANNT_DATE) = ExcelWrite.CsvPaymentLineColumn.WD_ANNT_DATE                            ''製品･ｻｰﾋﾞｽ廃止発表日
        setValue(ExcelWrite.ExcelPaymentLineColumn.WD_DATE) = ExcelWrite.CsvPaymentLineColumn.WD_DATE                                      ''製品･ｻｰﾋﾞｽ廃止予定
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_CHG_DATE) = ExcelWrite.CsvPaymentLineColumn.PRICE_CHG_DATE                        ''価格改定予定日
        setValue(ExcelWrite.ExcelPaymentLineColumn.QTY) = ExcelWrite.CsvPaymentLineColumn.QTY                                              ''数量
        setValue(ExcelWrite.ExcelPaymentLineColumn.INST_DATE) = ExcelWrite.CsvPaymentLineColumn.INST_YEAR                                  ''導入_年月
        setValue(ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE) = ExcelWrite.CsvPaymentLineColumn.PAY_START_YEAR                        ''請求開始_年月
        setValue(ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE) = ExcelWrite.CsvPaymentLineColumn.PAY_END_YEAR                            ''請求終了_年月
        setValue(ExcelWrite.ExcelPaymentLineColumn.IGF_START_DATE) = ExcelWrite.CsvPaymentLineColumn.IGF_START_DATE                        ''IGF計算開始_年月
        setValue(ExcelWrite.ExcelPaymentLineColumn.IGF_END_DATE) = ExcelWrite.CsvPaymentLineColumn.IGF_END_DATE                            ''IGF計算終了_年月
        setValue(ExcelWrite.ExcelPaymentLineColumn.PAY_FLAG) = ExcelWrite.CsvPaymentLineColumn.PAY_FLAG                                    ''Payment展開
        setValue(ExcelWrite.ExcelPaymentLineColumn.BID_FLAG) = ExcelWrite.CsvPaymentLineColumn.BID_FLAG                                    ''定額BID
        setValue(ExcelWrite.ExcelPaymentLineColumn.PAY_MONTHS) = ExcelWrite.CsvPaymentLineColumn.PAY_MONTHS                                ''請求期間
        setValue(ExcelWrite.ExcelPaymentLineColumn.PAY_VALIDATION) = ExcelWrite.CsvPaymentLineColumn.PAY_VALIDATION                        ''Validation
        setValue(ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD) = ExcelWrite.CsvPaymentLineColumn.PAY_METHOD                                ''支払方法
        setValue(ExcelWrite.ExcelPaymentLineColumn.IGF_APPLIED) = ExcelWrite.CsvPaymentLineColumn.IGF_APPLIED                              ''IGF_対象
        setValue(ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_NO) = ExcelWrite.CsvPaymentLineColumn.IGF_CONT_NO                              ''IGF契約番号
        setValue(ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_FORM) = ExcelWrite.CsvPaymentLineColumn.IGF_CONT_FORM                          ''IGF契約形態
        setValue(ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_MANAGMENT) = ExcelWrite.CsvPaymentLineColumn.IGF_CONT_MANAGMENT                ''IGF契約物件管理
        setValue(ExcelWrite.ExcelPaymentLineColumn.IGF_RATE_IOC) = ExcelWrite.CsvPaymentLineColumn.IGF_RATE_IOC                            ''IGF_IOC料率
        setValue(ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL) = ExcelWrite.CsvPaymentLineColumn.LIST_PRICE_PROPOSAL              ''Listprice(単価)_提案時
        setValue(ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH) = ExcelWrite.CsvPaymentLineColumn.LIST_PRICE_REFLESH                    ''Listprice(単価)_ﾘﾌﾚｯｼｭ後
        setValue(ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_PROPOSAL) = ExcelWrite.CsvPaymentLineColumn.LIST_PRICE_TOTAL_PROPOSAL  ''Listprice(合計)_提案時	
        setValue(ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH) = ExcelWrite.CsvPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH    ''Listprice(合計)_ﾘﾌﾚｯｼｭ後	
        setValue(ExcelWrite.ExcelPaymentLineColumn.DP_IOC) = ExcelWrite.CsvPaymentLineColumn.DP_IOC                                        ''IOC D%
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC) = ExcelWrite.CsvPaymentLineColumn.PRICE_UNIT_IOC                        ''Offering Price_単価Validation前
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC_VAL) = ExcelWrite.CsvPaymentLineColumn.PRICE_UNIT_BAU                    ''Offering Price 単価Validation後
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC) = ExcelWrite.CsvPaymentLineColumn.PRICE_QTY_IOC                          ''Offering Price_小計
        setValue(ExcelWrite.ExcelPaymentLineColumn.COST_RATE) = ExcelWrite.CsvPaymentLineColumn.COST_RATE                                  ''COST %
        setValue(ExcelWrite.ExcelPaymentLineColumn.COST) = ExcelWrite.CsvPaymentLineColumn.COST                                            ''COST_単価
        setValue(ExcelWrite.ExcelPaymentLineColumn.COST_TOTAL) = ExcelWrite.CsvPaymentLineColumn.COST_TOTAL                                ''COST_合計
        setValue(ExcelWrite.ExcelPaymentLineColumn.COST_INPUT_DATE) = ExcelWrite.CsvPaymentLineColumn.COST_INPUT_DATE                      ''COST_入力日
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_TO_SPLIT) = ExcelWrite.CsvPaymentLineColumn.PRICE_TO_SPLIT                        ''展開金額
        setValue(ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_IOC) = ExcelWrite.CsvPaymentLineColumn.LIST_PRICE_TOTAL_IOC            ''Listprice_期間合計
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_TOTAL_IOC) = ExcelWrite.CsvPaymentLineColumn.PRICE_TOTAL_IOC                      ''D%適用後_期間合計
        setValue(ExcelWrite.ExcelPaymentLineColumn.COST_TOTAL_IOC) = ExcelWrite.CsvPaymentLineColumn.COST_TOTAL_IOC                        ''COST_期間合計
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_TOTAL_IGF) = ExcelWrite.CsvPaymentLineColumn.PRICE_TOTAL_IGF                      ''IGF適用後 期間合計
        setValue(ExcelWrite.ExcelPaymentLineColumn.CONTRACT_IN) = ExcelWrite.CsvPaymentLineColumn.CONTRACT_IN                              ''契約期間内
        setValue(ExcelWrite.ExcelPaymentLineColumn.CONTRACT_OUT) = ExcelWrite.CsvPaymentLineColumn.CONTRACT_OUT                            ''契約期間外
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_DEFF_IGF) = ExcelWrite.CsvPaymentLineColumn.PRICE_DEFF_IGF                        ''IGF金利(差額)
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR1                              ''年度情報1
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR2                              ''年度情報2
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR3                              ''年度情報3
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR4                              ''年度情報4
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR5                              ''年度情報5
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR6                              ''年度情報6
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR7                              ''年度情報7
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR8                              ''年度情報8
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR9                              ''年度情報9
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR10                            ''年度情報10
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR11                            ''年度情報11
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR12                            ''年度情報12
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR13                            ''年度情報13
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR14                            ''年度情報14
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR15                            ''年度情報15
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR16                            ''年度情報16
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR17                            ''年度情報17
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR18                            ''年度情報18
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR19                            ''年度情報19
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20                            ''年度情報20
        setValue(ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL) = ExcelWrite.CsvPaymentLineColumn.TAX_RATE                            ''過去の契約金額合計
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR1_MONTH1                ''年度1_月度情報1
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH2) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR1_MONTH2                ''年度1_月度情報2
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH3) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR1_MONTH3                ''年度1_月度情報3
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH4) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR1_MONTH4                ''年度1_月度情報4
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH5) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR1_MONTH5                ''年度1_月度情報5
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH6) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR1_MONTH6                ''年度1_月度情報6
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH7) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR1_MONTH7                ''年度1_月度情報7
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH8) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR1_MONTH8                ''年度1_月度情報8
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH9) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR1_MONTH9                ''年度1_月度情報9
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH10) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR1_MONTH10              ''年度1_月度情報10
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH11) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR1_MONTH11              ''年度1_月度情報11
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH12) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR1_MONTH12              ''年度1_月度情報12
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH1) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR2_MONTH1                ''年度2_月度情報1
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH2) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR2_MONTH2                ''年度2_月度情報2
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH3) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR2_MONTH3                ''年度2_月度情報3
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH4) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR2_MONTH4                ''年度2_月度情報4
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH5) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR2_MONTH5                ''年度2_月度情報5
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH6) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR2_MONTH6                ''年度2_月度情報6
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH7) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR2_MONTH7                ''年度2_月度情報7
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH8) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR2_MONTH8                ''年度2_月度情報8
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH9) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR2_MONTH9                ''年度2_月度情報9
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH10) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR2_MONTH10              ''年度2_月度情報10
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH11) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR2_MONTH11              ''年度2_月度情報11
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH12) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR2_MONTH12              ''年度2_月度情報12
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH1) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR3_MONTH1                ''年度3_月度情報1
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH2) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR3_MONTH2                ''年度3_月度情報2
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH3) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR3_MONTH3                ''年度3_月度情報3
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH4) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR3_MONTH4                ''年度3_月度情報4
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH5) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR3_MONTH5                ''年度3_月度情報5
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH6) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR3_MONTH6                ''年度3_月度情報6
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH7) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR3_MONTH7                ''年度3_月度情報7
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH8) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR3_MONTH8                ''年度3_月度情報8
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH9) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR3_MONTH9                ''年度3_月度情報9
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH10) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR3_MONTH10              ''年度3_月度情報10
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH11) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR3_MONTH11              ''年度3_月度情報11
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH12) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR3_MONTH12              ''年度3_月度情報12
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH1) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR4_MONTH1                ''年度4_月度情報1
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH2) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR4_MONTH2                ''年度4_月度情報2
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH3) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR4_MONTH3                ''年度4_月度情報3
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH4) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR4_MONTH4                ''年度4_月度情報4
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH5) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR4_MONTH5                ''年度4_月度情報5
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH6) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR4_MONTH6                ''年度4_月度情報6
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH7) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR4_MONTH7                ''年度4_月度情報7
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH8) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR4_MONTH8                ''年度4_月度情報8
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH9) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR4_MONTH9                ''年度4_月度情報9
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH10) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR4_MONTH10              ''年度4_月度情報10
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH11) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR4_MONTH11              ''年度4_月度情報11
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH12) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR4_MONTH12              ''年度4_月度情報12
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH1) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR5_MONTH1                ''年度5_月度情報1
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH2) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR5_MONTH2                ''年度5_月度情報2
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH3) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR5_MONTH3                ''年度5_月度情報3
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH4) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR5_MONTH4                ''年度5_月度情報4
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH5) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR5_MONTH5                ''年度5_月度情報5
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH6) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR5_MONTH6                ''年度5_月度情報6
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH7) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR5_MONTH7                ''年度5_月度情報7
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH8) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR5_MONTH8                ''年度5_月度情報8
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH9) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR5_MONTH9                ''年度5_月度情報9
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH10) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR5_MONTH10              ''年度5_月度情報10
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH11) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR5_MONTH11              ''年度5_月度情報11
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH12) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR5_MONTH12              ''年度5_月度情報12
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH1) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR6_MONTH1                ''年度6_月度情報1
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH2) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR6_MONTH2                ''年度6_月度情報2
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH3) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR6_MONTH3                ''年度6_月度情報3
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH4) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR6_MONTH4                ''年度6_月度情報4
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH5) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR6_MONTH5                ''年度6_月度情報5
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH6) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR6_MONTH6                ''年度6_月度情報6
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH7) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR6_MONTH7                ''年度6_月度情報7
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH8) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR6_MONTH8                ''年度6_月度情報8
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH9) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR6_MONTH9                ''年度6_月度情報9
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH10) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR6_MONTH10              ''年度6_月度情報10
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH11) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR6_MONTH11              ''年度6_月度情報11
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH12) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR6_MONTH12              ''年度6_月度情報12
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH1) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR7_MONTH1                ''年度7_月度情報1
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH2) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR7_MONTH2                ''年度7_月度情報2
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH3) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR7_MONTH3                ''年度7_月度情報3
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH4) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR7_MONTH4                ''年度7_月度情報4
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH5) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR7_MONTH5                ''年度7_月度情報5
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH6) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR7_MONTH6                ''年度7_月度情報6
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH7) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR7_MONTH7                ''年度7_月度情報7
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH8) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR7_MONTH8                ''年度7_月度情報8
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH9) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR7_MONTH9                ''年度7_月度情報9
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH10) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR7_MONTH10              ''年度7_月度情報10
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH11) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR7_MONTH11              ''年度7_月度情報11
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH12) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR7_MONTH12              ''年度7_月度情報12
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH1) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR8_MONTH1                ''年度8_月度情報1
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH2) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR8_MONTH2                ''年度8_月度情報2
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH3) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR8_MONTH3                ''年度8_月度情報3
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH4) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR8_MONTH4                ''年度8_月度情報4
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH5) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR8_MONTH5                ''年度8_月度情報5
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH6) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR8_MONTH6                ''年度8_月度情報6
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH7) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR8_MONTH7                ''年度8_月度情報7
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH8) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR8_MONTH8                ''年度8_月度情報8
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH9) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR8_MONTH9                ''年度8_月度情報9
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH10) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR8_MONTH10              ''年度8_月度情報10
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH11) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR8_MONTH11              ''年度8_月度情報11
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH12) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR8_MONTH12              ''年度8_月度情報12
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH1) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR9_MONTH1                ''年度9_月度情報1
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH2) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR9_MONTH2                ''年度9_月度情報2
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH3) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR9_MONTH3                ''年度9_月度情報3
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH4) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR9_MONTH4                ''年度9_月度情報4
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH5) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR9_MONTH5                ''年度9_月度情報5
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH6) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR9_MONTH6                ''年度9_月度情報6
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH7) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR9_MONTH7                ''年度9_月度情報7
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH8) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR9_MONTH8                ''年度9_月度情報8
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH9) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR9_MONTH9                ''年度9_月度情報9
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH10) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR9_MONTH10              ''年度9_月度情報10
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH11) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR9_MONTH11              ''年度9_月度情報11
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH12) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR9_MONTH12              ''年度9_月度情報12
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH1) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR10_MONTH1              ''年度10_月度情報1
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH2) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR10_MONTH2              ''年度10_月度情報2
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH3) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR10_MONTH3              ''年度10_月度情報3
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH4) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR10_MONTH4              ''年度10_月度情報4
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH5) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR10_MONTH5              ''年度10_月度情報5
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH6) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR10_MONTH6              ''年度10_月度情報6
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH7) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR10_MONTH7              ''年度10_月度情報7
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH8) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR10_MONTH8              ''年度10_月度情報8
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH9) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR10_MONTH9              ''年度10_月度情報9
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH10) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR10_MONTH10            ''年度10_月度情報10
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH11) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR10_MONTH11            ''年度10_月度情報11
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH12) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR10_MONTH12            ''年度10_月度情報12
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH1) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR11_MONTH1              ''年度11_月度情報1
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH2) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR11_MONTH2              ''年度11_月度情報2
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH3) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR11_MONTH3              ''年度11_月度情報3
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH4) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR11_MONTH4              ''年度11_月度情報4
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH5) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR11_MONTH5              ''年度11_月度情報5
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH6) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR11_MONTH6              ''年度11_月度情報6
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH7) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR11_MONTH7              ''年度11_月度情報7
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH8) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR11_MONTH8              ''年度11_月度情報8
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH9) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR11_MONTH9              ''年度11_月度情報9
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH10) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR11_MONTH10            ''年度11_月度情報10
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH11) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR11_MONTH11            ''年度11_月度情報11
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH12) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR11_MONTH12            ''年度11_月度情報12
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH1) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR12_MONTH1              ''年度12_月度情報1
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH2) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR12_MONTH2              ''年度12_月度情報2
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH3) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR12_MONTH3              ''年度12_月度情報3
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH4) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR12_MONTH4              ''年度12_月度情報4
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH5) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR12_MONTH5              ''年度12_月度情報5
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH6) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR12_MONTH6              ''年度12_月度情報6
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH7) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR12_MONTH7              ''年度12_月度情報7
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH8) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR12_MONTH8              ''年度12_月度情報8
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH9) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR12_MONTH9              ''年度12_月度情報9
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH10) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR12_MONTH10            ''年度12_月度情報10
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH11) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR12_MONTH11            ''年度12_月度情報11
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH12) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR12_MONTH12            ''年度12_月度情報12
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH1) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR13_MONTH1              ''年度13_月度情報1
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH2) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR13_MONTH2              ''年度13_月度情報2
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH3) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR13_MONTH3              ''年度13_月度情報3
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH4) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR13_MONTH4              ''年度13_月度情報4
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH5) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR13_MONTH5              ''年度13_月度情報5
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH6) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR13_MONTH6              ''年度13_月度情報6
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH7) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR13_MONTH7              ''年度13_月度情報7
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH8) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR13_MONTH8              ''年度13_月度情報8
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH9) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR13_MONTH9              ''年度13_月度情報9
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH10) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR13_MONTH10            ''年度13_月度情報10
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH11) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR13_MONTH11            ''年度13_月度情報11
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH12) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR13_MONTH12            ''年度13_月度情報12
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH1) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR14_MONTH1              ''年度14_月度情報1
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH2) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR14_MONTH2              ''年度14_月度情報2
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH3) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR14_MONTH3              ''年度14_月度情報3
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH4) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR14_MONTH4              ''年度14_月度情報4
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH5) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR14_MONTH5              ''年度14_月度情報5
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH6) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR14_MONTH6              ''年度14_月度情報6
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH7) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR14_MONTH7              ''年度14_月度情報7
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH8) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR14_MONTH8              ''年度14_月度情報8
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH9) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR14_MONTH9              ''年度14_月度情報9
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH10) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR14_MONTH10            ''年度14_月度情報10
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH11) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR14_MONTH11            ''年度14_月度情報11
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH12) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR14_MONTH12            ''年度14_月度情報12
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH1) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR15_MONTH1              ''年度15_月度情報1
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH2) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR15_MONTH2              ''年度15_月度情報2
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH3) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR15_MONTH3              ''年度15_月度情報3
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH4) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR15_MONTH4              ''年度15_月度情報4
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH5) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR15_MONTH5              ''年度15_月度情報5
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH6) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR15_MONTH6              ''年度15_月度情報6
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH7) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR15_MONTH7              ''年度15_月度情報7
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH8) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR15_MONTH8              ''年度15_月度情報8
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH9) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR15_MONTH9              ''年度15_月度情報9
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH10) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR15_MONTH10            ''年度15_月度情報10
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH11) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR15_MONTH11            ''年度15_月度情報11
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH12) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR15_MONTH12            ''年度15_月度情報12
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH1) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR16_MONTH1              ''年度16_月度情報1
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH2) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR16_MONTH2              ''年度16_月度情報2
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH3) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR16_MONTH3              ''年度16_月度情報3
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH4) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR16_MONTH4              ''年度16_月度情報4
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH5) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR16_MONTH5              ''年度16_月度情報5
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH6) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR16_MONTH6              ''年度16_月度情報6
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH7) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR16_MONTH7              ''年度16_月度情報7
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH8) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR16_MONTH8              ''年度16_月度情報8
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH9) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR16_MONTH9              ''年度16_月度情報9
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH10) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR16_MONTH10            ''年度16_月度情報10
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH11) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR16_MONTH11            ''年度16_月度情報11
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH12) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR16_MONTH12            ''年度16_月度情報12
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH1) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR17_MONTH1              ''年度17_月度情報1
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH2) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR17_MONTH2              ''年度17_月度情報2
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH3) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR17_MONTH3              ''年度17_月度情報3
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH4) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR17_MONTH4              ''年度17_月度情報4
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH5) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR17_MONTH5              ''年度17_月度情報5
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH6) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR17_MONTH6              ''年度17_月度情報6
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH7) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR17_MONTH7              ''年度17_月度情報7
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH8) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR17_MONTH8              ''年度17_月度情報8
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH9) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR17_MONTH9              ''年度17_月度情報9
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH10) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR17_MONTH10            ''年度17_月度情報10
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH11) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR17_MONTH11            ''年度17_月度情報11
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH12) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR17_MONTH12            ''年度17_月度情報12
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH1) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR18_MONTH1              ''年度18_月度情報1
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH2) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR18_MONTH2              ''年度18_月度情報2
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH3) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR18_MONTH3              ''年度18_月度情報3
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH4) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR18_MONTH4              ''年度18_月度情報4
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH5) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR18_MONTH5              ''年度18_月度情報5
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH6) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR18_MONTH6              ''年度18_月度情報6
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH7) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR18_MONTH7              ''年度18_月度情報7
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH8) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR18_MONTH8              ''年度18_月度情報8
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH9) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR18_MONTH9              ''年度18_月度情報9
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH10) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR18_MONTH10            ''年度18_月度情報10
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH11) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR18_MONTH11            ''年度18_月度情報11
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH12) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR18_MONTH12            ''年度18_月度情報12
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH1) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR19_MONTH1              ''年度19_月度情報1
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH2) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR19_MONTH2              ''年度19_月度情報2
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH3) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR19_MONTH3              ''年度19_月度情報3
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH4) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR19_MONTH4              ''年度19_月度情報4
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH5) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR19_MONTH5              ''年度19_月度情報5
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH6) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR19_MONTH6              ''年度19_月度情報6
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH7) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR19_MONTH7              ''年度19_月度情報7
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH8) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR19_MONTH8              ''年度19_月度情報8
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH9) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR19_MONTH9              ''年度19_月度情報9
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH10) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR19_MONTH10            ''年度19_月度情報10
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH11) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR19_MONTH11            ''年度19_月度情報11
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH12) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR19_MONTH12            ''年度19_月度情報12
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH1) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20_MONTH1              ''年度20_月度情報1
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH2) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20_MONTH2              ''年度20_月度情報2
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH3) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20_MONTH3              ''年度20_月度情報3
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH4) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20_MONTH4              ''年度20_月度情報4
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH5) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20_MONTH5              ''年度20_月度情報5
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH6) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20_MONTH6              ''年度20_月度情報6
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH7) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20_MONTH7              ''年度20_月度情報7
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH8) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20_MONTH8              ''年度20_月度情報8
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH9) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20_MONTH9              ''年度20_月度情報9
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH10) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20_MONTH10            ''年度20_月度情報10
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH11) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20_MONTH11            ''年度20_月度情報11
        setValue(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12) = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20_MONTH12            ''年度20_月度情報12

        ''ﾌﾟﾗｲﾍﾞｰﾄ変数にセット
        Me.ChangePaymentLineColumn = setValue

    End Sub

    '--------------------------------------------------------
    '概    要  ：CSVのNull値を、0に変換する
    '説    明  ：
    '--------------------------------------------------------
    Private Function ChangeNullToZero(ByVal value As String) As String

        ''初期化
        ChangeNullToZero = 0

        ''数値変換可能なら、そのまま値を返す。
        If IsNumeric(value) = True Then
            ChangeNullToZero = value
        End If

    End Function

    '--------------------------------------------------------
    '概    要  ：CSVのデータの数値項目に"null"が入っていた場合、0へ変換する。
    '            ※CSVの値ではなく、Excelの式をセットする項目も後の拡張性のため0へ変換する。
    '説    明  ：
    '--------------------------------------------------------
    Private Sub ChangeCsvDataNullToZero(ByRef StrSplitLine() As String)

        ''固定文字"null"を数字の0に変換する。
        ''※展開金額以外のサーバーのINTEGER、SMALLINT、DECIMAL、BIGINT項目が対象
        For i As Integer = 0 To StrSplitLine.Length - 1
            Select Case i + 1
                Case CsvPaymentLineColumn.LINE_NO
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.FILE_NAME_SUFFIX
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.FILE_NAME_SUFFIX_INTR
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.QTY
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PAY_MONTHS
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.IGF_RATE_BAUCOC
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.IGF_RATE_IOC
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.LIST_PRICE_PROPOSAL
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.LIST_PRICE_REFLESH
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.LIST_PRICE_TOTAL_PROPOSAL
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.DP_BAU
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.DP_COC
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.DP_IOC
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_UNIT_BAU
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_QTY_BAU
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_UNIT_COC
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_QTY_COC
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_UNIT_IOC
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_QTY_IOC
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.COST_RATE
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.COST
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.COST_TOTAL
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.TAX_RATE
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.LIST_PRICE_TOTAL_IOC
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_TOTAL_IOC
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.COST_TOTAL_IOC
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_TO_SPLIT
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = ""
                    End If
                Case CsvPaymentLineColumn.PRICE_TOTAL_IGF
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.CONTRACT_IN
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.CONTRACT_OUT
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_DEFF_IGF
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PAY_FLAG
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.IGF_START_DATE
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.IGF_END_DATE
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR1
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR2
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR3
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR4
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR5
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR6
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR7
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR8
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR9
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR10
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR11
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR12
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR1_MONTH1
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR1_MONTH2
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR1_MONTH3
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR1_MONTH4
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR1_MONTH5
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR1_MONTH6
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR1_MONTH7
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR1_MONTH8
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR1_MONTH9
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR1_MONTH10
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR1_MONTH11
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR1_MONTH12
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR2_MONTH1
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR2_MONTH2
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR2_MONTH3
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR2_MONTH4
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR2_MONTH5
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR2_MONTH6
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR2_MONTH7
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR2_MONTH8
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR2_MONTH9
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR2_MONTH10
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR2_MONTH11
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR2_MONTH12
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR3_MONTH1
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR3_MONTH2
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR3_MONTH3
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR3_MONTH4
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR3_MONTH5
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR3_MONTH6
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR3_MONTH7
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR3_MONTH8
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR3_MONTH9
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR3_MONTH10
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR3_MONTH11
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR3_MONTH12
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR4_MONTH1
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR4_MONTH2
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR4_MONTH3
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR4_MONTH4
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR4_MONTH5
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR4_MONTH6
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR4_MONTH7
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR4_MONTH8
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR4_MONTH9
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR4_MONTH10
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR4_MONTH11
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR4_MONTH12
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR5_MONTH1
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR5_MONTH2
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR5_MONTH3
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR5_MONTH4
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR5_MONTH5
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR5_MONTH6
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR5_MONTH7
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR5_MONTH8
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR5_MONTH9
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR5_MONTH10
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR5_MONTH11
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR5_MONTH12
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR6_MONTH1
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR6_MONTH2
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR6_MONTH3
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR6_MONTH4
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR6_MONTH5
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR6_MONTH6
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR6_MONTH7
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR6_MONTH8
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR6_MONTH9
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR6_MONTH10
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR6_MONTH11
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR6_MONTH12
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR7_MONTH1
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR7_MONTH2
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR7_MONTH3
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR7_MONTH4
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR7_MONTH5
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR7_MONTH6
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR7_MONTH7
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR7_MONTH8
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR7_MONTH9
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR7_MONTH10
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR7_MONTH11
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR7_MONTH12
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR8_MONTH1
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR8_MONTH2
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR8_MONTH3
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR8_MONTH4
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR8_MONTH5
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR8_MONTH6
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR8_MONTH7
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR8_MONTH8
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR8_MONTH9
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR8_MONTH10
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR8_MONTH11
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR8_MONTH12
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR9_MONTH1
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR9_MONTH2
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR9_MONTH3
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR9_MONTH4
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR9_MONTH5
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR9_MONTH6
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR9_MONTH7
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR9_MONTH8
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR9_MONTH9
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR9_MONTH10
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR9_MONTH11
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR9_MONTH12
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR10_MONTH1
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR10_MONTH2
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR10_MONTH3
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR10_MONTH4
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR10_MONTH5
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR10_MONTH6
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR10_MONTH7
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR10_MONTH8
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR10_MONTH9
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR10_MONTH10
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR10_MONTH11
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR10_MONTH12
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR11_MONTH1
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR11_MONTH2
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR11_MONTH3
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR11_MONTH4
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR11_MONTH5
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR11_MONTH6
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR11_MONTH7
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR11_MONTH8
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR11_MONTH9
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR11_MONTH10
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR11_MONTH11
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR11_MONTH12
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR12_MONTH1
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR12_MONTH2
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR12_MONTH3
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR12_MONTH4
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR12_MONTH5
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR12_MONTH6
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR12_MONTH7
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR12_MONTH8
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR12_MONTH9
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR12_MONTH10
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR12_MONTH11
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineColumn.PRICE_YEAR12_MONTH12
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
            End Select
        Next
    End Sub

    '--------------------------------------------------------
    '概    要  ：CSVのデータの数値項目に"null"が入っていた場合、0へ変換する。
    '            ※CSVの値ではなく、Excelの式をセットする項目も後の拡張性のため0へ変換する。
    '説    明  ：
    '--------------------------------------------------------
    Public Sub ChangeDetailCsvDataNullToZero(ByRef StrSplitLine() As String)

        ''固定文字"null"を数字の0に変換する。
        ''※サーバーのINTEGER、SMALLINT、DECIMAL、BIGINT項目が対象
        For i As Integer = 0 To StrSplitLine.Length - 1
            Select Case i + 1
                Case CsvPaymentLineDetailColumn.FILE_NAME_SUFFIX
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineDetailColumn.SEQ
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineDetailColumn.QTY_INTEGER
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineDetailColumn.LIST_PRICE_PROPOSAL
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineDetailColumn.LIST_PRICE
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineDetailColumn.LIST_PRICE_TOTAL_PROPOSAL
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineDetailColumn.LIST_PRICE_TOTAL
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineDetailColumn.COST_RATE
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineDetailColumn.COST
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineDetailColumn.COST_TOTAL
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineDetailColumn.HWMA_LIST_PRICE
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineDetailColumn.HWMA_LIST_PRICE_TOTAL
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineDetailColumn.HOURLY_SCALE
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineDetailColumn.MA_EXT_SCALE
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineDetailColumn.DP
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineDetailColumn.HWMA_DP_LIST_PRICE
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
                Case CsvPaymentLineDetailColumn.HWMA_DP_LIST_PRICE_TOTAL
                    If StrSplitLine(i) = "null" Then
                        StrSplitLine(i) = 0
                    End If
            End Select
        Next
    End Sub

    '--------------------------------------------------------
    '概    要  ：ExcelのN行データを削除する。
    '説    明  ：
    '--------------------------------------------------------
    Private Sub DeleteNLine(ByRef xlSheet As Excel.Worksheet,
                            ByVal delPaymentRows() As Integer)

        Dim delRow As Excel.Range = Nothing
        Try
            ''削除対象のN行をループ
            For i As Integer = delPaymentRows.Length - 1 To 0 Step -1
                delRow = xlSheet.Range(delPaymentRows(i) & ":" & delPaymentRows(i))
                delRow.Delete(Shift:=Excel.XlDeleteShiftDirection.xlShiftUp)
            Next

        Catch ex As Exception
            Throw ex

        Finally
            ''オブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(delRow, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub

    '--------------------------------------------------------
    '概    要  ：個別PSファイルの1行分のデータを整形して書込む
    '説    明  ：
    '--------------------------------------------------------
    Private Sub SetPSSheetCellValue(ByRef xlSheet As Excel.Worksheet, _
                                    ByVal Outputstring() As String, _
                                    ByVal CsvCount As Integer, _
                                    ByVal startOutputRow As Integer,
                                    ByVal excelFomulate As PaymentLineFomulateInfo)

        Dim xlRange As Excel.Range
        Dim objCells(ExcelWrite.ExcelPaymentLineColumn.PRICE_DEFF_IGF - 1) As Object

        Try
            ''セルに値を代入
            For n As Integer = ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG To ExcelWrite.ExcelPaymentLineColumn.PRICE_DEFF_IGF
                Select Case n

                    Case ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG
                        '更新フラグの'U'を書き込まない
                        If Outputstring(n - 1).ToString() = "U" Then
                            Continue For
                        Else
                            objCells(n - 1) = Outputstring(n - 1)
                        End If

                    Case ExcelWrite.ExcelPaymentLineColumn.CONTRACT
                        'CSVに値がなければ、画面の値をセットする。
                        If changeDBNullToString(Outputstring(n - 1)) = "" Then
                            objCells(n - 1) = CommonVariable.CONTRACTNO
                        Else
                            objCells(n - 1) = Outputstring(n - 1)
                        End If

                    Case ExcelWrite.ExcelPaymentLineColumn.QTY, _
                         ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL, _
                         ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH

                        '数字項目のため、数字にして表示する
                        If Outputstring(n - 1).ToString().Length > 0 Then
                            Dim convNum As Long = 0
                            convNum = Convert.ToInt64(Outputstring(n - 1).ToString)
                            objCells(n - 1) = convNum
                        Else
                            objCells(n - 1) = Outputstring(n - 1)
                        End If

                    Case ExcelWrite.ExcelPaymentLineColumn.PAY_MONTHS
                        If excelFomulate.PAY_MONTHS <> "" Then
                            objCells(n - 1) = excelFomulate.PAY_MONTHS.Replace("@", startOutputRow + CsvCount)
                        End If
                    Case ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_PROPOSAL
                        If excelFomulate.LIST_PRICE_TOTAL_PROPOSAL <> "" Then
                            objCells(n - 1) = excelFomulate.LIST_PRICE_TOTAL_PROPOSAL.Replace("@", startOutputRow + CsvCount)
                        End If
                    Case ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH
                        If excelFomulate.LIST_PRICE_TOTAL_REFLESH <> "" Then
                            objCells(n - 1) = excelFomulate.LIST_PRICE_TOTAL_REFLESH.Replace("@", startOutputRow + CsvCount)
                        End If
                    Case ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC
                        If excelFomulate.PRICE_UNIT_IOC <> "" Then
                            objCells(n - 1) = excelFomulate.PRICE_UNIT_IOC.Replace("@", startOutputRow + CsvCount)
                        End If
                    Case ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC_VAL
                        If excelFomulate.PRICE_UNIT_IOC_VAL <> "" Then
                            objCells(n - 1) = excelFomulate.PRICE_UNIT_IOC_VAL.Replace("@", startOutputRow + CsvCount)
                        End If
                    Case ExcelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC
                        If excelFomulate.PRICE_QTY_IOC <> "" Then
                            objCells(n - 1) = excelFomulate.PRICE_QTY_IOC.Replace("@", startOutputRow + CsvCount)
                        End If
                    Case ExcelWrite.ExcelPaymentLineColumn.COST_TOTAL
                        If excelFomulate.COST_TOTAL <> "" Then
                            objCells(n - 1) = excelFomulate.COST_TOTAL.Replace("@", startOutputRow + CsvCount)
                        End If
                    Case ExcelWrite.ExcelPaymentLineColumn.PRICE_TO_SPLIT
                        If excelFomulate.PRICE_TO_SPLIT <> "" Then
                            objCells(n - 1) = excelFomulate.PRICE_TO_SPLIT.Replace("@", startOutputRow + CsvCount)
                        End If
                    Case ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_IOC
                        If excelFomulate.LIST_PRICE_TOTAL_IOC <> "" Then
                            objCells(n - 1) = excelFomulate.LIST_PRICE_TOTAL_IOC.Replace("@", startOutputRow + CsvCount)
                        End If
                    Case ExcelWrite.ExcelPaymentLineColumn.PRICE_TOTAL_IOC
                        If excelFomulate.PRICE_TOTAL_IOC <> "" Then
                            objCells(n - 1) = excelFomulate.PRICE_TOTAL_IOC.Replace("@", startOutputRow + CsvCount)
                        End If
                    Case ExcelWrite.ExcelPaymentLineColumn.COST_TOTAL_IOC
                        If excelFomulate.COST_TOTAL_IOC <> "" Then
                            objCells(n - 1) = excelFomulate.COST_TOTAL_IOC.Replace("@", startOutputRow + CsvCount)
                        End If
                    Case ExcelWrite.ExcelPaymentLineColumn.PRICE_TOTAL_IGF
                        If excelFomulate.PRICE_IGF_TOTAL <> "" Then
                            objCells(n - 1) = excelFomulate.PRICE_IGF_TOTAL.Replace("@", startOutputRow + CsvCount)
                        End If
                    Case ExcelWrite.ExcelPaymentLineColumn.CONTRACT_IN
                        If excelFomulate.PRICE_CONT_TOTAL <> "" Then
                            objCells(n - 1) = excelFomulate.PRICE_CONT_TOTAL.Replace("@", startOutputRow + CsvCount)
                        End If
                    Case ExcelWrite.ExcelPaymentLineColumn.CONTRACT_OUT
                        If excelFomulate.PRICE_OO_CONT_TOTAL <> "" Then
                            objCells(n - 1) = excelFomulate.PRICE_OO_CONT_TOTAL.Replace("@", startOutputRow + CsvCount)
                        End If
                    Case ExcelWrite.ExcelPaymentLineColumn.PRICE_DEFF_IGF
                        If excelFomulate.IGF_DIF_INTEREST <> "" Then
                            objCells(n - 1) = excelFomulate.IGF_DIF_INTEREST.Replace("@", startOutputRow + CsvCount)
                        End If

                    Case ExcelWrite.ExcelPaymentLineColumn.IGF_RATE_IOC, _
                         ExcelWrite.ExcelPaymentLineColumn.DP_IOC, _
                         ExcelWrite.ExcelPaymentLineColumn.COST_RATE

                        '%表示にするために100分の１にする
                        If Outputstring(n - 1).ToString().Length > 0 Then
                            Outputstring(n - 1) = StringEdit.GetTrancatePercentageValue((Convert.ToDecimal(Outputstring(n - 1).ToString) / 100))
                        End If
                        objCells(n - 1) = Outputstring(n - 1)

                    Case Else
                        objCells(n - 1) = Outputstring(n - 1)
                End Select
            Next
            xlRange = xlSheet.Range(EXCEL_PS_Exc_OUTCOLUM.Replace("@", startOutputRow + CsvCount))
            xlRange.Value = objCells

            xlRange = xlSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL) & startOutputRow & ":" & _
                                    ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL) & startOutputRow + CsvCount)
            xlRange.Value = 0

        Catch ex As Exception
            Throw ex
        Finally
            ''オブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try

    End Sub

    '--------------------------------------------------------
    '概    要  ：Export時、MasterMDBのClientValueTableの値を取得
    '説    明  ：
    '--------------------------------------------------------
    Public Function GetClientValueTable() As DataTable

        ''初期化
        GetClientValueTable = Nothing

        ''データの取得
        Dim con As OleDbConnection
        Dim mmc As New MasterMdbControl
        con = mmc.GetOleDBConnection(CommonVariable.MdbPW)
        Dim mdbContrl As New MUSE.DataAccess.OleDb.OleDbConvertClientValue

        Return mdbContrl.SelectDataTable(con)

    End Function

    ''1555 ServicePac TBLの取得 str
    '--------------------------------------------------------
    '概    要  ：MasterMDBのServicePacTableの値を取得
    '説    明  ：
    '--------------------------------------------------------
    Public Function GetServicePacTable() As DataTable

        ''初期化
        GetServicePacTable = Nothing

        ''データの取得
        Dim con As OleDbConnection
        Dim mmc As New MasterMdbControl
        con = mmc.GetOleDBConnection(CommonVariable.MdbPW)
        Dim mdbContrl As New MUSE.DataAccess.OleDb.OleDbServicePac

        Return mdbContrl.SelectDataTable(con)

    End Function
    ''1555 ServicePac TBLの取得 end

    ''' <summary>
    ''' 項目入れ替え
    ''' ※構成情報取込でのCSV出力では処理が煩雑になるため統合反映で実施
    ''' </summary>
    ''' <param name="strData"></param>
    ''' <remarks></remarks>
    Private Sub ReplaceItem(ByRef strData() As String)

        Dim strPatternCd As String = strData(ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD - 1)

        Select Case strPatternCd
            Case CommonConstant.PATTERNCD_TYPE_IBM_HW_AAS_BOX,
                 CommonConstant.PATTERNCD_TYPE_IBM_HW_AAS_MES,
                 CommonConstant.PATTERNCD_TYPE_IBM_HW_QCOS,
                 CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_BOX,
                 CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_MES,
                 CommonConstant.PATTERNCD_TYPE_IBM_HWMA_QCOS,
                 CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_WarrantyOP,
                 CommonConstant.PATTERNCD_TYPE_IBM_HWMA_QCOS_WarrantyOP
                '項目２、項目３入れ替え
                Dim strItem2 As String = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02 - 1)
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02 - 1) = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03 - 1)
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03 - 1) = strItem2

            Case CommonConstant.PATTERNCD_TYPE_SWBrandSW,
                 CommonConstant.PATTERNCD_TYPE_SWBrandSWMA
                'CHIS対応前の項目入れ替え
                Dim strItem3 As String = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03 - 1)
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03 - 1) = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM06 - 1)
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM06 - 1) = strItem3
                '項目２、項目３入れ替え
                Dim strItem2 As String = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02 - 1)
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02 - 1) = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03 - 1)
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03 - 1) = strItem2

            Case CommonConstant.PATTERNCD_TYPE_HWBrandSW_AAS,
                 CommonConstant.PATTERNCD_TYPE_HWBrandSW_QCOS,
                 CommonConstant.PATTERNCD_TYPE_HWBrandSWMA_AAS,
                 CommonConstant.PATTERNCD_TYPE_HWBrandSWMA_QCOS,
                 CommonConstant.PATTERNCD_TYPE_VLS
                'CHIS対応前の項目入れ替え
                Dim strItem3 As String = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03 - 1)
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03 - 1) = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM06 - 1)
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM06 - 1) = strItem3
                '項目２、項目３入れ替え
                Dim strItem2 As String = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02 - 1)
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02 - 1) = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03 - 1)
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03 - 1) = strItem2
                Dim swmaStrYear As String = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11 - 1)
                'サービス提供期間の移動
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11 - 1) = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM08 - 1)
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12 - 1) = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM09 - 1)
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM08 - 1) = swmaStrYear
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM09 - 1) = ""

            Case CommonConstant.PATTERNCD_TYPE_PA
                Dim strItem6 As String = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM06 - 1)
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM06 - 1) = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM05 - 1)
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM05 - 1) = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM04 - 1)
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM04 - 1) = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03 - 1)
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03 - 1) = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02 - 1)
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02 - 1) = strItem6
                'サービス提供期間の移動
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11 - 1) = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM08 - 1)
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12 - 1) = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM09 - 1)
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM08 - 1) = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM15 - 1)
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM15 - 1) = ""
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM09 - 1) = ""

            Case CommonConstant.PATTERNCD_TYPE_HWServicePac,
                 CommonConstant.PATTERNCD_TYPE_SWServicePac
                'CHIS対応前の項目入れ替え
                Dim strItem5 As String = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM05 - 1)
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM05 - 1) = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM04 - 1)
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM04 - 1) = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03 - 1)
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03 - 1) = strItem5
                '項目２、項目３入れ替え
                Dim strItem2 As String = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02 - 1)
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02 - 1) = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03 - 1)
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03 - 1) = strItem2
            Case CommonConstant.PATTERNCD_TYPE_HW_CISCO
                '項目２、項目３、項目４入れ替え
                Dim strItem4 As String = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM04 - 1)
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM04 - 1) = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03 - 1)
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03 - 1) = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02 - 1)
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02 - 1) = strItem4
            Case CommonConstant.PATTERNCD_TYPE_CISCO_MAINTENANCE
                '項目１、項目２、項目３、項目５入れ替え
                Dim strItem1 As String = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01 - 1)
                Dim strItem2 As String = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02 - 1)
                Dim strItem3 As String = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03 - 1)
                Dim strItem5 As String = strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM05 - 1)
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01 - 1) = strItem3
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02 - 1) = strItem5
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03 - 1) = strItem2
                strData(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM05 - 1) = strItem1
        End Select

    End Sub

    ''' <summary>
    '''概  要：新規HWMAの保守金額を取得
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetNewMAMaintePrice(ByRef con As OleDbConnection, _
                                         ByVal partNO As String,
                                         ByRef maintePrice As Double, _
                                         ByRef nonvpa As String) As Boolean

        ''初期化
        GetNewMAMaintePrice = False

        Dim dr As OleDbDataReader
        Dim cmd As New OleDbCommand
        Dim sql As New StringBuilder
        Dim searchPartNo1 As String
        Dim searchPartNo2 As String

        Try

            ''保守金額取得            
            searchPartNo1 = partNO.PadLeft(7, "0")
            searchPartNo2 = partNO.PadLeft(8, "0")
            sql.Length = 0
            Call sql.Append(CommonConstant.SQL_STR_SELECT)
            Call sql.Append(M_QCOSTable.COLUMN_NAME_PRICE_M)
            Call sql.Append(CommonConstant.STR_COMMA)
            Call sql.Append(M_QCOSTable.COLUMN_NAME_NONVPA)
            Call sql.Append(CommonConstant.SQL_STR_FROM)
            Call sql.Append(M_QCOSTable.TABLE_NAME)
            Call sql.Append(CommonConstant.SQL_STR_WHERE)
            Call sql.Append(" Trim ")
            Call sql.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            Call sql.Append(M_QCOSTable.COLUMN_NAME_PARTNO)
            Call sql.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
            Call sql.Append(CommonConstant.SQL_STR_EQUAL)
            Call sql.Append(StringEdit.EncloseSingleQuotation(searchPartNo1))
            Call sql.Append(CommonConstant.SQL_STR_OR)
            Call sql.Append(" Trim ")
            Call sql.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            Call sql.Append(M_QCOSTable.COLUMN_NAME_PARTNO)
            Call sql.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
            Call sql.Append(CommonConstant.SQL_STR_EQUAL)
            Call sql.Append(StringEdit.EncloseSingleQuotation(searchPartNo2))

            cmd.Connection = con
            cmd.CommandText = sql.ToString
            dr = cmd.ExecuteReader
            If dr.Read() Then
                maintePrice = CDbl(dr.Item(M_QCOSTable.COLUMN_NAME_PRICE_M))
                nonvpa = ExcelWrite.changeDBNullToString(dr.Item(M_QCOSTable.COLUMN_NAME_NONVPA))
                Return True
            End If

        Catch ex As Exception
            Throw ex

        Finally
            If IsNothing(dr) = False AndAlso _
               dr.IsClosed = False Then
                dr.Close()
            End If

        End Try

    End Function

    ''' <summary>
    ''' 機能：CSVﾃﾞｰﾀをExcelﾌｧｲﾙに出力
    ''' </summary>
    ''' <param name="strFileName"></param>
    ''' <param name="strOutputFileName"></param>
    ''' <param name="strCsvFileName">作業用CSVﾌｧｲﾙ名</param>
    ''' <param name="intTextStartRow">CSVﾌｧｲﾙ読込開始行</param>
    ''' <param name="strStartRange"></param>
    ''' <param name="OUTERR">ｴﾗｰﾛｸﾞ</param>
    ''' <param name="errCount"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function OptputExcelValRef(ByVal strFileName As String,
                                       ByVal strOutputFileName As String,
                                       ByVal strCsvFileName As String,
                                       ByVal intTextStartRow As Integer,
                                       ByVal strStartRange As String,
                                       ByRef OUTERR As OutputErrorList,
                                       ByRef errCount As Integer) As Integer
        'ファイル操作
        Dim sr As StreamReader = Nothing
        Dim sw As StreamWriter = Nothing
        Dim strLine As String
        Dim strSplitLine() As String
        Dim strOutFileName As String
        Dim strTemp() As String
        Dim ExcelOutPath As String
        Dim intRecCnt As Integer = 0
        Dim intCnt As Integer
        Dim strOut As String
        Dim strWork As String
        Dim xlApp As Excel.Application
        Dim xlBooks As Excel.Workbooks
        Dim xlBook As Excel.Workbook = Nothing
        Dim xlSheets As Excel.Sheets = Nothing
        Dim xlSheet As Excel.Worksheet = Nothing
        Dim intTypeData() As Integer = {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2}

        OptputExcelValRef = CD_RET_ERR_SYS

        Try
            '=====================================================
            '件数取得と作業用ＣＳＶ取得
            '=====================================================
            strTemp = strFileName.Split("\")
            ExcelOutPath = ExcelExportFileDirPath & "\" & strTemp(strTemp.Length - 2).ToString
            strOutFileName = Path.GetFileName(strFileName)
            sr = New StreamReader(strFileName, Encoding.GetEncoding("shift-jis"))
            sw = New StreamWriter(strCsvFileName, False, System.Text.Encoding.Default)

            intRecCnt = 0
            While sr.Peek() > -1
                strLine = sr.ReadLine()
                If strLine.IndexOf("EOF") >= 0 Then
                    Exit While
                End If
                If intRecCnt >= intTextStartRow Then
                    'カンマ区切りのデータを分解する
                    Erase strSplitLine
                    Call SplitData(strLine, strSplitLine)
                    strOut = ""
                    For intCnt = 0 To (strSplitLine.Length - 1)
                        strWork = strSplitLine(intCnt).Replace("""", """""")
                        strOut = strOut & """" & strWork & ""","
                    Next
                    sw.WriteLine(strOut)
                End If
                intRecCnt = intRecCnt + 1
            End While
            sw.Close()
            sr.Close()

            'EOFﾁｪｯｸ
            strSplitLine = strLine.Split(",")
            If strSplitLine(0) <> "EOF" Then
                OptputExcelValRef = CD_RET_ERR_NO_EOF
                Exit Function
            End If
            'フッター件数と実件数比較
            intRecCnt = intRecCnt - intTextStartRow
            If Integer.Parse(strSplitLine(1)) <> intRecCnt Then
                OptputExcelValRef = CD_RET_ERR_UNMATCH_EOF
                Exit Function
            End If

            '0件ﾃﾞｰﾀを取り込もうとするとｴﾗｰになるためﾁｪｯｸ
            If intRecCnt > 0 Then
                xlApp = New Excel.Application
                xlApp.EnableEvents = False
                xlBooks = xlApp.Workbooks
                xlBooks.Application.DisplayAlerts = False
                xlApp.EnableEvents = True

                xlBook = xlBooks.Open(ExcelOutPath & "\" & strOutputFileName)
                xlApp.Calculation = Excel.XlCalculation.xlCalculationManual
                xlSheets = xlBook.Sheets
                xlSheet = xlSheets.Item(1)

                '=====================================================
                'データ出力
                '=====================================================
                Call LoadCsvToExcel(strCsvFileName, 1, xlSheet.Name, strStartRange, xlSheet, intTypeData)

                'ブックの保存
                xlBooks.Application.EnableEvents = True
                xlBooks.Application.DisplayAlerts = True
                xlBook.Save()
            End If

            OptputExcelValRef = intRecCnt

        Catch ex As Exception

            ''例外の処理
            OUTERR.OutImportErrorList(ex.Message & "(OptputExcelValRef)", "Import")
            Return -1

        Finally
            'ファイルオブジェクトの解放
            If IsNothing(sw) = False Then
                sr = Nothing
            End If
            If IsNothing(sr) = False Then
                sr = Nothing
            End If

            'エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBook) = False Then
                xlBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlBooks, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlApp) = False Then
                xlApp.EnableEvents = True
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            ''ガベージコレクトの起動
            GC.Collect()

        End Try

    End Function

    Private Sub SetPsData(ByRef objData() As Object)

        If Not objData Is Nothing Then
            'Excel出力用配列から、Nothin、Nullを除外
            For j As Integer = 0 To objData.Length - 2
                If IsDBNull(objData(j)) Or IsNothing(objData(j)) Then
                    objData(j) = changeDBNullToString(objData(j))
                End If
                If j >= ExcelPaymentLineColumn.PRICE_YEAR1 Then
                    ''空白なら、0をセット
                    If changeDBNullToString(objData(j)) = "" Then
                        objData(j) = 0
                    End If
                End If
            Next
        End If

    End Sub

    'Req.1656 パターン名称補正 2018/09 Str
    ''' <summary>
    ''' パターン名称変換
    ''' </summary>
    ''' <param name="PatternCD">サーバ取得のパターンNo</param>
    ''' <param name="PatternNm">サーバ取得のパターン名称</param>
    ''' <param name="Qty">数量</param>
    ''' <returns>変換したパターン名称</returns>
    ''' <remarks></remarks>
    '''Req.1656 パターン名称補正 2018/10 Str
    Private Function GetPatternNm(ByVal PatternCD As String, _
                                  ByVal PatternNm As String, _
                                  ByVal Qty As String, _
                                  ByVal Item01 As String) As String
        '    Private Function GetPatternNm(ByVal PatternCD As String, _
        '                                  ByVal PatternNm As String, _
        '                                  ByVal Qty As String) As String
        'Req.1656 パターン名称補正 2018/10 End

        Select Case PatternCD
            Case "0"
                GetPatternNm = "作業指示"

            Case "1"
                'Req.1656 パターン名称補正 2018/10 Str
                If Left(Item01, 3) = "666" Then
                    GetPatternNm = "Service Integrator"
                Else
                    'Req.1656 パターン名称補正 2018/10 End
                    GetPatternNm = "IBM HW AAS BOX"
                    'Req.1656 パターン名称補正 2018/10 Str
                End If
                'Req.1656 パターン名称補正 2018/10 End

            Case "2"
                GetPatternNm = "IBM HW AAS MES"

            Case "3"
                GetPatternNm = "IBM HW QCOS"

            Case "4"
                GetPatternNm = "HW(CISCO)"

            Case "5"
                GetPatternNm = "HWBrandSW AAS"

            Case "6"
                GetPatternNm = "HWBrandSW QCOS"

            Case "7"
                GetPatternNm = "HWBrandSWMA AAS"

            Case "8"
                GetPatternNm = "HWBrandSWMA QCOS"

            Case "9"
                GetPatternNm = "SWBrandSW"

            Case "10"
                GetPatternNm = "SWBrandSWMA"

            Case "11"
                GetPatternNm = "PA"

            Case "12"
                GetPatternNm = "VLS"

            Case "13"
                GetPatternNm = "HWｻｰﾋﾞｽﾊﾟｯｸ"

            Case "14"
                GetPatternNm = "SWｻｰﾋﾞｽﾊﾟｯｸ"

            Case "15"
                GetPatternNm = "IBM HWMA AAS BOX"

            Case "16"
                GetPatternNm = "IBM HWMA AAS MES"

            Case "17"
                GetPatternNm = "IBM HWMA QCOS"

            Case "18"
                GetPatternNm = "IBM HWMA AAS 保証ｵﾌﾟｼｮﾝ"

            Case "19"
                GetPatternNm = "IBM HWMA QCOS 保証ｵﾌﾟｼｮﾝ"

            Case "20"
                GetPatternNm = "他社製品(MVMS)"

            Case "21"
                GetPatternNm = "CISCO保守"

            Case "22"
                GetPatternNm = "S-Link"

            Case "23"
                GetPatternNm = "保守拡張"

            Case "24"
                GetPatternNm = "ﾎｽﾄ系SW"

            Case "25"
                GetPatternNm = PatternNm

            Case "26"
                GetPatternNm = "HW Brand Service"

            Case "27"
                GetPatternNm = "SW Brand Service"

            Case "28"
                GetPatternNm = "請求統合"

            Case "29"
                GetPatternNm = "IGF(金利)"

            Case "30"
                GetPatternNm = "IGF(再ﾘｰｽ)"

            Case "31"
                GetPatternNm = "IGF(中古)"

            Case "32"
                GetPatternNm = "FMA"

            Case "33"
                GetPatternNm = "ｵﾌｧﾘﾝｸﾞSW(SRO/ESSO/ELA)"

            Case "34"
                GetPatternNm = "ｼｽﾃﾑ･ｻｰﾋﾞｽ"

            Case "35"
                GetPatternNm = "CIS"

            Case "36"
                GetPatternNm = "ExcessTCV"

            Case "37"
                GetPatternNm = "Primo使用サービス"

            Case "38"
                GetPatternNm = "S&D RENTAL"

            Case "39"
                GetPatternNm = "ISS"

            Case "41"
                GetPatternNm = "MA復帰料金"

            Case "42"
                GetPatternNm = "SO"

            Case "43"
                GetPatternNm = "ﾍﾞｰｼｯｸ･ｾﾚｸｼｮﾝ"

            Case "44"
                GetPatternNm = "ﾍﾞｰｼｯｸ･ｾﾚｸｼｮﾝ 追加ｻｰﾋﾞｽ"

            Case "45"
                GetPatternNm = "Allotment"

            Case "46"
                GetPatternNm = "Variance Cash"

            Case "47"
                GetPatternNm = "MSS"

            Case "48"
                GetPatternNm = "Saas"

            Case "49"
                '1648追加 str パターン名称を変更
                'GetPatternNm = "IGF(ﾘｰｽ)"
                GetPatternNm = "IGF"
                '1648追加 end パターン名称を変更

            Case "50"
                '1648追加 str パターン名称を変更
                'GetPatternNm = "IGF(ﾘｰｽ解約金)"
                GetPatternNm = "IGF(解約金弁済金)"
                '1648追加 end パターン名称を変更

            Case "90"
                GetPatternNm = "Bidpackage削除ﾃﾞｰﾀ"

            Case "99"
                GetPatternNm = "ｺﾒﾝﾄ"

            Case Else
                GetPatternNm = ""
        End Select

        Select Case PatternCD
            Case "25"
            Case "90"
            Case Else
                If GetPatternNm <> "" Then
                    If Val(Qty) < 0 Then
                        GetPatternNm = GetPatternNm & " 削除ﾃﾞｰﾀ"
                    End If
                End If

        End Select

    End Function
    'Req.1656 パターン名称補正 2018/09 End

#End Region

End Class
