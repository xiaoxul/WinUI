Imports System.Text
Imports System.IO
Imports System.Reflection
Imports MUSE.Utility
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.SharedStructure
Imports MUSE.Utility.UserDataSet
Imports MUSE.Utility.UserDataTable.Master
Imports MUSE.Utility.UserDataTable.Transaction
Imports MUSE.Utility.UserDataTable.Work
Imports MUSE.Utility.UserMessageBox
Imports MUSE.Utility.UserException
Imports MUSE.Utility.XmlClass.Parameter
Imports MUSE.Controller
Imports MUSE.UserControl.UCnt_DataGrid

'==========================================================================
'�N���X���FFrm_ExtensionList
'�T    �v�FFrm_ExtensionList�N���X
'��    ���FFrm_ExtensionList���
'��    ���F[Ver1.0]  2015/10/21 
'==========================================================================
Public Class Frm_ExtensionList
    Inherits System.Windows.Forms.Form

#Region " Windows �t�H�[�� �f�U�C�i�Ő������ꂽ�R�[�h "

    Public Sub New()
        MyBase.New()

        ' ���̌Ăяo���� Windows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
        InitializeComponent()

        ' InitializeComponent() �Ăяo���̌�ɏ�������ǉ����܂��B

    End Sub

    ' Form �́A�R���|�[�l���g�ꗗ�Ɍ㏈�������s���邽�߂� dispose ���I�[�o�[���C�h���܂��B
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    ' Windows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
    Private components As System.ComponentModel.IContainer

    ' ���� : �ȉ��̃v���V�[�W���́AWindows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
    'Windows �t�H�[�� �f�U�C�i���g���ĕύX���Ă��������B  
    ' �R�[�h �G�f�B�^���g���ĕύX���Ȃ��ł��������B
    '        Friend WithEvents UCnt_Pal00012 As MUSE.UserControl.UCnt_Pal0001
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Btn_Cancel As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Ok As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Close As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Update As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Lbl_StartMonth As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Lbl_StartYear As System.Windows.Forms.Label
    Friend WithEvents Txb_EndYM As System.Windows.Forms.TextBox
    Friend WithEvents Chk_DelDataOutput As System.Windows.Forms.CheckBox
    Friend WithEvents Txb_OioEndMonth As System.Windows.Forms.TextBox
    Friend WithEvents Txb_OioEndYear As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Txb_OioEndMonth = New System.Windows.Forms.TextBox()
        Me.Txb_OioEndYear = New System.Windows.Forms.TextBox()
        Me.Chk_DelDataOutput = New System.Windows.Forms.CheckBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Txb_EndYM = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Lbl_StartMonth = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Lbl_StartYear = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Btn_Update = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Close = New MUSE.UserControl.UCnt_Btn0001()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Txb_OioEndMonth)
        Me.GroupBox4.Controls.Add(Me.Txb_OioEndYear)
        Me.GroupBox4.Controls.Add(Me.Chk_DelDataOutput)
        Me.GroupBox4.Controls.Add(Me.Label9)
        Me.GroupBox4.Controls.Add(Me.Txb_EndYM)
        Me.GroupBox4.Controls.Add(Me.Label8)
        Me.GroupBox4.Controls.Add(Me.Label7)
        Me.GroupBox4.Controls.Add(Me.Label6)
        Me.GroupBox4.Controls.Add(Me.Label5)
        Me.GroupBox4.Controls.Add(Me.Lbl_StartMonth)
        Me.GroupBox4.Controls.Add(Me.Label4)
        Me.GroupBox4.Controls.Add(Me.Lbl_StartYear)
        Me.GroupBox4.Controls.Add(Me.Label3)
        Me.GroupBox4.Location = New System.Drawing.Point(22, 6)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(476, 215)
        Me.GroupBox4.TabIndex = 5
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "�����_����Ԏw��"
        '
        'Txb_OioEndMonth
        '
        Me.Txb_OioEndMonth.Location = New System.Drawing.Point(276, 60)
        Me.Txb_OioEndMonth.MaxLength = 2
        Me.Txb_OioEndMonth.Name = "Txb_OioEndMonth"
        Me.Txb_OioEndMonth.Size = New System.Drawing.Size(36, 22)
        Me.Txb_OioEndMonth.TabIndex = 5
        Me.Txb_OioEndMonth.Text = "mm"
        '
        'Txb_OioEndYear
        '
        Me.Txb_OioEndYear.Location = New System.Drawing.Point(210, 60)
        Me.Txb_OioEndYear.MaxLength = 4
        Me.Txb_OioEndYear.Name = "Txb_OioEndYear"
        Me.Txb_OioEndYear.Size = New System.Drawing.Size(45, 22)
        Me.Txb_OioEndYear.TabIndex = 4
        Me.Txb_OioEndYear.Text = "��������"
        '
        'Chk_DelDataOutput
        '
        Me.Chk_DelDataOutput.AutoSize = True
        Me.Chk_DelDataOutput.Location = New System.Drawing.Point(321, 165)
        Me.Chk_DelDataOutput.Name = "Chk_DelDataOutput"
        Me.Chk_DelDataOutput.Size = New System.Drawing.Size(18, 17)
        Me.Chk_DelDataOutput.TabIndex = 1
        Me.Chk_DelDataOutput.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(31, 165)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(252, 15)
        Me.Label9.TabIndex = 11
        Me.Label9.Text = "Payment���  = ""D""�̃f�[�^���o�͂���"
        '
        'Txb_EndYM
        '
        Me.Txb_EndYM.Location = New System.Drawing.Point(77, 119)
        Me.Txb_EndYM.Name = "Txb_EndYM"
        Me.Txb_EndYM.Size = New System.Drawing.Size(178, 22)
        Me.Txb_EndYM.TabIndex = 0
        Me.Txb_EndYM.Text = "���������N������"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(31, 100)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(184, 15)
        Me.Label8.TabIndex = 9
        Me.Label8.Text = "������̊�{�_����ԏI��"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(312, 64)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(22, 15)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = "��"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(252, 64)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(22, 15)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "�N"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(143, 64)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(47, 15)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "���@�`"
        '
        'Lbl_StartMonth
        '
        Me.Lbl_StartMonth.AutoSize = True
        Me.Lbl_StartMonth.Location = New System.Drawing.Point(116, 64)
        Me.Lbl_StartMonth.Name = "Lbl_StartMonth"
        Me.Lbl_StartMonth.Size = New System.Drawing.Size(29, 15)
        Me.Lbl_StartMonth.TabIndex = 3
        Me.Lbl_StartMonth.Text = "mm"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(97, 64)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(22, 15)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "�N"
        '
        'Lbl_StartYear
        '
        Me.Lbl_StartYear.AutoSize = True
        Me.Lbl_StartYear.Location = New System.Drawing.Point(60, 64)
        Me.Lbl_StartYear.Name = "Lbl_StartYear"
        Me.Lbl_StartYear.Size = New System.Drawing.Size(35, 15)
        Me.Lbl_StartYear.TabIndex = 1
        Me.Lbl_StartYear.Text = "yyyy"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(31, 36)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(139, 15)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "���݂̊�{�_�����"
        '
        'Btn_Update
        '
        Me.Btn_Update.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Update.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Update.ForeColor = System.Drawing.Color.White
        Me.Btn_Update.Location = New System.Drawing.Point(227, 229)
        Me.Btn_Update.Name = "Btn_Update"
        Me.Btn_Update.Size = New System.Drawing.Size(122, 55)
        Me.Btn_Update.TabIndex = 2
        Me.Btn_Update.Text = "OK"
        Me.Btn_Update.UseVisualStyleBackColor = False
        '
        'Btn_Close
        '
        Me.Btn_Close.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Close.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Close.ForeColor = System.Drawing.Color.White
        Me.Btn_Close.Location = New System.Drawing.Point(377, 229)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(121, 55)
        Me.Btn_Close.TabIndex = 3
        Me.Btn_Close.Text = "�L�����Z��"
        Me.Btn_Close.UseVisualStyleBackColor = False
        '
        'Frm_ExtensionList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(387, 254)
        Me.Controls.Add(Me.Btn_Update)
        Me.Controls.Add(Me.Btn_Close)
        Me.Controls.Add(Me.GroupBox4)
        Me.MaximizeBox = False
        Me.Name = "Frm_ExtensionList"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "�����_����Ԏw��_�C�A���O"
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region "�����o�ϐ� "

    Private m_StartYear As String
    Private m_StartMonth As String
    Private m_EndYear As String
    Private m_EndMonth As String
    Private m_ExtYear As String
    Private m_ExtMonth As String
    Private m_DelDataOutput As Boolean
    Private m_isOK As Boolean

#End Region

#Region "�v���p�e�B"

    Public Property StartYear() As String
        Get
            Return m_StartYear
        End Get
        Set(ByVal Value As String)
            m_StartYear = Value
        End Set
    End Property

    Public Property StartMonth() As String
        Get
            Return m_StartMonth
        End Get
        Set(ByVal Value As String)
            m_StartMonth = Value
        End Set
    End Property

    Public Property EndYear() As String
        Get
            Return m_EndYear
        End Get
        Set(ByVal Value As String)
            m_EndYear = Value
        End Set
    End Property

    Public Property EndMonth() As String
        Get
            Return m_EndMonth
        End Get
        Set(ByVal Value As String)
            m_EndMonth = Value
        End Set
    End Property

    Public Property ExtYear() As String
        Get
            Return m_ExtYear
        End Get
        Set(ByVal Value As String)
            m_ExtYear = Value
        End Set
    End Property

    Public Property ExtMonth() As String
        Get
            Return m_ExtMonth
        End Get
        Set(ByVal Value As String)
            m_ExtMonth = Value
        End Set
    End Property

    Public Property DelDataOutput() As Boolean
        Get
            Return m_DelDataOutput
        End Get
        Set(ByVal Value As Boolean)
            m_DelDataOutput = Value
        End Set
    End Property

    Public Property isOK() As Boolean
        Get
            Return m_isOK
        End Get
        Set(ByVal Value As Boolean)
            m_isOK = Value
        End Set
    End Property

#End Region

#Region " �C�x���g�n���h�� "

    '--------------------------------------------------------
    '���\�b�h���FFrm_StwCategory_Load
    '�T    �v  �F��ʃ��[�h����
    '��    ��  �F��ʃ��[�h�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Frm_ExtensionList_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try
            Me.Cursor = Cursors.WaitCursor

            '��ʂ̏����f�[�^�\���������s��
            SetInitialData()

            m_isOK = False

        Catch ex As MuseException
            Me.Activate()
            Me.Cursor = Cursors.Default
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
            Me.Close()
        Catch ex As Exception
            Me.Activate()
            Me.Cursor = Cursors.Default
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
            Me.Close()
        Finally
            Me.Cursor = Cursors.Default
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Close_Click
    '�T    �v  �FBtn_Close�N���b�N����
    '��    ��  �FBtn_Close�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click

        m_ExtYear = ""
        m_ExtMonth = ""

        Me.DialogResult = DialogResult.Cancel
        Me.Close()

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Update_Click
    '�T    �v  �FBtn_Update_Click�N���b�N����
    '��    ��  �FBtn_Update_Click�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Update_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Update.Click

        Try
            Dim wStr As String
            Dim wYear As String
            Dim wMonth As String
            Dim ii As Integer

            If Trim(Txb_EndYM.Text) = "" Then
                MsgBox("�N������͂��Ă�������")
                Txb_EndYM.Focus()
                Exit Sub
            End If

            If Txb_EndYM.Text.IndexOf("�N") < 0 Then
                MsgBox("�N���Ŏw�肵�Ă�������")
                Txb_EndYM.Focus()
                Exit Sub
            End If

            If Txb_EndYM.Text.IndexOf("��") < 0 Then
                MsgBox("�N���Ŏw�肵�Ă�������")
                Txb_EndYM.Focus()
                Exit Sub
            End If

            If Not IsNumeric(Txb_OioEndYear.Text) Then
                MsgBox("�N���s���ł�")
                Txb_OioEndYear.Focus()
                Exit Sub
            End If

            If Not IsNumeric(Txb_OioEndMonth.Text) Then
                MsgBox("�����s���ł�")
                Txb_OioEndMonth.Focus()
                Exit Sub
            End If

            If Val(Txb_OioEndMonth.Text) < 1 Or _
               Val(Txb_OioEndMonth.Text) > 12 Then
                MsgBox("�����s���ł�")
                Txb_OioEndMonth.Focus()
                Exit Sub
            End If

            '�N�؂�o��
            ii = InStr(1, Txb_EndYM.Text, "�N")
            wYear = Mid(Txb_EndYM.Text, 1, ii - 1)
            wStr = Mid(Txb_EndYM.Text, ii + 1)

            '���؂�o��
            ii = InStr(1, Txb_EndYM.Text, "��")
            wStr = Mid(Txb_EndYM.Text, 1, ii - 1)
            wMonth = Strings.Right(wStr, 2)

            If Not IsDate(wYear & "/" & wMonth & "/01") Then
                MsgBox("�w�肳��Ă�����t���s���ł�")
                Txb_EndYM.Focus()
                Exit Sub
            End If

            If CDate(StartYear & "/" & StartMonth & "/01") > _
                CDate(Txb_OioEndYear.Text & "/" & Txb_OioEndMonth.Text & "/01") Then
                MsgBox("�J�n�N�����傫�����t���w�肵�Ă�������")
                Txb_OioEndYear.Focus()
                Exit Sub
            End If

            m_ExtYear = wYear
            m_ExtMonth = wMonth
            m_EndYear = Txb_OioEndYear.Text
            m_EndMonth = Txb_OioEndMonth.Text
            m_DelDataOutput = Chk_DelDataOutput.Checked
            m_isOK = True

            Me.Cursor = Cursors.WaitCursor

            DialogResult = DialogResult.OK

            Me.Close()

        Catch ex As MuseException
            Me.Activate()
            Me.Cursor = Cursors.Default
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
            Exit Sub
        Catch ex As Exception
            Me.Activate()
            Me.Cursor = Cursors.Default
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
            Exit Sub
        Finally
            '�����͂��Ȃ���΁A��ʂ����^�����͂�����ꍇ�̓��b�Z�[�W��\���̏�A����ʑ��s
            Me.Cursor = Cursors.Default
        End Try

    End Sub

#End Region

#Region " �v���C�x�[�g���\�b�h "

    '--------------------------------------------------------
    '���\�b�h���FSetInitialData
    '�T    �v  �F��������
    '��    ��  �F�����������s��
    '��    ��  �F�Ȃ�
    '�� �� �l  �F�Ȃ�
    '--------------------------------------------------------
    Private Sub SetInitialData()

        Lbl_StartYear.Text = m_StartYear
        Lbl_StartMonth.Text = m_StartMonth
        Txb_OioEndYear.Text = m_EndYear
        Txb_OioEndMonth.Text = m_EndMonth

        Txb_EndYM.Text = m_ExtYear & "�N" & m_ExtMonth & "��"

        Chk_DelDataOutput.Checked = m_DelDataOutput

    End Sub

#End Region



End Class
