Imports System.Text
Imports System.IO
Imports System.Reflection
Imports MUSE.Utility
Imports MUSE.Utility.UserMessageBox
Imports MUSE.Utility.UserException
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.XmlClass.Parameter

'==========================================================================
'�N���X���FFrm_FileSelect
'�T    �v�FFileSelect�N���X
'��    ���F�֘A�t�@�C���w����
'��    ���F[Ver1.0]  2006/10/01  �����@���K
'==========================================================================
Public Class Frm_FileSelect
    Inherits System.Windows.Forms.Form

#Region " Windows �t�H�[�� �f�U�C�i�Ő������ꂽ�R�[�h "

    Public Sub New()
        MyBase.New()

        ' ���̌Ăяo���� Windows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
        InitializeComponent()

        ' InitializeComponent() �Ăяo���̌�ɏ�������ǉ����܂��B

    End Sub

    ' Form �́A�R���|�[�l���g�ꗗ�Ɍ㏈�������s���邽�߂� dispose ���I�[�o�[���C�h���܂��B
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    ' Windows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
    Private components As System.ComponentModel.IContainer

    ' ���� : �ȉ��̃v���V�[�W���́AWindows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
    'Windows �t�H�[�� �f�U�C�i���g���ĕύX���Ă��������B  
    ' �R�[�h �G�f�B�^���g���ĕύX���Ȃ��ł��������B
    Friend WithEvents Btn_Clear_eBS_Sale As UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Ref_eBS_Sale As UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Clear_ConfigSWMA As UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Ref_ConfigSWMA As UserControl.UCnt_Btn0001
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Lst_File_eBS_Sale As System.Windows.Forms.ListBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Lst_File_ConfigSWMA As System.Windows.Forms.ListBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Btn_Cancel As UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Ok As UserControl.UCnt_Btn0001
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Chk_BoxReplace As System.Windows.Forms.CheckBox
    Friend WithEvents Btn_Clear_eBS_Mainte As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Ref_eBS_Mainte As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Lst_File_eBS_Mainte As System.Windows.Forms.ListBox
    Friend WithEvents Pnl_Swma As System.Windows.Forms.Panel
    Friend WithEvents Pnl_Ebs_Sale As System.Windows.Forms.Panel
    Friend WithEvents Pnl_Ebs_Mainte As System.Windows.Forms.Panel
    Friend WithEvents Grp_FileType As System.Windows.Forms.GroupBox
    Friend WithEvents Btn_Up_ConfigSWMA As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Down_ConfigSWMA As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Up_eBS_Sale As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Down_eBS_Sale As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Up_eBS_Mainte As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Down_eBS_Mainte As MUSE.UserControl.UCnt_Btn0001
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Btn_Ok = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Cancel = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Clear_eBS_Mainte = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Ref_eBS_Mainte = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Clear_eBS_Sale = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Ref_eBS_Sale = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Clear_ConfigSWMA = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Ref_ConfigSWMA = New MUSE.UserControl.UCnt_Btn0001()
        Me.Lst_File_eBS_Mainte = New System.Windows.Forms.ListBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Lst_File_eBS_Sale = New System.Windows.Forms.ListBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Lst_File_ConfigSWMA = New System.Windows.Forms.ListBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Pnl_Ebs_Sale = New System.Windows.Forms.Panel()
        Me.Btn_Up_eBS_Sale = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Down_eBS_Sale = New MUSE.UserControl.UCnt_Btn0001()
        Me.Pnl_Swma = New System.Windows.Forms.Panel()
        Me.Btn_Up_ConfigSWMA = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Down_ConfigSWMA = New MUSE.UserControl.UCnt_Btn0001()
        Me.Pnl_Ebs_Mainte = New System.Windows.Forms.Panel()
        Me.Btn_Up_eBS_Mainte = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Down_eBS_Mainte = New MUSE.UserControl.UCnt_Btn0001()
        Me.Chk_BoxReplace = New System.Windows.Forms.CheckBox()
        Me.Grp_FileType = New System.Windows.Forms.GroupBox()
        Me.GroupBox5.SuspendLayout()
        Me.Pnl_Ebs_Sale.SuspendLayout()
        Me.Pnl_Swma.SuspendLayout()
        Me.Pnl_Ebs_Mainte.SuspendLayout()
        Me.Grp_FileType.SuspendLayout()
        Me.SuspendLayout()
        '
        'Btn_Ok
        '
        Me.Btn_Ok.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Ok.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Ok.ForeColor = System.Drawing.Color.White
        Me.Btn_Ok.Location = New System.Drawing.Point(185, 600)
        Me.Btn_Ok.Name = "Btn_Ok"
        Me.Btn_Ok.Size = New System.Drawing.Size(157, 55)
        Me.Btn_Ok.TabIndex = 3
        Me.Btn_Ok.Text = "OK"
        Me.Btn_Ok.UseVisualStyleBackColor = False
        '
        'Btn_Cancel
        '
        Me.Btn_Cancel.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Cancel.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Cancel.ForeColor = System.Drawing.Color.White
        Me.Btn_Cancel.Location = New System.Drawing.Point(364, 600)
        Me.Btn_Cancel.Name = "Btn_Cancel"
        Me.Btn_Cancel.Size = New System.Drawing.Size(157, 55)
        Me.Btn_Cancel.TabIndex = 4
        Me.Btn_Cancel.Text = "Cancel"
        Me.Btn_Cancel.UseVisualStyleBackColor = False
        '
        'Btn_Clear_eBS_Mainte
        '
        Me.Btn_Clear_eBS_Mainte.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Clear_eBS_Mainte.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Clear_eBS_Mainte.ForeColor = System.Drawing.Color.White
        Me.Btn_Clear_eBS_Mainte.Location = New System.Drawing.Point(314, 115)
        Me.Btn_Clear_eBS_Mainte.Name = "Btn_Clear_eBS_Mainte"
        Me.Btn_Clear_eBS_Mainte.Size = New System.Drawing.Size(100, 40)
        Me.Btn_Clear_eBS_Mainte.TabIndex = 2
        Me.Btn_Clear_eBS_Mainte.Text = "�N���A"
        Me.Btn_Clear_eBS_Mainte.UseVisualStyleBackColor = False
        '
        'Btn_Ref_eBS_Mainte
        '
        Me.Btn_Ref_eBS_Mainte.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Ref_eBS_Mainte.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Ref_eBS_Mainte.ForeColor = System.Drawing.Color.White
        Me.Btn_Ref_eBS_Mainte.Location = New System.Drawing.Point(202, 115)
        Me.Btn_Ref_eBS_Mainte.Name = "Btn_Ref_eBS_Mainte"
        Me.Btn_Ref_eBS_Mainte.Size = New System.Drawing.Size(100, 40)
        Me.Btn_Ref_eBS_Mainte.TabIndex = 1
        Me.Btn_Ref_eBS_Mainte.Text = "�Q��"
        Me.Btn_Ref_eBS_Mainte.UseVisualStyleBackColor = False
        '
        'Btn_Clear_eBS_Sale
        '
        Me.Btn_Clear_eBS_Sale.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Clear_eBS_Sale.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Clear_eBS_Sale.ForeColor = System.Drawing.Color.White
        Me.Btn_Clear_eBS_Sale.Location = New System.Drawing.Point(314, 110)
        Me.Btn_Clear_eBS_Sale.Name = "Btn_Clear_eBS_Sale"
        Me.Btn_Clear_eBS_Sale.Size = New System.Drawing.Size(100, 40)
        Me.Btn_Clear_eBS_Sale.TabIndex = 2
        Me.Btn_Clear_eBS_Sale.Text = "�N���A"
        Me.Btn_Clear_eBS_Sale.UseVisualStyleBackColor = False
        '
        'Btn_Ref_eBS_Sale
        '
        Me.Btn_Ref_eBS_Sale.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Ref_eBS_Sale.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Ref_eBS_Sale.ForeColor = System.Drawing.Color.White
        Me.Btn_Ref_eBS_Sale.Location = New System.Drawing.Point(202, 110)
        Me.Btn_Ref_eBS_Sale.Name = "Btn_Ref_eBS_Sale"
        Me.Btn_Ref_eBS_Sale.Size = New System.Drawing.Size(100, 40)
        Me.Btn_Ref_eBS_Sale.TabIndex = 1
        Me.Btn_Ref_eBS_Sale.Text = "�Q��"
        Me.Btn_Ref_eBS_Sale.UseVisualStyleBackColor = False
        '
        'Btn_Clear_ConfigSWMA
        '
        Me.Btn_Clear_ConfigSWMA.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Clear_ConfigSWMA.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Clear_ConfigSWMA.ForeColor = System.Drawing.Color.White
        Me.Btn_Clear_ConfigSWMA.Location = New System.Drawing.Point(314, 110)
        Me.Btn_Clear_ConfigSWMA.Name = "Btn_Clear_ConfigSWMA"
        Me.Btn_Clear_ConfigSWMA.Size = New System.Drawing.Size(100, 40)
        Me.Btn_Clear_ConfigSWMA.TabIndex = 2
        Me.Btn_Clear_ConfigSWMA.Text = "�N���A"
        Me.Btn_Clear_ConfigSWMA.UseVisualStyleBackColor = False
        '
        'Btn_Ref_ConfigSWMA
        '
        Me.Btn_Ref_ConfigSWMA.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Ref_ConfigSWMA.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Ref_ConfigSWMA.ForeColor = System.Drawing.Color.White
        Me.Btn_Ref_ConfigSWMA.Location = New System.Drawing.Point(202, 110)
        Me.Btn_Ref_ConfigSWMA.Name = "Btn_Ref_ConfigSWMA"
        Me.Btn_Ref_ConfigSWMA.Size = New System.Drawing.Size(100, 40)
        Me.Btn_Ref_ConfigSWMA.TabIndex = 1
        Me.Btn_Ref_ConfigSWMA.Text = "�Q��"
        Me.Btn_Ref_ConfigSWMA.UseVisualStyleBackColor = False
        '
        'Lst_File_eBS_Mainte
        '
        Me.Lst_File_eBS_Mainte.HorizontalScrollbar = True
        Me.Lst_File_eBS_Mainte.ItemHeight = 15
        Me.Lst_File_eBS_Mainte.Location = New System.Drawing.Point(17, 30)
        Me.Lst_File_eBS_Mainte.Name = "Lst_File_eBS_Mainte"
        Me.Lst_File_eBS_Mainte.Size = New System.Drawing.Size(397, 79)
        Me.Lst_File_eBS_Mainte.TabIndex = 0
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(17, 10)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(196, 20)
        Me.Label5.TabIndex = 51
        Me.Label5.Text = "��e-BS (�ێ�)"
        '
        'Lst_File_eBS_Sale
        '
        Me.Lst_File_eBS_Sale.HorizontalScrollbar = True
        Me.Lst_File_eBS_Sale.ItemHeight = 15
        Me.Lst_File_eBS_Sale.Location = New System.Drawing.Point(17, 25)
        Me.Lst_File_eBS_Sale.Name = "Lst_File_eBS_Sale"
        Me.Lst_File_eBS_Sale.Size = New System.Drawing.Size(397, 79)
        Me.Lst_File_eBS_Sale.TabIndex = 0
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(17, 5)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(196, 20)
        Me.Label4.TabIndex = 49
        Me.Label4.Text = "��e-BS (����)"
        '
        'Lst_File_ConfigSWMA
        '
        Me.Lst_File_ConfigSWMA.HorizontalScrollbar = True
        Me.Lst_File_ConfigSWMA.ItemHeight = 15
        Me.Lst_File_ConfigSWMA.Location = New System.Drawing.Point(17, 30)
        Me.Lst_File_ConfigSWMA.Name = "Lst_File_ConfigSWMA"
        Me.Lst_File_ConfigSWMA.Size = New System.Drawing.Size(397, 79)
        Me.Lst_File_ConfigSWMA.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(17, 10)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(196, 20)
        Me.Label1.TabIndex = 47
        Me.Label1.Text = "��SWMA"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Pnl_Ebs_Sale)
        Me.GroupBox5.Controls.Add(Me.Pnl_Swma)
        Me.GroupBox5.Controls.Add(Me.Pnl_Ebs_Mainte)
        Me.GroupBox5.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.GroupBox5.Location = New System.Drawing.Point(34, 10)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(487, 480)
        Me.GroupBox5.TabIndex = 0
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "�֘A�t�@�C���w��"
        '
        'Pnl_Ebs_Sale
        '
        Me.Pnl_Ebs_Sale.Controls.Add(Me.Lst_File_eBS_Sale)
        Me.Pnl_Ebs_Sale.Controls.Add(Me.Label4)
        Me.Pnl_Ebs_Sale.Controls.Add(Me.Btn_Clear_eBS_Sale)
        Me.Pnl_Ebs_Sale.Controls.Add(Me.Btn_Ref_eBS_Sale)
        Me.Pnl_Ebs_Sale.Controls.Add(Me.Btn_Up_eBS_Sale)
        Me.Pnl_Ebs_Sale.Controls.Add(Me.Btn_Down_eBS_Sale)
        Me.Pnl_Ebs_Sale.Location = New System.Drawing.Point(17, 165)
        Me.Pnl_Ebs_Sale.Name = "Pnl_Ebs_Sale"
        Me.Pnl_Ebs_Sale.Size = New System.Drawing.Size(448, 155)
        Me.Pnl_Ebs_Sale.TabIndex = 1
        '
        'Btn_Up_eBS_Sale
        '
        Me.Btn_Up_eBS_Sale.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Up_eBS_Sale.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Up_eBS_Sale.ForeColor = System.Drawing.Color.White
        Me.Btn_Up_eBS_Sale.Location = New System.Drawing.Point(414, 55)
        Me.Btn_Up_eBS_Sale.Name = "Btn_Up_eBS_Sale"
        Me.Btn_Up_eBS_Sale.Size = New System.Drawing.Size(28, 25)
        Me.Btn_Up_eBS_Sale.TabIndex = 3
        Me.Btn_Up_eBS_Sale.Text = "��"
        Me.Btn_Up_eBS_Sale.UseVisualStyleBackColor = False
        '
        'Btn_Down_eBS_Sale
        '
        Me.Btn_Down_eBS_Sale.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Down_eBS_Sale.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Down_eBS_Sale.ForeColor = System.Drawing.Color.White
        Me.Btn_Down_eBS_Sale.Location = New System.Drawing.Point(414, 80)
        Me.Btn_Down_eBS_Sale.Name = "Btn_Down_eBS_Sale"
        Me.Btn_Down_eBS_Sale.Size = New System.Drawing.Size(28, 25)
        Me.Btn_Down_eBS_Sale.TabIndex = 4
        Me.Btn_Down_eBS_Sale.Text = "��"
        Me.Btn_Down_eBS_Sale.UseVisualStyleBackColor = False
        '
        'Pnl_Swma
        '
        Me.Pnl_Swma.Controls.Add(Me.Lst_File_ConfigSWMA)
        Me.Pnl_Swma.Controls.Add(Me.Label1)
        Me.Pnl_Swma.Controls.Add(Me.Btn_Clear_ConfigSWMA)
        Me.Pnl_Swma.Controls.Add(Me.Btn_Ref_ConfigSWMA)
        Me.Pnl_Swma.Controls.Add(Me.Btn_Up_ConfigSWMA)
        Me.Pnl_Swma.Controls.Add(Me.Btn_Down_ConfigSWMA)
        Me.Pnl_Swma.Location = New System.Drawing.Point(17, 15)
        Me.Pnl_Swma.Name = "Pnl_Swma"
        Me.Pnl_Swma.Size = New System.Drawing.Size(448, 155)
        Me.Pnl_Swma.TabIndex = 0
        '
        'Btn_Up_ConfigSWMA
        '
        Me.Btn_Up_ConfigSWMA.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Up_ConfigSWMA.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Up_ConfigSWMA.ForeColor = System.Drawing.Color.White
        Me.Btn_Up_ConfigSWMA.Location = New System.Drawing.Point(414, 60)
        Me.Btn_Up_ConfigSWMA.Name = "Btn_Up_ConfigSWMA"
        Me.Btn_Up_ConfigSWMA.Size = New System.Drawing.Size(28, 25)
        Me.Btn_Up_ConfigSWMA.TabIndex = 3
        Me.Btn_Up_ConfigSWMA.Text = "��"
        Me.Btn_Up_ConfigSWMA.UseVisualStyleBackColor = False
        '
        'Btn_Down_ConfigSWMA
        '
        Me.Btn_Down_ConfigSWMA.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Down_ConfigSWMA.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Down_ConfigSWMA.ForeColor = System.Drawing.Color.White
        Me.Btn_Down_ConfigSWMA.Location = New System.Drawing.Point(414, 85)
        Me.Btn_Down_ConfigSWMA.Name = "Btn_Down_ConfigSWMA"
        Me.Btn_Down_ConfigSWMA.Size = New System.Drawing.Size(28, 25)
        Me.Btn_Down_ConfigSWMA.TabIndex = 4
        Me.Btn_Down_ConfigSWMA.Text = "��"
        Me.Btn_Down_ConfigSWMA.UseVisualStyleBackColor = False
        '
        'Pnl_Ebs_Mainte
        '
        Me.Pnl_Ebs_Mainte.Controls.Add(Me.Btn_Clear_eBS_Mainte)
        Me.Pnl_Ebs_Mainte.Controls.Add(Me.Btn_Ref_eBS_Mainte)
        Me.Pnl_Ebs_Mainte.Controls.Add(Me.Lst_File_eBS_Mainte)
        Me.Pnl_Ebs_Mainte.Controls.Add(Me.Label5)
        Me.Pnl_Ebs_Mainte.Controls.Add(Me.Btn_Up_eBS_Mainte)
        Me.Pnl_Ebs_Mainte.Controls.Add(Me.Btn_Down_eBS_Mainte)
        Me.Pnl_Ebs_Mainte.Location = New System.Drawing.Point(17, 315)
        Me.Pnl_Ebs_Mainte.Name = "Pnl_Ebs_Mainte"
        Me.Pnl_Ebs_Mainte.Size = New System.Drawing.Size(448, 160)
        Me.Pnl_Ebs_Mainte.TabIndex = 2
        '
        'Btn_Up_eBS_Mainte
        '
        Me.Btn_Up_eBS_Mainte.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Up_eBS_Mainte.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Up_eBS_Mainte.ForeColor = System.Drawing.Color.White
        Me.Btn_Up_eBS_Mainte.Location = New System.Drawing.Point(414, 60)
        Me.Btn_Up_eBS_Mainte.Name = "Btn_Up_eBS_Mainte"
        Me.Btn_Up_eBS_Mainte.Size = New System.Drawing.Size(28, 25)
        Me.Btn_Up_eBS_Mainte.TabIndex = 3
        Me.Btn_Up_eBS_Mainte.Text = "��"
        Me.Btn_Up_eBS_Mainte.UseVisualStyleBackColor = False
        '
        'Btn_Down_eBS_Mainte
        '
        Me.Btn_Down_eBS_Mainte.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Down_eBS_Mainte.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Down_eBS_Mainte.ForeColor = System.Drawing.Color.White
        Me.Btn_Down_eBS_Mainte.Location = New System.Drawing.Point(414, 85)
        Me.Btn_Down_eBS_Mainte.Name = "Btn_Down_eBS_Mainte"
        Me.Btn_Down_eBS_Mainte.Size = New System.Drawing.Size(28, 25)
        Me.Btn_Down_eBS_Mainte.TabIndex = 4
        Me.Btn_Down_eBS_Mainte.Text = "��"
        Me.Btn_Down_eBS_Mainte.UseVisualStyleBackColor = False
        '
        'Chk_BoxReplace
        '
        Me.Chk_BoxReplace.Location = New System.Drawing.Point(39, 25)
        Me.Chk_BoxReplace.Name = "Chk_BoxReplace"
        Me.Chk_BoxReplace.Size = New System.Drawing.Size(174, 30)
        Me.Chk_BoxReplace.TabIndex = 0
        Me.Chk_BoxReplace.Text = "BoxReplace"
        '
        'Grp_FileType
        '
        Me.Grp_FileType.Controls.Add(Me.Chk_BoxReplace)
        Me.Grp_FileType.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Grp_FileType.Location = New System.Drawing.Point(34, 510)
        Me.Grp_FileType.Name = "Grp_FileType"
        Me.Grp_FileType.Size = New System.Drawing.Size(235, 70)
        Me.Grp_FileType.TabIndex = 1
        Me.Grp_FileType.TabStop = False
        Me.Grp_FileType.Text = "Config�t�@�C�����"
        '
        'Frm_FileSelect
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.AutoSize = True
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(416, 561)
        Me.Controls.Add(Me.Grp_FileType)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.Btn_Cancel)
        Me.Controls.Add(Me.Btn_Ok)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Frm_FileSelect"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "�֘A�t�@�C���w��"
        Me.GroupBox5.ResumeLayout(False)
        Me.Pnl_Ebs_Sale.ResumeLayout(False)
        Me.Pnl_Swma.ResumeLayout(False)
        Me.Pnl_Ebs_Mainte.ResumeLayout(False)
        Me.Grp_FileType.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region " �����o�ϐ� "

    Dim _inputFile As InputFileList
    Dim _htSwmaList As New Hashtable
    Dim _htEbsSaleList As New Hashtable
    Dim _htEbsMainteList As New Hashtable
    Dim _dialogInitialPath As String
#End Region

#Region " �v���p�e�B "

    Public WriteOnly Property InputFile() As InputFileList
        Set(ByVal Value As InputFileList)
            Me._inputFile = Value
        End Set
    End Property

    Public Property DialogInitialPath() As String
        Get
            Return Me._dialogInitialPath
        End Get
        Set(ByVal Value As String)
            Me._dialogInitialPath = Value
        End Set
    End Property

#End Region

#Region " �C�x���g�n���h�� "

    '--------------------------------------------------------
    '���\�b�h���FFrm_FileSelect_Load
    '�T    �v  �F��ʃ��[�h����
    '��    ��  �F��ʃ��[�h�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Frm_FileSelect_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try
            '��ʐݒ�
            Me.SetInitialData()

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
            Me.Close()
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
            Me.Close()
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Ref_ConfigSWMA_Click
    '�T    �v  �FBtn_Ref_ConfigSWMA�N���b�N����
    '��    ��  �FBtn_Ref_ConfigSWMA�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Ref_ConfigSWMA_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Ref_ConfigSWMA.Click

        Try
            Dim dialog As OpenFileDialog = New OpenFileDialog
            'dialog.InitialDirectory = configValue.CSV_PATH
            dialog.Filter = "csv files (*.csv)|*.csv"
            dialog.Multiselect = True '�����I���Ƃ���B
            dialog.InitialDirectory = GetFileSeletctDialogInitialPath()

            If dialog.ShowDialog() = DialogResult.OK Then
                Dim index As Integer
                Dim fileName As String
                For Each fileName In dialog.FileNames
                    index = Me.Lst_File_ConfigSWMA.Items.Add(Path.GetFileName(fileName))
                    Me._htSwmaList.Add(index, fileName)
                Next

            End If

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Clear_ConfigSWMA_Click
    '�T    �v  �FBtn_Clear_ConfigSWMA�N���b�N����
    '��    ��  �FBtn_Clear_ConfigSWMA�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Clear_ConfigSWMA_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear_ConfigSWMA.Click
        Try
            Dim index As Integer

            index = Me.Lst_File_ConfigSWMA.SelectedIndex
            If index <> -1 Then
                '�w�肵���t�@�C�����X�g�{�b�N�X�N���A
                Me.Lst_File_ConfigSWMA.Items.RemoveAt(index)
                '�n�b�V���e�[�u���ĕҏW
                For index = 0 To Me._htSwmaList.Count - 1
                    '����̒l����
                    Me._htSwmaList(index) = Me._htSwmaList(index + 1)
                Next
                '��ԍŌ�̒l���폜
                Me._htSwmaList.Remove(Me._htSwmaList.Count - 1)
            Else
                '�t�@�C�����X�g�{�b�N�X�̑S�Ă̍��ڃN���A
                Me.Lst_File_ConfigSWMA.Items.Clear()
                Me._htSwmaList.Clear()
            End If

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try
    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Ref_eBS_Sale_Click
    '�T    �v  �FBtn_Ref_eBS_Sale�N���b�N����
    '��    ��  �FBtn_Ref_eBS_Sale�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Ref_eBS_Sale_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Ref_eBS_Sale.Click

        Try
            Dim dialog As OpenFileDialog = New OpenFileDialog
            dialog.Filter = "csv files (*.csv)|*.csv"
            dialog.Multiselect = True '�����I���Ƃ���B
            dialog.InitialDirectory = GetFileSeletctDialogInitialPath()
            If dialog.ShowDialog() = DialogResult.OK Then
                'Dim fileName As String = dialog.FileName
                Dim index As Integer
                Dim fileName As String
                For Each fileName In dialog.FileNames
                    index = Me.Lst_File_eBS_Sale.Items.Add(Path.GetFileName(fileName))
                    Me._htEbsSaleList.Add(index, fileName)
                Next
            End If

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try
    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Clear_eBS_Sale_Click
    '�T    �v  �FBtn_Clear_eBS_Sale�N���b�N����
    '��    ��  �FBtn_Clear_eBS_Sale�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Clear_eBS_Sale_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear_eBS_Sale.Click

        Try
            Dim index As Integer

            index = Me.Lst_File_eBS_Sale.SelectedIndex
            If index <> -1 Then
                '�w�肵���t�@�C�����X�g�{�b�N�X�N���A
                Me.Lst_File_eBS_Sale.Items.RemoveAt(index)
                '�n�b�V���e�[�u���ĕҏW
                For index = 0 To Me._htEbsSaleList.Count - 1
                    '����̒l����
                    Me._htEbsSaleList(index) = Me._htEbsSaleList(index + 1)
                Next
                '��ԍŌ�̒l���폜
                Me._htEbsSaleList.Remove(Me._htEbsSaleList.Count - 1)
            Else
                '�t�@�C�����X�g�{�b�N�X�̑S�Ă̍��ڃN���A
                Me.Lst_File_eBS_Sale.Items.Clear()
                Me._htEbsSaleList.Clear()
            End If

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Ref_eBS_Mainte_Click
    '�T    �v  �FBtn_Ref_eBS_Mainte�N���b�N����
    '��    ��  �FBtn_Ref_eBS_Mainte�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Ref_eBS_Mainte_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Ref_eBS_Mainte.Click

        Try
            Dim dialog As OpenFileDialog = New OpenFileDialog
            dialog.Filter = "csv files (*.csv)|*.csv"
            dialog.Multiselect = True '�����I���Ƃ���B
            dialog.InitialDirectory = GetFileSeletctDialogInitialPath()
            If dialog.ShowDialog() = DialogResult.OK Then
                Dim index As Integer
                Dim fileName As String
                For Each fileName In dialog.FileNames
                    index = Me.Lst_File_eBS_Mainte.Items.Add(Path.GetFileName(fileName))
                    Me._htEbsMainteList.Add(index, fileName)
                Next
            End If

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Clear_eBS_Mainte_Click
    '�T    �v  �FBtn_Clear_eBS_Mainte�N���b�N����
    '��    ��  �FBtn_Clear_eBS_Mainte�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Clear_eBS_Mainte_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear_eBS_Mainte.Click

        Try
            Dim index As Integer

            index = Me.Lst_File_eBS_Mainte.SelectedIndex
            If index <> -1 Then
                '�w�肵���t�@�C�����X�g�{�b�N�X�N���A
                Me.Lst_File_eBS_Mainte.Items.RemoveAt(index)
                'Me.eBSMainteList.RemoveAt(index)
                '�n�b�V���e�[�u���ĕҏW
                For index = 0 To Me._htEbsMainteList.Count - 1
                    '����̒l����
                    Me._htEbsMainteList(index) = Me._htEbsMainteList(index + 1)
                Next
                '��ԍŌ�̒l���폜
                Me._htEbsMainteList.Remove(Me._htEbsMainteList.Count - 1)
            Else
                '�t�@�C�����X�g�{�b�N�X�̑S�Ă̍��ڃN���A
                Me.Lst_File_eBS_Mainte.Items.Clear()
                Me._htEbsMainteList.Clear()
            End If

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Ok_Click
    '�T    �v  �FBtn_Ok�N���b�N����
    '��    ��  �FBtn_Ok�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Ok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Ok.Click
        Try
            '�t�@�C�����X�g�f�[�^�ݒ�
            Me.SetFileListData()

            '��ʂ����
            Me.Close()

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Cancel_Click
    '�T    �v  �FBtn_Cancel�N���b�N����
    '��    ��  �FBtn_Cancel�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Cancel.Click
        Try
            '��ʂ����
            Me.Close()

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '*----<<---- Shimizu 2008/11/26 START ----<<---- 
    '--------------------------------------------------------
    '���\�b�h���FBtn_Up_ConfigSWMA_Click
    '�T    �v  �FBtn_Up_ConfigSWMA�N���b�N����
    '��    ��  �FBtn_Up_ConfigSWMA�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Up_ConfigSWMA_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Up_ConfigSWMA.Click

        Try
            Dim index As Integer
            index = Me.Lst_File_ConfigSWMA.SelectedIndex

            If index = -1 Or index = 0 Then
                Exit Sub
            End If

            '==============================
            '�����X�g�{�b�N�X�ĕҏW��
            '==============================
            Dim item As String
            '1��̒l��ޔ�
            item = Me.Lst_File_ConfigSWMA.Items(index - 1)
            Me.Lst_File_ConfigSWMA.Items(index - 1) = Me.Lst_File_ConfigSWMA.Items(index)
            Me.Lst_File_ConfigSWMA.Items(index) = item
            Me.Lst_File_ConfigSWMA.SelectedIndex = index - 1

            '==============================
            '�����X�g�ĕҏW��
            '==============================
            Dim fileName As String
            '1��̒l��ޔ�
            fileName = Me._htSwmaList(index - 1)
            Me._htSwmaList(index - 1) = Me._htSwmaList(index)
            Me._htSwmaList(index) = fileName

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Down_ConfigSWMA_Click
    '�T    �v  �FBtn_Down_ConfigSWMA�N���b�N����
    '��    ��  �FBtn_Down_ConfigSWMA�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Down_ConfigSWMA_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Down_ConfigSWMA.Click

        Try
            Dim index As Integer
            index = Me.Lst_File_ConfigSWMA.SelectedIndex

            If index = -1 Or index = Me.Lst_File_ConfigSWMA.Items.Count - 1 Then
                Exit Sub
            End If

            '==============================
            '�����X�g�{�b�N�X�ĕҏW��
            '==============================
            Dim item As String
            '1���̒l��ޔ�
            item = Me.Lst_File_ConfigSWMA.Items(index + 1)
            Me.Lst_File_ConfigSWMA.Items(index + 1) = Me.Lst_File_ConfigSWMA.Items(index)
            Me.Lst_File_ConfigSWMA.Items(index) = item
            Me.Lst_File_ConfigSWMA.SelectedIndex = index + 1

            '==============================
            '���n�b�V���e�[�u���ĕҏW��
            '==============================
            Dim fileName As String
            '1���̒l��ޔ�
            fileName = Me._htSwmaList(index + 1)
            Me._htSwmaList(index + 1) = Me._htSwmaList(index)
            Me._htSwmaList(index) = fileName

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Up_eBS_Sale_Click
    '�T    �v  �FBtn_Up_eBS_Sale�N���b�N����
    '��    ��  �FBtn_Up_eBS_Sale�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Up_eBS_Sale_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Up_eBS_Sale.Click

        Try
            Dim index As Integer
            index = Me.Lst_File_eBS_Sale.SelectedIndex

            If index = -1 Or index = 0 Then
                Exit Sub
            End If

            '==============================
            '�����X�g�{�b�N�X�ĕҏW��
            '==============================
            Dim item As String
            '1��̒l��ޔ�
            item = Me.Lst_File_eBS_Sale.Items(index - 1)
            Me.Lst_File_eBS_Sale.Items(index - 1) = Me.Lst_File_eBS_Sale.Items(index)
            Me.Lst_File_eBS_Sale.Items(index) = item
            Me.Lst_File_eBS_Sale.SelectedIndex = index - 1

            '==============================
            '�����X�g�ĕҏW��
            '==============================
            Dim fileName As String
            '1��̒l��ޔ�
            fileName = Me._htEbsSaleList(index - 1)
            Me._htEbsSaleList(index - 1) = Me._htEbsSaleList(index)
            Me._htEbsSaleList(index) = fileName

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Down_eBS_Sale_Click
    '�T    �v  �FBtn_Down_eBS_Sale�N���b�N����
    '��    ��  �FBtn_Down_eBS_Sale�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Down_eBS_Sale_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Down_eBS_Sale.Click

        Try
            Dim index As Integer
            index = Me.Lst_File_eBS_Sale.SelectedIndex

            If index = -1 Or index = Me.Lst_File_eBS_Sale.Items.Count - 1 Then
                Exit Sub
            End If

            '==============================
            '�����X�g�{�b�N�X�ĕҏW��
            '==============================
            Dim item As String
            '1���̒l��ޔ�
            item = Me.Lst_File_eBS_Sale.Items(index + 1)
            Me.Lst_File_eBS_Sale.Items(index + 1) = Me.Lst_File_eBS_Sale.Items(index)
            Me.Lst_File_eBS_Sale.Items(index) = item
            Me.Lst_File_eBS_Sale.SelectedIndex = index + 1

            '==============================
            '���n�b�V���e�[�u���ĕҏW��
            '==============================
            Dim fileName As String
            '1���̒l��ޔ�
            fileName = Me._htEbsSaleList(index + 1)
            Me._htEbsSaleList(index + 1) = Me._htEbsSaleList(index)
            Me._htEbsSaleList(index) = fileName

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Up_eBS_Mainte_Click
    '�T    �v  �FBtn_Up_eBS_Mainte�N���b�N����
    '��    ��  �FBtn_Up_eBS_Mainte�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Up_eBS_Mainte_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Up_eBS_Mainte.Click

        Try
            Dim index As Integer
            index = Me.Lst_File_eBS_Mainte.SelectedIndex

            If index = -1 Or index = 0 Then
                Exit Sub
            End If

            '==============================
            '�����X�g�{�b�N�X�ĕҏW��
            '==============================
            Dim item As String
            '1��̒l��ޔ�
            item = Me.Lst_File_eBS_Mainte.Items(index - 1)
            Me.Lst_File_eBS_Mainte.Items(index - 1) = Me.Lst_File_eBS_Mainte.Items(index)
            Me.Lst_File_eBS_Mainte.Items(index) = item
            Me.Lst_File_eBS_Mainte.SelectedIndex = index - 1

            '==============================
            '�����X�g�ĕҏW��
            '==============================
            Dim fileName As String
            '1��̒l��ޔ�
            fileName = Me._htEbsMainteList(index - 1)
            Me._htEbsMainteList(index - 1) = Me._htEbsMainteList(index)
            Me._htEbsMainteList(index) = fileName

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Down_eBS_Mainte_Click
    '�T    �v  �FBtn_Down_eBS_Mainte�N���b�N����
    '��    ��  �FBtn_Down_eBS_Mainte�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Down_eBS_Mainte_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Down_eBS_Mainte.Click

        Try
            Dim index As Integer
            index = Me.Lst_File_eBS_Mainte.SelectedIndex

            If index = -1 Or index = Me.Lst_File_eBS_Mainte.Items.Count - 1 Then
                Exit Sub
            End If

            '==============================
            '�����X�g�{�b�N�X�ĕҏW��
            '==============================
            Dim item As String
            '1���̒l��ޔ�
            item = Me.Lst_File_eBS_Mainte.Items(index + 1)
            Me.Lst_File_eBS_Mainte.Items(index + 1) = Me.Lst_File_eBS_Mainte.Items(index)
            Me.Lst_File_eBS_Mainte.Items(index) = item
            Me.Lst_File_eBS_Mainte.SelectedIndex = index + 1

            '==============================
            '���n�b�V���e�[�u���ĕҏW��
            '==============================
            Dim fileName As String
            '1���̒l��ޔ�
            fileName = Me._htEbsMainteList(index + 1)
            Me._htEbsMainteList(index + 1) = Me._htEbsMainteList(index)
            Me._htEbsMainteList(index) = fileName

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

#End Region

#Region " �v���C�x�[�g���\�b�h "

    '--------------------------------------------------------
    '���\�b�h���FSetFileList
    '�T    �v  �F��ʓ��͒l�擾����
    '��    ��  �F��ʓ��͒l�擾�������s��
    '��    ��  �F�Ȃ�
    '�� �� �l  �F��ʓ��͒l
    '--------------------------------------------------------
    Private Sub SetInitialData()

        Dim fileNames As String()
        Dim fileName As String
        Dim index As Integer

        '==============================
        '��SWMA��
        '==============================
        fileNames = Me._inputFile.SWMA.Split(CommonConstant.STR_SLASH)
        For Each fileName In fileNames
            If Not fileName.Equals(String.Empty) Then
                index = Me.Lst_File_ConfigSWMA.Items.Add(Path.GetFileName(fileName))
                Me._htSwmaList.Add(index, fileName)
            End If
        Next

        '==============================
        '��eBS(����)��
        '==============================
        fileNames = Me._inputFile.eBS_Sale.Split(CommonConstant.STR_SLASH)
        For Each fileName In fileNames
            If Not fileName.Equals(String.Empty) Then
                index = Me.Lst_File_eBS_Sale.Items.Add(Path.GetFileName(fileName))
                Me._htEbsSaleList.Add(index, fileName)
            End If
        Next

        '==============================
        '��eBS(�ێ�)��
        '==============================
        fileNames = Me._inputFile.eBS_Mainte.Split(CommonConstant.STR_SLASH)
        For Each fileName In fileNames
            If Not fileName.Equals(String.Empty) Then
                index = Me.Lst_File_eBS_Mainte.Items.Add(Path.GetFileName(fileName))
                Me._htEbsMainteList.Add(index, fileName)
            End If
        Next

        '==============================
        '��BoxReplace��
        '==============================
        If Me._inputFile.BoxReplace = CommonConstant.ParamCheck.Yes Then
            Me.Chk_BoxReplace.Checked = True
        Else
            Me.Chk_BoxReplace.Checked = False
        End If

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FSetFileListData
    '�T    �v  �F��ʓ��͒l�擾����
    '��    ��  �F��ʓ��͒l�擾�������s��
    '��    ��  �F�Ȃ�
    '�� �� �l  �F��ʓ��͒l
    '--------------------------------------------------------
    Private Sub SetFileListData()

        Dim fileName As String
        Dim SWMAFileName As New StringBuilder
        Dim eBSSaleFileName As New StringBuilder
        Dim eBSMainteFileName As New StringBuilder
        Dim index As Integer

        '==============================
        '��SWMA��
        '==============================
        For index = 0 To Me._htSwmaList.Count - 1
            fileName = Me._htSwmaList(index).ToString()
            If SWMAFileName.Length > 0 Then
                SWMAFileName.Append(CommonConstant.STR_SLASH)
            End If
            SWMAFileName.Append(fileName)
        Next
        Me._inputFile.SWMA = SWMAFileName.ToString()

        '==============================
        '��eBS(����)��
        '==============================
        For index = 0 To Me._htEbsSaleList.Count - 1
            fileName = Me._htEbsSaleList(index).ToString()
            If eBSSaleFileName.Length > 0 Then
                eBSSaleFileName.Append(CommonConstant.STR_SLASH)
            End If
            eBSSaleFileName.Append(fileName)
        Next
        Me._inputFile.eBS_Sale = eBSSaleFileName.ToString()

        '==============================
        '��eBS(�ێ�)��
        '==============================
        For index = 0 To Me._htEbsMainteList.Count - 1
            fileName = Me._htEbsMainteList(index).ToString()
            If eBSMainteFileName.Length > 0 Then
                eBSMainteFileName.Append(CommonConstant.STR_SLASH)
            End If
            eBSMainteFileName.Append(fileName)
        Next
        Me._inputFile.eBS_Mainte = eBSMainteFileName.ToString()

        '==============================
        '��BoxReplace��
        '==============================
        If Me.Chk_BoxReplace.Checked = True Then
            Me._inputFile.BoxReplace = CommonConstant.ParamCheck.Yes
        Else
            Me._inputFile.BoxReplace = CommonConstant.ParamCheck.No
        End If

    End Sub

    ''' <summary>
    ''' �T  �v�F�Q�ƃ{�^���̃t�@�C���I���_�C�A�����O�{�b�N�X�̏����ʒu���w�肷��B
    ''' ��  ���FConfig\�Y���t�H���_���f�t�H���g�ʒu
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetFileSeletctDialogInitialPath() As String

        Dim strCpNo As String = CommonVariable.CPNO.Trim.PadLeft(8, "0")
        Dim strContractNO As String = CommonVariable.CONTRACTNO.ToString().PadLeft(3, "0c")
        Dim strPath As String

        GetFileSeletctDialogInitialPath = ""

        strPath = CommonConstant.FOLDERNAME_CONFIG & "\" & strCpNo & "_" & strContractNO
        Return FileManager.GetLocalFolderPath(strPath)

    End Function

#End Region

End Class