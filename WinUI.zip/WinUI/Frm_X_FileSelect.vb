Imports System.Text
Imports System.IO
Imports System.Reflection
Imports MUSE.Utility
Imports MUSE.Utility.UserMessageBox
Imports MUSE.Utility.UserException
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.XmlClass.Parameter

'==========================================================================
'�N���X���FFrm_X_FileSelect
'�T    �v�FX_FileSelect�N���X
'��    ���F�֘A�t�@�C���w����
'��    ���F[Ver1.0]  2007/02/16  �����@���K
'==========================================================================
Public Class Frm_X_FileSelect
    Inherits System.Windows.Forms.Form

#Region " Windows �t�H�[�� �f�U�C�i�Ő������ꂽ�R�[�h "

    Public Sub New()
        MyBase.New()

        ' ���̌Ăяo���� Windows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
        InitializeComponent()

        ' InitializeComponent() �Ăяo���̌�ɏ�������ǉ����܂��B

    End Sub

    ' Form �́A�R���|�[�l���g�ꗗ�Ɍ㏈�������s���邽�߂� dispose ���I�[�o�[���C�h���܂��B
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    ' Windows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
    Private components As System.ComponentModel.IContainer

    ' ���� : �ȉ��̃v���V�[�W���́AWindows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
    'Windows �t�H�[�� �f�U�C�i���g���ĕύX���Ă��������B  
    ' �R�[�h �G�f�B�^���g���ĕύX���Ȃ��ł��������B
    Friend WithEvents Btn_Ok As UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Cancel As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Btn_Clear_eBS_Sale As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Lst_File_eBS_Sale As System.Windows.Forms.ListBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Btn_Ref_eBS_Sale As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Lst_File_eBS_Mainte As System.Windows.Forms.ListBox
    Friend WithEvents Btn_Ref_eBS_Mainte As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Clear_eBS_Mainte As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Up_eBS_Sale As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Down_eBS_Sale As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Up_eBS_Mainte As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Down_eBS_Mainte As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Txt_SystemQuantity As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_SystemQuantity As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Btn_Ok = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Cancel = New MUSE.UserControl.UCnt_Btn0001()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Lst_File_eBS_Mainte = New System.Windows.Forms.ListBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Btn_Ref_eBS_Mainte = New MUSE.UserControl.UCnt_Btn0001()
        Me.Lst_File_eBS_Sale = New System.Windows.Forms.ListBox()
        Me.Btn_Clear_eBS_Sale = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Clear_eBS_Mainte = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Ref_eBS_Sale = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Up_eBS_Sale = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Down_eBS_Sale = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Down_eBS_Mainte = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Up_eBS_Mainte = New MUSE.UserControl.UCnt_Btn0001()
        Me.Txt_SystemQuantity = New System.Windows.Forms.TextBox()
        Me.Lbl_SystemQuantity = New System.Windows.Forms.Label()
        Me.GroupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'Btn_Ok
        '
        Me.Btn_Ok.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Ok.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Ok.ForeColor = System.Drawing.Color.White
        Me.Btn_Ok.Location = New System.Drawing.Point(185, 400)
        Me.Btn_Ok.Name = "Btn_Ok"
        Me.Btn_Ok.Size = New System.Drawing.Size(157, 55)
        Me.Btn_Ok.TabIndex = 2
        Me.Btn_Ok.Text = "OK"
        Me.Btn_Ok.UseVisualStyleBackColor = False
        '
        'Btn_Cancel
        '
        Me.Btn_Cancel.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Cancel.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Cancel.ForeColor = System.Drawing.Color.White
        Me.Btn_Cancel.Location = New System.Drawing.Point(364, 400)
        Me.Btn_Cancel.Name = "Btn_Cancel"
        Me.Btn_Cancel.Size = New System.Drawing.Size(157, 55)
        Me.Btn_Cancel.TabIndex = 3
        Me.Btn_Cancel.Text = "Cancel"
        Me.Btn_Cancel.UseVisualStyleBackColor = False
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Label4)
        Me.GroupBox5.Controls.Add(Me.Lst_File_eBS_Mainte)
        Me.GroupBox5.Controls.Add(Me.Label5)
        Me.GroupBox5.Controls.Add(Me.Btn_Ref_eBS_Mainte)
        Me.GroupBox5.Controls.Add(Me.Lst_File_eBS_Sale)
        Me.GroupBox5.Controls.Add(Me.Btn_Clear_eBS_Sale)
        Me.GroupBox5.Controls.Add(Me.Btn_Clear_eBS_Mainte)
        Me.GroupBox5.Controls.Add(Me.Btn_Ref_eBS_Sale)
        Me.GroupBox5.Controls.Add(Me.Btn_Up_eBS_Sale)
        Me.GroupBox5.Controls.Add(Me.Btn_Down_eBS_Sale)
        Me.GroupBox5.Controls.Add(Me.Btn_Down_eBS_Mainte)
        Me.GroupBox5.Controls.Add(Me.Btn_Up_eBS_Mainte)
        Me.GroupBox5.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.GroupBox5.Location = New System.Drawing.Point(34, 10)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(487, 330)
        Me.GroupBox5.TabIndex = 0
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "�֘A�t�@�C���w��"
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label4.Location = New System.Drawing.Point(39, 25)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(196, 20)
        Me.Label4.TabIndex = 49
        Me.Label4.Text = "��e-BS (����)"
        '
        'Lst_File_eBS_Mainte
        '
        Me.Lst_File_eBS_Mainte.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Lst_File_eBS_Mainte.HorizontalScrollbar = True
        Me.Lst_File_eBS_Mainte.ItemHeight = 15
        Me.Lst_File_eBS_Mainte.Location = New System.Drawing.Point(39, 195)
        Me.Lst_File_eBS_Mainte.Name = "Lst_File_eBS_Mainte"
        Me.Lst_File_eBS_Mainte.Size = New System.Drawing.Size(403, 79)
        Me.Lst_File_eBS_Mainte.TabIndex = 5
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label5.Location = New System.Drawing.Point(39, 175)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(196, 20)
        Me.Label5.TabIndex = 51
        Me.Label5.Text = "��e-BS (�ێ�)"
        '
        'Btn_Ref_eBS_Mainte
        '
        Me.Btn_Ref_eBS_Mainte.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Ref_eBS_Mainte.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Ref_eBS_Mainte.ForeColor = System.Drawing.Color.White
        Me.Btn_Ref_eBS_Mainte.Location = New System.Drawing.Point(230, 280)
        Me.Btn_Ref_eBS_Mainte.Name = "Btn_Ref_eBS_Mainte"
        Me.Btn_Ref_eBS_Mainte.Size = New System.Drawing.Size(100, 40)
        Me.Btn_Ref_eBS_Mainte.TabIndex = 6
        Me.Btn_Ref_eBS_Mainte.Text = "�Q��"
        Me.Btn_Ref_eBS_Mainte.UseVisualStyleBackColor = False
        '
        'Lst_File_eBS_Sale
        '
        Me.Lst_File_eBS_Sale.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Lst_File_eBS_Sale.HorizontalScrollbar = True
        Me.Lst_File_eBS_Sale.ItemHeight = 15
        Me.Lst_File_eBS_Sale.Location = New System.Drawing.Point(39, 45)
        Me.Lst_File_eBS_Sale.Name = "Lst_File_eBS_Sale"
        Me.Lst_File_eBS_Sale.Size = New System.Drawing.Size(403, 79)
        Me.Lst_File_eBS_Sale.TabIndex = 0
        '
        'Btn_Clear_eBS_Sale
        '
        Me.Btn_Clear_eBS_Sale.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Clear_eBS_Sale.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Clear_eBS_Sale.ForeColor = System.Drawing.Color.White
        Me.Btn_Clear_eBS_Sale.Location = New System.Drawing.Point(342, 130)
        Me.Btn_Clear_eBS_Sale.Name = "Btn_Clear_eBS_Sale"
        Me.Btn_Clear_eBS_Sale.Size = New System.Drawing.Size(100, 40)
        Me.Btn_Clear_eBS_Sale.TabIndex = 2
        Me.Btn_Clear_eBS_Sale.Text = "�N���A"
        Me.Btn_Clear_eBS_Sale.UseVisualStyleBackColor = False
        '
        'Btn_Clear_eBS_Mainte
        '
        Me.Btn_Clear_eBS_Mainte.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Clear_eBS_Mainte.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Clear_eBS_Mainte.ForeColor = System.Drawing.Color.White
        Me.Btn_Clear_eBS_Mainte.Location = New System.Drawing.Point(342, 280)
        Me.Btn_Clear_eBS_Mainte.Name = "Btn_Clear_eBS_Mainte"
        Me.Btn_Clear_eBS_Mainte.Size = New System.Drawing.Size(100, 40)
        Me.Btn_Clear_eBS_Mainte.TabIndex = 7
        Me.Btn_Clear_eBS_Mainte.Text = "�N���A"
        Me.Btn_Clear_eBS_Mainte.UseVisualStyleBackColor = False
        '
        'Btn_Ref_eBS_Sale
        '
        Me.Btn_Ref_eBS_Sale.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Ref_eBS_Sale.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Ref_eBS_Sale.ForeColor = System.Drawing.Color.White
        Me.Btn_Ref_eBS_Sale.Location = New System.Drawing.Point(230, 130)
        Me.Btn_Ref_eBS_Sale.Name = "Btn_Ref_eBS_Sale"
        Me.Btn_Ref_eBS_Sale.Size = New System.Drawing.Size(100, 40)
        Me.Btn_Ref_eBS_Sale.TabIndex = 1
        Me.Btn_Ref_eBS_Sale.Text = "�Q��"
        Me.Btn_Ref_eBS_Sale.UseVisualStyleBackColor = False
        '
        'Btn_Up_eBS_Sale
        '
        Me.Btn_Up_eBS_Sale.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Up_eBS_Sale.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Up_eBS_Sale.ForeColor = System.Drawing.Color.White
        Me.Btn_Up_eBS_Sale.Location = New System.Drawing.Point(442, 75)
        Me.Btn_Up_eBS_Sale.Name = "Btn_Up_eBS_Sale"
        Me.Btn_Up_eBS_Sale.Size = New System.Drawing.Size(28, 25)
        Me.Btn_Up_eBS_Sale.TabIndex = 3
        Me.Btn_Up_eBS_Sale.Text = "��"
        Me.Btn_Up_eBS_Sale.UseVisualStyleBackColor = False
        '
        'Btn_Down_eBS_Sale
        '
        Me.Btn_Down_eBS_Sale.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Down_eBS_Sale.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Down_eBS_Sale.ForeColor = System.Drawing.Color.White
        Me.Btn_Down_eBS_Sale.Location = New System.Drawing.Point(442, 100)
        Me.Btn_Down_eBS_Sale.Name = "Btn_Down_eBS_Sale"
        Me.Btn_Down_eBS_Sale.Size = New System.Drawing.Size(28, 25)
        Me.Btn_Down_eBS_Sale.TabIndex = 4
        Me.Btn_Down_eBS_Sale.Text = "��"
        Me.Btn_Down_eBS_Sale.UseVisualStyleBackColor = False
        '
        'Btn_Down_eBS_Mainte
        '
        Me.Btn_Down_eBS_Mainte.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Down_eBS_Mainte.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Down_eBS_Mainte.ForeColor = System.Drawing.Color.White
        Me.Btn_Down_eBS_Mainte.Location = New System.Drawing.Point(442, 250)
        Me.Btn_Down_eBS_Mainte.Name = "Btn_Down_eBS_Mainte"
        Me.Btn_Down_eBS_Mainte.Size = New System.Drawing.Size(28, 25)
        Me.Btn_Down_eBS_Mainte.TabIndex = 9
        Me.Btn_Down_eBS_Mainte.Text = "��"
        Me.Btn_Down_eBS_Mainte.UseVisualStyleBackColor = False
        '
        'Btn_Up_eBS_Mainte
        '
        Me.Btn_Up_eBS_Mainte.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Up_eBS_Mainte.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Up_eBS_Mainte.ForeColor = System.Drawing.Color.White
        Me.Btn_Up_eBS_Mainte.Location = New System.Drawing.Point(442, 225)
        Me.Btn_Up_eBS_Mainte.Name = "Btn_Up_eBS_Mainte"
        Me.Btn_Up_eBS_Mainte.Size = New System.Drawing.Size(28, 25)
        Me.Btn_Up_eBS_Mainte.TabIndex = 8
        Me.Btn_Up_eBS_Mainte.Text = "��"
        Me.Btn_Up_eBS_Mainte.UseVisualStyleBackColor = False
        '
        'Txt_SystemQuantity
        '
        Me.Txt_SystemQuantity.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.Txt_SystemQuantity.Location = New System.Drawing.Point(470, 350)
        Me.Txt_SystemQuantity.MaxLength = 3
        Me.Txt_SystemQuantity.Name = "Txt_SystemQuantity"
        Me.Txt_SystemQuantity.Size = New System.Drawing.Size(49, 22)
        Me.Txt_SystemQuantity.TabIndex = 1
        Me.Txt_SystemQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.Txt_SystemQuantity.Visible = False
        '
        'Lbl_SystemQuantity
        '
        Me.Lbl_SystemQuantity.Location = New System.Drawing.Point(353, 355)
        Me.Lbl_SystemQuantity.Name = "Lbl_SystemQuantity"
        Me.Lbl_SystemQuantity.Size = New System.Drawing.Size(117, 20)
        Me.Lbl_SystemQuantity.TabIndex = 47
        Me.Lbl_SystemQuantity.Text = "SYSTEM��"
        Me.Lbl_SystemQuantity.Visible = False
        '
        'Frm_X_FileSelect
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.AutoSize = True
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(416, 401)
        Me.Controls.Add(Me.Txt_SystemQuantity)
        Me.Controls.Add(Me.Lbl_SystemQuantity)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.Btn_Cancel)
        Me.Controls.Add(Me.Btn_Ok)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Frm_X_FileSelect"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "�֘A�t�@�C���w��"
        Me.GroupBox5.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

#Region " �����o�ϐ� "

    Dim _inputFile As X_InputFileList
    Dim _htEbsSaleList As New Hashtable
    Dim _htEbsMainteList As New Hashtable
    Dim _dialogInitialPath As String

#End Region

#Region " �v���p�e�B "

    Public WriteOnly Property InputFile() As X_InputFileList
        Set(ByVal Value As X_InputFileList)
            Me._inputFile = Value
        End Set
    End Property

    Public Property DialogInitialPath() As String
        Get
            Return Me._dialogInitialPath
        End Get
        Set(ByVal Value As String)
            Me._dialogInitialPath = Value
        End Set
    End Property

#End Region

#Region " �C�x���g�n���h�� "

    '--------------------------------------------------------
    '���\�b�h���FFrm_X_FileSelect_Load
    '�T    �v  �F��ʃ��[�h����
    '��    ��  �F��ʃ��[�h�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Frm_X_FileSelect_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try
            '��ʐݒ�
            Me.SetInitialData()

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
            Me.Close()
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
            Me.Close()
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Ref_eBS_Sale_Click
    '�T    �v  �FBtn_Ref_eBS_Sale�N���b�N����
    '��    ��  �FBtn_Ref_eBS_Sale�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Ref_eBS_Sale_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Ref_eBS_Sale.Click

        Try
            Dim dialog As OpenFileDialog = New OpenFileDialog
            dialog.Filter = "csv files (*.csv)|*.csv"
            dialog.Multiselect = True '�����I���Ƃ���B
            dialog.InitialDirectory = GetFileSeletctDialogInitialPath()

            If dialog.ShowDialog() = DialogResult.OK Then
                Dim index As Integer
                Dim fileName As String
                For Each fileName In dialog.FileNames
                    index = Me.Lst_File_eBS_Sale.Items.Add(Path.GetFileName(fileName))
                    Me._htEbsSaleList.Add(index, fileName)
                Next
            End If

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try
    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Clear_eBS_Sale_Click
    '�T    �v  �FBtn_Clear_eBS_Sale�N���b�N����
    '��    ��  �FBtn_Clear_eBS_Sale�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Clear_eBS_Sale_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear_eBS_Sale.Click

        Try
            Dim index As Integer

            index = Me.Lst_File_eBS_Sale.SelectedIndex
            If index <> -1 Then
                '�w�肵���t�@�C�����X�g�{�b�N�X�N���A
                Me.Lst_File_eBS_Sale.Items.RemoveAt(index)
                '�n�b�V���e�[�u���ĕҏW
                For index = 0 To Me._htEbsSaleList.Count - 1
                    '����̒l����
                    Me._htEbsSaleList(index) = Me._htEbsSaleList(index + 1)
                Next
                '��ԍŌ�̒l���폜
                Me._htEbsSaleList.Remove(Me._htEbsSaleList.Count - 1)
            Else
                '�t�@�C�����X�g�{�b�N�X�̑S�Ă̍��ڃN���A
                Me.Lst_File_eBS_Sale.Items.Clear()
                Me._htEbsSaleList.Clear()
            End If

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Ref_eBS_Mainte_Click
    '�T    �v  �FBtn_Ref_eBS_Mainte�N���b�N����
    '��    ��  �FBtn_Ref_eBS_Mainte�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Ref_eBS_Mainte_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Ref_eBS_Mainte.Click

        Try
            Dim dialog As OpenFileDialog = New OpenFileDialog
            dialog.Filter = "csv files (*.csv)|*.csv"
            dialog.Multiselect = True '�����I���Ƃ���B
            dialog.InitialDirectory = GetFileSeletctDialogInitialPath()

            If dialog.ShowDialog() = DialogResult.OK Then
                Dim index As Integer
                Dim fileName As String
                For Each fileName In dialog.FileNames
                    index = Me.Lst_File_eBS_Mainte.Items.Add(Path.GetFileName(fileName))
                    Me._htEbsMainteList.Add(index, fileName)
                Next
            End If

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Clear_eBS_Mainte_Click
    '�T    �v  �FBtn_Clear_eBS_Mainte�N���b�N����
    '��    ��  �FBtn_Clear_eBS_Mainte�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Clear_eBS_Mainte_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear_eBS_Mainte.Click

        Try
            Dim index As Integer

            index = Me.Lst_File_eBS_Mainte.SelectedIndex
            If index <> -1 Then
                '�w�肵���t�@�C�����X�g�{�b�N�X�N���A
                Me.Lst_File_eBS_Mainte.Items.RemoveAt(index)
                '�n�b�V���e�[�u���ĕҏW
                For index = 0 To Me._htEbsMainteList.Count - 1
                    '����̒l����
                    Me._htEbsMainteList(index) = Me._htEbsMainteList(index + 1)
                Next
                '��ԍŌ�̒l���폜
                Me._htEbsMainteList.Remove(Me._htEbsMainteList.Count - 1)
            Else
                '�t�@�C�����X�g�{�b�N�X�̑S�Ă̍��ڃN���A
                Me.Lst_File_eBS_Mainte.Items.Clear()
                Me._htEbsMainteList.Clear()
            End If

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Ok_Click
    '�T    �v  �FBtn_Ok�N���b�N����
    '��    ��  �FBtn_Ok�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Ok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Ok.Click
        Try
            '�t�@�C�����X�g�f�[�^�ݒ�
            Me.SetFileListData()

            '��ʂ����
            Me.Close()

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Cancel_Click
    '�T    �v  �FBtn_Cancel�N���b�N����
    '��    ��  �FBtn_Cancel�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Cancel.Click
        Try
            '��ʂ����
            Me.Close()

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Up_eBS_Sale_Click
    '�T    �v  �FBtn_Up_eBS_Sale�N���b�N����
    '��    ��  �FBtn_Up_eBS_Sale�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Up_eBS_Sale_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Up_eBS_Sale.Click

        Try
            Dim index As Integer
            index = Me.Lst_File_eBS_Sale.SelectedIndex

            If index = -1 Or index = 0 Then
                Exit Sub
            End If

            '==============================
            '�����X�g�{�b�N�X�ĕҏW��
            '==============================
            Dim item As String
            '1��̒l��ޔ�
            item = Me.Lst_File_eBS_Sale.Items(index - 1)
            Me.Lst_File_eBS_Sale.Items(index - 1) = Me.Lst_File_eBS_Sale.Items(index)
            Me.Lst_File_eBS_Sale.Items(index) = item
            Me.Lst_File_eBS_Sale.SelectedIndex = index - 1

            '==============================
            '�����X�g�ĕҏW��
            '==============================
            Dim fileName As String
            '1��̒l��ޔ�
            fileName = Me._htEbsSaleList(index - 1)
            Me._htEbsSaleList(index - 1) = Me._htEbsSaleList(index)
            Me._htEbsSaleList(index) = fileName

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Down_eBS_Sale_Click
    '�T    �v  �FBtn_Down_eBS_Sale�N���b�N����
    '��    ��  �FBtn_Down_eBS_Sale�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Down_eBS_Sale_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Down_eBS_Sale.Click

        Try
            Dim index As Integer
            index = Me.Lst_File_eBS_Sale.SelectedIndex

            If index = -1 Or index = Me.Lst_File_eBS_Sale.Items.Count - 1 Then
                Exit Sub
            End If

            '==============================
            '�����X�g�{�b�N�X�ĕҏW��
            '==============================
            Dim item As String
            '1���̒l��ޔ�
            item = Me.Lst_File_eBS_Sale.Items(index + 1)
            Me.Lst_File_eBS_Sale.Items(index + 1) = Me.Lst_File_eBS_Sale.Items(index)
            Me.Lst_File_eBS_Sale.Items(index) = item
            Me.Lst_File_eBS_Sale.SelectedIndex = index + 1

            '==============================
            '���n�b�V���e�[�u���ĕҏW��
            '==============================
            Dim fileName As String
            '1���̒l��ޔ�
            fileName = Me._htEbsSaleList(index + 1)
            Me._htEbsSaleList(index + 1) = Me._htEbsSaleList(index)
            Me._htEbsSaleList(index) = fileName

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Up_eBS_Mainte_Click
    '�T    �v  �FBtn_Up_eBS_Mainte�N���b�N����
    '��    ��  �FBtn_Up_eBS_Mainte�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Up_eBS_Mainte_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Up_eBS_Mainte.Click

        Try
            Dim index As Integer
            index = Me.Lst_File_eBS_Mainte.SelectedIndex

            If index = -1 Or index = 0 Then
                Exit Sub
            End If

            '==============================
            '�����X�g�{�b�N�X�ĕҏW��
            '==============================
            Dim item As String
            '1��̒l��ޔ�
            item = Me.Lst_File_eBS_Mainte.Items(index - 1)
            Me.Lst_File_eBS_Mainte.Items(index - 1) = Me.Lst_File_eBS_Mainte.Items(index)
            Me.Lst_File_eBS_Mainte.Items(index) = item
            Me.Lst_File_eBS_Mainte.SelectedIndex = index - 1

            '==============================
            '�����X�g�ĕҏW��
            '==============================
            Dim fileName As String
            '1��̒l��ޔ�
            fileName = Me._htEbsMainteList(index - 1)
            Me._htEbsMainteList(index - 1) = Me._htEbsMainteList(index)
            Me._htEbsMainteList(index) = fileName

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Down_eBS_Mainte_Click
    '�T    �v  �FBtn_Down_eBS_Mainte�N���b�N����
    '��    ��  �FBtn_Down_eBS_Mainte�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Down_eBS_Mainte_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Down_eBS_Mainte.Click

        Try
            Dim index As Integer
            index = Me.Lst_File_eBS_Mainte.SelectedIndex

            If index = -1 Or index = Me.Lst_File_eBS_Mainte.Items.Count - 1 Then
                Exit Sub
            End If

            '==============================
            '�����X�g�{�b�N�X�ĕҏW��
            '==============================
            Dim item As String
            '1���̒l��ޔ�
            item = Me.Lst_File_eBS_Mainte.Items(index + 1)
            Me.Lst_File_eBS_Mainte.Items(index + 1) = Me.Lst_File_eBS_Mainte.Items(index)
            Me.Lst_File_eBS_Mainte.Items(index) = item
            Me.Lst_File_eBS_Mainte.SelectedIndex = index + 1

            '==============================
            '���n�b�V���e�[�u���ĕҏW��
            '==============================
            Dim fileName As String
            '1���̒l��ޔ�
            fileName = Me._htEbsMainteList(index + 1)
            Me._htEbsMainteList(index + 1) = Me._htEbsMainteList(index)
            Me._htEbsMainteList(index) = fileName

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

#End Region

#Region " �v���C�x�[�g���\�b�h "

    '--------------------------------------------------------
    '���\�b�h���FSetFileList
    '�T    �v  �F��ʓ��͒l�擾����
    '��    ��  �F��ʓ��͒l�擾�������s��
    '��    ��  �F�Ȃ�
    '�� �� �l  �F��ʓ��͒l
    '--------------------------------------------------------
    Private Sub SetInitialData()

        Dim fileNames As String()
        Dim fileName As String
        Dim index As Integer

        '==============================
        '��eBS(����)��
        '==============================
        fileNames = Me._inputFile.eBS_Sale.Split(CommonConstant.STR_SLASH)
        For Each fileName In fileNames
            If Not fileName.Equals(String.Empty) Then
                index = Me.Lst_File_eBS_Sale.Items.Add(Path.GetFileName(fileName))
                Me._htEbsSaleList.Add(index, fileName)
            End If
        Next

        '==============================
        '��eBS(�ێ�)��
        '==============================
        fileNames = Me._inputFile.eBS_Mainte.Split(CommonConstant.STR_SLASH)
        For Each fileName In fileNames
            If Not fileName.Equals(String.Empty) Then
                index = Me.Lst_File_eBS_Mainte.Items.Add(Path.GetFileName(fileName))
                Me._htEbsMainteList.Add(index, fileName)
            End If
        Next

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FSetFileListData
    '�T    �v  �F��ʓ��͒l�擾����
    '��    ��  �F��ʓ��͒l�擾�������s��
    '��    ��  �F�Ȃ�
    '�� �� �l  �F��ʓ��͒l
    '--------------------------------------------------------
    Private Sub SetFileListData()

        Dim fileName As String
        Dim eBSSaleFileName As New StringBuilder
        Dim eBSMainteFileName As New StringBuilder
        Dim index As Integer

        '==============================
        '��eBS(����)��
        '==============================
        For index = 0 To Me._htEbsSaleList.Count - 1
            fileName = Me._htEbsSaleList(index).ToString()
            If eBSSaleFileName.Length > 0 Then
                eBSSaleFileName.Append(CommonConstant.STR_SLASH)
            End If
            eBSSaleFileName.Append(fileName)
        Next
        Me._inputFile.eBS_Sale = eBSSaleFileName.ToString()

        '==============================
        '��eBS(�ێ�)��
        '==============================
        For index = 0 To Me._htEbsMainteList.Count - 1
            fileName = Me._htEbsMainteList(index).ToString()
            If eBSMainteFileName.Length > 0 Then
                eBSMainteFileName.Append(CommonConstant.STR_SLASH)
            End If
            eBSMainteFileName.Append(fileName)
        Next
        Me._inputFile.eBS_Mainte = eBSMainteFileName.ToString()

    End Sub

    ''' <summary>
    ''' �T  �v�F�Q�ƃ{�^���̃t�@�C���I���_�C�A�����O�{�b�N�X�̏����ʒu���w�肷��B
    ''' ��  ���FConfig\�Y���t�H���_���f�t�H���g�ʒu
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetFileSeletctDialogInitialPath() As String

        Dim strCpNo As String = CommonVariable.CPNO.Trim.PadLeft(8, "0")
        Dim strContractNO As String = CommonVariable.CONTRACTNO.ToString().PadLeft(3, "0c")
        Dim strPath As String

        GetFileSeletctDialogInitialPath = ""

        strPath = CommonConstant.FOLDERNAME_CONFIG & "\" & strCpNo & "_" & strContractNO
        Return FileManager.GetLocalFolderPath(strPath)

    End Function

#End Region

End Class