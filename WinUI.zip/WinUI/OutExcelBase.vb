﻿Imports Microsoft.Office.Interop
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.OioBamaCommmon

Public Class OutExcelBase

#Region "構造体"

    ''' <summary>
    '''概  要：ｼｰﾄのﾚｲｱｳﾄ情報
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Public Structure LayoutInfo
        Dim SheetLayout As SheetLayoutInfo              ''シート全体のレイアウト
        Dim OutBlockLayout() As OutBlockLayoutInfo      ''ブロック単位のレイアウト設定
    End Structure

    ''' <summary>
    '''概  要：シート全体の設定
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Public Structure SheetLayoutInfo
        Dim isNextRow As Boolean                            ''前回の出力ﾃﾞｰﾀ後に出力するかどうか？ 
        Dim NextRow As Integer                              ''前回の出力の何行後に出力するか？
    End Structure

    ''' <summary>
    '''概  要：処理対象ブロック毎のﾚｲｱｳﾄを設定
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Public Structure OutBlockLayoutInfo

        ''ﾀｲﾄﾙ行の設定
        Dim isTitleRow As Boolean                           ''ﾀｲﾄﾙ行：ﾃﾝﾌﾟﾚｰﾄ行を使用するかどうか？
        Dim TitleRow As String                              ''ﾀｲﾄﾙ行：位置
        Dim TitlePasteStrIndex As Integer                   ''ﾀｲﾄﾙ行：貼付開始位置

        ''ﾃﾝﾌﾟﾚｰﾄ行の設定
        Dim isTmpRow As Boolean                             ''ﾃﾝﾌﾟﾚｰﾄ行：ﾃﾝﾌﾟﾚｰﾄ行を使用するかどうか？
        Dim TmplateRow As String                            ''ﾃﾝﾌﾟﾚｰﾄ行：位置
        Dim TmpPasteStrIndex As Integer                     ''ﾃﾝﾌﾟﾚｰﾄ行：貼付開始位置

        ''項目の出力位置の調整
        Dim IsFreeFormat As Boolean                         ''値貼付：連続したデータの貼り付け or セルの位置を指定して貼付
        Dim PasteStrIndex As Integer                        ''値貼付：出力開始位置
        Dim IsChgRefColumn As Boolean                       ''値貼付：出力対象ﾃﾞｰﾀと、出力列の位置関係を変更するかどうか？
        Dim SetChgRefColumn(,) As String                    ''値貼付：出力対象ﾃﾞｰﾀと、出力列の位置関係
        Dim PasteArea As String                             ''値貼付：貼付の範囲[A@Str:IT@End]
        Dim PasteStrClomunsIdx As Integer                   ''値貼付：貼付の開始列
        Dim PasteEndClomunsIdx As Integer                   ''値貼付：貼付の終了列

        ''                          以下、任意の書式設定
        ''------------------------------------------------------------------------------------
        ''列のﾚｲｱｳﾄｾｯﾄ
        Dim IsChgColumnLayOut As Boolean                    ''列毎にﾚｲｱｳﾄを設定変更するかどうか？
        Dim ColumnLayOut() As ColumnLayout                  ''列毎にﾚｲｱｳﾄｾｯﾄを保存

        ''行のﾚｲｱｳﾄｾｯﾄ
        Dim IsChgRowLayOut As Boolean                       ''行毎にﾚｲｱｳﾄを設定変更するかどうか？
        Dim RowLayOut() As RowLayout                        ''行毎にﾚｲｱｳﾄｾｯﾄを保存

        ''セルのﾚｲｱｳﾄｾｯﾄ
        Dim IsChgCellLayOut As Boolean                      ''セル毎にﾚｲｱｳﾄを設定変更するかどうか？
        Dim CellLayOut() As CellLayout                      ''セル毎にﾚｲｱｳﾄｾｯﾄを保存

    End Structure


    ''以下、設定できる書式情報
    ''列の書式
    Public Structure ColumnLayout
        Dim Font As Font                ''フォント
        Dim Interior As Interior        ''セルのInterior
        Dim Borders() As Border          ''罫線
        Dim Hidden As Boolean          ''表示/非表示
        Dim ColumnWidth As Integer      ''行の幅
    End Structure

    ''行の書式
    Public Structure RowLayout
        Dim IsOutPutRow As Boolean      ''書式の設定を出力範囲 or 行全体にするか
        Dim Font As Font                ''フォント
        Dim Interior As Interior        ''セルのInterior
        Dim Borders() As Border         ''罫線
        Dim Hidden As Boolean           ''表示/非表示
        Dim RowHeight As Integer        ''行の幅
        'Dim Group As Group              ''グループ
    End Structure

    ''セルの書式
    Public Structure CellLayout
        Dim Font As Font                ''フォント
        Dim Interior As Interior        ''セルのInterior
        Dim Borders() As Border         ''罫線
        Dim Hidden As Boolean           ''表示/非表示
        Dim ColumnWidth As Integer      ''列の幅
        Dim RowHeight As Integer        ''行の幅
    End Structure

    ''フォント
    Public Structure Font
        Dim Size As Integer             ''サイズ
        Dim Color As Integer            ''色(RGB指定)
        Dim ColorIndex As Integer       ''色(Index指定)
        Dim Bold As Boolean             ''太字/それ以外
        Dim FontStyle As String         ''フォントの種類
    End Structure

    ''Interior
    Public Structure Interior
        Dim Color As Integer            ''色(RGB指定)
        Dim ColorIndex As Integer       ''色(Index指定)
    End Structure

    ''罫線
    Public Structure Border
        Dim LineStyle As Integer        ''罫線の種類
        Dim Color As Integer            ''色(RGB指定)
        Dim ColorIndex As Integer       ''色(Index指定)
    End Structure

#End Region

#Region "プライベート変数"

    ''起動時の設定値：Application
    Private _AppDisplayAlerts As Boolean
    Private _AppEnableEvents As Boolean
    Private _AppScreenUpdateing As Boolean

    ''起動時の設定値：WorkBook
    Private _WorkBookCalculation As New ArrayList

    ''起動時の設定値：WorkSheet
    Private _WorkSheetAutoFilter As New ArrayList
    Private _WorkSheetProtectContents As New ArrayList

    ''出力のカレント行位置
    Dim _CurrentRow As Integer

#End Region

#Region "Protectメソッド"

#Region "Excelの基本動作"

    ''' <summary>
    ''' 概　要：Applicationの作成
    ''' 説　明：
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Protected Function CreateApp() As Excel.Application

        ''初期化
        Dim rtnValue As Excel.Application
        rtnValue = New Excel.Application

        ''Applicationの初期値を退避
        Me._AppDisplayAlerts = rtnValue.DisplayAlerts
        Me._AppEnableEvents = rtnValue.EnableEvents
        Me._AppScreenUpdateing = rtnValue.ScreenUpdating

        ''Applicationの設定
        rtnValue.DisplayAlerts = False
        rtnValue.EnableEvents = False
        rtnValue.ScreenUpdating = False

        ''戻り値
        Return rtnValue

    End Function


    ''' <summary>
    ''' 概　要：ApplicationのQuit
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Protected Sub QuitApp(ByRef xlApp As Excel.Application)

        Try
            ''Applicationの初期値を退避
            xlApp.DisplayAlerts = Me._AppDisplayAlerts
            xlApp.EnableEvents = Me._AppEnableEvents
            xlApp.ScreenUpdating = Me._AppScreenUpdateing

        Catch ex As Exception
            Throw ex

        Finally
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub


    ''' <summary>
    ''' 概　要：WorkBookのOpen
    ''' 説　明：
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Protected Function OpenWorkBook(ByRef xlApp As Excel.Application, _
                                    ByVal path As String) As Excel.Workbook

        ''初期化
        Dim rtnValue As Excel.Workbook
        OpenWorkBook = rtnValue
        Try
            ''BookOpen
            rtnValue = xlApp.Workbooks.Open(path)

            ''Bookの初期値を退避
            Dim setValue(1) As String
            setValue(0) = rtnValue.Name
            setValue(1) = xlApp.Calculation
            Me._WorkBookCalculation.Add(setValue)

            ''BookOpen時の初期設定
            xlApp.Calculation = Excel.XlCalculation.xlCalculationManual

            Return rtnValue

        Catch ex As Exception
            Throw ex

        End Try

    End Function

    ''' <summary>
    ''' 概　要：WorkBookのClose
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Protected Sub CloseWorkBook(ByRef xlApp As Excel.Application, _
                                            ByRef xlWorkBook As Excel.Workbook)

        ''初期化
        Try
            If IsNothing(xlWorkBook) = False Then
                ''Excelの自動計算を元に戻す
                Dim setValue(1) As String
                For Each setValue In Me._WorkBookCalculation
                    If setValue(0) = xlWorkBook.Name Then
                        xlApp.Calculation = CInt(setValue(1))
                    End If
                Next
            End If

        Catch ex As Exception
            Throw ex

        Finally
            ''WorkBookのClose
            If IsNothing(xlWorkBook) = False Then
                xlWorkBook.Close()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlWorkBook, ExcelObjRelease.OBJECT_NOTHING)

        End Try
    End Sub

    ''' <summary>
    ''' 概　要：WorkBookのSave
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Protected Sub SaveWorkBook(ByRef xlApp As Excel.Application, _
                               ByRef xlWorkBook As Excel.Workbook)

        Try
            ''自動計算の設定を元に戻してから保存する。
            Dim setValue(1) As String
            For Each setValue In Me._WorkBookCalculation
                If setValue(0) = xlWorkBook.Name Then
                    xlApp.Calculation = CInt(setValue(1))
                End If
            Next

            ''Bookの保存            
            Call xlWorkBook.Save()

        Catch ex As Exception
            Throw ex

        End Try

    End Sub


    ''' <summary>
    ''' 概　要：WorkSheetの取得
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Protected Function SetWorkSheet(ByRef xlWorkBook As Excel.Workbook, _
                                    ByVal sheetNM As String) As Excel.Worksheet

        ''初期化
        Dim isSheetSearch As Boolean = False
        Dim rtnValue As Excel.Worksheet
        SetWorkSheet = rtnValue

        Dim xlFilter As Excel.AutoFilter
        Dim xlCell As Excel.Range
        Try
            ''WorkSheetを検索
            For i As Integer = 1 To xlWorkBook.Worksheets.Count
                rtnValue = xlWorkBook.Worksheets(i)
                If rtnValue.Name = sheetNM Then
                    isSheetSearch = True
                    Exit For
                End If
            Next

            ''WorkSheetの存在判定
            Dim setFilter(1) As String
            Dim setProFilter(1) As String
            If isSheetSearch = True Then

                ''シートの保護を判定し、保護なら解除する。
                setProFilter(0) = rtnValue.Name
                setProFilter(1) = rtnValue.ProtectContents
                Me._WorkSheetProtectContents.Add(setProFilter)
                ''ｵｰﾄﾌｨﾙﾀを解除し、設定値を退避する。
                If rtnValue.AutoFilterMode = True Then
                    xlFilter = rtnValue.AutoFilter
                    xlCell = xlFilter.Range
                    setFilter(0) = rtnValue.Name
                    setFilter(1) = xlCell.Address
                    Call _WorkSheetAutoFilter.Add(setFilter)
                End If

                rtnValue.AutoFilterMode = False
                Return rtnValue
            Else
                ''WorkSheetが見つからなければ、Nothingを返す。
                ExcelObjRelease.ReleaseExcelObj(rtnValue, ExcelObjRelease.OBJECT_NOTHING)
                Return Nothing
            End If

        Catch ex As Exception
            ExcelObjRelease.ReleaseExcelObj(rtnValue, ExcelObjRelease.OBJECT_NOTHING)
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlFilter, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Function


    ''' <summary>
    ''' 概　要：WorkSheetのClose
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Protected Sub CloseWorkSheet(ByRef xlWorkSheet As Excel.Worksheet)

        Dim xlCell As Excel.Range
        Try
            If IsNothing(xlWorkSheet) = False Then

                ''ｵｰﾄﾌｨﾙﾀを戻す
                For Each tmpValue() As String In _WorkSheetAutoFilter
                    If xlWorkSheet.Name = tmpValue(0) Then
                        Call xlWorkSheet.Activate()
                        xlCell = xlWorkSheet.Range(tmpValue(1))
                        xlCell.AutoFilter(Field:=1)
                        Exit For
                    End If
                Next
            End If

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlWorkSheet, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Sub

#End Region

#Region "Excelファイルの読込"

    ''' <summary>
    ''' 概　要：個別PSのExcel情報をDataTableへセット
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Protected Function GetXlsPSData(ByRef xlApp As Excel.Application, _
                                    ByVal PSPath As String) As DataTable
        ''初期化
        Dim rtnTable As New DataTable
        rtnTable = Me.CretatePSTable
        GetXlsPSData = rtnTable

        Dim OioSheet As String = ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET
        Dim PaymentStrRow As Integer = ExcelWrite.EXCEL_COST_PAYMENT_OUTROW
        Const PaymentEndRow As Integer = 65536

        Dim xlPSBook As Excel.Workbook
        Dim xlOioSheet As Excel.Worksheet
        Dim xlCell As Excel.Range

        Try

            ''Book Open/Sheet Set 
            xlPSBook = Me.OpenWorkBook(xlApp, PSPath)
            xlOioSheet = Me.SetWorkSheet(xlPSBook, OioSheet)

            ''Eof行の取得
            Dim Eof As Integer
            For Eof = PaymentStrRow To PaymentEndRow
                xlCell = xlOioSheet.Cells(Eof, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)
                If ExcelWrite.changeDBNullToString(xlCell.Value) = "" Then
                    Eof = Eof - 1
                    Exit For
                End If
            Next
            If Eof < PaymentStrRow Then
                Exit Function
            End If

            ''セルの値を取得
            Dim cellValue(,) As Object
            xlCell = xlOioSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG) & PaymentStrRow & _
                                      ":" & _
                                      ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH12) & Eof)
            cellValue = xlCell.Value

            ''セルの値をDataTableへセット
            Dim insRow As DataRow
            For rowIdx As Integer = 1 To UBound(cellValue, 1)
                insRow = rtnTable.NewRow
                Call SetPSInsertRow(rowIdx, insRow, cellValue)
                Call rtnTable.Rows.Add(insRow)
            Next
            Return rtnTable

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            Me.CloseWorkSheet(xlOioSheet)
            Me.CloseWorkBook(xlApp, xlPSBook)
            GC.Collect()
        End Try

    End Function

    ''' <summary>
    ''' 概　要：個別DetailのExcel情報をDataTableへセット
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Protected Function GetXlsDetailData(ByRef xlApp As Excel.Application, _
                                        ByVal DetailPath As String) As DataTable
        ''初期化
        Dim rtnTable As New DataTable
        rtnTable = Me.CretateDetailTable
        GetXlsDetailData = rtnTable

        Dim DetailSheet As String = ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET
        Dim PaymentStrRow As Integer = ExcelWrite.EXCEL_COST_DETAIL_OUTROW

        Const PaymentEndRow As Integer = 65536

        Dim xlDetailBook As Excel.Workbook
        Dim xlDetailSheet As Excel.Worksheet
        Dim xlCell As Excel.Range
        Try

            ''Book Open/Sheet Set 
            xlDetailBook = Me.OpenWorkBook(xlApp, DetailPath)
            xlDetailSheet = Me.SetWorkSheet(xlDetailBook, DetailSheet)

            ''Eof行の取得
            Dim tmpContract As String
            Dim fileNM As String
            Dim fileNMSuffix As String
            Dim fileInSuffix As String

            Dim Eof As Integer
            For Eof = PaymentStrRow To PaymentEndRow
                ''契約順番
                xlCell = xlDetailSheet.Cells(Eof, ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT)
                tmpContract = ExcelWrite.changeDBNullToString(xlCell.Value)

                ''ファイル名
                xlCell = xlDetailSheet.Cells(Eof, ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME)
                fileNM = ExcelWrite.changeDBNullToString(xlCell.Value)

                ''ファイル名Suffix
                xlCell = xlDetailSheet.Cells(Eof, ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX)
                fileNMSuffix = ExcelWrite.changeDBNullToString(xlCell.Value)

                ''ファイル内Suffix
                xlCell = xlDetailSheet.Cells(Eof, ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR)
                fileInSuffix = ExcelWrite.changeDBNullToString(xlCell.Value)

                If tmpContract = "" And _
                   fileNM = "" And _
                   fileNMSuffix = "" And _
                   fileInSuffix = "" Then
                    Eof = Eof - 1
                    Exit For
                End If
            Next
            If Eof <= PaymentStrRow Then
                Exit Function
            End If

            ''セルの値を取得
            Dim cellValue(,) As Object
            xlCell = xlDetailSheet.Range(ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineDetailColumn.UPDATE_FLAG) & PaymentStrRow & _
                                         ":" & _
                                         ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineDetailColumn.COST_INPUT_DATE) & Eof)
            cellValue = xlCell.Value

            ''セルの値をDataTableへセット
            Dim insRow As DataRow
            For rowIdx As Integer = 1 To UBound(cellValue, 1)
                insRow = rtnTable.NewRow
                Call SetDetailInsertRow(rowIdx, insRow, cellValue)
                Call rtnTable.Rows.Add(insRow)
            Next
            Return rtnTable

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlDetailSheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlDetailBook) = False Then
                xlDetailBook.Close()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlDetailBook, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Function

#End Region

#Region "Excelファイルの書込"

    ''' <summary>
    '''概  要：DataRowの値をシートに書き込む
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Protected Sub OutRowDataToSheet(ByRef xlOutSheet As Excel.Worksheet, _
                                    ByRef rows As Array, _
                                    ByRef SheetLayout As LayoutInfo)


        Const OutMaxLine As Integer = 1000              ''出力Max行        
        Try
            ''出力するBlock数ﾙｰﾌﾟ
            Dim outIdx As Integer
            For outIdx = 0 To UBound(SheetLayout.OutBlockLayout)

                ''カレント行のセット
                If SheetLayout.SheetLayout.isNextRow = True Then
                    Me._CurrentRow = Me._CurrentRow + SheetLayout.SheetLayout.NextRow
                End If

                ''タイトル行をコピペ
                Call Me.CopyTitleRow(outIdx, xlOutSheet, rows(outIdx), OutMaxLine, SheetLayout)

                ''ﾃﾝﾌﾟﾚｰﾄ行をコピペ
                Call Me.CopyTmpRow(outIdx, xlOutSheet, rows(outIdx), OutMaxLine, SheetLayout)

                ''値を貼り付け
                Call Me.SetCellValue(outIdx, xlOutSheet, rows(outIdx), OutMaxLine, SheetLayout)

            Next

        Catch ex As Exception
            Throw ex

        End Try
    End Sub

    ''' <summary>
    '''概  要：デフォルトの書式設定をセット
    '''説  明：※OioSheetをｺﾋﾟｰ時の設定値をｾｯﾄ
    ''' </summary>
    ''' <remarks></remarks>
    Protected Overridable Function GetDefaultBlockLayout(ByVal Idx As Integer) As OutBlockLayoutInfo()

        ''初期化
        Dim rtnValue(Idx) As OutBlockLayoutInfo
        GetDefaultBlockLayout = rtnValue

        ''件数分、ループする。
        For i As Integer = 0 To Idx

            rtnValue(Idx).TmplateRow = "2"
            rtnValue(Idx).TmpPasteStrIndex = 6
            rtnValue(Idx).PasteStrIndex = 6
            rtnValue(Idx).IsChgRefColumn = False
            rtnValue(Idx).SetChgRefColumn = Nothing

            ''任意の書式設定
            rtnValue(Idx).PasteArea = "A@Str:IT@End"
            rtnValue(Idx).PasteStrClomunsIdx = ExcelWrite.ChgExcelRowCharToNumber("A")
            rtnValue(Idx).PasteEndClomunsIdx = ExcelWrite.ChgExcelRowCharToNumber("IT")
            rtnValue(Idx).IsChgColumnLayOut = False
            rtnValue(Idx).ColumnLayOut = Nothing
            rtnValue(Idx).IsChgRowLayOut = False
            rtnValue(Idx).RowLayOut = Nothing
            rtnValue(Idx).IsChgCellLayOut = False
            rtnValue(Idx).CellLayOut = Nothing

        Next
        Return rtnValue

    End Function


    ''' <summary>
    '''概  要：セルの書式をセットする。
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Sub SetCellLayout(ByVal outIdx As Integer, _
                      ByRef xlOutSheet As Excel.Worksheet, _
                      ByVal Idx As Integer, _
                      ByRef rows() As DataRow, _
                      ByRef SheetLayout As LayoutInfo)

        ''処理対象外なら、処理終了
        If SheetLayout.OutBlockLayout(outIdx).IsChgCellLayOut = False Then
            Exit Sub
        End If

        Dim xlCell As Excel.Range
        Try
            With SheetLayout.OutBlockLayout(outIdx)

                ''対象列分ﾙｰﾌﾟを回して、対象のセルを検索する。
                Dim layoutIdx As Integer
                If .isTmpRow = True Then
                    For idxD As Integer = .PasteStrClomunsIdx To _
                                          .PasteEndClomunsIdx

                        ''セルの書式変更対象かどうか判定
                        If isCellLayoutChang(xlOutSheet.Name, layoutIdx, Idx, idxD, rows, SheetLayout) = True Then
                            xlCell = xlOutSheet.Cells(Idx + .TmpPasteStrIndex, idxD)
                            If IsNothing(.CellLayOut) = False Then
                                Call SetInterior(xlCell, .CellLayOut(layoutIdx).Interior)
                            End If
                        End If
                    Next
                End If

            End With
        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try
    End Sub

    Protected Sub SetInterior(ByRef xlCell As Excel.Range, _
                              ByRef Interior As Interior)

        Dim xlInterior As Excel.Interior
        Try
            ''背景色のセット
            xlInterior = xlCell.Interior
            xlInterior.Color = Interior.Color

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlInterior, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub
#End Region

#End Region

#Region "Overridableメソッド"

#Region "Excelの基本動作"

#End Region

#Region "Excelファイルの読込み"

    ''' <summary>
    ''' 概　要：ExcelのPaymentﾃﾞｰﾀ取得用Tableを定義する。
    ''' 説　明：※GetXlsPSDataにて使用する。
    ''            列を増やしたい場合、継承元で追加。
    ''' </summary>
    ''' <remarks></remarks>
    Protected Overridable Function CretatePSTable() As DataTable

        ''初期化
        Dim rtnTable As New DataTable

        ''列を作成
        For i As Integer = ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG To _
                           ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH12

            Call rtnTable.Columns.Add("CellNM" & i, Type.GetType("System.String"))
        Next

        ''戻り値
        Return rtnTable

    End Function


    ''' <summary>
    ''' 概　要：ExcelのPaymentﾃﾞｰﾀの1行分の値をセットする。
    ''' 説　明：※GetXlsPSDataにて使用する。
    ''            列を増やしたい場合、継承元で追加。
    ''' </summary>
    ''' <remarks></remarks>
    Protected Overridable Sub SetPSInsertRow(ByVal rowIdx As Integer, _
                                             ByRef insRow As DataRow, _
                                             ByRef cellValue(,) As Object)

        ''Cellの値をセットする
        For i As Integer = ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG To _
                           ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH12
            insRow.Item("CellNM" & i) = ExcelWrite.changeDBNullToString(cellValue(rowIdx, i))
        Next

    End Sub


    ''' <summary>
    ''' 概　要：Excelの詳細ﾃﾞｰﾀ取得用Tableを定義する。
    ''' 説　明：※GetXlsDetailDataにて使用する。
    ''            列を増やしたい場合、継承元で追加。
    ''' </summary>
    ''' <remarks></remarks>
    Protected Overridable Function CretateDetailTable() As DataTable

        ''初期化
        Dim rtnTable As New DataTable

        ''列を作成
        For i As Integer = ExcelWrite.ExcelPaymentLineDetailColumn.UPDATE_FLAG To _
                           ExcelWrite.ExcelPaymentLineDetailColumn.COST_INPUT_DATE

            Call rtnTable.Columns.Add("CellNM" & i, Type.GetType("System.String"))
        Next

        ''戻り値
        Return rtnTable

    End Function

    ''' <summary>
    ''' 概　要：ExcelのDetailﾃﾞｰﾀの1行分の値をセットする。
    ''' 説　明：※GetXlsDetailDataにて使用する。
    ''            列を増やしたい場合、継承元で追加。
    ''' </summary>
    ''' <remarks></remarks>
    Protected Overridable Sub SetDetailInsertRow(ByVal rowIdx As Integer, _
                                                 ByRef insRow As DataRow, _
                                                 ByRef cellValue(,) As Object)

        ''Cellの値をセットする
        For i As Integer = ExcelWrite.ExcelPaymentLineDetailColumn.UPDATE_FLAG To _
                           ExcelWrite.ExcelPaymentLineDetailColumn.COST_INPUT_DATE
            insRow.Item("CellNM" & i) = ExcelWrite.changeDBNullToString(cellValue(rowIdx, i))
        Next

    End Sub


#End Region

#Region "Excelファイルの書込"

    ''' <summary>
    '''概  要：ﾃﾝﾌﾟﾚｰﾄ行をｺﾋﾟﾍﾟする
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Protected Overridable Sub CopyTitleRow(ByVal outIdx As Integer, _
                                           ByRef xlOutSheet As Excel.Worksheet, _
                                           ByRef rows() As DataRow, _
                                           ByVal OutMaxLine As Integer, _
                                           ByRef SheetLayout As LayoutInfo)


        ''ﾀｲﾄﾙ作成対象か判定
        If SheetLayout.OutBlockLayout(outIdx).isTitleRow = False Then
            Exit Sub
        End If

        ''連番出力の場合、前回の出力の後にﾀｲﾄﾙ行を張り付ける。
        If SheetLayout.SheetLayout.isNextRow = True And _
           outIdx <> 0 Then
            SheetLayout.OutBlockLayout(outIdx).TitlePasteStrIndex = Me._CurrentRow
        End If

        Dim isHidden As Boolean                 ''初期値：ﾃﾝﾌﾟﾚｰﾄ行が非表示かどうか
        Dim copyRow As Excel.Range              ''ｺﾋﾟｰ対象行
        Dim pasteRow As Excel.Range             ''貼付対象行
        Try
            ''ﾀｲﾄﾙ行Copy
            copyRow = xlOutSheet.Rows(SheetLayout.OutBlockLayout(outIdx).TitleRow)

            ''ﾀｲﾄﾙ行表示
            If copyRow.Hidden = True Then
                isHidden = True
                copyRow.Hidden = False
            Else
                isHidden = False
            End If
            Call copyRow.Copy()

            ''貼付範囲を計算して、貼付
            Dim pasteArea As String             ''貼付範囲
            Dim pasteStr As Integer             ''貼付範囲：開始位置             
            Dim pasteEnd As Integer             ''貼付範囲：終了位置             
            Dim pasteCount As Integer           ''貼付範囲：開始⇒終了間の行数             
            Dim tmpPasteCount() As String

            ''"8:10"の連番で範囲が指定されている場合、行数を取得
            tmpPasteCount = Split(SheetLayout.OutBlockLayout(outIdx).TitleRow, ":")
            If tmpPasteCount.Length <> 0 Then
                pasteCount = CInt(tmpPasteCount(1)) - CInt(tmpPasteCount(0))
            Else
                pasteCount = 0
            End If

            ''貼り付け範囲取得
            pasteStr = SheetLayout.OutBlockLayout(outIdx).TitlePasteStrIndex
            pasteEnd = pasteStr + pasteCount
            pasteArea = "@Str:@End".Replace("@Str", pasteStr) _
                                   .Replace("@End", pasteEnd)

            ''カレント行更新
            Me._CurrentRow = pasteEnd + 1

            ''値貼り付け
            pasteRow = xlOutSheet.Range(pasteArea)
            Call pasteRow.PasteSpecial()

            ''タイトル行を非表示にする
            If isHidden = True Then
                copyRow.Hidden = True
            End If

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(copyRow, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(pasteRow, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    '''概  要：ﾃﾝﾌﾟﾚｰﾄ行をｺﾋﾟﾍﾟする
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Protected Overridable Sub CopyTmpRow(ByVal outIdx As Integer, _
                                         ByRef xlOutSheet As Excel.Worksheet, _
                                         ByRef rows() As DataRow, _
                                         ByVal OutMaxLine As Integer, _
                                         ByRef SheetLayout As LayoutInfo)


        ''ﾃﾝﾌﾟﾚ-ト作成対象か判定
        If SheetLayout.OutBlockLayout(outIdx).isTmpRow = False Then
            Exit Sub
        End If

        ''連番出力の場合、前回の出力の後にﾀｲﾄﾙ行を張り付ける。
        If SheetLayout.SheetLayout.isNextRow = True And _
           outIdx <> 0 Then
            SheetLayout.OutBlockLayout(outIdx).TmpPasteStrIndex = Me._CurrentRow
        End If


        Dim isHidden As Boolean                 ''初期値：ﾃﾝﾌﾟﾚｰﾄ行が非表示かどうか
        Dim copyRow As Excel.Range              ''ｺﾋﾟｰ対象行
        Dim pasteRow As Excel.Range             ''貼付対象行
        Try
            ''ﾃﾝﾌﾟﾚｰﾄ行Copy
            copyRow = xlOutSheet.Rows(SheetLayout.OutBlockLayout(outIdx).TmplateRow)

            ''ﾃﾝﾌﾟﾚｰﾄ行表示
            If copyRow.Hidden = True Then
                isHidden = True
                copyRow.Hidden = False
            Else
                isHidden = False
            End If

            Call copyRow.Copy()

            ''貼付範囲を計算して、貼付
            Dim pasteCount As Integer           ''コピー回数
            Dim pasteArea As String             ''貼付範囲
            Dim pasteStr As Integer             ''貼付範囲：開始位置             
            Dim pasteEnd As Integer             ''貼付範囲：終了位置             
            pasteCount = System.Math.Truncate((rows.Length - 1) / 1000) + 1
            For Idx As Integer = 1 To pasteCount

                ''1回分の貼付範囲を取得
                pasteStr = SheetLayout.OutBlockLayout(outIdx).TmpPasteStrIndex + ((Idx - 1) * OutMaxLine)
                If Idx <> pasteCount Then
                    pasteEnd = SheetLayout.OutBlockLayout(outIdx).TmpPasteStrIndex + (Idx * OutMaxLine) - 1
                Else
                    pasteEnd = SheetLayout.OutBlockLayout(outIdx).TmpPasteStrIndex + rows.Length - 1
                End If
                pasteArea = "@Str:@End".Replace("@Str", pasteStr) _
                                       .Replace("@End", pasteEnd)

                ''ﾃﾞｰﾀ貼付
                pasteRow = xlOutSheet.Range(pasteArea)
                Call pasteRow.PasteSpecial()
            Next

            ''ﾃﾝﾌﾟﾚ行を非表示にする
            If isHidden = True Then
                copyRow.Hidden = True
            End If
        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(copyRow, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(pasteRow, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub


    ''' <summary>
    '''概  要：値を張り付ける
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Protected Overridable Sub SetCellValue(ByVal outIdx As Integer, _
                                           ByRef xlOutSheet As Excel.Worksheet, _
                                           ByRef rows() As DataRow, _
                                           ByVal OutMaxLine As Integer, _
                                           ByRef SheetLayout As LayoutInfo)

        Dim xlOutCell As Excel.Range

        Try
            ''連番出力の場合、前回の出力の後にﾀｲﾄﾙ行を張り付ける。
            If SheetLayout.SheetLayout.isNextRow = True And _
               outIdx <> 0 Then
                SheetLayout.OutBlockLayout(outIdx).PasteStrIndex = Me._CurrentRow
            End If

            If SheetLayout.OutBlockLayout(outIdx).IsFreeFormat = False Then

                ''レイアウトのセット
                For idx As Integer = 0 To rows.Length - 1
                    ''セルのレイアウトセット        
                    Me.SetCellLayout(outIdx, xlOutSheet, idx, rows, SheetLayout)

                Next

                ''Freeフォーマット以外の場合、連続した行に値を張り付ける。
                ''貼付範囲を計算して、貼付
                Dim pasteCount As Integer           ''コピー回数
                Dim pasteArea As String             ''貼付範囲
                Dim pasteStr As Integer             ''貼付範囲：開始位置             
                Dim pasteEnd As Integer             ''貼付範囲：終了位置             
                Dim pasetValue(,) As Object
                pasteCount = System.Math.Truncate((rows.Length - 1) / 1000) + 1
                For Idx As Integer = 1 To pasteCount

                    ''1回分の貼付範囲を取得
                    pasteStr = SheetLayout.OutBlockLayout(outIdx).PasteStrIndex + ((Idx - 1) * OutMaxLine)
                    If Idx <> pasteCount Then
                        pasteEnd = SheetLayout.OutBlockLayout(outIdx).PasteStrIndex + (Idx * OutMaxLine) - 1
                    Else
                        pasteEnd = SheetLayout.OutBlockLayout(outIdx).PasteStrIndex + rows.Length - 1
                    End If
                    pasteArea = SheetLayout.OutBlockLayout(outIdx).PasteArea.Replace("@Str", pasteStr) _
                                                                            .Replace("@End", pasteEnd)

                    ''カレント行の更新
                    Me._CurrentRow = pasteEnd + 1

                    ''ﾃﾞｰﾀ貼付
                    pasetValue = GetOutPasteValue(outIdx, rows, 0, (pasteEnd - pasteStr), SheetLayout, Idx)
                    xlOutCell = xlOutSheet.Range(pasteArea)
                    xlOutCell.Formula = pasetValue

                    ''行の高さを合わせる
                    xlOutCell = xlOutSheet.Rows(pasteStr & ":" & pasteEnd)
                    Call xlOutCell.AutoFit()
                Next
            Else

                ''Freeフォーマットの場合、アドレスに直接値をセット
                For idx As Integer = 0 To UBound(SheetLayout.OutBlockLayout(outIdx).SetChgRefColumn, 1)
                    xlOutCell = xlOutSheet.Range(SheetLayout.OutBlockLayout(outIdx).SetChgRefColumn(idx, 0))
                    xlOutCell.Formula = rows(0).Item(SheetLayout.OutBlockLayout(outIdx).SetChgRefColumn(idx, 1))
                Next
            End If

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlOutCell, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub


    ''' <summary>
    '''概  要：値を張り付け用の配列作成
    '''説  明：
    ''' </summary>
    ''' <remarks></remarks>
    Protected Overridable Function GetOutPasteValue(ByVal outIdx As Integer, _
                                                    ByRef rows() As DataRow, _
                                                    ByRef pasteStr As Integer, _
                                                    ByRef pasteEnd As Integer, _
                                                    ByRef SheetLayout As LayoutInfo, _
                                                    ByRef pastecount As Integer) As Object(,)

        Try
            ''初期化
            Dim rtnValue(pasteEnd, SheetLayout.OutBlockLayout(outIdx).PasteEndClomunsIdx) As Object

            Dim addrow As Integer
            If pastecount <> 1 Then
                addrow = (pastecount - 1) * 1000
            Else
                addrow = 0
            End If

            ''貼付対象ﾃﾞｰﾀを配列に割り当てる。
            If SheetLayout.OutBlockLayout(outIdx).IsChgRefColumn = False Then
                ''Layoutで特にItemNM と貼付列の対応付けがされていない
                For Idx As Integer = pasteStr To pasteEnd
                    For IdxD As Integer = 0 To SheetLayout.OutBlockLayout(outIdx).PasteEndClomunsIdx - SheetLayout.OutBlockLayout(outIdx).PasteStrClomunsIdx
                        rtnValue(Idx, IdxD - 1) = rows(Idx).Item(IdxD - 1)
                    Next
                Next
            Else
                ''Layoutで特にItemNM と貼付列の対応付けが有り
                For Idx As Integer = pasteStr To pasteEnd
                    For IdxD As Integer = 0 To SheetLayout.OutBlockLayout(outIdx).PasteEndClomunsIdx - SheetLayout.OutBlockLayout(0).PasteStrClomunsIdx

                        ''貼付列の対応付を検索する。
                        Dim tmpSetRefOutColum As Array
                        For IdxS As Integer = 0 To UBound(SheetLayout.OutBlockLayout(outIdx).SetChgRefColumn, 1)
                            tmpSetRefOutColum = SheetLayout.OutBlockLayout(outIdx).SetChgRefColumn
                            If ExcelWrite.ChgExcelRowCharToNumber(tmpSetRefOutColum(IdxS, 0)) - SheetLayout.OutBlockLayout(outIdx).PasteStrClomunsIdx = IdxD Then
                                rtnValue(Idx, IdxD) = rows(Idx + addrow).Item(tmpSetRefOutColum(IdxS, 1))
                            End If
                        Next

                    Next
                Next
            End If
            Return rtnValue

        Catch ex As Exception
            Throw ex

        End Try

    End Function


    ''' <summary>
    '''概  要：対象のセルの書式が変更対象か判定する。
    '''説  明：※条件値は、継承元でｾｯﾄする。
    ''' </summary>
    ''' <remarks></remarks>
    Protected Overridable Function isCellLayoutChang(ByVal sheetNM As String, _
                                                     ByRef layoutIdx As Integer, _
                                                     ByVal Idx As Integer,
                                                     ByVal IdxD As Integer,
                                                     ByRef rows() As DataRow,
                                                     ByRef SheetLayout As LayoutInfo) As Boolean
        ''初期化
        isCellLayoutChang = False
        layoutIdx = 0       ''適用するレイアウト

    End Function


#End Region

#End Region

End Class
