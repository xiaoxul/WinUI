﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frm_AsrAll
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.dvgCpno = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.colCpno = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colContractName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDb = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOutputState = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colStdSet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colStdReport = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVerupExcel = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVerupPsCsv = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2colVerupPsPriceCsv = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVerupPsdCsv = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMngAct = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMngDelivery = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colContractStart = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colContractEnd = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExcelStart = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPaymentPeriod = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rdoBoth = New System.Windows.Forms.RadioButton()
        Me.rdoVersion = New System.Windows.Forms.RadioButton()
        Me.rdoStandard = New System.Windows.Forms.RadioButton()
        Me.rdoAct = New System.Windows.Forms.RadioButton()
        Me.rdoDeliv = New System.Windows.Forms.RadioButton()
        Me.tabFile = New System.Windows.Forms.TabControl()
        Me.tabImport = New System.Windows.Forms.TabPage()
        Me.btnImportManageFileOutputExplorer = New MUSE.UserControl.UCnt_Btn0001()
        Me.bntMdbToExcel = New MUSE.UserControl.UCnt_Btn0001()
        Me.tabExport = New System.Windows.Forms.TabPage()
        Me.btnExportManageFileInputExplorer = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnExcelToMdb = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnExportPsExcelOutputExplorer = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnExportPsCsvOutputExplorer = New MUSE.UserControl.UCnt_Btn0001()
        Me.tabStandard = New System.Windows.Forms.TabPage()
        Me.btnCsvToMdb = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnSubmittedDataAll = New MUSE.UserControl.UCnt_Btn0001()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.btnStdSetMakeOutputExplorer = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnStdSetMake = New MUSE.UserControl.UCnt_Btn0001()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.btnStdOutOutputExplorer = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnStdOut = New MUSE.UserControl.UCnt_Btn0001()
        Me.tabVersion = New System.Windows.Forms.TabPage()
        Me.cmdSaveFormat = New MUSE.UserControl.UCnt_Btn0001()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.btnVerUpExportExplore = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnVerUpExcelToMdb = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnVerUpCsvToMdb = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnVerUpExcelExplorer = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnVersionUp = New MUSE.UserControl.UCnt_Btn0001()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.ttButon = New System.Windows.Forms.ToolTip(Me.components)
        Me.cboWorkDate = New System.Windows.Forms.ComboBox()
        Me.grpAct = New System.Windows.Forms.GroupBox()
        Me.cbSheet5 = New System.Windows.Forms.CheckBox()
        Me.cbSheet3 = New System.Windows.Forms.CheckBox()
        Me.cbSheet4 = New System.Windows.Forms.CheckBox()
        Me.cbSheet2 = New System.Windows.Forms.CheckBox()
        Me.cbSheet1 = New System.Windows.Forms.CheckBox()
        Me.btnLogExplorer = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnRefresh = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnLogout = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnCpnoChkOff = New MUSE.UserControl.UCnt_Btn0001()
        Me.upalTitle = New MUSE.UserControl.UCnt_Pal0001()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.dvgCpno, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.tabFile.SuspendLayout()
        Me.tabImport.SuspendLayout()
        Me.tabExport.SuspendLayout()
        Me.tabStandard.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.tabVersion.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.grpAct.SuspendLayout()
        Me.SuspendLayout()
        '
        'dvgCpno
        '
        Me.dvgCpno.AllowUserToAddRows = False
        Me.dvgCpno.AllowUserToResizeRows = False
        Me.dvgCpno.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dvgCpno.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.colCpno, Me.colContractName, Me.colDb, Me.colOutputState, Me.colStdSet, Me.colStdReport, Me.colVerupExcel, Me.colVerupPsCsv, Me.Column2colVerupPsPriceCsv, Me.colVerupPsdCsv, Me.colMngAct, Me.colMngDelivery, Me.colContractStart, Me.colContractEnd, Me.colExcelStart, Me.colPaymentPeriod})
        Me.dvgCpno.Location = New System.Drawing.Point(12, 208)
        Me.dvgCpno.MultiSelect = False
        Me.dvgCpno.Name = "dvgCpno"
        Me.dvgCpno.RowHeadersVisible = False
        Me.dvgCpno.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.dvgCpno.RowTemplate.Height = 21
        Me.dvgCpno.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dvgCpno.Size = New System.Drawing.Size(709, 192)
        Me.dvgCpno.TabIndex = 7
        '
        'Column1
        '
        Me.Column1.HeaderText = ""
        Me.Column1.Name = "Column1"
        Me.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Column1.Width = 20
        '
        'colCpno
        '
        Me.colCpno.HeaderText = "CPNO"
        Me.colCpno.Name = "colCpno"
        Me.colCpno.ReadOnly = True
        Me.colCpno.Width = 50
        '
        'colContractName
        '
        Me.colContractName.HeaderText = "お客様名"
        Me.colContractName.Name = "colContractName"
        Me.colContractName.ReadOnly = True
        '
        'colDb
        '
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.colDb.DefaultCellStyle = DataGridViewCellStyle1
        Me.colDb.HeaderText = "DB"
        Me.colDb.Name = "colDb"
        Me.colDb.ReadOnly = True
        Me.colDb.Width = 120
        '
        'colOutputState
        '
        Me.colOutputState.HeaderText = "出力状況"
        Me.colOutputState.Name = "colOutputState"
        Me.colOutputState.ReadOnly = True
        Me.colOutputState.Width = 520
        '
        'colStdSet
        '
        Me.colStdSet.HeaderText = "標準帳票設定"
        Me.colStdSet.Name = "colStdSet"
        Me.colStdSet.ReadOnly = True
        Me.colStdSet.Width = 200
        '
        'colStdReport
        '
        Me.colStdReport.HeaderText = "標準帳票出力(EXCEL)"
        Me.colStdReport.Name = "colStdReport"
        Me.colStdReport.ReadOnly = True
        Me.colStdReport.Width = 200
        '
        'colVerupExcel
        '
        Me.colVerupExcel.HeaderText = "ﾊﾞｰｼﾞｮﾝｱｯﾌﾟ(EXCEL)"
        Me.colVerupExcel.Name = "colVerupExcel"
        Me.colVerupExcel.ReadOnly = True
        Me.colVerupExcel.Width = 200
        '
        'colVerupPsCsv
        '
        Me.colVerupPsCsv.HeaderText = "ｴｸｽﾎﾟｰﾄV_PLINE(CSV)"
        Me.colVerupPsCsv.Name = "colVerupPsCsv"
        Me.colVerupPsCsv.ReadOnly = True
        Me.colVerupPsCsv.Width = 200
        '
        'Column2colVerupPsPriceCsv
        '
        Me.Column2colVerupPsPriceCsv.HeaderText = "ｴｸｽﾎﾟｰﾄT_PPRICE(CSV)"
        Me.Column2colVerupPsPriceCsv.Name = "Column2colVerupPsPriceCsv"
        Me.Column2colVerupPsPriceCsv.ReadOnly = True
        Me.Column2colVerupPsPriceCsv.Width = 200
        '
        'colVerupPsdCsv
        '
        Me.colVerupPsdCsv.HeaderText = "ｴｸｽﾎﾟｰﾄ詳細(CSV)"
        Me.colVerupPsdCsv.Name = "colVerupPsdCsv"
        Me.colVerupPsdCsv.ReadOnly = True
        Me.colVerupPsdCsv.Width = 200
        '
        'colMngAct
        '
        Me.colMngAct.HeaderText = "実行支援"
        Me.colMngAct.Name = "colMngAct"
        Me.colMngAct.Width = 200
        '
        'colMngDelivery
        '
        Me.colMngDelivery.HeaderText = "デリバリ支援"
        Me.colMngDelivery.Name = "colMngDelivery"
        Me.colMngDelivery.Width = 200
        '
        'colContractStart
        '
        Me.colContractStart.HeaderText = "契約開始"
        Me.colContractStart.Name = "colContractStart"
        '
        'colContractEnd
        '
        Me.colContractEnd.HeaderText = "契約終了"
        Me.colContractEnd.Name = "colContractEnd"
        '
        'colExcelStart
        '
        Me.colExcelStart.HeaderText = "Excel開始年"
        Me.colExcelStart.Name = "colExcelStart"
        Me.colExcelStart.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        '
        'colPaymentPeriod
        '
        Me.colPaymentPeriod.HeaderText = "Payment展開期間"
        Me.colPaymentPeriod.Name = "colPaymentPeriod"
        Me.colPaymentPeriod.Width = 200
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rdoBoth)
        Me.GroupBox1.Controls.Add(Me.rdoVersion)
        Me.GroupBox1.Controls.Add(Me.rdoStandard)
        Me.GroupBox1.Controls.Add(Me.rdoAct)
        Me.GroupBox1.Controls.Add(Me.rdoDeliv)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 51)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(707, 43)
        Me.GroupBox1.TabIndex = 16
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "一括処理"
        '
        'rdoBoth
        '
        Me.rdoBoth.AutoSize = True
        Me.rdoBoth.Location = New System.Drawing.Point(202, 18)
        Me.rdoBoth.Name = "rdoBoth"
        Me.rdoBoth.Size = New System.Drawing.Size(143, 16)
        Me.rdoBoth.TabIndex = 2
        Me.rdoBoth.Text = "実行・ﾃﾞﾘﾊﾞﾘ（作成のみ）"
        Me.rdoBoth.UseVisualStyleBackColor = True
        '
        'rdoVersion
        '
        Me.rdoVersion.AutoSize = True
        Me.rdoVersion.Location = New System.Drawing.Point(465, 18)
        Me.rdoVersion.Name = "rdoVersion"
        Me.rdoVersion.Size = New System.Drawing.Size(87, 16)
        Me.rdoVersion.TabIndex = 4
        Me.rdoVersion.Text = "ﾊﾞｰｼﾞｮﾝｱｯﾌﾟ"
        Me.rdoVersion.UseVisualStyleBackColor = True
        '
        'rdoStandard
        '
        Me.rdoStandard.AutoSize = True
        Me.rdoStandard.Location = New System.Drawing.Point(369, 18)
        Me.rdoStandard.Name = "rdoStandard"
        Me.rdoStandard.Size = New System.Drawing.Size(71, 16)
        Me.rdoStandard.TabIndex = 3
        Me.rdoStandard.Text = "標準帳票"
        Me.rdoStandard.UseVisualStyleBackColor = True
        '
        'rdoAct
        '
        Me.rdoAct.AutoSize = True
        Me.rdoAct.Checked = True
        Me.rdoAct.Location = New System.Drawing.Point(6, 18)
        Me.rdoAct.Name = "rdoAct"
        Me.rdoAct.Size = New System.Drawing.Size(71, 16)
        Me.rdoAct.TabIndex = 0
        Me.rdoAct.TabStop = True
        Me.rdoAct.Text = "実行支援"
        Me.rdoAct.UseVisualStyleBackColor = True
        '
        'rdoDeliv
        '
        Me.rdoDeliv.AutoSize = True
        Me.rdoDeliv.Location = New System.Drawing.Point(100, 18)
        Me.rdoDeliv.Name = "rdoDeliv"
        Me.rdoDeliv.Size = New System.Drawing.Size(80, 16)
        Me.rdoDeliv.TabIndex = 1
        Me.rdoDeliv.Text = "ﾃﾞﾘﾊﾞﾘ支援"
        Me.rdoDeliv.UseVisualStyleBackColor = True
        '
        'tabFile
        '
        Me.tabFile.Controls.Add(Me.tabImport)
        Me.tabFile.Controls.Add(Me.tabExport)
        Me.tabFile.Controls.Add(Me.tabStandard)
        Me.tabFile.Controls.Add(Me.tabVersion)
        Me.tabFile.Location = New System.Drawing.Point(12, 406)
        Me.tabFile.Name = "tabFile"
        Me.tabFile.SelectedIndex = 0
        Me.tabFile.Size = New System.Drawing.Size(713, 188)
        Me.tabFile.TabIndex = 8
        '
        'tabImport
        '
        Me.tabImport.Controls.Add(Me.btnImportManageFileOutputExplorer)
        Me.tabImport.Controls.Add(Me.bntMdbToExcel)
        Me.tabImport.Location = New System.Drawing.Point(4, 22)
        Me.tabImport.Name = "tabImport"
        Me.tabImport.Padding = New System.Windows.Forms.Padding(3)
        Me.tabImport.Size = New System.Drawing.Size(705, 162)
        Me.tabImport.TabIndex = 0
        Me.tabImport.Text = "サーバー → 支援ファイル作成"
        Me.tabImport.UseVisualStyleBackColor = True
        '
        'btnImportManageFileOutputExplorer
        '
        Me.btnImportManageFileOutputExplorer.BackColor = System.Drawing.Color.Magenta
        Me.btnImportManageFileOutputExplorer.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnImportManageFileOutputExplorer.ForeColor = System.Drawing.Color.White
        Me.btnImportManageFileOutputExplorer.Location = New System.Drawing.Point(169, 24)
        Me.btnImportManageFileOutputExplorer.Name = "btnImportManageFileOutputExplorer"
        Me.btnImportManageFileOutputExplorer.Size = New System.Drawing.Size(130, 44)
        Me.btnImportManageFileOutputExplorer.TabIndex = 11
        Me.btnImportManageFileOutputExplorer.Text = "出力フォルダ"
        Me.btnImportManageFileOutputExplorer.UseVisualStyleBackColor = False
        '
        'bntMdbToExcel
        '
        Me.bntMdbToExcel.BackColor = System.Drawing.Color.RoyalBlue
        Me.bntMdbToExcel.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.bntMdbToExcel.ForeColor = System.Drawing.Color.White
        Me.bntMdbToExcel.Location = New System.Drawing.Point(24, 24)
        Me.bntMdbToExcel.Name = "bntMdbToExcel"
        Me.bntMdbToExcel.Size = New System.Drawing.Size(130, 44)
        Me.bntMdbToExcel.TabIndex = 10
        Me.bntMdbToExcel.Text = "支援ファイル作成"
        Me.bntMdbToExcel.UseVisualStyleBackColor = False
        '
        'tabExport
        '
        Me.tabExport.BackColor = System.Drawing.Color.Transparent
        Me.tabExport.Controls.Add(Me.btnExportManageFileInputExplorer)
        Me.tabExport.Controls.Add(Me.btnExcelToMdb)
        Me.tabExport.Controls.Add(Me.btnExportPsExcelOutputExplorer)
        Me.tabExport.Controls.Add(Me.btnExportPsCsvOutputExplorer)
        Me.tabExport.Location = New System.Drawing.Point(4, 22)
        Me.tabExport.Name = "tabExport"
        Me.tabExport.Padding = New System.Windows.Forms.Padding(3)
        Me.tabExport.Size = New System.Drawing.Size(705, 162)
        Me.tabExport.TabIndex = 1
        Me.tabExport.Text = "支援ファイル読込 → サーバー"
        '
        'btnExportManageFileInputExplorer
        '
        Me.btnExportManageFileInputExplorer.BackColor = System.Drawing.Color.DarkOrange
        Me.btnExportManageFileInputExplorer.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnExportManageFileInputExplorer.ForeColor = System.Drawing.Color.White
        Me.btnExportManageFileInputExplorer.Location = New System.Drawing.Point(24, 24)
        Me.btnExportManageFileInputExplorer.Name = "btnExportManageFileInputExplorer"
        Me.btnExportManageFileInputExplorer.Size = New System.Drawing.Size(130, 44)
        Me.btnExportManageFileInputExplorer.TabIndex = 12
        Me.btnExportManageFileInputExplorer.Text = "入力フォルダ(支援ファイル)"
        Me.btnExportManageFileInputExplorer.UseVisualStyleBackColor = False
        '
        'btnExcelToMdb
        '
        Me.btnExcelToMdb.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnExcelToMdb.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnExcelToMdb.ForeColor = System.Drawing.Color.White
        Me.btnExcelToMdb.Location = New System.Drawing.Point(190, 24)
        Me.btnExcelToMdb.Name = "btnExcelToMdb"
        Me.btnExcelToMdb.Size = New System.Drawing.Size(130, 44)
        Me.btnExcelToMdb.TabIndex = 13
        Me.btnExcelToMdb.Text = "支援ファイルサーバーエクスポート"
        Me.btnExcelToMdb.UseVisualStyleBackColor = False
        '
        'btnExportPsExcelOutputExplorer
        '
        Me.btnExportPsExcelOutputExplorer.BackColor = System.Drawing.Color.Magenta
        Me.btnExportPsExcelOutputExplorer.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnExportPsExcelOutputExplorer.ForeColor = System.Drawing.Color.White
        Me.btnExportPsExcelOutputExplorer.Location = New System.Drawing.Point(24, 102)
        Me.btnExportPsExcelOutputExplorer.Name = "btnExportPsExcelOutputExplorer"
        Me.btnExportPsExcelOutputExplorer.Size = New System.Drawing.Size(130, 44)
        Me.btnExportPsExcelOutputExplorer.TabIndex = 14
        Me.btnExportPsExcelOutputExplorer.Text = "出力フォルダ"
        Me.btnExportPsExcelOutputExplorer.UseVisualStyleBackColor = False
        '
        'btnExportPsCsvOutputExplorer
        '
        Me.btnExportPsCsvOutputExplorer.BackColor = System.Drawing.Color.Magenta
        Me.btnExportPsCsvOutputExplorer.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnExportPsCsvOutputExplorer.ForeColor = System.Drawing.Color.White
        Me.btnExportPsCsvOutputExplorer.Location = New System.Drawing.Point(190, 102)
        Me.btnExportPsCsvOutputExplorer.Name = "btnExportPsCsvOutputExplorer"
        Me.btnExportPsCsvOutputExplorer.Size = New System.Drawing.Size(130, 44)
        Me.btnExportPsCsvOutputExplorer.TabIndex = 16
        Me.btnExportPsCsvOutputExplorer.Text = "出力フォルダ"
        Me.btnExportPsCsvOutputExplorer.UseVisualStyleBackColor = False
        '
        'tabStandard
        '
        Me.tabStandard.Controls.Add(Me.btnCsvToMdb)
        Me.tabStandard.Controls.Add(Me.btnSubmittedDataAll)
        Me.tabStandard.Controls.Add(Me.GroupBox6)
        Me.tabStandard.Controls.Add(Me.GroupBox7)
        Me.tabStandard.Location = New System.Drawing.Point(4, 22)
        Me.tabStandard.Name = "tabStandard"
        Me.tabStandard.Padding = New System.Windows.Forms.Padding(3)
        Me.tabStandard.Size = New System.Drawing.Size(705, 162)
        Me.tabStandard.TabIndex = 2
        Me.tabStandard.Text = "標準帳票"
        Me.tabStandard.UseVisualStyleBackColor = True
        '
        'btnCsvToMdb
        '
        Me.btnCsvToMdb.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnCsvToMdb.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnCsvToMdb.ForeColor = System.Drawing.Color.White
        Me.btnCsvToMdb.Location = New System.Drawing.Point(24, 98)
        Me.btnCsvToMdb.Name = "btnCsvToMdb"
        Me.btnCsvToMdb.Size = New System.Drawing.Size(130, 44)
        Me.btnCsvToMdb.TabIndex = 41
        Me.btnCsvToMdb.Text = "ｲﾝﾎﾟｰﾄ用CSV変換"
        Me.ttButon.SetToolTip(Me.btnCsvToMdb, "サーバーから取得したCSVファイルをＤＢに格納します。")
        Me.btnCsvToMdb.UseVisualStyleBackColor = False
        '
        'btnSubmittedDataAll
        '
        Me.btnSubmittedDataAll.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnSubmittedDataAll.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnSubmittedDataAll.ForeColor = System.Drawing.Color.White
        Me.btnSubmittedDataAll.Location = New System.Drawing.Point(377, 98)
        Me.btnSubmittedDataAll.Name = "btnSubmittedDataAll"
        Me.btnSubmittedDataAll.Size = New System.Drawing.Size(130, 44)
        Me.btnSubmittedDataAll.TabIndex = 19
        Me.btnSubmittedDataAll.Text = "ｲﾝﾎﾟｰﾄ用CSV変換 && ﾃﾞｰﾀ提供（全ﾃﾞｰﾀ）"
        Me.btnSubmittedDataAll.UseVisualStyleBackColor = False
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.btnStdSetMakeOutputExplorer)
        Me.GroupBox6.Controls.Add(Me.btnStdSetMake)
        Me.GroupBox6.Location = New System.Drawing.Point(6, 6)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(340, 73)
        Me.GroupBox6.TabIndex = 39
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "作成"
        '
        'btnStdSetMakeOutputExplorer
        '
        Me.btnStdSetMakeOutputExplorer.BackColor = System.Drawing.Color.Magenta
        Me.btnStdSetMakeOutputExplorer.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnStdSetMakeOutputExplorer.ForeColor = System.Drawing.Color.White
        Me.btnStdSetMakeOutputExplorer.Location = New System.Drawing.Point(184, 18)
        Me.btnStdSetMakeOutputExplorer.Name = "btnStdSetMakeOutputExplorer"
        Me.btnStdSetMakeOutputExplorer.Size = New System.Drawing.Size(130, 44)
        Me.btnStdSetMakeOutputExplorer.TabIndex = 18
        Me.btnStdSetMakeOutputExplorer.Text = "出力フォルダ"
        Me.btnStdSetMakeOutputExplorer.UseVisualStyleBackColor = False
        '
        'btnStdSetMake
        '
        Me.btnStdSetMake.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnStdSetMake.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnStdSetMake.ForeColor = System.Drawing.Color.White
        Me.btnStdSetMake.Location = New System.Drawing.Point(18, 18)
        Me.btnStdSetMake.Name = "btnStdSetMake"
        Me.btnStdSetMake.Size = New System.Drawing.Size(130, 44)
        Me.btnStdSetMake.TabIndex = 17
        Me.btnStdSetMake.Text = "作成"
        Me.btnStdSetMake.UseVisualStyleBackColor = False
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.btnStdOutOutputExplorer)
        Me.GroupBox7.Controls.Add(Me.btnStdOut)
        Me.GroupBox7.Location = New System.Drawing.Point(359, 6)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(340, 73)
        Me.GroupBox7.TabIndex = 40
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "出力"
        '
        'btnStdOutOutputExplorer
        '
        Me.btnStdOutOutputExplorer.BackColor = System.Drawing.Color.Magenta
        Me.btnStdOutOutputExplorer.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnStdOutOutputExplorer.ForeColor = System.Drawing.Color.White
        Me.btnStdOutOutputExplorer.Location = New System.Drawing.Point(184, 18)
        Me.btnStdOutOutputExplorer.Name = "btnStdOutOutputExplorer"
        Me.btnStdOutOutputExplorer.Size = New System.Drawing.Size(130, 44)
        Me.btnStdOutOutputExplorer.TabIndex = 20
        Me.btnStdOutOutputExplorer.Text = "出力フォルダ"
        Me.btnStdOutOutputExplorer.UseVisualStyleBackColor = False
        '
        'btnStdOut
        '
        Me.btnStdOut.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnStdOut.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnStdOut.ForeColor = System.Drawing.Color.White
        Me.btnStdOut.Location = New System.Drawing.Point(18, 18)
        Me.btnStdOut.Name = "btnStdOut"
        Me.btnStdOut.Size = New System.Drawing.Size(130, 44)
        Me.btnStdOut.TabIndex = 19
        Me.btnStdOut.Text = "出力"
        Me.btnStdOut.UseVisualStyleBackColor = False
        '
        'tabVersion
        '
        Me.tabVersion.Controls.Add(Me.cmdSaveFormat)
        Me.tabVersion.Controls.Add(Me.GroupBox8)
        Me.tabVersion.Controls.Add(Me.btnVerUpCsvToMdb)
        Me.tabVersion.Controls.Add(Me.btnVerUpExcelExplorer)
        Me.tabVersion.Controls.Add(Me.btnVersionUp)
        Me.tabVersion.Location = New System.Drawing.Point(4, 22)
        Me.tabVersion.Name = "tabVersion"
        Me.tabVersion.Padding = New System.Windows.Forms.Padding(3)
        Me.tabVersion.Size = New System.Drawing.Size(705, 162)
        Me.tabVersion.TabIndex = 3
        Me.tabVersion.Text = "バージョンアップ"
        Me.tabVersion.UseVisualStyleBackColor = True
        '
        'cmdSaveFormat
        '
        Me.cmdSaveFormat.BackColor = System.Drawing.Color.RoyalBlue
        Me.cmdSaveFormat.Enabled = False
        Me.cmdSaveFormat.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.cmdSaveFormat.ForeColor = System.Drawing.Color.White
        Me.cmdSaveFormat.Location = New System.Drawing.Point(24, 102)
        Me.cmdSaveFormat.Name = "cmdSaveFormat"
        Me.cmdSaveFormat.Size = New System.Drawing.Size(130, 44)
        Me.cmdSaveFormat.TabIndex = 22
        Me.cmdSaveFormat.Text = "体裁ファイル取込"
        Me.cmdSaveFormat.UseVisualStyleBackColor = False
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.btnVerUpExportExplore)
        Me.GroupBox8.Controls.Add(Me.btnVerUpExcelToMdb)
        Me.GroupBox8.Location = New System.Drawing.Point(359, 84)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(340, 73)
        Me.GroupBox8.TabIndex = 40
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "ｴｸｽﾎﾟｰﾄ用CSV変換"
        '
        'btnVerUpExportExplore
        '
        Me.btnVerUpExportExplore.BackColor = System.Drawing.Color.Magenta
        Me.btnVerUpExportExplore.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnVerUpExportExplore.ForeColor = System.Drawing.Color.White
        Me.btnVerUpExportExplore.Location = New System.Drawing.Point(184, 18)
        Me.btnVerUpExportExplore.Name = "btnVerUpExportExplore"
        Me.btnVerUpExportExplore.Size = New System.Drawing.Size(130, 44)
        Me.btnVerUpExportExplore.TabIndex = 26
        Me.btnVerUpExportExplore.Text = "出力フォルダ"
        Me.btnVerUpExportExplore.UseVisualStyleBackColor = False
        '
        'btnVerUpExcelToMdb
        '
        Me.btnVerUpExcelToMdb.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnVerUpExcelToMdb.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnVerUpExcelToMdb.ForeColor = System.Drawing.Color.White
        Me.btnVerUpExcelToMdb.Location = New System.Drawing.Point(18, 18)
        Me.btnVerUpExcelToMdb.Name = "btnVerUpExcelToMdb"
        Me.btnVerUpExcelToMdb.Size = New System.Drawing.Size(130, 44)
        Me.btnVerUpExcelToMdb.TabIndex = 25
        Me.btnVerUpExcelToMdb.Text = "ｴｸｽﾎﾟｰﾄ用CSV変換"
        Me.btnVerUpExcelToMdb.UseVisualStyleBackColor = False
        '
        'btnVerUpCsvToMdb
        '
        Me.btnVerUpCsvToMdb.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnVerUpCsvToMdb.Enabled = False
        Me.btnVerUpCsvToMdb.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnVerUpCsvToMdb.ForeColor = System.Drawing.Color.White
        Me.btnVerUpCsvToMdb.Location = New System.Drawing.Point(24, 24)
        Me.btnVerUpCsvToMdb.Name = "btnVerUpCsvToMdb"
        Me.btnVerUpCsvToMdb.Size = New System.Drawing.Size(130, 44)
        Me.btnVerUpCsvToMdb.TabIndex = 21
        Me.btnVerUpCsvToMdb.Text = "変換前データ取得"
        Me.ttButon.SetToolTip(Me.btnVerUpCsvToMdb, "サーバーから取得したCSVファイルをＤＢに格納します。")
        Me.btnVerUpCsvToMdb.UseVisualStyleBackColor = False
        '
        'btnVerUpExcelExplorer
        '
        Me.btnVerUpExcelExplorer.BackColor = System.Drawing.Color.Magenta
        Me.btnVerUpExcelExplorer.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnVerUpExcelExplorer.ForeColor = System.Drawing.Color.White
        Me.btnVerUpExcelExplorer.Location = New System.Drawing.Point(543, 24)
        Me.btnVerUpExcelExplorer.Name = "btnVerUpExcelExplorer"
        Me.btnVerUpExcelExplorer.Size = New System.Drawing.Size(130, 44)
        Me.btnVerUpExcelExplorer.TabIndex = 24
        Me.btnVerUpExcelExplorer.Text = "出力フォルダ"
        Me.btnVerUpExcelExplorer.UseVisualStyleBackColor = False
        '
        'btnVersionUp
        '
        Me.btnVersionUp.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnVersionUp.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnVersionUp.ForeColor = System.Drawing.Color.White
        Me.btnVersionUp.Location = New System.Drawing.Point(377, 24)
        Me.btnVersionUp.Name = "btnVersionUp"
        Me.btnVersionUp.Size = New System.Drawing.Size(130, 44)
        Me.btnVersionUp.TabIndex = 23
        Me.btnVersionUp.Text = "Payment出力"
        Me.btnVersionUp.UseVisualStyleBackColor = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(538, 182)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(88, 12)
        Me.Label6.TabIndex = 22
        Me.Label6.Text = "作業年月フォルダ"
        '
        'cboWorkDate
        '
        Me.cboWorkDate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboWorkDate.FormattingEnabled = True
        Me.cboWorkDate.Location = New System.Drawing.Point(632, 178)
        Me.cboWorkDate.Name = "cboWorkDate"
        Me.cboWorkDate.Size = New System.Drawing.Size(89, 20)
        Me.cboWorkDate.TabIndex = 6
        '
        'grpAct
        '
        Me.grpAct.Controls.Add(Me.cbSheet5)
        Me.grpAct.Controls.Add(Me.cbSheet3)
        Me.grpAct.Controls.Add(Me.cbSheet4)
        Me.grpAct.Controls.Add(Me.cbSheet2)
        Me.grpAct.Controls.Add(Me.cbSheet1)
        Me.grpAct.Enabled = False
        Me.grpAct.Location = New System.Drawing.Point(12, 100)
        Me.grpAct.Name = "grpAct"
        Me.grpAct.Size = New System.Drawing.Size(707, 64)
        Me.grpAct.TabIndex = 36
        Me.grpAct.TabStop = False
        Me.grpAct.Text = "実行支援　連携シート出力選択（作成のみ）"
        '
        'cbSheet5
        '
        Me.cbSheet5.AutoSize = True
        Me.cbSheet5.Location = New System.Drawing.Point(8, 40)
        Me.cbSheet5.Name = "cbSheet5"
        Me.cbSheet5.Size = New System.Drawing.Size(120, 16)
        Me.cbSheet5.TabIndex = 36
        Me.cbSheet5.Text = "⑤要確認保守廃止"
        Me.cbSheet5.UseVisualStyleBackColor = True
        '
        'cbSheet3
        '
        Me.cbSheet3.AutoSize = True
        Me.cbSheet3.Location = New System.Drawing.Point(379, 18)
        Me.cbSheet3.Name = "cbSheet3"
        Me.cbSheet3.Size = New System.Drawing.Size(142, 16)
        Me.cbSheet3.TabIndex = 2
        Me.cbSheet3.Text = "③要確認EOS価格改定"
        Me.cbSheet3.UseVisualStyleBackColor = True
        '
        'cbSheet4
        '
        Me.cbSheet4.AutoSize = True
        Me.cbSheet4.Location = New System.Drawing.Point(527, 18)
        Me.cbSheet4.Name = "cbSheet4"
        Me.cbSheet4.Size = New System.Drawing.Size(172, 16)
        Me.cbSheet4.TabIndex = 35
        Me.cbSheet4.Text = "④参考未発注（過去－２ヶ月）"
        Me.cbSheet4.UseVisualStyleBackColor = True
        '
        'cbSheet2
        '
        Me.cbSheet2.AutoSize = True
        Me.cbSheet2.Location = New System.Drawing.Point(194, 18)
        Me.cbSheet2.Name = "cbSheet2"
        Me.cbSheet2.Size = New System.Drawing.Size(182, 16)
        Me.cbSheet2.TabIndex = 1
        Me.cbSheet2.Text = "②任意回答未実行（3ヶ月以降）"
        Me.cbSheet2.UseVisualStyleBackColor = True
        '
        'cbSheet1
        '
        Me.cbSheet1.AutoSize = True
        Me.cbSheet1.Checked = True
        Me.cbSheet1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.cbSheet1.Location = New System.Drawing.Point(8, 18)
        Me.cbSheet1.Name = "cbSheet1"
        Me.cbSheet1.Size = New System.Drawing.Size(184, 16)
        Me.cbSheet1.TabIndex = 0
        Me.cbSheet1.Text = "①要回答未実行（過去－２ヶ月）"
        Me.cbSheet1.UseVisualStyleBackColor = True
        '
        'btnLogExplorer
        '
        Me.btnLogExplorer.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnLogExplorer.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnLogExplorer.ForeColor = System.Drawing.Color.White
        Me.btnLogExplorer.Location = New System.Drawing.Point(393, 600)
        Me.btnLogExplorer.Name = "btnLogExplorer"
        Me.btnLogExplorer.Size = New System.Drawing.Size(130, 44)
        Me.btnLogExplorer.TabIndex = 28
        Me.btnLogExplorer.Text = "ログフォルダ"
        Me.btnLogExplorer.UseVisualStyleBackColor = False
        '
        'btnRefresh
        '
        Me.btnRefresh.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnRefresh.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnRefresh.ForeColor = System.Drawing.Color.White
        Me.btnRefresh.Location = New System.Drawing.Point(559, 600)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(130, 44)
        Me.btnRefresh.TabIndex = 29
        Me.btnRefresh.Text = "リフレッシュ"
        Me.btnRefresh.UseVisualStyleBackColor = False
        '
        'btnLogout
        '
        Me.btnLogout.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnLogout.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnLogout.ForeColor = System.Drawing.Color.White
        Me.btnLogout.Location = New System.Drawing.Point(40, 600)
        Me.btnLogout.Name = "btnLogout"
        Me.btnLogout.Size = New System.Drawing.Size(130, 44)
        Me.btnLogout.TabIndex = 27
        Me.btnLogout.Text = "ログアウト"
        Me.btnLogout.UseVisualStyleBackColor = False
        '
        'btnCpnoChkOff
        '
        Me.btnCpnoChkOff.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnCpnoChkOff.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.btnCpnoChkOff.ForeColor = System.Drawing.Color.White
        Me.btnCpnoChkOff.Location = New System.Drawing.Point(12, 178)
        Me.btnCpnoChkOff.Name = "btnCpnoChkOff"
        Me.btnCpnoChkOff.Size = New System.Drawing.Size(107, 24)
        Me.btnCpnoChkOff.TabIndex = 5
        Me.btnCpnoChkOff.Text = "CPNO全選択"
        Me.btnCpnoChkOff.UseVisualStyleBackColor = False
        '
        'upalTitle
        '
        Me.upalTitle.BackColor = System.Drawing.Color.Teal
        Me.upalTitle.BackColro2 = System.Drawing.Color.PaleTurquoise
        Me.upalTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.upalTitle.ForeColor = System.Drawing.Color.White
        Me.upalTitle.Location = New System.Drawing.Point(2, 1)
        Me.upalTitle.Name = "upalTitle"
        Me.upalTitle.Size = New System.Drawing.Size(734, 44)
        Me.upalTitle.TabIndex = 33
        Me.upalTitle.TitleText = "OIO BAMA Client　一括処理"
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.HeaderText = "CPNO"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Width = 50
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.HeaderText = "お客様名"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        '
        'DataGridViewTextBoxColumn3
        '
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DataGridViewTextBoxColumn3.DefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridViewTextBoxColumn3.HeaderText = "DB"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        Me.DataGridViewTextBoxColumn3.Width = 120
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.HeaderText = "出力状況"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        Me.DataGridViewTextBoxColumn4.Width = 200
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.HeaderText = "標準帳票設定"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        Me.DataGridViewTextBoxColumn5.Width = 200
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.HeaderText = "標準帳票出力(EXCEL)"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.ReadOnly = True
        Me.DataGridViewTextBoxColumn6.Width = 200
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.HeaderText = "ﾊﾞｰｼﾞｮﾝｱｯﾌﾟ(EXCEL)"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.ReadOnly = True
        Me.DataGridViewTextBoxColumn7.Width = 200
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.HeaderText = "ｴｸｽﾎﾟｰﾄV_PLINE(CSV)"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.ReadOnly = True
        Me.DataGridViewTextBoxColumn8.Width = 200
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.HeaderText = "ｴｸｽﾎﾟｰﾄT_PPRICE(CSV)"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.ReadOnly = True
        Me.DataGridViewTextBoxColumn9.Width = 200
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.HeaderText = "ｴｸｽﾎﾟｰﾄ詳細(CSV)"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        Me.DataGridViewTextBoxColumn10.ReadOnly = True
        Me.DataGridViewTextBoxColumn10.Width = 200
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.HeaderText = "実行支援"
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.Width = 200
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.HeaderText = "デリバリ支援"
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        Me.DataGridViewTextBoxColumn12.Width = 200
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.HeaderText = "契約開始"
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        '
        'DataGridViewTextBoxColumn14
        '
        Me.DataGridViewTextBoxColumn14.HeaderText = "契約終了"
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        '
        'DataGridViewTextBoxColumn15
        '
        Me.DataGridViewTextBoxColumn15.HeaderText = "Excel開始年"
        Me.DataGridViewTextBoxColumn15.Name = "DataGridViewTextBoxColumn15"
        Me.DataGridViewTextBoxColumn15.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        '
        'DataGridViewTextBoxColumn16
        '
        Me.DataGridViewTextBoxColumn16.HeaderText = "Payment展開期間"
        Me.DataGridViewTextBoxColumn16.Name = "DataGridViewTextBoxColumn16"
        Me.DataGridViewTextBoxColumn16.Width = 200
        '
        'Frm_AsrAll
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(734, 656)
        Me.Controls.Add(Me.grpAct)
        Me.Controls.Add(Me.cboWorkDate)
        Me.Controls.Add(Me.btnLogExplorer)
        Me.Controls.Add(Me.btnRefresh)
        Me.Controls.Add(Me.btnLogout)
        Me.Controls.Add(Me.btnCpnoChkOff)
        Me.Controls.Add(Me.upalTitle)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.tabFile)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.dvgCpno)
        Me.MaximizeBox = False
        Me.Name = "Frm_AsrAll"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "OIO BAMA Client"
        CType(Me.dvgCpno, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.tabFile.ResumeLayout(False)
        Me.tabImport.ResumeLayout(False)
        Me.tabExport.ResumeLayout(False)
        Me.tabStandard.ResumeLayout(False)
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox7.ResumeLayout(False)
        Me.tabVersion.ResumeLayout(False)
        Me.GroupBox8.ResumeLayout(False)
        Me.grpAct.ResumeLayout(False)
        Me.grpAct.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents dvgCpno As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents rdoAct As System.Windows.Forms.RadioButton
    Friend WithEvents rdoDeliv As System.Windows.Forms.RadioButton
    Friend WithEvents tabFile As System.Windows.Forms.TabControl
    Friend WithEvents tabImport As System.Windows.Forms.TabPage
    Friend WithEvents tabExport As System.Windows.Forms.TabPage
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents upalTitle As MUSE.UserControl.UCnt_Pal0001
    Friend WithEvents btnCpnoChkOff As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents btnExportManageFileInputExplorer As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents btnLogout As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents bntMdbToExcel As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents btnExcelToMdb As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents btnRefresh As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents ttButon As System.Windows.Forms.ToolTip
    Friend WithEvents btnLogExplorer As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents btnExportPsExcelOutputExplorer As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents btnExportPsCsvOutputExplorer As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents btnImportManageFileOutputExplorer As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents cboWorkDate As System.Windows.Forms.ComboBox
    Friend WithEvents btnStdSetMake As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents btnStdOut As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents tabStandard As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents btnStdSetMakeOutputExplorer As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents btnStdOutOutputExplorer As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents rdoStandard As System.Windows.Forms.RadioButton
    Friend WithEvents tabVersion As System.Windows.Forms.TabPage
    Friend WithEvents btnVersionUp As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents btnVerUpExcelExplorer As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents rdoVersion As System.Windows.Forms.RadioButton
    Friend WithEvents btnVerUpCsvToMdb As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents btnVerUpExportExplore As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents btnVerUpExcelToMdb As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents cmdSaveFormat As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents rdoBoth As System.Windows.Forms.RadioButton
    Friend WithEvents btnSubmittedDataAll As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents grpAct As System.Windows.Forms.GroupBox
    Friend WithEvents cbSheet3 As System.Windows.Forms.CheckBox
    Friend WithEvents cbSheet4 As System.Windows.Forms.CheckBox
    Friend WithEvents cbSheet2 As System.Windows.Forms.CheckBox
    Friend WithEvents cbSheet1 As System.Windows.Forms.CheckBox
    Friend WithEvents btnCsvToMdb As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn13 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn15 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn16 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents colCpno As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colContractName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDb As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colOutputState As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colStdSet As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colStdReport As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colVerupExcel As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colVerupPsCsv As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2colVerupPsPriceCsv As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colVerupPsdCsv As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMngAct As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMngDelivery As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colContractStart As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colContractEnd As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colExcelStart As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPaymentPeriod As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents cbSheet5 As System.Windows.Forms.CheckBox

End Class
