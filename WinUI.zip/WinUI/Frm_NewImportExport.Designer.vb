﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frm_NewImportExport
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabImportExport = New System.Windows.Forms.TabControl()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.lnkURL = New System.Windows.Forms.LinkLabel()
        Me.lblPsExUpdate = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.btnExPayment = New MUSE.UserControl.UCnt_Btn0001()
        Me.txtExPayment = New System.Windows.Forms.TextBox()
        Me.lblExPayment = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.btnDirectImport = New MUSE.UserControl.UCnt_Btn0001()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.rbPsdS = New System.Windows.Forms.RadioButton()
        Me.rbPsdF = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.rbPsK = New System.Windows.Forms.RadioButton()
        Me.rbPsI = New System.Windows.Forms.RadioButton()
        Me.rbPsP = New System.Windows.Forms.RadioButton()
        Me.rbPsS = New System.Windows.Forms.RadioButton()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.BtnExportGo = New MUSE.UserControl.UCnt_Btn0001()
        Me.BtnDispExplorer = New MUSE.UserControl.UCnt_Btn0001()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.lblPsInUpdate = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.lblInPaymentSheet = New System.Windows.Forms.Label()
        Me.txtInPaymentSheet = New System.Windows.Forms.TextBox()
        Me.btnImportCsvMdb = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnImportCsv = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnImportMdb = New MUSE.UserControl.UCnt_Btn0001()
        Me.txtContract = New System.Windows.Forms.TextBox()
        Me.txtCpnoName = New System.Windows.Forms.TextBox()
        Me.txtCpno = New System.Windows.Forms.TextBox()
        Me.txtCustomerName = New System.Windows.Forms.TextBox()
        Me.txtModifyNo = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.BtnRefresh = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnLogOut = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnReturn = New MUSE.UserControl.UCnt_Btn0001()
        Me.UCnt_Pal00011 = New MUSE.UserControl.UCnt_Pal0001()
        Me.TabImportExport.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabImportExport
        '
        Me.TabImportExport.Controls.Add(Me.TabPage2)
        Me.TabImportExport.Controls.Add(Me.TabPage5)
        Me.TabImportExport.Location = New System.Drawing.Point(16, 119)
        Me.TabImportExport.Name = "TabImportExport"
        Me.TabImportExport.SelectedIndex = 0
        Me.TabImportExport.Size = New System.Drawing.Size(624, 330)
        Me.TabImportExport.TabIndex = 0
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Label13)
        Me.TabPage2.Controls.Add(Me.lnkURL)
        Me.TabPage2.Controls.Add(Me.lblPsExUpdate)
        Me.TabPage2.Controls.Add(Me.Label8)
        Me.TabPage2.Controls.Add(Me.btnExPayment)
        Me.TabPage2.Controls.Add(Me.txtExPayment)
        Me.TabPage2.Controls.Add(Me.lblExPayment)
        Me.TabPage2.Controls.Add(Me.GroupBox4)
        Me.TabPage2.Controls.Add(Me.GroupBox5)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3, 3, 3, 3)
        Me.TabPage2.Size = New System.Drawing.Size(616, 304)
        Me.TabPage2.TabIndex = 0
        Me.TabPage2.Text = "エクスポート　EXCEL→CSV 変換"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.Black
        Me.Label13.Location = New System.Drawing.Point(28, 59)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(120, 12)
        Me.Label13.TabIndex = 93
        Me.Label13.Text = "OIO-BAMA サーバー"
        '
        'lnkURL
        '
        Me.lnkURL.AutoSize = True
        Me.lnkURL.Location = New System.Drawing.Point(28, 75)
        Me.lnkURL.Name = "lnkURL"
        Me.lnkURL.Size = New System.Drawing.Size(351, 12)
        Me.lnkURL.TabIndex = 92
        Me.lnkURL.TabStop = True
        Me.lnkURL.Text = "https://w3-06preprod.ibm.com/jp/sales/oio/oiobama/web/index.jsp"
        '
        'lblPsExUpdate
        '
        Me.lblPsExUpdate.AutoSize = True
        Me.lblPsExUpdate.Location = New System.Drawing.Point(370, 51)
        Me.lblPsExUpdate.Name = "lblPsExUpdate"
        Me.lblPsExUpdate.Size = New System.Drawing.Size(125, 12)
        Me.lblPsExUpdate.TabIndex = 89
        Me.lblPsExUpdate.Text = "xxxx/xx/xx　HH:MM:SS"
        Me.lblPsExUpdate.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(303, 51)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(59, 12)
        Me.Label8.TabIndex = 88
        Me.Label8.Text = "更新日時："
        '
        'btnExPayment
        '
        Me.btnExPayment.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnExPayment.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExPayment.ForeColor = System.Drawing.Color.White
        Me.btnExPayment.Location = New System.Drawing.Point(513, 17)
        Me.btnExPayment.Name = "btnExPayment"
        Me.btnExPayment.Size = New System.Drawing.Size(74, 29)
        Me.btnExPayment.TabIndex = 2
        Me.btnExPayment.Text = "参照"
        Me.btnExPayment.UseVisualStyleBackColor = False
        '
        'txtExPayment
        '
        Me.txtExPayment.BackColor = System.Drawing.Color.Yellow
        Me.txtExPayment.Location = New System.Drawing.Point(28, 23)
        Me.txtExPayment.Name = "txtExPayment"
        Me.txtExPayment.Size = New System.Drawing.Size(467, 19)
        Me.txtExPayment.TabIndex = 1
        '
        'lblExPayment
        '
        Me.lblExPayment.AutoSize = True
        Me.lblExPayment.Location = New System.Drawing.Point(26, 9)
        Me.lblExPayment.Name = "lblExPayment"
        Me.lblExPayment.Size = New System.Drawing.Size(95, 12)
        Me.lblExPayment.TabIndex = 68
        Me.lblExPayment.Text = "Paymentファイル名"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.btnDirectImport)
        Me.GroupBox4.Controls.Add(Me.GroupBox3)
        Me.GroupBox4.Controls.Add(Me.GroupBox2)
        Me.GroupBox4.Location = New System.Drawing.Point(17, 168)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(583, 119)
        Me.GroupBox4.TabIndex = 97
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "サーバー直接"
        '
        'btnDirectImport
        '
        Me.btnDirectImport.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnDirectImport.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDirectImport.ForeColor = System.Drawing.Color.White
        Me.btnDirectImport.Location = New System.Drawing.Point(437, 63)
        Me.btnDirectImport.Name = "btnDirectImport"
        Me.btnDirectImport.Size = New System.Drawing.Size(133, 44)
        Me.btnDirectImport.TabIndex = 94
        Me.btnDirectImport.Text = "サーバ直接エクスポート"
        Me.btnDirectImport.UseVisualStyleBackColor = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.rbPsdS)
        Me.GroupBox3.Controls.Add(Me.rbPsdF)
        Me.GroupBox3.Location = New System.Drawing.Point(6, 63)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(312, 46)
        Me.GroupBox3.TabIndex = 96
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "詳細 エクスポート方法"
        '
        'rbPsdS
        '
        Me.rbPsdS.AutoSize = True
        Me.rbPsdS.Location = New System.Drawing.Point(79, 23)
        Me.rbPsdS.Name = "rbPsdS"
        Me.rbPsdS.Size = New System.Drawing.Size(71, 16)
        Me.rbPsdS.TabIndex = 1
        Me.rbPsdS.TabStop = True
        Me.rbPsdS.Text = "差分追加"
        Me.rbPsdS.UseVisualStyleBackColor = True
        '
        'rbPsdF
        '
        Me.rbPsdF.AutoSize = True
        Me.rbPsdF.Checked = True
        Me.rbPsdF.Location = New System.Drawing.Point(9, 23)
        Me.rbPsdF.Name = "rbPsdF"
        Me.rbPsdF.Size = New System.Drawing.Size(64, 16)
        Me.rbPsdF.TabIndex = 0
        Me.rbPsdF.TabStop = True
        Me.rbPsdF.Text = "Replace"
        Me.rbPsdF.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rbPsK)
        Me.GroupBox2.Controls.Add(Me.rbPsI)
        Me.GroupBox2.Controls.Add(Me.rbPsP)
        Me.GroupBox2.Controls.Add(Me.rbPsS)
        Me.GroupBox2.Location = New System.Drawing.Point(6, 11)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(564, 46)
        Me.GroupBox2.TabIndex = 95
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Payment エクスポート方法"
        '
        'rbPsK
        '
        Me.rbPsK.AutoSize = True
        Me.rbPsK.Location = New System.Drawing.Point(427, 18)
        Me.rbPsK.Name = "rbPsK"
        Me.rbPsK.Size = New System.Drawing.Size(47, 16)
        Me.rbPsK.TabIndex = 6
        Me.rbPsK.TabStop = True
        Me.rbPsK.Text = "更新"
        Me.rbPsK.UseVisualStyleBackColor = True
        '
        'rbPsI
        '
        Me.rbPsI.AutoSize = True
        Me.rbPsI.Checked = True
        Me.rbPsI.Location = New System.Drawing.Point(9, 17)
        Me.rbPsI.Name = "rbPsI"
        Me.rbPsI.Size = New System.Drawing.Size(137, 16)
        Me.rbPsI.TabIndex = 3
        Me.rbPsI.TabStop = True
        Me.rbPsI.Text = "Replace&&更新-作成中"
        Me.rbPsI.UseVisualStyleBackColor = True
        '
        'rbPsP
        '
        Me.rbPsP.AutoSize = True
        Me.rbPsP.Location = New System.Drawing.Point(156, 17)
        Me.rbPsP.Name = "rbPsP"
        Me.rbPsP.Size = New System.Drawing.Size(182, 16)
        Me.rbPsP.TabIndex = 4
        Me.rbPsP.TabStop = True
        Me.rbPsP.Text = "Replace&&更新-価格承認に変更"
        Me.rbPsP.UseVisualStyleBackColor = True
        '
        'rbPsS
        '
        Me.rbPsS.AutoSize = True
        Me.rbPsS.Location = New System.Drawing.Point(346, 17)
        Me.rbPsS.Name = "rbPsS"
        Me.rbPsS.Size = New System.Drawing.Size(71, 16)
        Me.rbPsS.TabIndex = 5
        Me.rbPsS.TabStop = True
        Me.rbPsS.Text = "差分追加"
        Me.rbPsS.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.BtnExportGo)
        Me.GroupBox5.Controls.Add(Me.BtnDispExplorer)
        Me.GroupBox5.Location = New System.Drawing.Point(17, 9)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(583, 153)
        Me.GroupBox5.TabIndex = 98
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "GroupBox5"
        '
        'BtnExportGo
        '
        Me.BtnExportGo.BackColor = System.Drawing.Color.RoyalBlue
        Me.BtnExportGo.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnExportGo.ForeColor = System.Drawing.Color.White
        Me.BtnExportGo.Location = New System.Drawing.Point(288, 90)
        Me.BtnExportGo.Name = "BtnExportGo"
        Me.BtnExportGo.Size = New System.Drawing.Size(133, 44)
        Me.BtnExportGo.TabIndex = 3
        Me.BtnExportGo.Text = "エクスポート" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.BtnExportGo.UseVisualStyleBackColor = False
        '
        'BtnDispExplorer
        '
        Me.BtnDispExplorer.BackColor = System.Drawing.Color.RoyalBlue
        Me.BtnDispExplorer.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnDispExplorer.ForeColor = System.Drawing.Color.White
        Me.BtnDispExplorer.Location = New System.Drawing.Point(437, 90)
        Me.BtnDispExplorer.Name = "BtnDispExplorer"
        Me.BtnDispExplorer.Size = New System.Drawing.Size(133, 44)
        Me.BtnDispExplorer.TabIndex = 4
        Me.BtnDispExplorer.Text = "ﾌｫﾙﾀﾞ表示"
        Me.BtnDispExplorer.UseVisualStyleBackColor = False
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.lblPsInUpdate)
        Me.TabPage5.Controls.Add(Me.Label9)
        Me.TabPage5.Controls.Add(Me.lblInPaymentSheet)
        Me.TabPage5.Controls.Add(Me.txtInPaymentSheet)
        Me.TabPage5.Controls.Add(Me.btnImportCsvMdb)
        Me.TabPage5.Controls.Add(Me.btnImportCsv)
        Me.TabPage5.Controls.Add(Me.btnImportMdb)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3, 3, 3, 3)
        Me.TabPage5.Size = New System.Drawing.Size(616, 304)
        Me.TabPage5.TabIndex = 1
        Me.TabPage5.Text = "インポート　CSV→EXCEL 変換"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'lblPsInUpdate
        '
        Me.lblPsInUpdate.AutoSize = True
        Me.lblPsInUpdate.Location = New System.Drawing.Point(461, 97)
        Me.lblPsInUpdate.Name = "lblPsInUpdate"
        Me.lblPsInUpdate.Size = New System.Drawing.Size(125, 12)
        Me.lblPsInUpdate.TabIndex = 90
        Me.lblPsInUpdate.Text = "xxxx/xx/xx　HH:MM:SS"
        Me.lblPsInUpdate.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(387, 97)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(59, 12)
        Me.Label9.TabIndex = 89
        Me.Label9.Text = "更新日時："
        '
        'lblInPaymentSheet
        '
        Me.lblInPaymentSheet.AutoSize = True
        Me.lblInPaymentSheet.Location = New System.Drawing.Point(35, 58)
        Me.lblInPaymentSheet.Name = "lblInPaymentSheet"
        Me.lblInPaymentSheet.Size = New System.Drawing.Size(123, 12)
        Me.lblInPaymentSheet.TabIndex = 74
        Me.lblInPaymentSheet.Text = "Csvファイル名(Payment)"
        '
        'txtInPaymentSheet
        '
        Me.txtInPaymentSheet.BackColor = System.Drawing.Color.Gainsboro
        Me.txtInPaymentSheet.Enabled = False
        Me.txtInPaymentSheet.Location = New System.Drawing.Point(37, 75)
        Me.txtInPaymentSheet.Name = "txtInPaymentSheet"
        Me.txtInPaymentSheet.Size = New System.Drawing.Size(549, 19)
        Me.txtInPaymentSheet.TabIndex = 5
        '
        'btnImportCsvMdb
        '
        Me.btnImportCsvMdb.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnImportCsvMdb.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnImportCsvMdb.ForeColor = System.Drawing.Color.White
        Me.btnImportCsvMdb.Location = New System.Drawing.Point(446, 250)
        Me.btnImportCsvMdb.Name = "btnImportCsvMdb"
        Me.btnImportCsvMdb.Size = New System.Drawing.Size(145, 44)
        Me.btnImportCsvMdb.TabIndex = 71
        Me.btnImportCsvMdb.Text = "インポート" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "（作成中+契約済）"
        Me.btnImportCsvMdb.UseVisualStyleBackColor = False
        '
        'btnImportCsv
        '
        Me.btnImportCsv.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnImportCsv.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnImportCsv.ForeColor = System.Drawing.Color.White
        Me.btnImportCsv.Location = New System.Drawing.Point(121, 250)
        Me.btnImportCsv.Name = "btnImportCsv"
        Me.btnImportCsv.Size = New System.Drawing.Size(145, 44)
        Me.btnImportCsv.TabIndex = 70
        Me.btnImportCsv.Text = "インポート" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "（作成中のみ）"
        Me.btnImportCsv.UseVisualStyleBackColor = False
        '
        'btnImportMdb
        '
        Me.btnImportMdb.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnImportMdb.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnImportMdb.ForeColor = System.Drawing.Color.White
        Me.btnImportMdb.Location = New System.Drawing.Point(284, 250)
        Me.btnImportMdb.Name = "btnImportMdb"
        Me.btnImportMdb.Size = New System.Drawing.Size(145, 44)
        Me.btnImportMdb.TabIndex = 18
        Me.btnImportMdb.Text = "インポート" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "（契約済のみ）"
        Me.btnImportMdb.UseVisualStyleBackColor = False
        '
        'txtContract
        '
        Me.txtContract.BackColor = System.Drawing.SystemColors.Control
        Me.txtContract.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtContract.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.txtContract.Location = New System.Drawing.Point(213, 36)
        Me.txtContract.Name = "txtContract"
        Me.txtContract.ReadOnly = True
        Me.txtContract.Size = New System.Drawing.Size(82, 12)
        Me.txtContract.TabIndex = 72
        Me.txtContract.TabStop = False
        Me.txtContract.Visible = False
        '
        'txtCpnoName
        '
        Me.txtCpnoName.BackColor = System.Drawing.SystemColors.Control
        Me.txtCpnoName.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtCpnoName.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.txtCpnoName.Location = New System.Drawing.Point(120, 18)
        Me.txtCpnoName.Name = "txtCpnoName"
        Me.txtCpnoName.ReadOnly = True
        Me.txtCpnoName.Size = New System.Drawing.Size(244, 12)
        Me.txtCpnoName.TabIndex = 73
        Me.txtCpnoName.TabStop = False
        '
        'txtCpno
        '
        Me.txtCpno.Enabled = False
        Me.txtCpno.Location = New System.Drawing.Point(317, 92)
        Me.txtCpno.Name = "txtCpno"
        Me.txtCpno.Size = New System.Drawing.Size(48, 19)
        Me.txtCpno.TabIndex = 74
        Me.txtCpno.Visible = False
        '
        'txtCustomerName
        '
        Me.txtCustomerName.Enabled = False
        Me.txtCustomerName.Location = New System.Drawing.Point(263, 92)
        Me.txtCustomerName.Name = "txtCustomerName"
        Me.txtCustomerName.Size = New System.Drawing.Size(48, 19)
        Me.txtCustomerName.TabIndex = 75
        Me.txtCustomerName.Visible = False
        '
        'txtModifyNo
        '
        Me.txtModifyNo.BackColor = System.Drawing.SystemColors.Control
        Me.txtModifyNo.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtModifyNo.Font = New System.Drawing.Font("MS UI Gothic", 9.0!)
        Me.txtModifyNo.Location = New System.Drawing.Point(120, 37)
        Me.txtModifyNo.Name = "txtModifyNo"
        Me.txtModifyNo.ReadOnly = True
        Me.txtModifyNo.Size = New System.Drawing.Size(82, 12)
        Me.txtModifyNo.TabIndex = 76
        Me.txtModifyNo.TabStop = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtModifyNo)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.txtCpnoName)
        Me.GroupBox1.Controls.Add(Me.txtContract)
        Me.GroupBox1.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(16, 50)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(624, 61)
        Me.GroupBox1.TabIndex = 79
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "契約情報"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label4.Location = New System.Drawing.Point(10, 21)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(104, 12)
        Me.Label4.TabIndex = 51
        Me.Label4.Text = "お客様名（CPNO）"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label6.Location = New System.Drawing.Point(10, 40)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(57, 12)
        Me.Label6.TabIndex = 53
        Me.Label6.Text = "契約順番"
        '
        'BtnRefresh
        '
        Me.BtnRefresh.BackColor = System.Drawing.Color.RoyalBlue
        Me.BtnRefresh.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnRefresh.ForeColor = System.Drawing.Color.White
        Me.BtnRefresh.Location = New System.Drawing.Point(503, 460)
        Me.BtnRefresh.Name = "BtnRefresh"
        Me.BtnRefresh.Size = New System.Drawing.Size(133, 44)
        Me.BtnRefresh.TabIndex = 265
        Me.BtnRefresh.Text = "ﾌｧｲﾙ名ﾘﾌﾚｯｼｭ"
        Me.BtnRefresh.UseVisualStyleBackColor = False
        '
        'btnLogOut
        '
        Me.btnLogOut.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnLogOut.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogOut.ForeColor = System.Drawing.Color.White
        Me.btnLogOut.Location = New System.Drawing.Point(12, 460)
        Me.btnLogOut.Name = "btnLogOut"
        Me.btnLogOut.Size = New System.Drawing.Size(133, 44)
        Me.btnLogOut.TabIndex = 264
        Me.btnLogOut.Text = "ログアウト"
        Me.btnLogOut.UseVisualStyleBackColor = False
        '
        'btnReturn
        '
        Me.btnReturn.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnReturn.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReturn.ForeColor = System.Drawing.Color.White
        Me.btnReturn.Location = New System.Drawing.Point(163, 460)
        Me.btnReturn.Name = "btnReturn"
        Me.btnReturn.Size = New System.Drawing.Size(133, 44)
        Me.btnReturn.TabIndex = 263
        Me.btnReturn.Text = "メニューへ"
        Me.btnReturn.UseVisualStyleBackColor = False
        '
        'UCnt_Pal00011
        '
        Me.UCnt_Pal00011.BackColor = System.Drawing.Color.Teal
        Me.UCnt_Pal00011.BackColro2 = System.Drawing.Color.PaleTurquoise
        Me.UCnt_Pal00011.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UCnt_Pal00011.ForeColor = System.Drawing.Color.White
        Me.UCnt_Pal00011.Location = New System.Drawing.Point(0, 0)
        Me.UCnt_Pal00011.Name = "UCnt_Pal00011"
        Me.UCnt_Pal00011.Size = New System.Drawing.Size(653, 44)
        Me.UCnt_Pal00011.TabIndex = 32
        Me.UCnt_Pal00011.TitleText = "OIO BAMA Client エクスポート EXCEL→CSV変換 / インポート CSV→EXCEL変換"
        '
        'Frm_NewImportExport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(652, 512)
        Me.ControlBox = False
        Me.Controls.Add(Me.BtnRefresh)
        Me.Controls.Add(Me.btnLogOut)
        Me.Controls.Add(Me.btnReturn)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.TabImportExport)
        Me.Controls.Add(Me.txtCustomerName)
        Me.Controls.Add(Me.UCnt_Pal00011)
        Me.Controls.Add(Me.txtCpno)
        Me.MaximizeBox = False
        Me.Name = "Frm_NewImportExport"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "OIO BAMA Client "
        Me.TabImportExport.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents UCnt_Pal00011 As MUSE.UserControl.UCnt_Pal0001
    Friend WithEvents TabImportExport As System.Windows.Forms.TabControl
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents btnExPayment As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents txtExPayment As System.Windows.Forms.TextBox
    Friend WithEvents lblExPayment As System.Windows.Forms.Label
    Friend WithEvents BtnExportGo As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents lblInPaymentSheet As System.Windows.Forms.Label
    Friend WithEvents txtInPaymentSheet As System.Windows.Forms.TextBox
    Friend WithEvents btnImportMdb As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents txtContract As System.Windows.Forms.TextBox
    Friend WithEvents txtCpnoName As System.Windows.Forms.TextBox
    Friend WithEvents txtCpno As System.Windows.Forms.TextBox
    Friend WithEvents txtCustomerName As System.Windows.Forms.TextBox
    Friend WithEvents txtModifyNo As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents btnLogOut As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents btnReturn As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents BtnDispExplorer As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents lblPsExUpdate As System.Windows.Forms.Label
    Friend WithEvents lblPsInUpdate As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents BtnRefresh As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents lnkURL As System.Windows.Forms.LinkLabel
    Friend WithEvents btnImportCsvMdb As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents btnImportCsv As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents btnDirectImport As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents rbPsdS As System.Windows.Forms.RadioButton
    Friend WithEvents rbPsdF As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents rbPsK As System.Windows.Forms.RadioButton
    Friend WithEvents rbPsI As System.Windows.Forms.RadioButton
    Friend WithEvents rbPsP As System.Windows.Forms.RadioButton
    Friend WithEvents rbPsS As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
End Class
