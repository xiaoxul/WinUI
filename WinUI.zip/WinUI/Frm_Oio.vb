Imports System.Text
Imports System.IO
Imports System.Reflection
Imports Microsoft.Office.Interop
Imports MUSE.Utility
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.SharedStructure
Imports MUSE.Utility.UserDataSet
Imports MUSE.Utility.UserDataTable.Master
Imports MUSE.Utility.UserDataTable.Transaction
Imports MUSE.Utility.UserDataTable.Work
Imports MUSE.Utility.UserMessageBox
Imports MUSE.Utility.UserException
Imports MUSE.Utility.XmlClass.Parameter
Imports MUSE.Utility.XmlClass.SystemInfo
Imports MUSE.Controller
Imports MUSE.Utility.OioBamaCommmon


'==========================================================================
'�N���X���FFrm_Oio
'�T    �v�FFrm_Oio�N���X
'��    ���FFrm_Oio���
'��    ���F[Ver1.0]  2007/06/18  �����@���K
'==========================================================================
Public Class Frm_Oio
    Inherits System.Windows.Forms.Form

#Region " Windows �t�H�[�� �f�U�C�i�Ő������ꂽ�R�[�h "

    Dim h As Object

    Public Sub New()
        MyBase.New()

        ' ���̌Ăяo���� Windows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
        InitializeComponent()

        ' InitializeComponent() �Ăяo���̌�ɏ�������ǉ����܂��B

    End Sub

    ' Form �́A�R���|�[�l���g�ꗗ�Ɍ㏈�������s���邽�߂� dispose ���I�[�o�[���C�h���܂��B
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    ' Windows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
    Private components As System.ComponentModel.IContainer

    ' ���� : �ȉ��̃v���V�[�W���́AWindows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
    'Windows �t�H�[�� �f�U�C�i���g���ĕύX���Ă��������B  
    ' �R�[�h �G�f�B�^���g���ĕύX���Ȃ��ł��������B
    Friend WithEvents UCnt_Pal00012 As MUSE.UserControl.UCnt_Pal0001
    Friend WithEvents Btn_Close As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_OutputExcel As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Btn_Edit_Project As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Clear_Project As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Add_Project As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Up_Project As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Down_Project As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_ReadFormInfo As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_SaveFormInfo As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents lblSuffixNo As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents lblContractName As System.Windows.Forms.Label
    Friend WithEvents lblCPNO As System.Windows.Forms.Label
    Friend WithEvents lblContractNo As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Lst_Project As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader7 As System.Windows.Forms.ColumnHeader
    Friend WithEvents RadIsat As System.Windows.Forms.RadioButton
    Friend WithEvents Chk_Ma As System.Windows.Forms.CheckBox
    Friend WithEvents RadKousei As System.Windows.Forms.RadioButton
    Friend WithEvents GrpExistItsma As System.Windows.Forms.GroupBox
    Friend WithEvents btn_Del As MUSE.UserControl.UCnt_Btn0001
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Chk_Ma = New System.Windows.Forms.CheckBox()
        Me.GrpExistItsma = New System.Windows.Forms.GroupBox()
        Me.RadKousei = New System.Windows.Forms.RadioButton()
        Me.RadIsat = New System.Windows.Forms.RadioButton()
        Me.Lst_Project = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader5 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader6 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader7 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Btn_Edit_Project = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Clear_Project = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Add_Project = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Up_Project = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Down_Project = New MUSE.UserControl.UCnt_Btn0001()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.lblSuffixNo = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.lblContractName = New System.Windows.Forms.Label()
        Me.lblCPNO = New System.Windows.Forms.Label()
        Me.lblContractNo = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btn_Del = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Close = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_SaveFormInfo = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_ReadFormInfo = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_OutputExcel = New MUSE.UserControl.UCnt_Btn0001()
        Me.UCnt_Pal00012 = New MUSE.UserControl.UCnt_Pal0001()
        Me.GroupBox4.SuspendLayout()
        Me.GrpExistItsma.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Chk_Ma)
        Me.GroupBox4.Controls.Add(Me.GrpExistItsma)
        Me.GroupBox4.Controls.Add(Me.Lst_Project)
        Me.GroupBox4.Controls.Add(Me.Btn_Edit_Project)
        Me.GroupBox4.Controls.Add(Me.Btn_Clear_Project)
        Me.GroupBox4.Controls.Add(Me.Btn_Add_Project)
        Me.GroupBox4.Controls.Add(Me.Btn_Up_Project)
        Me.GroupBox4.Controls.Add(Me.Btn_Down_Project)
        Me.GroupBox4.Location = New System.Drawing.Point(26, 156)
        Me.GroupBox4.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Padding = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.GroupBox4.Size = New System.Drawing.Size(768, 232)
        Me.GroupBox4.TabIndex = 6
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "�Č��o�^ @"
        '
        'Chk_Ma
        '
        Me.Chk_Ma.AutoSize = True
        Me.Chk_Ma.Location = New System.Drawing.Point(283, 168)
        Me.Chk_Ma.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Chk_Ma.Name = "Chk_Ma"
        Me.Chk_Ma.Size = New System.Drawing.Size(65, 16)
        Me.Chk_Ma.TabIndex = 1
        Me.Chk_Ma.Text = "����MA"
        '
        'GrpExistItsma
        '
        Me.GrpExistItsma.Controls.Add(Me.RadKousei)
        Me.GrpExistItsma.Controls.Add(Me.RadIsat)
        Me.GrpExistItsma.Location = New System.Drawing.Point(286, 168)
        Me.GrpExistItsma.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.GrpExistItsma.Name = "GrpExistItsma"
        Me.GrpExistItsma.Padding = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.GrpExistItsma.Size = New System.Drawing.Size(175, 46)
        Me.GrpExistItsma.TabIndex = 2
        Me.GrpExistItsma.TabStop = False
        '
        'RadKousei
        '
        Me.RadKousei.AutoSize = True
        Me.RadKousei.Location = New System.Drawing.Point(94, 22)
        Me.RadKousei.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.RadKousei.Name = "RadKousei"
        Me.RadKousei.Size = New System.Drawing.Size(59, 16)
        Me.RadKousei.TabIndex = 1
        Me.RadKousei.Text = "���\��"
        '
        'RadIsat
        '
        Me.RadIsat.AutoSize = True
        Me.RadIsat.Location = New System.Drawing.Point(11, 22)
        Me.RadIsat.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.RadIsat.Name = "RadIsat"
        Me.RadIsat.Size = New System.Drawing.Size(72, 16)
        Me.RadIsat.TabIndex = 0
        Me.RadIsat.Text = "ISAT����"
        '
        'Lst_Project
        '
        Me.Lst_Project.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader4, Me.ColumnHeader5, Me.ColumnHeader6, Me.ColumnHeader7})
        Me.Lst_Project.FullRowSelect = True
        Me.Lst_Project.GridLines = True
        Me.Lst_Project.Location = New System.Drawing.Point(8, 18)
        Me.Lst_Project.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Lst_Project.Name = "Lst_Project"
        Me.Lst_Project.Size = New System.Drawing.Size(709, 145)
        Me.Lst_Project.TabIndex = 265
        Me.Lst_Project.UseCompatibleStateImageBehavior = False
        Me.Lst_Project.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "�Č��ԍ�"
        Me.ColumnHeader1.Width = 90
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "�Č���"
        Me.ColumnHeader2.Width = 130
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "�����N��"
        Me.ColumnHeader4.Width = 90
        '
        'ColumnHeader5
        '
        Me.ColumnHeader5.Text = "�����J�n�N��"
        Me.ColumnHeader5.Width = 90
        '
        'ColumnHeader6
        '
        Me.ColumnHeader6.Text = "�����I���N��"
        Me.ColumnHeader6.Width = 90
        '
        'ColumnHeader7
        '
        Me.ColumnHeader7.Text = "�ێ烌�x��"
        Me.ColumnHeader7.Width = 90
        '
        'Btn_Edit_Project
        '
        Me.Btn_Edit_Project.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Edit_Project.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Edit_Project.ForeColor = System.Drawing.Color.White
        Me.Btn_Edit_Project.Location = New System.Drawing.Point(567, 172)
        Me.Btn_Edit_Project.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Btn_Edit_Project.Name = "Btn_Edit_Project"
        Me.Btn_Edit_Project.Size = New System.Drawing.Size(76, 32)
        Me.Btn_Edit_Project.TabIndex = 4
        Me.Btn_Edit_Project.Text = "�ύX"
        Me.Btn_Edit_Project.UseVisualStyleBackColor = False
        '
        'Btn_Clear_Project
        '
        Me.Btn_Clear_Project.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Clear_Project.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Clear_Project.ForeColor = System.Drawing.Color.White
        Me.Btn_Clear_Project.Location = New System.Drawing.Point(651, 172)
        Me.Btn_Clear_Project.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Btn_Clear_Project.Name = "Btn_Clear_Project"
        Me.Btn_Clear_Project.Size = New System.Drawing.Size(76, 32)
        Me.Btn_Clear_Project.TabIndex = 5
        Me.Btn_Clear_Project.Text = "�N���A"
        Me.Btn_Clear_Project.UseVisualStyleBackColor = False
        '
        'Btn_Add_Project
        '
        Me.Btn_Add_Project.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Add_Project.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Add_Project.ForeColor = System.Drawing.Color.White
        Me.Btn_Add_Project.Location = New System.Drawing.Point(483, 172)
        Me.Btn_Add_Project.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Btn_Add_Project.Name = "Btn_Add_Project"
        Me.Btn_Add_Project.Size = New System.Drawing.Size(76, 32)
        Me.Btn_Add_Project.TabIndex = 3
        Me.Btn_Add_Project.Text = "�o�^"
        Me.Btn_Add_Project.UseVisualStyleBackColor = False
        '
        'Btn_Up_Project
        '
        Me.Btn_Up_Project.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Up_Project.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Up_Project.ForeColor = System.Drawing.Color.White
        Me.Btn_Up_Project.Location = New System.Drawing.Point(727, 116)
        Me.Btn_Up_Project.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Btn_Up_Project.Name = "Btn_Up_Project"
        Me.Btn_Up_Project.Size = New System.Drawing.Size(25, 24)
        Me.Btn_Up_Project.TabIndex = 6
        Me.Btn_Up_Project.Text = "��"
        Me.Btn_Up_Project.UseVisualStyleBackColor = False
        '
        'Btn_Down_Project
        '
        Me.Btn_Down_Project.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Down_Project.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Down_Project.ForeColor = System.Drawing.Color.White
        Me.Btn_Down_Project.Location = New System.Drawing.Point(727, 140)
        Me.Btn_Down_Project.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Btn_Down_Project.Name = "Btn_Down_Project"
        Me.Btn_Down_Project.Size = New System.Drawing.Size(25, 24)
        Me.Btn_Down_Project.TabIndex = 7
        Me.Btn_Down_Project.Text = "��"
        Me.Btn_Down_Project.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.lblSuffixNo)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.lblContractName)
        Me.GroupBox1.Controls.Add(Me.lblCPNO)
        Me.GroupBox1.Controls.Add(Me.lblContractNo)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(26, 50)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.GroupBox1.Size = New System.Drawing.Size(768, 101)
        Me.GroupBox1.TabIndex = 264
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "�_����"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label12.Location = New System.Drawing.Point(6, 64)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(70, 12)
        Me.Label12.TabIndex = 53
        Me.Label12.Text = "�_�񏇔Ԗ�"
        '
        'lblSuffixNo
        '
        Me.lblSuffixNo.AutoSize = True
        Me.lblSuffixNo.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblSuffixNo.Location = New System.Drawing.Point(140, 78)
        Me.lblSuffixNo.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblSuffixNo.Name = "lblSuffixNo"
        Me.lblSuffixNo.Size = New System.Drawing.Size(0, 12)
        Me.lblSuffixNo.TabIndex = 54
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label13.Location = New System.Drawing.Point(6, 26)
        Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(104, 12)
        Me.Label13.TabIndex = 51
        Me.Label13.Text = "���q�l���iCPNO�j"
        '
        'lblContractName
        '
        Me.lblContractName.AutoSize = True
        Me.lblContractName.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblContractName.Location = New System.Drawing.Point(140, 59)
        Me.lblContractName.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblContractName.Name = "lblContractName"
        Me.lblContractName.Size = New System.Drawing.Size(0, 12)
        Me.lblContractName.TabIndex = 54
        '
        'lblCPNO
        '
        Me.lblCPNO.AutoSize = True
        Me.lblCPNO.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblCPNO.Location = New System.Drawing.Point(140, 21)
        Me.lblCPNO.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblCPNO.Name = "lblCPNO"
        Me.lblCPNO.Size = New System.Drawing.Size(0, 12)
        Me.lblCPNO.TabIndex = 52
        '
        'lblContractNo
        '
        Me.lblContractNo.AutoSize = True
        Me.lblContractNo.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblContractNo.Location = New System.Drawing.Point(140, 40)
        Me.lblContractNo.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblContractNo.Name = "lblContractNo"
        Me.lblContractNo.Size = New System.Drawing.Size(0, 12)
        Me.lblContractNo.TabIndex = 54
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label3.Location = New System.Drawing.Point(6, 45)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(57, 12)
        Me.Label3.TabIndex = 53
        Me.Label3.Text = "�_�񏇔�"
        '
        'btn_Del
        '
        Me.btn_Del.BackColor = System.Drawing.Color.RoyalBlue
        Me.btn_Del.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Del.ForeColor = System.Drawing.Color.White
        Me.btn_Del.Location = New System.Drawing.Point(152, 410)
        Me.btn_Del.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btn_Del.Name = "btn_Del"
        Me.btn_Del.Size = New System.Drawing.Size(118, 45)
        Me.btn_Del.TabIndex = 10
        Me.btn_Del.Text = "�\�����"
        Me.btn_Del.UseVisualStyleBackColor = False
        '
        'Btn_Close
        '
        Me.Btn_Close.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Close.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Close.ForeColor = System.Drawing.Color.White
        Me.Btn_Close.Location = New System.Drawing.Point(26, 410)
        Me.Btn_Close.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(117, 45)
        Me.Btn_Close.TabIndex = 9
        Me.Btn_Close.Text = "���j���[��"
        Me.Btn_Close.UseVisualStyleBackColor = False
        '
        'Btn_SaveFormInfo
        '
        Me.Btn_SaveFormInfo.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_SaveFormInfo.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_SaveFormInfo.ForeColor = System.Drawing.Color.White
        Me.Btn_SaveFormInfo.Location = New System.Drawing.Point(424, 410)
        Me.Btn_SaveFormInfo.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Btn_SaveFormInfo.Name = "Btn_SaveFormInfo"
        Me.Btn_SaveFormInfo.Size = New System.Drawing.Size(117, 45)
        Me.Btn_SaveFormInfo.TabIndex = 11
        Me.Btn_SaveFormInfo.Text = "�ݒ���@�@�ۑ�"
        Me.Btn_SaveFormInfo.UseVisualStyleBackColor = False
        '
        'Btn_ReadFormInfo
        '
        Me.Btn_ReadFormInfo.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_ReadFormInfo.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_ReadFormInfo.ForeColor = System.Drawing.Color.White
        Me.Btn_ReadFormInfo.Location = New System.Drawing.Point(550, 410)
        Me.Btn_ReadFormInfo.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Btn_ReadFormInfo.Name = "Btn_ReadFormInfo"
        Me.Btn_ReadFormInfo.Size = New System.Drawing.Size(117, 45)
        Me.Btn_ReadFormInfo.TabIndex = 12
        Me.Btn_ReadFormInfo.Text = "�ݒ���@�@�Ǎ�"
        Me.Btn_ReadFormInfo.UseVisualStyleBackColor = False
        '
        'Btn_OutputExcel
        '
        Me.Btn_OutputExcel.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_OutputExcel.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_OutputExcel.ForeColor = System.Drawing.Color.White
        Me.Btn_OutputExcel.Location = New System.Drawing.Point(676, 410)
        Me.Btn_OutputExcel.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Btn_OutputExcel.Name = "Btn_OutputExcel"
        Me.Btn_OutputExcel.Size = New System.Drawing.Size(117, 45)
        Me.Btn_OutputExcel.TabIndex = 13
        Me.Btn_OutputExcel.Text = "Payment���f"
        Me.Btn_OutputExcel.UseVisualStyleBackColor = False
        '
        'UCnt_Pal00012
        '
        Me.UCnt_Pal00012.BackColor = System.Drawing.Color.Teal
        Me.UCnt_Pal00012.BackColro2 = System.Drawing.Color.PaleTurquoise
        Me.UCnt_Pal00012.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UCnt_Pal00012.ForeColor = System.Drawing.Color.White
        Me.UCnt_Pal00012.Location = New System.Drawing.Point(0, 0)
        Me.UCnt_Pal00012.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.UCnt_Pal00012.Name = "UCnt_Pal00012"
        Me.UCnt_Pal00012.Size = New System.Drawing.Size(824, 44)
        Me.UCnt_Pal00012.TabIndex = 27
        Me.UCnt_Pal00012.TitleText = "OIO BAMA Client  @"
        '
        'Frm_Oio
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(827, 484)
        Me.Controls.Add(Me.btn_Del)
        Me.Controls.Add(Me.Btn_Close)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Btn_SaveFormInfo)
        Me.Controls.Add(Me.Btn_ReadFormInfo)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.Btn_OutputExcel)
        Me.Controls.Add(Me.UCnt_Pal00012)
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.MaximizeBox = False
        Me.Name = "Frm_Oio"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "OIO BAMA Client"
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GrpExistItsma.ResumeLayout(False)
        Me.GrpExistItsma.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region " �萔 "
    '������
    Private Const COMBOTABLE_COLUMN_NAME_TEXT = "text"
    Private Const COMBOTABLE_COLUMN_NAME_VALUE = "value"
    Private Const STR_CONTRACT_TYPE_NEW = "OIO�@�V�K"
    Private Const STR_CONTRACT_TYPE_CHANGE = "OIO�@�ύX�_��"
    Private Const STR_PROJECT_TYPE_STD = "�ʏ�"
    Private Const STR_PROJECT_TYPE_MA = "����MA"
    Private Const STR_LOADING As String = "OIO�N�����E�E�E"
    Private Const STR_MESSAGE_READ_MASTER As String = "�}�X�^�f�[�^��Ǎ����ł��B"
    Private Const STR_CREATING As String = "�쐬���E�E�E"
    Private Const STR_MESSAGE_CREATE_BIDPACKAGE As String = "BidPackage���쐬���ł��B"
    Private Const STR_BIDPACKAGE As String = "BidPackage"
    Private Const STR_TESTING As String = "���������ؒ�������"
    Private Const STR_CREATING_FILE As String = "�������E�E�E"
    Private Const STR_MESSAGE_CREATE_FILE As String = "�t�@�C���𓝍����ł��B"
    Private Const STR_MESSAGE_FILE As String = "�t�@�C�����쐬���ł��B"

    '============================== 
    'EXCEL�s�ʒu
    '==============================
    'PaymentLine �f�[�^�J�n�s
    Private Const EXCEL_PAYMENTLINEDATE_OUTROW As Integer = 6
    'EXCEL�̍ŏI�s
    Private Const EXCEL_MAX_ROW As Integer = 65536

#End Region

#Region "�ϐ�"
    ''���͂̃_�C�A�����O���
    Private IMPORTDIALOG_DEFULT_PATH As String = "../csvtemp/"

    Private strPaymentSheet As String()
    Private strDetail As String()
    Private ReferencePath As String

    Private _CPNO As String = ""
    Private _CONTRACT As String = ""
    Private _MODIFY As String = ""

#End Region

#Region " �����o�ϐ� "

    Dim param As New OioParameter
    Dim htProject As New Hashtable
    Private bIgnoreEvent As Boolean

    '�o�̓t�H���_
    Private OUTPUT_LOGFOLDER As String

#Region "�o�͏󋵃��O"
    'log4net�I�u�W�F�N�g
    Private iLog As log4net.ILog = _
        log4net.LogManager.GetLogger( _
        System.Reflection.MethodBase.GetCurrentMethod().DeclaringType)
#End Region

    Private _psLine As New OioProject
#End Region

#Region "�R���X�g���N�^"
    Sub New(ByVal psLine As OioProject)
        InitializeComponent()
        Me._psLine = psLine

        '�Œ�p�X�𑊑΃p�X�֕ύX
        OUTPUT_LOGFOLDER = FileManager.GetLocalFolderPath(CommonConstant.FOLDERNAME_LOG)
    End Sub
#End Region

#Region " �C�x���g�n���h�� "

    '--------------------------------------------------------
    '���\�b�h���FFrm_Oio_Load
    '�T    �v  �F��ʃ��[�h����
    '��    ��  �F��ʃ��[�h�������s��
    '��    ��                 �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Frm_Oio_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


        Try
            Me.bIgnoreEvent = False
            '==============================
            '������������
            '==============================

            Me.Cursor = Cursors.WaitCursor

            '���s���{Version
            Me.Text = CommonVariable.OBAMATITLE

            '�����\���p�̃f�[�^���擾
            Me.SetInitialData()

            Me.Cursor = Cursors.Default

            '�V�X�e�����Ǎ�
            Dim info As SystemInfo = FileReader.ReadSystemInfo()
            If info.TestFlg = CommonConstant.ParamCheck.Yes Then
                '���ؗp�̏ꍇ
                Me.UCnt_Pal00012.BackColor = Color.DimGray
                Me.UCnt_Pal00012.BackColro2 = Color.Silver
                Me.UCnt_Pal00012.TitleText = Me.UCnt_Pal00012.TitleText.Replace(Space(1) & Me.STR_TESTING, String.Empty) & Space(1) & Me.STR_TESTING
            End If

        Catch ex As MuseException
            Me.Activate()
            Me.Cursor = Cursors.Default
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
            Me.Close()
        Catch ex As Exception
            Me.Activate()
            Me.Cursor = Cursors.Default
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
            Me.Close()
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_OutputExcelt_Click
    '�T    �v  �FBtn_OutputExcel�N���b�N����
    '��    ��  �FBtn_OutputExcel�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_OutputExcel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_OutputExcel.Click

        '�����̊m�F���b�Z�[�W��\������B
        If MuseMessageBox.ShowQuestion(FileReader.GetMessage("MSG_0332"), Me.Text) = DialogResult.OK Then

            '�������_�C�A���O��`
            Dim waitDialog As New Frm_WaitDialog
            Dim prjSrc() As OioProject
            Dim arAddFileNames As New ArrayList

            Try
                If Me.Lst_Project.Items.Count = 0 Then
                    Throw New MuseException(FileReader.GetMessage("MSG_0002"))
                End If

                'MasterMDB���݃`�F�b�N
                Dim ofm As New OioFileManage
                Dim strErrMsg As String
                If ofm.CheckExistsMdb(OioFileManage.enmMdbType.Master, CommonVariable.MdbPW, strErrMsg) = False Then
                    Call MuseMessageBox.ShowError(strErrMsg, Me.Text)
                    Exit Sub
                End If

                ''�������f�ς݂��ް������݂��邩����
                If Me._psLine.isNLine = True Then
                    If ChkBPExchange(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me._psLine.FileName) Then
                        Throw New MuseException(FileReader.GetMessage("MSG_0323"))
                    End If
                End If

                '�t�@�C�����ݒ�
                Dim bidPackageName As New StringBuilder
                bidPackageName.Append(CommonConstant.STR_SHARP)
                bidPackageName.Append(CommonVariable.CPNO)
                bidPackageName.Append(CommonConstant.STR_UNDERBAR)
                bidPackageName.Append(CommonVariable.CONTRACTNO.ToString.PadLeft(3, "0c"))
                bidPackageName.Append(CommonConstant.STR_UNDERBAR)
                bidPackageName.Append("Payment")
                bidPackageName.Append(CommonConstant.STR_UNDERBAR)
                bidPackageName.Append(DateTime.Now.ToString("yyMMdd"))
                bidPackageName.Append(CommonConstant.STR_UNDERBAR)
                bidPackageName.Append(DateTime.Now.ToString("HHmm"))

                '���O�t�H���_(C:\OBAMA-Client\Log)�ɏo��
                Dim strFileName As String = OUTPUT_LOGFOLDER & "\" & bidPackageName.ToString & "xls"
                Me.Refresh()
                Me.Cursor = Cursors.WaitCursor

                '�������_�C�A���O�\��
                waitDialog.Text = Me.STR_CREATING
                waitDialog.lbl_Message.Text = STR_MESSAGE_FILE
                waitDialog.Pic_Excel.Visible = True
                waitDialog.ProgressMin = 0
                waitDialog.ProgressMax = 7
                waitDialog.ProgressStep = 1
                waitDialog.ProgressValue = 0
                waitDialog.Show()
                waitDialog.Refresh()

                '�o�͏󋵃��O�̃t�@�C������ݒ肷��
                Dim strLogFile As String = System.IO.Path.GetDirectoryName(strFileName) & System.IO.Path.DirectorySeparatorChar
                Dim logRepositories() As log4net.Repository.ILoggerRepository = log4net.LogManager.GetAllRepositories()

                '��`���擾
                For Each repository As log4net.Repository.ILoggerRepository In logRepositories

                    '�A�y���_���X�g����㏑���Ώۂ��擾����
                    For Each appender As log4net.Appender.IAppender In repository.GetAppenders()
                        Dim fileAppender As log4net.Appender.FileAppender = DirectCast(appender, log4net.Appender.FileAppender)
                        If fileAppender.Name.Equals("OutputBidPackageAppender") Then
                            'File�p�����[�^���㏑��
                            strLogFile = strLogFile & System.IO.Path.GetFileNameWithoutExtension(strFileName) & "_�o�͏�" & CommonConstant.EXTENSION_LOG
                            fileAppender.File = strLogFile
                            fileAppender.LockingModel = New log4net.Appender.FileAppender.MinimalLock
                            '�ݒ��L���ɂ���
                            fileAppender.ActivateOptions()
                            Exit For
                        End If
                    Next
                Next

                '==============================
                '���p�����[�^�t�@�C���쐬������
                '==============================
                '��ʓ��͒l�擾
                Me.GetInputValue()
                '�o�̓t�@�C�������p�����[�^�ɒǉ�
                Me.param.OutputFile = strFileName
                Me.param.LogFile = Path.ChangeExtension(strFileName, CommonConstant.EXTENSION_LOG)
                Me.param.PramFile = Path.ChangeExtension(strFileName, CommonConstant.EXTENSION_XML)

                'InputFile(Config)�𐔗ʂŕ���
                Dim htProjectSrc As New Hashtable
                Call SplitInputFile(prjSrc, arAddFileNames)

                Me.WriteParameterFile(param)

                '==============================
                '���T�Z���� (Excel)�쐬������
                '==============================
                Dim result As Boolean
                Dim configNMTable As DataTable
                result = Me.OutputEstimate(waitDialog, configNMTable)
                '�����t�@�C�������ɖ߂�
                Call InputConfigReinstate(prjSrc)
                If result = False Then
                    waitDialog.Close()
                    Me.Refresh()
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If

                waitDialog.Close()

                Me.Refresh()
                Me.Cursor = Cursors.Default

            Catch ex As MuseException
                Me.Activate()
                waitDialog.Close()
                Me.Cursor = Cursors.Default
                MuseMessageBox.ShowWarning(ex.Message, sender.Text)
                Exit Sub
            Catch ex As Exception
                Me.Activate()
                waitDialog.Close()
                Me.Cursor = Cursors.Default
                FileWriter.WriteErrorLog(ex)
                MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
                Exit Sub
            Finally
                Call DeleteAddFile(arAddFileNames)
            End Try

            '-------------------'
            '''CSV�\���捞 �J�n
            '-------------------'
            Dim ErrMSG_001 As String = FileReader.GetMessage("MSG_0273")    ''PaymentSheet�����������ɃG���[���������܂����B�G���[���O���Q�Ƃ��Ă��������B
            Dim OutExcel As OutputExcel = New OutputExcel
            Dim PaymentCount As Integer = 0
            Dim PaymentDetailCount As Integer = 0
            Dim strCpNo As String = ""
            Dim strContractNo As String = ""
            Dim strSuffixNo As String = ""
            Dim CPNOhide As String = CommonVariable.CPNO

            If ExcelWrite.ChkPaymentErr(Me.Name, sender.Name, _
                            CommonVariable.CPNO, CommonVariable.CONTRACTNO) = False Then
                Exit Sub
            End If

            System.Environment.CurrentDirectory = Application.StartupPath
            ReferencePath = System.IO.Path.GetFullPath(IMPORTDIALOG_DEFULT_PATH & "\" & _
                                                                 CPNOhide.PadLeft(8, "0c") & "_" & _
                                                                 Convert.ToInt32(Me.lblContractNo.Text).ToString("000"))

            If Directory.Exists(ReferencePath) = False Then
                MsgBox(FileReader.GetMessage("MSG_0261"), MsgBoxStyle.Critical, Me.Name)
                Exit Sub
            End If

            strPaymentSheet = System.IO.Directory.GetFiles(ReferencePath, "PS_" & "*" & ".csv", System.IO.SearchOption.TopDirectoryOnly)
            strDetail = System.IO.Directory.GetFiles(ReferencePath, "PSD_" & "*" & ".csv", System.IO.SearchOption.TopDirectoryOnly)

            '�������_�C�A���O��`
            Dim waitDialog2 As New Frm_WaitDialog
            Dim OUTERR As New OutputErrorList
            strCpNo = Me.lblCPNO.Text
            strContractNo = Me.lblContractNo.Text

            '�G���[���O�����ݒ�
            OUTERR.CpNo = strCpNo
            OUTERR.ContractNo = strContractNo
            OutExcel.CpNo = strCpNo
            OutExcel.ContractNo = strContractNo

            ''�J�n�����̃��O���o��
            OUTERR.OutputErrorList2("START", "BPMakeExchange", , , True)

            '�������_�C�A���O�\��
            Call InitWaitDialog(waitDialog2)
            waitDialog2.Show()
            waitDialog2.Refresh()

            Dim xlApp As New Excel.Application
            Dim xlPSBook As Excel.Workbook
            Dim xlPSSheet As Excel.Worksheet
            Dim xlDetailSheet As Excel.Worksheet

            Try
                ''Excel�t�@�C�����ɕt������������擾
                Dim createTime As String
                createTime = Now.ToString("yyyyMMdd_HHmmss")

                ''                 ���ȉ��AExcel�̼�ď����擾
                ''--------------------------------------------------------------------
                xlApp.DisplayAlerts = False
                xlApp.EnableEvents = False
                xlPSBook = OpenPSBook(xlApp)
                xlApp.Calculation = Excel.XlCalculation.xlCalculationManual
                Call SetWorkSheet(xlPSBook, xlPSSheet, xlDetailSheet)


                ''                 ���ȉ��ACSV�t�@�C���̓Ǎ�����
                ''--------------------------------------------------------------------
                '�ݒ�ύX�̉\������
                PaymentCount = OutExcel.OutPutExcelFromCsvTempPs(xlPSSheet, _
                                                                 OUTERR, _
                                                                 Me.strPaymentSheet, _
                                                                 1)

                If PaymentCount = -1 Then
                    MsgBox(ErrMSG_001, MsgBoxStyle.Exclamation)
                    Exit Sub
                End If

                ''�ڍ׍쐬����(EXCEL)
                PaymentDetailCount = OutExcel.OutPutExcelPaymentDetailSheet_Temp(xlDetailSheet, _
                                                                 OUTERR, _
                                                                 Me.strDetail)

                If PaymentDetailCount = -1 Then
                    MsgBox(ErrMSG_001, MsgBoxStyle.Exclamation)
                    Exit Sub
                End If

                ''WorkBook�̕ۑ�
                Dim ofm As New OioFileManage
                Dim savePSPath As String
                savePSPath = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO) & _
                             ofm.GetNewPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO, createTime)

                Call xlPSBook.SaveAs(Filename:=savePSPath, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

                ''                 ���ȉ��ASuffix�̍X�V/BK�t�@�C���̍쐬����
                ''--------------------------------------------------------------------
                ''�ESuffix��UpDate����B
                ''�ECsv��BK�t�@�C�����쐬����B
                ''�E���������s�����ꍇ�ASuffixUp����Exceļ�ق��폜
                Try
                    '��VBActNMList�ɓ���
                    Call ExcelWrite.KickVBASuffixUpAct(xlApp, xlPSBook, ExcelWrite.VBActNMList.�������f, CommonVariable.USERID, CommonVariable.USERPW)

                    ''�v���p�e�B�Ƀt�@�C�������L�� str
                    'Dim obj As Object
                    'Dim fso As Object

                    'fso = CreateObject("Scripting.FileSystemObject")
                    'obj = GetObject(xlPSBook.Path & "\" & xlPSBook.Name)

                    'obj.BuiltinDocumentProperties("Category") = xlPSBook.Name
                    'obj.save()

                    'obj = Nothing
                    'fso = Nothing

                    Dim properties As Object
                    properties = xlPSBook.BuiltinDocumentProperties
                    properties.Item("Category").value = xlPSBook.Name
                    xlPSBook.Save()

                    properties = Nothing
                    ''�v���p�e�B�Ƀt�@�C�������L�� end


                    ''BK�t�@�C���쐬�@Payment csv
                    Call CreateBKPaymentCsvFile(strPaymentSheet)

                    ''BK�t�@�C���쐬�@PaymentDetail csv
                    Call CreateBKPaymentDetailCsvFile(strDetail)

                    ''�Ǘ��ԍ�_DSP0800-01 Str
                Catch ex As Exception
                    Call DeleteSuffixUpExcelFile(createTime)
                    Throw ex

                End Try

                Dim strFileNamePayment As String
                strFileNamePayment = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO) & _
                                     ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
                Call OutputExcelLog(strFileNamePayment, strPaymentSheet(0))

                ''�������b�Z�[�W�̕\��
                Dim MsgStr As String
                MsgStr = GetExitMessage(PaymentCount, PaymentDetailCount)
                MsgBox(MsgStr, _
                       MsgBoxStyle.Information, _
                       Me.Text)

            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, Me.Text)

            Finally
                ''Excel�̉��
                xlApp.DisplayAlerts = False
                xlApp.EnableEvents = False
                ExcelObjRelease.ReleaseExcelObj(xlPSSheet, ExcelObjRelease.OBJECT_NOTHING)
                ExcelObjRelease.ReleaseExcelObj(xlDetailSheet, ExcelObjRelease.OBJECT_NOTHING)
                If IsNothing(xlPSBook) = False Then
                    Call xlPSBook.Close()
                End If
                ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
                If IsNothing(xlApp) = False Then
                    Call xlApp.Quit()
                End If
                ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
                GC.Collect()

                Call waitDialog2.Close()
                OUTERR.OutputErrorList2("END", "BPMakeExchange", , , False)

            End Try
            '---------------------'
            '''CSV�\���捞 �I���
            '---------------------'

        End If
    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Add_Project_Click
    '�T    �v  �FBtn_Add_Project�N���b�N����
    '��    ��  �FBtn_Add_Project�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Add_Project_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Add_Project.Click

        Try

            '��ۼު�Č� N�s=1��/�\���捞=���� 
            If Me._psLine.isNLine = True Then
                If Lst_Project.Items.Count = 1 Then
                    MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0083"), Me.Text)
                    Exit Sub
                End If
            End If

            'MasterMDB���݃`�F�b�N
            Dim ofm As New OioFileManage
            Dim strErrMsg As String
            If ofm.CheckExistsMdb(OioFileManage.enmMdbType.Master, CommonVariable.MdbPW, strErrMsg) = False Then
                Call MuseMessageBox.ShowError(strErrMsg, Me.Text)
                Exit Sub
            End If

            '==============================
            '���v���W�F�N�g�o�^��ʕ\����
            '==============================
            Dim oioProject As New Frm_Oio_Project(Me._psLine)
            oioProject.Project = New OioProject
            If Me.Chk_Ma.Checked = True Then
                If Me.RadIsat.Checked = True Then
                    oioProject.Project.ProjectType = CommonConstant.ParamProjectType.MaIsat
                Else
                    oioProject.Project.ProjectType = CommonConstant.ParamProjectType.MaEx
                End If
            Else
                oioProject.Project.ProjectType = CommonConstant.ParamProjectType.Std
            End If
            '1647 str
            oioProject.Project.Project_Kbn = 1
            '1647 ebd
            oioProject.ShowDialog()

            If Not oioProject.Project.ProjectName Is Nothing Then '�v���W�F�N�g����Nothing�̏ꍇ�̓L�����Z���������ꂽ���̂Ƃ���B
                oioProject.Project.selProjctNO = Me.Lst_Project.Items.Count
                Me.htProject.Add(Me.Lst_Project.Items.Count, oioProject.Project)
                '==============================
                '���v���W�F�N�g���X�g��������
                '==============================
                Me.InitialProjectData()
                Me.Lst_Project.Items(Me.Lst_Project.Items.Count - 1).Selected = True
                Me.Lst_Project.Select()
            End If

        Catch ex As MuseException
            Me.Activate()
            Me.Cursor = Cursors.Default
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            Me.Cursor = Cursors.Default
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Edit_Project_Click
    '�T    �v  �FBtn_Edit_Project�N���b�N����
    '��    ��  �FBtn_Edit_Project�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Edit_Project_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Edit_Project.Click

        Try

            If Me.Lst_Project.SelectedItems.Count = 0 Then
                Throw New MuseException(FileReader.GetMessage("MSG_0002"))
            End If

            'MasterMDB���݃`�F�b�N
            Dim ofm As New OioFileManage
            Dim strErrMsg As String
            If ofm.CheckExistsMdb(OioFileManage.enmMdbType.Master, CommonVariable.MdbPW, strErrMsg) = False Then
                Call MuseMessageBox.ShowError(strErrMsg, Me.Text)
                Exit Sub
            End If

            '==============================
            '���v���W�F�N�g�o�^��ʕ\����
            '==============================
            Dim selectIndex As Integer
            selectIndex = Me.Lst_Project.SelectedItems.Item(0).Index

            Me._psLine.PlanNo = Me.htProject(selectIndex).PlanNO
            Me._psLine.ProjectName = Me.htProject(selectIndex).ProjectName
            Me._psLine.IntroductYM = CDate(Me.htProject(selectIndex).Introduction).ToString("yyyy/MM")
            Me._psLine.PayStartTime = Me.htProject(selectIndex).PayStartTime
            Me._psLine.PayEndTime = Me.htProject(selectIndex).PayEndTime
            Dim oioProject As New Frm_Oio_Project(Me._psLine)
            oioProject.Project = Me.htProject(selectIndex)

            '1647 str
            oioProject.Project.Project_Kbn = 2
            '1647 ebd

            oioProject.ShowDialog()

            '==============================
            '���v���W�F�N�g���X�g��������
            '==============================
            Me.InitialProjectData()
            Me.Lst_Project.Items(selectIndex).Selected = True
            Me.Lst_Project.Select()

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Clear_Project_Click
    '�T    �v  �FBtn_Clear_Project�N���b�N����
    '��    ��  �FBtn_Clear_Project�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Clear_Project_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear_Project.Click

        Try
            Dim selectIndex As Integer

            If Me.Lst_Project.Items.Count = 0 Then
                Exit Sub
            End If

            If Me.Lst_Project.SelectedItems.Count > 0 Then
                If MuseMessageBox.ShowWarningQuestion(FileReader.GetMessage("MSG_0011"), sender.Text) = DialogResult.Cancel Then
                    Me.Lst_Project.Select()
                    Exit Sub
                End If
                selectIndex = Me.Lst_Project.SelectedItems.Item(0).Index
                '�n�b�V���e�[�u���ĕҏW
                Dim index As Integer
                For index = 0 To Me.htProject.Count - 1
                    If index >= selectIndex Then
                        '����̒l����
                        Me.htProject(index) = Me.htProject(index + 1)
                    End If
                Next
                Dim row As DataRow
                '��ԍŌ�̒l���폜
                Me.htProject.Remove(Me.htProject.Count - 1)
                For index = 0 To Me.htProject.Count - 1
                    Dim oioProj As XmlClass.Parameter.OioProject
                    oioProj = Me.htProject(index)
                    oioProj.selProjctNO = index
                Next
            Else
                If MuseMessageBox.ShowWarningQuestion(FileReader.GetMessage("MSG_0012"), sender.Text) = DialogResult.Cancel Then
                    Me.Lst_Project.Select()
                    Exit Sub
                End If
                '�v���W�F�N�g���X�g�{�b�N�X�̑S�Ă̍��ڃN���A
                Me.htProject.Clear()
            End If

            '==============================
            '���v���W�F�N�g���X�g��������
            '==============================
            Me.InitialProjectData()

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Up_Project_Click
    '�T    �v  �FBtn_Up_Ma�N���b�N����
    '��    ��  �FBtn_Up_Ma�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Up_Project_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Up_Project.Click

        Try
            If Me.Lst_Project.SelectedItems.Count = 0 Then
                Exit Sub
            End If

            Dim selectIndex As Integer
            selectIndex = Me.Lst_Project.SelectedItems.Item(0).Index

            If selectIndex = 0 Then
                Me.Lst_Project.Items(selectIndex).Selected = True
                Me.Lst_Project.Select()
                Exit Sub
            End If

            '==============================
            '���n�b�V���e�[�u���ĕҏW��
            '==============================
            Dim project As OioProject
            '1��̒l��ޔ�
            project = Me.htProject(selectIndex - 1)
            Me.htProject(selectIndex - 1) = Me.htProject(selectIndex)
            Me.htProject(selectIndex) = project

            '==============================
            '���v���W�F�N�g���X�g��������
            '==============================
            Me.InitialProjectData()
            Me.Lst_Project.Items(selectIndex - 1).Selected = True
            Me.Lst_Project.Select()

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Down_Project_Click
    '�T    �v  �FBtn_Down_Ma�N���b�N����
    '��    ��  �FBtn_Down_Ma�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Down_Project_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Down_Project.Click

        Try
            If Me.Lst_Project.SelectedItems.Count = 0 Then
                Exit Sub
            End If

            Dim selectIndex As Integer
            selectIndex = Me.Lst_Project.SelectedItems.Item(0).Index

            If selectIndex = Me.Lst_Project.Items.Count - 1 Then
                Me.Lst_Project.Items(selectIndex).Selected = True
                Me.Lst_Project.Select()
                Exit Sub
            End If

            '==============================
            '���n�b�V���e�[�u���ĕҏW��
            '==============================
            Dim project As OioProject
            '1���̒l��ޔ�
            project = Me.htProject(selectIndex + 1)
            Me.htProject(selectIndex + 1) = Me.htProject(selectIndex)
            Me.htProject(selectIndex) = project

            '==============================
            '���v���W�F�N�g���X�g��������
            '==============================
            Me.InitialProjectData()
            Me.Lst_Project.Items(selectIndex + 1).Selected = True
            Me.Lst_Project.Select()

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_ReadFormInfo_Click
    '�T    �v  �FBtn_ReadFormInfo�N���b�N����
    '��    ��  �FBtn_ReadFormInfo�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_ReadFormInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_ReadFormInfo.Click

        Try
            Dim dialog As OpenFileDialog = New OpenFileDialog
            dialog.Filter = "xml files (*.xml)|*.xml"
            dialog.InitialDirectory = GetFileSeletctDialogInitialPath()

            If dialog.ShowDialog() = DialogResult.OK Then
                '==============================
                '���p�����[�^�t�@�C���Ǎ���
                '==============================
                Dim Lparam As New OioParameter
                Lparam = FileReader.ReadOioParameter(dialog.FileName)
                If Lparam.ProjectList(0).CpNo = CommonVariable.CPNO Then
                    If Me._psLine.isNLine = False Then
                        If Lparam.isNLine = True Then
                            Call MuseMessageBox.ShowWarning(FileReader.GetMessage("MSG_0415"), Me.Text)
                            Exit Sub
                        End If
                    Else
                        If Lparam.isNLine = False Then
                            Call MuseMessageBox.ShowWarning(FileReader.GetMessage("MSG_0416"), Me.Text)
                            Exit Sub
                        End If
                    End If

                    Me.param = Lparam
                    '==============================
                    '���p�����[�^���ݒ聞
                    '==============================
                    Me.SetParamData()
                Else
                    Call MuseMessageBox.ShowWarning(FileReader.GetMessage("MSG_0269"), Me.Text)
                End If
            End If

        Catch ex As MuseException
            Me.Activate()
            Me.Cursor = Cursors.Default
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            Me.Cursor = Cursors.Default
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_SaveFormInfo_Click
    '�T    �v  �FBtn_SaveFormInfo�N���b�N����
    '��    ��  �FBtn_SaveFormInfo�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_SaveFormInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_SaveFormInfo.Click

        Try

            If Me.Lst_Project.Items.Count = 0 Then
                Throw New MuseException(FileReader.GetMessage("MSG_0002"))
            End If

            Dim dialog As SaveFileDialog = New SaveFileDialog
            dialog.Filter = "excel files (*.xml)|*.xml"

            ''takahashi �ǉ�
            dialog.InitialDirectory = GetFileSeletctDialogInitialPath()

            '�t�@�C�����ݒ�
            Dim bidPackageName As New StringBuilder
            bidPackageName.Append(CommonConstant.STR_SHARP)
            bidPackageName.Append(CommonVariable.CPNO)
            bidPackageName.Append(CommonConstant.STR_UNDERBAR)
            bidPackageName.Append(CommonVariable.CONTRACTNO.ToString.PadLeft(3, "0c"))
            bidPackageName.Append(CommonConstant.STR_UNDERBAR)
            bidPackageName.Append("Payment")
            bidPackageName.Append(CommonConstant.STR_UNDERBAR)
            bidPackageName.Append(DateTime.Now.ToString("yyMMdd"))
            bidPackageName.Append(CommonConstant.STR_UNDERBAR)
            bidPackageName.Append(DateTime.Now.ToString("HHmm"))

            dialog.FileName = bidPackageName.ToString()

            If dialog.ShowDialog() = DialogResult.OK Then
                Me.Refresh()
                Me.Cursor = Cursors.WaitCursor

                '==============================
                '���p�����[�^�t�@�C���쐬������
                '==============================
                '��ʓ��͒l�擾
                Me.GetInputValue()
                '�o�̓t�@�C�������p�����[�^�ɒǉ�
                Me.param.OutputFile = dialog.FileName
                Me.param.LogFile = Path.ChangeExtension(dialog.FileName, CommonConstant.EXTENSION_LOG)
                Me.param.PramFile = Path.ChangeExtension(dialog.FileName, CommonConstant.EXTENSION_XML)

                FileWriter.CreateOioParameter(param, Me.param.PramFile)

                Me.Refresh()
                Me.Cursor = Cursors.Default

                '�����I�����b�Z�[�W�\��
                Me.Activate()
                MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0001"), sender.Text)
            End If

        Catch ex As MuseException
            Me.Activate()
            Me.Cursor = Cursors.Default
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            Me.Cursor = Cursors.Default
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try
    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Close_Click
    '�T    �v  �FBtn_Close�N���b�N����
    '��    ��  �FBtn_Close�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click

        Try
            Me.DialogResult = DialogResult.No
            Me.Close()
        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FChk_Ma_CheckedChanged
    '�T    �v  �F����MA�`�F�b�N�{�b�N�X ��ԕω�
    '��    ��  �F����MA�`�F�b�N�{�b�N�X ��ԕω�
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Chk_Ma_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Chk_Ma.CheckedChanged

        If Chk_Ma.Checked = True Then
            GrpExistItsma.Enabled = True
        Else
            GrpExistItsma.Enabled = False
        End If

    End Sub

    ''' <summary>
    ''' �@�\�F�\������������ʕ\��
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btn_Del_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Del.Click
        ''�\������������ʕ\��
        Me.Hide()
        Dim FrmPSDetailDelete As New Frm_PSDetailDelete
        FrmPSDetailDelete.ShowDialog()
        ''Cancel�����O�A�E�g/No���\������荞�݃{�^���Ƃ���B
        If FrmPSDetailDelete.DialogResult = DialogResult.Cancel Then
            Me.DialogResult = DialogResult.Cancel
            Me.Close()
        ElseIf FrmPSDetailDelete.DialogResult = DialogResult.No Then
            Me.Show()
        End If
    End Sub

#End Region

#Region " �v���C�x�[�g���\�b�h "

    ''' <summary>
    '''�T  �v�F�������޲��۸ނ̏����l���Z�b�g����B
    '''��  ���F
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InitWaitDialog(ByRef waitDialog As Frm_WaitDialog)

        ''�������޲��۸ނ̏����l���Z�b�g
        waitDialog.Text = STR_CREATING_FILE
        waitDialog.lbl_Message.Text = STR_MESSAGE_CREATE_FILE
        waitDialog.Pic_Excel.Visible = True
        waitDialog.ProgressMin = 0
        waitDialog.ProgressMax = 7
        waitDialog.ProgressStep = 1
        waitDialog.ProgressValue = 0

    End Sub


    ''' <summary>
    '''�T  �v�F��������ү���ނ��擾
    '''��  ���F
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetExitMessage(ByVal PaymentCount As Integer, _
                                    ByVal PaymentDetailCount As Integer) As String

        ''������
        Dim rtnMessage As String = ""

        ''�w�b�_
        rtnMessage = rtnMessage & "Payment�t�@�C���ւ̔��f���������܂����B" & vbCrLf

        ''Payment�̏o�͌���
        rtnMessage = rtnMessage & "Payment�f�[�^" & vbCrLf _
                                & " ��" & PaymentCount & "�s" & vbCrLf
        ''�ڍׂ̏o�͌���
        rtnMessage = rtnMessage & "�ڍ׃f�[�^" & vbCrLf _
                                & " ��" & PaymentDetailCount & "�s" & vbCrLf

        Return rtnMessage
    End Function

    ''' <summary>
    ''' �@�@�\�FPSBook��Open����B
    ''' ���@���F
    ''' </summary>
    ''' <remarks></remarks>
    Private Function OpenPSBook(ByRef xlApp As Excel.Application) As Excel.Workbook

        ''�G���[���b�Z�[�W
        Dim ErrMSG_002 As String = FileReader.GetMessage("MSG_0280")

        ''������
        OpenPSBook = Nothing

        Try
            ''Payment���߽���擾
            Dim ofm As New OioFileManage
            Dim PSPath As String
            PSPath = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO) & _
                     ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)

            ''WorkBook��Open�`�F�b�N
            If ofm.ChkOpenedExcelFile(PSPath) = False Then
                Throw New Exception(ErrMSG_002 & vbCrLf & vbCrLf & "̧�ٖ��F" & ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO))
            End If

            ''WorkBook��Open
            OpenPSBook = xlApp.Workbooks.Open(PSPath)

        Catch ex As Exception
            Throw ex

        End Try

    End Function


    ''' <summary>
    ''' �@�@�\�FPSBook����A�����ɕK�v��Sheet���擾����B
    ''' ���@���F
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetWorkSheet(ByRef xlPSBook As Excel.Workbook, _
                             ByRef xlPSSheet As Excel.Worksheet, _
                             ByRef xlDetailSheet As Excel.Worksheet)

        ''�G���[���b�Z�[�W
        Dim ErrMSG_001 As String = "WorkSheet�̃Z�b�g�Ɏ��s���܂����B"

        ''������
        xlPSSheet = Nothing
        xlDetailSheet = Nothing

        Try
            ''Sheet���Z�b�g����B
            xlPSSheet = ExcelWrite.GetWorkSheet(xlPSBook, ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)
            xlDetailSheet = ExcelWrite.GetWorkSheet(xlPSBook, ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)

            ''�I�[�g�t�B���^�̏������O���B
            Dim ew As New ExcelWrite
            Call ew.CrearAutoFilter(xlPSSheet)
            Call ew.CrearAutoFilter(xlDetailSheet)

        Catch ex As Exception
            Throw New Exception(ErrMSG_001 & vbCrLf & _
                                ex.Message)

        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FSetInitialData
    '�T    �v  �F��������
    '��    ��  �F�����������s��
    '��    ��  �F�Ȃ�
    '�� �� �l  �F�Ȃ�
    '--------------------------------------------------------
    Private Sub SetInitialData()

        '*�R���{�{�b�N�X�ݒ�p�̃e�[�u�����`
        Dim comboTable As New DataTable
        comboTable.Columns.Add(Me.COMBOTABLE_COLUMN_NAME_TEXT, Type.GetType("System.String"))
        comboTable.Columns.Add(Me.COMBOTABLE_COLUMN_NAME_VALUE, Type.GetType("System.String"))

        '�_�����\��
        lblCPNO.Text = CommonVariable.CUSTOMERNAME.Replace("&", "&&") & "(" & CommonVariable.CPNO & ")"
        lblContractNo.Text = CommonVariable.CONTRACTNO.ToString().PadLeft(3, "0c")
        lblContractName.Text = CommonVariable.CONTRACTNONAME.Replace("&", "&&")

        '==============================================================
        '���R���{�{�b�N�X�ɒl�ݒ聞
        '==============================================================
        Dim control As New OioControl
        Dim CustomerNameTable As New DataTable
        Dim dataCustomername As DataRow
        control.StartUpPath = Application.StartupPath
        CustomerNameTable = control.GetCpNoData()
        '==============================================================
        '���R���{�{�b�N�X�ɒl�ݒ聞
        '==============================================================
        Me.Chk_Ma.Checked = False
        Me.RadIsat.Checked = True
        Me.RadKousei.Checked = False
        Me.GrpExistItsma.Enabled = False

        If Me._psLine.isNLine = True Then
            UCnt_Pal00012.TitleText = UCnt_Pal00012.TitleText.Replace("@", "�w���s�捞")
            GroupBox4.Text = GroupBox4.Text.Replace("@", "")
        Else
            UCnt_Pal00012.TitleText = UCnt_Pal00012.TitleText.Replace("@", "�\���捞")
            GroupBox4.Text = GroupBox4.Text.Replace("@", "�������o�^��")
        End If

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FSetParamData
    '�T    �v  �F�p�����[�^���ݒ菈��
    '��    ��  �F�p�����[�^���̐ݒ���s��
    '��    ��  �F�Ȃ�
    '�� �� �l  �F�Ȃ�
    '--------------------------------------------------------
    Private Sub SetParamData()

        '�v���W�F�N�g
        Me.htProject.Clear()
        Dim index As Integer
        Dim project As OioProject
        For Each project In Me.param.ProjectList
            Me.htProject.Add(index, project)
            index += 1
        Next
        Me.InitialProjectData()

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FGetInputValue
    '�T    �v  �F��ʓ��͒l�擾����
    '��    ��  �F��ʓ��͒l�擾�������s��
    '��    ��  �F�Ȃ�
    '�� �� �l  �F��ʓ��͒l
    '--------------------------------------------------------
    Private Function GetInputValue()

        '==============================================================
        '�����ʍ��ځ�
        '==============================================================
        '���q�l��
        Me.param.CustomerName = CommonVariable.CUSTOMERNAME
        Me.param.isNLine = Me._psLine.isNLine
        '�v���W�F�N�g
        Dim index As Integer
        Dim projectList(Me.htProject.Count - 1) As OioProject
        For index = 0 To Me.htProject.Count - 1
            projectList(index) = New OioProject
            projectList(index) = Me.htProject(index)
        Next
        Me.param.ProjectList = projectList

    End Function

    '--------------------------------------------------------
    '���\�b�h���FWriteParameterFile
    '�T    �v  �F�p�����[�^�t�@�C����������
    '��    ��  �F�p�����[�^�t�@�C������������
    '��    ��  �Fparam�F�p�����[�^
    '�� �� �l  �F��������
    '--------------------------------------------------------
    Public Sub WriteParameterFile(ByVal param As OioParameter)

        '==============================
        '���p�����[�^�t�@�C��������
        '==============================
        FileWriter.WriteOioParameter(param)

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FOutputEstimate
    '�T    �v  �F���Ϗ��o�͏���
    '��    ��  �F���Ϗ����o�͂���
    '��    ��  �FwaitDialog�F�҂����
    '�� �� �l  �F��������
    '--------------------------------------------------------
    Public Function OutputEstimate(ByVal waitDialog As Frm_WaitDialog, ByRef rtnTable As DataTable) As Boolean

        Dim control As New OioControl
        control.StartUpPath = Application.StartupPath
        control.PSLINE = Me._psLine
        control.MdbPW = CommonVariable.MdbPW

        Try

            '==============================
            '���p�����[�^�t�@�C���Ǎ���
            '==============================
            Me.param = FileReader.ReadOioParameter()
            Me.param.CpNo = control.GetCpNo(Me.param.CustomerName)
            Me.param.DelItsmaSsdOtherSheetFlg = False
            Me.param.DelExistItsmaAnnualSheetFlg = False
            Me.param.DelItsmaOtherSheetFlg = False
            Me.param.DelItsmaExtendSheetFlg = False
            Me.param.DelIgsSvcSheetFlg = False
            Me.param.DelCiscoManualSheetFlg = False

            waitDialog.PerformStep()

            '==============================
            '�����O�ɉ�ʑI�����ڂ�ݒ聞
            '==============================
            control.SetLogStartTime()
            control.SetLogFromParam(Me.param)
            waitDialog.PerformStep()

            '������ ���� ������
            Dim bFirst As Boolean = True
            Dim ebsSaleDataTemp As New EbsSaleTable
            Dim ebsMainteDataTemp As New EbsMainteTable
            '������ ���� ������

            '==============================
            '���v���W�F�N�g���ݒ聞
            '==============================
            Dim nMKFileNo As Integer = 0
            Dim project As OioProject
            For Each project In Me.param.ProjectList

                '==============================
                '�����O�ɉ�ʑI�����ڂ�ݒ聞
                '==============================
                control.SetLogFromParam(project)

                '==============================
                '���֘A�e�[�u����`��
                '==============================
                'CONFIG(SWMA)
                Dim configSwmaData As New ConfigSwmaDataSet
                'eBS
                Dim ebsSaleData As New EbsSaleTable
                Dim ebsMainteData As New EbsMainteTable

                '==============================
                '��Input�t�@�C���t�H�[�}�b�g�`�F�b�N��
                '==============================
                Dim blnRet As Boolean
                blnRet = control.CheckFileFormat(project)
                If blnRet = False Then
                    Exit Function
                End If

                '==============================
                '��Input�t�@�C���Ǎ���
                '==============================
                control.SetLogTimeWithComment("Input�t�@�C���Ǎ��J�n")
                control.ReadInputFile(project, configSwmaData, ebsSaleData, ebsMainteData, param.inventryData, nMKFileNo)
                If project.paData.Rows.Count <> 0 Then
                    If project.Pa_Level = "" Then
                        Me.Activate()
                        MsgBox(Prompt:=FileReader.GetMessage("MSG_0406"), Title:=Me.Text)
                        Exit Function
                    End If
                    If project.Pa_Anniversary = "" Then
                        Me.Activate()
                        MsgBox(Prompt:=FileReader.GetMessage("MSG_0407"), Title:=Me.Text)
                        Exit Function
                    End If
                End If

                Select Case project.ProjectType     '�v���W�F�N�g��ޔ���
                    Case CommonConstant.ParamProjectType.Std
                        '�ʏ�̏ꍇ
                        '==============================
                        '���e�[�u��������
                        '==============================
                        control.CheckTable(project.configData, configSwmaData)
                End Select

                '==============================
                '���e�[�u����r��
                '==============================
                control.CompareTable(project,
                                     param.ServicePacSheetData,
                                     configSwmaData,
                                     ebsSaleData,
                                     ebsMainteData,
                                     param.NotesPW,
                                     param.inventryData,
                                     CommonVariable.MdbPW)
                control.SetLogTimeWithComment("Input�t�@�C���Ǎ�����")

                If bFirst = True Then
                    ebsSaleDataTemp = ebsSaleData.Copy()
                    ebsMainteDataTemp = ebsMainteData.Copy()
                    bFirst = False
                End If
                '==============================
                '���֘A�e�[�u�������
                '==============================
                configSwmaData.Dispose()
                ebsSaleData.Dispose()
                ebsMainteData.Dispose()
            Next
            waitDialog.PerformStep()

            '==============================
            '��StwCategory���͉�ʁ�
            '==============================
            If InputBrankStwCategory(control) = False Then
                Exit Function
            End If

            '1717 str
            '==============================
            '��Config�f�[�^�␳���͉�ʁ�
            '==============================
            Dim strFilterConfig As String
            Dim rowConfig() As DataRow
            Dim HasConfig As Boolean

            '�S�v���W�F�N�g��ConfigsystemTable��1���ȏ゠��ΑΏ�

            HasConfig = False

            For Each project In Me.param.ProjectList

                strFilterConfig = ""
                rowConfig = project.configData.Tables("ConfigSystemTable").Select(strFilterConfig)

                If rowConfig.Length > 0 Then
                    HasConfig = True
                End If

            Next

            If HasConfig = True Then

                Dim frm As New Frm_DataCorrection
                frm.upalTitle.TitleText = "OIO BAMA Client�@�f�[�^�␳(Config)"
                frm.Proc = frm.PROC_CONFIG
                frm.oioProject = Me.param.ProjectList
                If frm.ShowDialog(Me) = DialogResult.Cancel Then
                    frm.Close()
                    Exit Function
                End If
                Me.param.ProjectList = frm.oioProject
                frm.Close()
            End If
            '1717 end

            '==============================
            '��zSW�f�[�^�␳���͉�ʁ�
            '==============================

            ''Dummy�݂̂ɑΉ� str
            Dim rowzSW() As DataRow
            Dim strFilterzSW As String
            strFilterzSW = Zsw_ProductTable.COLUMN_NAME_SYSTEM_KIND & "<>'" & Zsw_ProductTable.CD_SYSTEM_KIND_DUMMY & "'"

            rowzSW = project.zswData.Select(strFilterzSW)
            '            If project.zswData.Rows.Count > 0 Then
            If rowzSW.Length > 0 Then

                ''Dummy�݂̂ɑΉ� end
                Dim frm As New Frm_DataCorrection
                frm.upalTitle.TitleText = "OIO BAMA Client�@�f�[�^�␳(zSW)"
                frm.Proc = frm.PROC_ZSW
                frm.oioProject = Me.param.ProjectList
                If frm.ShowDialog(Me) = DialogResult.Cancel Then
                    frm.Close()
                    Exit Function
                End If
                Me.param.ProjectList = frm.oioProject
                frm.Close()
            End If

            ebsSaleDataTemp.Dispose()
            ebsMainteDataTemp.Dispose()

            '�o�̓V�[�g�̑I���t���O��p��
            Dim OutputFlg As OioOutputSheet
            OutputFlg.Init()

            '==============================
            '��Excel�o�́�
            '==============================
            'Req.1614 Isat�捞���W�b�N�ύX 2018/03 Str
            'control.OutputExcel(Me.param, OutputFlg, rtnTable)
            control.OutputExcel(Me.param, OutputFlg, rtnTable, CommonVariable.MdbPW)
            'Req.1614 Isat�捞���W�b�N�ύX 2018/03 End
            waitDialog.PerformStep()

            '==============================
            '���␳��ʁ�
            '==============================
            Dim ofm As New OioFileManage
            Dim strPath As String = ofm.GetLocalOutputCsvTempCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            Dim strCsvFileName() As String = System.IO.Directory.GetFiles(strPath, "PS_" & "*" & ".csv", System.IO.SearchOption.TopDirectoryOnly)
            Dim fi As New FileInfo(strCsvFileName(0))
            If fi.Length > 0 Then
                Dim frmIgf As New Frm_DataCorrection
                frmIgf.upalTitle.TitleText = "OIO BAMA Client�@�f�[�^�␳(IGF)"
                frmIgf.Proc = frmIgf.PROC_IGF
                If frmIgf.ShowDialog(Me) = DialogResult.Cancel Then
                    frmIgf.Close()
                    Exit Function
                End If
                frmIgf.Close()
            End If

            '==============================
            '���������ʃ��O�o�́�
            '==============================
            Dim versionInfo As New StringBuilder
            versionInfo.Append(Me.Text)
            versionInfo.Append(Space(1))
            versionInfo.Append(CommonConstant.STR_VERSION)

            FileWriter.WriteProcessResultLog(control.LogList, versionInfo.ToString(), Me.param.LogFile)
            waitDialog.PerformStep()

            '==============================
            '���p�����[�^�t�@�C���o�́�
            '==============================
            FileWriter.CreateOioParameter(param, Me.param.PramFile)
            waitDialog.PerformStep()

            '==============================
            '���p�����[�^�N���A��
            '==============================
            Me.param.Clear()

        Catch ex As Exception
            control.SetLogTimeWithComment("�G���[�����̂��߁APayment�o�͂𒆎~���܂��B�ڍׂ̓G���[���O���Q�Ƃ��Ă��������B")
            Throw ex
        Finally
            '==============================
            '���C�x���g���O�o�́�
            '==============================
            control.SetLogEndTime()
            FileWriter.WriteEventLog(control.LogList)
            waitDialog.PerformStep()
        End Try

        Return True

    End Function

    '--------------------------------------------------------
    '���\�b�h���FOutputEstimate
    '�T    �v  �F���Ϗ��o�͏���
    '��    ��  �F���Ϗ����o�͂���
    '��    ��  �FwaitDialog�F�҂����
    '�� �� �l  �F��������
    '--------------------------------------------------------
    Public Function InitialProjectData() As Boolean

        Dim index As Integer
        Dim project As OioProject

        Me.Lst_Project.Items.Clear()

        For index = 0 To Me.htProject.Count - 1
            project = Me.htProject(index)
            Select Case project.ProjectType
                Case CommonConstant.ParamProjectType.Std
                    Dim item() As String = {project.PlanNo, project.ProjectName, project.Introduction, Convert.ToDateTime(project.PayStartTime & "/01").ToString("yyyy�NM��"), Convert.ToDateTime(project.PayEndTime & "/01").ToString("yyyy�NM��"), project.MainteLevel}
                    Me.Lst_Project.Items.Add(New ListViewItem(item))
                Case CommonConstant.ParamProjectType.MaIsat
                    Dim item() As String = {project.PlanNo, project.ProjectName, project.Introduction, project.StartTime, Convert.ToDateTime(project.PayEndTime & "/01").ToString("yyyy�NM��"), project.MainteLevel}

                    Me.Lst_Project.Items.Add(New ListViewItem(item))
                Case CommonConstant.ParamProjectType.MaEx
                    Dim item() As String = {project.PlanNo, project.ProjectName, project.Introduction, project.StartTime, Convert.ToDateTime(project.PayEndTime & "/01").ToString("yyyy�NM��"), project.MainteLevel}

                    Me.Lst_Project.Items.Add(New ListViewItem(item))
            End Select
        Next

    End Function

    ''' <summary>
    ''' �@�\�FStwCategory����
    ''' </summary>
    ''' <param name="control"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function InputBrankStwCategory(ByRef control As OioControl) As Boolean
        Dim bRet As Boolean = False

        Dim frm As Frm_StwCategory = New Frm_StwCategory
        Dim aStwUnknownDatas As New ArrayList

        'StwCategory���}�X�^�ƕR�t���Ȃ��f�[�^��S�Ē��o
        control.SelectBrankStwCategory(param, aStwUnknownDatas)

        If aStwUnknownDatas.Count > 0 Then

            'STW Category���̓_�C�A���O��\��
            frm.StwUnknownData = aStwUnknownDatas
            If frm.ShowDialog(Me) <> DialogResult.Cancel Then

                'STW Category���̓_�C�A���O�ɂē��͂��ꂽ���e���e���R�[�h�ɔ��f
                aStwUnknownDatas = frm.StwUnknownData
                control.UpdateStwCategory(param, aStwUnknownDatas)
                bRet = True
            End If
        Else
            bRet = True
        End If

        Return bRet

    End Function

    ''' <summary>
    ''' �T  �v�F�Q�ƃ{�^���̃t�@�C���I���_�C�A�����O�{�b�N�X�̏����ʒu���w�肷��B
    ''' ��  ���FConfig\�Y���t�H���_���f�t�H���g�ʒu
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetFileSeletctDialogInitialPath() As String

        Dim strCpNo As String = CommonVariable.CPNO.Trim.PadLeft(8, "0")
        Dim strContractNO As String = CommonVariable.CONTRACTNO.ToString().PadLeft(3, "0c")
        Dim strPath As String

        GetFileSeletctDialogInitialPath = ""

        strPath = CommonConstant.FOLDERNAME_CONFIG & "\" & strCpNo & "_" & strContractNO
        Return FileManager.GetLocalFolderPath(strPath)

    End Function

    ''' <summary>
    ''' �T�@�v�F�捞�ݒ���N�s�̃f�[�^���������f�ς݂��ǂ����𔻒肷��B
    ''' ���@���F���^�p�̃p�^�[���FN�s�̍���1�`10�����Ƃŏ����Ă��܂����ꍇ�̔�����s���B
    ''' </summary>
    ''' <remarks></remarks>
    Private Function ChkBPExchange(ByVal cpno As String,
                                   ByVal contractNo As Integer,
                                   ByVal nLineFileNm As String) As Boolean

        ''������
        ChkBPExchange = False

        ''PaymentSheet���߽���擾����B
        Dim ofm As New MUSE.Utility.OioBamaCommmon.OioFileManage
        Dim PSPath As String
        PSPath = ofm.GetLocalCPNOFolder(cpno, contractNo) & _
                 ofm.GetPaymentLineExcelFileNm(cpno, contractNo)

        ''��PS�̎擾�p��Excel�I�u�W�F�N�g
        Dim matchItem10 As Boolean = False          ''����10�̒l���I�𒆂�N�s�ƃ}�b�`���邩�ǂ���?
        Dim xlApp As New Excel.Application
        Dim xlPSBook As Excel.Workbook
        Dim xlOioSheet As Excel.Worksheet

        Try
            xlApp.EnableEvents = False

            xlPSBook = xlApp.Workbooks.Open(PSPath)
            xlOioSheet = xlPSBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)

            ''����10�̒l���I�𒆂�N�s�̔���
            matchItem10 = ExistMatchItem10(xlOioSheet, nLineFileNm)

            xlApp.EnableEvents = True

            Return matchItem10

        Catch ex As Exception
            Throw ex

        Finally

            ''Excel�̉��
            ExcelObjRelease.ReleaseExcelObj(xlOioSheet, ExcelObjRelease.OBJECT_NOTHING)

            If IsNothing(xlPSBook) = False Then
                xlPSBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)

            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()

        End Try

    End Function


    ''' <summary>
    ''' �T�@�v�F�������f�Ŏ捞�ς�N�s�����݂��邩�`�F�b�N
    ''' ���@���F��N�s�̃t�@�C����������10�̒l�ƈ�v���邩���肷��B
    ''' </summary>
    ''' <remarks></remarks>
    Private Function ExistMatchItem10(ByRef xlOioSheet As Excel.Worksheet, _
                                      ByVal nLineFileNm As String) As Boolean

        ''������
        ExistMatchItem10 = False
        Dim excelLine(1, 188) As Object             ''Excel�̃Z�����

        Try

            ''����10�̒l��S��List�Ɋi�[
            Dim itemList As New ArrayList
            For i As Integer = EXCEL_PAYMENTLINEDATE_OUTROW To EXCEL_MAX_ROW

                ''1�s���̃f�[�^�擾
                excelLine = xlOioSheet.Range("A" & i & ":" & "IF" & i).Value

                ''Eof�̔���
                ''��No���󔒂�EOF
                If ExcelWrite.changeDBNullToString(excelLine(1, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)) = "" Then
                    Exit For
                End If

                ''�_������ς͑ΏۊO
                If ExcelWrite.changeDBNullToString(excelLine(1, ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG)) = "C" Then
                    Continue For
                End If

                ''N�s/�R�����g�s�͑ΏۊO
                If ExcelWrite.changeDBNullToString(excelLine(1, ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG)) = "N" Or _
                   ExcelWrite.changeDBNullToString(excelLine(1, ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG)) = "C" Then
                    Continue For
                End If

                ''����10��ǉ�
                ''���g���q���O������ԂŃZ�b�g����B
                Dim Item10 As String
                Item10 = Path.GetFileNameWithoutExtension(ExcelWrite.changeDBNullToString(excelLine(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10)))
                If Item10.Length > 3 Then
                    Item10 = Item10.Substring(3, Item10.Length - 3)
                Else
                    Item10 = ""
                End If
                itemList.Add(Item10)

            Next

            ''��v����N�s�����݂��邩����
            If itemList.IndexOf(Path.GetFileNameWithoutExtension(nLineFileNm)) = -1 Then
                ExistMatchItem10 = False
            Else
                ExistMatchItem10 = True
            End If

        Catch ex As Exception
            Throw ex

        Finally
            ''�Z���̉��
            ExcelObjRelease.ReleaseExcelObj(excelLine, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Function

    ''' <summary>
    '''�T    �v�FPayment . xls�t�@�C���̃t�@�C�������擾����B
    '''��    ���F�����Ŏ󂯂Ƃ����ACPNO�A�_�񏇔ԁASuffix�����Ƀt�@�C�������擾����B
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub CreateBKPaymentCsvFile(ByVal paymentSheetNM() As String)

        ''BK�t�@�C���쐬
        Dim strOutFileName As String
        Dim CsvOutPath As String = Path.GetDirectoryName(strPaymentSheet(0))
        Dim strFName As String = ""
        For i As Integer = 0 To paymentSheetNM.Length - 1
            strFName = paymentSheetNM(i)
            strOutFileName = Path.GetFileName(strFName)
            File.Copy(strFName,
                      CsvOutPath &
                      "\BK" &
                      GetBKPaymentCsvSuffix(strFName) &
                      strOutFileName,
                      True)
            File.Delete(strFName)
        Next

    End Sub

    ''' <summary>
    '''�T    �v�FPaymentDetail . xls�t�@�C���̃t�@�C�������擾����B
    '''��    ���F�����Ŏ󂯂Ƃ����ACPNO�A�_�񏇔ԁASuffix�����Ƀt�@�C�������擾����B
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub CreateBKPaymentDetailCsvFile(ByVal PaymentDetailSheetNM() As String)

        ''BK�t�@�C���ɕt�^����T�t�B�b�N�X�ԍ��̎擾
        Dim fileSuffix As String

        ''BK�t�@�C���쐬
        Dim strOutFileName As String
        Dim CsvOutPath As String = Path.GetDirectoryName(PaymentDetailSheetNM(0))
        Dim strFName As String = ""
        For i As Integer = 0 To PaymentDetailSheetNM.Length - 1
            strFName = PaymentDetailSheetNM(i)
            strOutFileName = Path.GetFileName(strFName)
            File.Copy(strFName, CsvOutPath &
                      "\BK" &
                    GetBKPaymentDetailCsvSuffix(strFName) &
                      strOutFileName,
                      True)
            File.Delete(strFName)
        Next

    End Sub

    ''' <summary>
    '''�T    �v�FBKCsv�t�@�C�����ɕt�^����T�t�B�b�N�X���擾�ipayment)
    '''��    ���FBKCsv�t�@�C�����ɕt�^����T�t�B�b�N�X���擾�ipayment)
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetBKPaymentCsvSuffix(ByVal CsvFileNm As String) As String

        ''������
        GetBKPaymentCsvSuffix = "00"

        ''�t�H���_����A�R�s�[��Csv�t�@�C�����Ɠ�����BK�t�@�C����S�Ď擾
        ''�@��Csv�t�@�C���t�H�[�}�b�g�FN�s�t�@�C���� + .csv
        ''�@��BK�t�@�C���t�H�[�}�b�g �FBK_ + �T�t�B�b�N�X_ + N�s�t�@�C���� + .csv
        Dim filter As String
        Dim bkFileNm() As String
        Dim fileNm As String = Path.GetFileName(CsvFileNm)
        Dim folderPath As String = Path.GetDirectoryName(CsvFileNm)
        filter = "BK" &
                  "*" &
                  "_PS_" &
                  fileNm &
                  ".csv"
        bkFileNm = System.IO.Directory.GetFiles(folderPath, filter)

        ''BK�t�@�C���̒�����A�ŐV�̃T�t�B�b�N�X���擾
        Dim suffix As String
        For i As Integer = 0 To bkFileNm.Length - 1
            ''BK_�@�̌��2�P�^���T�t�B�b�N�X
            suffix = bkFileNm(i).Substring(2, 2).PadLeft(2, "0")

            ''�T�t�B�b�N�X���C���N�������g
            If suffix >= GetBKPaymentCsvSuffix And
                IsNumeric(suffix) Then
                GetBKPaymentCsvSuffix = (CInt(suffix) + 1).ToString.PadLeft(2, "0")
            End If
        Next

    End Function

    ''' <summary>
    '''�T    �v�FBKCsv�t�@�C�����ɕt�^����T�t�B�b�N�X���擾�ipayment)
    '''��    ���FBKCsv�t�@�C�����ɕt�^����T�t�B�b�N�X���擾�ipayment)
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetBKPaymentDetailCsvSuffix(ByVal CsvFileNm As String) As String

        ''������
        GetBKPaymentDetailCsvSuffix = "00"

        ''�t�H���_����A�R�s�[��Csv�t�@�C�����Ɠ�����BK�t�@�C����S�Ď擾
        ''�@��Csv�t�@�C���t�H�[�}�b�g�FN�s�t�@�C���� + .csv
        ''�@��BK�t�@�C���t�H�[�}�b�g �FBK_ + �T�t�B�b�N�X_ + N�s�t�@�C���� + .csv
        Dim filter As String
        Dim bkFileNm() As String
        Dim fileNm As String = Path.GetFileName(CsvFileNm)
        Dim folderPath As String = Path.GetDirectoryName(CsvFileNm)
        filter = "BK" &
                  "*" &
                  "_PSD_" &
                  fileNm &
                  ".csv"
        bkFileNm = System.IO.Directory.GetFiles(folderPath, filter)

        ''BK�t�@�C���̒�����A�ŐV�̃T�t�B�b�N�X���擾
        Dim suffix As String
        For i As Integer = 0 To bkFileNm.Length - 1
            ''BK_�@�̌��2�P�^���T�t�B�b�N�X
            suffix = bkFileNm(i).Substring(2, 2).PadLeft(2, "0")

            ''�T�t�B�b�N�X���C���N�������g
            If suffix >= GetBKPaymentDetailCsvSuffix And
                IsNumeric(suffix) Then
                GetBKPaymentDetailCsvSuffix = (CInt(suffix) + 1).ToString.PadLeft(2, "0")
            End If
        Next

    End Function

    ''' <summary>
    ''' ���@���F�������f�������s���A�s�v�Ȍ�PS�A�ʏڍ׃t�@�C���̍폜�������s���B
    ''' �T�@�v�F
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub DeleteSuffixUpExcelFile(ByVal createTime As String)

        Try

            Dim ofm As New OioFileManage

            ''��PS�t�@�C�� .xls�̍폜
            Dim delPSExcelFilePath As String
            Dim delPSExcelDirPath As String
            Dim delPSExcelFileNM As String
            delPSExcelDirPath = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            delPSExcelFileNM = ofm.GetNewPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO, createTime)
            delPSExcelFilePath = delPSExcelDirPath & delPSExcelFileNM & ".xlsm"

            ''�t�@�C�������݂���΍폜
            If File.Exists(delPSExcelFilePath) = True Then
                File.Delete(delPSExcelFilePath)
            End If

        Catch ex As Exception
            MsgBox(ex.Message, Me.Text, vbCritical)

        End Try

    End Sub

    ''' <summary>
    ''' ExcelLog�o��
    ''' </summary>
    ''' <param name="strFileNameExcelPs"></param>
    ''' <param name="strFileNameCsvPs"></param>
    ''' <remarks></remarks>
    Private Sub OutputExcelLog(ByVal strFileNameExcelPs As String, ByVal strFileNameCsvPs As String)

        Dim xlApp As Excel.Application = Nothing
        Dim xlBooks As Excel.Workbooks = Nothing
        Dim xlBook As Excel.Workbook = Nothing
        Dim xlSheets As Excel.Sheets = Nothing
        Dim xlSheet As Excel.Worksheet = Nothing

        Try
            'Excel��޼ު�ď����ݒ�
            xlApp = New Excel.Application
            xlApp.DisplayAlerts = False
            xlApp.EnableEvents = False
            xlApp.EnableEvents = False
            xlApp.Visible = False
            xlBooks = xlApp.Workbooks

            '''' �@�����FExcel��޼ު��OPEN
            xlBook = xlBooks.Open(strFileNameExcelPs)
            xlSheets = xlBook.Worksheets

            'MVMS
            xlSheet = xlSheets.Item(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)
            Call OutputExcelLogMvms(xlBooks, xlSheet, strFileNameCsvPs)

            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)

        Catch ex As Exception
            Throw ex
        Finally
            '''' �����FExcel��޼ު�ĉ��
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBook) = False Then
                xlBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBooks, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try

    End Sub

    ''' <summary>
    ''' MVMS��ExcelLog�o��
    ''' </summary>
    ''' <param name="xlBooks"></param>
    ''' <param name="xlSheet"></param>
    ''' <param name="strFileNameCsvPs"></param>
    ''' <remarks></remarks>
    Private Sub OutputExcelLogMvms(ByRef xlBooks As Excel.Workbooks, ByVal xlSheet As Excel.Worksheet, ByVal strFileNameCsvPs As String)

        Dim intOutputCnt As Integer = 0
        Dim strRange As String
        Dim intRowCnt As Integer
        Dim obData(,) As Object
        Dim xlRange As Excel.Range
        Dim strPatternNo As String
        Dim strItem10 As String
        Dim strAns As String
        Dim strOutputLine As String
        Dim strWork As String
        Dim ofm As New OioFileManage
        Dim strLogFileName As String
        Dim strLogPath As String
        Dim sw As StreamWriter
        Dim strCreateDate As String

        Dim xlTmpBook As Excel.Workbook = Nothing
        Dim xlTmpSheets As Excel.Sheets = Nothing
        Dim xlTmpSheet As Excel.Worksheet = Nothing

        Try
            strLogPath = Path.GetFullPath("../log/")
            strCreateDate = Now.ToString("yyyyMMdd_HHmmss")
            strLogFileName = strLogPath & "WorkCsv_LOG_MVMS_" & strCreateDate & ".csv"
            sw = New StreamWriter(strLogFileName, False, System.Text.Encoding.Default)

            strFileNameCsvPs = Path.GetFileName(strFileNameCsvPs)

            '���ԃt�@�C���쐬
            intRowCnt = ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW
            Do

                '�P�s�擾(��Ǝw��FLG�񂩂�List Price(�P��)Validation��܂�)
                strRange = "A" & intRowCnt.ToString & ":CC" & intRowCnt.ToString
                xlRange = xlSheet.Range(strRange)
                obData = xlRange.Value
                ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)

                '�ŏI�s������
                If ExcelWrite.changeDBNullToString(obData(1, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)) = "" Then
                    Exit Do
                End If

                '�Ώۃf�[�^������
                '�����NO=20 ���� ����10=�捞��CSV̧�ٖ��̏ꍇ�A�Ώۃf�[�^�Ƃ���
                strPatternNo = ExcelWrite.changeDBNullToString(obData(1, ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD))
                strItem10 = ExcelWrite.changeDBNullToString(obData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10))
                If strPatternNo = CommonConstant.PATTERNCD_TYPE_OtherMVMS And
                    strItem10.IndexOf(strFileNameCsvPs) <> -1 Then
                    strOutputLine = ""
                    strAns = ""
                    'Payment���
                    strWork = AddDoublequotes(obData(1, ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG))
                    strOutputLine = strOutputLine & strWork & ","
                    'NO
                    strWork = AddDoublequotes(obData(1, ExcelWrite.ExcelPaymentLineColumn.LINE_NO))
                    strOutputLine = strOutputLine & strWork & ","
                    'BU
                    strWork = AddDoublequotes(obData(1, ExcelWrite.ExcelPaymentLineColumn.BU))
                    strOutputLine = strOutputLine & strWork & ","
                    'BRAND
                    strWork = AddDoublequotes(obData(1, ExcelWrite.ExcelPaymentLineColumn.BRAND))
                    strOutputLine = strOutputLine & strWork & ","
                    'SUM_CATEGORY
                    strWork = AddDoublequotes(obData(1, ExcelWrite.ExcelPaymentLineColumn.SUM_CATEGORY))
                    strOutputLine = strOutputLine & strWork & ","
                    'BRAND_SUB
                    strWork = AddDoublequotes(obData(1, ExcelWrite.ExcelPaymentLineColumn.BRAND_SUB))
                    strOutputLine = strOutputLine & strWork & ","
                    '�����NO
                    strWork = AddDoublequotes(obData(1, ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD))
                    strOutputLine = strOutputLine & strWork & ","
                    '����ݖ���
                    strWork = AddDoublequotes(obData(1, ExcelWrite.ExcelPaymentLineColumn.PATTERN))
                    strOutputLine = strOutputLine & strWork & ","
                    '���ڂP
                    strWork = ExcelWrite.changeDBNullToString(obData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01))
                    If strWork.Trim = "" Then
                        strAns = strAns & "�u���ڂP�v"
                    End If
                    strWork = AddDoublequotes(strWork.Trim)
                    strOutputLine = strOutputLine & strWork & ","
                    '���ڂR
                    strWork = ExcelWrite.changeDBNullToString(obData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01))
                    If strWork.Trim = "" Then
                        strAns = strAns & "�u���ڂR�v"
                    End If
                    strWork = AddDoublequotes(strWork.Trim)
                    strOutputLine = strOutputLine & strWork & ","
                    '���ڂW
                    strWork = ExcelWrite.changeDBNullToString(obData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM08))
                    If strWork.Trim = "" Then
                        strAns = strAns & "�u���ڂW�v"
                    End If
                    strWork = AddDoublequotes(strWork.Trim)
                    strOutputLine = strOutputLine & strWork & ","
                    '���ڂP�O
                    strWork = AddDoublequotes(obData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10))
                    strOutputLine = strOutputLine & strWork & ","
                    '���޽����(�J�n)
                    strWork = ExcelWrite.changeDBNullToString(obData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11))
                    If IsDate(strWork) = False Then
                        strAns = strAns & "�u���޽����(�J�n�v"
                    End If
                    strWork = AddDoublequotes(strWork.Trim)
                    strOutputLine = strOutputLine & strWork & ","
                    '���޽����(�I��)
                    strWork = ExcelWrite.changeDBNullToString(obData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12))
                    If IsDate(strWork) = False Then
                        strAns = strAns & "�u���޽����(�I��)�v"
                    End If
                    strWork = AddDoublequotes(strWork.Trim)
                    strOutputLine = strOutputLine & strWork & ","
                    '����
                    strWork = AddDoublequotes(obData(1, ExcelWrite.ExcelPaymentLineColumn.QTY))
                    strOutputLine = strOutputLine & strWork & ","
                    '�o�הN��
                    strWork = ExcelWrite.changeDBNullToString(obData(1, ExcelWrite.ExcelPaymentLineColumn.INST_DATE))
                    If IsDate(strWork) = False Then
                        strAns = strAns & "�u�o�הN���v"
                    End If
                    strWork = AddDoublequotes(strWork.Trim)
                    strOutputLine = strOutputLine & strWork & ","
                    '�������� �J�n�N��
                    strWork = ExcelWrite.changeDBNullToString(obData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE))
                    If IsDate(strWork) = False Then
                        strAns = strAns & "�u�������� �J�n�N���v"
                    End If
                    strWork = AddDoublequotes(strWork.Trim)
                    strOutputLine = strOutputLine & strWork & ","
                    '�������� �I���N��
                    strWork = ExcelWrite.changeDBNullToString(obData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE))
                    If IsDate(strWork) = False Then
                        strAns = strAns & "�u�������� �I���N���v"
                    End If
                    strWork = AddDoublequotes(strWork.Trim)
                    strOutputLine = strOutputLine & strWork & ","
                    '�x�����@
                    strWork = ExcelWrite.changeDBNullToString(obData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD))
                    If strWork.Trim = "" Then
                        strAns = strAns & "�u�x�����@�v"
                    End If
                    strWork = AddDoublequotes(strWork.Trim)
                    strOutputLine = strOutputLine & strWork & ","
                    'List Price(�P��)��Ď�
                    strWork = ExcelWrite.changeDBNullToString(obData(1, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL))
                    If strWork.Trim = "" Then
                        strAns = strAns & "�uList Price(�P��)��Ď��v"
                    End If
                    strWork = AddDoublequotes(strWork.Trim)
                    strOutputLine = strOutputLine & strWork & ","
                    'List Price(�P��)Validation��
                    strWork = ExcelWrite.changeDBNullToString(obData(1, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH))
                    If strWork.Trim = "" Then
                        strAns = strAns & "�uList Price(�P��)Validation��v"
                    End If
                    strWork = AddDoublequotes(strWork.Trim)
                    strOutputLine = strOutputLine & strWork & ","

                    If strAns.Trim <> "" Then
                        strAns = strAns & "��������܂���B"
                    End If
                    strAns = AddDoublequotes(strAns)
                    strOutputLine = strAns & "," & strOutputLine
                    sw.WriteLine(strOutputLine)
                    intOutputCnt = intOutputCnt + 1
                End If
                intRowCnt = intRowCnt + 1
            Loop
            sw.Close()

            If intOutputCnt > 0 Then
                'Template�R�s�[
                Dim strExcelLogName As String
                Dim strTmpMvmsName As String
                strExcelLogName = strLogPath & "LogMvms_" & strCreateDate & ".xlsx"
                strTmpMvmsName = ofm.GetLocalTemplateFolder & "LogMvmsTemplate.xlsx"
                FileCopy(strTmpMvmsName, strExcelLogName)

                xlTmpBook = xlBooks.Open(strExcelLogName)
                xlTmpSheets = xlTmpBook.Worksheets
                xlTmpSheet = xlTmpSheets.Item("Log")

                '�r���쐬
                Const DIVISION_LINES As Integer = 1000
                Dim intSho As Integer = intOutputCnt \ DIVISION_LINES
                Dim intAmari As Integer = intOutputCnt Mod DIVISION_LINES

                For intCnt As Integer = 1 To intSho
                    xlRange = xlTmpSheet.Range("3:3")
                    xlRange.Copy()
                    ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                    strRange = (3 + (intCnt - 1) * DIVISION_LINES).ToString() & ":" & (3 - 1 + intCnt * DIVISION_LINES).ToString()
                    Debug.Print(strRange)
                    xlRange = xlTmpSheet.Range(strRange)
                    xlRange.PasteSpecial(Excel.XlPasteType.xlPasteFormats)
                    ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                Next
                If intAmari <> 0 Then
                    xlRange = xlTmpSheet.Range("3:3")
                    xlRange.Copy()
                    ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                    strRange = (3 + (intSho * DIVISION_LINES)).ToString() & ":" & (3 + (intSho * DIVISION_LINES + intAmari) - 1).ToString()
                    Debug.Print(strRange)
                    xlRange = xlTmpSheet.Range(strRange)
                    xlRange.PasteSpecial(Excel.XlPasteType.xlPasteFormats)
                    ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
                End If


                'CSV�ް���Excel�iPayment��āj�ɓǍ����̶�т̌^
                Dim intDataType(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12 - 1) As Integer
                Call ExcelWrite.SetExcelDataTypePayment(intDataType)
                '���̧�ق�Exceļ�قɓǂݍ��܂���
                Call ExcelWrite.LoadCsvToExcel(strLogFileName, 1, "Log", "A3", xlTmpSheet)
                ExcelObjRelease.ReleaseExcelObj(xlTmpSheet, ExcelObjRelease.OBJECT_NOTHING)
                ExcelObjRelease.ReleaseExcelObj(xlTmpSheets, ExcelObjRelease.OBJECT_NOTHING)
                xlTmpBook.Save()
                xlTmpBook.Close()
                ExcelObjRelease.ReleaseExcelObj(xlTmpBook, ExcelObjRelease.OBJECT_NOTHING)

            End If


        Catch ex As Exception
            Throw ex

        Finally
            '''' �����FExcel��޼ު�ĉ��
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)

            ExcelObjRelease.ReleaseExcelObj(xlTmpSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlTmpSheets, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlTmpBook) = False Then
                xlTmpBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlTmpBook, ExcelObjRelease.OBJECT_NOTHING)

            'ܰ�̧�ٍ폜
            Call ofm.DeleteWorkFile(strLogPath)
        End Try

    End Sub

    Private Function AddDoublequotes(ByVal strData As String) As String

        AddDoublequotes = ExcelWrite.changeDBNullToString(strData)

        AddDoublequotes = AddDoublequotes.Replace("""", """""")

        AddDoublequotes = """" & AddDoublequotes & """"

    End Function

    ''' <summary>
    ''' �@�\�F��ʂ�����͂��ꂽ���ʕ��Ńt�@�C�����R�s�[����
    ''' </summary>
    ''' <param name="prjSrc"></param>
    ''' <param name="htProjectSrc"></param>
    ''' <remarks></remarks>
    Private Sub SplitInputFile(ByRef prjSrc() As OioProject, ByRef arAddFileNames As ArrayList)

        Dim intIndexSrc As Integer
        Dim intIndexCopy As Integer
        Dim intCopyCnt As Integer
        Dim intPrjCnt As Integer
        Dim prj As OioProject
        Dim strFileNameSrc As String
        Dim strPathConfig As String
        Dim strFileNemeDest As String
        Dim strExtension As String
        Dim strCopyOrgFilName As String

        Try
            For intPrjCnt = 0 To param.ProjectList.Length - 1
                Dim inputFile() As InputFileList
                prj = param.ProjectList(intPrjCnt)
                '����InputFileList��ۑ�
                ReDim Preserve prjSrc(intPrjCnt)
                prjSrc(intPrjCnt) = New OioProject
                prjSrc(intPrjCnt).InputFile = prj.InputFile
                intIndexCopy = 0
                For intIndexSrc = 0 To prj.InputFile.Length - 1
                    If prj.InputFile(intIndexSrc).InputQuantity > 1 Then
                        For intCopyCnt = 1 To prj.InputFile(intIndexSrc).InputQuantity
                            ReDim Preserve inputFile(intIndexCopy)
                            inputFile(intIndexCopy) = New InputFileList

                            With inputFile(intIndexCopy)
                                .BoxReplace = prj.InputFile(intIndexSrc).BoxReplace
                                'Config
                                If prj.InputFile(intIndexSrc).Config.Trim <> "" Then
                                    strPathConfig = Path.GetDirectoryName(prj.InputFile(intIndexSrc).Config)
                                    strFileNameSrc = Path.GetFileNameWithoutExtension(prj.InputFile(intIndexSrc).Config)
                                    strExtension = Path.GetExtension(prj.InputFile(intIndexSrc).Config)
                                    '�t�@�C������ύX���ăR�s�[����
                                    strFileNemeDest = strFileNameSrc & "_" & intCopyCnt.ToString & "���" & strExtension
                                    File.Copy(prj.InputFile(intIndexSrc).Config, strPathConfig & "\" & strFileNemeDest, True)
                                    '�I�����ɍ폜����t�@�C������ۑ�
                                    arAddFileNames.Add(strPathConfig & "\" & strFileNemeDest)

                                    .Config = strPathConfig & "\" & strFileNemeDest
                                Else
                                    .Config = prj.InputFile(intIndexSrc).Config
                                End If
                                .eBS_Mainte = prj.InputFile(intIndexSrc).eBS_Mainte
                                .eBS_Sale = prj.InputFile(intIndexSrc).eBS_Sale
                                .InputQuantity = prj.InputFile(intIndexSrc).InputQuantity
                                'SWMA
                                If prj.InputFile(intIndexSrc).Config.Trim = "" And prj.InputFile(intIndexSrc).SWMA.Trim <> "" Then
                                    strPathConfig = Path.GetDirectoryName(prj.InputFile(intIndexSrc).SWMA)
                                    strFileNameSrc = Path.GetFileNameWithoutExtension(prj.InputFile(intIndexSrc).SWMA)
                                    strExtension = Path.GetExtension(prj.InputFile(intIndexSrc).SWMA)
                                    '�t�@�C������ύX���ăR�s�[����
                                    strFileNemeDest = strFileNameSrc & "_" & intCopyCnt.ToString & "���" & strExtension
                                    File.Copy(prj.InputFile(intIndexSrc).SWMA, strPathConfig & "\" & strFileNemeDest, True)
                                    '�I�����ɍ폜����t�@�C������ۑ�
                                    arAddFileNames.Add(strPathConfig & "\" & strFileNemeDest)

                                    .SWMA = strPathConfig & "\" & strFileNemeDest
                                Else
                                    .SWMA = prj.InputFile(intIndexSrc).SWMA
                                End If
                                .SystemQuantity = prj.InputFile(intIndexSrc).SystemQuantity
                            End With
                            intIndexCopy = intIndexCopy + 1
                        Next

                    Else
                        ReDim Preserve inputFile(intIndexCopy)
                        inputFile(intIndexCopy) = New InputFileList

                        With inputFile(intIndexCopy)
                            .BoxReplace = prj.InputFile(intIndexSrc).BoxReplace
                            'Config
                            If prj.InputFile(intIndexSrc).Config.Trim <> "" Then
                                strPathConfig = Path.GetDirectoryName(prj.InputFile(intIndexSrc).Config)
                                strFileNameSrc = Path.GetFileNameWithoutExtension(prj.InputFile(intIndexSrc).Config)
                                strExtension = Path.GetExtension(prj.InputFile(intIndexSrc).Config)
                                '�t�@�C������ύX���Ȃ�
                                strFileNemeDest = strFileNameSrc & strExtension

                                .Config = strPathConfig & "\" & strFileNemeDest
                            Else
                                .Config = prj.InputFile(intIndexSrc).Config
                            End If
                            .eBS_Mainte = prj.InputFile(intIndexSrc).eBS_Mainte
                            .eBS_Sale = prj.InputFile(intIndexSrc).eBS_Sale
                            .InputQuantity = prj.InputFile(intIndexSrc).InputQuantity
                            'SWMA
                            If prj.InputFile(intIndexSrc).Config.Trim = "" And prj.InputFile(intIndexSrc).SWMA.Trim <> "" Then
                                strPathConfig = Path.GetDirectoryName(prj.InputFile(intIndexSrc).SWMA)
                                strFileNameSrc = Path.GetFileNameWithoutExtension(prj.InputFile(intIndexSrc).SWMA)
                                strExtension = Path.GetExtension(prj.InputFile(intIndexSrc).SWMA)
                                '�t�@�C������ύX���Ȃ�
                                strFileNemeDest = strFileNameSrc & strExtension

                                .SWMA = strPathConfig & "\" & strFileNemeDest
                            Else
                                .SWMA = prj.InputFile(intIndexSrc).SWMA
                            End If
                            .SystemQuantity = prj.InputFile(intIndexSrc).SystemQuantity
                        End With
                        intIndexCopy = intIndexCopy + 1

                    End If
                Next
                If Not inputFile Is Nothing Then
                    param.ProjectList(intPrjCnt).InputFile = inputFile
                    '1717 str �ʃv���W�F�N�g������AConfig�����̕W���P�[�X�̏ꍇ�ɑO���񂪃R�s�[�����ׁA��������ǉ�
                    inputFile = Nothing
                    '1717 end
                End If
            Next

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' �@�\�F�������ꂽInputFile�����ɖ߂�
    ''' </summary>
    ''' <param name="prjSrc"></param>
    ''' <remarks></remarks>
    Private Sub InputConfigReinstate(ByVal prjSrc() As OioProject)

        Dim intPrjCnt As Integer
        Dim intCnt As Integer
        Dim htProjectSrc As Hashtable
        Dim oioPrj As OioProject

        Try
            htProjectSrc = Me.htProject.Clone
            Me.htProject.Clear()
            For intPrjCnt = 0 To param.ProjectList.Length - 1
                param.ProjectList(intPrjCnt).InputFile = prjSrc(intPrjCnt).InputFile
                oioPrj = DirectCast(htProjectSrc(intPrjCnt), MUSE.Utility.XmlClass.Parameter.OioProject)
                oioPrj.InputFile = prjSrc(intPrjCnt).InputFile
                Me.htProject.Add(intPrjCnt, oioPrj)
            Next

        Catch ex As Exception
            Throw ex

        End Try

    End Sub

    ''' <summary>
    ''' ���ʕ����ŃR�s�[�����t�@�C�����폜����
    ''' </summary>
    ''' <param name="arAddFileNames"></param>
    ''' <remarks></remarks>
    Private Sub DeleteAddFile(ByVal arAddFileNames As ArrayList)

        Try
            If arAddFileNames.Count > 0 Then
                For intCnt As Integer = 0 To (arAddFileNames.Count - 1)
                    File.Delete(arAddFileNames(intCnt).ToString)
                Next
            End If

        Catch ex As Exception
            Throw ex

        End Try

    End Sub

#End Region

End Class