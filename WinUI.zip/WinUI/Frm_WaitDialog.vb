'==========================================================================
'�N���X���FFrm_WaitDialog
'�T    �v�FWaitDialog�N���X
'��    ���F�҂����
'��    ���F[Ver1.0]  2006/10/01  �����@���K
'==========================================================================
Imports System.Runtime.InteropServices

Public Class Frm_WaitDialog
    Inherits System.Windows.Forms.Form

    <DllImport("user32.dll")> Public Shared Function AttachThreadInput(ByVal idAttach As Integer, ByVal idAttachTo As Integer, ByVal fAttach As Boolean) As Boolean
    End Function
    <DllImport("user32.dll")> Public Shared Function GetForegroundWindow() As IntPtr
    End Function
    <DllImport("user32.dll")> Public Shared Function GetWindowThreadProcessId(ByVal hwnd As IntPtr, ByRef lpdwProcessId As Integer) As Integer
    End Function

#Region " Windows �t�H�[�� �f�U�C�i�Ő������ꂽ�R�[�h "

    Public Sub New()
        MyBase.New()

        ' ���̌Ăяo���� Windows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
        InitializeComponent()

        ' InitializeComponent() �Ăяo���̌�ɏ�������ǉ����܂��B

    End Sub

    ' Form �́A�R���|�[�l���g�ꗗ�Ɍ㏈�������s���邽�߂� dispose ���I�[�o�[���C�h���܂��B
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    ' Windows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
    Private components As System.ComponentModel.IContainer

    ' ���� : �ȉ��̃v���V�[�W���́AWindows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
    'Windows �t�H�[�� �f�U�C�i���g���ĕύX���Ă��������B  
    ' �R�[�h �G�f�B�^���g���ĕύX���Ȃ��ł��������B
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Prg_Process As System.Windows.Forms.ProgressBar
    Friend WithEvents lbl_Message As System.Windows.Forms.Label
    Friend WithEvents Pic_Clock As System.Windows.Forms.PictureBox
    Friend WithEvents Pic_Excel As System.Windows.Forms.PictureBox
    Friend WithEvents Pic_Folder As System.Windows.Forms.PictureBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Frm_WaitDialog))
        Me.lbl_Message = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Prg_Process = New System.Windows.Forms.ProgressBar()
        Me.Pic_Clock = New System.Windows.Forms.PictureBox()
        Me.Pic_Excel = New System.Windows.Forms.PictureBox()
        Me.Pic_Folder = New System.Windows.Forms.PictureBox()
        CType(Me.Pic_Clock, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pic_Excel, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pic_Folder, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lbl_Message
        '
        Me.lbl_Message.AutoSize = True
        Me.lbl_Message.Font = New System.Drawing.Font("�l�r �S�V�b�N", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lbl_Message.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbl_Message.Location = New System.Drawing.Point(78, 15)
        Me.lbl_Message.Name = "lbl_Message"
        Me.lbl_Message.Size = New System.Drawing.Size(0, 17)
        Me.lbl_Message.TabIndex = 0
        Me.lbl_Message.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("�l�r �S�V�b�N", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(78, 45)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(258, 30)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "���΂炭���҂��������B"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Prg_Process
        '
        Me.Prg_Process.Location = New System.Drawing.Point(39, 85)
        Me.Prg_Process.Name = "Prg_Process"
        Me.Prg_Process.Size = New System.Drawing.Size(297, 15)
        Me.Prg_Process.TabIndex = 5
        '
        'Pic_Clock
        '
        Me.Pic_Clock.Image = CType(resources.GetObject("Pic_Clock.Image"), System.Drawing.Image)
        Me.Pic_Clock.Location = New System.Drawing.Point(11, 10)
        Me.Pic_Clock.Name = "Pic_Clock"
        Me.Pic_Clock.Size = New System.Drawing.Size(67, 65)
        Me.Pic_Clock.TabIndex = 7
        Me.Pic_Clock.TabStop = False
        Me.Pic_Clock.Visible = False
        '
        'Pic_Excel
        '
        Me.Pic_Excel.Image = CType(resources.GetObject("Pic_Excel.Image"), System.Drawing.Image)
        Me.Pic_Excel.Location = New System.Drawing.Point(11, 10)
        Me.Pic_Excel.Name = "Pic_Excel"
        Me.Pic_Excel.Size = New System.Drawing.Size(67, 65)
        Me.Pic_Excel.TabIndex = 8
        Me.Pic_Excel.TabStop = False
        Me.Pic_Excel.Visible = False
        '
        'Pic_Folder
        '
        Me.Pic_Folder.Image = CType(resources.GetObject("Pic_Folder.Image"), System.Drawing.Image)
        Me.Pic_Folder.Location = New System.Drawing.Point(11, 10)
        Me.Pic_Folder.Name = "Pic_Folder"
        Me.Pic_Folder.Size = New System.Drawing.Size(67, 65)
        Me.Pic_Folder.TabIndex = 9
        Me.Pic_Folder.TabStop = False
        Me.Pic_Folder.Visible = False
        '
        'Frm_WaitDialog
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(268, 97)
        Me.ControlBox = False
        Me.Controls.Add(Me.Pic_Folder)
        Me.Controls.Add(Me.Pic_Excel)
        Me.Controls.Add(Me.Pic_Clock)
        Me.Controls.Add(Me.Prg_Process)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lbl_Message)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Frm_WaitDialog"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        CType(Me.Pic_Clock, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pic_Excel, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pic_Folder, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

#Region " �v���p�e�B "

    Public WriteOnly Property ProgressMax() As Integer
        Set(ByVal Value As Integer)
            Me.Prg_Process.Maximum = Value
        End Set
    End Property

    Public WriteOnly Property ProgressValue() As Integer
        Set(ByVal Value As Integer)
            Me.Prg_Process.Value = Value
        End Set
    End Property

    Public WriteOnly Property ProgressMin() As Integer
        Set(ByVal Value As Integer)
            Me.Prg_Process.Minimum = Value
        End Set
    End Property

    Public WriteOnly Property ProgressStep() As Integer
        Set(ByVal Value As Integer)
            Me.Prg_Process.Step = Value
        End Set
    End Property

#End Region

#Region "�p�u���b�N"
    ''' <summary>
    ''' �e�t�H�[���ɑ΂��čőO�ʕ\������
    ''' </summary>
    ''' <param name="frm"></param>
    ''' <param name="frm"></param>
    ''' <remarks></remarks>
    Public Sub Activate2(ByVal frmParent As Form)
        Dim targetThreadProcessId As Integer = GetWindowThreadProcessId(GetForegroundWindow(), IntPtr.Zero.ToInt32)
        Dim ThreadProcessId As Integer = GetWindowThreadProcessId(frmParent.Handle, 0&)
        AttachThreadInput(ThreadProcessId, targetThreadProcessId, True)
        Me.Activate()
        AttachThreadInput(ThreadProcessId, targetThreadProcessId, False)
    End Sub
#End Region

#Region " �v���C�x�[�g���\�b�h "

    '--------------------------------------------------------
    '���\�b�h���FPerformStep
    '�T    �v  �F�i���󋵂�i�߂�
    '��    ��  �F�i���󋵂�i�߂�
    '��    ��  �F�Ȃ�
    '�� �� �l  �F�Ȃ�
    '--------------------------------------------------------
    Public Sub PerformStep()
        Me.Prg_Process.PerformStep()
    End Sub

#End Region


End Class