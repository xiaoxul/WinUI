﻿Imports System.Net
Imports System.Text
Imports System.Xml
Imports System.IO
Imports MUSE.Utility
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.XmlClass.ConnectionInfo
Imports MUSE.Utility.OioBamaCommmon
Imports MUSE.Utility.UserDataTable.Master
Imports MUSE.Controller


Public Class ServerCsv

#Region "Const"
    Public Const CD_GETCSV_ALL As Integer = 0
    Public Const CD_GETCSV_PAYMENTLINE As Integer = 1
    Public Const RET_OK As Integer = 0
    Public Const RET_NO_FILE As Integer = 1
    Public Const RET_SYS_ERROR As Integer = 2
    Public Const RET_CANCEL As Integer = 3
#End Region

#Region ""
    Public GetPsCsvFlg As Boolean
    Public GetPsRefCsvFlg As Boolean
    Public GetPsValCsvFlg As Boolean
    Public GetDetailCsvFlg As Boolean
    Public GetDetailRefCsvFlg As Boolean
    Public GetDetailValCsvFlg As Boolean
#End Region

#Region "Public"
    ''' <summary>
    ''' 機能：Intranetログイン
    ''' </summary>
    ''' <param name="intProcCd">処理CD</param>
    ''' <param name="cc">クッキー</param>
    ''' <param name="strObamaUrl">OIO-BAMMAサーバーＵＲＬ</param>
    ''' <param name="strMsg">ログ出力用メッセージ</param>
    ''' <returns>True:正常 False:エラー</returns>
    ''' <remarks></remarks>
    Public Function LoginServer(ByVal intProcCd As Integer, ByRef cc As CookieContainer, ByRef strObamaUrl As String, ByRef strMsg As String) As Integer

        Dim strUrlLogin As String
        Dim LoginUserId As String
        Dim LoginPassword As String
        Dim frm As New Frm_IntraLogin
        Dim oe As New OutputExcel

        LoginServer = RET_SYS_ERROR

        Try
            '=============================================
            '初期設定
            '=============================================
            Dim fileName As New StringBuilder
            fileName.Append(FileManager.GetLocalFolderPath(CommonConstant.FOLDERNAME_XML))
            fileName.Append("LocalConnectionInfo.xml")

            'XmlSerializerオブジェクトの作成
            Dim serializer As New Serialization.XmlSerializer(GetType(LocalConnectionInfo))
            'ファイルを開く
            Dim fsXml As New FileStream(fileName.ToString(), FileMode.Open, FileAccess.Read)
            'XMLファイルから読み込み、逆シリアル化する
            Dim info As LocalConnectionInfo = CType(serializer.Deserialize(fsXml), LocalConnectionInfo)
            '閉じる
            fsXml.Close()

            If intProcCd = OutputExcel.CD_PROC_OLD Then
                strObamaUrl = info.OioBama_Url_Maps
            Else
                strObamaUrl = info.OioBama_Url
            End If
            strUrlLogin = strObamaUrl & "login.wss"

            '=============================================
            'ログイン
            '=============================================
            LoginUserId = CommonVariable.USERID
            LoginPassword = CommonVariable.USERPW

            Dim wreqLogin As System.Net.HttpWebRequest = CType(System.Net.WebRequest.Create(strUrlLogin), HttpWebRequest)
            wreqLogin.CookieContainer = cc

            '認証の設定
            wreqLogin.Credentials = New NetworkCredential(LoginUserId, LoginPassword)

            'HttpWebResponseの取得
            Dim wresLogin As HttpWebResponse = CType(wreqLogin.GetResponse(), HttpWebResponse)
            wresLogin.Close()

            LoginServer = RET_OK

        Catch ex As Exception
            strMsg = ex.Message.ToString & "(LoginServer)"

        Finally
            frm.Close()

        End Try

    End Function

    ''' <summary>
    ''' OIO-BAMAサーバーからCSVをダウンロードする
    ''' </summary>
    ''' <param name="strCpNo"></param>
    ''' <param name="strContractNo"></param>
    ''' <param name="strLockFlag"></param>
    ''' <param name="strObamaUrl"></param>
    ''' <param name="cc"></param>
    ''' <param name="strPath"></param>
    ''' <param name="strFileName"></param>
    ''' <param name="strMsg"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetServerCsvs(ByVal strCpNo As String,
                                  ByVal strContractNo As String,
                                  ByVal strLockFlag As String,
                                  ByVal strObamaUrl As String,
                                  ByVal cc As CookieContainer,
                                  ByVal strPath As String,
                                  ByRef strFileName() As String,
                                  ByRef strMsg As String) As Integer

        Dim intRet As Integer
        Dim strUrl As String
        Dim blnNoFile As Boolean = False

        GetServerCsvs = RET_SYS_ERROR

        Try
            '=============================================
            'Paymentline
            '=============================================
            '統合
            If Me.GetPsCsvFlg = True Then
                strUrl = strObamaUrl & "downloadPLine.wss?cpno=" & strCpNo
                If strContractNo = "" And strLockFlag = "" Then
                    strUrl = strUrl & "&downloadall=true"
                Else
                    If strContractNo <> "" Then
                        strUrl = strUrl & "&contract=" & strContractNo
                    End If
                    If strLockFlag <> "" Then
                        strUrl = strUrl & "&lock_flag=" & strLockFlag
                    End If
                End If
                intRet = GetServerCsv(strUrl, cc, strPath, strFileName(0), strMsg, "Payment Line(統合)")
                If intRet = RET_SYS_ERROR Then
                    Exit Function
                ElseIf intRet = RET_NO_FILE Then
                    blnNoFile = True
                End If
            End If
            'インポートValidation Log
            If Me.GetPsValCsvFlg = True Then
                strUrl = strObamaUrl & "downloadValidationLog.wss?cpno=" & strCpNo & "&validFlag=PL_I"
                intRet = GetServerCsv(strUrl, cc, strPath, strFileName(1), strMsg, "Payment Line インポートValidation Log")
                If intRet = RET_SYS_ERROR Then
                    Exit Function
                ElseIf intRet = RET_NO_FILE Then
                    blnNoFile = True
                End If
            End If
            'リフレッシュValidation Log
            If Me.GetPsRefCsvFlg = True Then
                strUrl = strObamaUrl & "downloadValidationLog.wss?cpno=" & strCpNo & "&validFlag=PL_R"
                intRet = GetServerCsv(strUrl, cc, strPath, strFileName(2), strMsg, "Payment Line リフレッシュValidation Log")
                If intRet = RET_SYS_ERROR Then
                    Exit Function
                ElseIf intRet = RET_NO_FILE Then
                    blnNoFile = True
                End If
            End If


            '=============================================
            '個別詳細
            '=============================================
            '統合
            If Me.GetDetailCsvFlg = True Then
                strUrl = strObamaUrl & "downloadPLineDetail.wss?cpno=" & strCpNo
                If strContractNo = "" And strLockFlag = "" Then
                    strUrl = strUrl & "&downloadall=true"
                Else
                    If strContractNo <> "" Then
                        strUrl = strUrl & "&contract=" & strContractNo
                    End If
                    If strLockFlag <> "" Then
                        strUrl = strUrl & "&lock_flag=" & strLockFlag
                    End If
                End If
                intRet = GetServerCsv(strUrl, cc, strPath, strFileName(3), strMsg, "個別詳細（統合）")
                If intRet = RET_SYS_ERROR Then
                    Exit Function
                ElseIf intRet = RET_NO_FILE Then
                    blnNoFile = True
                End If
            End If
            'インポートValidation Log
            If Me.GetDetailValCsvFlg = True Then
                strUrl = strObamaUrl & "downloadValidationLog.wss?cpno=" & strCpNo & "&validFlag=PLD_I"
                intRet = GetServerCsv(strUrl, cc, strPath, strFileName(4), strMsg, "個別詳細 インポートValidation Log")
                If intRet = RET_SYS_ERROR Then
                    Exit Function
                ElseIf intRet = RET_NO_FILE Then
                    blnNoFile = True
                End If
            End If
            'リフレッシュValidation Log
            If Me.GetDetailRefCsvFlg = True Then
                strUrl = strObamaUrl & "downloadValidationLog.wss?cpno=" & strCpNo & "&validFlag=PLD_R"
                intRet = GetServerCsv(strUrl, cc, strPath, strFileName(5), strMsg, "個別詳細 リフレッシュValidation Log")
                If intRet = RET_SYS_ERROR Then
                    Exit Function
                ElseIf intRet = RET_NO_FILE Then
                    blnNoFile = True
                End If
            End If

            If blnNoFile = True Then
                GetServerCsvs = RET_NO_FILE
            Else
                GetServerCsvs = RET_OK
            End If

        Catch ex As Exception
            strMsg = ex.Message.ToString & "(GetServerCsvs)"

        End Try

    End Function

    'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
    ''' <summary>
    ''' サーバー直接インポート
    ''' </summary>
    ''' <param name="strPsFileName"></param>
    ''' <param name="strPsdFileName"></param>
    ''' <param name="waitDialog"></param>
    ''' <param name="outErr"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function DirectServerCsvImport(ByVal strPsFileName As String,
                                          ByVal strPsdFileName As String,
                                          ByVal strImpotMethodPs As String,
                                          ByVal strImpotMethodPsd As String,
                                          ByRef waitDialog As Frm_WaitDialog,
                                          ByRef outErr As OutputErrorList) As Boolean

        Dim strUrl As String
        Dim req As System.Net.HttpWebRequest
        Dim strId As String = CommonVariable.USERID
        Dim strPass As String = CommonVariable.USERPW
        Dim strSendMsg As String = ""
        Dim strBoundary As String
        Dim strFileNamePs As String
        Dim strFileNamePsd As String
        Dim cc As CookieContainer = New CookieContainer()       'クッキー設定
        Dim sr As StreamReader
        Dim strErrMsg As String
        Dim strBaseUrl As String

        Const STR_LINE As String = "-----------------------------"

        Debug.Print(Now.ToString("yyyyy/MM/dd HH:mm:ss") & ":開始")
        Dim dtStart As Date = Now

        DirectServerCsvImport = False

        Try
            '=========================================================
            'ログイン
            '=========================================================
            If Not waitDialog Is Nothing Then
                waitDialog.lbl_Message.Text = "サーバーログイン"
                waitDialog.Activate()
                waitDialog.Refresh()
            End If
            outErr.OutExportErrorList("サーバーログイン", "Export", , , False)

            Dim mmc As New MasterMdbControl
            strBaseUrl = mmc.GetMasterMbdPath.OioBama_Url
            strUrl = strBaseUrl & "login.wss"
            Dim wreqLogin As System.Net.HttpWebRequest = CType(System.Net.WebRequest.Create(strUrl), HttpWebRequest)
            wreqLogin.CookieContainer = cc

            '認証の設定
            wreqLogin.Credentials = New NetworkCredential(strId, strPass)

            'HttpWebResponseの取得
            Dim wresLogin As HttpWebResponse = CType(wreqLogin.GetResponse(), HttpWebResponse)
            wresLogin.Close()

            '=========================================================
            '送信メッセージ
            '=========================================================
            If Not waitDialog Is Nothing Then
                waitDialog.lbl_Message.Text = "送信メッセージ作成"
                waitDialog.Activate()
                waitDialog.Refresh()
            End If
            outErr.OutExportErrorList("送信メッセージ作成", "Export", , , False)

            'ヘッダー
            strUrl = strBaseUrl & "import.wss"
            req = CType(System.Net.WebRequest.Create(strUrl), HttpWebRequest)
            req.Method = "POST"
            req.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
            req.Referer = strBaseUrl & "menu.wss?funcId=I000"
            req.Headers.Add("Accept-Encoding", "gzip,deflate")
            req.KeepAlive = True
            req.ServicePoint.Expect100Continue = False
            req.CookieContainer = cc
            'ContentTypeを設定
            strBoundary = System.Environment.TickCount.ToString()
            req.ContentType = "multipart/form-data; boundary=---------------------------" & strBoundary

            'タイムアウト時間設定（ミリ秒）
            req.Timeout = 600000

            '---------------------------------------------------------
            'Payment
            '---------------------------------------------------------
            'ファイルのデータ
            strFileNamePs = Path.GetFileName(strPsFileName)
            strSendMsg = strSendMsg & STR_LINE & strBoundary & vbCrLf
            strSendMsg = strSendMsg & "Content-Disposition: form-data; name=""csvPaymentLine""; filename=""" & strFileNamePs & """" & vbCrLf
            If strFileNamePs = "" Then
                strSendMsg = strSendMsg & "Content-Type: application/octet-stream" & vbCrLf
                strSendMsg = strSendMsg & vbCrLf
            Else
                strSendMsg = strSendMsg & "Content-Type: application/csv" & vbCrLf
                strSendMsg = strSendMsg & vbCrLf
                sr = New StreamReader(strPsFileName, Encoding.GetEncoding("shift-jis"))
                strSendMsg = strSendMsg & sr.ReadToEnd
                sr.Close()
            End If

            'インポート種類
            If strImpotMethodPs <> "" Then
                strSendMsg = strSendMsg & STR_LINE & strBoundary & vbCrLf
                strSendMsg = strSendMsg & "Content-Disposition: form-data; name=""importMethod""" & vbCrLf
                strSendMsg = strSendMsg & vbCrLf
                strSendMsg = strSendMsg & strImpotMethodPs & vbCrLf
            End If

            '何かのフラグ
            strSendMsg = strSendMsg & STR_LINE & strBoundary & vbCrLf
            strSendMsg = strSendMsg & "Content-Disposition: form-data; name=""customerFlag""" & vbCrLf
            strSendMsg = strSendMsg & vbCrLf
            strSendMsg = strSendMsg & "M" & vbCrLf

            '---------------------------------------------------------
            '詳細
            '---------------------------------------------------------
            'ファイルのデータ
            strFileNamePsd = IO.Path.GetFileName(strPsdFileName)
            strSendMsg = strSendMsg & STR_LINE & strBoundary & vbCrLf
            strSendMsg = strSendMsg & "Content-Disposition: form-data; name=""csvFeature""; filename=""" & strFileNamePsd & """" & vbCrLf
            If strFileNamePsd = "" Then
                strSendMsg = strSendMsg & "Content-Type: application/octet-stream" & vbCrLf
                strSendMsg = strSendMsg & vbCrLf
            Else
                strSendMsg = strSendMsg & "Content-Type: application/csv" & vbCrLf
                strSendMsg = strSendMsg & vbCrLf
                sr = New StreamReader(strPsdFileName, Encoding.GetEncoding("shift-jis"))
                strSendMsg = strSendMsg & sr.ReadToEnd
                sr.Close()
            End If

            'インポート種類
            If strImpotMethodPsd <> "" Then
                strSendMsg = strSendMsg & STR_LINE & strBoundary & vbCrLf
                strSendMsg = strSendMsg & "Content-Disposition: form-data; name=""importDetail""" & vbCrLf
                strSendMsg = strSendMsg & vbCrLf
                strSendMsg = strSendMsg & strImpotMethodPsd & vbCrLf
            End If

            '何か
            strSendMsg = strSendMsg & STR_LINE & strBoundary & vbCrLf
            strSendMsg = strSendMsg & "Content-Disposition: form-data; name=""import""" & vbCrLf
            strSendMsg = strSendMsg & vbCrLf
            strSendMsg = strSendMsg & "インポート" & vbCrLf
            strSendMsg = strSendMsg & STR_LINE & strBoundary & "--" & vbCrLf

            If Not waitDialog Is Nothing Then
                waitDialog.lbl_Message.Text = "CSV送信中"
                waitDialog.Activate()
                waitDialog.Refresh()
            End If
            outErr.OutExportErrorList("CSV送信中", "Export", , , False)

            req.ContentLength = Encoding.Default.GetBytes(strSendMsg).Length
            'バイト型配列に変換
            Dim postDataBytes As Byte() = Encoding.Default.GetBytes(strSendMsg)
            'データをPOST送信するためのStreamを取得
            Dim reqStream As Stream = req.GetRequestStream()
            '送信するデータを書き込む
            reqStream.Write(postDataBytes, 0, postDataBytes.Length)
            reqStream.Close()

            '=========================================================
            '受信メッセージ
            '=========================================================
            If Not waitDialog Is Nothing Then
                waitDialog.lbl_Message.Text = "サーバーから応答待ち中"
                waitDialog.Activate()
                waitDialog.Refresh()
            End If
            outErr.OutExportErrorList("サーバーから応答待ち中", "Export", , , False)

            'サーバーからの応答を受信するためのWebResponseを取得
            Dim res As System.Net.WebResponse = req.GetResponse()
            '応答データを受信するためのStreamを取得
            Dim resStream As System.IO.Stream = res.GetResponseStream()
            sr = New System.IO.StreamReader(resStream, System.Text.Encoding.UTF8)
            Dim strRecieveMsg As String
            strRecieveMsg = sr.ReadToEnd
            sr.Close()

            Debug.Print(Now.ToString("yyyyy/MM/dd HH:mm:ss") & ":受信完了")
            Debug.Print(strRecieveMsg)
            outErr.OutExportErrorList("サーバーから応答 解析中", "Export", , , False)

            Dim intPos As Integer
            intPos = strRecieveMsg.IndexOf("<p class=""ibm-ind-error"">")
            If intPos >= 0 Then
                strErrMsg = strRecieveMsg.Substring(intPos + ("<p class=""ibm-ind-error"">").Length)
                strErrMsg = strErrMsg.Substring(0, (strErrMsg.IndexOf("</p>")))
                MsgBox(strErrMsg, MsgBoxStyle.Critical, "Error")
                Exit Function
            Else
                intPos = strRecieveMsg.IndexOf("<p class=""ibm-ind-information"">")
                If intPos >= 0 Then
                    strErrMsg = strRecieveMsg.Substring(intPos + ("<p class=""ibm-ind-information"">").Length)
                    strErrMsg = strErrMsg.Substring(0, (strErrMsg.IndexOf("</p>")))
                    intPos = strErrMsg.IndexOf("<br />")
                    If intPos >= 0 Then
                        strErrMsg = strErrMsg.Substring(0, intPos) & vbCrLf & strErrMsg.Substring(intPos + ("<br />").Length)
                    End If
                End If
            End If

            DirectServerCsvImport = True

        Catch ex As Exception
            Dim strExMsg As String = ex.Message.ToString
            If strExMsg = "リモート サーバーがエラーを返しました: (503) サーバーを使用できません" Then
                Debug.Print(Now.ToString("yyyyy/MM/dd HH:mm:ss") & ":「" & strExMsg & "」発生")
                outErr.OutExportErrorList("「" & strExMsg & "」発生", "Export", , , False)

                '応答はエラーだがサーバーでは処理が続行している可能性があるため
                'T_CUSTOMERのP_STATUS、D_STATUSを検索して判断する
                Dim blnRet As Boolean
                blnRet = checkValidationStatus(outErr)
                If blnRet = False Then
                    Exit Function
                End If
                DirectServerCsvImport = True
            Else
                Debug.Print(Now.ToString("yyyyy/MM/dd HH:mm:ss") & ":Error")
                outErr.OutExportErrorList(ex.Message.ToString, "Export", , , False)
                MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "Error")
            End If
        End Try

    End Function
    'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

#End Region

#Region "Private"
    ''' <summary>
    ''' 機能：サーバーからCSVファイルを取得
    ''' </summary>
    ''' <param name="strUrlDownLoad1"></param>
    ''' <param name="cc"></param>
    ''' <param name="strPath"></param>
    ''' <param name="strFileName"></param>
    ''' <param name="strMsg">ログ出力用メッセージ</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetServerCsv(ByVal strUrlDownLoad As String, ByVal cc As CookieContainer, ByVal strPath As String, ByRef strFileName As String, ByRef strMsg As String, ByVal strAddMsg As String) As Integer

        Dim strWork As String
        Dim intPos As Integer
        Dim wreqDownload As HttpWebRequest
        Dim wresDownload As HttpWebResponse
        Dim streamDownload As Stream
        Dim intReadByte As Integer

        GetServerCsv = RET_SYS_ERROR

        Try
            '=============================================
            'ファイルダウンロード
            '=============================================
            wreqDownload = CType(WebRequest.Create(strUrlDownLoad), HttpWebRequest)
            wreqDownload.CookieContainer = cc
            wresDownload = CType(wreqDownload.GetResponse(), HttpWebResponse)

            'ファイル名取得
            strWork = wresDownload.Headers.ToString
            intPos = strWork.IndexOf("filename=")
            If intPos = -1 Then
                wresDownload.Close()
                strMsg = strMsg & strAddMsg & "：CSVファイルが存在しません。" & vbCrLf
                GetServerCsv = RET_NO_FILE
                Exit Function
            Else
                strWork = strWork.Substring(intPos + 9)
                intPos = strWork.LastIndexOf(".csv")
                If intPos = -1 Then
                    wresDownload.Close()
                    strMsg = strMsg & strAddMsg & "：CSVファイルが存在しません。" & vbCrLf
                    GetServerCsv = RET_NO_FILE
                    Exit Function
                End If
                strFileName = strWork.Substring(0, intPos + 4)
            End If

            '受信
            streamDownload = wresDownload.GetResponseStream()

            'ファイルに書き込むためのFileStreamを作成
            Dim fs As New FileStream(strPath & strFileName, FileMode.Create, FileAccess.Write)

            '応答データをファイルに書き込む
            Dim readData As Byte() = New Byte(1023) {}
            While True
                'データを読み込む
                Dim readSize As Integer = streamDownload.Read(readData, 0, readData.Length)
                If readSize = 0 Then
                    'すべてのデータを読み込んだ時
                    Exit While
                End If
                '読み込んだデータをファイルに書き込む
                fs.Write(readData, 0, readSize)
            End While
            fs.Close()
            fs.Dispose()
            streamDownload.Close()
            wresDownload.Close()

            GetServerCsv = RET_OK

        Catch ex As Exception
            strMsg = strAddMsg & "：" & ex.Message.ToString & "(GetServerCsv)"

        End Try

    End Function

    'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
    ''' <summary>
    ''' Validation Status チェック処理
    ''' </summary>
    ''' <param name="outErr"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function checkValidationStatus(ByRef outErr As OutputErrorList) As Boolean

        Dim wc As New WebDb.WebDbCommon
        Dim blnRet As Boolean
        Dim strMsg As String
        Dim dt As New M_CONTRACT_BASETable
        Dim oc As New OioControl
        Dim dtTerm As DataTable
        Dim dtInterval As DataTable
        Dim intTerm As Integer = 0
        Dim intInterval As Integer = 0
        Dim intCnt As Integer
        Dim strPStatus As String
        Dim strDStatus As String
        Dim blnCheck As Boolean = False     'Validation正常:True、Validation異常:False

        checkValidationStatus = False
        blnCheck = False

        Try
            'Validationtチェック期間（秒）を取得
            dtTerm = oc.GetCodeData("checkValdationTerm", CommonVariable.MdbPW)
            If dtTerm.Rows.Count > 0 Then
                intTerm = Integer.Parse(dtTerm.Rows(0).Item("ItemValue"))
            End If
            'Validationtチェック間隔（秒）を取得
            dtInterval = oc.GetCodeData("checkValdationInterval", CommonVariable.MdbPW)
            If dtInterval.Rows.Count > 0 Then
                intInterval = Integer.Parse(dtInterval.Rows(0).Item("ItemValue"))
            End If

            outErr.OutExportErrorList("チェック期間：" & intTerm.ToString & "秒", "Export", , , False)
            outErr.OutExportErrorList("チェック間隔：" & intInterval.ToString & "秒", "Export", , , False)

            '
            For intCnt = 1 To (intTerm / intInterval)
                'sleep
                System.Threading.Thread.Sleep(intInterval * 1000)

                Debug.Print(Now.ToString("yyyyy/MM/dd HH:mm:ss") & ":チェック　" & intCnt.ToString & "回目")
                outErr.OutExportErrorList("チェック　" & intCnt.ToString & "回目", "Export", , , False)

                '契約基本情報取得
                wc.IntraId = CommonVariable.USERID
                wc.IntraPass = CommonVariable.USERPW
                blnRet = wc.GetContractBaseData(CommonVariable.CPNO, dt, strMsg)
                If blnRet = False Then
                    MsgBox(strMsg, vbCritical, "checkValidationStatus")
                    Exit Function
                End If

                'P_STATUS、D_STATUS判定
                strPStatus = dt.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_P_STATUS)
                strDStatus = dt.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_D_STATUS)

                'Paymentまたは詳細がエラーの場合、エラーで返す
                If strPStatus = "E" Or strDStatus = "E" Then
                    outErr.OutExportErrorList(FileReader.GetMessage("MSG_0497"), "Export", , , False)
                    MsgBox(FileReader.GetMessage("MSG_0497"), vbCritical, "checkValidationStatus")
                    Exit Function
                End If
                'Payment、詳細が共にValidation済みの場合、正常終了
                If strPStatus = "C" And strDStatus = "C" Then
                    blnCheck = True
                    Exit For
                End If
            Next

            'チェック期間中にValidationが終了しなかった場合、異常終了
            If blnCheck = False Then
                outErr.OutExportErrorList(FileReader.GetMessage("MSG_0498"), "Export", , , False)
                MsgBox(FileReader.GetMessage("MSG_0498"), vbCritical, "checkValidationStatus")
                Exit Function
            End If

            checkValidationStatus = True

        Catch ex As Exception
            outErr.OutExportErrorList(ex.Message.ToString, "Export", , , False)
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "checkValidationStatus")
        End Try

    End Function
    'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

#End Region

End Class
