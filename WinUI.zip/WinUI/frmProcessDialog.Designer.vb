﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmProcessDialog
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblMsg1 = New System.Windows.Forms.Label()
        Me.lblMsg2 = New System.Windows.Forms.Label()
        Me.lblMsg3 = New System.Windows.Forms.Label()
        Me.lblMsg4 = New System.Windows.Forms.Label()
        Me.lblProc1 = New System.Windows.Forms.Label()
        Me.lblProc2 = New System.Windows.Forms.Label()
        Me.lblProc3 = New System.Windows.Forms.Label()
        Me.lblProc4 = New System.Windows.Forms.Label()
        Me.lblProc5 = New System.Windows.Forms.Label()
        Me.lblProc6 = New System.Windows.Forms.Label()
        Me.lblProc7 = New System.Windows.Forms.Label()
        Me.lblProc8 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblMsg1
        '
        Me.lblMsg1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblMsg1.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblMsg1.Location = New System.Drawing.Point(16, 11)
        Me.lblMsg1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblMsg1.Name = "lblMsg1"
        Me.lblMsg1.Size = New System.Drawing.Size(834, 23)
        Me.lblMsg1.TabIndex = 0
        Me.lblMsg1.Text = "Label1"
        '
        'lblMsg2
        '
        Me.lblMsg2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblMsg2.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblMsg2.Location = New System.Drawing.Point(16, 35)
        Me.lblMsg2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblMsg2.Name = "lblMsg2"
        Me.lblMsg2.Size = New System.Drawing.Size(834, 23)
        Me.lblMsg2.TabIndex = 1
        Me.lblMsg2.Text = "Label2"
        '
        'lblMsg3
        '
        Me.lblMsg3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblMsg3.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblMsg3.Location = New System.Drawing.Point(16, 59)
        Me.lblMsg3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblMsg3.Name = "lblMsg3"
        Me.lblMsg3.Size = New System.Drawing.Size(834, 23)
        Me.lblMsg3.TabIndex = 2
        Me.lblMsg3.Text = "Label3"
        '
        'lblMsg4
        '
        Me.lblMsg4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblMsg4.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblMsg4.Location = New System.Drawing.Point(16, 82)
        Me.lblMsg4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblMsg4.Name = "lblMsg4"
        Me.lblMsg4.Size = New System.Drawing.Size(834, 23)
        Me.lblMsg4.TabIndex = 3
        Me.lblMsg4.Text = "Label4"
        '
        'lblProc1
        '
        Me.lblProc1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblProc1.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblProc1.Location = New System.Drawing.Point(16, 106)
        Me.lblProc1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblProc1.Name = "lblProc1"
        Me.lblProc1.Size = New System.Drawing.Size(417, 23)
        Me.lblProc1.TabIndex = 4
        Me.lblProc1.Text = "Process1"
        '
        'lblProc2
        '
        Me.lblProc2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblProc2.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblProc2.Location = New System.Drawing.Point(16, 130)
        Me.lblProc2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblProc2.Name = "lblProc2"
        Me.lblProc2.Size = New System.Drawing.Size(417, 23)
        Me.lblProc2.TabIndex = 5
        Me.lblProc2.Text = "Process2"
        '
        'lblProc3
        '
        Me.lblProc3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblProc3.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblProc3.Location = New System.Drawing.Point(16, 154)
        Me.lblProc3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblProc3.Name = "lblProc3"
        Me.lblProc3.Size = New System.Drawing.Size(417, 23)
        Me.lblProc3.TabIndex = 6
        Me.lblProc3.Text = "Process3"
        '
        'lblProc4
        '
        Me.lblProc4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblProc4.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblProc4.Location = New System.Drawing.Point(16, 178)
        Me.lblProc4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblProc4.Name = "lblProc4"
        Me.lblProc4.Size = New System.Drawing.Size(417, 23)
        Me.lblProc4.TabIndex = 7
        Me.lblProc4.Text = "Process4"
        '
        'lblProc5
        '
        Me.lblProc5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblProc5.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblProc5.Location = New System.Drawing.Point(433, 106)
        Me.lblProc5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblProc5.Name = "lblProc5"
        Me.lblProc5.Size = New System.Drawing.Size(417, 23)
        Me.lblProc5.TabIndex = 11
        Me.lblProc5.Text = "Process5"
        '
        'lblProc6
        '
        Me.lblProc6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblProc6.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblProc6.Location = New System.Drawing.Point(433, 130)
        Me.lblProc6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblProc6.Name = "lblProc6"
        Me.lblProc6.Size = New System.Drawing.Size(417, 23)
        Me.lblProc6.TabIndex = 10
        Me.lblProc6.Text = "Process6"
        '
        'lblProc7
        '
        Me.lblProc7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblProc7.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblProc7.Location = New System.Drawing.Point(433, 154)
        Me.lblProc7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblProc7.Name = "lblProc7"
        Me.lblProc7.Size = New System.Drawing.Size(417, 23)
        Me.lblProc7.TabIndex = 9
        Me.lblProc7.Text = "Process7"
        '
        'lblProc8
        '
        Me.lblProc8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblProc8.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblProc8.Location = New System.Drawing.Point(433, 178)
        Me.lblProc8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblProc8.Name = "lblProc8"
        Me.lblProc8.Size = New System.Drawing.Size(417, 23)
        Me.lblProc8.TabIndex = 8
        Me.lblProc8.Text = "Process8"
        '
        'frmProcessDialog
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(873, 219)
        Me.ControlBox = False
        Me.Controls.Add(Me.lblProc5)
        Me.Controls.Add(Me.lblProc6)
        Me.Controls.Add(Me.lblProc7)
        Me.Controls.Add(Me.lblProc8)
        Me.Controls.Add(Me.lblProc4)
        Me.Controls.Add(Me.lblProc3)
        Me.Controls.Add(Me.lblProc2)
        Me.Controls.Add(Me.lblProc1)
        Me.Controls.Add(Me.lblMsg4)
        Me.Controls.Add(Me.lblMsg3)
        Me.Controls.Add(Me.lblMsg2)
        Me.Controls.Add(Me.lblMsg1)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmProcessDialog"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lblMsg1 As System.Windows.Forms.Label
    Friend WithEvents lblMsg2 As System.Windows.Forms.Label
    Friend WithEvents lblMsg3 As System.Windows.Forms.Label
    Friend WithEvents lblMsg4 As System.Windows.Forms.Label
    Friend WithEvents lblProc1 As System.Windows.Forms.Label
    Friend WithEvents lblProc2 As System.Windows.Forms.Label
    Friend WithEvents lblProc3 As System.Windows.Forms.Label
    Friend WithEvents lblProc4 As System.Windows.Forms.Label
    Friend WithEvents lblProc5 As System.Windows.Forms.Label
    Friend WithEvents lblProc6 As System.Windows.Forms.Label
    Friend WithEvents lblProc7 As System.Windows.Forms.Label
    Friend WithEvents lblProc8 As System.Windows.Forms.Label
End Class
