﻿Imports System.Text
Imports System.IO
Imports MUSE.Utility
Imports MUSE.Utility.OioBamaCommmon
Imports MUSE.Utility.SharedClass
Imports MUSE.DataAccess.OleDb
Imports System.Data.OleDb
Imports MUSE.Utility.UserDataTable.Master

Public Class CreateTempDb

    Private Const DELIMITA As String = ","
    Const FILENAME_CSV_TBL1 As String = "WorkCsv_PsTbl1"
    Const FILENAME_CSV_TBL2 As String = "WorkCsv_PsTbl2"
    Const FILENAME_CSV_TBL3 As String = "WorkCsv_PsTbl3"
    Const FILENAME_CSV_TBL4 As String = "WorkCsv_PsTbl4"
    Const FILENAME_CSV_OEDERSORT As String = "WorkCsv_PsOrderSort"
    Const FILENAME_CSV_PSD As String = "WorkCsv_PsdTbl"
    Const FILENAME_CSV_SCHEMA As String = "schema.ini"
    Const EXTENSION_CSV As String = ".csv"

#Region "Public"

    ''' <summary>
    ''' 概    要  ：契約締結済みのデータをMDBへ保管する。
    ''' 説    明  ：※大量データInsertの処理を高速化するために、
    '''               Microsoft ActiveX Object LibrallyのRecordSetを使用
    ''' </summary>
    ''' <param name="rtnMDBPath"></param>
    ''' <param name="arrayWriteObjLine"></param>
    ''' <param name="strStartYear"></param>
    ''' <param name="errCount"></param>
    ''' <param name="OUTERR"></param>
    ''' <param name="blnCreatingMdb">作成中MDBﾌﾗｸﾞ　True：作成する、False：作成しない</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function CreateDataKeepMDB(ByRef rtnMDBPath As String,
                                      ByRef arrayWriteObjLine As ArrayList,
                                      ByVal strStartYear As String, _
                                      ByRef errCount As Integer, _
                                      ByRef OUTERR As OutputErrorList,
                                      Optional ByVal blnCreatingMdb As Boolean = False) As Integer

        Dim ofm As New OioFileManage
        Dim tmpMDBPath As String
        Dim outMDBPath As String
        Dim strCsvPath As String
        Dim strIniPath As String
        '2018/11 AccessViolation防止 Str
        'Dim con As New ADODB.Connection()
        Dim con As New ADODB.Connection
        '2018/11 AccessViolation防止 End
        Dim cmd As ADODB.Command
        Dim strCreateDate As String = "_" & Now.ToString("yyyyMMdd_HHmmss")
        Dim strFileName As String

        CreateDataKeepMDB = -1

        ''※エラー処理の概要
        ''　エラーが発生したら、ImportErrログを出力して処理終了
        Try
            '===========================================
            '初期設定
            '===========================================
            strCsvPath = Path.GetFullPath("../log/")
            strIniPath = strCsvPath
            '作業ファイル削除
            Call ofm.DeleteWorkFile(strCsvPath, strIniPath)

            '===========================================
            '作業用CSV出力
            '===========================================
            'CSV作成
            Call OutputCsvPsTable(strCreateDate, arrayWriteObjLine, strStartYear, strCsvPath)
            'schema.ini
            Call OutputSchemaPs(strCreateDate, strIniPath)

            '===========================================
            'テンプレートMDBのｺﾋﾟｰ
            '===========================================
            If blnCreatingMdb = False Then
                tmpMDBPath = ofm.GetLocalTempMDBPath
            Else
                tmpMDBPath = ofm.GetLocalTempCreatingMDBPath
            End If
            If rtnMDBPath = "" Then
                If blnCreatingMdb = False Then
                    outMDBPath = ofm.GetDataKeepMDBPath(CommonVariable.CPNO)
                Else
                    outMDBPath = ofm.GetDataCreatingMDBPath(CommonVariable.CPNO)
                End If
            Else
                outMDBPath = rtnMDBPath
            End If
            File.Delete(outMDBPath)
            File.Copy(tmpMDBPath, outMDBPath, True)

            '===========================================
            'DB更新
            '===========================================
            'DB接続
            Dim mmc As New MasterMdbControl
            If blnCreatingMdb = False Then
                con = mmc.GetAdoTmpDBConnection(CommonVariable.CPNO, CommonVariable.MdbPW)
            Else
                con = mmc.GetAdoTmpDBPConnection(CommonVariable.CPNO, CommonVariable.MdbPW)
            End If
            cmd = New ADODB.Command
            cmd.ActiveConnection = con

            'PaymentTBL1
            strFileName = FILENAME_CSV_TBL1 & strCreateDate & EXTENSION_CSV
            cmd.CommandText = "INSERT INTO [PaymentTBL1] SELECT * FROM [Text;Database=" & strCsvPath & "].[" & strFileName & "]"
            cmd.Execute()
            'PaymentTBL2
            strFileName = FILENAME_CSV_TBL2 & strCreateDate & EXTENSION_CSV
            cmd.CommandText = "INSERT INTO [PaymentTBL2] SELECT * FROM [Text;Database=" & strCsvPath & "].[" & strFileName & "]"
            cmd.Execute()
            'PaymentTBL3
            strFileName = FILENAME_CSV_TBL3 & strCreateDate & EXTENSION_CSV
            cmd.CommandText = "INSERT INTO [PaymentTBL3] SELECT * FROM [Text;Database=" & strCsvPath & "].[" & strFileName & "]"
            cmd.Execute()
            'PaymentTBL4
            strFileName = FILENAME_CSV_TBL4 & strCreateDate & EXTENSION_CSV
            cmd.CommandText = "INSERT INTO [PaymentTBL4] SELECT * FROM [Text;Database=" & strCsvPath & "].[" & strFileName & "]"
            cmd.Execute()
            'FrmDataOutPut_OrderSort
            strFileName = FILENAME_CSV_OEDERSORT & strCreateDate & EXTENSION_CSV
            cmd.CommandText = "INSERT INTO [FrmDataOutPut_OrderSort] SELECT * FROM [Text;Database=" & strCsvPath & "].[" & strFileName & "]"
            cmd.Execute()

            'TempDBのﾃﾞｰﾀをNullから空文字に置換
            OUTERR.OutImportErrorList("開始：Nullから空文字", "Import")
            Call SetDBNullToSpace(con, "PaymentTBL1")
            Call SetDBNullToSpace(con, "PaymentTBL2")
            Call SetDBNullToSpace(con, "PaymentTBL3")
            Call SetDBNullToSpace(con, "PaymentTBL4")
            Call SetDBNullToSpace(con, "FrmDataOutPut_OrderSort")
            OUTERR.OutImportErrorList("終了：Nullから空文字", "Import")

            con.Close()

            '===========================================
            '作業ファイル削除
            '===========================================
            Call ofm.DeleteWorkFile(strCsvPath, strIniPath)

            Return arrayWriteObjLine.Count

        Catch ex As Exception

            ''メッセージの処理は呼び出し元で一括して行う。
            ''※契約締結済みMDBﾌｧｲﾙの処理中にエラーが発生しました。
            errCount = -1
            OUTERR.OutImportErrorList(ex.Message, "Import")

        Finally
            ''Connectionのクローズ
            If con.State <> ADODB.ObjectStateEnum.adStateClosed Then
                con.Close()
            End If
        End Try

    End Function

    '--------------------------------------------------------
    '概    要  ：契約締結済みのデータをMDBへ保管する。
    '説    明  ：※大量データInsertの処理を高速化するために、
    '              Microsoft ActiveX Object LibrallyのRecordSetを使用
    '--------------------------------------------------------
    Public Function CreateDataKeepDetailMDB(ByRef rtnMDBPath As String,
                                            ByRef arrayDetailWriteObjLine As ArrayList,
                                            ByRef errCount As Integer, _
                                            ByRef OUTERR As OutputErrorList,
                                            Optional ByVal blnCreatingMdb As Boolean = False) As Integer

        '2018/11 AccessViolation防止 Str
        'Dim con As New ADODB.Connection()
        Dim con As New ADODB.Connection
        '2018/11 AccessViolation防止 End
        Dim cmd As ADODB.Command
        Dim ofm As New OioFileManage
        Dim outMDBPath As String
        Dim strCsvPath As String
        Dim strIniPath As String
        Dim strCreateDate As String = "_" & Now.ToString("yyyyMMdd_HHmmss")
        Dim strFileName As String
        '2018/11 AccessViolation調査 Str
        Dim wStr As String
        '2018/11 AccessViolation調査 End

        CreateDataKeepDetailMDB = -1

        ''※エラー処理の概要
        ''　エラーが発生したら、ImportErrログを出力して処理終了-
        Try
            '===========================================
            '初期設定
            '===========================================
            strCsvPath = Path.GetFullPath("../log/")
            strIniPath = strCsvPath
            '作業ファイル削除
            Call ofm.DeleteWorkFile(strCsvPath, strIniPath)

            '===========================================
            '作業用CSV出力
            '===========================================
            'CSV作成
            Call OutputCsvPsdTable(strCreateDate, arrayDetailWriteObjLine, strCsvPath)
            'schema.ini
            Call OutputSchemaPsd(strCreateDate, strIniPath)

            '===========================================
            'DB更新
            '===========================================
            'DB接続
            If rtnMDBPath = "" Then
                If blnCreatingMdb = False Then
                    outMDBPath = ofm.GetDataKeepMDBPath(CommonVariable.CPNO)
                Else
                    outMDBPath = ofm.GetDataCreatingMDBPath(CommonVariable.CPNO)
                End If
            Else
                outMDBPath = rtnMDBPath
            End If
            Dim mmc As New MasterMdbControl
            If blnCreatingMdb = False Then
                con = mmc.GetAdoTmpDBConnection(CommonVariable.CPNO, CommonVariable.MdbPW)
            Else
                con = mmc.GetAdoTmpDBPConnection(CommonVariable.CPNO, CommonVariable.MdbPW)
            End If
            cmd = New ADODB.Command
            cmd.ActiveConnection = con

            '2018/11 AccessViolation調査 Str
            wStr = "[STEP1]"
            '2018/11 AccessViolation調査 End

            'PaymentDetailTBL
            strFileName = FILENAME_CSV_PSD & strCreateDate & EXTENSION_CSV
            '2018/11 AccessViolation防止 Str
            con.Execute("INSERT INTO [PaymentDetailTBL] SELECT * FROM [Text;Database=" & strCsvPath & "].[" & strFileName & "]")
            'cmd.CommandText = "INSERT INTO [PaymentDetailTBL] SELECT * FROM [Text;Database=" & strCsvPath & "].[" & strFileName & "]"
            'cmd.Execute()
            '2018/11 AccessViolation防止 End

            '2018/11 AccessViolation調査 Str
            wStr = "[STEP2]"
            '2018/11 AccessViolation調査 End

            'TempDBのﾃﾞｰﾀをNullから空文字に置換
            OUTERR.OutImportErrorList("開始：Nullから空文字", "Import")
            Call SetDBNullToSpace(con, "PaymentDetailTBL")
            OUTERR.OutImportErrorList("終了：Nullから空文字", "Import")

            con.Close()

            '===========================================
            '作業ファイル削除
            '===========================================
            Call ofm.DeleteWorkFile(strCsvPath, strIniPath)

            Return arrayDetailWriteObjLine.Count

            '2018/11 AccessViolation調査 Str
        Catch ex As AccessViolationException
            MsgBox(ex.Message & vbCrLf & wStr)
            errCount = -1
            OUTERR.OutImportErrorList(ex.Message, "Import")
            '2018/11 AccessViolation調査 End

        Catch ex As Exception
            ''メッセージの処理は呼び出し元で一括して行う。
            ''※契約締結済みMDBﾌｧｲﾙの処理中にエラーが発生しました。
            errCount = -1
            OUTERR.OutImportErrorList(ex.Message, "Import")

        Finally
            ''Connectionのクローズ
            If con.State <> ADODB.ObjectStateEnum.adStateClosed Then
                con.Close()
            End If

        End Try

    End Function
#End Region

#Region "Private"

    ''' <summary>
    ''' 機　能：カンマ区切りのデータを分解する
    ''' 説　明：ダブルクォーテーション中のカンマも対応する
    ''' </summary>
    ''' <param name="strData">元データ</param>
    ''' <param name="strSplitData">分解後データ</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function SplitData(ByVal strData As String, ByRef strSplitData() As String) As Boolean

        Dim strSplitDelemita() As String        '
        Dim intCnt As Integer                   '
        Dim intIndex As Integer = 0             '
        Dim strWork As String                   '
        Dim intNextDataCtn As Integer           '
        Dim intStartCnt As Integer              '
        Dim intStepCnt As Integer               '
        Dim strComcatData As String             '
        Dim blnComcatData As Boolean            '

        SplitData = False

        '２個続きのダブルクォートを１つに変換する
        strWork = strData.Replace(Chr(34) & Chr(34), Chr(34))
        'カンマ区切りを分解する
        strSplitDelemita = strWork.Split(DELIMITA)

        '分解したデータをチェックする
        For intCnt = 0 To strSplitDelemita.Length - 1
            '両端にダブルクォーテーションがあるか
            If Left(LTrim(strSplitDelemita(intCnt)), 1) = Chr(34) Then
                '右端にダブルクォーテーションが出るまで繰り返す
                intStartCnt = intCnt
                intStepCnt = 0
                strComcatData = ""
                blnComcatData = False
                For intNextDataCtn = intStartCnt To (strSplitDelemita.Length - 1)
                    '次のデータがまだあるか
                    If intNextDataCtn <= (strSplitDelemita.Length - 1) Then
                        '右端にダブルクォーテーションがあるか
                        If Right(RTrim(strSplitDelemita(intNextDataCtn)), 1) = Chr(34) Then
                            '現データ＋結合データ＋カンマ＋次データを結合する
                            If intNextDataCtn = intStartCnt Then
                                strWork = strSplitDelemita(intCnt)
                                intCnt = intCnt + intStepCnt
                            Else
                                strWork = strSplitDelemita(intCnt) & strComcatData & DELIMITA & strSplitDelemita(intNextDataCtn)
                                intCnt = intCnt + intStepCnt + 1
                            End If
                            ReDim Preserve strSplitData(intIndex)
                            '両端のダウブルクォート削除
                            strSplitData(intIndex) = strWork.Substring(1, strWork.Length - 2)
                            intIndex = intIndex + 1
                            blnComcatData = True
                            Exit For
                        Else
                            If intNextDataCtn <> intStartCnt Then
                                strComcatData = strComcatData & DELIMITA & strSplitDelemita(intNextDataCtn)
                                intStepCnt = intStepCnt + 1
                            End If
                        End If
                    End If
                Next

                '右端にデータがなかった場合、通常データとして扱う
                If blnComcatData = False Then
                    ReDim Preserve strSplitData(intIndex)
                    strSplitData(intIndex) = strSplitDelemita(intCnt)
                    intIndex = intIndex + 1
                End If
            Else
                'ダブルクォーテーションがない場合
                ReDim Preserve strSplitData(intIndex)
                strSplitData(intIndex) = strSplitDelemita(intCnt)
                intIndex = intIndex + 1
            End If
        Next

        SplitData = True

    End Function

    ''' <summary>
    ''' 機能；PaymentTBL1～3の作業用CSV出力
    ''' </summary>
    ''' <param name="strCreateDate"></param>
    ''' <param name="arrayWriteObjLine"></param>
    ''' <param name="strStartYear"></param>
    ''' <param name="strCsvPath"></param>
    ''' <remarks></remarks>
    Private Sub OutputCsvPsTable(ByVal strCreateDate As String, ByVal arrayWriteObjLine As ArrayList, ByVal strStartYear As String, ByVal strCsvPath As String)

        Dim sw1 As StreamWriter
        Dim sw2 As StreamWriter
        Dim sw3 As StreamWriter
        Dim swOrderSort As StreamWriter
        Dim intId As Integer
        Dim strOut As String
        Dim intFldCnt As Integer
        Dim intMonthCnt As Integer
        Dim strWork As String

        Try
            sw1 = New StreamWriter(strCsvPath & FILENAME_CSV_TBL1 & strCreateDate & EXTENSION_CSV, False, System.Text.Encoding.Default)
            sw2 = New StreamWriter(strCsvPath & FILENAME_CSV_TBL2 & strCreateDate & EXTENSION_CSV, False, System.Text.Encoding.Default)
            sw3 = New StreamWriter(strCsvPath & FILENAME_CSV_TBL3 & strCreateDate & EXTENSION_CSV, False, System.Text.Encoding.Default)
            swOrderSort = New StreamWriter(strCsvPath & FILENAME_CSV_OEDERSORT & strCreateDate & EXTENSION_CSV, False)
            intId = 1
            For Each obj() As Object In arrayWriteObjLine
                'PaymentTBL1
                strOut = intId.ToString("00000") & ","
                For intFldCnt = ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG To ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM24
                    strWork = ExcelWrite.changeDBNullToString(obj(intFldCnt - 1))
                    strWork = strWork.Replace("""", """""")
                    strOut = strOut & """" & strWork & ""","
                Next
                sw1.WriteLine(strOut)

                'PaymentTBL2
                strOut = intId.ToString("00000") & ","
                For intFldCnt = ExcelWrite.ExcelPaymentLineColumn.WD_ANNT_DATE To ExcelWrite.ExcelPaymentLineColumn.PRICE_DEFF_IGF
                    strWork = ExcelWrite.changeDBNullToString(obj(intFldCnt - 1))
                    strWork = strWork.Replace("""", """""")
                    strOut = strOut & """" & strWork & ""","
                Next
                strWork = ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL - 1))
                strWork = strWork.Replace("""", """""")
                strOut = strOut & """" & strWork & ""","
                sw2.WriteLine(strOut)

                'PaymentTBL3
                For intFldCnt = 1 To 20
                    strOut = intId.ToString("00000") & ","
                    '年
                    strOut = strOut & """" & (Integer.Parse(strStartYear) + intFldCnt - 1).ToString & ""","
                    '年額
                    strOut = strOut & """" & ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1 + intFldCnt - 2)) & ""","
                    '月額
                    For intMonthCnt = 1 To 12
                        strOut = strOut & """" & ExcelWrite.changeDBNullToString(obj((intFldCnt - 1) * 12 + (intMonthCnt - 1) + (ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1 - 1))) & ""","
                    Next
                    sw3.WriteLine(strOut)
                Next

                'FrmDataOutPut_OrderSort
                strOut = OutputCsvPsTableOderSort(intId, obj)
                If strOut <> "" Then
                    swOrderSort.WriteLine(strOut)
                End If

                intId = intId + 1
            Next

            swOrderSort.Close()
            sw3.Close()
            sw2.Close()
            sw1.Close()

            'PaymentTBL4
            Call OutputCsvPsTable4(strCreateDate, arrayWriteObjLine, strStartYear, strCsvPath)

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' 機能；詳細の作業用CSV出力
    ''' </summary>
    ''' <param name="strCreateDate"></param>
    ''' <param name="arrayWriteObjLine"></param>
    ''' <param name="strCsvPath"></param>
    ''' <remarks></remarks>
    Private Sub OutputCsvPsdTable(ByVal strCreateDate As String, ByVal arrayWriteObjLine As ArrayList, ByVal strCsvPath As String)

        Dim sw1 As StreamWriter
        Dim intId As Integer
        Dim strOut As String
        Dim intFldCnt As Integer
        Dim strWork As String

        Try
            sw1 = New StreamWriter(strCsvPath & FILENAME_CSV_PSD & strCreateDate & EXTENSION_CSV, False, System.Text.Encoding.Default)
            intId = 1
            For Each obj() As Object In arrayWriteObjLine
                'PaymentDetail
                strOut = intId.ToString("00000") & ","
                For intFldCnt = ExcelWrite.ExcelPaymentLineDetailColumn.UPDATE_FLAG To ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE
                    strWork = ExcelWrite.changeDBNullToString(obj(intFldCnt - 1))
                    strWork = strWork.Replace("""", """""")
                    strOut = strOut & """" & strWork & ""","
                Next
                sw1.WriteLine(strOut)

                intId = intId + 1
            Next

            sw1.Close()

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' 機能；PaymentTBL4の作業用CSV出力
    ''' </summary>
    ''' <param name="strCreateDate"></param>
    ''' <param name="arrayWriteObjLine"></param>
    ''' <param name="strStartYear"></param>
    ''' <param name="strCsvPath"></param>
    ''' <remarks></remarks>
    Private Sub OutputCsvPsTable4(ByVal strCreateDate As String, ByVal arrayWriteObjLine As ArrayList, ByVal strStartYear As String, ByVal strCsvPath As String)

        Dim diffMonth As Integer
        Dim excelStrYM As DateTime
        Dim contractEndYM As DateTime
        Dim planNo As New ArrayList
        Dim lease As New ArrayList
        Dim finance As New ArrayList
        Dim objLine() As Object
        Dim tmpPlanNO As String
        Dim tmpPrice As Double
        Dim strIdx As Integer
        Dim endIdx As Integer
        Dim isLeath As Boolean
        Dim isFinance As Boolean
        Dim sw4 As StreamWriter
        Dim strOut As String

        Try
            ''契約開始年月-契約終了年月の月数取得
            excelStrYM = CDate(strStartYear & "/" & "1")
            contractEndYM = CommonVariable.ContractEnd
            diffMonth = DateDiff("m", excelStrYM, contractEndYM)

            ''契約期間外のリース/ファイナンス
            strIdx = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1 + diffMonth
            endIdx = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12 - 1
            If diffMonth > 0 And 240 > diffMonth Then
                For Each objLine In arrayWriteObjLine

                    ''ﾘｰｽ/ﾌｧｲﾅﾝｽ判定
                    isLeath = False
                    isFinance = False
                    Select Case objLine(ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_FORM - 1)
                        Case "ﾘｰｽ"
                            isLeath = True
                        Case "ﾌｧｲﾅﾝｽ"
                            isFinance = True
                        Case Else
                            Continue For
                    End Select

                    ''案件番号取得
                    tmpPlanNO = objLine(ExcelWrite.ExcelPaymentLineColumn.PROJ_ID - 1)
                    If Trim(tmpPlanNO) = "" Or 2 > tmpPlanNO.Length Then
                        tmpPlanNO = "不明"
                    Else
                        tmpPlanNO = tmpPlanNO.Substring(0, 2)
                    End If
                    If planNo.IndexOf(tmpPlanNO) = -1 Then
                        Call planNo.Add(tmpPlanNO)
                        Call lease.Add(0)
                        Call finance.Add(0)
                    End If

                    ''ﾘｰｽ or ﾌｧｲﾅﾝｽ集計
                    tmpPrice = 0
                    For Idx As Integer = strIdx To endIdx
                        If IsNumeric(objLine(Idx)) = True Then
                            tmpPrice = tmpPrice + CDbl(objLine(Idx))
                        End If
                    Next
                    If isLeath = True Then
                        lease(planNo.IndexOf(tmpPlanNO)) = lease(planNo.IndexOf(tmpPlanNO)) + tmpPrice
                    End If
                    If isFinance = True Then
                        finance(planNo.IndexOf(tmpPlanNO)) = finance(planNo.IndexOf(tmpPlanNO)) + tmpPrice
                    End If
                Next
            End If

            sw4 = New StreamWriter(strCsvPath & "\" & FILENAME_CSV_TBL4 & strCreateDate & EXTENSION_CSV, False, System.Text.Encoding.Default)
            For Each tmpPlanNO In planNo
                strOut = """" & tmpPlanNO & ""","
                strOut = strOut & """" & lease(planNo.IndexOf(tmpPlanNO)) & ""","
                strOut = strOut & """" & finance(planNo.IndexOf(tmpPlanNO)) & """"
                sw4.WriteLine(strOut)
            Next
            sw4.Close()

        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    ''' <summary>
    ''' 機　能：OderSortのCSVを作成
    ''' 説　明：
    ''' </summary>
    ''' <param name="i"></param>
    ''' <param name="obj"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function OutputCsvPsTableOderSort(ByVal i As Integer, ByRef obj() As Object) As String

        '2017/08 請求イニシャル変更 Str
        Dim oBT As New OleDbBusinessType
        Dim mmc As New MasterMdbControl
        Dim con As OleDbConnection
        Dim wBT As BusinessTypeTable

        'マスタMDB接続を取得
        con = mmc.GetOleDBConnection(CommonVariable.MdbPW)
        '2017/08 請求イニシャル変更 End

        Dim strOut As String = ""
        ''請求コードとソート順を取得
        Dim OrderCD As String = ""
        Dim OrderSort As String = ""
        ''請求コード取得
        Dim PatternCD As String = ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD - 1))
        Dim PatternRN As String = ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.PATTERN - 1))

        OutputCsvPsTableOderSort = ""

        If ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.ORDERCODE - 1)) <> "" Then
            OrderCD = ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.ORDERCODE - 1))
        Else
            PatternCD = ExcelWrite.GetPatternCD(PatternCD, PatternRN)
            Select Case PatternCD
                Case CommonConstant.PATTERNCD_TYPE_IBM_HW_AAS_BOX,
                     CommonConstant.PATTERNCD_TYPE_IBM_HW_AAS_MES
                    OrderCD = "OM"

                Case CommonConstant.PATTERNCD_TYPE_IBM_HW_QCOS,
                     CommonConstant.PATTERNCD_TYPE_HW_CISCO
                    OrderCD = "OA"

                Case CommonConstant.PATTERNCD_TYPE_VLS,
                     CommonConstant.PATTERNCD_TYPE_HWBrandSW_QCOS,
                     CommonConstant.PATTERNCD_TYPE_HWBrandSWMA_QCOS,
                     CommonConstant.PATTERNCD_TYPE_HWServicePac,
                     CommonConstant.PATTERNCD_TYPE_SWServicePac
                    OrderCD = "OF"

                Case CommonConstant.PATTERNCD_TYPE_ExcessTCV,
                     CommonConstant.PATTERNCD_TYPE_CIS
                    OrderCD = "OT"

                Case CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_WarrantyOP,
                     CommonConstant.PATTERNCD_TYPE_IBM_HWMA_QCOS_WarrantyOP,
                     CommonConstant.PATTERNCD_TYPE_HW_Brand_Service, _
                     CommonConstant.PATTERNCD_TYPE_QCOS_MAF,
                     CommonConstant.PATTERNCD_TYPE_AAS_MAF
                    OrderCD = "OW"

                Case CommonConstant.PATTERNCD_TYPE_IGF_INTERESTRATE,
                     CommonConstant.PATTERNCD_TYPE_IGF_RELEASE,
                     CommonConstant.PATTERNCD_TYPE_IGF_USED
                    OrderCD = "IGF"

                Case CommonConstant.PATTERNCD_TYPE_DIRECTINPUT,
                     CommonConstant.PATTERNCD_TYPE_UNIFICATION
                    OrderCD = "P"

                Case CommonConstant.PATTERNCD_TYPE_SW_Brand_Service,
                     CommonConstant.PATTERNCD_TYPE_ISS,
                     CommonConstant.PATTERNCD_TYPE_SO
                    OrderCD = "SA"

                Case CommonConstant.PATTERNCD_TYPE_OFFER
                    OrderCD = "PP"

                Case CommonConstant.PATTERNCD_TYPE_HWBrandSWMA_AAS
                    OrderCD = "PP2"

                    '1587 str SaasのパターンNOを追加
                    '                Case CommonConstant.PATTERNCD_TYPE_PA
                Case CommonConstant.PATTERNCD_TYPE_PA, _
                     CommonConstant.PATTERNCD_TYPE_SAAS
                    '1587 end SaasのパターンNOを追加
                    OrderCD = "LD"
                Case CommonConstant.PATTERNCD_TYPE_Bidpackage_DELETE_DATA
                    OrderCD = "BPT"
                Case CommonConstant.PATTERNCD_TYPE_RENTAL
                    OrderCD = "R"
                    '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) Start
                Case CommonConstant.PATTERNCD_TYPE_Allotment
                    OrderCD = "OT"
                Case CommonConstant.PATTERNCD_TYPE_MSS
                    OrderCD = "SA"
                    '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) End
            End Select

            Select Case PatternCD
                Case CommonConstant.PATTERNCD_TYPE_HWBrandSW_AAS
                    If ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM07 - 1)) = "Media" Then
                        OrderCD = "PP1"
                    Else
                        OrderCD = "PP2"
                    End If

                Case CommonConstant.PATTERNCD_TYPE_SWBrandSW
                    If ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM07 - 1)) = "Media" Then
                        OrderCD = "PP1"
                    Else
                        OrderCD = "PP2"
                    End If

                Case CommonConstant.PATTERNCD_TYPE_SWBrandSWMA
                    If ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM07 - 1)) = "Media" Then
                        OrderCD = "PP1"
                    Else
                        OrderCD = "PP2"
                    End If
                Case CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_BOX, _
                     CommonConstant.PATTERNCD_TYPE_SYSTEMSERVICE
                    If ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD - 1)) = "年額" Then
                        OrderCD = "AM"
                    Else
                        OrderCD = "M"
                    End If

                Case CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_MES
                    If ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD - 1)) = "年額" Then
                        OrderCD = "AM"
                    Else
                        OrderCD = "M"
                    End If

                Case CommonConstant.PATTERNCD_TYPE_IBM_HWMA_QCOS
                    If ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD - 1)) = "年額" Then
                        OrderCD = "MS"
                    Else
                        OrderCD = "MQ"
                    End If

                Case CommonConstant.PATTERNCD_TYPE_OtherMVMS
                    If ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD - 1)) = "年額" Then
                        OrderCD = "MS"
                    Else
                        OrderCD = "MQ"
                    End If

                Case CommonConstant.PATTERNCD_TYPE_CISCO_MAINTENANCE
                    If ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD - 1)) = "年額" Then
                        OrderCD = "MS"
                    Else
                        OrderCD = "MQ"
                    End If

                Case CommonConstant.PATTERNCD_TYPE_SLink
                    If ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM06 - 1)) = "JP7D" Or _
                       ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM06 - 1)) = "JP7E" Then
                        If ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD - 1)) = "月額" Then
                            OrderCD = "MQ"
                        Else
                            If ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD - 1)) = "年額" Then
                                OrderCD = "MS"
                            Else
                                OrderCD = "OW"
                            End If
                        End If
                    ElseIf ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM06 - 1)) = "JP7V" Then
                        If ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD - 1)) = "年額" Then
                            OrderCD = "MS"
                        Else
                            OrderCD = "MQ"
                        End If
                    Else

                        '2017/08 請求イニシャル変更 Str
                        If ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM06 - 1)) <> "" Then
                            If oBT.SelectData(con, _
                                              ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM06 - 1)), _
                                              wBT) = True Then
                                OrderCD = wBT.Rows(0).Item(BusinessTypeTable.COLUMN_NAME_BILLINITIAL).ToString
                            Else
                                OrderCD = "SA"
                            End If
                        Else
                            '2017/08 請求イニシャル変更 End
                            OrderCD = "SA"
                            '2017/08 請求イニシャル変更 Str
                        End If
                        '2017/08 請求イニシャル変更 End
                    End If

                Case CommonConstant.PATTERNCD_TYPE_MAINTENANCE
                    If ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD - 1)) = "月額" Then
                        OrderCD = "MQ"
                    Else
                        If ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD - 1)) = "年額" Then
                            OrderCD = "MS"
                        Else
                            OrderCD = "OW"
                        End If
                    End If

                Case CommonConstant.PATTERNCD_TYPE_HOST_SW
                    If ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD - 1)) = "年額" Then
                        OrderCD = "AL"
                    Else
                        OrderCD = "PP"
                    End If

                Case CommonConstant.PATTERNCD_TYPE_FMA
                    If ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD - 1)) = "年額" Then
                        OrderCD = "MS"
                    Else
                        OrderCD = "MQ"
                    End If
                Case CommonConstant.PATTERNCD_TYPE_PRIMO
                    If ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.BRAND_SUB - 1)) = "SO-SVC(PRIMO)" Then
                        OrderCD = "SO"
                    Else
                        OrderCD = "SA"
                    End If
                    ''製品番号の5文字目が"-"かどうかでAAS かQCOSかを判定
                Case CommonConstant.PATTERNCD_TYPE_BASICSELECTION, _
                     CommonConstant.PATTERNCD_TYPE_BASICSELECTION_ADD_SERVICE
                    If Mid(ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01 - 1)), 5, 1) = "-" Then
                        If ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD - 1)) = "年額" Then
                            OrderCD = "AM"
                        Else
                            OrderCD = "M"
                        End If
                    Else
                        If ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD - 1)) = "年額" Then
                            OrderCD = "MS"
                        Else
                            OrderCD = "MQ"
                        End If
                    End If

            End Select

            If ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.IGF_APPLIED - 1)) = "Y" Then
                OrderCD = "IGF"
                '2017/08 請求イニシャル変更 Str
            ElseIf InStr(ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.PATTERN - 1)).ToString, "Allotment") > 0 Then
                OrderCD = "OT"
                '2017/08 請求イニシャル変更 End
            End If

            If OrderCD = "" Then
                OrderCD = "P"
            End If

        End If

        ''請求のソート順取得(Bidpackage削除データ以外はアルファベット順)
        Select Case OrderCD
            Case "AC"
                OrderSort = "01"
            Case "AL"
                OrderSort = "02"
            Case "AM"
                OrderSort = "03"
            Case "AP"
                OrderSort = "04"
            Case "IGF"
                OrderSort = "05"
            Case "LD"
                OrderSort = "06"
            Case "M"
                OrderSort = "07"
            Case "MC"
                OrderSort = "08"
            Case "MQ"
                OrderSort = "09"
            Case "MS"
                OrderSort = "10"
            Case "OA"
                OrderSort = "11"
            Case "OC"
                OrderSort = "12"
            Case "OF"
                OrderSort = "13"
            Case "OM"
                OrderSort = "14"
            Case "OT"
                OrderSort = "15"
            Case "OW"
                OrderSort = "16"
            Case "P"
                OrderSort = "17"
            Case "PP"
                OrderSort = "18"
            Case "PP1"
                OrderSort = "19"
            Case "PP2"
                OrderSort = "20"
            Case "PP3"
                OrderSort = "21"
            Case "PR"
                OrderSort = "22"
            Case "R"
                OrderSort = "23"
            Case "SA"
                OrderSort = "24"
            Case "SO"
                OrderSort = "25"
            Case "BPT"
                OrderSort = "26"
        End Select

        strOut = strOut & i.ToString("00000") & ","
        strOut = strOut & """" & OrderCD & ""","
        strOut = strOut & """" & OrderSort & "_" & ExcelWrite.changeDBNullToString(obj(ExcelWrite.ExcelPaymentLineColumn.CONTRACT - 1)).PadLeft(3, "0") & """"

        OutputCsvPsTableOderSort = strOut

    End Function

    ''' <summary>
    ''' 機能：以下のschema.iniを出力
    '''       PaymenttBL1、PaymenttBL2、PaymenttBL3、PaymenttBL4、FrmDataOutPut_OrderSort
    ''' </summary>
    ''' <param name="strCreateDate"></param>
    ''' <param name="strOutputPath"></param>
    ''' <remarks></remarks>
    Private Sub OutputSchemaPs(ByVal strCreateDate As String, ByVal strOutputPath As String)

        Dim sw As StreamWriter

        Try
            sw = New StreamWriter(strOutputPath & FILENAME_CSV_SCHEMA, False)

            'TBL1
            sw.WriteLine("[" & FILENAME_CSV_TBL1 & strCreateDate & EXTENSION_CSV & "]")
            sw.WriteLine("ColNameHeader=False")
            sw.WriteLine("MaxScanRows=25")
            sw.WriteLine("CharacterSet=ANSI")
            sw.WriteLine("Format=CsvDelimited")
            sw.WriteLine("Col1=ID Text Width 255")
            sw.WriteLine("Col2=UPDATE_FLAG Text Width 255")
            sw.WriteLine("Col3=LOCK_FLAG Text Width 255")
            sw.WriteLine("Col4=VALID_FLAG Text Width 255")
            sw.WriteLine("Col5=LINE_NO Text Width 255")
            sw.WriteLine("Col6=FILE_NAME Text Width 255")
            sw.WriteLine("Col7=FILE_NAME_SUFFIX Text Width 255")
            sw.WriteLine("Col8=FILE_NAME_SUFFIX_INTR Text Width 255")
            sw.WriteLine("Col9=CONTRACT Text Width 255")
            sw.WriteLine("Col10=ST_COST Text Width 255")
            sw.WriteLine("Col11=ST_APPROVAL Text Width 255")
            sw.WriteLine("Col12=PROJ_ID Text Width 255")
            sw.WriteLine("Col13=CONTRACT_SEQ Text Width 255")
            sw.WriteLine("Col14=NEW_EXIST Text Width 255")
            sw.WriteLine("Col15=CUST_CATEGORY Text Width 255")
            sw.WriteLine("Col16=LETTER_PLAN_DATE Memo")
            sw.WriteLine("Col17=LETTER_ACCEPT_DATE Text Width 255")
            sw.WriteLine("Col18=ORDER_DATE Text Width 255")
            sw.WriteLine("Col19=LETTER_ID Text Width 255")
            sw.WriteLine("Col20=BILLING_CD Text Width 255")
            sw.WriteLine("Col21=BU Text Width 255")
            sw.WriteLine("Col22=BRAND Text Width 255")
            sw.WriteLine("Col23=SUM_CATEGORY Text Width 255")
            sw.WriteLine("Col24=BRAND_SUB Text Width 255")
            sw.WriteLine("Col25=T_OP1 Text Width 255")
            sw.WriteLine("Col26=T_OP2 Text Width 255")
            sw.WriteLine("Col27=T_SIZE Text Width 255")
            sw.WriteLine("Col28=NON_SBO Text Width 255")
            sw.WriteLine("Col29=ADDITION_ITEM Text Width 255")
            sw.WriteLine("Col30=TOPACS_CPNO Text Width 255")
            sw.WriteLine("Col31=BRAND_AP_FORM Text Width 255")
            sw.WriteLine("Col32=BRAND_AP_REQ Text Width 255")
            sw.WriteLine("Col33=BRAND_AP_CONF Text Width 255")
            sw.WriteLine("Col34=PATTERN_CD Text Width 255")
            sw.WriteLine("Col35=PATTERN Text Width 255")
            sw.WriteLine("Col36=PROD_ITEM01 Text Width 255")
            sw.WriteLine("Col37=PROD_ITEM02 Memo")
            sw.WriteLine("Col38=PROD_ITEM03 Memo")
            sw.WriteLine("Col39=PROD_ITEM04 Text Width 255")
            sw.WriteLine("Col40=PROD_ITEM05 Text Width 255")
            sw.WriteLine("Col41=PROD_ITEM06 Text Width 255")
            sw.WriteLine("Col42=PROD_ITEM07 Text Width 255")
            sw.WriteLine("Col43=PROD_ITEM08 Text Width 255")
            sw.WriteLine("Col44=PROD_ITEM09 Text Width 255")
            sw.WriteLine("Col45=PROD_ITEM10 Text Width 255")
            sw.WriteLine("Col46=PROD_ITEM11 Text Width 255")
            sw.WriteLine("Col47=PROD_ITEM12 Text Width 255")
            sw.WriteLine("Col48=PROD_ITEM13 Text Width 255")
            sw.WriteLine("Col49=PROD_ITEM14 Text Width 255")
            sw.WriteLine("Col50=PROD_ITEM15 Memo")
            sw.WriteLine("Col51=PROD_ITEM16 Text Width 255")
            sw.WriteLine("Col52=PROD_ITEM17 Text Width 255")
            sw.WriteLine("Col53=PROD_ITEM18 Text Width 255")
            sw.WriteLine("Col54=PROD_ITEM19 Text Width 255")
            sw.WriteLine("Col55=PROD_ITEM20 Text Width 255")
            sw.WriteLine("Col56=PROD_ITEM22 Text Width 255")
            sw.WriteLine("Col57=PROD_ITEM23 Text Width 255")
            sw.WriteLine("Col58=PROD_ITEM24 Text Width 255")

            'TBL2
            sw.WriteLine("[" & FILENAME_CSV_TBL2 & strCreateDate & EXTENSION_CSV & "]")
            sw.WriteLine("ColNameHeader=False")
            sw.WriteLine("MaxScanRows=25")
            sw.WriteLine("CharacterSet=ANSI")
            sw.WriteLine("Format=CsvDelimited")
            sw.WriteLine("Col1=ID Text Width 255")
            sw.WriteLine("Col2=WD_ANNT_DATE Text Width 255")
            sw.WriteLine("Col3=WD_DATE Text Width 255")
            sw.WriteLine("Col4=PRICE_CHG_DATE Text Width 255")
            sw.WriteLine("Col5=QTY Text Width 255")
            sw.WriteLine("Col6=INST_DATE Text Width 255")
            sw.WriteLine("Col7=PAY_START_DATE Text Width 255")
            sw.WriteLine("Col8=PAY_END_DATE Text Width 255")
            sw.WriteLine("Col9=IGF_START_DATE Text Width 255")
            sw.WriteLine("Col10=IGF_END_DATE Text Width 255")
            sw.WriteLine("Col11=PAY_FLAG Text Width 255")
            sw.WriteLine("Col12=BID_FLAG Text Width 255")
            sw.WriteLine("Col13=PAY_MONTHS Text Width 255")
            sw.WriteLine("Col14=VALID_CTRL Text Width 255")
            sw.WriteLine("Col15=PAY_METHOD Text Width 255")
            sw.WriteLine("Col16=IGF_APPLIED Text Width 255")
            sw.WriteLine("Col17=IGF_CONT_NO Text Width 255")
            sw.WriteLine("Col18=IGF_CONT_TYPE Text Width 255")
            sw.WriteLine("Col19=IGF_PROPERTY Text Width 255")
            sw.WriteLine("Col20=IGF_RATE_IOC Text Width 255")
            sw.WriteLine("Col21=LIST_PRICE_PROPOSAL Text Width 255")
            sw.WriteLine("Col22=LIST_PRICE Text Width 255")
            sw.WriteLine("Col23=LIST_PRICE_TOTAL_PROPOSAL Text Width 255")
            sw.WriteLine("Col24=LIST_PRICE_TOTAL Text Width 255")
            sw.WriteLine("Col25=DP_IOC Text Width 255")
            sw.WriteLine("Col26=PRICE_UNIT_IOC Text Width 255")
            sw.WriteLine("Col27=PRICE_UNIT_IOC_VAL Text Width 255")
            sw.WriteLine("Col28=PRICE_QTY_IOC Text Width 255")
            sw.WriteLine("Col29=COST_RATE Text Width 255")
            sw.WriteLine("Col30=COST Text Width 255")
            sw.WriteLine("Col31=COST_TOTAL Text Width 255")
            sw.WriteLine("Col32=COST_INPUT_DATE Text Width 255")
            sw.WriteLine("Col33=PRICE_TO_SPLIT Text Width 255")
            sw.WriteLine("Col34=LIST_PRICE_TOTAL_IOC Text Width 255")
            sw.WriteLine("Col35=PRICE_TOTAL_IOC Text Width 255")
            sw.WriteLine("Col36=COST_TOTAL_IOC Text Width 255")
            sw.WriteLine("Col37=PRICE_IGF_TOTAL Text Width 255")
            sw.WriteLine("Col38=PRICE_CONT_TOTAL Text Width 255")
            sw.WriteLine("Col39=PRICE_OO_CONT_TOTAL Text Width 255")
            sw.WriteLine("Col40=IGF_DIF_INTEREST Text Width 255")
            sw.WriteLine("Col41=PAST_PRICE_TOTAL Text Width 255")

            'TBL3
            sw.WriteLine("[" & FILENAME_CSV_TBL3 & strCreateDate & EXTENSION_CSV & "]")
            sw.WriteLine("ColNameHeader=False")
            sw.WriteLine("MaxScanRows=25")
            sw.WriteLine("CharacterSet=ANSI")
            sw.WriteLine("Format=CsvDelimited")
            sw.WriteLine("Col1=ID Text Width 255")
            sw.WriteLine("Col2=IOC_YEAER Text Width 255")
            sw.WriteLine("Col3=IOC_YYYY Text Width 255")
            sw.WriteLine("Col4=IOC_01 Text Width 255")
            sw.WriteLine("Col5=IOC_02 Text Width 255")
            sw.WriteLine("Col6=IOC_03 Text Width 255")
            sw.WriteLine("Col7=IOC_04 Text Width 255")
            sw.WriteLine("Col8=IOC_05 Text Width 255")
            sw.WriteLine("Col9=IOC_06 Text Width 255")
            sw.WriteLine("Col10=IOC_07 Text Width 255")
            sw.WriteLine("Col11=IOC_08 Text Width 255")
            sw.WriteLine("Col12=IOC_09 Text Width 255")
            sw.WriteLine("Col13=IOC_10 Text Width 255")
            sw.WriteLine("Col14=IOC_11 Text Width 255")
            sw.WriteLine("Col15=IOC_12 Text Width 255")

            'TBL4
            sw.WriteLine("[" & FILENAME_CSV_TBL4 & strCreateDate & EXTENSION_CSV & "]")
            sw.WriteLine("ColNameHeader=False")
            sw.WriteLine("MaxScanRows=25")
            sw.WriteLine("CharacterSet=ANSI")
            sw.WriteLine("Format=CsvDelimited")
            sw.WriteLine("Col1=PROJ_ID Text Width 2")
            sw.WriteLine("Col2=LEASE Double")
            sw.WriteLine("Col3=FINANCE Double")

            'FrmDataOutPut_OrderSort
            sw.WriteLine("[" & FILENAME_CSV_OEDERSORT & strCreateDate & EXTENSION_CSV & "]")
            sw.WriteLine("ColNameHeader=False")
            sw.WriteLine("MaxScanRows=25")
            sw.WriteLine("CharacterSet=ANSI")
            sw.WriteLine("Format=CsvDelimited")
            sw.WriteLine("Col1=ID Text Width 255")
            sw.WriteLine("Col2=ORDERCODE Text Width 255")
            sw.WriteLine("Col3=ORDERSORTNO Text Width 255")

            sw.Close()

        Catch ex As Exception
            Throw ex

        End Try

    End Sub

    ''' <summary>
    ''' 機能：詳細のschema.iniを出力
    ''' </summary>
    ''' <param name="strCreateDate"></param>
    ''' <param name="strOutputPath"></param>
    ''' <remarks></remarks>
    Private Sub OutputSchemaPsd(ByVal strCreateDate As String, ByVal strOutputPath As String)

        Dim sw As StreamWriter

        Try
            sw = New StreamWriter(strOutputPath & FILENAME_CSV_SCHEMA, False)

            'PaymentDetail
            sw.WriteLine("[" & FILENAME_CSV_PSD & strCreateDate & EXTENSION_CSV & "]")
            sw.WriteLine("ColNameHeader=False")
            sw.WriteLine("MaxScanRows=25")
            sw.WriteLine("CharacterSet=ANSI")
            sw.WriteLine("Format=CsvDelimited")
            sw.WriteLine("Col1=DETAIL_ID Text Width 255")
            sw.WriteLine("Col2=UPDATE_FLAG Text Width 255")
            sw.WriteLine("Col3=LOCK_FLAG Text Width 255")
            sw.WriteLine("Col4=VALID_FLAG Text Width 255")
            sw.WriteLine("Col5=CONTRACT Text Width 255")
            sw.WriteLine("Col6=FILE_NAME Text Width 255")
            sw.WriteLine("Col7=FILE_NAME_SUFFIX Text Width 255")
            sw.WriteLine("Col8=FILE_NAME_SUFFIX_INTR Text Width 255")
            sw.WriteLine("Col9=SEQ Text Width 255")
            sw.WriteLine("Col10=IDENTITY_FLAG Text Width 255")
            sw.WriteLine("Col11=PROD_NO Text Width 255")
            sw.WriteLine("Col12=PROD_NAME Text Width 255")
            sw.WriteLine("Col13=WD_ANNT_DATE Text Width 255")
            sw.WriteLine("Col14=WD_DATE Text Width 255")
            sw.WriteLine("Col15=PRICE_CHG_DATE Text Width 255")
            sw.WriteLine("Col16=MES_CATEGORY Text Width 255")
            sw.WriteLine("Col17=MES_GROUP Text Width 255")
            sw.WriteLine("Col18=SPECIAL_FEATURE Text Width 255")
            sw.WriteLine("Col19=QTY Text Width 255")
            sw.WriteLine("Col20=LIST_PRICE_PROPOSAL Text Width 255")
            sw.WriteLine("Col21=LIST_PRICE Text Width 255")
            sw.WriteLine("Col22=LIST_PRICE_TOTAL_PROPOSAL Text Width 255")
            sw.WriteLine("Col23=LIST_PRICE_TOTAL Text Width 255")
            sw.WriteLine("Col24=COST_RATE Text Width 255")
            sw.WriteLine("Col25=COST Text Width 255")
            sw.WriteLine("Col26=COST_TOTAL Text Width 255")
            sw.WriteLine("Col27=COST_INPUT_DATE Text Width 255")
            sw.WriteLine("Col28=LIST_PRICE_MMC Text Width 255")
            sw.WriteLine("Col29=LIST_PRICE_TOTAL_MMC Text Width 255")
            sw.WriteLine("Col30=TIME_PER Text Width 255")
            sw.WriteLine("Col31=EXTENSION_PER Text Width 255")
            sw.Close()

        Catch ex As Exception
            Throw ex

        End Try

    End Sub

    ''' <summary>
    ''' 機能：TempDBのﾃﾞｰﾀをNullから空文字に置換
    ''' </summary>
    ''' <param name="con"></param>
    ''' <param name="strTableName"></param>
    ''' <remarks></remarks>
    Private Sub SetDBNullToSpace(ByVal con As ADODB.Connection, ByVal strTableName As String)

        Dim rs As New ADODB.Recordset
        Dim cmd As New ADODB.Command
        Dim strSQL As String
        Dim strSQLUpdate As String
        Dim intCnt As Integer

        Try
            cmd.ActiveConnection = con
            strSQL = "SELECT * FROM " & strTableName
            rs.Open(strSQL, con, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockPessimistic)
            For intCnt = 0 To (rs.Fields.Count - 1)
                strSQLUpdate = ""
                If rs.Fields(intCnt).Type = ADODB.DataTypeEnum.adDouble And strTableName = "PaymentTBL4" Then
                    strSQLUpdate = strSQLUpdate & "0"
                Else
                    strSQLUpdate = strSQLUpdate & """"""
                End If
                If strSQLUpdate <> "" Then
                    strSQLUpdate = "update " & strTableName & " set " & rs.Fields(intCnt).Name & "=" & strSQLUpdate & " where " & rs.Fields(intCnt).Name & " is null"
                    cmd.CommandText = strSQLUpdate
                    cmd.Execute()
                End If
            Next
            rs.Close()

        Catch ex As Exception
            Throw ex
        End Try

    End Sub
#End Region

End Class
