﻿Imports System.IO
Imports System.Text
Imports Microsoft.Office.Interop
Imports System.Data.OleDb
Imports MUSE.Utility
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.OioBamaCommmon
Imports MUSE.Utility.UserMessageBox
Imports MUSE.WinUI.OioBamaCommmon
Imports MUSE.DataAccess.OleDb
Imports MUSE.Utility.UserDataTable.Master

Public Class NewExcelTOPACS

#Region "定数"

    '==============================
    'EXCEL行位置
    '==============================
    'PaymentLine データ開始行
    Private Const EXCEL_PAYMENTLINEDATE_OUTROW As Integer = 6
    Private Const EXCEL_PAYMENTLINEDATE_OUTCOLUM As String = "A@:AK@"
    Private Const EXCEL_PAYMENTLINEDATE_ALLCOLUM As String = "A@:AN@"
    Private Const EXCEL_PAYMENTLINE_SUM_EXPAND_MONTH_OUTCOLUM As String = "CS@:IF@"
    Private Const EXCEL_PAYMENTLINE_KIHYO_NO_OUTCELL As String = "AD@:AD@"

    'EXCELの最終行
    Private Const EXCEL_MAX_ROW As Integer = 65536

    '==============================
    'Topacs列位置
    '==============================
    '集計行の名称
    Private Const TOPACSCOL_SUMARRYTITLE As Integer = 25
    'CRAD
    Private Const TOPACSCOL_CRAD As Integer = 38
    'BVD
    Private Const TOPACSCOL_BVD As Integer = 39
    'LID
    Private Const TOPACSCOL_LID As Integer = 40
    'ListPrice合計（リフレッシュ後）
    Private Const TOPACSCOL_LISTPRICE_REFLESH As Integer = 34
    '割引後合計
    Private Const TOPACSCOL_DISCOUNT_SUM As Integer = 37

    ''カラム名
    Private Const COLNM As String = "Col"

    ''Excelの背景色
    ''中集計
    Private CELLINFO_BACKCOLOR_PINK As String = "13408767"
    ''大集計
    Private CELLINFO_BACKCOLOR_YELLOW As String = "10092543"


#End Region

#Region "列挙体"

    ''Topacsのセルの位置
    Private Enum TopacsColumn
        LOCK_FLAG = 1                       ''ﾛｯｸFLG
        VALID_FLAG                          ''有効/無効
        LINE_NO                             ''NO
        FILE_NAME                           ''ﾌｧｲﾙ名
        FILE_NAME_SUFFIX                    ''ﾌｧｲﾙ名Suffix
        FILE_NAME_SUFFIX_INTR               ''ﾌｧｲﾙ内Suffix
        CONTRACT                            ''契約順番
        CONTRACT_SEQ                        ''契約通番
        NEW_EXIST                           ''新規/既存
        BU                                  ''Brand Category_BU
        BRAND                               ''Brand Category_Brand
        SUM_CATEGORY                        ''Brand Category_ｻﾏﾘｰ用ｶﾃｺﾞﾘ
        BRAND_SUB                           ''Brand Category_SubBrand
        OP1                                 ''Brand Category_Option1
        OP2                                 ''Brand Category_Option2
        BRAND_SIZE                          ''Brand Category_Size
        NON_SBO                             ''Brand Category_SBO制限
        TOPACS_CPNO                         ''Brand承認_TOPACS CPNO
        BRAND_AP_FORM                       ''Brand承認_起票番号
        BRAND_AP_NAME                       ''Brand承認_起票者
        BRAND_AP_REQ                        ''Brand承認_申請番号
        BRAND_AP_CONF                       ''Brand承認_承認番号
        PATTERNCD                           ''入力項目ﾊﾟﾀｰﾝCD
        PATTERN                             ''入力項目ﾊﾟﾀｰﾝ
        PROD_ITEM01                         ''ﾊﾟﾀｰﾝ別入力項目_項目１
        PROD_ITEM02                         ''ﾊﾟﾀｰﾝ別入力項目_項目２
        WD_ANNT_DATE                        ''製品･ｻｰﾋﾞｽ廃止発表日
        WD_DATE                             ''製品･ｻｰﾋﾞｽ廃止予定
        PRICE_CHG_DATE                      ''価格改定予定日
        QTY                                 ''数量
        INST_YEAR                           ''導入_年
        INST_MONTH                          ''導入_月
        LIST_PRICE_REFLESH                  ''Listprice(単価)_ﾘﾌﾚｯｼｭ後
        LIST_PRICE_TOTAL_REFLESH            ''Listprice(合計)_ﾘﾌﾚｯｼｭ後
        DP_IOC                              ''IOC D%
        PRICE_UNIT_IOC                      ''IOC単価
        PRICE_QTY_IOC                       ''IOC合計
        CRAD                                ''CRAD
        BVD                                 ''BVD
        LID                                 ''LID
        ERRLOG = LID + 2                    ''エラーログ　※最後の列　に空白列を一つも受ける
    End Enum
#End Region

    ''ローカルで使用するDataTable定義用のインナークラスを定義
#Region "インナークラス"

    Private Class KihyoPSTable
        Inherits DataTable

        Public Sub New()

            Me.TableName = "KihyoPSTable"

            ''個別PSに出力する項目
            Me.Columns.Add("KIHYO_NO")
            Me.Columns.Add("SINSEI_NO")

            ''書き込み対象の判別に仕様する項目
            Me.Columns.Add("KIHYO_NAME")
            Me.Columns.Add("CONTRACT")
            Me.Columns.Add("FILE_NAME")
            Me.Columns.Add("FILE_NAME_SUFFIX")
            Me.Columns.Add("FILE_NAME_SUFFIX_INTR")

            Me.Columns.Add("PATTERNCD")
            Me.Columns.Add("PATTERN")
            Me.Columns.Add("ITEM01")
            Me.Columns.Add("LISTPRICE")
            Me.Columns.Add("DISCOUNTPRICE")

            ''WarrentLogに出力する項目
            Me.Columns.Add("LINE_NO")

            ''集計行の判定
            Me.Columns.Add("COLOR")

        End Sub

    End Class

#End Region

#Region "TOPACS申請ファイル作成処理"

    ''' <summary>
    ''' 機　能：TOPACS申請ファイル作成処理
    ''' 説　明：
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function OutputExcelTOPACS(ByVal xlsPSPath As String, _
                                  ByVal destFilePath As String, _
                                  ByVal templateFilePath As String, _
                                  ByRef isZero As Boolean,
                                  ByRef strMsg As String) As Boolean

        Dim excelWrite As New ExcelWrite
        OutputExcelTOPACS = False

        ''Excelオブジェクトの定義
        Dim xlApp As New Excel.Application
        Dim xlInPSBook As Excel.Workbook = Nothing
        Dim xlInSheet As Excel.Worksheet = Nothing
        Dim xlInPSSheet As Excel.Worksheet = Nothing
        Dim xlOutBook As Excel.Workbook = Nothing
        Dim xlOutPSSheet As Excel.Worksheet = Nothing
        Dim xlOutDetailSheet As Excel.Worksheet = Nothing
        Dim dtTOPACSPS As New DataTable
        Dim dtTOPACSDist As New DataTable

        Try
            Dim TopacsCPNO As String
            TopacsCPNO = GetTopacsCPNO(CommonVariable.CPNO)

            'Excelオブジェクトの設定
            xlApp.EnableEvents = False
            xlApp.DisplayAlerts = False

            'テンプレートファイルをOpenする
            xlOutBook = xlApp.Workbooks.Open(templateFilePath)
            xlOutPSSheet = xlOutBook.Sheets(excelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)

            '個別PSシートをセット
            xlInPSBook = xlApp.Workbooks.Open(xlsPSPath)
            xlInPSSheet = xlInPSBook.Worksheets.Item(excelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)

            ''Excelの再計算機能をOFF
            xlApp.Calculation = Excel.XlCalculation.xlCalculationManual

            '出力Excelに個別詳細ワークシートをコピーする
            xlInSheet = xlInPSBook.Worksheets.Item(excelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)
            xlOutPSSheet = xlOutBook.Worksheets.Item(excelWrite.EXCEL_TOPACSDATE_PAYMENTSHEET)
            xlInSheet.Copy(After:=xlOutPSSheet)

            '個別詳細シートをセット
            xlOutDetailSheet = xlOutBook.Worksheets(excelWrite.EXCEL_TOPACSDATE_DETAILSHEET)

            '式を値に切替
            Call DetailFomulaClear(xlOutDetailSheet)

            ''Excelのオートフィルタを初期化
            Call excelWrite.CrearAutoFilter(xlInPSSheet)
            Call excelWrite.CrearAutoFilter(xlOutPSSheet)

            ''==========================================================
            ''    --------------- PSワークシート作成 --------------- 
            ''==========================================================
            ''ConvertClientValueテーブルの値を取得
            Dim CilentValueTable As ConvertClientValueTable
            CilentValueTable = GetConvertClientValueTable()

            ''個別PS.Xlsのデータを取得する。
            dtTOPACSPS = GetPSDataTable(TopacsCPNO, xlInPSSheet, CilentValueTable)

            ''特殊フューチャーの金額を集計
            dtTOPACSPS = GetSumSpecialFeature(dtTOPACSPS)

            ''サマリカテゴリ(Topacs用)、導入月でソート
            SortByBrCategory(dtTOPACSPS)

            ''0件の処理
            If dtTOPACSPS.Rows.Count = 0 Then
                isZero = True
                OutputExcelTOPACS = True
                Exit Function
            End If

            ''サブブランド、導入年月の集計行を追加
            Dim dtTOPACSSum As DataTable
            dtTOPACSSum = GetSummaryTopacsTable(dtTOPACSPS)

            'Topacsシートにデータを書き込む
            Call WriteTopacsPSSheet(xlOutPSSheet, dtTOPACSSum)

            ''==========================================================
            '' --------------- 個別詳細ワークシート作成 --------------- 
            ''==========================================================
            '重複をグループ化
            Dim dv As DataView = New DataView(dtTOPACSPS)
            dtTOPACSDist = dv.ToTable("DistinctTable", True, New String() {COLNM & excelWrite.ExcelPaymentLineDetailColumn.FILE_NAME, _
                                                                           COLNM & excelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX, _
                                                                           COLNM & excelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR})

            ''個別詳細ファイルから、個別PSファイルに紐づかないデータを削除する。
            Call DelUnmachDetailRow(xlOutDetailSheet, dtTOPACSDist)

            xlApp.DisplayAlerts = False
            xlOutPSSheet.EnableSelection = Excel.XlEnableSelection.xlUnlockedCells

            'Bookの保存
            xlOutBook.SaveAs(destFilePath, _
                             Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled, _
                             Type.Missing, _
                             Type.Missing, _
                             Type.Missing, _
                             Type.Missing, _
                             0, _
                             Type.Missing, _
                             Type.Missing, _
                             Type.Missing, _
                             Type.Missing)


            OutputExcelTOPACS = True

        Catch ex As Exception
            strMsg = ex.Message.ToString & "(OutputExcelTOPACS)"

        Finally
            '後処理
            ''Excelの再計算機能をOFF
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True


            ''シートの解放
            ExcelObjRelease.ReleaseExcelObj(xlInSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlInPSSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlOutPSSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlOutDetailSheet, ExcelObjRelease.OBJECT_NOTHING)

            ''Bookの解放
            If IsNothing(xlInPSBook) = False Then
                xlInPSBook.Close(False)
                xlApp.Calculation = Excel.XlCalculation.xlCalculationAutomatic
            End If
            ExcelObjRelease.ReleaseExcelObj(xlInPSBook, ExcelObjRelease.OBJECT_NOTHING)

            If IsNothing(xlOutBook) = False Then
                xlOutBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlOutBook, ExcelObjRelease.OBJECT_NOTHING)

            ''APPの解放
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Function

#End Region

#Region "TOPACS申請反映処理"


    ''' <summary>
    ''' 機　能：TOPACS申請反映処理
    ''' 説　明：
    ''' </summary>
    ''' <param name="sourceFilePath">TOPACSファイルパス</param>
    ''' <param name="destFilePath">PSファイルパス</param>
    ''' <param name="outCntPS">個別詳細パス</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function TOPACSReflection(ByVal TopacsFilePath As String, _
                                     ByVal PSFilePath As String, _
                                     ByRef outCntPS As Integer,
                                     ByRef outCntUnMatchPS As Integer,
                                     ByRef outCntNotEntry As Integer,
                                     ByRef exitMsg As String) As Boolean

        TOPACSReflection = False


        ''TopacsBookのシート名
        Dim excelWrite As New ExcelWrite
        Dim TOPACS_SHEETNM_PS As String = excelWrite.EXCEL_TOPACSDATE_PAYMENTSHEET
        Dim TOPACS_SHEETNM_PSD As String = excelWrite.EXCEL_TOPACSDATE_DETAILSHEET

        ''Appの定義
        Dim xlApp As New Excel.Application

        ''Bookの定義
        Dim xlTopacsBook As Excel.Workbook = Nothing
        Dim xlOutPSBook As Excel.Workbook = Nothing
        Dim xlOutPSBookPSSheet As Excel.Worksheet = Nothing

        ''Sheetの定義
        Dim xlInTopacsPSSheet As Excel.Worksheet = Nothing
        Dim xlInTopacsDetailSheet As Excel.Worksheet = Nothing
        Dim xlInTopacsWorningLogSheet As Excel.Worksheet = Nothing

        ''Cell情報の定義
        Dim xlCell As Excel.Range = Nothing
        Dim xlRange As Excel.Range = Nothing
        Dim ExcelCellInfo(188) As Object         'Excelのセル情報
        Dim ExcelWork(1, 188) As Object          'Excelのセル情報

        ''その他ローカル変数の定義
        Dim blnRet As Boolean
        Dim intCnt As Integer
        Dim dtKihyoPS As New DataTable
        Dim drKihyoPS As DataRow
        Dim worningRows As New ArrayList
        Dim worningKihyoNo As New ArrayList
        Dim xlInterior As Excel.Interior         '背景色の判定

        Try
            'Excelオブジェクトの設定
            xlApp.EnableEvents = False
            xlTopacsBook = xlApp.Workbooks.Open(TopacsFilePath)
            xlOutPSBook = xlApp.Workbooks.Open(PSFilePath)
            xlApp.EnableEvents = True
            xlOutPSBookPSSheet = xlOutPSBook.Worksheets.Item(excelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)
            xlInTopacsPSSheet = xlTopacsBook.Worksheets.Item(TOPACS_SHEETNM_PS)

            ''Excelのオートフィルタを初期化
            Call excelWrite.CrearAutoFilter(xlOutPSBookPSSheet)

            ''=======================================
            ''              PS書込み
            ''=======================================
            ''個別PSに出力する項目
            dtKihyoPS.Columns.Add("KIHYO_NO")
            dtKihyoPS.Columns.Add("SINSEI_NO")
            dtKihyoPS.Columns.Add("TOPACS_CPNO")
            dtKihyoPS.Columns.Add("SYONIN_NO")

            ''書き込み対象の判別に仕様する項目
            dtKihyoPS.Columns.Add("KIHYO_NAME")
            dtKihyoPS.Columns.Add("CONTRACT")
            dtKihyoPS.Columns.Add("FILE_NAME")
            dtKihyoPS.Columns.Add("FILE_NAME_SUFFIX")
            dtKihyoPS.Columns.Add("FILE_NAME_SUFFIX_INTR")

            dtKihyoPS.Columns.Add("PATTERNCD")
            dtKihyoPS.Columns.Add("PATTERN")
            dtKihyoPS.Columns.Add("ITEM01")
            dtKihyoPS.Columns.Add("LISTPRICE")
            dtKihyoPS.Columns.Add("DISCOUNTPRICE")

            dtKihyoPS.Columns.Add("INST_YEAR")
            dtKihyoPS.Columns.Add("INST_MONTH")

            ''WarrentLogに出力する項目
            dtKihyoPS.Columns.Add("LINE_NO")

            ''集計行の判定
            dtKihyoPS.Columns.Add("COLOR")

            'TopacsのPSの編集に必要な情報をデータテーブルに格納する
            Dim intIndex As Integer
            For intIndex = excelWrite.EXCEL_TOPACS_PAYMENT_OUTROW To EXCEL_MAX_ROW

                '1行取得
                xlCell = xlInTopacsPSSheet.Range("A" & intIndex & ":" & "IF" & intIndex)
                ExcelWork = xlCell.Value

                For intCnt = 1 To 188
                    ExcelCellInfo(intCnt) = ExcelWork(1, intCnt)
                Next

                ''Eof行チェック
                blnRet = CheckRowItemRow(intIndex, ExcelCellInfo)
                If blnRet = False Then
                    Exit For
                End If

                drKihyoPS = dtKihyoPS.NewRow()
                drKihyoPS("KIHYO_NO") = ExcelCellInfo(TopacsColumn.BRAND_AP_FORM)
                drKihyoPS("SINSEI_NO") = ExcelCellInfo(TopacsColumn.BRAND_AP_REQ)
                drKihyoPS("TOPACS_CPNO") = ExcelCellInfo(TopacsColumn.TOPACS_CPNO)
                drKihyoPS("SYONIN_NO") = ExcelCellInfo(TopacsColumn.BRAND_AP_CONF)
                drKihyoPS("KIHYO_NAME") = ExcelCellInfo(TopacsColumn.BRAND_AP_NAME)
                drKihyoPS("CONTRACT") = ExcelCellInfo(TopacsColumn.CONTRACT)
                drKihyoPS("FILE_NAME") = ExcelCellInfo(TopacsColumn.FILE_NAME)
                drKihyoPS("FILE_NAME_SUFFIX") = ExcelCellInfo(TopacsColumn.FILE_NAME_SUFFIX)
                drKihyoPS("FILE_NAME_SUFFIX_INTR") = ExcelCellInfo(TopacsColumn.FILE_NAME_SUFFIX_INTR)
                drKihyoPS("LINE_NO") = ExcelCellInfo(TopacsColumn.LINE_NO)

                drKihyoPS("INST_YEAR") = ExcelCellInfo(TopacsColumn.INST_YEAR)
                drKihyoPS("INST_MONTH") = ExcelCellInfo(TopacsColumn.INST_MONTH)

                drKihyoPS("PATTERNCD") = ExcelCellInfo(TopacsColumn.PATTERNCD)
                drKihyoPS("PATTERN") = ExcelCellInfo(TopacsColumn.PATTERN)
                drKihyoPS("ITEM01") = ExcelCellInfo(TopacsColumn.PROD_ITEM01)
                drKihyoPS("LISTPRICE") = ExcelCellInfo(TopacsColumn.LIST_PRICE_TOTAL_REFLESH)
                drKihyoPS("DISCOUNTPRICE") = ExcelCellInfo(TopacsColumn.PRICE_QTY_IOC)

                ''集計行の判定に使用
                xlCell = xlInTopacsPSSheet.Range("A" & intIndex)
                xlInterior = xlCell.Interior
                drKihyoPS("COLOR") = xlInterior.Color
                dtKihyoPS.Rows.Add(drKihyoPS)

            Next

            ''行番号の重複チェック
            Dim DtOBAMAPS As DataTable
            Dim rtnMsg As String
            DtOBAMAPS = GetPSDataTable(xlOutPSBookPSSheet)
            If ChkDistinctLinno(DtOBAMAPS, rtnMsg) Then
                ''重複していた場合、処理終了
                exitMsg = rtnMsg
                Exit Function
            End If

            ''Topacsファイルのループ
            Dim TopacsRows As Integer
            Dim isErr As Boolean            ''取込失敗かどうか判定
            Dim isNotEntry As Boolean       ''取込失敗の理由が起票者Nullかどうか判定
            Dim errLineNo As String
            Dim errKihyoNo As String

            ''作業中のTopacsのExcel行
            Dim outTopacsRows = EXCEL_PAYMENTLINEDATE_OUTROW - 1
            For Each dr As DataRow In dtKihyoPS.Rows

                ''取込失敗情報の初期化
                isErr = False
                isNotEntry = False
                errLineNo = ""
                errKihyoNo = ""

                ''作業中のTopacsのExcel行
                outTopacsRows = outTopacsRows + 1

                ''①集計行の場合、出力対象外
                ''※エラーリストは出力しないでループの最初に戻る。
                If ChangeNothingToBlank(dr("COLOR")) = CELLINFO_BACKCOLOR_PINK Or _
                   ChangeNothingToBlank(dr("COLOR")) = CELLINFO_BACKCOLOR_YELLOW Then

                    Continue For
                End If

                ''②起票者がNULLの場合、出力対象外
                ''※エラーリストを出力する。
                ''※無駄なPaymentデータとTopacsデータのマッチング判定は避けて、SkipPaymentへ移動
                If ChangeNothingToBlank(dr("KIHYO_NAME")) = "" Then

                    ''起票者Nullか判定
                    isNotEntry = True

                    ''取込失敗情報のセット
                    isErr = True
                    errLineNo = ChangeNothingToBlank(dr("LINE_NO"))
                    errKihyoNo = ChangeNothingToBlank(dr("KIHYO_NO"))

                    ''PaymentSheetの比較処理をスキップする
                    GoTo SkipPayment

                End If

                ''PaymentSheetのループ
                ''※Topacs1行文データにマッチするPayment情報を探し、見つかればTopacs情報を書き込む
                ''▼----------------------------------------------------------------
                Dim isMatchPSData As Boolean = False
                For intIndex = excelWrite.EXCEL_PAYMENTLINEDATE_OUTROW To EXCEL_MAX_ROW

                    '1行取得
                    xlCell = xlOutPSBookPSSheet.Range("A" & intIndex & ":" & "IF" & intIndex)
                    ExcelWork = xlCell.Value

                    For intCnt = 1 To 188
                        ExcelCellInfo(intCnt) = ExcelWork(1, intCnt)
                    Next

                    ''Eof行チェック
                    blnRet = CheckRowItem(intIndex, ExcelCellInfo)
                    If blnRet = False Then
                        Exit For
                    End If

                    ''個別PSとマッチするデータが存在するかどうか？
                    If ExistPSDate(DtOBAMAPS, ExcelCellInfo, dr) = True Then

                        isMatchPSData = True

                        '更新行数の取得
                        outCntPS += 1

                        ''個別PS情報の書込
                        xlCell = xlOutPSBookPSSheet.Cells
                        xlRange = DirectCast(xlCell(intIndex, excelWrite.ExcelPaymentLineColumn.BRAND_AP_FORM), Excel.Range)
                        xlRange.Value = dr("KIHYO_NO")
                        xlRange = DirectCast(xlCell(intIndex, excelWrite.ExcelPaymentLineColumn.BRAND_AP_REQ), Excel.Range)
                        xlRange.Value = dr("SINSEI_NO")

                        xlRange = DirectCast(xlCell(intIndex, excelWrite.ExcelPaymentLineColumn.TOPACS_CPNO), Excel.Range)
                        xlRange.Value = dr("TOPACS_CPNO")
                        xlRange = DirectCast(xlCell(intIndex, excelWrite.ExcelPaymentLineColumn.BRAND_AP_CONF), Excel.Range)
                        xlRange.Value = dr("SYONIN_NO")

                        ''特殊フューチャーの存在するパターンの場合、複件数のPayment情報を更新する。
                        Dim changedPatternCd As String
                        changedPatternCd = excelWrite.GetPatternCD(dr("PATTERNCD"), dr("PATTERN"))
                        If changedPatternCd = "1" Or
                           changedPatternCd = "2" Then

                            Call WriteSFuterDate(xlOutPSBookPSSheet, DtOBAMAPS, dr)

                        End If

                        Exit For

                    End If
                Next
                ''▲---------------------------------------------------------------------

                ''一致するデータが存在しない場合、取込失敗情報をセット
                If isMatchPSData = False Then
                    ''取込失敗情報をセット                    
                    isErr = True
                    errLineNo = ChangeNothingToBlank(dr("LINE_NO"))
                    errKihyoNo = ChangeNothingToBlank(dr("KIHYO_NO"))
                End If

SkipPayment:

                ''取込失敗情報をTopacsファイルの最後の列　＋　１列後にエラーを出力
                If isErr Then
                    Dim msg As String

                    ''取込失敗件数を数える。
                    ''※起票者Null件数と、取込失敗件数は分けてカウントする。
                    If isNotEntry Then
                        outCntNotEntry = outCntNotEntry + 1
                        msg = "起票者が入力されていないため、取込対象外です。"
                    Else
                        outCntUnMatchPS = outCntUnMatchPS + 1
                        msg = "行番" + errLineNo + "の起票番号" + errKihyoNo + "の取込が失敗しました。"
                        msg = msg + "行番、パターンコード、製品番号、導入年月、Listprice合計、割引後価格合計が一致するデータがありません。"
                    End If

                    ''メッセージ表示
                    xlRange = xlInTopacsPSSheet.Cells(outTopacsRows, TopacsColumn.ERRLOG)
                    xlRange.Value = msg

                Else
                    ''取込失敗情報を初期化
                    xlRange = xlInTopacsPSSheet.Cells(outTopacsRows, TopacsColumn.ERRLOG)
                    xlRange.Value = ""
                End If
            Next

            xlOutPSBookPSSheet.EnableOutlining = True

            ''警告メッセージの非表示
            xlApp.DisplayAlerts = False

            ''マクロのBeforeSaveイベントの無効化
            xlApp.EnableEvents = False

            'Bookの保存
            ''別名保存の処理を実行
            '※VBActNMListに統合
            excelWrite.KickVBABookSave(xlApp, xlOutPSBook, excelWrite.VBActNMList.TOPACS取込, CommonVariable.USERID, CommonVariable.USERPW)

            ''警告メッセージの非表示
            xlApp.DisplayAlerts = False

            xlTopacsBook.Save()

            xlApp.DisplayAlerts = True
            xlApp.EnableEvents = True
            TOPACSReflection = True

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")

        Finally
            '後処理
            ExcelObjRelease.ReleaseExcelObj(xlInterior, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlInTopacsPSSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlInTopacsDetailSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlInTopacsWorningLogSheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlTopacsBook) = False Then
                xlTopacsBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlTopacsBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlOutPSBookPSSheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlOutPSBook) = False Then
                xlOutPSBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlOutPSBook, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Function

#End Region

#Region "WS1シートコピー"

    ''' <summary>
    ''' 概　要：WS1シートをTopacs ファイルにコピーする
    ''' </summary>
    ''' <remarks></remarks>
    Public Function CopyWS1(ByVal TopacsExcelFilePath As String, _
                            ByVal PSExcelFilePath As String) As Boolean

        CopyWS1 = False

        Dim App As New Excel.Application
        Dim TopacsBook As Excel.Workbook            ''Topacsファイル
        Dim TopacsSheet As Excel.Worksheet          ''Topacsファイル　コピー先シート
        Dim TopacsWS1Sheet As Excel.Worksheet       ''Topacsファイル　WS1シート
        Dim psBook As Excel.Workbook                ''個別PS　Book
        Dim psSheet As Excel.Worksheet              ''個別PS　WS1シート
        Dim xlShape As Excel.Shape

        ''Excelアプリ　初期設定
        App.EnableEvents = False
        App.DisplayAlerts = False

        Try

            ''WS1を先頭のシートへコピー
            psBook = App.Workbooks.Open(PSExcelFilePath)
            psSheet = psBook.Worksheets(excelWrite.EXCEL_PAYMENTLINEDATE_WS1)
            TopacsBook = App.Workbooks.Open(TopacsExcelFilePath)
            TopacsSheet = TopacsBook.Worksheets(excelWrite.EXCEL_TOPACSDATE_PAYMENTSHEET)
            psSheet.Copy(Before:=TopacsSheet)

            For Each xlName As Excel.Name In TopacsBook.Names
                xlName.Delete()
            Next

            ''Bookの保存
            TopacsBook.Save()

            CopyWS1 = True

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")

        Finally
            App.EnableEvents = True
            App.DisplayAlerts = True

            ''Excelオブジェ　解放
            ExcelObjRelease.ReleaseExcelObj(xlShape, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(psSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(TopacsSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(TopacsWS1Sheet, ExcelObjRelease.OBJECT_NOTHING)

            If IsNothing(TopacsBook) = False Then
                TopacsBook.Close(False)
            End If
            If IsNothing(psBook) = False Then
                psBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(TopacsBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(psBook, ExcelObjRelease.OBJECT_NOTHING)

            If IsNothing(App) = False Then
                App.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(App, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()

        End Try
    End Function
#End Region

#Region "プライベートメソッド"
    ''' <summary>
    ''' 機能：行チェック
    ''' 説明：行番、ファイル名、契約順番、案件番号のいずれかにデータあるかチェックする
    ''' 　　　True：ある　False：ない
    ''' </summary>
    ''' <param name="intIndex"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckRowItem(ByVal intIndex As Integer, ByVal ExcelCellInfo() As Object) As Integer

        CheckRowItem = False

        Try
            '行番、ファイル名、契約順番、案件番号 が共に空文字の場合、データ無しとみなす
            If IsNothing(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.LINE_NO)) = True And _
                IsNothing(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.FILE_NAME)) = True And _
                IsNothing(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.CONTRACT)) = True And _
                IsNothing(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.PROJ_ID)) = True Then

                Exit Function
            End If
        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical)
        End Try

        CheckRowItem = True

    End Function

    ''' <summary>
    ''' 機能：Eof行のチェック
    ''' 説明：個別詳細の行データがEOFかどうか判定する。
    ''' 　　　True：ある　False：ない
    ''' </summary>
    ''' <param name="intIndex"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckDetailEofLine(ByVal ExcelCellInfo() As Object) As Integer

        CheckDetailEofLine = False

        Try
            '行番、ファイル名、契約順番、案件番号 が共に空文字の場合、データ無しとみなす
            If IsNothing(ExcelCellInfo(excelWrite.ExcelPaymentLineDetailColumn.FILE_NAME)) = True And _
                IsNothing(ExcelCellInfo(excelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX)) = True And _
                IsNothing(ExcelCellInfo(excelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR)) = True And _
                IsNothing(ExcelCellInfo(excelWrite.ExcelPaymentLineDetailColumn.SEQ)) = True Then

                Exit Function
            End If
        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical)
        End Try

        CheckDetailEofLine = True

    End Function


    ''' <summary>
    ''' 機能：行チェック
    ''' 説明：行番、ファイル名、契約順番、案件番号、IOC合計のいずれかにデータあるかチェックする
    ''' 　　　True：ある　False：ない
    ''' </summary>
    ''' <param name="intIndex"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckRowItemRow(ByVal intIndex As Integer, ByVal ExcelCellInfo() As Object) As Integer

        CheckRowItemRow = False

        Try
            '行番、ファイル名、契約順番、IOC合計が共に空文字の場合、データ無しとみなす
            If IsNothing(ExcelCellInfo(TopacsColumn.LINE_NO)) = True And _
                IsNothing(ExcelCellInfo(TopacsColumn.CONTRACT)) = True And _
                IsNothing(ExcelCellInfo(TopacsColumn.PRICE_QTY_IOC)) = True Then

                Exit Function
            End If
        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical)
        End Try

        CheckRowItemRow = True

    End Function

    ''' <summary>
    ''' Brandカテゴリでソートする
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SortByBrCategory(ByRef dtSort As DataTable)
        If 1 < dtSort.Rows.Count Then
            Dim k As Integer
            For k = 0 To dtSort.Rows.Count - 1
                Select Case dtSort.Rows(k)(COLNM & excelWrite.ExcelPaymentLineColumn.BU).ToString()
                    Case "STG"
                        Select Case dtSort.Rows(k)(COLNM & excelWrite.ExcelPaymentLineColumn.BRAND).ToString()
                            Case "HW"
                                dtSort.Rows(k)("SORT_COL") = "01"
                            Case "HW BRAND SW"
                                dtSort.Rows(k)("SORT_COL") = "02"
                            Case "HW BRAND SWMA"
                                dtSort.Rows(k)("SORT_COL") = "03"
                            Case "HW brand SVC"
                                dtSort.Rows(k)("SORT_COL") = "04"
                            Case Else
                                dtSort.Rows(k)("SORT_COL") = "05"
                        End Select
                    Case "SWG"
                        Select Case dtSort.Rows(k)(COLNM & excelWrite.ExcelPaymentLineColumn.BRAND).ToString()
                            Case "ESW"
                                dtSort.Rows(k)("SORT_COL") = "06"
                            Case "SW Brand SW"
                                dtSort.Rows(k)("SORT_COL") = "07"
                            Case "SW Brand SWMA"
                                dtSort.Rows(k)("SORT_COL") = "08"
                            Case "PA-Media"
                                dtSort.Rows(k)("SORT_COL") = "09"
                            Case "PA-License"
                                dtSort.Rows(k)("SORT_COL") = "10"
                            Case "PA-S&S"
                                dtSort.Rows(k)("SORT_COL") = "11"
                            Case "SW Brand Service"
                                dtSort.Rows(k)("SORT_COL") = "12"
                            Case Else
                                dtSort.Rows(k)("SORT_COL") = "13"
                        End Select
                    Case "GTS"
                        Select Case dtSort.Rows(k)(COLNM & excelWrite.ExcelPaymentLineColumn.BRAND).ToString()
                            Case "GTS-MTS"
                                dtSort.Rows(k)("SORT_COL") = "14"
                            Case "GTS-ITS"
                                dtSort.Rows(k)("SORT_COL") = "15"
                            Case Else
                                dtSort.Rows(k)("SORT_COL") = "16"
                        End Select
                    Case "GBS"
                        Select Case dtSort.Rows(k)(COLNM & excelWrite.ExcelPaymentLineColumn.BRAND).ToString()
                            Case "GBS-SVC"
                                dtSort.Rows(k)("SORT_COL") = "17"
                            Case Else
                                dtSort.Rows(k)("SORT_COL") = "18"
                        End Select
                    Case "IGF"
                        Select Case dtSort.Rows(k)(COLNM & excelWrite.ExcelPaymentLineColumn.BRAND).ToString()
                            Case "IGF(中古)"
                                dtSort.Rows(k)("SORT_COL") = "19"
                            Case "IGF(金利)"
                                dtSort.Rows(k)("SORT_COL") = "20"
                            Case Else
                                dtSort.Rows(k)("SORT_COL") = "21"
                        End Select
                    Case "VLS"
                        Select Case dtSort.Rows(k)(COLNM & excelWrite.ExcelPaymentLineColumn.BRAND).ToString()
                            Case "IASC"
                                dtSort.Rows(k)("SORT_COL") = "22"
                            Case "IASC(SPOT)"
                                dtSort.Rows(k)("SORT_COL") = "23"
                            Case Else
                                dtSort.Rows(k)("SORT_COL") = "24"
                        End Select
                    Case Else
                        dtSort.Rows(k)("SORT_COL") = "25"
                End Select
            Next
            ''Brandカテゴリ,サマリカテゴリ（Topacs用）,導入年、月、NOでソート
            Dim dvSort As DataView = New DataView(dtSort)
            dvSort.Sort = "SORT_COL, Col22, Col63 , Col4 ASC"
            dtSort = dvSort.ToTable()

        End If
    End Sub


    ''' <summary>
    ''' 概　要：Topasc申請の対象データか判別
    ''' 説　明：
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ChechTopacsOutput(ByVal ExcelCellInfo() As Object) As Boolean

        ''初期化
        ChechTopacsOutput = False

        ''-------------------------------------------------
        ''以下、除外条件
        ''-------------------------------------------------
        ''作業指示行
        If Convert.ToString(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.VALID_FLAG)) = "N" Then
            Exit Function
        End If

        ''コメント行
        If Convert.ToString(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.VALID_FLAG)) = "C" Then
            Exit Function
        End If

        ''契約締結済み
        If Convert.ToString(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.LOCK_FLAG)) = "C" Then
            Exit Function
        End If

        If Convert.ToString(ExcelCellInfo(ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD)) = "1" Then
            If Left(Convert.ToString(ExcelCellInfo(ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01)), 3) = "666" Then
                Exit Function
            End If
        End If

        ''入力項目パターンが0 ～ 12以外
        Dim changePatternCD As String
        changePatternCD = excelWrite.GetPatternCD(excelWrite.changeDBNullToString(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.PATTERN_CD)), excelWrite.changeDBNullToString(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.PATTERN)))
        If (IsNumeric(changePatternCD) AndAlso Convert.ToInt32(changePatternCD) > 12) Then
            Exit Function
        End If

        ''数量がマイナス
        If IsNumeric(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.QTY)) = True Then
            If CDbl(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.QTY)) < 0 Then
                Exit Function
            End If
        End If

        Return True

    End Function

    ''' <summary>
    ''' 説　明：サブブランド、導入月の集計行を追加する。
    ''' 概　要：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSummaryTopacsTable(ByVal dtTOPACSPS As DataTable) As DataTable

        '集計行を追加
        Dim breakDounyuMonth As String = ""
        Dim breakSumCategory As String = ""

        ''ListPriceの集計
        Dim sumListPriceLarge As Decimal
        Dim sumListPriceMiddle As Decimal
        Dim dblListPriceLarge As Decimal
        Dim dblListPriceMiddle As Decimal

        ''COC合計の集計
        Dim sumCOC_SUMLarge As Decimal
        Dim sumCOC_SUMMiddle As Decimal
        Dim dblCOC_SUMLarge As Decimal
        Dim dblCOC_SUMMiddle As Decimal

        Dim cntRow As Integer

        ''Table構造体のコピー
        Dim dtTOPACSSum As DataTable
        dtTOPACSSum = dtTOPACSPS.Clone()

        Dim SumCategory As String
        Dim dounyuMonth As String

        Dim Bu As String
        Dim Brand As String
        Dim dispDounyuMonth As String
        Dim breakBu As String
        Dim breakBrand As String
        Dim breakdispDounyuMonth As String
        For Each dr As DataRow In dtTOPACSPS.Rows
            ''導入年月のセット
            If IsDate(dr.Item(COLNM & excelWrite.ExcelPaymentLineColumn.INST_DATE)) = True Then
                dounyuMonth = CDate(dr.Item(COLNM & excelWrite.ExcelPaymentLineColumn.INST_DATE)).ToString("yyyy/MM")
            Else
                dounyuMonth = ""
            End If

            ''サマリカテゴリをセット（集計、ソート条件をSubBrand ⇒　サマリカテゴリに変更）
            SumCategory = dr.Item(COLNM & excelWrite.ExcelPaymentLineColumn.SUM_CATEGORY).trim

            Bu = dr.Item(COLNM & excelWrite.ExcelPaymentLineColumn.BU)
            Brand = dr.Item(COLNM & excelWrite.ExcelPaymentLineColumn.BRAND)

            ''集計行の見出しに使用
            Bu = dr.Item(COLNM & excelWrite.ExcelPaymentLineColumn.BU).ToString()
            Brand = dr.Item(COLNM & excelWrite.ExcelPaymentLineColumn.BRAND).ToString()
            If IsDate(dr.Item(COLNM & excelWrite.ExcelPaymentLineColumn.INST_DATE)) = True Then
                dispDounyuMonth = CDate(dr.Item(COLNM & excelWrite.ExcelPaymentLineColumn.INST_DATE)).ToString("yyyy/MM")
            Else
                dispDounyuMonth = ""
            End If

            '最初の1行目
            If cntRow = 0 Then
                breakDounyuMonth = dounyuMonth
                breakSumCategory = SumCategory

                breakBu = Bu
                breakBrand = Brand

                ''集計行の見出しに使用
                breakBu = dr.Item(COLNM & excelWrite.ExcelPaymentLineColumn.BU).ToString()
                breakBrand = dr.Item(COLNM & excelWrite.ExcelPaymentLineColumn.BRAND).ToString()
                If IsDate(dr.Item(COLNM & excelWrite.ExcelPaymentLineColumn.INST_DATE)) = True Then
                    breakdispDounyuMonth = CDate(dr.Item(COLNM & excelWrite.ExcelPaymentLineColumn.INST_DATE)).ToString("yyyy/MM")
                Else
                    breakdispDounyuMonth = ""
                End If

                dtTOPACSSum.ImportRow(dr)
                cntRow += 1

                '中合計を加算
                dblListPriceMiddle = 0
                If Double.TryParse(dr.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH).ToString(), dblListPriceMiddle) Then
                    sumListPriceMiddle += dblListPriceMiddle
                End If
                dblCOC_SUMMiddle = 0
                If Double.TryParse(dr.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC).ToString(), dblCOC_SUMMiddle) Then
                    sumCOC_SUMMiddle += dblCOC_SUMMiddle
                End If

                '大合計を加算
                dblListPriceLarge = 0
                If Double.TryParse(dr.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH).ToString(), dblListPriceLarge) Then
                    sumListPriceLarge += dblListPriceLarge
                End If
                dblCOC_SUMLarge = 0
                If Double.TryParse(dr.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC).ToString(), dblCOC_SUMLarge) Then
                    sumCOC_SUMLarge += dblCOC_SUMLarge
                End If

                Continue For

            End If

            '中分類の集計行を挿入
            If breakDounyuMonth <> dounyuMonth Or _
                breakSumCategory <> SumCategory Or _
                breakBu <> Bu Or _
                breakBrand <> Brand Then
                Dim drNew2 As DataRow = dtTOPACSSum.NewRow()

                drNew2.Item("中分類集計列") = 1
                drNew2.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH) = sumListPriceMiddle
                drNew2.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC) = sumCOC_SUMMiddle
                drNew2.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PROD_ITEM01) = GetTopaceSummaryTile("中集計",
                                                                                                     breakBu,
                                                                                                     breakBrand,
                                                                                                     breakSumCategory,
                                                                                                     breakdispDounyuMonth)
                sumListPriceMiddle = 0
                sumCOC_SUMMiddle = 0
                dtTOPACSSum.Rows.Add(drNew2)
                breakDounyuMonth = dounyuMonth

                ''集計行の見出しに使用
                If IsDate(dr.Item(COLNM & excelWrite.ExcelPaymentLineColumn.INST_DATE)) = True Then
                    breakdispDounyuMonth = CDate(dr.Item(COLNM & excelWrite.ExcelPaymentLineColumn.INST_DATE)).ToString("yyyy/MM")
                Else
                    breakdispDounyuMonth = ""
                End If

            End If

            '大分類の集計行を挿入            
            If breakSumCategory <> SumCategory Or _
               breakBu <> Bu Or _
               breakBrand <> Brand Then

                Dim drNew1 As DataRow = dtTOPACSSum.NewRow()
                drNew1.Item("大分類集計列") = 1
                drNew1.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH) = sumListPriceLarge
                drNew1.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC) = sumCOC_SUMLarge
                drNew1.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PROD_ITEM01) = GetTopaceSummaryTile("大集計",
                                                                                                     breakBu,
                                                                                                     breakBrand,
                                                                                                     breakSumCategory,
                                                                                                     breakdispDounyuMonth)
                sumListPriceLarge = 0
                sumCOC_SUMLarge = 0
                dtTOPACSSum.Rows.Add(drNew1)
                breakSumCategory = SumCategory
                breakBu = Bu
                breakBrand = Brand
                If IsDate(dr.Item(COLNM & excelWrite.ExcelPaymentLineColumn.INST_DATE)) = True Then
                    breakdispDounyuMonth = CDate(dr.Item(COLNM & excelWrite.ExcelPaymentLineColumn.INST_DATE)).ToString("yyyy/MM")
                Else
                    breakdispDounyuMonth = ""
                End If

            End If

            '中合計を加算
            dblListPriceMiddle = 0
            If Double.TryParse(dr.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH).ToString(), dblListPriceMiddle) Then
                sumListPriceMiddle += dblListPriceMiddle
            End If
            dblCOC_SUMMiddle = 0
            If Double.TryParse(dr.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC).ToString(), dblCOC_SUMMiddle) Then
                sumCOC_SUMMiddle += dblCOC_SUMMiddle
            End If

            '大合計を加算
            dblListPriceLarge = 0
            If Double.TryParse(dr.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH).ToString(), dblListPriceLarge) Then
                sumListPriceLarge += dblListPriceLarge
            End If
            dblCOC_SUMLarge = 0
            If Double.TryParse(dr.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC).ToString(), dblCOC_SUMLarge) Then
                sumCOC_SUMLarge += dblCOC_SUMLarge
            End If

            dtTOPACSSum.ImportRow(dr)

            cntRow += 1
        Next

        '最後の集計行
        Dim drEndNew2 As DataRow = dtTOPACSSum.NewRow()
        drEndNew2.Item("中分類集計列") = 1
        drEndNew2.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH) = sumListPriceMiddle
        drEndNew2.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC) = sumCOC_SUMMiddle
        drEndNew2.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PROD_ITEM01) = GetTopaceSummaryTile("中集計",
                                                                                                Bu,
                                                                                                Brand, SumCategory,
                                                                                                dispDounyuMonth)
        dtTOPACSSum.Rows.Add(drEndNew2)

        Dim drEndNew1 As DataRow = dtTOPACSSum.NewRow()
        drEndNew1.Item("大分類集計列") = 1
        drEndNew1.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH) = sumListPriceLarge
        drEndNew1.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC) = sumCOC_SUMLarge
        drEndNew1.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PROD_ITEM01) = GetTopaceSummaryTile("大集計",
                                                                                                Bu,
                                                                                                Brand,
                                                                                                SumCategory,
                                                                                                dispDounyuMonth)
        dtTOPACSSum.Rows.Add(drEndNew1)

        Return dtTOPACSSum

    End Function

    ''' <summary>
    ''' 説　明：TopacsファイルのPSシートへデータを書き込む
    ''' 概　要：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub WriteTopacsPSSheet(ByVal PSSheet As Excel.Worksheet, _
                                   ByVal dtTOPACSSum As DataTable)

        Dim tes As New TestClass2
        Dim xlCell As Excel.Range
        Dim xlEntireRow As Excel.Range
        Dim xlInterior As Excel.Interior
        Dim xlFormatConditions As Excel.FormatConditions
        Dim xlFont As Excel.Font

        Try

            '書式行表示
            xlCell = PSSheet.Range("2:2")
            xlEntireRow = xlCell.EntireRow
            xlEntireRow.Hidden = False

            Dim cntR As Integer = 0
            For Each drRow As DataRow In dtTOPACSSum.Rows
                '書式行コピー
                xlCell = PSSheet.Range("2:2")
                xlCell.Copy()
                xlCell = PSSheet.Range((excelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + cntR).ToString() & ":" & (excelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + cntR).ToString())
                xlCell.PasteSpecial()

                'セルに値をセットする
                xlCell = PSSheet.Range(Replace(EXCEL_PAYMENTLINEDATE_OUTCOLUM, "@", excelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + cntR))
                Call SetTopacsCellLine(xlCell, drRow)

                '中分類と、大分類の書式を設定
                If drRow("中分類集計列").ToString() = "1" Then
                    xlCell = PSSheet.Range(Replace(EXCEL_PAYMENTLINEDATE_ALLCOLUM, "@", excelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + cntR))
                    xlFormatConditions = xlCell.FormatConditions
                    xlFormatConditions.Delete()
                    xlInterior = xlCell.Interior
                    xlInterior.Color = 13408767
                    xlFont = xlCell.Font
                    xlFont.FontStyle = "太字"

                    ''集計行のタイトルをセット
                    xlCell = PSSheet.Cells(excelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + cntR, TOPACSCOL_SUMARRYTITLE)
                    xlCell.Value = drRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PROD_ITEM01)

                    ''集計金額をセット
                    xlCell = PSSheet.Cells(excelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + cntR, TOPACSCOL_LISTPRICE_REFLESH)
                    xlCell.Value = drRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH)
                    xlCell = PSSheet.Cells(excelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + cntR, TOPACSCOL_DISCOUNT_SUM)
                    xlCell.Value = drRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC)

                    ''CRAD,BVD,LIDのセルの式を消す
                    xlCell = PSSheet.Cells(excelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + cntR, TOPACSCOL_CRAD)
                    xlCell.Value = ""
                    xlCell = PSSheet.Cells(excelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + cntR, TOPACSCOL_BVD)
                    xlCell.Value = ""
                    xlCell = PSSheet.Cells(excelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + cntR, TOPACSCOL_LID)
                    xlCell.Value = ""

                ElseIf drRow("大分類集計列").ToString() = "1" Then
                    xlCell = PSSheet.Range(Replace(EXCEL_PAYMENTLINEDATE_ALLCOLUM, "@", excelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + cntR))
                    xlFormatConditions = xlCell.FormatConditions
                    xlFormatConditions.Delete()
                    xlInterior = xlCell.Interior
                    xlInterior.Color = 10092543
                    xlFont = xlCell.Font
                    xlFont.FontStyle = "太字"

                    ''集計行のタイトルをセット
                    xlCell = PSSheet.Cells(excelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + cntR, TOPACSCOL_SUMARRYTITLE)
                    xlCell.Value = drRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PROD_ITEM01)

                    ''集計金額をセット
                    xlCell = PSSheet.Cells(excelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + cntR, TOPACSCOL_LISTPRICE_REFLESH)
                    xlCell.Value = drRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH)
                    xlCell = PSSheet.Cells(excelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + cntR, TOPACSCOL_DISCOUNT_SUM)
                    xlCell.Value = drRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC)

                    ''CRAD,BVD,LIDのセルの式を消す
                    xlCell = PSSheet.Cells(excelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + cntR, TOPACSCOL_CRAD)
                    xlCell.Value = ""
                    xlCell = PSSheet.Cells(excelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + cntR, TOPACSCOL_BVD)
                    xlCell.Value = ""
                    xlCell = PSSheet.Cells(excelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + cntR, TOPACSCOL_LID)
                    xlCell.Value = ""
                End If

                cntR += 1

            Next

            '書式行非表示
            xlCell = PSSheet.Range("2:2")
            xlEntireRow = xlCell.EntireRow
            xlEntireRow.Hidden = True

        Catch ex As Exception
            Throw ex

        Finally
            ''Excelオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlFont, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlInterior, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlFormatConditions, ExcelObjRelease.OBJECT_NOTHING)
        End Try

    End Sub

    ''' <summary>
    ''' 説　明：TopacsファイルのPSシートのセルに値をセット
    ''' 概　要：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetTopacsCellLine(ByRef xlCell As Excel.Range,
                                  ByVal row As DataRow)

        Dim pasetObjects(37) As Object

        Dim cellCoutn As Integer = 0

        ''TopaceファイルのPSシートの行に出力するデータを編集
        For i As Integer = 1 To row.ItemArray.Length
            Select Case i
                Case excelWrite.ExcelPaymentLineColumn.LOCK_FLAG
                    ''ﾛｯｸFLG
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.VALID_FLAG
                    ''有効/無効
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.LINE_NO
                    ''NO
                    If IsNumeric(row.Item(COLNM & i)) Then
                        pasetObjects(cellCoutn) = CInt(row.Item(COLNM & i)).ToString
                        cellCoutn = cellCoutn + 1
                    Else
                        pasetObjects(cellCoutn) = ""
                        cellCoutn = cellCoutn + 1
                    End If

                Case excelWrite.ExcelPaymentLineColumn.FILE_NAME
                    ''ﾌｧｲﾙ名
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX
                    ''ﾌｧｲﾙ名Suffix
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR
                    ''ﾌｧｲﾙ内Suffix
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.CONTRACT
                    ''契約NO
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case ExcelWrite.ExcelPaymentLineColumn.CONTRACT_SEQ
                    ''契約通番
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.NEW_EXIST
                    ''新規/既存
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.BU
                    ''BU
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.BRAND
                    ''Brand
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.SUM_CATEGORY
                    ''ｻﾏﾘｰ用ｶﾃｺﾞﾘ
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.BRAND_SUB
                    ''Sub Brand
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.OP1
                    ''Option1
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.OP2
                    ''Option2
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.BRAND_SIZE
                    ''Size
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.NON_SBO
                    ''SBO制限
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.TOPACS_CPNO
                    ''Topacs用CPNO
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.BRAND_AP_FORM
                    ''起票番号
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                    ''起票者名はデフォルト空白値をセット
                    pasetObjects(cellCoutn) = ""
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.BRAND_AP_REQ
                    ''申請番号
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.BRAND_AP_CONF
                    ''承認番号
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.PATTERN_CD
                    ''ﾊﾟﾀｰﾝ NO
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.PATTERN
                    ''ﾃﾞｰﾀ内容
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.PROD_ITEM01
                    ''製品番号
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.PROD_ITEM03
                    ''製品名称
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.WD_ANNT_DATE
                    ''廃止発表日
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.WD_DATE
                    ''廃止予定日
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.PRICE_CHG_DATE
                    ''予定日
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.QTY
                    ''数量
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.INST_DATE
                    If IsDate(row.Item(COLNM & i)) = True Then
                        ''導入年
                        pasetObjects(cellCoutn) = CDate(row.Item(COLNM & i)).Year
                        cellCoutn = cellCoutn + 1

                        ''導入月
                        pasetObjects(cellCoutn) = CDate(row.Item(COLNM & i)).Month
                        cellCoutn = cellCoutn + 1
                    Else
                        ''導入年
                        pasetObjects(cellCoutn) = ""
                        cellCoutn = cellCoutn + 1

                        ''導入月
                        pasetObjects(cellCoutn) = ""
                        cellCoutn = cellCoutn + 1
                    End If

                Case excelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH
                    ''ListPrice単価
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH
                    ''ListPrice合計
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.DP_IOC
                    ''D%
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

                Case excelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC
                    If IsDBNull(row.Item(COLNM & (i + 1))) Then
                        ''割引後価格単価
                        pasetObjects(cellCoutn) = row.Item(COLNM & i)
                        cellCoutn = cellCoutn + 1
                    Else
                        If Val(row.Item(COLNM & (i + 1))) <> 0 Then
                            ''割引後価格単価(Validation)
                            pasetObjects(cellCoutn) = row.Item(COLNM & (i + 1))
                            cellCoutn = cellCoutn + 1
                        Else
                            ''割引後価格単価
                            pasetObjects(cellCoutn) = row.Item(COLNM & i)
                            cellCoutn = cellCoutn + 1
                        End If
                    End If

                Case excelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC
                    ''割引後価格合計
                    pasetObjects(cellCoutn) = row.Item(COLNM & i)
                    cellCoutn = cellCoutn + 1

            End Select
        Next

        ''セルへ値をセットする。
        xlCell.Value = pasetObjects

    End Sub



    ''' <summary>
    ''' 説　明：特殊フューチャーの金額を集計したデータを返す
    ''' 概　要：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSumSpecialFeature(ByVal InDataTable As DataTable) As DataTable

        Dim rtnTable As DataTable
        rtnTable = InDataTable.Clone

        Dim specialFeatureRows() As DataRow
        Dim notSpecialFeatureRows() As DataRow

        ''--------------------------------------------------------
        ''特殊フューチャーのを含まないデータ
        ''-------------------------------------------------------
        Dim filter As New StringBuilder
        ''特殊フューチャー以外をSelect 
        ''※イメージ:（パターンCD 1、2以外) And (直接入力のパターン名称 1,2以外)

        ''パターンCDが直接入力以外
        filter.Append(CommonConstant.SQL_STR_NOT)
        filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        filter.Append(COLNM & excelWrite.ExcelPaymentLineColumn.PATTERN_CD)
        filter.Append(" IN ('1','2') ")
        filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

        notSpecialFeatureRows = InDataTable.Select(filter.ToString)

        ''行の挿入
        Dim insRow As DataRow
        For Each tempRow As DataRow In notSpecialFeatureRows

            ''直接入力の場合、パターン名称で処理を変更
            ''※IBM　HW　AAS BOX or MESは出力しない
            If tempRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PATTERN) = CommonConstant.PATTERNNM_IBM_HW_AAS_BOX Or _
               tempRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PATTERN) = CommonConstant.PATTERNNM_IBM_HW_AAS_MES Then
                Continue For
            End If

            insRow = rtnTable.NewRow
            Call SetSpecialFeatureRow(insRow, tempRow)

            rtnTable.Rows.Add(insRow)
        Next

        ''------------------------------------------------------
        ''特殊フューチャーを含むパターンコードの集計
        ''------------------------------------------------------
        specialFeatureRows = GetSumFeature(InDataTable)

        ''行の挿入
        For Each tempRow As DataRow In specialFeatureRows
            insRow = rtnTable.NewRow
            Call SetSpecialFeatureRow(insRow, tempRow)
            rtnTable.Rows.Add(insRow)
        Next

        Return rtnTable

    End Function


    ''' <summary>
    ''' 説　明：特殊フューチャーを持つパターンコードの集計
    ''' 概　要：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSumFeature(ByVal InDataTable As DataTable) As DataRow()

        Dim rtnRows() As DataRow

        ''特殊フューチャーを含まないレコードの抽出
        Dim filter As New StringBuilder

        ''直接入力以外
        filter.Append(COLNM & excelWrite.ExcelPaymentLineColumn.PATTERN_CD)
        filter.Append(" IN ")
        filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        filter.Append(" '1' , '2' ")
        filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(COLNM & excelWrite.ExcelPaymentLineColumn.OP1)
        filter.Append(CommonConstant.SQL_STR_NOT)
        filter.Append(" IN ('CBUﾌｨｰﾁｬｰ','ﾏｲｸﾛｺｰﾄﾞﾌｨｰﾁｬｰ') ")

        ''直接入力
        filter.Append(CommonConstant.SQL_STR_OR)
        filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        filter.Append(COLNM & excelWrite.ExcelPaymentLineColumn.PATTERN_CD)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNCD_TYPE_DIRECTINPUT))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(COLNM & excelWrite.ExcelPaymentLineColumn.PATTERN)
        filter.Append(" IN ('IBM HW AAS BOX','IBM HW AAS MES') ")
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(COLNM & excelWrite.ExcelPaymentLineColumn.OP1)
        filter.Append(CommonConstant.SQL_STR_NOT)
        filter.Append(" IN ('CBUﾌｨｰﾁｬｰ','ﾏｲｸﾛｺｰﾄﾞﾌｨｰﾁｬｰ') ")
        filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

        ''データ取得
        rtnRows = InDataTable.Select(filter.ToString)

        ''特殊フューチャーの金額を集計し、BOXの金額へ加算する。
        Dim Qty As Integer
        Dim DPIOC As Decimal
        Dim ListPrice As Decimal
        Dim sumListPrice As Decimal
        Dim PriceQtyIOC As Decimal
        Dim sumPriceQtyIOC As Decimal
        Dim filterFeature As New StringBuilder

        For i As Integer = 0 To rtnRows.Length - 1

            ''BOXの金額、数量をセット
            Qty = rtnRows(i).Item(COLNM & excelWrite.ExcelPaymentLineColumn.QTY)
            sumListPrice = changeDBNullToZero(rtnRows(i).Item(COLNM & excelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH))
            sumPriceQtyIOC = changeDBNullToZero(rtnRows(i).Item(COLNM & excelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC))

            ''BOXに紐づく特殊フューチャーを取得
            filterFeature.Remove(0, filterFeature.Length)
            filterFeature.Append(COLNM & excelWrite.ExcelPaymentLineColumn.PATTERN_CD)
            filterFeature.Append(CommonConstant.SQL_STR_EQUAL)
            filterFeature.Append(StringEdit.EncloseSingleQuotation(rtnRows(i).Item(COLNM & excelWrite.ExcelPaymentLineColumn.PATTERN_CD)))
            filterFeature.Append(CommonConstant.SQL_STR_AND)
            filterFeature.Append(COLNM & excelWrite.ExcelPaymentLineColumn.FILE_NAME)
            filterFeature.Append(CommonConstant.SQL_STR_EQUAL)
            filterFeature.Append(StringEdit.EncloseSingleQuotation(rtnRows(i).Item(COLNM & excelWrite.ExcelPaymentLineColumn.FILE_NAME)))
            filterFeature.Append(CommonConstant.SQL_STR_AND)
            filterFeature.Append(COLNM & excelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX)
            filterFeature.Append(CommonConstant.SQL_STR_EQUAL)
            filterFeature.Append(StringEdit.EncloseSingleQuotation(rtnRows(i).Item(COLNM & excelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX)))
            filterFeature.Append(CommonConstant.SQL_STR_AND)
            filterFeature.Append(COLNM & excelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR)
            filterFeature.Append(CommonConstant.SQL_STR_EQUAL)
            filterFeature.Append(StringEdit.EncloseSingleQuotation(rtnRows(i).Item(COLNM & excelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR)))
            filterFeature.Append(CommonConstant.SQL_STR_AND)
            filterFeature.Append(COLNM & excelWrite.ExcelPaymentLineColumn.CONTRACT)
            filterFeature.Append(CommonConstant.SQL_STR_EQUAL)
            filterFeature.Append(StringEdit.EncloseSingleQuotation(rtnRows(i).Item(COLNM & excelWrite.ExcelPaymentLineColumn.CONTRACT)))
            filterFeature.Append(CommonConstant.SQL_STR_AND)
            filterFeature.Append(COLNM & excelWrite.ExcelPaymentLineColumn.OP1)
            filterFeature.Append(" IN ('CBUﾌｨｰﾁｬｰ','ﾏｲｸﾛｺｰﾄﾞﾌｨｰﾁｬｰ') ")

            ''特殊フューチャーの金額を集計
            For Each tempRow As DataRow In InDataTable.Select(filterFeature.ToString)
                sumListPrice = sumListPrice + changeDBNullToZero(tempRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH))
                sumPriceQtyIOC = sumPriceQtyIOC + changeDBNullToZero(tempRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC))
            Next

            ''単価、D%を算出
            If Qty <> 0 Then
                ListPrice = sumListPrice / Qty
                PriceQtyIOC = sumPriceQtyIOC / Qty
            Else
                ListPrice = 0
                PriceQtyIOC = 0
            End If
            If sumListPrice <> 0 Then
                DPIOC = 1 - (sumPriceQtyIOC / sumListPrice)
            Else
                DPIOC = 0
            End If

            ''集計金額のセット
            rtnRows(i).Item(COLNM & excelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH) = ListPrice
            rtnRows(i).Item(COLNM & excelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH) = sumListPrice
            rtnRows(i).Item(COLNM & excelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC) = PriceQtyIOC
            rtnRows(i).Item(COLNM & excelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC) = sumPriceQtyIOC
            rtnRows(i).Item(COLNM & excelWrite.ExcelPaymentLineColumn.COST_RATE) = DPIOC

        Next

        Return rtnRows

    End Function

    ''' <summary>
    ''' 説　明：集計結果をDataRowへセットする。
    ''' 概　要：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetSpecialFeatureRow(ByRef setRow As DataRow, _
                                     ByVal row As DataRow)

        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.UPDATE_FLAG) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.UPDATE_FLAG)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LOCK_FLAG) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LOCK_FLAG)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.VALID_FLAG) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.VALID_FLAG)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LINE_NO) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LINE_NO)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.FILE_NAME) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.FILE_NAME)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.CONTRACT) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.CONTRACT)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.ST_COST) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.ST_COST)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.ST_APPROVAL) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.ST_APPROVAL)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PROJ_ID) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PROJ_ID)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.CONTRACT_SEQ) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.CONTRACT_SEQ)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.NEW_EXIST) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.NEW_EXIST)
        setRow.Item(COLNM & ExcelWrite.ExcelPaymentLineColumn.CUST_CATEGORY) = row.Item(COLNM & ExcelWrite.ExcelPaymentLineColumn.CUST_CATEGORY)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LETTER_PLAN_DATE) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LETTER_PLAN_DATE)
        setRow.Item(COLNM & ExcelWrite.ExcelPaymentLineColumn.LETTER_ACCEPT_DATE) = row.Item(COLNM & ExcelWrite.ExcelPaymentLineColumn.LETTER_ACCEPT_DATE)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.ORDER_DATE) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.ORDER_DATE)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LETTER_ID) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LETTER_ID)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.BU) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.BU)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.BRAND) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.BRAND)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.SUM_CATEGORY) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.SUM_CATEGORY)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.BRAND_SUB) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.BRAND_SUB)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.OP1) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.OP1)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.OP2) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.OP2)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.BRAND_SIZE) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.BRAND_SIZE)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.NON_SBO) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.NON_SBO)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.TOPACS_CPNO) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.TOPACS_CPNO)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.BRAND_AP_FORM) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.BRAND_AP_FORM)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.BRAND_AP_REQ) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.BRAND_AP_REQ)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.BRAND_AP_CONF) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.BRAND_AP_CONF)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PATTERN_CD) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PATTERN_CD)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PATTERN) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PATTERN)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PROD_ITEM01) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PROD_ITEM01)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PROD_ITEM02) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PROD_ITEM02)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PROD_ITEM03) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PROD_ITEM03)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PROD_ITEM04) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PROD_ITEM04)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PROD_ITEM05) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PROD_ITEM05)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PROD_ITEM06) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PROD_ITEM06)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PROD_ITEM07) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PROD_ITEM07)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PROD_ITEM08) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PROD_ITEM08)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PROD_ITEM09) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PROD_ITEM09)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PROD_ITEM10) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PROD_ITEM10)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.WD_ANNT_DATE) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.WD_ANNT_DATE)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.WD_DATE) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.WD_DATE)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PRICE_CHG_DATE) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PRICE_CHG_DATE)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.QTY) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.QTY)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.INST_DATE) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.INST_DATE)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PAY_START_DATE) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PAY_START_DATE)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PAY_END_DATE) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PAY_END_DATE)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PAY_MONTHS) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PAY_MONTHS)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PAY_METHOD) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PAY_METHOD)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.IGF_APPLIED) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.IGF_APPLIED)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.IGF_CONT_NO) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.IGF_CONT_NO)
        setRow.Item(COLNM & ExcelWrite.ExcelPaymentLineColumn.IGF_RATE_IOC) = row.Item(COLNM & ExcelWrite.ExcelPaymentLineColumn.IGF_RATE_IOC)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_PROPOSAL) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_PROPOSAL)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH)
        setRow.Item(COLNM & ExcelWrite.ExcelPaymentLineColumn.DP_IOC) = row.Item(COLNM & ExcelWrite.ExcelPaymentLineColumn.DP_IOC)
        setRow.Item(COLNM & ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC) = row.Item(COLNM & ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC)
        'Re1.1346 2015/12 Str
        setRow.Item(COLNM & ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC_VAL) = row.Item(COLNM & ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC_VAL)
        'Re1.1346 2015/12 End
        setRow.Item(COLNM & ExcelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC) = row.Item(COLNM & ExcelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.COST_RATE) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.COST_RATE)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.COST) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.COST)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.COST_TOTAL) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.COST_TOTAL)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.COST_INPUT_DATE) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.COST_INPUT_DATE)
        setRow.Item(COLNM & ExcelWrite.ExcelPaymentLineColumn.PRICE_TO_SPLIT) = row.Item(COLNM & ExcelWrite.ExcelPaymentLineColumn.PRICE_TO_SPLIT)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_IOC) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_IOC)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PRICE_TOTAL_IOC) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PRICE_TOTAL_IOC)
        setRow.Item(COLNM & excelWrite.ExcelPaymentLineColumn.COST_TOTAL_IOC) = row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.COST_TOTAL_IOC)

    End Sub

    ''' <summary>
    ''' 機　能：Topacs起票ファイルに紐づく個別PS.xlsのデータが存在するかどうか？
    ''' 説　明：
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ExistPSDate(ByRef DtOBAMAPS As DataTable, _
                                 ByVal ExcelCellInfo() As Object, _
                                 ByVal dr As DataRow) As Boolean

        ''初期化
        ExistPSDate = False

        ''変換後のパターンCD
        Dim chgPatternCd As String
        chgPatternCd = excelWrite.GetPatternCD(ChangeNothingToBlank(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.PATTERN_CD)), ChangeNothingToBlank(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.PATTERN)))

        ''-------------------------------------------
        ''以下、マッチングの判定
        ''-------------------------------------------
        ''コメント行
        If ChangeNothingToBlank(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.VALID_FLAG)) = "C" Then
            Exit Function
        End If

        ''N行
        If ChangeNothingToBlank(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.VALID_FLAG)) = "N" Then
            Exit Function
        End If

        ''行番号
        If ChangeNothingToBlank(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.LINE_NO)) <> dr("LINE_NO").ToString Then
            Exit Function
        End If

        ''数量
        If IsNumeric(ChangeNothingToBlank(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.QTY))) = False OrElse _
           CDbl(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.QTY)) < 0 Then
            Exit Function
        End If

        ''製品番号
        If ChangeNothingToBlank(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.PROD_ITEM01)) <> dr("ITEM01").ToString Then
            Exit Function
        End If

        ''パターンコード
        If ChangeNothingToBlank(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.PATTERN_CD)) <> dr("PATTERNCD").ToString Then
            Exit Function
        End If

        If chgPatternCd <> "1" And
           chgPatternCd <> "2" Then

            ''Listprice
            If changeDBNullToZero(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH)) <> changeDBNullToZero(dr("LISTPRICE")) Then
                Exit Function
            End If

            ''割引後
            If changeDBNullToZero(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC)) <> changeDBNullToZero(dr("DISCOUNTPRICE")) Then
                Exit Function
            End If

        Else

            ''特殊フューチャーを含むパターンの場合、特殊フューチャーの金額を集計する。
            Dim rtnListPrice As String
            Dim rtnPriceQtyIoc As String
            Call GetSPFuterTotal(DtOBAMAPS, ExcelCellInfo, rtnListPrice, rtnPriceQtyIoc)

            ''Listprice
            If changeDBNullToZero(rtnListPrice) <> changeDBNullToZero(dr("LISTPRICE")) Then
                Exit Function
            End If

            ''割引後
            If changeDBNullToZero(rtnPriceQtyIoc) <> changeDBNullToZero(dr("DISCOUNTPRICE")) Then
                Exit Function
            End If

        End If

        ''導入年月　比較
        Dim PSInstD As String
        Dim TopInstD As String
        PSInstD = excelWrite.changeDBNullToString(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.INST_DATE))
        If IsDate(PSInstD) = True Then
            PSInstD = CDate(PSInstD).ToString("yyyy/MM")
        Else
            PSInstD = ""
        End If
        TopInstD = dr("INST_YEAR") & "/" & dr("INST_MONTH")
        If IsDate(TopInstD) = True Then
            TopInstD = CDate(TopInstD).ToString("yyyy/MM")
        Else
            TopInstD = ""
        End If
        If PSInstD <> TopInstD Then
            Exit Function
        End If

        Return True

    End Function

    ''' <summary>
    ''' 機　能：Nothingを空文字へ変換する。
    ''' 説　明：
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ChangeNothingToBlank(ByVal Value As Object) As String

        ChangeNothingToBlank = ""

        If IsNothing(Value) = False Then
            Return Value.ToString
        End If

    End Function

    ''' <summary>
    ''' 機　能：集計用のKeyをセットする。
    ''' 説　明：
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetBUSummaryKey(ByVal row As DataRow) As String

        ''初期化
        GetBUSummaryKey = ""

        ''BU,Brand,ｻﾏﾘｰ用ｶﾃｺﾞﾘをKeyとする。
        GetBUSummaryKey = GetBUSummaryKey & row.Item(COLNM & "21").ToString()
        GetBUSummaryKey = GetBUSummaryKey & row.Item(COLNM & "22").ToString()
        GetBUSummaryKey = GetBUSummaryKey & row.Item(COLNM & "23").ToString()

    End Function


    ''' <summary>
    ''' 機　能：Topacs申請ファイルの集計行タイトル名を取得
    ''' 説　明：
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetTopaceSummaryTile(ByVal titelKb As String, _
                                          ByVal bu As String, _
                                          ByVal brand As String, _
                                          ByVal summaryCategory As String, _
                                          ByVal dounyuDate As String) As String

        ''初期化
        GetTopaceSummaryTile = ""

        ''タイトル文言の変更
        Select Case titelKb
            Case "中集計"
                GetTopaceSummaryTile = bu + " " +
                       brand + " " +
                       summaryCategory + " " +
                        dounyuDate + " " +
                        "合計"

            Case "大集計"
                GetTopaceSummaryTile = bu + " " +
                       brand + " " +
                       summaryCategory + " " +
                        "合計"

        End Select

    End Function

    ''' <summary>
    ''' 機　能：ConvertClientValueTableの取得
    ''' 説　明：
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetConvertClientValueTable() As ConvertClientValueTable

        Try
            ''初期化
            Dim rtnTable As New ConvertClientValueTable
            GetConvertClientValueTable = rtnTable

            ''MDBの接続情報を取得	
            Dim con As OleDbConnection
            Dim mmc As New MasterMdbControl
            con = mmc.GetOleDBConnection(CommonVariable.MdbPW)

            ''値の取得
            Dim selectTable As New OleDbConvertClientValue
            rtnTable = selectTable.SelectDataTable(con, "ImportBrandName")

            Return rtnTable

        Catch ex As Exception
            Throw ex
        End Try

    End Function


    ''' <summary>
    ''' 機　能：個別PS .xlsﾌｧｲﾙからデータを取得
    ''' 説　明：
    ''' </summary>
    ''' <param name="TOPACS_CPNO"></param>
    ''' <param name="xlInPSSheet"></param>
    ''' <param name="ClientValue"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetPSDataTable(ByVal TOPACS_CPNO As String, _
                                    ByRef xlInPSSheet As Excel.Worksheet, _
                                    ByRef ClientValue As ConvertClientValueTable) As DataTable

        ''テーブル定義
        Dim rtnTable As New DataTable

        'データテーブルに列を追加
        For i As Integer = excelWrite.ExcelPaymentLineColumn.UPDATE_FLAG To excelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH12
            rtnTable.Columns.Add(COLNM & i.ToString())
        Next
        rtnTable.Columns.Add("大分類集計列")
        rtnTable.Columns.Add("中分類集計列")
        rtnTable.Columns.Add("SORT_COL")

        ''戻り値の初期化
        GetPSDataTable = rtnTable

        ''全列をデータテーブルに格納する
        Dim xlCell As Excel.Range
        Dim ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH12) As Object          ''Excelのセル情報
        Dim ExcelWork(1, excelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH12) As Object           ''Excelのセル情報
        Try
            For i As Integer = excelWrite.EXCEL_PAYMENTLINEDATE_OUTROW To EXCEL_MAX_ROW

                ''1行取得
                xlCell = xlInPSSheet.Range(excelWrite.EXCEL_PAYMENT_LINE_RANGE.Replace("@", i.ToString))
                ExcelWork = xlCell.Value

                ''ExcelのデータをExcelCellInfoへ値を格納し直す
                For j As Integer = excelWrite.ExcelPaymentLineColumn.UPDATE_FLAG To excelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH12
                    ExcelCellInfo(j) = ExcelWork(1, j)
                Next

                '行チェック
                If CheckRowItem(i, ExcelCellInfo) = False Then
                    Exit For
                End If

                ''出力対象のデータかどうか
                If ChechTopacsOutput(ExcelCellInfo) = False Then
                    Continue For
                End If

                ''サマリカテゴリの取得
                Dim summaryCategory As String
                summaryCategory = GetTopacsSummaryCategory(ExcelCellInfo, ClientValue)

                'Excelの値をデータテーブルにセット
                Dim row As DataRow = rtnTable.NewRow()
                For k As Integer = 1 To ExcelCellInfo.Length - 1

                    row.Item(k - 1) = ExcelWrite.changeDBNullToString(ExcelCellInfo(k))

                    ''Linnoは先頭0埋めにする
                    If k = excelWrite.ExcelPaymentLineColumn.LINE_NO Then
                        row.Item(k - 1) = excelWrite.changeDBNullToString(ExcelCellInfo(k)).ToString.PadLeft(8, "0")
                    End If

                    ''導入月は先頭0埋めにする。
                    If k = excelWrite.ExcelPaymentLineColumn.INST_DATE Then
                        Dim strWork As String = excelWrite.changeDBNullToString(ExcelCellInfo(k))
                        If IsDate(strWork) = True Then
                            row.Item(k - 1) = CDate(strWork).ToString("yyyy/MM/dd")
                        Else
                            row.Item(k - 1) = ""
                        End If
                    End If

                    ''Topacs用のサマリカテゴリをセット
                    If k = excelWrite.ExcelPaymentLineColumn.SUM_CATEGORY Then
                        row.Item(k - 1) = summaryCategory
                    End If

                    ''TopacsCPNO
                    If k = excelWrite.ExcelPaymentLineColumn.TOPACS_CPNO And _
                       excelWrite.changeDBNullToString(ExcelCellInfo(k)) = "" Then
                        row.Item(k - 1) = TOPACS_CPNO
                    End If

                Next

                rtnTable.Rows.Add(row)
            Next

            Return rtnTable

        Catch ex As Exception
            Throw ex

        Finally
            ''Excelオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Function


    ''' <summary>
    ''' 機　能：個別PS .xlsﾌｧｲﾙからデータを取得
    ''' 説　明：
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetPSDataTable(ByRef xlInPSSheet As Excel.Worksheet) As DataTable

        ''テーブル定義
        Dim rtnTable As New DataTable

        'データテーブルに列を追加
        For i As Integer = excelWrite.ExcelPaymentLineColumn.UPDATE_FLAG To excelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH12
            rtnTable.Columns.Add(COLNM & i.ToString())
        Next
        rtnTable.Columns.Add("ExcelRow")

        ''戻り値の初期化
        GetPSDataTable = rtnTable

        ''全列をデータテーブルに格納する
        Dim xlCell As Excel.Range
        Dim ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH12) As Object          ''Excelのセル情報
        Dim ExcelWork(1, excelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH12) As Object           ''Excelのセル情報
        Try
            For i As Integer = EXCEL_PAYMENTLINEDATE_OUTROW To EXCEL_MAX_ROW

                ''1行取得
                xlCell = xlInPSSheet.Range(excelWrite.EXCEL_PAYMENT_LINE_RANGE.Replace("@", i.ToString))
                ExcelWork = xlCell.Value

                ''ExcelのデータをExcelCellInfoへ値を格納し直す
                For j As Integer = excelWrite.ExcelPaymentLineColumn.UPDATE_FLAG To excelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH12
                    ExcelCellInfo(j) = ExcelWork(1, j)
                Next

                '行チェック
                If CheckRowItem(i, ExcelCellInfo) = False Then
                    Exit For
                End If

                'Excelの値をデータテーブルにセット
                Dim row As DataRow = rtnTable.NewRow()
                For k As Integer = 1 To ExcelCellInfo.Length - 1

                    row.Item(COLNM & k) = excelWrite.changeDBNullToString(ExcelCellInfo(k))

                Next
                row.Item("ExcelRow") = i

                rtnTable.Rows.Add(row)

            Next

            Return rtnTable

        Catch ex As Exception
            Throw ex

        Finally
            ''Excelオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Function


    ''' <summary>
    ''' 機　能：Topacs用のサマリカテゴリを取得
    ''' 説　明：
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetTopacsSummaryCategory(ByVal ExcelCellInfo() As Object, _
                                              ByRef ClientValue As ConvertClientValueTable) As String

        ''初期化
        Dim rtnValue As String = ""
        GetTopacsSummaryCategory = rtnValue

        ''Topacs用のサマリカテゴリ取得に必要な情報をセット
        Dim brandInfo As OioFileManage.SummaryCategoryItem
        brandInfo.NewExist = ChangeNothingToBlank(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.NEW_EXIST)).ToString
        brandInfo.PatternCD = ChangeNothingToBlank(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.PATTERN_CD)).ToString
        brandInfo.PatternNM = ChangeNothingToBlank(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.PATTERN)).ToString
        brandInfo.Bu = ChangeNothingToBlank(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.BU)).ToString
        brandInfo.Brand = ChangeNothingToBlank(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.BRAND)).ToString
        brandInfo.SubBrand = ChangeNothingToBlank(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.BRAND_SUB)).ToString
        ''OP1の文言は出力しない。
        brandInfo.OP1 = ""
        brandInfo.OP2 = ChangeNothingToBlank(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.OP2)).ToString
        brandInfo.Size = ChangeNothingToBlank(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.BRAND_SIZE)).ToString
        brandInfo.NonSBO = ChangeNothingToBlank(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.NON_SBO)).ToString

        ''Topacs用のサマリカテゴリを取得
        Dim ofm As New OioFileManage
        rtnValue = ofm.GetSummaryCategory(brandInfo, ClientValue)

        Return rtnValue

    End Function

    ''' <summary>
    ''' 機　能：個別PSファイルにひもづかない個別詳細ファイルの削除
    ''' 説　明：
    ''' </summary>
    ''' <param name="xlOutDetailSheet"></param>
    ''' <param name="dtTOPACSDist"></param>
    ''' <remarks></remarks>
    Private Sub DelUnmachDetailRow(ByRef xlOutDetailSheet As Excel.Worksheet, _
                                   ByRef dtTOPACSDist As DataTable)

        Dim xlCell As Excel.Range
        Dim ExcelWork(1, excelWrite.ExcelPaymentLineDetailColumn.COST_INPUT_DATE) As Object
        Dim ExcelCellInfo(excelWrite.ExcelPaymentLineDetailColumn.COST_INPUT_DATE) As Object

        Try
            For i As Integer = excelWrite.EXCEL_DETAILLINEDATE_OUTROW To EXCEL_MAX_ROW

                ''1行取得
                xlCell = xlOutDetailSheet.Range("A" & i & ":" & "Z" & i)
                ExcelWork = xlCell.Value

                ''ExcelCellInfoへ値を格納し直す
                For j As Integer = 1 To excelWrite.ExcelPaymentLineDetailColumn.COST_INPUT_DATE
                    ExcelCellInfo(j) = ExcelWork(1, j)
                Next

                ''行チェック
                If CheckDetailEofLine(ExcelCellInfo) = False Then
                    Exit For
                End If

                ''ﾌｧｲﾙ名、ファイル内Suffix、ﾌｧｲﾙ名Suffixがマッチしているか判定
                Dim isMatchFileSuffix As Boolean = False
                Dim filter As New StringBuilder
                filter.Length = 0
                filter.Append(COLNM & excelWrite.ExcelPaymentLineColumn.FILE_NAME)
                filter.Append(CommonConstant.SQL_STR_EQUAL)
                filter.Append(StringEdit.EncloseSingleQuotation(ExcelCellInfo(excelWrite.ExcelPaymentLineDetailColumn.FILE_NAME)))
                filter.Append(CommonConstant.SQL_STR_AND)
                filter.Append(COLNM & excelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX)
                filter.Append(CommonConstant.SQL_STR_EQUAL)
                filter.Append(StringEdit.EncloseSingleQuotation(ExcelCellInfo(excelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX)))
                filter.Append(CommonConstant.SQL_STR_AND)
                filter.Append(COLNM & excelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR)
                filter.Append(CommonConstant.SQL_STR_EQUAL)
                filter.Append(StringEdit.EncloseSingleQuotation(ExcelCellInfo(excelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR)))

                ''ﾌｧｲﾙ名、ファイル内Suffix、ﾌｧｲﾙ名Suffixがマッチしない場合、明細削除
                If dtTOPACSDist.Select(filter.ToString).Length = 0 Then
                    xlCell = xlOutDetailSheet.Range((i).ToString() + ":" + (i).ToString())
                    xlCell.Delete()
                    i -= 1
                End If

            Next

            xlCell = xlOutDetailSheet.Range("W:Z")
            xlCell.Delete()

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' 機　能：Topacs起票データをデータテーブルへ格納する。
    ''' 説　明：
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetTopacsData(ByRef xlInTopacsPSSheet As Excel.Worksheet) As KihyoPSTable

        Dim rtnTable As New KihyoPSTable
        Dim drKihyoPS As DataRow

        ''Cell情報の定義
        Dim xlCell As Excel.Range = Nothing
        Dim xlInterior As Excel.Interior         '背景色の判定
        Dim ExcelCellInfo(188) As Object         'Excelのセル情報
        Dim ExcelWork(1, 188) As Object          'Excelのセル情報

        Try
            'TopacsのPSの編集に必要な情報をデータテーブルに格納する
            Dim intIndex As Integer
            For intIndex = EXCEL_PAYMENTLINEDATE_OUTROW To EXCEL_MAX_ROW

                ''1行取得
                xlCell = xlInTopacsPSSheet.Range("A" & intIndex & ":" & "IF" & intIndex)
                ExcelWork = xlCell.Value

                For intCnt As Integer = 1 To 188
                    ExcelCellInfo(intCnt) = ExcelWork(1, intCnt)
                Next

                ''Eof行チェック
                If CheckRowItemRow(intIndex, ExcelCellInfo) = False Then
                    Exit For
                End If

                drKihyoPS = rtnTable.NewRow()
                drKihyoPS("KIHYO_NO") = ExcelCellInfo(TopacsColumn.BRAND_AP_FORM)
                drKihyoPS("SINSEI_NO") = ExcelCellInfo(TopacsColumn.BRAND_AP_REQ)
                drKihyoPS("KIHYO_NAME") = ExcelCellInfo(TopacsColumn.BRAND_AP_NAME)
                drKihyoPS("CONTRACT") = ExcelCellInfo(TopacsColumn.CONTRACT)
                drKihyoPS("FILE_NAME") = ExcelCellInfo(TopacsColumn.FILE_NAME)
                drKihyoPS("FILE_NAME_SUFFIX") = ExcelCellInfo(TopacsColumn.FILE_NAME_SUFFIX)
                drKihyoPS("FILE_NAME_SUFFIX_INTR") = ExcelCellInfo(TopacsColumn.FILE_NAME_SUFFIX_INTR)
                drKihyoPS("LINE_NO") = ExcelCellInfo(TopacsColumn.LINE_NO)

                drKihyoPS("PATTERNCD") = ExcelCellInfo(TopacsColumn.PATTERNCD)
                drKihyoPS("PATTERN") = ExcelCellInfo(TopacsColumn.PATTERN)
                drKihyoPS("ITEM01") = ExcelCellInfo(TopacsColumn.PROD_ITEM01)
                drKihyoPS("LISTPRICE") = ExcelCellInfo(TopacsColumn.LIST_PRICE_TOTAL_REFLESH)
                drKihyoPS("DISCOUNTPRICE") = ExcelCellInfo(TopacsColumn.PRICE_QTY_IOC)

                ''集計行の判定に使用
                xlCell = xlInTopacsPSSheet.Range("A" & intIndex)
                xlInterior = xlCell.Interior
                drKihyoPS("COLOR") = xlInterior.Color
                rtnTable.Rows.Add(drKihyoPS)

            Next

            Return rtnTable

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlInterior, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Function


    ''' <summary>
    '''概    要：重複するLinnoの調査
    '''説    明：
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ChkDistinctLinno(ByVal DtOBAMAPS As DataTable,
                                      ByRef rtnMsg As String) As Boolean

        ''初期化
        ChkDistinctLinno = False

        ''以下の取込先PaymentのNoが重複しています。
        rtnMsg = FileReader.GetMessage("MSG_0320")

        ''重複したLinnoが存在するかチェックする。
        Dim lineNoList As New ArrayList
        For Each row As DataRow In DtOBAMAPS.Rows

            If lineNoList.IndexOf(excelWrite.changeDBNullToString(row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LINE_NO))) = -1 Then
                ''重複するデータ無しなら、List追加
                lineNoList.Add(excelWrite.changeDBNullToString(row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LINE_NO)))
            Else
                ''重複するデータ有りなら、警告メッセージ作成
                rtnMsg = rtnMsg &
                         vbCrLf &
                         " ・" & excelWrite.changeDBNullToString(row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LINE_NO)).ToString.PadLeft(8, "0")
                ChkDistinctLinno = True
            End If
        Next

    End Function

    ''' <summary>
    ''' 機能：ListPriceとIoc合計の集計金額の取得
    ''' 説明：※特殊フューチャーの金額を合計する。
    ''' </summary>
    ''' <param name="DtOBAMAPS"></param>
    ''' <param name="ExcelCellInfo"></param>
    ''' <param name="rtnListPrice"></param>
    ''' <param name="rtnPriceQtyIoc"></param>
    ''' <remarks></remarks>
    Private Sub GetSPFuterTotal(ByRef DtOBAMAPS As DataTable,
                                ByRef ExcelCellInfo() As Object,
                                ByRef rtnListPrice As String,
                                ByRef rtnPriceQtyIoc As String)

        ''初期化
        ''※集計対象金額がExcel上空白ならば、集計金額は空白をセットする。
        rtnListPrice = ""
        rtnPriceQtyIoc = ""

        ''個別PSの特殊フューチャー金額の合計値を取得する。
        Dim filter As New StringBuilder
        filter.Append(COLNM & excelWrite.ExcelPaymentLineColumn.PATTERN_CD)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(excelWrite.changeDBNullToString(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.PATTERN_CD))))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(COLNM & excelWrite.ExcelPaymentLineColumn.PATTERN)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(excelWrite.changeDBNullToString(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.PATTERN))))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(COLNM & excelWrite.ExcelPaymentLineColumn.FILE_NAME)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(excelWrite.changeDBNullToString(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.FILE_NAME))))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(COLNM & excelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(excelWrite.changeDBNullToString(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX))))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(COLNM & excelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(excelWrite.changeDBNullToString(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR))))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(COLNM & excelWrite.ExcelPaymentLineColumn.CONTRACT)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(excelWrite.changeDBNullToString(ExcelCellInfo(excelWrite.ExcelPaymentLineColumn.CONTRACT))))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(COLNM & excelWrite.ExcelPaymentLineColumn.VALID_FLAG)
        filter.Append(CommonConstant.SQL_STR_NOT)
        filter.Append(CommonConstant.SQL_STR_IN)
        filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        filter.Append(StringEdit.EncloseSingleQuotation("C"))
        filter.Append(CommonConstant.STR_COMMA)
        filter.Append(StringEdit.EncloseSingleQuotation("N"))
        filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(COLNM & excelWrite.ExcelPaymentLineColumn.QTY)
        filter.Append(CommonConstant.SQL_STR_NOT)
        filter.Append(CommonConstant.SQL_STR_LIKE)
        filter.Append(StringEdit.EncloseSingleQuotation("-*"))

        ''金額の集計処理
        For Each row As DataRow In DtOBAMAPS.Select(filter.ToString)

            ''ListPriceの集計
            If IsNumeric(excelWrite.changeDBNullToString(row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH))) Then
                rtnListPrice = CStr(CDec(changeDBNullToZero(rtnListPrice)) + CDec(row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH)))
            End If

            ''IOC合計の集計
            If IsNumeric(excelWrite.changeDBNullToString(row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC))) Then
                rtnPriceQtyIoc = CStr(CDec(changeDBNullToZero(rtnPriceQtyIoc)) + CDec(row.Item(COLNM & excelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC)))
            End If

        Next

    End Sub

    ''' <summary>
    ''' 機能：Nullチェック
    ''' 説明：値がNullの場合、0を返す
    ''' </summary>
    ''' <param name="Value"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Shared Function changeDBNullToZero(ByVal Value As Object) As String
        If IsNumeric(Value) Then
            Return Value.ToString
        Else
            Return "0"
        End If
    End Function


    ''' <summary>
    ''' 機能：申請書の情報を個別PSに書き込む
    ''' 説明：※特殊フューチャーを含むパターンの場合、特殊フューチャーの申請番号も反映する。
    ''' </summary>
    ''' <param name="Value"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Sub WriteSFuterDate(ByRef xlOutPSBookPSSheet As Excel.Worksheet, _
                                ByRef DtOBAMAPS As DataTable, _
                                ByRef dr As DataRow)

        Dim Cell As Excel.Range
        Try
            Dim filter As New StringBuilder
            filter.Append(COLNM & excelWrite.ExcelPaymentLineColumn.PATTERN_CD)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(excelWrite.changeDBNullToString(dr("PATTERNCD"))))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append(COLNM & excelWrite.ExcelPaymentLineColumn.PATTERN)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(excelWrite.changeDBNullToString(dr("PATTERN"))))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append(COLNM & excelWrite.ExcelPaymentLineColumn.FILE_NAME)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(excelWrite.changeDBNullToString(dr("FILE_NAME"))))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append(COLNM & excelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(excelWrite.changeDBNullToString(dr("FILE_NAME_SUFFIX"))))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append(COLNM & excelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(excelWrite.changeDBNullToString(dr("FILE_NAME_SUFFIX_INTR"))))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append(COLNM & excelWrite.ExcelPaymentLineColumn.CONTRACT)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(excelWrite.changeDBNullToString(dr("CONTRACT"))))

            ''コメント行は反映しない
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append(COLNM & excelWrite.ExcelPaymentLineColumn.VALID_FLAG)
            filter.Append(CommonConstant.SQL_STR_NOT)
            filter.Append(CommonConstant.SQL_STR_IN)
            filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            filter.Append(StringEdit.EncloseSingleQuotation("C"))
            filter.Append(CommonConstant.STR_COMMA)
            filter.Append(StringEdit.EncloseSingleQuotation("N"))
            filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append(COLNM & excelWrite.ExcelPaymentLineColumn.QTY)
            filter.Append(CommonConstant.SQL_STR_NOT)
            filter.Append(CommonConstant.SQL_STR_LIKE)
            filter.Append(StringEdit.EncloseSingleQuotation("-*"))

            ''特殊フューチャーを含むパターンCDのデータを更新する。
            ''※①申請書に紐づく特殊ﾌｭｰﾁｬｰと通常のBOX情報を全て取得する。
            ''※②上記のデータより、Excelの行位置を取得し、申請番号その他データを書き込む
            Dim excelRowNo As Integer
            For Each row As DataRow In DtOBAMAPS.Select(filter.ToString)

                ''Excel行番号を取得
                excelRowNo = CInt(row.Item("ExcelRow"))

                ''=====================================
                ''           個別PS情報の書込
                ''=====================================
                Cell = xlOutPSBookPSSheet.Cells(excelRowNo, excelWrite.ExcelPaymentLineColumn.BRAND_AP_FORM)
                Cell.Value = dr("KIHYO_NO")

                Cell = xlOutPSBookPSSheet.Cells(excelRowNo, excelWrite.ExcelPaymentLineColumn.BRAND_AP_REQ)
                Cell.Value = dr("SINSEI_NO")

                Cell = xlOutPSBookPSSheet.Cells(excelRowNo, excelWrite.ExcelPaymentLineColumn.TOPACS_CPNO)
                Cell.Value = dr("TOPACS_CPNO")

                Cell = xlOutPSBookPSSheet.Cells(excelRowNo, excelWrite.ExcelPaymentLineColumn.BRAND_AP_CONF)
                Cell.Value = dr("SYONIN_NO")
            Next

        Catch ex As Exception
            Throw ex

        Finally
            ''Excelオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(Cell, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub

    Private Function GetTopacsCPNO(ByVal CPNO As String) As String

        Dim strMsg As String = ""
        Dim blnRet As Boolean
        Dim wc As New WebDb.WebDbCommon
        Dim dt As New M_CONTRACT_BASETable

        GetTopacsCPNO = ""
        Try
            '認証設定
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW

            '契約基本情報取得
            blnRet = wc.GetContractBaseData(CPNO, dt, strMsg)
            If blnRet = False Then
                Throw New Exception(strMsg)
                Exit Function
            End If

            If dt.Rows.Count > 0 Then
                GetTopacsCPNO = dt.Rows(0).Item(M_CONTRACT_BASETable.COLUMN_NAME_TOPACS_CPNO).ToString
            End If

        Catch ex As Exception

        End Try

    End Function

    ''' <summary>
    ''' 機　能：詳細ｼｰﾄの外部参照ﾘﾝｸを削除する。
    ''' 説　明：※時間帯掛率/延長掛率/D%を値貼付にする。
    ''' </summary>
    Private Sub DetailFomulaClear(ByRef detailSheet As Excel.Worksheet)

        Const Col_CONTRACT As Integer = 1
        Const Col_FILE_NAME As Integer = 2
        Const Col_FILE_NAME_SUFFIX As Integer = 3
        Const Col_FILE_NAME_SUFFIX_INTR As Integer = 4
        Const Col_SEQ As Integer = 5

        Dim Eof As Integer
        Dim xlCell As Excel.Range
        Dim xlPasteCell As Excel.Range
        Dim tmpValue(,) As Object
        Dim area As String
        Try
            ''Eof行の判定
            For Idx As Integer = excelWrite.EXCEL_DETAILLINEDATE_OUTROW To 65536
                area = excelWrite.ChgExcelRowNumberToChar(excelWrite.ExcelPaymentLineDetailColumn.CONTRACT) & Idx & ":" & _
                       excelWrite.ChgExcelRowNumberToChar(excelWrite.ExcelPaymentLineDetailColumn.SEQ) & Idx
                xlCell = detailSheet.Range(area)
                tmpValue = xlCell.Value

                If excelWrite.changeDBNullToString(tmpValue(1, Col_CONTRACT)) = "" And _
                   excelWrite.changeDBNullToString(tmpValue(1, Col_FILE_NAME)) = "" And _
                   excelWrite.changeDBNullToString(tmpValue(1, Col_FILE_NAME_SUFFIX)) = "" And _
                   excelWrite.changeDBNullToString(tmpValue(1, Col_FILE_NAME_SUFFIX_INTR)) = "" And _
                   excelWrite.changeDBNullToString(tmpValue(1, Col_SEQ)) = "" Then

                    Eof = Idx - 1
                    Exit For
                End If
            Next

            ''0件の処理
            If Eof < excelWrite.EXCEL_DETAILLINEDATE_OUTROW Then
                Exit Sub
            End If

            ''2000行づつ値を貼付
            Dim dateCount As Integer         ''ﾃﾞｰﾀ件数
            Dim pasteMax As Integer          ''貼付数
            Dim pasteStr As Integer          ''貼付開始位置
            Dim pasteEnd As Integer          ''貼付終了位置
            Dim pasteArea As String          ''貼付範囲
            Dim pasteCount As Integer        ''貼付回数

            ''2001件目以降から、2回貼付
            pasteMax = 2000
            dateCount = Eof - excelWrite.EXCEL_DETAILLINEDATE_OUTROW + 1
            If dateCount = 1 Then
                pasteCount = 1
            Else
                pasteCount = Math.Truncate((dateCount - 1) / pasteMax) + 1
            End If

            ''値貼付
            For Idx As Integer = 1 To pasteCount
                pasteStr = excelWrite.EXCEL_DETAILLINEDATE_OUTROW + ((Idx - 1) * pasteMax)
                If Idx = pasteCount Then
                    pasteEnd = Eof
                Else
                    pasteEnd = excelWrite.EXCEL_DETAILLINEDATE_OUTROW + (Idx * pasteMax) - 1
                End If

                pasteArea = ExcelWrite.ChgExcelRowNumberToChar(ExcelWrite.ExcelPaymentLineDetailColumn.HOURLY_SCALE) & pasteStr & ":" & _
                            ExcelWrite.ChgExcelRowNumberToChar(ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE) & pasteEnd
                xlCell = detailSheet.Range(pasteArea)
                xlPasteCell = detailSheet.Range(pasteArea)
                xlPasteCell.Value = xlCell.Value
            Next

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPasteCell, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub


#End Region

End Class
