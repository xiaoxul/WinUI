﻿Imports System.IO
Imports System.Text
Imports System.Runtime
Imports Microsoft.Office.Interop
Imports Microsoft.VisualBasic.ControlChars
Imports MUSE.Utility.SharedClass
Imports MUSE.WinUI.OioBamaCommmon
Imports MUSE.WinUI.OioBamaCommmon.OioExcelManage
Imports MUSE.Controller
Imports MUSE.Utility.UserDataTable.Master
Imports MUSE.Utility
Imports System.Data.OleDb
Imports MUSE.Utility.OioBamaCommmon

'==========================================================================
'クラス名：OutputCsv
'概    要：Csv出力用クラス
'説    明：PaymentSheetを読込み、Csvファイルを出力する。
'作    成：[Ver1.0]  2010/11/17  
'==========================================================================
Public Class OutputCsv

#Region "定数"
    ''Csvの区切文字
    Private CSV_DELIMITA As String = ","

    ''ファイル情報
    Private Const PSheetNm As Integer = 2               ''PaymentSheet名
    Private Const KobetuSyousaiSheetNm As Integer = 2   ''個別詳細Sheet名
    Private Const WorkSheetNm As Integer = 1   ''ワークシート

    ''Csvのエンコーディング
    Private Const ENCODE_SHIFT_JIS As String = "shift-jis"
    Private EXPORTDIALOG_DEFULT_PATH As String = "../excel/"
    Private EXPORTCSV1_DEFULT_PATH As String = "../csv1/"
    Private EXPORTCSV2_DEFULT_PATH As String = "../csv2/"

    ''PaymentLine
    Private Const EXCEL_PAYMENTLINEDATE_OUTROW As Integer = 6

    ''個別詳細
    Private Const EXCEL_PAYMENTLINEDETAILDATE_OUTROW As Integer = 6

    ''PaymentLineValidationlog
    Private Const EXCEL_PAYMENTLINEVALIDATIONLOGDATE_OUTROW As Integer = 4

    ''個別詳細Validationlog
    Private Const EXCEL_PAYMENTLINEVALIDATIONLOGDETAILDATE_OUTROW As Integer = 4

    ''Payment Lineファイル　お客様情報タイトル    
    Private Const CSV_TITLE_CUSTINFO_CCPNO As String = "CPNO"
    Private Const CSV_TITLE_CUSTINFO_CUST_NAME As String = "CUST_NAME"
    Private Const CSV_TITLE_CUSTINFO_START_YEAR As String = "START_YEAR"
    Private Const CSV_TITLE_CUSTINFO_START_MONTH As String = "START_MONTH"
    Private Const CSV_TITLE_CUSTINFO_END_YEAR As String = "END_YEAR"
    Private Const CSV_TITLE_CUSTINFO_END_MONTH As String = "END_MONTH"
    Private Const CSV_TITLE_CUSTINFO_PA_ANV_DATE As String = "PA_ANV_DATE"
    Private Const CSV_TITLE_CUSTINFO_PA_LEVEL As String = "PA_LEVEL"
    Private Const CSV_TITLE_CUSTINFO_APPROVAL_DATE As String = "APPROVAL_DATE"
    Private Const CSV_TITLE_CUSTINFO_CONTRACT_DATE As String = "CONTRACT_DATE"

    ''Payment Lineファイル　Payment Line情報タイトル
    Private Const CSV_TITLE_PaymentLine_UPDATE_FLAG As String = "UPDATE_FLAG"
    Private Const CSV_TITLE_PaymentLine_LOCK_FLAG As String = "LOCK_FLAG"
    Private Const CSV_TITLE_PaymentLine_VALID_FLAG As String = "VALID_FLAG"
    Private Const CSV_TITLE_PaymentLine_LINE_NO As String = "LINE_NO"
    Private Const CSV_TITLE_PaymentLine_FILE_NAME As String = "FILE_NAME"
    Private Const CSV_TITLE_PaymentLine_FILE_NAME_SUFFIX As String = "FILE_NAME_SUFFIX"
    Private Const CSV_TITLE_PaymentLine_FILE_NAME_SUFFIX_INTR As String = "FILE_NAME_SUFFIX_INTR"
    Private Const CSV_TITLE_PaymentLine_CONTRACT As String = "CONTRACT"
    Private Const CSV_TITLE_PaymentLine_ST_COST As String = "ST_COST"
    Private Const CSV_TITLE_PaymentLine_ST_APPROVAL As String = "ST_APPROVAL"
    Private Const CSV_TITLE_PaymentLine_PROJ_ID As String = "PROJ_ID"
    Private Const CSV_TITLE_PaymentLine_CONTRACT_SEQ As String = "CONTRACT_SEQ"
    Private Const CSV_TITLE_PaymentLine_NEW_EXIST As String = "NEW_EXIST"
    Private Const CSV_TITLE_PaymentLine_INV_EXP As String = "INV_EXP"
    Private Const CSV_TITLE_PaymentLine_CUST_CATEGORY As String = "CUST_CATEGORY"
    Private Const CSV_TITLE_PaymentLine_LETTER_PLAN_DATE As String = "LETTER_PLAN_DATE"
    Private Const CSV_TITLE_PaymentLine_LETTER_ISSUE_DATE As String = "LETTER_ISSUE_DATE"
    Private Const CSV_TITLE_PaymentLine_LETTER_ACCEPT_DATE As String = "LETTER_ACCEPT_DATE"
    Private Const CSV_TITLE_PaymentLine_ORDER_DATE As String = "ORDER_DATE"
    Private Const CSV_TITLE_PaymentLine_LETTER_ID As String = "LETTER_ID"
    Private Const CSV_TITLE_PaymentLine_BILLING_CD As String = "BILLING_CD"
    Private Const CSV_TITLE_PaymentLine_BU As String = "BU"
    Private Const CSV_TITLE_PaymentLine_BRAND As String = "BRAND"
    Private Const CSV_TITLE_PaymentLine_SUM_CATEGORY As String = "SUM_CATEGORY"
    Private Const CSV_TITLE_PaymentLine_BRAND_SUB As String = "BRAND_SUB"
    Private Const CSV_TITLE_PaymentLine_OP1 As String = "OP1"
    Private Const CSV_TITLE_PaymentLine_OP2 As String = "OP2"
    Private Const CSV_TITLE_PaymentLine_SIZE As String = "SIZE"
    Private Const CSV_TITLE_PaymentLine_NON_SBO As String = "NON_SBO"
    Private Const CSV_TITLE_PaymentLine_ADDITION_ITEM As String = "ADDITION_ITEM"
    Private Const CSV_TITLE_PaymentLine_TOPACS_CPNO As String = "TOPACS_CPNO"
    Private Const CSV_TITLE_PaymentLine_BRAND_AP_FORM As String = "BRAND_AP_FORM"
    Private Const CSV_TITLE_PaymentLine_BRAND_AP_REQ As String = "BRAND_AP_REQ"
    Private Const CSV_TITLE_PaymentLine_BRAND_AP_CONF As String = "BRAND_AP_CONF"
    Private Const CSV_TITLE_PaymentLine_PATTERN_CD As String = "PATTERN_CD"
    Private Const CSV_TITLE_PaymentLine_PATTERN As String = "PATTERN"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM01 As String = "PROD_ITEM01"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM02 As String = "PROD_ITEM02"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM03 As String = "PROD_ITEM03"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM04 As String = "PROD_ITEM04"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM05 As String = "PROD_ITEM05"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM06 As String = "PROD_ITEM06"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM07 As String = "PROD_ITEM07"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM08 As String = "PROD_ITEM08"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM09 As String = "PROD_ITEM09"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM10 As String = "PROD_ITEM10"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM11 As String = "PROD_ITEM11"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM12 As String = "PROD_ITEM12"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM13 As String = "PROD_ITEM13"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM14 As String = "PROD_ITEM14"
    Private Const CSV_TITLE_PaymentLine_PROD_ITEM15 As String = "PROD_ITEM15"
    Private Const CSV_TITLE_PaymentLine_WD_ANNT_DATE As String = "WD_ANNT_DATE"
    Private Const CSV_TITLE_PaymentLine_WD_DATE As String = "WD_DATE"
    Private Const CSV_TITLE_PaymentLine_PRICE_CHG_DATE As String = "PRICE_CHG_DATE"
    Private Const CSV_TITLE_PaymentLine_QTY As String = "QTY"
    Private Const CSV_TITLE_PaymentLine_INST_YEAR As String = "INST_YEAR"
    Private Const CSV_TITLE_PaymentLine_INST_MONTH As String = "INST_MONTH"
    Private Const CSV_TITLE_PaymentLine_PAY_START_YEAR As String = "PAY_START_YEAR"
    Private Const CSV_TITLE_PaymentLine_PAY_START_MONTH As String = "PAY_START_MONTH"
    Private Const CSV_TITLE_PaymentLine_PAY_START_RMONTH As String = "PAY_START_RMONTH"
    Private Const CSV_TITLE_PaymentLine_PAY_END_YEAR As String = "PAY_END_YEAR"
    Private Const CSV_TITLE_PaymentLine_PAY_END_MONTH As String = "PAY_END_MONTH"
    Private Const CSV_TITLE_PaymentLine_PAY_END_RMONTH As String = "PAY_END_RMONTH"
    Private Const CSV_TITLE_PaymentLine_PAY_FLAG As String = "PAY_FLAG"
    Private Const CSV_TITLE_PaymentLine_BID_FLAG As String = "BID_FLAG"
    Private Const CSV_TITLE_PaymentLine_IGF_START_DATE As String = "IGF_START_DATE"
    Private Const CSV_TITLE_PaymentLine_IGF_END_DATE As String = "IGF_END_DATE"
    Private Const CSV_TITLE_PaymentLine_PAY_MONTHS As String = "PAY_MONTHS"
    Private Const CSV_TITLE_PaymentLine_VALID_CTRL As String = "VALID_CTRL"
    Private Const CSV_TITLE_PaymentLine_PAY_METHOD As String = "PAY_METHOD"
    Private Const CSV_TITLE_PaymentLine_IGF_APPLIED As String = "IGF_APPLIED"
    Private Const CSV_TITLE_PaymentLine_IGF_CONT_NO As String = "IGF_CONT_NO"
    Private Const CSV_TITLE_PaymentLine_IGF_CONT_TYPE As String = "IGF_CONT_TYPE"
    Private Const CSV_TITLE_PaymentLine_IGF_PROPERTY As String = "IGF_PROPERTY"
    Private Const CSV_TITLE_PaymentLine_IGF_RATE_BAUCOC As String = "IGF_RATE_BAUCOC"
    Private Const CSV_TITLE_PaymentLine_IGF_RATE_IOC As String = "IGF_RATE_IOC"
    Private Const CSV_TITLE_PaymentLine_LIST_PRICE_PROPOSAL As String = "LIST_PRICE_PROPOSAL"
    Private Const CSV_TITLE_PaymentLine_LIST_PRICE As String = "LIST_PRICE"
    Private Const CSV_TITLE_PaymentLine_T_LIST_PRICE_PROPOSAL As String = "LIST_PRICE_TOTAL_PROPOSAL"
    Private Const CSV_TITLE_PaymentLine_T_LIST_PRICE As String = "LIST_PRICE_TOTAL"
    Private Const CSV_TITLE_PaymentLine_DP_BAU As String = "DP_BAU"
    Private Const CSV_TITLE_PaymentLine_DP_COC As String = "DP_COC"
    Private Const CSV_TITLE_PaymentLine_DP_IOC As String = "DP_IOC"
    Private Const CSV_TITLE_PaymentLine_PRICE_UNIT_BAU As String = "PRICE_UNIT_BAU"
    Private Const CSV_TITLE_PaymentLine_PRICE_QTY_BAU As String = "PRICE_QTY_BAU"
    Private Const CSV_TITLE_PaymentLine_PRICE_UNIT_COC As String = "PRICE_UNIT_COC"
    Private Const CSV_TITLE_PaymentLine_PRICE_QTY_COC As String = "PRICE_QTY_COC"
    Private Const CSV_TITLE_PaymentLine_PRICE_UNIT_IOC As String = "PRICE_UNIT_IOC"
    Private Const CSV_TITLE_PaymentLine_PRICE_QTY_IOC As String = "PRICE_QTY_IOC"
    Private Const CSV_TITLE_PaymentLine_COST_RATE As String = "COST_RATE"
    Private Const CSV_TITLE_PaymentLine_COST As String = "COST"
    Private Const CSV_TITLE_PaymentLine_COST_TOTAL As String = "COST_TOTAL"
    Private Const CSV_TITLE_PaymentLine_COST_INPUT_DATE As String = "COST_INPUT_DATE"
    Private Const CSV_TITLE_PaymentLine_TAX_RATE As String = "TAX_RATE"
    Private Const CSV_TITLE_PaymentLine_PRICE_TO_SPLIT As String = "PRICE_TO_SPLIT"
    Private Const CSV_TITLE_PaymentLine_LIST_PRICE_TOTAL_IOC As String = "LIST_PRICE_TOTAL_IOC"
    Private Const CSV_TITLE_PaymentLine_PRICE_TOTAL_IOC As String = "PRICE_TOTAL_IOC"
    Private Const CSV_TITLE_PaymentLine_COST_TOTAL_IOC As String = "COST_TOTAL_IOC"
    Private Const CSV_TITLE_PaymentLine_PRICE_IGF_TOTAL As String = "PRICE_IGF_TOTAL"
    Private Const CSV_TITLE_PaymentLine_PRICE_CONT_TOTAL As String = "PRICE_CONT_TOTAL"
    Private Const CSV_TITLE_PaymentLine_PRICE_OO_CONT_TOTAL As String = "PRICE_OO_CONT_TOTAL"
    Private Const CSV_TITLE_PaymentLine_IGF_DIF_INTEREST As String = "IGF_DIF_INTEREST"

    ''個別詳細の列タイトル
    Private Const CSV_TITLE_CUSTINFO_UPDATE_FLAG As String = "UPDATE_FLAG"
    Private Const CSV_TITLE_CUSTINFO_LOCK_FLAG As String = "LOCK_FLAG"
    Private Const CSV_TITLE_CUSTINFO_VALID_FLAG As String = "VALID_FLAG"
    Private Const CSV_TITLE_CUSTINFO_CONTRACT As String = "CONTRACT"
    Private Const CSV_TITLE_CUSTINFO_FILE_NAME As String = "FILE_NAME"
    Private Const CSV_TITLE_CUSTINFO_FILE_NAME_SUFFIX As String = "FILE_NAME_SUFFIX"
    Private Const CSV_TITLE_CUSTINFO_FILE_NAME_SUFFIX_INTR As String = "FILE_NAME_SUFFIX_INTR"
    Private Const CSV_TITLE_CUSTINFO_SEQ As String = "SEQ"
    Private Const CSV_TITLE_CUSTINFO_IDENTITY_FLAG As String = "IDENTITY_FLAG"
    Private Const CSV_TITLE_CUSTINFO_PROD_NO As String = "PROD_NO"
    Private Const CSV_TITLE_CUSTINFO_PROD_NAME As String = "PROD_NAME"
    Private Const CSV_TITLE_CUSTINFO_WD_ANNT_DATE As String = "WD_ANNT_DATE"
    Private Const CSV_TITLE_CUSTINFO_WD_DATE As String = "WD_DATE"
    Private Const CSV_TITLE_CUSTINFO_PRICE_CHG_DATE As String = "PRICE_CHG_DATE"
    Private Const CSV_TITLE_CUSTINFO_MES_CATEGORY As String = "MES_CATEGORY"
    Private Const CSV_TITLE_CUSTINFO_MES_GROUP As String = "MES_GROUP"
    Private Const CSV_TITLE_CUSTINFO_SPECIAL_FEATURE As String = "SPECIAL_FEATURE"
    Private Const CSV_TITLE_CUSTINFO_QTY As String = "QTY"
    Private Const CSV_TITLE_CUSTINFO_LIST_PRICE_PROPSAL As String = "LIST_PRICE_PROPOSAL"
    Private Const CSV_TITLE_CUSTINFO_LIST_PRICE As String = "LIST_PRICE"
    Private Const CSV_TITLE_CUSTINFO_T_LIST_PRICE_PROPOSAL As String = "LIST_PRICE_TOTAL_PROPOSAL"
    Private Const CSV_TITLE_CUSTINFO_T_LIST_PRICE As String = "LIST_PRICE_TOTAL"
    Private Const CSV_TITLE_CUSTINFO_COST_RATE As String = "COST_RATE"
    Private Const CSV_TITLE_CUSTINFO_COST As String = "COST"
    Private Const CSV_TITLE_CUSTINFO_COST_TOTAL As String = "COST_TOTAL"
    Private Const CSV_TITLE_CUSTINFO_COST_INPUT_DATE As String = "COST_INPUT_DATE"
    Private Const CSV_TITLE_HWMA_LIST_PRICE As String = "HWMA_LIST_PRICE"                        ''単価(MMMC)          
    Private Const CSV_TITLE_HWMA_LIST_PRICE_TOTAL As String = "HWMA_LIST_PRICE_TOTAL"            ''合計(MMMC)
    Private Const CSV_TITLE_HOURLY_SCALE As String = "HOURLY_SCALE"                              ''時間帯掛け率
    Private Const CSV_TITLE_MA_EXT_SCALE As String = "MA_EXT_SCALE"                              ''延長掛率
    Private Const CSV_TITLE_DP As String = "DP"                                                  ''保守D%
    Private Const CSV_TITLE_HWMA_DP_LIST_PRICE As String = "HWMA_DP_LIST_PRICE"                  ''保守D%適用後_単価
    Private Const CSV_TITLE_HWMA_DP_LIST_PRICE_TOTAL As String = "HWMA_DP_LIST_PRICE_TOTAL"      ''保守D%適用後_合計
#End Region

#Region "構造体"
    ''お客様情報
    Private Structure CustInfo
        Dim Cpno As String
        Dim Custname As String
        Dim StartKeiyear As String
        Dim StartKeimonth As String
        Dim EndKeiyear As String
        Dim EndKeimonth As String
        Dim Panvdate As String
        Dim Palevel As String
        Dim Approvaldate As String
        Dim Contractdate As String
        Dim ExcelStart As String
    End Structure

    '案件情報
    Private Structure PlanInfo
        Dim CPNO As String
        Dim PLAN_NAME As String
        Dim LEVEL1 As String
        Dim LEVEL2 As String
        Dim LEVEL3 As String
        Dim LEVEL4 As String
        Dim ROW_NO_MAX As Integer
    End Structure

    'ファイル間チェック
    Private Structure FileKey
        Dim FileName As String
        Dim Suffix As String
        Dim InnerSuffix As String
    End Structure

#End Region

#Region "変数"
    ''Chis項目と、修正前の項目の対応表をセット
    Dim ChangePaymentLineColumn() As Integer
#End Region

#Region "パブリックメソッド"
    '--------------------------------------------------------
    'メソッド名：WriteCsv
    '概    要  ：CSVの出力処理
    '説    明  ：PaymentSheetを読込み、CSVファイルを出力する。
    '引    数  ：frm = CsvSampleのフォームオブジェクト
    '戻 り 値  ：なし
    '--------------------------------------------------------
    Public Function WriteCsv(ByVal strFileNamePayment As String,
                             ByVal strCustname As String,
                             ByVal strCpno As String,
                             ByVal strConstractNo As String, _
                             ByRef OutPutFilePath As String,
                             ByRef OutPutFileName As String,
                             ByVal createTime As String) As Integer

        ''Csvの出力データを格納
        Dim CustItem As CustInfo            'お客様情報
        Dim CsvTitleCustInfo As String      'Csvファイルへ出力するデータを格納
        Dim CsvCustInfo As String
        Dim CsvTitlePaymentLine As String
        Dim CsvPaymentLine As String

        ''インクリメント用のカウンタ
        Dim ExcelCount As Integer
        Dim intRowCount As Integer

        ''ファイルオブジェクト
        Dim CsvFileName As New StringBuilder
        Dim CsvWriter As StreamWriter = Nothing

        ''Excelオブジェクト
        Dim AppExcel As Excel.Application = Nothing
        Dim xlBooks As Excel.Workbooks = Nothing
        Dim WorkBook As Excel.Workbook = Nothing
        Dim xlSheets As Excel.Sheets = Nothing
        Dim WorkSheet As Excel.Worksheet = Nothing
        Dim xlCell As Excel.Range = Nothing

        ''Excelのセル情報
        Dim ExcelCellInfo(1, 358) As Object

        'エラーログ
        Dim OUTERR As New OutputErrorList

        Try

            ''Csv出力先フォルダの存在チェック
            Dim strTemp() As String
            strTemp = strFileNamePayment.Split("\")

            ''Csv出力先フォルダの存在チェック
            Dim Csv1FolderPath As String
            Dim Csv2FolderPath As String
            CreateCsvFolder(strFileNamePayment, Csv1FolderPath, Csv2FolderPath)

            ''ファイル名、契約順番等を取得
            Dim FileSeqNo As Integer
            Dim strOutFileName As String = Path.GetFileName(strFileNamePayment)
            If strConstractNo.Length > 0 Then
                FileSeqNo = Convert.ToInt32(strConstractNo)
            Else
                FileSeqNo = Convert.ToInt32(strOutFileName.Substring(19, 2))
            End If

            'エラーログ初期設定
            OUTERR.CpNo = strCpno
            OUTERR.ContractNo = FileSeqNo.ToString("000")

            ''Csv出力用オブジェクト作成
            Dim OutPutFile As String = ""
            OutPutFile = strOutFileName.Substring(0, 19) & _
                         createTime & ".csv"
            If OutPutFilePath = "" Then
                CsvWriter = New StreamWriter(Csv2FolderPath & "\" & OutPutFile,
                                             False,
                                             Encoding.GetEncoding(ENCODE_SHIFT_JIS))
                ''完了メッセージに表示するパス名をセット
                OutPutFilePath = Csv2FolderPath
            Else
                CsvWriter = New StreamWriter(OutPutFilePath & "\" & OutPutFile,
                                             False,
                                             Encoding.GetEncoding(ENCODE_SHIFT_JIS))
            End If

            ''完了メッセージに表示するファイル名をセット
            OutPutFileName = OutPutFile

            ''1行目：CSVファイル名　出力
            CsvWriter.WriteLine(Path.GetFileName(OutPutFile))

            ''2行目：お客様情報列タイトル　出力
            CsvTitleCustInfo = GetTitelCustInfo()
            CsvWriter.WriteLine(CsvTitleCustInfo)

            ''3行目：お客様情報 出力
            CustItem = GetTFrmCustInfo(strCpno, strCustname, strConstractNo, OutPutFile, OUTERR)
            If IsNothing(CustItem) Then
                Return WriteCsv
            End If
            CsvCustInfo = GetCsvCustInfo(CustItem)
            CsvWriter.WriteLine(CsvCustInfo)

            ''4行目：Payment Lineタイトル 取得
            CsvTitlePaymentLine = GetCsvTitlePaymentLine(CustItem.ExcelStart)
            CsvWriter.WriteLine(CsvTitlePaymentLine)

            ''エクセル用のオブジェクト初期設定
            AppExcel = New Excel.Application
            AppExcel.EnableEvents = False
            xlBooks = AppExcel.Workbooks
            WorkBook = xlBooks.Open(strFileNamePayment, ReadOnly:=True)
            AppExcel.EnableEvents = True
            xlSheets = WorkBook.Worksheets
            Dim excelWrite As New ExcelWrite
            WorkSheet = xlSheets.Item(excelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)

            ''Excelのオートフィルタを初期化
            Call excelWrite.CrearAutoFilter(WorkSheet)

            ''5行目：Payment Line 取得
            ''Export用：変換データテーブル
            Dim clientValueTable As DataTable
            clientValueTable = GetClientValueTable()

            ''※Chis項目と、修正前の項目との対応表をセットする。
            Call SetChangePaymentLineColumn()

            ExcelCount = 0                ''Excelのカウント数
            intRowCount = 0               ''データの出力数
            Dim i As Integer = EXCEL_PAYMENTLINEDATE_OUTROW
            Do
                CsvPaymentLine = ""

                ''Excel1行分の情報を取得
                xlCell = WorkSheet.Range(excelWrite.EXCEL_PAYMENT_LINE_RANGE.Replace("@", i.ToString))
                ExcelCellInfo = xlCell.Value

                ''ExcelのEOFの判定
                If ChkExcelEofLine(ExcelCellInfo) Then
                    Exit Do
                End If

                ''Excelの読込件数インクリメント
                ExcelCount = ExcelCount + 1

                ''100件毎に出力状況をログで出力する。
                If ExcelCount Mod 100 = 0 Then
                    OUTERR.OutExportErrorList(FileReader.GetMessage("MSG_0287").Replace("@", ExcelCount), "Export")
                End If

                ''出力対象のデータかどうか判定
                If CheackExportPaymentOutput(ExcelCellInfo) = False Then
                    i = i + 1
                    Continue Do
                End If

                ''CSV1行分のデータを書込
                CsvPaymentLine = GetPaymentLine(ExcelCellInfo, clientValueTable, False)
                CsvWriter.WriteLine(CsvPaymentLine)
                intRowCount = intRowCount + 1
                i = i + 1
            Loop

            ''6行目：EOF,PaymentLine行数の出力
            CsvWriter.WriteLine("EOF," & intRowCount)

            ''処理件数を返す。
            Return intRowCount

        Catch ex As Exception
            ''エラーメッセージ表示
            OUTERR.OutExportErrorList(ex.Message, "Export")
            Return -1

        Finally
            ''エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(WorkSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(WorkBook) = False Then
                WorkBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(WorkBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlBooks, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(AppExcel) = False Then
                AppExcel.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(AppExcel, ExcelObjRelease.OBJECT_NOTHING)

            ''ファイルオブジェクトの解放
            If IsNothing(CsvWriter) = False Then
                CsvWriter.Close()
            End If

            OUTERR = Nothing

            ''ガベージコレクトの起動
            GC.Collect()
        End Try

    End Function

    'Req.1710：エクスポート機能変更 2018/12 Str
    '--------------------------------------------------------
    'メソッド名：WriteCsv2
    '概    要  ：CSVの出力処理(Export/Import画面用)
    '説    明  ：PaymentSheetを読込み、CSVファイルを出力する。
    '引    数  ：frm = CsvSampleのフォームオブジェクト
    '戻 り 値  ：なし
    '--------------------------------------------------------
    Public Function WriteCsv2(ByVal strFileNamePayment As String,
                              ByVal strCustname As String,
                              ByVal strCpno As String,
                              ByVal strConstractNo As String, _
                              ByRef OutPutFilePath As String,
                              ByRef OutPutFileName As String,
                              ByVal createTime As String,
                              ByRef strErrMsg As String) As Integer

        ''Csvの出力データを格納
        Dim CustItem As CustInfo            'お客様情報
        Dim CsvTitleCustInfo As String      'Csvファイルへ出力するデータを格納
        Dim CsvCustInfo As String
        Dim CsvTitlePaymentLine As String
        Dim CsvPaymentLine As String

        ''インクリメント用のカウンタ
        Dim ExcelCount As Integer
        Dim intRowCount As Integer

        ''ファイルオブジェクト
        Dim CsvFileName As New StringBuilder
        Dim CsvWriter As StreamWriter = Nothing

        ''Excelオブジェクト
        Dim AppExcel As Excel.Application = Nothing
        Dim xlBooks As Excel.Workbooks = Nothing
        Dim WorkBook As Excel.Workbook = Nothing
        Dim xlSheets As Excel.Sheets = Nothing
        Dim WorkSheet As Excel.Worksheet = Nothing
        Dim xlCell As Excel.Range = Nothing

        ''Excelのセル情報
        Dim ExcelCellInfo(1, 358) As Object

        'エラーログ
        Dim OUTERR As New OutputErrorList

        Dim fMix As Boolean = False
        Dim fLocal As Boolean = False
        Dim fSvr As Boolean = False
        Dim lngRow As Long = 0
        Dim lngRowMax As Long = 0
        'Mdbの値を保持
        Dim MdbDataList(,) As Object = Nothing

        strErrMsg = ""

        Try

            ''Csv出力先フォルダの存在チェック
            Dim strTemp() As String
            strTemp = strFileNamePayment.Split("\")

            ''Csv出力先フォルダの存在チェック
            Dim Csv1FolderPath As String
            Dim Csv2FolderPath As String
            CreateCsvFolder(strFileNamePayment, Csv1FolderPath, Csv2FolderPath)

            ''ファイル名、契約順番等を取得
            Dim FileSeqNo As Integer
            Dim strOutFileName As String = Path.GetFileName(strFileNamePayment)
            If strConstractNo.Length > 0 Then
                FileSeqNo = Convert.ToInt32(strConstractNo)
            Else
                FileSeqNo = Convert.ToInt32(strOutFileName.Substring(19, 2))
            End If

            'エラーログ初期設定
            OUTERR.CpNo = strCpno
            OUTERR.ContractNo = FileSeqNo.ToString("000")

            ''Csv出力用オブジェクト作成
            Dim OutPutFile As String = ""
            OutPutFile = strOutFileName.Substring(0, 19) & _
                         createTime & ".csv"
            If OutPutFilePath = "" Then
                CsvWriter = New StreamWriter(Csv2FolderPath & "\" & OutPutFile,
                                             False,
                                             Encoding.GetEncoding(ENCODE_SHIFT_JIS))
                ''完了メッセージに表示するパス名をセット
                OutPutFilePath = Csv2FolderPath
            Else
                CsvWriter = New StreamWriter(OutPutFilePath & "\" & OutPutFile,
                                             False,
                                             Encoding.GetEncoding(ENCODE_SHIFT_JIS))
            End If

            ''完了メッセージに表示するファイル名をセット
            OutPutFileName = OutPutFile

            ''1行目：CSVファイル名　出力
            CsvWriter.WriteLine(Path.GetFileName(OutPutFile))

            ''2行目：お客様情報列タイトル　出力
            CsvTitleCustInfo = GetTitelCustInfo()
            CsvWriter.WriteLine(CsvTitleCustInfo)

            ''3行目：お客様情報 出力
            CustItem = GetTFrmCustInfo(strCpno, strCustname, strConstractNo, OutPutFile, OUTERR)
            If IsNothing(CustItem) Then
                Return WriteCsv2
            End If
            CsvCustInfo = GetCsvCustInfo(CustItem)
            CsvWriter.WriteLine(CsvCustInfo)

            ''4行目：Payment Lineタイトル 取得
            CsvTitlePaymentLine = GetCsvTitlePaymentLine(CustItem.ExcelStart)
            CsvWriter.WriteLine(CsvTitlePaymentLine)

            ''エクセル用のオブジェクト初期設定
            AppExcel = New Excel.Application
            AppExcel.EnableEvents = False
            xlBooks = AppExcel.Workbooks
            WorkBook = xlBooks.Open(strFileNamePayment, ReadOnly:=True)
            AppExcel.EnableEvents = True
            xlSheets = WorkBook.Worksheets
            Dim excelWrite As New ExcelWrite
            WorkSheet = xlSheets.Item(excelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)

            ''Excelのオートフィルタを初期化
            Call excelWrite.CrearAutoFilter(WorkSheet)

            ''5行目：Payment Line 取得
            ''Export用：変換データテーブル
            Dim clientValueTable As DataTable
            clientValueTable = GetClientValueTable()

            ''※Chis項目と、修正前の項目との対応表をセットする。
            Call SetChangePaymentLineColumn()

            'Paymentシート全体のステータスを取得する
            lngRowMax = WorkSheet.Cells(WorkSheet.Rows.Count, excelWrite.ExcelPaymentLineColumn.LINE_NO).End(Excel.XlDirection.xlUp).Row
            For lngRow = EXCEL_PAYMENTLINEDATE_OUTROW To lngRowMax
                If WorkSheet.Cells(lngRow, excelWrite.ExcelPaymentLineColumn.LOCK_FLAG).value = "" Then
                    fLocal = True
                End If
                If WorkSheet.Cells(lngRow, excelWrite.ExcelPaymentLineColumn.LOCK_FLAG).value = "C" Then
                    fSvr = True
                End If
                If fLocal = True And fSvr = True Then
                    '作成中と契約済みが混在している
                    fMix = True
                    'MDBから情報を取得
                    Call GetMDBDataInArray(MdbDataList)
                    Exit For
                End If
            Next

            ExcelCount = 0                ''Excelのカウント数
            intRowCount = 0               ''データの出力数
            Dim i As Integer = EXCEL_PAYMENTLINEDATE_OUTROW
            Do
                CsvPaymentLine = ""

                ''Excel1行分の情報を取得
                xlCell = WorkSheet.Range(excelWrite.EXCEL_PAYMENT_LINE_RANGE.Replace("@", i.ToString))
                ExcelCellInfo = xlCell.Value

                ''ExcelのEOFの判定
                If ChkExcelEofLine(ExcelCellInfo) Then
                    Exit Do
                End If

                ''Excelの読込件数インクリメント
                ExcelCount = ExcelCount + 1

                ''100件毎に出力状況をログで出力する。
                If ExcelCount Mod 100 = 0 Then
                    OUTERR.OutExportErrorList(FileReader.GetMessage("MSG_0287").Replace("@", ExcelCount), "Export")
                End If

                ''出力対象のデータかどうか判定
                If CheackExportPaymentOutput(ExcelCellInfo) = False Then
                    i = i + 1
                    Continue Do
                End If

                ''CSV1行分のデータを書込
                If ExcelCellInfo(1, excelWrite.ExcelPaymentLineColumn.LOCK_FLAG) = "C" And _
                    fMix = True Then
                    'MDB契約済み情報をセットする
                    CsvPaymentLine = GetMDBLine(ExcelCellInfo, MdbDataList)
                    If CsvPaymentLine = "" Then
                        '該当契約が見つからない
                        strErrMsg = FileReader.GetMessage("MSG_0565")
                        Exit Function
                    End If
                    CsvPaymentLine = GetPaymentLine(ExcelCellInfo, clientValueTable, False)
                Else
                    CsvPaymentLine = GetPaymentLine(ExcelCellInfo, clientValueTable, False)
                End If
                CsvWriter.WriteLine(CsvPaymentLine)
                intRowCount = intRowCount + 1
                i = i + 1
            Loop

            ''6行目：EOF,PaymentLine行数の出力
            CsvWriter.WriteLine("EOF," & intRowCount)

            ''処理件数を返す。
            Return intRowCount

        Catch ex As Exception
            ''エラーメッセージ表示
            OUTERR.OutExportErrorList(ex.Message, "Export")
            Return -1

        Finally
            ''エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(WorkSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(WorkBook) = False Then
                WorkBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(WorkBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlBooks, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(AppExcel) = False Then
                AppExcel.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(AppExcel, ExcelObjRelease.OBJECT_NOTHING)

            ''ファイルオブジェクトの解放
            If IsNothing(CsvWriter) = False Then
                CsvWriter.Close()
            End If

            OUTERR = Nothing

            ''ガベージコレクトの起動
            GC.Collect()
        End Try

    End Function
    'Req.1710：エクスポート機能変更 2018/12 End

    '--------------------------------------------------------
    '概    要  ：CSVの出力処理
    '説    明  ：個別詳細.Xlsを読込み、CSVファイルを出力する。
    '--------------------------------------------------------
    Public Function WriteKobetusyosaiCsv(ByVal strFileNameDetail As String,
                                         ByVal strCpno As String,
                                         ByVal strConstractNo As String, _
                                         ByRef OutPutFilePath As String,
                                         ByRef OutPutFileName As String,
                                         ByVal creatTime As String) As Integer

        ''Csvファイルへ出力するデータを格納
        Dim CsvTitleKobetuSyousai As String
        Dim CsvKobetuSyousai As String

        ''カウンタ
        Dim CsvCount As Integer
        Dim intRowCount As Integer

        ''ファイルオブジェクト
        Dim CsvFileName As New StringBuilder
        Dim CsvWriter As StreamWriter = Nothing

        ''Excelオブジェクト
        Dim AppExcel As Excel.Application = Nothing
        Dim xlBooks As Excel.Workbooks = Nothing
        Dim WorkBook As Excel.Workbook = Nothing
        Dim xlSheets As Excel.Sheets = Nothing
        Dim WorkSheet As Excel.Worksheet = Nothing
        Dim xlCell As Excel.Range = Nothing

        ''Excelのセル情報
        Dim ExcelCellInfo(1, 188) As Object

        'エラーログ
        Dim OUTERR As New OutputErrorList

        Try

            ''エクセル用のオブジェクト初期設定
            AppExcel = New Excel.Application
            AppExcel.EnableEvents = False
            xlBooks = AppExcel.Workbooks
            WorkBook = xlBooks.Open(strFileNameDetail, ReadOnly:=True)
            AppExcel.EnableEvents = True
            xlSheets = WorkBook.Worksheets
            WorkSheet = xlSheets.Item(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)

            Dim strTemp() As String
            strTemp = strFileNameDetail.Split("\")

            System.Environment.CurrentDirectory = Application.StartupPath
            Dim strOutPath As String = System.IO.Path.GetFullPath(EXPORTCSV2_DEFULT_PATH & strTemp(strTemp.Length - 2))
            ''Csv2出力先フォルダの存在チェック
            If Directory.Exists(strOutPath) = False Then
                'フォルダが存在しない場合は作成
                Directory.CreateDirectory(strOutPath)
            End If

            Dim strOutPath1 As String = System.IO.Path.GetFullPath(EXPORTCSV1_DEFULT_PATH & strTemp(strTemp.Length - 2))
            ''Csv1出力先フォルダの存在チェック
            If Directory.Exists(strOutPath1) = False Then
                'フォルダが存在しない場合は作成
                Directory.CreateDirectory(strOutPath1)
            End If

            ''Csv出力用オブジェクト作成
            Dim OutPutFile As String = ""

            'エラーログ初期設定
            OUTERR.CpNo = strCpno
            OUTERR.ContractNo = strConstractNo

            OutPutFile = Path.GetFileName(strFileNameDetail).Replace("Payment", "PaymentDetail")
            OutPutFile = OutPutFile.Substring(0, OutPutFile.Length - "yyyyMMdd_HHmmss.xlsm".Length) & creatTime & ".csv"
            If OutPutFilePath = "" Then
                CsvWriter = New StreamWriter(strOutPath & "\" & OutPutFile, False, Encoding.GetEncoding(ENCODE_SHIFT_JIS))
                ''出力完了メッセージの出力先をセット
                OutPutFilePath = strOutPath
            Else
                CsvWriter = New StreamWriter(OutPutFilePath & "\" & OutPutFile, False, Encoding.GetEncoding(ENCODE_SHIFT_JIS))
            End If

            ''出力完了メッセージの出力先をセット
            OutPutFileName = OutPutFile

            ''1行目：CSVファイル名　出力
            CsvWriter.WriteLine(Path.GetFileName(OutPutFile))

            ''2行目：CPNO　出力
            CsvWriter.WriteLine(Trim(strCpno))

            ''3行目：列タイトル　出力
            CsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai()
            CsvWriter.WriteLine(CsvTitleKobetuSyousai)

            ''4行目：KobetuSyousai 取得
            CsvCount = 0
            intRowCount = 0
            Dim i As Integer = 0
            i = ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW
            do 
                '書き込み可否フラグ　データにエラーがある場合は処理を止めず該当レコードをスキップする
                'これがFalseの場合そのデータをスキップする
                CsvKobetuSyousai = ""

                xlCell = WorkSheet.Range("A" & i & ":" & "AG" & i)
                ExcelCellInfo = xlCell.Value
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

                ''※Eof条件から、SEQをなくす。
                If (IsNothing(ExcelCellInfo(1, 4)) OrElse CStr(ExcelCellInfo(1, 4)) = "") _
                    AndAlso (IsNothing(ExcelCellInfo(1, 5)) OrElse CStr(ExcelCellInfo(1, 5)) = "") _
                    AndAlso (IsNothing(ExcelCellInfo(1, 10)) OrElse CStr(ExcelCellInfo(1, 10)) = "") Then
                    Exit Do
                End If

                If (IsNothing(ExcelCellInfo(1, 2)) OrElse _
                    ExcelCellInfo(1, 2).ToString <> "C") Then

                    CsvCount = CsvCount + 1
                    CsvKobetuSyousai = GetKobetuSyousai(ExcelCellInfo)
                    CsvWriter.WriteLine(CsvKobetuSyousai)
                End If

                intRowCount = intRowCount + 1

                ''100件毎に出力状況録を出力する。
                If intRowCount Mod 100 = 0 Then
                    OUTERR.OutExportErrorList(FileReader.GetMessage("MSG_0288").Replace("@", intRowCount), "Export")
                End If

                i = i + 1
            Loop

            ''5行目：EOF,PaymentLine行数の出力
            CsvWriter.WriteLine("EOF," & CsvCount)

            Return CsvCount

        Catch ex As Exception
            ''エラーメッセージ表示
            OUTERR.OutExportErrorList(ex.Message, "Export")
            Return -1

        Finally
            ''エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(WorkSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(WorkBook) = False Then
                WorkBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(WorkBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlBooks, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(AppExcel) = False Then
                AppExcel.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(AppExcel, ExcelObjRelease.OBJECT_NOTHING)

            ''ファイルオブジェクトの解放
            If IsNothing(CsvWriter) = False Then
                CsvWriter.Close()
            End If

            OUTERR = Nothing

            ''ガベージコレクトの起動
            GC.Collect()
        End Try

    End Function

#End Region

#Region "プライベートメソッド"
    '--------------------------------------------------------
    'メソッド名：GetFrmCustInfo
    '概    要  ：お客様情報列タイトルを取得
    '説    明  ：お客様情報列タイトルを取得。
    '引    数  ：なし
    '戻 り 値  ：GetFrmCustInfo = お客様情報(String)
    '--------------------------------------------------------
    Private Function GetTitelCustInfo() As String
        ''戻り値の初期化
        GetTitelCustInfo = ""

        GetTitelCustInfo = GetTitelCustInfo & CSV_TITLE_CUSTINFO_CCPNO & CSV_DELIMITA
        GetTitelCustInfo = GetTitelCustInfo & CSV_TITLE_CUSTINFO_CUST_NAME & CSV_DELIMITA
        GetTitelCustInfo = GetTitelCustInfo & CSV_TITLE_CUSTINFO_START_YEAR & CSV_DELIMITA
        GetTitelCustInfo = GetTitelCustInfo & CSV_TITLE_CUSTINFO_START_MONTH & CSV_DELIMITA
        GetTitelCustInfo = GetTitelCustInfo & CSV_TITLE_CUSTINFO_END_YEAR & CSV_DELIMITA
        GetTitelCustInfo = GetTitelCustInfo & CSV_TITLE_CUSTINFO_END_MONTH & CSV_DELIMITA
        GetTitelCustInfo = GetTitelCustInfo & CSV_TITLE_CUSTINFO_PA_ANV_DATE & CSV_DELIMITA
        GetTitelCustInfo = GetTitelCustInfo & CSV_TITLE_CUSTINFO_PA_LEVEL & CSV_DELIMITA
        GetTitelCustInfo = GetTitelCustInfo & CSV_TITLE_CUSTINFO_APPROVAL_DATE & CSV_DELIMITA

        ''最後の項目は区切文字不要
        GetTitelCustInfo = GetTitelCustInfo & CSV_TITLE_CUSTINFO_CONTRACT_DATE

        Return GetTitelCustInfo

    End Function

    '--------------------------------------------------------
    'メソッド名：GetTFrmCustInfo
    '概    要  ：お客様情報の取得
    '説    明  ：CsvSample画面からお客様情報を取得
    '引    数  ：Frm = CsvSample画面オブジェクト
    '戻 り 値  ：CustInfo = お客様情報(Structure)
    '--------------------------------------------------------
    Private Function GetTFrmCustInfo(ByVal strCpNo As String,
                                     ByVal strCustname As String,
                                     ByVal strConstractNo As String,
                                     ByVal strFileName As String,
                                     ByRef OUTERR As OutputErrorList) As CustInfo

        ''戻り値の初期化
        GetTFrmCustInfo = Nothing

        '契約情報取得
        Dim dt As New DataTable
        Dim cOleDbAcc As New OleDbAcc.OleDbCpnoBpt
        dt = cOleDbAcc.getContract(strCpNo)

        If dt.Rows.Count > 0 Then

            With GetTFrmCustInfo
                .Cpno = strCpNo
                .Custname = strCustname
                If IsDBNull(dt.Rows(0).Item("START_YEAR")) Then
                    .StartKeiyear = ""
                Else

                    .StartKeiyear = GetZeroFirstFormat(dt.Rows(0).Item("START_YEAR"))
                End If

                If IsDBNull(dt.Rows(0).Item("START_MONTH")) Then
                    .StartKeimonth = ""
                Else
                    .StartKeimonth = GetZeroFirstFormat(dt.Rows(0).Item("START_MONTH"))
                End If

                If IsDBNull(dt.Rows(0).Item("END_YEAR")) Then
                    .EndKeiyear = ""
                Else
                    .EndKeiyear = GetZeroFirstFormat(dt.Rows(0).Item("END_YEAR"))
                End If

                If IsDBNull(dt.Rows(0).Item("END_MONTH")) Then
                    .EndKeimonth = ""
                Else
                    .EndKeimonth = GetZeroFirstFormat(dt.Rows(0).Item("END_MONTH"))
                End If

                .Panvdate = "01"
                Dim strPaAnvDate As String = ExcelWrite.changeDBNullToString(dt.Rows(0).Item("PA_ANV_DATE"))
                If IsNumeric(strPaAnvDate) = True Then
                    If Integer.Parse(strPaAnvDate) >= 1 And Integer.Parse(strPaAnvDate) <= 12 Then
                        .Panvdate = GetZeroFirstFormat(strPaAnvDate)
                    End If
                End If

                If IsDBNull(dt.Rows(0).Item("PA_LEVEL")) Then
                    .Palevel = ""
                Else
                    ''ServerとClientでは、PALevelの表記が異なるため、変換
                    Dim paLevel As String
                    Select Case dt.Rows(0).Item("PA_LEVEL")
                        Case "PAX"
                            paLevel = "A"
                        Case "BL"
                            paLevel = "B"
                        Case "ED"
                            paLevel = "K"
                        Case Else
                            paLevel = dt.Rows(0).Item("PA_LEVEL")
                    End Select
                    .Palevel = paLevel
                End If

                'EXCEL_START
                If IsDBNull(dt.Rows(0).Item("EXCEL_START")) Then
                    .ExcelStart = ""
                Else
                    .ExcelStart = Convert.ToDateTime(dt.Rows(0).Item("EXCEL_START").ToString.Substring(0, 4) & "/" & _
                                                     dt.Rows(0).Item("EXCEL_START").ToString.Substring(4, 2) & "/01").ToString("yyyy/MM/dd")
                End If

                '価格承認依頼日、契約締結日は契約詳細情報テーブルから取得するのではなく、固定値を出力すること
                .Approvaldate = Convert.ToDateTime("2011/01/01")
                .Contractdate = Convert.ToDateTime("2011/01/01")

            End With

        Else
            OUTERR.OutputErrorList(FileReader.GetMessage("MSG_0256"), "Export")
            Return Nothing
        End If
        Return GetTFrmCustInfo

    End Function

    '--------------------------------------------------------
    'メソッド名：GetCsvCustInfo
    '概    要  ：お客様情報のセット
    '説    明  ：CustInfo構造体からお客様情報CSV行を取得
    '引    数  ：CustInfo = CustInfo(Structure)
    '戻 り 値  ：GetCsvCustInfo = お客様Csv情報(String)
    '--------------------------------------------------------
    Private Function GetCsvCustInfo(ByVal CustInfo As CustInfo) As String
        ''お客様Csv情報の初期化
        GetCsvCustInfo = ""

        With CustInfo
            GetCsvCustInfo = GetCsvCustInfo & .Cpno & CSV_DELIMITA
            GetCsvCustInfo = GetCsvCustInfo & .Custname & CSV_DELIMITA
            GetCsvCustInfo = GetCsvCustInfo & .StartKeiyear & CSV_DELIMITA
            GetCsvCustInfo = GetCsvCustInfo & .StartKeimonth & CSV_DELIMITA
            GetCsvCustInfo = GetCsvCustInfo & .EndKeiyear & CSV_DELIMITA
            GetCsvCustInfo = GetCsvCustInfo & .EndKeimonth & CSV_DELIMITA
            GetCsvCustInfo = GetCsvCustInfo & .Panvdate & CSV_DELIMITA
            GetCsvCustInfo = GetCsvCustInfo & .Palevel & CSV_DELIMITA
            GetCsvCustInfo = GetCsvCustInfo & .Approvaldate & CSV_DELIMITA
            ''最後の項目の為区切文字なし
            GetCsvCustInfo = GetCsvCustInfo & .Contractdate
        End With

        Return GetCsvCustInfo

    End Function

    '--------------------------------------------------------
    'メソッド名：GetCsvTitlePaymentLine
    '概    要  ：PaymentLineのCsvタイトルを取得
    '説    明  ：PaymentLineのCsvタイトルを取得
    '引    数  ：なし
    '戻 り 値  ：GetCsvTitlePaymentLine = PaymentLineのCsvタイトル(String)
    '--------------------------------------------------------
    Private Function GetCsvTitlePaymentLine(ByVal strExcelStart As String) As String

        Dim range(19) As String

        ''PaymentLineのCsvタイトル初期化
        GetCsvTitlePaymentLine = ""
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_UPDATE_FLAG & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_LOCK_FLAG & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_VALID_FLAG & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_LINE_NO & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_FILE_NAME & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_FILE_NAME_SUFFIX & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_FILE_NAME_SUFFIX_INTR & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_CONTRACT & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_ST_COST & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_ST_APPROVAL & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PROJ_ID & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_CONTRACT_SEQ & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_NEW_EXIST & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_INV_EXP & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_CUST_CATEGORY & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_LETTER_PLAN_DATE & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_LETTER_ISSUE_DATE & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_LETTER_ACCEPT_DATE & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_ORDER_DATE & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_LETTER_ID & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_BILLING_CD & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_BU & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_BRAND & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_SUM_CATEGORY & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_BRAND_SUB & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_OP1 & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_OP2 & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_SIZE & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_NON_SBO & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_ADDITION_ITEM & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_TOPACS_CPNO & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_BRAND_AP_FORM & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_BRAND_AP_REQ & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_BRAND_AP_CONF & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PATTERN_CD & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PATTERN & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PROD_ITEM01 & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PROD_ITEM02 & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PROD_ITEM03 & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PROD_ITEM04 & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PROD_ITEM05 & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PROD_ITEM06 & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PROD_ITEM07 & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PROD_ITEM08 & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PROD_ITEM09 & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PROD_ITEM10 & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PROD_ITEM11 & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PROD_ITEM12 & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PROD_ITEM13 & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PROD_ITEM14 & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PROD_ITEM15 & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_WD_ANNT_DATE & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_WD_DATE & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PRICE_CHG_DATE & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_QTY & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_INST_YEAR & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_INST_MONTH & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PAY_START_YEAR & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PAY_START_MONTH & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PAY_END_YEAR & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PAY_END_MONTH & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PAY_FLAG & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_BID_FLAG & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_IGF_START_DATE & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_IGF_END_DATE & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PAY_MONTHS & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_VALID_CTRL & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PAY_METHOD & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_IGF_APPLIED & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_IGF_CONT_NO & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_IGF_CONT_TYPE & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_IGF_PROPERTY & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_IGF_RATE_BAUCOC & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_IGF_RATE_IOC & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_LIST_PRICE_PROPOSAL & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_LIST_PRICE & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_T_LIST_PRICE_PROPOSAL & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_T_LIST_PRICE & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_DP_BAU & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_DP_COC & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_DP_IOC & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PRICE_UNIT_BAU & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PRICE_QTY_BAU & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PRICE_UNIT_COC & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PRICE_QTY_COC & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PRICE_UNIT_IOC & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PRICE_QTY_IOC & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_COST_RATE & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_COST & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_COST_TOTAL & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_COST_INPUT_DATE & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_TAX_RATE & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PRICE_TO_SPLIT & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_LIST_PRICE_TOTAL_IOC & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PRICE_TOTAL_IOC & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_COST_TOTAL_IOC & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PRICE_IGF_TOTAL & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PRICE_CONT_TOTAL & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_PRICE_OO_CONT_TOTAL & CSV_DELIMITA
        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & CSV_TITLE_PaymentLine_IGF_DIF_INTEREST & CSV_DELIMITA

        ''PaymentSheetからタイトルを取得
        If Not IsNothing(strExcelStart) AndAlso strExcelStart.Length > 0 Then
            Dim k As Integer = 0
            For k = 0 To UBound(range)
                'strExcelStart
                range(k) = Convert.ToDateTime(strExcelStart).AddYears(k).ToString("yyyy")
            Next

            ''IOC_YT　取得
            Dim i As Integer = 0
            For i = 0 To UBound(range)
                GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & "IOC_YT_" & CInt(range(i)) & CSV_DELIMITA
            Next

            ''IOC_yyyymm　取得
            For i = 0 To UBound(range)
                Dim j As Integer = 0
                For j = 1 To 12
                    If i = UBound(range) And j = 12 Then
                        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & "IOC_" & CInt(range(i)) & GetZeroFirstFormat(j)
                    Else
                        GetCsvTitlePaymentLine = GetCsvTitlePaymentLine & "IOC_" & CInt(range(i)) & GetZeroFirstFormat(j) & CSV_DELIMITA
                    End If
                Next
            Next
        End If

    End Function

    '--------------------------------------------------------
    'メソッド名：GetPaymentLine
    '概    要  ：Excelの行情報よりPaymentLineCsvを取得
    '説    明  ：Excelの行情報よりPaymentLineCsvを取得
    '引    数  ：ExcelCellInfo = Excel1行
    '戻 り 値  ：GetPaymentLine = PaymentLineCsv(String)
    '--------------------------------------------------------
    Public Function GetPaymentLine(ByVal ExcelCellInfo(,) As Object, ByVal ConvertClientValueData As ConvertClientValueTable, ByVal blnVer As Boolean) As String

        ''初期化
        Dim rtnValue As String = ""
        GetPaymentLine = rtnValue

        ''直接入力を名称変換後のパターンCD
        Dim chgPatternCd As String
        chgPatternCd = ExcelWrite.GetPatternCD(ExcelWrite.changeDBNullToString(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD)), ExcelWrite.changeDBNullToString(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PATTERN)))
        For i As Integer = 1 To UBound(ExcelCellInfo, 2)


            Dim changedItem As Boolean = False          ''項目の入替が発生したかどうか？
            If IsNothing(ExcelCellInfo(1, i)) = False Then

                ''============================================================
                ''                       データの整形
                ''============================================================
                Select Case i
                    'ﾊﾞｰｼﾞｮﾝｱｯﾌﾟ時、日付項目の場合、「yyyy-mm-dd」で出力
                    Case ExcelWrite.ExcelPaymentLineColumn.IGF_START_DATE,
                        ExcelWrite.ExcelPaymentLineColumn.IGF_END_DATE,
                        ExcelWrite.ExcelPaymentLineColumn.LETTER_ACCEPT_DATE,
                        ExcelWrite.ExcelPaymentLineColumn.ORDER_DATE,
                        ExcelWrite.ExcelPaymentLineColumn.WD_ANNT_DATE,
                        ExcelWrite.ExcelPaymentLineColumn.WD_DATE,
                        ExcelWrite.ExcelPaymentLineColumn.PRICE_CHG_DATE,
                        ExcelWrite.ExcelPaymentLineColumn.COST_INPUT_DATE
                        If blnVer = True Then
                            Call ChageDateExcelToDb2(ExcelCellInfo, i)
                        End If

                    Case ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03

                        ''PAかどうか判定
                        If chgPatternCd = CommonConstant.PATTERNCD_TYPE_PA Then

                            ''PAならば、PAレベルをサーバー出力用へ変換する。
                            ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM04) = GetPALevelName(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM04), ConvertClientValueData)
                        End If
                    Case ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM07

                        ''HWMAならば、QCOSｻｰﾋﾞｽ種類をサーバー出力用に出力する。
                        If chgPatternCd = CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_BOX Or _
                           chgPatternCd = CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_MES Or _
                           chgPatternCd = CommonConstant.PATTERNCD_TYPE_IBM_HWMA_QCOS Then

                            ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM07) = GetQcosWarrantytermName(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM07), ConvertClientValueData)

                        End If

                    Case ExcelWrite.ExcelPaymentLineColumn.IGF_RATE_IOC, _
                         ExcelWrite.ExcelPaymentLineColumn.DP_IOC, _
                         ExcelWrite.ExcelPaymentLineColumn.COST_RATE

                        ''%項目の整形

                        'Req.1710：エクスポート機能変更 2018/12 Str
                        If IsNumeric(ExcelCellInfo(1, i)) = True Then
                            'Req.1710：エクスポート機能変更 2018/12 End
                            ExcelCellInfo(1, i) = GetParsentFormat(ExcelCellInfo(1, i))
                            'Req.1710：エクスポート機能変更 2018/12 Str
                        End If
                        'Req.1710：エクスポート機能変更 2018/12 End

                End Select
            End If
        Next

        ''============================================================
        ''                       項目の位置を入れ替える。
        ''============================================================
        rtnValue = ChangePaymentItemIdx(chgPatternCd, ExcelCellInfo, blnVer)
        rtnValue = rtnValue.Replace(ChrW(160), " ")

        Return rtnValue

    End Function


    '--------------------------------------------------------
    '概    要  ：Chis対応用に、項目の位置を移動する。
    '説    明  ：
    '--------------------------------------------------------
    Private Function ChangePaymentItemIdx(ByVal chgPatternCd As String, _
                                          ByRef ExcelCellInfo(,) As Object, ByVal blnVer As Boolean) As String

        Dim intEnd As Integer
        Dim strWork As String
        Dim strInstYear As String = ""
        Dim strInstMonth As String = ""
        Dim strPayStartYear As String = ""
        Dim strPayStartMonth As String = ""
        Dim strPayEndYear As String = ""
        Dim strPayEndMonth As String = ""

        ''初期化
        Dim rtnValue As String = ""
        ChangePaymentItemIdx = rtnValue

        ''Chis項目でループする。
        If blnVer = False Then
            intEnd = ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20_MONTH12
        Else
            intEnd = ExcelWrite.CsvPaymentLineColumn.PRICE_DEFF_IGF
        End If
        For idx As Integer = ExcelWrite.CsvPaymentLineColumn.UPDATE_FLAG To intEnd

            Select Case idx
                Case ExcelWrite.CsvPaymentLineColumn.INV_EXP
                    rtnValue = rtnValue & SetDoubleQuote(CStr(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM16))) & CSV_DELIMITA
                Case ExcelWrite.CsvPaymentLineColumn.LETTER_ISSUE_DATE
                    rtnValue = rtnValue & SetDoubleQuote(CStr(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM17))) & CSV_DELIMITA
                Case ExcelWrite.CsvPaymentLineColumn.PROD_ITEM02
                    Select Case chgPatternCd
                        Case CommonConstant.PATTERNCD_TYPE_IBM_HW_AAS_BOX,
                             CommonConstant.PATTERNCD_TYPE_IBM_HW_AAS_MES,
                             CommonConstant.PATTERNCD_TYPE_IBM_HW_QCOS,
                             CommonConstant.PATTERNCD_TYPE_HWBrandSW_AAS,
                             CommonConstant.PATTERNCD_TYPE_HWBrandSW_QCOS,
                             CommonConstant.PATTERNCD_TYPE_HWBrandSWMA_AAS,
                             CommonConstant.PATTERNCD_TYPE_HWBrandSWMA_QCOS,
                             CommonConstant.PATTERNCD_TYPE_SWBrandSW,
                             CommonConstant.PATTERNCD_TYPE_SWBrandSWMA,
                             CommonConstant.PATTERNCD_TYPE_PA,
                             CommonConstant.PATTERNCD_TYPE_VLS,
                             CommonConstant.PATTERNCD_TYPE_HWServicePac,
                             CommonConstant.PATTERNCD_TYPE_SWServicePac,
                             CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_BOX,
                             CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_MES,
                             CommonConstant.PATTERNCD_TYPE_IBM_HWMA_QCOS,
                             CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_WarrantyOP,
                             CommonConstant.PATTERNCD_TYPE_IBM_HWMA_QCOS_WarrantyOP
                            rtnValue = rtnValue & SetDoubleQuote(CStr(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03))) & CSV_DELIMITA
                        Case Else
                            rtnValue = rtnValue & SetDoubleQuote(CStr(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02))) & CSV_DELIMITA
                    End Select

                Case ExcelWrite.CsvPaymentLineColumn.PROD_ITEM03
                    Select Case chgPatternCd
                        Case CommonConstant.PATTERNCD_TYPE_IBM_HW_AAS_BOX,
                             CommonConstant.PATTERNCD_TYPE_IBM_HW_AAS_MES,
                             CommonConstant.PATTERNCD_TYPE_IBM_HW_QCOS,
                             CommonConstant.PATTERNCD_TYPE_HWBrandSW_AAS,
                             CommonConstant.PATTERNCD_TYPE_HWBrandSW_QCOS,
                             CommonConstant.PATTERNCD_TYPE_HWBrandSWMA_AAS,
                             CommonConstant.PATTERNCD_TYPE_HWBrandSWMA_QCOS,
                             CommonConstant.PATTERNCD_TYPE_SWBrandSW,
                             CommonConstant.PATTERNCD_TYPE_SWBrandSWMA,
                             CommonConstant.PATTERNCD_TYPE_VLS,
                             CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_BOX,
                             CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_MES,
                             CommonConstant.PATTERNCD_TYPE_IBM_HWMA_QCOS,
                             CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_WarrantyOP,
                             CommonConstant.PATTERNCD_TYPE_IBM_HWMA_QCOS_WarrantyOP
                            rtnValue = rtnValue & SetDoubleQuote(CStr(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02))) & CSV_DELIMITA
                        Case CommonConstant.PATTERNCD_TYPE_PA,
                             CommonConstant.PATTERNCD_TYPE_HWServicePac,
                             CommonConstant.PATTERNCD_TYPE_SWServicePac
                            rtnValue = rtnValue & SetDoubleQuote(CStr(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM04))) & CSV_DELIMITA
                        Case Else
                            rtnValue = rtnValue & SetDoubleQuote(CStr(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03))) & CSV_DELIMITA
                    End Select

                Case ExcelWrite.CsvPaymentLineColumn.PROD_ITEM04

                    Select Case chgPatternCd
                        Case CommonConstant.PATTERNCD_TYPE_PA,
                             CommonConstant.PATTERNCD_TYPE_HWServicePac,
                             CommonConstant.PATTERNCD_TYPE_SWServicePac
                            rtnValue = rtnValue & SetDoubleQuote(CStr(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM05))) & CSV_DELIMITA
                        Case Else
                            rtnValue = rtnValue & SetDoubleQuote(CStr(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM04))) & CSV_DELIMITA
                    End Select

                Case ExcelWrite.CsvPaymentLineColumn.PROD_ITEM05
                    Select Case chgPatternCd
                        Case CommonConstant.PATTERNCD_TYPE_PA
                            rtnValue = rtnValue & SetDoubleQuote(CStr(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM06))) & CSV_DELIMITA
                        Case CommonConstant.PATTERNCD_TYPE_HWServicePac,
                             CommonConstant.PATTERNCD_TYPE_SWServicePac
                            rtnValue = rtnValue & SetDoubleQuote(CStr(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02))) & CSV_DELIMITA
                        Case Else
                            rtnValue = rtnValue & SetDoubleQuote(CStr(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM05))) & CSV_DELIMITA
                    End Select

                Case ExcelWrite.CsvPaymentLineColumn.PROD_ITEM06
                    Select Case chgPatternCd
                        Case CommonConstant.PATTERNCD_TYPE_PA
                            rtnValue = rtnValue & SetDoubleQuote(CStr(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02))) & CSV_DELIMITA
                        Case Else
                            rtnValue = rtnValue & SetDoubleQuote(CStr(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM06))) & CSV_DELIMITA
                    End Select

                    ''                      ▼以下、通常の項目入替処理
                    ''-------------------------------------------------------------------------------------                        

                Case ExcelWrite.CsvPaymentLineColumn.INST_YEAR
                    strWork = ExcelWrite.changeDBNullToString(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.INST_DATE))
                    If IsDate(strWork) = True Then
                        strInstYear = CDate(strWork).ToString("yyyy")
                        strInstMonth = CDate(strWork).ToString("MM")
                    Else
                        strInstYear = ""
                        strInstMonth = ""
                    End If
                    rtnValue = rtnValue & SetDoubleQuote(strInstYear) & CSV_DELIMITA
                Case ExcelWrite.CsvPaymentLineColumn.INST_MONTH
                    rtnValue = rtnValue & SetDoubleQuote(strInstMonth) & CSV_DELIMITA
                Case ExcelWrite.CsvPaymentLineColumn.PAY_START_YEAR
                    strWork = ExcelWrite.changeDBNullToString(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE))
                    If IsDate(strWork) = True Then
                        strPayStartYear = CDate(strWork).ToString("yyyy")
                        strPayStartMonth = CDate(strWork).ToString("MM")
                    Else
                        strPayStartYear = ""
                        strPayStartMonth = ""
                    End If
                    rtnValue = rtnValue & SetDoubleQuote(strPayStartYear) & CSV_DELIMITA
                Case ExcelWrite.CsvPaymentLineColumn.PAY_START_MONTH
                    rtnValue = rtnValue & SetDoubleQuote(strPayStartMonth) & CSV_DELIMITA
                Case ExcelWrite.CsvPaymentLineColumn.PAY_END_YEAR
                    strWork = ExcelWrite.changeDBNullToString(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE))
                    If IsDate(strWork) = True Then
                        strPayEndYear = CDate(strWork).ToString("yyyy")
                        strPayEndMonth = CDate(strWork).ToString("MM")
                    Else
                        strPayEndYear = ""
                        strPayEndMonth = ""
                    End If
                    rtnValue = rtnValue & SetDoubleQuote(strPayEndYear) & CSV_DELIMITA
                Case ExcelWrite.CsvPaymentLineColumn.PAY_END_MONTH
                    rtnValue = rtnValue & SetDoubleQuote(strPayEndMonth) & CSV_DELIMITA

                Case ExcelWrite.CsvPaymentLineColumn.IGF_RATE_BAUCOC
                    rtnValue = rtnValue & SetDoubleQuote(CStr(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM18))) & CSV_DELIMITA
                Case ExcelWrite.CsvPaymentLineColumn.DP_BAU
                    rtnValue = rtnValue & SetDoubleQuote(CStr(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM19))) & CSV_DELIMITA
                Case ExcelWrite.CsvPaymentLineColumn.DP_COC
                    rtnValue = rtnValue & SetDoubleQuote(CStr(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM20))) & CSV_DELIMITA
                Case ExcelWrite.CsvPaymentLineColumn.PRICE_UNIT_BAU
                    rtnValue = rtnValue & SetDoubleQuote(CStr(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC_VAL))) & CSV_DELIMITA
                Case ExcelWrite.CsvPaymentLineColumn.PRICE_QTY_BAU
                    rtnValue = rtnValue & SetDoubleQuote(CStr(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM22))) & CSV_DELIMITA
                Case ExcelWrite.CsvPaymentLineColumn.PRICE_UNIT_COC
                    rtnValue = rtnValue & SetDoubleQuote(CStr(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM23))) & CSV_DELIMITA
                Case ExcelWrite.CsvPaymentLineColumn.PRICE_QTY_COC
                    rtnValue = rtnValue & SetDoubleQuote(CStr(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM24))) & CSV_DELIMITA
                Case ExcelWrite.CsvPaymentLineColumn.TAX_RATE
                    rtnValue = rtnValue & SetDoubleQuote(CStr(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL))) & CSV_DELIMITA
                Case Else
                    If (idx >= ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR1 And idx <= ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20) Or
                        (idx >= ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR1_MONTH1 And idx <= ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20_MONTH12) Then
                        strWork = ExcelWrite.changeDBNullToZero(ExcelCellInfo(1, ChangePaymentLineColumn(idx)))
                        If idx <> ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20_MONTH12 Then
                            rtnValue = rtnValue & SetDoubleQuote(strWork) & CSV_DELIMITA
                        Else
                            rtnValue = rtnValue & SetDoubleQuote(strWork)
                        End If
                    Else
                        rtnValue = rtnValue & SetDoubleQuote(CStr(ExcelCellInfo(1, ChangePaymentLineColumn(idx)))) & CSV_DELIMITA
                    End If

            End Select
        Next
        Return rtnValue

    End Function


    '--------------------------------------------------------
    '概    要  ：Chis項目⇔修正前項目の対応表を作成
    '説    明  ：※Function関数だと、関数のオーバーヘッドがおおきいため、
    '　　　　　　　ﾌﾟﾗｲﾍﾞｰﾄ配列にｾｯﾄする。
    '--------------------------------------------------------
    Public Sub SetChangePaymentLineColumn()

        ''Chis項目との項目対応表を作成する。
        Dim setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20_MONTH12) As Integer

        setValue(ExcelWrite.CsvPaymentLineColumn.UPDATE_FLAG) = ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG                                     ''更新FLG                
        setValue(ExcelWrite.CsvPaymentLineColumn.LOCK_FLAG) = ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG                                         ''ﾛｯｸFLG
        setValue(ExcelWrite.CsvPaymentLineColumn.VALID_FLAG) = ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG                                       ''有効/無効
        setValue(ExcelWrite.CsvPaymentLineColumn.LINE_NO) = ExcelWrite.ExcelPaymentLineColumn.LINE_NO                                             ''NO
        setValue(ExcelWrite.CsvPaymentLineColumn.FILE_NAME) = ExcelWrite.ExcelPaymentLineColumn.FILE_NAME                                         ''ﾌｧｲﾙ名
        setValue(ExcelWrite.CsvPaymentLineColumn.FILE_NAME_SUFFIX) = ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX                           ''ﾌｧｲﾙ名Suffix
        setValue(ExcelWrite.CsvPaymentLineColumn.FILE_NAME_SUFFIX_INTR) = ExcelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR                 ''ﾌｧｲﾙ内Suffix
        setValue(ExcelWrite.CsvPaymentLineColumn.CONTRACT) = ExcelWrite.ExcelPaymentLineColumn.CONTRACT                                           ''契約順番
        setValue(ExcelWrite.CsvPaymentLineColumn.ST_COST) = ExcelWrite.ExcelPaymentLineColumn.ST_COST                                             ''COST_開示依頼
        setValue(ExcelWrite.CsvPaymentLineColumn.ST_APPROVAL) = ExcelWrite.ExcelPaymentLineColumn.ST_APPROVAL                                     ''価格承認_申請依頼
        setValue(ExcelWrite.CsvPaymentLineColumn.PROJ_ID) = ExcelWrite.ExcelPaymentLineColumn.PROJ_ID                                             ''案件番号
        setValue(ExcelWrite.CsvPaymentLineColumn.CONTRACT_SEQ) = ExcelWrite.ExcelPaymentLineColumn.CONTRACT_SEQ                                   ''契約通番
        setValue(ExcelWrite.CsvPaymentLineColumn.NEW_EXIST) = ExcelWrite.ExcelPaymentLineColumn.NEW_EXIST                                         ''新規/既存
        setValue(ExcelWrite.CsvPaymentLineColumn.INV_EXP) = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM16                                         ''投資/経費
        setValue(ExcelWrite.CsvPaymentLineColumn.CUST_CATEGORY) = ExcelWrite.ExcelPaymentLineColumn.CUST_CATEGORY                                 ''お客様集計ｶﾃｺﾞﾘ
        setValue(ExcelWrite.CsvPaymentLineColumn.LETTER_PLAN_DATE) = ExcelWrite.ExcelPaymentLineColumn.LETTER_PLAN_DATE                           ''実行通知書_発行予定日
        setValue(ExcelWrite.CsvPaymentLineColumn.LETTER_ISSUE_DATE) = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM17                               ''実行通知書_発行日
        setValue(ExcelWrite.CsvPaymentLineColumn.LETTER_ACCEPT_DATE) = ExcelWrite.ExcelPaymentLineColumn.LETTER_ACCEPT_DATE                       ''実行通知書_受領日
        setValue(ExcelWrite.CsvPaymentLineColumn.ORDER_DATE) = ExcelWrite.ExcelPaymentLineColumn.ORDER_DATE                                       ''発注完了日
        setValue(ExcelWrite.CsvPaymentLineColumn.LETTER_ID) = ExcelWrite.ExcelPaymentLineColumn.LETTER_ID                                         ''実行通知書番号
        setValue(ExcelWrite.CsvPaymentLineColumn.ORDERCODE) = ExcelWrite.ExcelPaymentLineColumn.ORDERCODE                                         ''請求コード
        setValue(ExcelWrite.CsvPaymentLineColumn.BU) = ExcelWrite.ExcelPaymentLineColumn.BU                                                       ''Brand Category_BU
        setValue(ExcelWrite.CsvPaymentLineColumn.BRAND) = ExcelWrite.ExcelPaymentLineColumn.BRAND                                                 ''Brand Category_Brand
        setValue(ExcelWrite.CsvPaymentLineColumn.SUM_CATEGORY) = ExcelWrite.ExcelPaymentLineColumn.SUM_CATEGORY                                   ''Brand Category_ｻﾏﾘｰ用ｶﾃｺﾞﾘ
        setValue(ExcelWrite.CsvPaymentLineColumn.BRAND_SUB) = ExcelWrite.ExcelPaymentLineColumn.BRAND_SUB                                         ''Brand Category_SubBrand
        setValue(ExcelWrite.CsvPaymentLineColumn.OP1) = ExcelWrite.ExcelPaymentLineColumn.OP1                                                     ''Brand Category_Option1
        setValue(ExcelWrite.CsvPaymentLineColumn.OP2) = ExcelWrite.ExcelPaymentLineColumn.OP2                                                     ''Brand Category_Option2
        setValue(ExcelWrite.CsvPaymentLineColumn.BRAND_SIZE) = ExcelWrite.ExcelPaymentLineColumn.BRAND_SIZE                                       ''Brand Category_Size
        setValue(ExcelWrite.CsvPaymentLineColumn.NON_SBO) = ExcelWrite.ExcelPaymentLineColumn.NON_SBO                                             ''Brand Category_SBO制限
        setValue(ExcelWrite.CsvPaymentLineColumn.POSTSCRIPT) = ExcelWrite.ExcelPaymentLineColumn.POSTSCRIPT                                       ''Brand Category_追記事項
        setValue(ExcelWrite.CsvPaymentLineColumn.TOPACS_CPNO) = ExcelWrite.ExcelPaymentLineColumn.TOPACS_CPNO                                     ''Brand承認_TOPACS CPNO
        setValue(ExcelWrite.CsvPaymentLineColumn.BRAND_AP_FORM) = ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_FORM                                 ''Brand承認_起票番号
        setValue(ExcelWrite.CsvPaymentLineColumn.BRAND_AP_REQ) = ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_REQ                                   ''Brand承認_申請番号
        setValue(ExcelWrite.CsvPaymentLineColumn.BRAND_AP_CONF) = ExcelWrite.ExcelPaymentLineColumn.BRAND_AP_CONF                                 ''Brand承認_承認番号
        setValue(ExcelWrite.CsvPaymentLineColumn.PATTERN_CD) = ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD                                       ''入力項目ﾊﾟﾀｰﾝ SEQ
        setValue(ExcelWrite.CsvPaymentLineColumn.PATTERN) = ExcelWrite.ExcelPaymentLineColumn.PATTERN                                             ''入力項目ﾊﾟﾀｰﾝ
        setValue(ExcelWrite.CsvPaymentLineColumn.PROD_ITEM01) = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01                                     ''ﾊﾟﾀｰﾝ別入力項目_項目１
        setValue(ExcelWrite.CsvPaymentLineColumn.PROD_ITEM02) = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02                                     ''ﾊﾟﾀｰﾝ別入力項目_項目２
        setValue(ExcelWrite.CsvPaymentLineColumn.PROD_ITEM03) = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03                                     ''ﾊﾟﾀｰﾝ別入力項目_項目３
        setValue(ExcelWrite.CsvPaymentLineColumn.PROD_ITEM04) = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM04                                     ''ﾊﾟﾀｰﾝ別入力項目_項目４
        setValue(ExcelWrite.CsvPaymentLineColumn.PROD_ITEM05) = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM05                                     ''ﾊﾟﾀｰﾝ別入力項目_項目５
        setValue(ExcelWrite.CsvPaymentLineColumn.PROD_ITEM06) = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM06                                     ''ﾊﾟﾀｰﾝ別入力項目_項目６
        setValue(ExcelWrite.CsvPaymentLineColumn.PROD_ITEM07) = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM07                                     ''ﾊﾟﾀｰﾝ別入力項目_項目７
        setValue(ExcelWrite.CsvPaymentLineColumn.PROD_ITEM08) = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM08                                     ''ﾊﾟﾀｰﾝ別入力項目_項目８
        setValue(ExcelWrite.CsvPaymentLineColumn.PROD_ITEM09) = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM09                                     ''ﾊﾟﾀｰﾝ別入力項目_項目９
        setValue(ExcelWrite.CsvPaymentLineColumn.PROD_ITEM10) = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10                                     ''ﾊﾟﾀｰﾝ別入力項目_項目１０
        setValue(ExcelWrite.CsvPaymentLineColumn.PROD_ITEM11) = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11                                     ''ﾊﾟﾀｰﾝ別入力項目_項目１１
        setValue(ExcelWrite.CsvPaymentLineColumn.PROD_ITEM12) = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12                                     ''ﾊﾟﾀｰﾝ別入力項目_項目１２
        setValue(ExcelWrite.CsvPaymentLineColumn.PROD_ITEM13) = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM13                                     ''ﾊﾟﾀｰﾝ別入力項目_項目１３
        setValue(ExcelWrite.CsvPaymentLineColumn.PROD_ITEM14) = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM14                                     ''ﾊﾟﾀｰﾝ別入力項目_項目１４
        setValue(ExcelWrite.CsvPaymentLineColumn.PROD_ITEM15) = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM15                                     ''ﾊﾟﾀｰﾝ別入力項目_項目１５
        setValue(ExcelWrite.CsvPaymentLineColumn.WD_ANNT_DATE) = ExcelWrite.ExcelPaymentLineColumn.WD_ANNT_DATE                                   ''製品･ｻｰﾋﾞｽ廃止発表日
        setValue(ExcelWrite.CsvPaymentLineColumn.WD_DATE) = ExcelWrite.ExcelPaymentLineColumn.WD_DATE                                             ''製品･ｻｰﾋﾞｽ廃止予定
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_CHG_DATE) = ExcelWrite.ExcelPaymentLineColumn.PRICE_CHG_DATE                               ''価格改定予定日
        setValue(ExcelWrite.CsvPaymentLineColumn.QTY) = ExcelWrite.ExcelPaymentLineColumn.QTY                                                     ''数量
        setValue(ExcelWrite.CsvPaymentLineColumn.INST_YEAR) = ExcelWrite.ExcelPaymentLineColumn.INST_DATE                                         ''導入_年
        setValue(ExcelWrite.CsvPaymentLineColumn.INST_MONTH) = ExcelWrite.ExcelPaymentLineColumn.INST_DATE + 1                                    ''導入_月
        setValue(ExcelWrite.CsvPaymentLineColumn.PAY_START_YEAR) = ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE                               ''請求開始_年
        setValue(ExcelWrite.CsvPaymentLineColumn.PAY_START_MONTH) = ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE + 1                          ''請求開始_月
        setValue(ExcelWrite.CsvPaymentLineColumn.PAY_END_YEAR) = ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE                                   ''請求終了_年
        setValue(ExcelWrite.CsvPaymentLineColumn.PAY_END_MONTH) = ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE + 1                              ''請求終了_月
        setValue(ExcelWrite.CsvPaymentLineColumn.IGF_START_DATE) = ExcelWrite.ExcelPaymentLineColumn.IGF_START_DATE                               ''IGF計算開始_年月
        setValue(ExcelWrite.CsvPaymentLineColumn.IGF_END_DATE) = ExcelWrite.ExcelPaymentLineColumn.IGF_END_DATE                                   ''IGF計算終了_年月
        setValue(ExcelWrite.CsvPaymentLineColumn.PAY_FLAG) = ExcelWrite.ExcelPaymentLineColumn.PAY_FLAG                                           ''Payment展開
        setValue(ExcelWrite.CsvPaymentLineColumn.BID_FLAG) = ExcelWrite.ExcelPaymentLineColumn.BID_FLAG                                           ''定額BID
        setValue(ExcelWrite.CsvPaymentLineColumn.PAY_MONTHS) = ExcelWrite.ExcelPaymentLineColumn.PAY_MONTHS                                       ''請求期間
        setValue(ExcelWrite.CsvPaymentLineColumn.PAY_VALIDATION) = ExcelWrite.ExcelPaymentLineColumn.PAY_VALIDATION                               ''Validation
        setValue(ExcelWrite.CsvPaymentLineColumn.PAY_METHOD) = ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD                                       ''支払方法
        setValue(ExcelWrite.CsvPaymentLineColumn.IGF_APPLIED) = ExcelWrite.ExcelPaymentLineColumn.IGF_APPLIED                                     ''IGF_対象
        setValue(ExcelWrite.CsvPaymentLineColumn.IGF_CONT_NO) = ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_NO                                     ''IGF契約番号
        setValue(ExcelWrite.CsvPaymentLineColumn.IGF_CONT_FORM) = ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_FORM                                 ''IGF契約形態
        setValue(ExcelWrite.CsvPaymentLineColumn.IGF_CONT_MANAGMENT) = ExcelWrite.ExcelPaymentLineColumn.IGF_CONT_MANAGMENT                       ''IGF契約物件管理
        setValue(ExcelWrite.CsvPaymentLineColumn.IGF_RATE_BAUCOC) = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM18                                 ''IGF_BAU&COC料率
        setValue(ExcelWrite.CsvPaymentLineColumn.IGF_RATE_IOC) = ExcelWrite.ExcelPaymentLineColumn.IGF_RATE_IOC                                   ''IGF_IOC料率
        setValue(ExcelWrite.CsvPaymentLineColumn.LIST_PRICE_PROPOSAL) = ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL                     ''Listprice(単価)_提案時
        setValue(ExcelWrite.CsvPaymentLineColumn.LIST_PRICE_REFLESH) = ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH                       ''Listprice(単価)_ﾘﾌﾚｯｼｭ後
        setValue(ExcelWrite.CsvPaymentLineColumn.LIST_PRICE_TOTAL_PROPOSAL) = ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_PROPOSAL         ''Listprice(合計)_提案時	
        setValue(ExcelWrite.CsvPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH) = ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH           ''Listprice(合計)_ﾘﾌﾚｯｼｭ後	
        setValue(ExcelWrite.CsvPaymentLineColumn.DP_BAU) = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM19                                          ''BAU D%
        setValue(ExcelWrite.CsvPaymentLineColumn.DP_COC) = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM20                                          ''COC D%
        setValue(ExcelWrite.CsvPaymentLineColumn.DP_IOC) = ExcelWrite.ExcelPaymentLineColumn.DP_IOC                                               ''IOC D%
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_UNIT_BAU) = ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC_VAL                           ''BAU単価
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_QTY_BAU) = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM22                                   ''BAU合計
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_UNIT_COC) = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM23                                  ''COC単価
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_QTY_COC) = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM24                                   ''COC合計
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_UNIT_IOC) = ExcelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC                               ''IOC単価
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_QTY_IOC) = ExcelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC                                 ''IOC合計
        setValue(ExcelWrite.CsvPaymentLineColumn.COST_RATE) = ExcelWrite.ExcelPaymentLineColumn.COST_RATE                                         ''COST %
        setValue(ExcelWrite.CsvPaymentLineColumn.COST) = ExcelWrite.ExcelPaymentLineColumn.COST                                                   ''COST_単価
        setValue(ExcelWrite.CsvPaymentLineColumn.COST_TOTAL) = ExcelWrite.ExcelPaymentLineColumn.COST_TOTAL                                       ''COST_合計
        setValue(ExcelWrite.CsvPaymentLineColumn.COST_INPUT_DATE) = ExcelWrite.ExcelPaymentLineColumn.COST_INPUT_DATE                             ''COST_入力日
        setValue(ExcelWrite.CsvPaymentLineColumn.TAX_RATE) = ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL                                   ''消費税率
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_TO_SPLIT) = ExcelWrite.ExcelPaymentLineColumn.PRICE_TO_SPLIT                               ''展開金額
        setValue(ExcelWrite.CsvPaymentLineColumn.LIST_PRICE_TOTAL_IOC) = ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_IOC                   ''Listprice_期間合計
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_TOTAL_IOC) = ExcelWrite.ExcelPaymentLineColumn.PRICE_TOTAL_IOC                             ''D%適用後_期間合計
        setValue(ExcelWrite.CsvPaymentLineColumn.COST_TOTAL_IOC) = ExcelWrite.ExcelPaymentLineColumn.COST_TOTAL_IOC                               ''COST_期間合計
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_TOTAL_IGF) = ExcelWrite.ExcelPaymentLineColumn.PRICE_TOTAL_IGF                             ''IGF適用後 期間合計
        setValue(ExcelWrite.CsvPaymentLineColumn.CONTRACT_IN) = ExcelWrite.ExcelPaymentLineColumn.CONTRACT_IN                                     ''契約期間内
        setValue(ExcelWrite.CsvPaymentLineColumn.CONTRACT_OUT) = ExcelWrite.ExcelPaymentLineColumn.CONTRACT_OUT                                   ''契約期間外
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_DEFF_IGF) = ExcelWrite.ExcelPaymentLineColumn.PRICE_DEFF_IGF                               ''IGF金利(差額)
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR1) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1                                     ''年度情報1
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR2) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2                                     ''年度情報2
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR3) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3                                     ''年度情報3
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR4) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4                                     ''年度情報4
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR5) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5                                     ''年度情報5
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR6) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6                                     ''年度情報6
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR7) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7                                     ''年度情報7
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR8) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8                                     ''年度情報8
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR9) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9                                     ''年度情報9
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR10) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10                                   ''年度情報10
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR11) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11                                   ''年度情報11
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR12) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12                                   ''年度情報12
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR13) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13                                   ''年度情報13
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR14) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14                                   ''年度情報14
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR15) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15                                   ''年度情報15
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR16) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16                                   ''年度情報16
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR17) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17                                   ''年度情報17
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR18) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18                                   ''年度情報18
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR19) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19                                   ''年度情報19
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20                                   ''年度情報20
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR1_MONTH1) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1                       ''年度1_月度情報1
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR1_MONTH2) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH2                       ''年度1_月度情報2
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR1_MONTH3) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH3                       ''年度1_月度情報3
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR1_MONTH4) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH4                       ''年度1_月度情報4
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR1_MONTH5) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH5                       ''年度1_月度情報5
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR1_MONTH6) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH6                       ''年度1_月度情報6
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR1_MONTH7) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH7                       ''年度1_月度情報7
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR1_MONTH8) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH8                       ''年度1_月度情報8
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR1_MONTH9) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH9                       ''年度1_月度情報9
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR1_MONTH10) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH10                     ''年度1_月度情報10
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR1_MONTH11) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH11                     ''年度1_月度情報11
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR1_MONTH12) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH12                     ''年度1_月度情報12
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR2_MONTH1) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH1                       ''年度2_月度情報1
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR2_MONTH2) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH2                       ''年度2_月度情報2
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR2_MONTH3) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH3                       ''年度2_月度情報3
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR2_MONTH4) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH4                       ''年度2_月度情報4
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR2_MONTH5) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH5                       ''年度2_月度情報5
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR2_MONTH6) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH6                       ''年度2_月度情報6
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR2_MONTH7) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH7                       ''年度2_月度情報7
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR2_MONTH8) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH8                       ''年度2_月度情報8
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR2_MONTH9) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH9                       ''年度2_月度情報9
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR2_MONTH10) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH10                     ''年度2_月度情報10
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR2_MONTH11) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH11                     ''年度2_月度情報11
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR2_MONTH12) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR2_MONTH12                     ''年度2_月度情報12
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR3_MONTH1) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH1                       ''年度3_月度情報1
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR3_MONTH2) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH2                       ''年度3_月度情報2
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR3_MONTH3) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH3                       ''年度3_月度情報3
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR3_MONTH4) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH4                       ''年度3_月度情報4
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR3_MONTH5) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH5                       ''年度3_月度情報5
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR3_MONTH6) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH6                       ''年度3_月度情報6
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR3_MONTH7) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH7                       ''年度3_月度情報7
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR3_MONTH8) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH8                       ''年度3_月度情報8
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR3_MONTH9) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH9                       ''年度3_月度情報9
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR3_MONTH10) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH10                     ''年度3_月度情報10
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR3_MONTH11) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH11                     ''年度3_月度情報11
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR3_MONTH12) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR3_MONTH12                     ''年度3_月度情報12
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR4_MONTH1) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH1                       ''年度4_月度情報1
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR4_MONTH2) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH2                       ''年度4_月度情報2
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR4_MONTH3) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH3                       ''年度4_月度情報3
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR4_MONTH4) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH4                       ''年度4_月度情報4
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR4_MONTH5) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH5                       ''年度4_月度情報5
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR4_MONTH6) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH6                       ''年度4_月度情報6
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR4_MONTH7) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH7                       ''年度4_月度情報7
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR4_MONTH8) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH8                       ''年度4_月度情報8
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR4_MONTH9) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH9                       ''年度4_月度情報9
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR4_MONTH10) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH10                     ''年度4_月度情報10
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR4_MONTH11) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH11                     ''年度4_月度情報11
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR4_MONTH12) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR4_MONTH12                     ''年度4_月度情報12
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR5_MONTH1) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH1                       ''年度5_月度情報1
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR5_MONTH2) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH2                       ''年度5_月度情報2
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR5_MONTH3) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH3                       ''年度5_月度情報3
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR5_MONTH4) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH4                       ''年度5_月度情報4
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR5_MONTH5) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH5                       ''年度5_月度情報5
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR5_MONTH6) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH6                       ''年度5_月度情報6
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR5_MONTH7) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH7                       ''年度5_月度情報7
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR5_MONTH8) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH8                       ''年度5_月度情報8
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR5_MONTH9) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH9                       ''年度5_月度情報9
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR5_MONTH10) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH10                     ''年度5_月度情報10
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR5_MONTH11) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH11                     ''年度5_月度情報11
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR5_MONTH12) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR5_MONTH12                     ''年度5_月度情報12
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR6_MONTH1) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH1                       ''年度6_月度情報1
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR6_MONTH2) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH2                       ''年度6_月度情報2
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR6_MONTH3) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH3                       ''年度6_月度情報3
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR6_MONTH4) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH4                       ''年度6_月度情報4
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR6_MONTH5) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH5                       ''年度6_月度情報5
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR6_MONTH6) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH6                       ''年度6_月度情報6
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR6_MONTH7) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH7                       ''年度6_月度情報7
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR6_MONTH8) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH8                       ''年度6_月度情報8
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR6_MONTH9) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH9                       ''年度6_月度情報9
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR6_MONTH10) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH10                     ''年度6_月度情報10
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR6_MONTH11) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH11                     ''年度6_月度情報11
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR6_MONTH12) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR6_MONTH12                     ''年度6_月度情報12
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR7_MONTH1) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH1                       ''年度7_月度情報1
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR7_MONTH2) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH2                       ''年度7_月度情報2
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR7_MONTH3) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH3                       ''年度7_月度情報3
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR7_MONTH4) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH4                       ''年度7_月度情報4
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR7_MONTH5) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH5                       ''年度7_月度情報5
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR7_MONTH6) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH6                       ''年度7_月度情報6
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR7_MONTH7) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH7                       ''年度7_月度情報7
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR7_MONTH8) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH8                       ''年度7_月度情報8
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR7_MONTH9) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH9                       ''年度7_月度情報9
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR7_MONTH10) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH10                     ''年度7_月度情報10
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR7_MONTH11) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH11                     ''年度7_月度情報11
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR7_MONTH12) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR7_MONTH12                     ''年度7_月度情報12
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR8_MONTH1) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH1                       ''年度8_月度情報1
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR8_MONTH2) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH2                       ''年度8_月度情報2
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR8_MONTH3) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH3                       ''年度8_月度情報3
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR8_MONTH4) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH4                       ''年度8_月度情報4
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR8_MONTH5) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH5                       ''年度8_月度情報5
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR8_MONTH6) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH6                       ''年度8_月度情報6
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR8_MONTH7) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH7                       ''年度8_月度情報7
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR8_MONTH8) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH8                       ''年度8_月度情報8
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR8_MONTH9) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH9                       ''年度8_月度情報9
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR8_MONTH10) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH10                     ''年度8_月度情報10
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR8_MONTH11) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH11                     ''年度8_月度情報11
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR8_MONTH12) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR8_MONTH12                     ''年度8_月度情報12
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR9_MONTH1) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH1                       ''年度9_月度情報1
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR9_MONTH2) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH2                       ''年度9_月度情報2
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR9_MONTH3) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH3                       ''年度9_月度情報3
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR9_MONTH4) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH4                       ''年度9_月度情報4
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR9_MONTH5) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH5                       ''年度9_月度情報5
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR9_MONTH6) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH6                       ''年度9_月度情報6
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR9_MONTH7) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH7                       ''年度9_月度情報7
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR9_MONTH8) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH8                       ''年度9_月度情報8
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR9_MONTH9) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH9                       ''年度9_月度情報9
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR9_MONTH10) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH10                     ''年度9_月度情報10
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR9_MONTH11) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH11                     ''年度9_月度情報11
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR9_MONTH12) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR9_MONTH12                     ''年度9_月度情報12
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR10_MONTH1) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH1                     ''年度10_月度情報1
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR10_MONTH2) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH2                     ''年度10_月度情報2
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR10_MONTH3) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH3                     ''年度10_月度情報3
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR10_MONTH4) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH4                     ''年度10_月度情報4
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR10_MONTH5) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH5                     ''年度10_月度情報5
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR10_MONTH6) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH6                     ''年度10_月度情報6
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR10_MONTH7) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH7                     ''年度10_月度情報7
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR10_MONTH8) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH8                     ''年度10_月度情報8
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR10_MONTH9) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH9                     ''年度10_月度情報9
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR10_MONTH10) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH10                   ''年度10_月度情報10
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR10_MONTH11) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH11                   ''年度10_月度情報11
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR10_MONTH12) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH12                   ''年度10_月度情報12
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR11_MONTH1) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH1                     ''年度11_月度情報1
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR11_MONTH2) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH2                     ''年度11_月度情報2
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR11_MONTH3) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH3                     ''年度11_月度情報3
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR11_MONTH4) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH4                     ''年度11_月度情報4
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR11_MONTH5) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH5                     ''年度11_月度情報5
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR11_MONTH6) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH6                     ''年度11_月度情報6
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR11_MONTH7) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH7                     ''年度11_月度情報7
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR11_MONTH8) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH8                     ''年度11_月度情報8
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR11_MONTH9) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH9                     ''年度11_月度情報9
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR11_MONTH10) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH10                   ''年度11_月度情報10
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR11_MONTH11) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH11                   ''年度11_月度情報11
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR11_MONTH12) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH12                   ''年度11_月度情報12
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR12_MONTH1) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH1                     ''年度12_月度情報1
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR12_MONTH2) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH2                     ''年度12_月度情報2
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR12_MONTH3) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH3                     ''年度12_月度情報3
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR12_MONTH4) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH4                     ''年度12_月度情報4
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR12_MONTH5) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH5                     ''年度12_月度情報5
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR12_MONTH6) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH6                     ''年度12_月度情報6
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR12_MONTH7) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH7                     ''年度12_月度情報7
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR12_MONTH8) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH8                     ''年度12_月度情報8
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR12_MONTH9) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH9                     ''年度12_月度情報9
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR12_MONTH10) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH10                   ''年度12_月度情報10
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR12_MONTH11) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH11                   ''年度12_月度情報11
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR12_MONTH12) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR12_MONTH12                   ''年度12_月度情報12
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR13_MONTH1) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH1                     ''年度13_月度情報1
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR13_MONTH2) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH2                     ''年度13_月度情報2
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR13_MONTH3) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH3                     ''年度13_月度情報3
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR13_MONTH4) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH4                     ''年度13_月度情報4
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR13_MONTH5) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH5                     ''年度13_月度情報5
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR13_MONTH6) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH6                     ''年度13_月度情報6
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR13_MONTH7) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH7                     ''年度13_月度情報7
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR13_MONTH8) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH8                     ''年度13_月度情報8
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR13_MONTH9) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH9                     ''年度13_月度情報9
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR13_MONTH10) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH10                   ''年度13_月度情報10
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR13_MONTH11) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH11                   ''年度13_月度情報11
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR13_MONTH12) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR13_MONTH12                   ''年度13_月度情報12
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR14_MONTH1) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH1                     ''年度14_月度情報1
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR14_MONTH2) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH2                     ''年度14_月度情報2
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR14_MONTH3) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH3                     ''年度14_月度情報3
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR14_MONTH4) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH4                     ''年度14_月度情報4
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR14_MONTH5) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH5                     ''年度14_月度情報5
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR14_MONTH6) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH6                     ''年度14_月度情報6
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR14_MONTH7) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH7                     ''年度14_月度情報7
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR14_MONTH8) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH8                     ''年度14_月度情報8
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR14_MONTH9) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH9                     ''年度14_月度情報9
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR14_MONTH10) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH10                   ''年度14_月度情報10
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR14_MONTH11) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH11                   ''年度14_月度情報11
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR14_MONTH12) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR14_MONTH12                   ''年度14_月度情報12
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR15_MONTH1) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH1                     ''年度15_月度情報1
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR15_MONTH2) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH2                     ''年度15_月度情報2
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR15_MONTH3) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH3                     ''年度15_月度情報3
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR15_MONTH4) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH4                     ''年度15_月度情報4
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR15_MONTH5) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH5                     ''年度15_月度情報5
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR15_MONTH6) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH6                     ''年度15_月度情報6
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR15_MONTH7) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH7                     ''年度15_月度情報7
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR15_MONTH8) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH8                     ''年度15_月度情報8
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR15_MONTH9) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH9                     ''年度15_月度情報9
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR15_MONTH10) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH10                   ''年度15_月度情報10
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR15_MONTH11) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH11                   ''年度15_月度情報11
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR15_MONTH12) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR15_MONTH12                   ''年度15_月度情報12
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR16_MONTH1) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH1                     ''年度16_月度情報1
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR16_MONTH2) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH2                     ''年度16_月度情報2
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR16_MONTH3) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH3                     ''年度16_月度情報3
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR16_MONTH4) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH4                     ''年度16_月度情報4
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR16_MONTH5) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH5                     ''年度16_月度情報5
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR16_MONTH6) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH6                     ''年度16_月度情報6
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR16_MONTH7) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH7                     ''年度16_月度情報7
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR16_MONTH8) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH8                     ''年度16_月度情報8
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR16_MONTH9) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH9                     ''年度16_月度情報9
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR16_MONTH10) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH10                   ''年度16_月度情報10
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR16_MONTH11) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH11                   ''年度16_月度情報11
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR16_MONTH12) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR16_MONTH12                   ''年度16_月度情報12
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR17_MONTH1) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH1                     ''年度17_月度情報1
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR17_MONTH2) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH2                     ''年度17_月度情報2
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR17_MONTH3) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH3                     ''年度17_月度情報3
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR17_MONTH4) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH4                     ''年度17_月度情報4
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR17_MONTH5) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH5                     ''年度17_月度情報5
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR17_MONTH6) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH6                     ''年度17_月度情報6
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR17_MONTH7) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH7                     ''年度17_月度情報7
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR17_MONTH8) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH8                     ''年度17_月度情報8
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR17_MONTH9) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH9                     ''年度17_月度情報9
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR17_MONTH10) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH10                   ''年度17_月度情報10
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR17_MONTH11) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH11                   ''年度17_月度情報11
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR17_MONTH12) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR17_MONTH12                   ''年度17_月度情報12
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR18_MONTH1) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH1                     ''年度18_月度情報1
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR18_MONTH2) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH2                     ''年度18_月度情報2
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR18_MONTH3) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH3                     ''年度18_月度情報3
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR18_MONTH4) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH4                     ''年度18_月度情報4
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR18_MONTH5) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH5                     ''年度18_月度情報5
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR18_MONTH6) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH6                     ''年度18_月度情報6
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR18_MONTH7) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH7                     ''年度18_月度情報7
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR18_MONTH8) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH8                     ''年度18_月度情報8
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR18_MONTH9) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH9                     ''年度18_月度情報9
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR18_MONTH10) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH10                   ''年度18_月度情報10
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR18_MONTH11) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH11                   ''年度18_月度情報11
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR18_MONTH12) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR18_MONTH12                   ''年度18_月度情報12
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR19_MONTH1) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH1                     ''年度19_月度情報1
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR19_MONTH2) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH2                     ''年度19_月度情報2
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR19_MONTH3) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH3                     ''年度19_月度情報3
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR19_MONTH4) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH4                     ''年度19_月度情報4
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR19_MONTH5) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH5                     ''年度19_月度情報5
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR19_MONTH6) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH6                     ''年度19_月度情報6
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR19_MONTH7) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH7                     ''年度19_月度情報7
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR19_MONTH8) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH8                     ''年度19_月度情報8
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR19_MONTH9) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH9                     ''年度19_月度情報9
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR19_MONTH10) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH10                   ''年度19_月度情報10
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR19_MONTH11) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH11                   ''年度19_月度情報11
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR19_MONTH12) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR19_MONTH12                   ''年度19_月度情報12
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20_MONTH1) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH1                     ''年度20_月度情報1
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20_MONTH2) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH2                     ''年度20_月度情報2
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20_MONTH3) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH3                     ''年度20_月度情報3
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20_MONTH4) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH4                     ''年度20_月度情報4
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20_MONTH5) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH5                     ''年度20_月度情報5
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20_MONTH6) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH6                     ''年度20_月度情報6
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20_MONTH7) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH7                     ''年度20_月度情報7
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20_MONTH8) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH8                     ''年度20_月度情報8
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20_MONTH9) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH9                     ''年度20_月度情報9
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20_MONTH10) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH10                   ''年度20_月度情報10
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20_MONTH11) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH11                   ''年度20_月度情報11
        setValue(ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR20_MONTH12) = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12                   ''年度20_月度情報12

        ''値のセット
        Me.ChangePaymentLineColumn = setValue

    End Sub

    '--------------------------------------------------------
    'メソッド名：GetCsvTitleKobetuSyousai
    '概    要  ：KobetuSyousaiのCsvタイトルを取得
    '説    明  ：KobetuSyousaiのCsvタイトルを取得
    '引    数  ：なし
    '戻 り 値  ：GetCsvTitleKobetuSyousai = KobetuSyousaiのCsvタイトル(String)
    '--------------------------------------------------------
    Private Function GetCsvTitleKobetuSyousai() As String

        ''KobetuSyousaiのCsvタイトル初期化
        GetCsvTitleKobetuSyousai = ""
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_CUSTINFO_UPDATE_FLAG & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_CUSTINFO_LOCK_FLAG & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_CUSTINFO_VALID_FLAG & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_CUSTINFO_CONTRACT & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_CUSTINFO_FILE_NAME & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_CUSTINFO_FILE_NAME_SUFFIX & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_CUSTINFO_FILE_NAME_SUFFIX_INTR & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_CUSTINFO_SEQ & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_CUSTINFO_IDENTITY_FLAG & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_CUSTINFO_PROD_NO & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_CUSTINFO_PROD_NAME & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_CUSTINFO_WD_ANNT_DATE & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_CUSTINFO_WD_DATE & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_CUSTINFO_PRICE_CHG_DATE & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_CUSTINFO_MES_CATEGORY & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_CUSTINFO_MES_GROUP & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_CUSTINFO_SPECIAL_FEATURE & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_CUSTINFO_QTY & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_CUSTINFO_LIST_PRICE_PROPSAL & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_CUSTINFO_LIST_PRICE & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_CUSTINFO_T_LIST_PRICE_PROPOSAL & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_CUSTINFO_T_LIST_PRICE & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_CUSTINFO_COST_RATE & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_CUSTINFO_COST & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_CUSTINFO_COST_TOTAL & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_CUSTINFO_COST_INPUT_DATE & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_HWMA_LIST_PRICE & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_HWMA_LIST_PRICE_TOTAL & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_HOURLY_SCALE & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_MA_EXT_SCALE & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_DP & CSV_DELIMITA
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_HWMA_DP_LIST_PRICE & CSV_DELIMITA

        ''最終項目の為、区切文字不要
        GetCsvTitleKobetuSyousai = GetCsvTitleKobetuSyousai & CSV_TITLE_HWMA_DP_LIST_PRICE_TOTAL

        Return GetCsvTitleKobetuSyousai

    End Function


    '--------------------------------------------------------
    'メソッド名：GetKobetuSyousai
    '概    要  ：Excelの行情報よりKobetuSyousaiCsvを取得
    '説    明  ：Excelの行情報よりKobetuSyousaiCsvを取得
    '引    数  ：ExcelCellInfo = Excel1行
    '戻 り 値  ：GetKobetuSyousai = KobetuSyousaiCsv(String)
    '--------------------------------------------------------
    Public Function GetKobetuSyousai(ByVal ExcelCellInfo(,) As Object) As String

        GetKobetuSyousai = ""
        Dim i As Integer = 0
        For i = 1 To UBound(ExcelCellInfo, 2)
            If i <> UBound(ExcelCellInfo, 2) Then
                If IsNothing(ExcelCellInfo(1, i)) = False Then
                    Select Case i
                        Case 10
                            Dim prod_No As String
                            prod_No = ExcelWrite.changeDBNullToString(ExcelCellInfo(1, i))
                            If prod_No.Length <= 4 Then
                                prod_No = prod_No.PadLeft(4, "0")
                            End If
                            ExcelCellInfo(1, i) = prod_No

                        Case ExcelWrite.ExcelPaymentLineDetailColumn.COST_RATE, _
                             ExcelWrite.ExcelPaymentLineDetailColumn.HOURLY_SCALE, _
                             ExcelWrite.ExcelPaymentLineDetailColumn.HOURLY_SCALE, _
                             ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE

                            ''％表示
                            If IsNumeric(ExcelCellInfo(1, i)) = True Then
                                ExcelCellInfo(1, i) = GetParsentFormat(ExcelCellInfo(1, i))
                            Else
                                ExcelCellInfo(1, i) = ""
                            End If

                    End Select
                End If
                GetKobetuSyousai = GetKobetuSyousai & SetDoubleQuote(CStr(ExcelCellInfo(1, i))) & CSV_DELIMITA
            Else
                ''最終行の為、区切文字不要
                GetKobetuSyousai = GetKobetuSyousai & SetDoubleQuote(CStr(ExcelCellInfo(1, i)))
            End If
        Next

        GetKobetuSyousai = GetKobetuSyousai.Replace(ChrW(160), " ")

        Return GetKobetuSyousai

    End Function

    '--------------------------------------------------------
    'メソッド名：GetYYYY
    '概    要  ：YYYY年よりYYYY部分の抽出
    '説    明  ：YYYY年よりYYYY部分の抽出
    '引    数  ：str = 抽出対象年月
    '戻 り 値  ：GetYYYY = YYYY(String)
    '--------------------------------------------------------
    Private Function GetYYYY(ByVal str As String) As String
        GetYYYY = ""
        If str.IndexOf("年") > 3 Then
            GetYYYY = str.Substring(0, str.IndexOf("年"))
            GetYYYY = str.Substring(0, 4)
        End If

        Return GetYYYY

    End Function
    '--------------------------------------------------------
    'メソッド名：GetMM
    '概    要  ：MM月よりMM部分の抽出
    '説    明  ：MM月よりMM部分の抽出
    '引    数  ：str = 抽出対象月月
    '戻 り 値  ：GetMM = MM(String)
    '--------------------------------------------------------
    Private Function GetMM(ByVal str As String) As String
        GetMM = ""
        If str.IndexOf("月") > 3 Then
            GetMM = str.Substring(str.IndexOf("年") + 1, str.IndexOf("月") - str.IndexOf("年") - 1)
        End If

        Return GetMM

    End Function

    '--------------------------------------------------------
    'メソッド名：ReleaseComObject
    '概    要  ：オブジェクト開放
    '説    明  ：オブジェクトを開放する
    '引    数  ：obj ： オブジェクト
    '戻 り 値  ：なし
    '--------------------------------------------------------
    Private Sub ReleaseComObject(ByVal obj As Object)

        If IsNothing(obj) = False Then
            InteropServices.Marshal.ReleaseComObject(obj)
        End If

    End Sub

    '--------------------------------------------------------
    'メソッド名：GetZeroFormat
    '概    要  ：先頭に0を付与する
    '説    明  ：先頭に0を付与する
    '引    数  ：value = 抽出対象月月
    '戻 り 値  ：GetMMFormat = MM(String)
    '--------------------------------------------------------
    Private Function GetZeroFirstFormat(ByVal value As Object) As String
        GetZeroFirstFormat = ""
        Return CInt(value).ToString("00")
    End Function

    '--------------------------------------------------------
    'メソッド名：GetParsentFormat
    '概    要  ：パーセント表示
    '説    明  ：00.000の形で出力する。
    '引    数  ：value = 抽出対象月月
    '戻 り 値  ：GetMMFormat = MM(String)
    '--------------------------------------------------------
    Private Function GetParsentFormat(ByVal value As Object) As Object

        GetParsentFormat = Nothing
        If CStr(value).IndexOf("%") > 0 Then
            value = CStr(value).Substring(0, CStr(value).IndexOf("%"))
        ElseIf CStr(value).IndexOf("％") > 0 Then
            value = CStr(value).Substring(0, CStr(value).IndexOf("％"))
        End If

        GetParsentFormat = CDbl(value * 100).ToString("##0.0000000000000")

        Return GetParsentFormat

    End Function

    '--------------------------------------------------------
    'メソッド名：GetParsentFormat
    '概    要  ：パーセント表示
    '説    明  ：00.000の形で出力する。
    '引    数  ：value = 抽出対象月月
    '戻 り 値  ：GetMMFormat = MM(String)
    '--------------------------------------------------------
    Private Function GetParsentFormat2(ByVal value As Object) As Object
        GetParsentFormat2 = Nothing
        If CStr(value).IndexOf("%") > 0 Then
            value = CStr(value).Substring(0, CStr(value).IndexOf("%"))
        ElseIf CStr(value).IndexOf("％") > 0 Then
            value = CStr(value).Substring(0, CStr(value).IndexOf("％"))
        End If

        GetParsentFormat2 = CDbl(value * 100).ToString("##0.00000")

        Return GetParsentFormat2

    End Function


    '--------------------------------------------------------
    'メソッド名：SetDoubleQuote
    '概    要  ：ダブルクォートを付与する。
    '説    明  ：引数に , or "　が含まれる場合、引数にダブルクォートを付与する。
    '引    数  ：value = 抽出対象月月
    '戻 り 値  ：GetMMFormat = MM(String)
    '--------------------------------------------------------
    Private Function SetDoubleQuote(ByVal value As String) As String

        If value = Nothing Then
            Return ""
        End If

        '' 「"」 を　「""」へ変換
        Dim blnAddQuote As Boolean = False
        If value.IndexOf(Quote) <> -1 Then
            value = value.Replace(Quote, Quote & Quote)
            blnAddQuote = True
        End If

        ''「,」がある場合、ダブルクォートを付与
        If value.IndexOf(",") <> -1 Or blnAddQuote = True Then
            Return Quote & value & Quote
        End If

        Return value

    End Function


    Private Function ChangeNothingToBrank(ByVal obj As Object)
        If IsNothing(obj) = True Or IsDBNull(obj) = True Then
            Return ""
        Else
            Return obj
        End If
    End Function

    ''' <summary>
    ''' 機能：Export時、出力対象のPayment情報かどうか判定
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CheackExportPaymentOutput(ByVal ExcelCellInfo(,) As Object) As Boolean

        ''初期化
        CheackExportPaymentOutput = True

        ''更新FLG = ""　でかつ、LockFLG = "C"は出力対象外
        If ChangeNothingToBrank(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG)) = "" And
           ChangeNothingToBrank(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG)) = "C" Then

            Return False

        End If

    End Function

    '--------------------------------------------------------
    '概    要  ：PALevelを、Excel用に変換する
    '説    明  ：
    '--------------------------------------------------------
    Private Function GetPALevelName(ByVal item3 As String,
                                    ByVal ConvertClientValueData As DataTable) As String

        GetPALevelName = item3

        ''PALevelの名称をConvertClientValueデータから検索する
        Dim filter As New StringBuilder
        filter.Append(ConvertClientValueTable.COLUMN_NAME_ClassCode)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(ConvertClientValueTable.CLASSCODE_IMPORTPALEVELNAME))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(ConvertClientValueTable.COLUMN_NAME_ClientValue)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(item3))

        Dim selectRow As DataRow
        For Each selectRow In ConvertClientValueData.Select(filter.ToString)
            GetPALevelName = selectRow(ConvertClientValueTable.COLUMN_NAME_ServerValue)
        Next

    End Function



    '--------------------------------------------------------
    '概    要  ：HWMAの保証種類を、Csv用に変換する
    '説    明  ：
    '--------------------------------------------------------
    Private Function GetQcosWarrantytermName(ByVal item7 As String,
                                             ByVal ConvertClientValueData As DataTable) As String

        GetQcosWarrantytermName = item7

        ''保障種類のサーバーでの名称ををCodeデータから検索する
        Dim filter As New StringBuilder
        filter.Append(ConvertClientValueTable.COLUMN_NAME_ClassCode)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(ConvertClientValueTable.CLASSCODE_IMPORTQCOSWARRANTYTERMNAME))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(ConvertClientValueTable.COLUMN_NAME_ClientValue)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(item7))

        Dim selectRow As DataRow
        For Each selectRow In ConvertClientValueData.Select(filter.ToString)
            GetQcosWarrantytermName = selectRow(ConvertClientValueTable.COLUMN_NAME_ServerValue)
        Next

    End Function

    '--------------------------------------------------------
    '概    要  ：Csv1フォルダとCSV2フォルダを作成する。
    '説    明  ：
    '--------------------------------------------------------
    Private Sub CreateCsvFolder(ByVal strFileNamePayment As String,
                                ByRef Csv1FolderPath As String,
                                ByRef Csv2FolderPath As String)

        ''Csv出力先フォルダの存在チェック
        Dim strTemp() As String
        strTemp = strFileNamePayment.Split("\")
        System.Environment.CurrentDirectory = Application.StartupPath
        Csv2FolderPath = System.IO.Path.GetFullPath(EXPORTCSV2_DEFULT_PATH & strTemp(strTemp.Length - 2))
        ''Csv出力先フォルダの存在チェック
        If Directory.Exists(Csv2FolderPath) = False Then
            'フォルダが存在しない場合は作成
            Directory.CreateDirectory(Csv2FolderPath)
        End If

        ''Csv出力先フォルダの存在チェック
        Csv1FolderPath = System.IO.Path.GetFullPath(EXPORTCSV1_DEFULT_PATH & strTemp(strTemp.Length - 2))

        ''Csv出力先フォルダの存在チェック
        If Directory.Exists(Csv1FolderPath) = False Then
            'フォルダが存在しない場合は作成
            Directory.CreateDirectory(Csv1FolderPath)
        End If
    End Sub

    '--------------------------------------------------------
    '概    要  ：Export時、MasterMDBのClientValueTableの値を取得
    '説    明  ：
    '--------------------------------------------------------
    Public Function GetClientValueTable() As DataTable

        ''初期化
        GetClientValueTable = Nothing

        ''データの取得
        Dim con As OleDbConnection
        Dim mmc As New MasterMdbControl
        con = mmc.GetOleDBConnection(CommonVariable.MdbPW)
        Dim mdbContrl As New MUSE.DataAccess.OleDb.OleDbConvertClientValue

        Return mdbContrl.SelectDataTable(con)

    End Function

    '--------------------------------------------------------
    '概    要  ：Export時、ExcelのEOF行の判定を行う。
    '説    明  ：
    '--------------------------------------------------------
    Private Function ChkExcelEofLine(ByRef ExcelCellInfo(,) As Object) As Boolean

        ''初期化
        ChkExcelEofLine = False

        If (IsNothing(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)) OrElse CStr(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)) = "") _
            AndAlso (IsNothing(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.FILE_NAME)) OrElse CStr(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.FILE_NAME)) = "") _
            AndAlso (IsNothing(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.CONTRACT)) OrElse CStr(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.CONTRACT)) = "") _
            AndAlso (IsNothing(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROJ_ID)) OrElse CStr(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROJ_ID)) = "") Then

            Return True

        End If

    End Function

    ''' <summary>
    ''' 機　能：バージョンアップ詳細のロード専用CSVを作成
    ''' </summary>
    ''' <param name="ExcelCellInfo"></param>
    ''' <param name="dtNow"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetVerupDetail(ByVal ExcelCellInfo(,) As Object, ByVal dtNow As DateTime) As String

        Dim intCol As Integer
        Dim intColCnt As Integer

        GetVerupDetail = ""

        'データ整え
        Dim prod_No As String = ExcelWrite.changeDBNullToString(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineDetailColumn.PROD_NO))
        If prod_No.Length <= 4 Then
            prod_No = prod_No.PadLeft(4, "0")
        End If
        ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineDetailColumn.PROD_NO) = prod_No
        Call ChageDateExcelToDb2(ExcelCellInfo, ExcelWrite.ExcelPaymentLineDetailColumn.WD_ANNT_DATE)
        Call ChageDateExcelToDb2(ExcelCellInfo, ExcelWrite.ExcelPaymentLineDetailColumn.WD_DATE)
        Call ChageDateExcelToDb2(ExcelCellInfo, ExcelWrite.ExcelPaymentLineDetailColumn.PRICE_CHG_DATE)
        Call ChageDateExcelToDb2(ExcelCellInfo, ExcelWrite.ExcelPaymentLineDetailColumn.COST_INPUT_DATE)
        Call MakeVerupDetailDataLine(ExcelCellInfo, ExcelWrite.ExcelPaymentLineDetailColumn.COST_RATE)
        Call MakeVerupDetailDataLine(ExcelCellInfo, ExcelWrite.ExcelPaymentLineDetailColumn.HOURLY_SCALE)
        Call MakeVerupDetailDataLine(ExcelCellInfo, ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE)

        'CPNO
        GetVerupDetail = """" & CommonVariable.CPNO & ""","
        '契約順番
        GetVerupDetail = GetVerupDetail & SetDoubleQuote(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineDetailColumn.CONTRACT)) & CSV_DELIMITA
        'ファイル名
        GetVerupDetail = GetVerupDetail & SetDoubleQuote(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME)) & CSV_DELIMITA
        'ファイル名Suffix
        GetVerupDetail = GetVerupDetail & SetDoubleQuote(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX)) & CSV_DELIMITA
        'ファイル内Suffix
        GetVerupDetail = GetVerupDetail & SetDoubleQuote(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineDetailColumn.FILE_NAME_SUFFIX_INTR)) & CSV_DELIMITA
        'シーケンス
        GetVerupDetail = GetVerupDetail & SetDoubleQuote(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineDetailColumn.SEQ)) & CSV_DELIMITA
        '削除Flag
        GetVerupDetail = GetVerupDetail & """""" & CSV_DELIMITA
        'Validation Status
        GetVerupDetail = GetVerupDetail & """Y""" & CSV_DELIMITA
        '更新FLG
        GetVerupDetail = GetVerupDetail & SetDoubleQuote(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineDetailColumn.UPDATE_FLAG)) & CSV_DELIMITA
        'ロックFLG
        GetVerupDetail = GetVerupDetail & SetDoubleQuote(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineDetailColumn.LOCK_FLAG)) & CSV_DELIMITA
        '有効/無効
        GetVerupDetail = GetVerupDetail & SetDoubleQuote(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineDetailColumn.VALID_FLAG)) & CSV_DELIMITA

        '識別FLG,製品番号,製品名,製品・サービス廃止発表日,製品・サービス廃止予定,価格改定予定,MESカテゴリ,MESグループ,特殊Feature,数量,提案時List Price,リフレッシュ後List Price,提案時List Price合計,リフレッシュ後List Price合計
        For intColCnt = ExcelWrite.ExcelPaymentLineDetailColumn.IDENTITY_FLAG To ExcelWrite.ExcelPaymentLineDetailColumn.LIST_PRICE_TOTAL
            GetVerupDetail = GetVerupDetail & SetDoubleQuote(ExcelCellInfo(1, intColCnt)) & CSV_DELIMITA
        Next

        '最新のList Price Total
        GetVerupDetail = GetVerupDetail & CSV_DELIMITA
        '最新の保守List Price年合計
        GetVerupDetail = GetVerupDetail & CSV_DELIMITA
        '最新の保守List Price月合計
        GetVerupDetail = GetVerupDetail & CSV_DELIMITA

        'COST %,COST単価,COST合計,COST入力日
        For intColCnt = ExcelWrite.ExcelPaymentLineDetailColumn.COST_RATE To ExcelWrite.ExcelPaymentLineDetailColumn.COST_INPUT_DATE
            GetVerupDetail = GetVerupDetail & ExcelCellInfo(1, intColCnt) & CSV_DELIMITA
        Next

        'CreateTimeStamp
        GetVerupDetail = GetVerupDetail & dtNow.ToString("yyyy-MM-dd HH:mm:ss") & CSV_DELIMITA
        'UpdateTimeStamp
        GetVerupDetail = GetVerupDetail & dtNow.ToString("yyyy-MM-dd HH:mm:ss") & CSV_DELIMITA
        'CreateUser
        GetVerupDetail = GetVerupDetail & "BATCH" & CSV_DELIMITA
        'UpdateUser
        GetVerupDetail = GetVerupDetail & "BATCH" & CSV_DELIMITA

        'HWMA Listprice(単価),HWMA Listprice(合計),時間帯掛け率,保守延長掛け率
        For intColCnt = ExcelWrite.ExcelPaymentLineDetailColumn.HWMA_LIST_PRICE To ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE
            GetVerupDetail = GetVerupDetail & ExcelCellInfo(1, intColCnt) & CSV_DELIMITA
        Next

        'D%,HWMA D%適用後(単価),HWMA D%適用後(合計)
        GetVerupDetail = GetVerupDetail & ",,"

        Return GetVerupDetail

    End Function

    ''' <summary>
    ''' 機　能：ﾊﾞｰｼﾞｮﾝｱｯﾌﾟのデータ整え
    ''' </summary>
    ''' <param name="ExcelCellInfo"></param>
    ''' <param name="intColum"></param>
    ''' <remarks></remarks>
    Private Sub MakeVerupDetailDataLine(ByRef ExcelCellInfo(,) As Object, ByVal intColum As Integer)

        If IsNumeric(ExcelCellInfo(1, intColum)) = True Then
            ExcelCellInfo(1, intColum) = GetParsentFormat(ExcelCellInfo(1, intColum))
        Else
            ExcelCellInfo(1, intColum) = ""
        End If

    End Sub

    Private Sub ChageDateExcelToDb2(ByRef ExcelCellInfo(,) As Object, ByVal intColum As Integer)

        If IsDate(ExcelCellInfo(1, intColum)) = True Then
            Dim dtItem As Date = Date.Parse(ExcelCellInfo(1, intColum))
            ExcelCellInfo(1, intColum) = dtItem.ToString("yyyy-MM-dd")
        Else
            ExcelCellInfo(1, intColum) = ""
        End If

    End Sub

    'Req.1710：エクスポート機能変更 2018/12 Str
    ''' <summary>
    ''' 機能：MDBを配列へ格納する。
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetMDBDataInArray(ByRef OutDataList(,) As Object)

        ''初期化
        OutDataList = Nothing

        ''MDBからﾃﾞｰﾀを取得        
        Dim Con As OleDbConnection
        Dim mmc As New MasterMdbControl
        Try

            ''接続取得
            Con = mmc.GetOleTmpDBConnection(CommonVariable.CPNO, CommonVariable.MdbPW)

            ''Sql取得
            Dim sql_Tbl1 As String = GetSql_PaymentTable1()
            Dim sql_Tbl2 As String = GetSql_PaymentTable2()
            Dim sql_Tbl3 As String = GetSql_PaymentTable3()

            ''ﾃﾞｰﾀ取得
            Dim Table1_Data As New DataTable
            Dim Table2_Data As New DataTable
            Dim Table3_Data As New DataTable
            Dim da_Tbl1 As New OleDbDataAdapter(sql_Tbl1, Con)
            Dim da_Tbl2 As New OleDbDataAdapter(sql_Tbl2, Con)
            Dim da_Tbl3 As New OleDbDataAdapter(sql_Tbl3, Con)
            Call da_Tbl1.Fill(Table1_Data)
            Call da_Tbl2.Fill(Table2_Data)
            Call da_Tbl3.Fill(Table3_Data)

            ''ﾃﾞｰﾀがなければ処理終了
            If Table1_Data.Rows.Count = 0 Then
                Exit Sub
            End If

            ''配列サイズ確定
            If Table1_Data.Rows.Count <> 0 Then
                ReDim Preserve OutDataList(Table1_Data.Rows.Count, ExcelWrite.MdbPaymentLineColumn.PRICE_YEAR20_MONTH12)
            End If

            ''ﾃﾞｰﾀを配列用に加工
            Dim Idx As Integer                  ''MDBのｶﾚﾝﾄ位置：年額/月額以外
            Dim IdxD As Integer                 ''MDBのｶﾚﾝﾄ位置：年額/月額
            Dim ArrayIdx As Integer             ''配列のIdx：年額/月額以外
            Dim ArrayIdxD As Integer            ''配列のIdx：年額/月額
            For Idx = 0 To Table1_Data.Rows.Count - 1

                ''配列のIdx初期化
                ArrayIdx = 0

                ''PaymentTBL1取得
                For i As Integer = 1 To Table1_Data.Columns.Count - 1
                    ArrayIdx = ArrayIdx + 1
                    OutDataList(Idx + 1, ArrayIdx) = Table1_Data.Rows(Idx).Item(i)
                Next

                ''PaymentTBL2取得
                For j As Integer = 1 To Table2_Data.Columns.Count - 2
                    ArrayIdx = ArrayIdx + 1
                    OutDataList(Idx + 1, ArrayIdx) = Table2_Data.Rows(Idx).Item(j)
                Next

                ''PaymentTBL3取得 ※20年分の値をセット
                IdxD = (Idx * 20) - 1

                '年額セット
                IdxD = IdxD + 1
                For IdxD = IdxD To IdxD + 19
                    ArrayIdx = ArrayIdx + 1
                    OutDataList(Idx + 1, ArrayIdx) = Table3_Data.Rows(IdxD).Item("IOC_YYYY")
                Next

                '過去の契約金額合計をセット(Mdbの40カラム目を統合Paymentの117カラム目にセット)
                ArrayIdx = ArrayIdx + 1
                OutDataList(Idx + 1, ArrayIdx) = Table2_Data.Rows(Idx).Item(Table2_Data.Columns.Count - 1)

                '月額セット
                ''PaymentTBL3取得 ※20年分の値をセット
                IdxD = (Idx * 20) - 1

                IdxD = IdxD + 1
                For IdxD = IdxD To IdxD + 19
                    For l As Integer = 1 To 12
                        ArrayIdx = ArrayIdx + 1

                        Select Case l
                            Case 1
                                OutDataList(Idx + 1, ArrayIdx) = Table3_Data.Rows(IdxD).Item("IOC_01")
                            Case 2
                                OutDataList(Idx + 1, ArrayIdx) = Table3_Data.Rows(IdxD).Item("IOC_02")
                            Case 3
                                OutDataList(Idx + 1, ArrayIdx) = Table3_Data.Rows(IdxD).Item("IOC_03")
                            Case 4
                                OutDataList(Idx + 1, ArrayIdx) = Table3_Data.Rows(IdxD).Item("IOC_04")
                            Case 5
                                OutDataList(Idx + 1, ArrayIdx) = Table3_Data.Rows(IdxD).Item("IOC_05")
                            Case 6
                                OutDataList(Idx + 1, ArrayIdx) = Table3_Data.Rows(IdxD).Item("IOC_06")
                            Case 7
                                OutDataList(Idx + 1, ArrayIdx) = Table3_Data.Rows(IdxD).Item("IOC_07")
                            Case 8
                                OutDataList(Idx + 1, ArrayIdx) = Table3_Data.Rows(IdxD).Item("IOC_08")
                            Case 9
                                OutDataList(Idx + 1, ArrayIdx) = Table3_Data.Rows(IdxD).Item("IOC_09")
                            Case 10
                                OutDataList(Idx + 1, ArrayIdx) = Table3_Data.Rows(IdxD).Item("IOC_10")
                            Case 11
                                OutDataList(Idx + 1, ArrayIdx) = Table3_Data.Rows(IdxD).Item("IOC_11")
                            Case 12
                                OutDataList(Idx + 1, ArrayIdx) = Table3_Data.Rows(IdxD).Item("IOC_12")
                        End Select
                    Next
                Next

            Next
            Con.Close()

        Catch ex As Exception
            ''ｴﾗｰの処理はなし
        End Try

    End Sub


    ''' <summary>
    ''' 概 要：PaymentTable1の取得SQL
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_PaymentTable1() As String

        ''戻り値
        Dim rtnValue As New StringBuilder

        ''Select句
        rtnValue.Append(CommonConstant.SQL_STR_SELECT)
        rtnValue.Append(CommonConstant.SQL_STR_ASTERISK)

        ''From句
        rtnValue.Append(CommonConstant.SQL_STR_FROM)
        rtnValue.Append(" PaymentTBL1 ")

        ''Order By句
        rtnValue.Append(CommonConstant.SQL_STR_ORDER_BY)
        rtnValue.Append(" ID ")

        Return rtnValue.ToString

    End Function


    ''' <summary>
    ''' 概 要：PaymentTable2の取得SQL
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_PaymentTable2() As String

        ''戻り値
        Dim rtnValue As New StringBuilder

        ''Select句
        rtnValue.Append(CommonConstant.SQL_STR_SELECT)
        rtnValue.Append(CommonConstant.SQL_STR_ASTERISK)

        ''From句
        rtnValue.Append(CommonConstant.SQL_STR_FROM)
        rtnValue.Append(" PaymentTBL2 ")

        ''Order By句
        rtnValue.Append(CommonConstant.SQL_STR_ORDER_BY)
        rtnValue.Append(" ID ")

        Return rtnValue.ToString

    End Function


    ''' <summary>
    ''' 概 要：PaymentTable3の取得SQL
    ''' 説 明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetSql_PaymentTable3() As String

        ''戻り値
        Dim rtnValue As New StringBuilder

        ''Select句
        rtnValue.Append(CommonConstant.SQL_STR_SELECT)
        rtnValue.Append(CommonConstant.SQL_STR_ASTERISK)

        ''From句
        rtnValue.Append(CommonConstant.SQL_STR_FROM)
        rtnValue.Append(" PaymentTBL3 ")

        ''Order By句
        rtnValue.Append(CommonConstant.SQL_STR_ORDER_BY)
        rtnValue.Append(" ID, IOC_YEAER")

        Return rtnValue.ToString

    End Function

    ''' <summary>
    ''' Excel行に対応した契約済み行情報をセットする
    ''' </summary>
    ''' <param name="ExcelCellInfo">対象のExcel行配列</param>
    ''' <param name="MdbDataList">対象CPNOのMDB配列</param>
    ''' <returns>状態</returns>
    ''' <remarks></remarks>
    Public Function GetMDBLine(ByRef ExcelCellInfo(,) As Object, _
                               ByVal MdbDataList(,) As Object) As String

        Dim lngRow As Long
        Dim lngCol As Long
        Dim wIdx As Long

        ''初期化
        GetMDBLine = ""

        Try
            wIdx = 1

            For lngRow = 1 To UBound(MdbDataList, 1)

                '一致行出力
                If Val(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)) = Val(MdbDataList(lngRow, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)) Then

                    GetMDBLine = "FIND"

                    For lngCol = 1 To UBound(MdbDataList, 2)
                        Select Case lngCol
                            Case ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG, _
                                 ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG, _
                                 ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10
                                '作業指示FLG, Payment種別, 取込元情報 はPaymentの情報を使用する

                            Case Else
                                'その他の項目はMDBの情報を使用する
                                ExcelCellInfo(1, lngCol) = MdbDataList(lngRow, lngCol)

                        End Select
                    Next

                    Exit For
                End If
            Next

        Catch ex As Exception
            Throw ex

        End Try

    End Function
    'Req.1710：エクスポート機能変更 2018/12 End

#End Region

End Class
