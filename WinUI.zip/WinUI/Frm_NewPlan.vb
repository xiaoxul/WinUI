﻿Imports System.Text
Imports System.Data.OleDb
Imports System.IO
Imports System.Collections.Generic
Imports MUSE.Utility
Imports MUSE.Utility.OioBamaCommmon
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.UserMessageBox
Imports MUSE.Utility.UserDataTable.Master
Imports Microsoft.Office.Interop

Public Class Frm_NewPlan

#Region "定数"
    Private Const ROW_NO_AREA = 1000

    ''押下した削除ボタンの判定
    Private Const DelLev_1 As Integer = 1
    Private Const DelLev_2 As Integer = 2
    Private Const DelLev_3 As Integer = 3
    Private Const DelLev_4 As Integer = 4
#End Region

#Region "構造体"
    '変更前設定値
    Private Structure BeforeValue
        Dim strLv1 As String            '案件番号１（入力項目のみ）
        Dim strLv2 As String            '案件番号２（入力項目のみ）
        Dim strLv3 As String            '案件番号３（入力項目のみ）
        Dim strLv4 As String            '案件番号４（入力項目のみ）
        Dim strPlanName1 As String      '案件名１
        Dim strPlanName2 As String      '案件名２
        Dim strPlanName3 As String      '案件名３
        Dim strPlanName4 As String      '案件名４
    End Structure

    Private Enum XLSPlanColumns
        StrEndRow = 1
        PLAN_NAME
        LEVEL1
        LEVEL2
        LEVEL3
        LEVEL4
        LEVELALL
        SPACE1              ''空行
        SPACE2              ''空行
        SPACE3              ''空行
        ERRFLG              ''エラー情報 (有/空白/対象外)　※Xlsで入力チェックボタン必須なので、空白しか存在しない想定
    End Enum

#End Region

#Region "メンバ変数 "
    Private Structure Plan
        Public No1 As String
        Public No2 As String
        Public No3 As String
        Public No4 As String
        Public ParentNo1 As String
        Public ParentNo2 As String
        Public ParentNo3 As String
        Public ParentNo4 As String
        Public Name As String
        Public PrintF As Boolean
        Public StartRowNo As Integer
    End Structure

    Private tbPlan As DataTable
    Private bvItem As BeforeValue

#End Region

#Region "コンストラクタ"
    Sub New(ByVal CPNO As Integer, _
            ByVal CONTRACT_NO As Integer, _
            ByVal CUSTOMERNAME As String)

        ' この呼び出しはデザイナーで必要です。
        InitializeComponent()
        ' InitializeComponent() 呼び出しの後で初期化を追加します。

    End Sub

    Sub New()

        ' この呼び出しはデザイナーで必要です。
        InitializeComponent()
        ' InitializeComponent() 呼び出しの後で初期化を追加します。

    End Sub
#End Region

#Region "イベントハンドラ "
    ''' <summary>
    ''' 機能：フォームロード
    ''' 説明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Frm_Plan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim blnRet As Boolean

        'テーブルを最新に更新
        Reflesh()

        '契約情報を表示
        lblCPNO.Text = CommonVariable.CUSTOMERNAME.Replace("&", "&&") & "(" & CommonVariable.CPNO & ")"
        lblContractNo.Text = CommonVariable.CONTRACTNO.ToString.PadLeft(3, "0c")
        lblContractName.Text = CommonVariable.CONTRACTNONAME.Replace("&", "&&")

        ''権限に応じてﾎﾞﾀﾝ非表示
        Me.Btn_DelLv1.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.Btn_DelLv1.Name)
        Me.Btn_DelLv2.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.Btn_DelLv2.Name)
        Me.Btn_DelLv3.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.Btn_DelLv3.Name)
        Me.Btn_DelLv4.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.Btn_DelLv4.Name)
        Me.BtnOutFolder.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.BtnOutFolder.Name)
        Me.BtnImportXls.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.BtnImportXls.Name)
        Me.BtnExportXls.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.BtnExportXls.Name)
        Me.btnSave.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.btnSave.Name)

        '初期表示
        Call SetIniDisp()

        'ツリー表示
        blnRet = SetTree()

        '画面の値をセットする
        Call SetDisplayValue()

        '実行環境＋Version
        Me.Text = CommonVariable.OBAMATITLE

    End Sub

    ''' <summary>
    ''' 機能：フォルダ表示ボタン
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub BtnOutFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnOutFolder.Click

        ''Explorer表示
        Dim ofm As New OioFileManage
        If ofm.DispExplorer(CommonConstant.FOLDERNAME_OUTPUT, CommonVariable.CPNO, CommonVariable.CONTRACTNO) = False Then
            MsgBox(FileReader.GetMessage("MSG_0208"), MsgBoxStyle.Exclamation, "")
        End If

    End Sub

    ''' <summary>
    ''' 機能：Level1フォーカス取得時
    ''' 説明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub txtLv11_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLv11.GotFocus

        txtLv11.SelectAll()

    End Sub

    ''' <summary>
    ''' 機能：Level2フォーカス取得時
    ''' 説明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub txtLv22_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLv22.GotFocus

        txtLv22.SelectAll()

    End Sub

    ''' <summary>
    ''' 機能：Level3フォーカス取得時
    ''' 説明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub txtLv33_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLv33.GotFocus

        txtLv33.SelectAll()

    End Sub

    ''' <summary>
    ''' 機能：Level4フォーカス取得時
    ''' 説明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub txtLv44_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLv44.GotFocus

        txtLv44.SelectAll()

    End Sub

    ''' <summary>
    ''' 機能：Level1フォーカス移動時
    ''' 説明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub txtLv11_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLv11.Validated

        If IsPlanNoEmpty() Then
            txtLv11.Text = String.Empty
            Return
        End If

        If txtLv11.Text <> String.Empty Then
            If IsNumeric(txtLv11.Text) Then
                If txtLv11.Text.Length < 2 Then
                    txtLv11.Text = "0" + txtLv11.Text
                End If
                txtLv11.BackColor = Color.White
            Else
                MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0065"), Me.Text)
                txtLv11.BackColor = Color.Red
                txtLv11.Text = String.Empty
            End If
        End If

        If Trim(txtLv11.Text) = "" Then
            txtLv12.Text = ""
            txtLv13.Text = ""
            txtLv14.Text = ""
        Else
            txtLv12.Text = "00"
            txtLv13.Text = "00"
            txtLv14.Text = "00"
        End If
        txtParentNo11.Text = txtLv11.Text
        txtParentNo12.Text = txtLv12.Text
        txtParentNo13.Text = txtLv13.Text
        txtParentNo14.Text = txtLv14.Text

        '下のLevelをクリアする
        Me.txtLv21.Text = String.Empty
        Me.txtLv22.Text = String.Empty
        Me.txtLv23.Text = String.Empty
        Me.txtLv24.Text = String.Empty
        Me.txtPlanName2.Text = String.Empty
        Me.nudStartRowNo2.Value = 0
        Me.txtLv31.Text = String.Empty
        Me.txtLv32.Text = String.Empty
        Me.txtLv33.Text = String.Empty
        Me.txtLv34.Text = String.Empty
        Me.txtPlanName3.Text = String.Empty
        Me.nudStartRowNo3.Value = 0
        Me.txtLv41.Text = String.Empty
        Me.txtLv42.Text = String.Empty
        Me.txtLv43.Text = String.Empty
        Me.txtLv44.Text = String.Empty
        Me.txtPlanName4.Text = String.Empty
        Me.nudStartRowNo4.Value = 0

    End Sub

    ''' <summary>
    ''' 機能：Leve22フォーカス移動時
    ''' 説明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub txtLv22_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLv22.Validated

        If IsPlanNoEmpty() Then
            txtLv22.Text = String.Empty
            Return
        End If

        If txtLv22.Text <> String.Empty Then
            If IsNumeric(txtLv22.Text) Then
                If txtLv22.Text.Length < 2 Then
                    txtLv22.Text = "0" + txtLv22.Text
                End If
                txtLv22.BackColor = Color.White
            Else
                MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0065"), Me.Text)
                txtLv22.BackColor = Color.Red
                txtLv22.Text = String.Empty
            End If
        End If

        If Trim(txtLv22.Text) = "" Then
            txtLv21.Text = ""
            txtLv23.Text = ""
            txtLv24.Text = ""
            txtParentNo21.Text = ""
            txtParentNo22.Text = ""
            txtParentNo23.Text = ""
            txtParentNo24.Text = ""
        Else
            txtLv21.Text = txtLv11.Text
            txtLv23.Text = "00"
            txtLv24.Text = "00"
            txtParentNo21.Text = txtParentNo11.Text
            txtParentNo22.Text = txtParentNo12.Text
            txtParentNo23.Text = txtParentNo13.Text
            txtParentNo24.Text = txtParentNo14.Text
        End If

        '下のLevelをクリアする
        Me.txtLv31.Text = String.Empty
        Me.txtLv32.Text = String.Empty
        Me.txtLv33.Text = String.Empty
        Me.txtLv34.Text = String.Empty
        Me.txtPlanName3.Text = String.Empty
        Me.nudStartRowNo3.Value = 0
        Me.txtLv41.Text = String.Empty
        Me.txtLv42.Text = String.Empty
        Me.txtLv43.Text = String.Empty
        Me.txtLv44.Text = String.Empty
        Me.txtPlanName4.Text = String.Empty
        Me.nudStartRowNo4.Value = 0

    End Sub

    ''' <summary>
    ''' 機能：Leve33フォーカス移動時
    ''' 説明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub txtLv33_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLv33.Validated

        If IsPlanNoEmpty() Then
            txtLv33.Text = String.Empty
            Return
        End If

        If txtLv33.Text <> String.Empty Then
            If IsNumeric(txtLv33.Text) Then
                If txtLv33.Text.Length < 2 Then
                    txtLv33.Text = "0" + txtLv33.Text
                End If
                txtLv33.BackColor = Color.White
            Else
                MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0065"), Me.Text)
                txtLv33.BackColor = Color.Red
                txtLv33.Text = String.Empty
            End If
        End If

        If Trim(txtLv33.Text) = "" Then
        Else
            txtLv31.Text = txtLv21.Text
            txtLv32.Text = txtLv22.Text
            txtLv34.Text = "00"
            txtParentNo31.Text = txtLv21.Text
            txtParentNo32.Text = txtLv22.Text
            txtParentNo33.Text = txtLv23.Text
            txtParentNo34.Text = txtLv24.Text
        End If

        '下のLevelをクリアする
        Me.txtLv41.Text = String.Empty
        Me.txtLv42.Text = String.Empty
        Me.txtLv43.Text = String.Empty
        Me.txtLv44.Text = String.Empty
        Me.txtPlanName4.Text = String.Empty
        Me.nudStartRowNo4.Value = 0

    End Sub

    ''' <summary>
    ''' 機能：Leve44フォーカス移動時
    ''' 説明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub txtLv44_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLv44.Validated

        If IsPlanNoEmpty() Then
            txtLv44.Text = String.Empty
            Return
        End If

        If txtLv44.Text <> String.Empty Then
            If IsNumeric(txtLv44.Text) Then
                If txtLv44.Text.Length < 2 Then
                    txtLv44.Text = "0" + txtLv44.Text
                End If
                txtLv44.BackColor = Color.White
            Else
                MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0065"), Me.Text)
                txtLv44.BackColor = Color.Red
                txtLv44.Text = String.Empty
            End If
        End If

        If Trim(txtLv33.Text) = "" Then
            txtLv41.Text = ""
            txtLv42.Text = ""
            txtLv43.Text = ""
            txtParentNo41.Text = ""
            txtParentNo42.Text = ""
            txtParentNo43.Text = ""
            txtParentNo44.Text = ""
        Else
            txtLv41.Text = txtLv31.Text
            txtLv42.Text = txtLv32.Text
            txtLv43.Text = txtLv33.Text
            txtParentNo41.Text = txtLv31.Text
            txtParentNo42.Text = txtLv32.Text
            txtParentNo43.Text = txtLv33.Text
            txtParentNo44.Text = txtLv34.Text
        End If

    End Sub

    ''' <summary>
    ''' 機能：Xls出力ボタンの処理
    ''' 説明：
    ''' </summary>
    Private Sub BtnExportXls_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnExportXls.Click

        ''※例外処理補足：Btn_Click処理中の例外のメッセージは、Click関数のCatch句で処理する。
        Try

            ''ﾊﾟｽの取得
            Dim ofm As New OioFileManage
            Dim tmpFilePath As String       ''ﾃﾝﾌﾟﾚﾊﾟｽ 　※案件情報Importファイル
            Dim outFilePath As String       ''出力先ﾊﾟｽ　※案件情報Importファイル            
            tmpFilePath = ofm.GetLocalM_PLANTemplatePath
            outFilePath = ofm.GetLocalM_PLANPath(CommonVariable.CPNO, _
                                                 CommonVariable.CONTRACTNO, _
                                                 CommonVariable.CONTRACTNONAME)

            ''テンプレファイルの存在チェック
            If File.Exists(tmpFilePath) = False Then
                Call MsgBox(Prompt:=FileReader.GetMessage("MSG_0341") & vbCrLf & _
                                     tmpFilePath,
                            Buttons:=MsgBoxStyle.Critical,
                            Title:=Me.Text)
                Exit Sub
            End If


            '案件情報取得
            Dim blnRet As Boolean
            Dim strMsg As String = ""
            Dim wc As New WebDb.WebDbCommon
            Dim dt As New M_PLANTable
            Dim planTBL As New M_PLANTable

            '認証設定
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW
            blnRet = wc.GetPlanData(CommonVariable.CPNO, dt, strMsg)
            If blnRet = False Then
                MsgBox(strMsg, vbCritical, "BtnExportXls_Click")
                Exit Sub
            End If
            'ソート
            Dim rows() As DataRow
            rows = dt.Select(Nothing, "LEVEL1,LEVEL2,LEVEL3,LEVEL4")
            For Each row As DataRow In rows
                planTBL.ImportRow(row)
            Next

            ''案件情報用Importﾌｧｲﾙを作成
            Call CreatePlanImportFile(planTBL, tmpFilePath, outFilePath)


            ''処理の完了メッセージ
            Call MsgBox(Prompt:=FileReader.GetMessage("MSG_0344") & vbCrLf & _
                                "  " & System.IO.Path.GetFileName(outFilePath),
                        Buttons:=MsgBoxStyle.Information,
                        Title:=Me.Text)

        Catch ex As Exception
            Call MsgBox(ex.Message,
                        Buttons:=MsgBoxStyle.Critical,
                        Title:=Me.Text)

        End Try

    End Sub

    ''' <summary>
    ''' 機能：Xls取込ボタンの処理
    ''' 説明：
    ''' </summary>
    Private Sub BtnImportXls_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnImportXls.Click

        Try

            Dim readFilePath As String       ''出力先ﾊﾟｽ　※案件情報Importファイル            

            ''ファイル参照のダイアルボックス表示
            Const Filter As String = "案件情報 ﾌｧｲﾙ (*.xlsm)|*.xlsm"
            Dim ofm As New OioFileManage
            Dim dialog As New OpenFileDialog
            dialog.Filter = Filter
            dialog.InitialDirectory = ofm.GetLocalOutputCPNOFolder(CommonVariable.CPNO, _
                                                                   CommonVariable.CONTRACTNO)

            If dialog.ShowDialog() = DialogResult.OK Then


                ''ファイル名取得
                readFilePath = dialog.FileName


                ''ExcelファイルのOpenチェック
                If ofm.ChkOpenedExcelFile(readFilePath) = False Then
                    Call MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0325") & vbCrLf & vbCrLf _
                                                  & "ファイル名：" & Path.GetFileName(readFilePath), Me.Text)
                    Exit Sub

                End If


                ''Excelファイルからデータを取得する。
                Dim planTBL As M_PLANTable
                Call GetXLSM_PLANData(readFilePath, planTBL)


                ''XLS情報をMDBにInsertする。
                Call InsertPlanTBL(planTBL)

                ''          以下、Import結果を画面に表示する。
                ''-------------------------------------------------
                'テーブルを最新に更新
                Call Me.Reflesh()

                '初期表示
                Call SetIniDisp()

                'ツリー表示
                Dim blnRet As Boolean
                blnRet = SetTree()

                '画面の値をセットする
                Call SetDisplayValue()


                ''完了メッセージ
                MsgBox(Prompt:=FileReader.GetMessage("MSG_0353"), _
                       Buttons:=vbInformation, _
                       Title:=Me.Text)

            End If

        Catch ex As Exception
            MsgBox(Prompt:=FileReader.GetMessage("MSG_0345") & vbCrLf & _
                           vbCrLf & _
                           ex.Message, _
                   Buttons:=vbCritical, _
                   Title:=Me.Text)
        End Try

    End Sub

    ''' <summary>
    ''' 機能：登録/更新ボタン押下
    ''' 説明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click

        Dim blnRet As Boolean

        '入力チェック
        If CheckInput() = False Then
            Return
        End If

        '登録更新
        Try
            Dim isrnsu As Boolean = False
            Dim ispnu As Boolean = False
            'Level1の行
            If IsRowNoStartUpdate(Me.txtLv11, Me.txtLv12, Me.txtLv13, Me.txtLv14, Me.txtPlanName1, Me.nudStartRowNo1) Then
                isrnsu = True
                Me.nudStartRowNo1.BackColor = Color.Red
            Else
                Me.nudStartRowNo1.BackColor = Color.White
                If IsPlanNameUpdate(Me.txtLv11, Me.txtLv12, Me.txtLv13, Me.txtLv14, Me.txtPlanName1, Me.nudStartRowNo1) Then
                    'ispnu = True
                    Me.txtPlanName1.BackColor = Color.White
                    RegistTable(Me.txtLv11, Me.txtLv12, Me.txtLv13, Me.txtLv14, Me.txtPlanName1, Me.nudStartRowNo1, 1)
                Else
                    Me.txtPlanName1.BackColor = Color.White
                    RegistTable(Me.txtLv11, Me.txtLv12, Me.txtLv13, Me.txtLv14, Me.txtPlanName1, Me.nudStartRowNo1, 1)
                End If
            End If

            'Level2の行
            If IsRowNoStartUpdate(Me.txtLv21, Me.txtLv22, Me.txtLv23, Me.txtLv24, Me.txtPlanName2, Me.nudStartRowNo2) Then
                isrnsu = True
                Me.nudStartRowNo2.BackColor = Color.Red
            Else
                Me.nudStartRowNo2.BackColor = Color.White
                If IsPlanNameUpdate(Me.txtLv21, Me.txtLv22, Me.txtLv23, Me.txtLv24, Me.txtPlanName2, Me.nudStartRowNo2) Then
                    'ispnu = True
                    Me.txtPlanName2.BackColor = Color.White
                    RegistTable(Me.txtLv21, Me.txtLv22, Me.txtLv23, Me.txtLv24, Me.txtPlanName2, Me.nudStartRowNo2, 2)
                Else
                    Me.txtPlanName2.BackColor = Color.White
                    RegistTable(Me.txtLv21, Me.txtLv22, Me.txtLv23, Me.txtLv24, Me.txtPlanName2, Me.nudStartRowNo2, 2)
                End If
            End If

            'Level3の行
            If IsRowNoStartUpdate(Me.txtLv31, Me.txtLv32, Me.txtLv33, Me.txtLv34, Me.txtPlanName3, Me.nudStartRowNo3) Then
                isrnsu = True
                Me.nudStartRowNo3.BackColor = Color.Red
            Else
                Me.nudStartRowNo3.BackColor = Color.White
                If IsPlanNameUpdate(Me.txtLv31, Me.txtLv32, Me.txtLv33, Me.txtLv34, Me.txtPlanName3, Me.nudStartRowNo3) Then
                    'ispnu = True
                    Me.txtPlanName3.BackColor = Color.White
                    RegistTable(Me.txtLv31, Me.txtLv32, Me.txtLv33, Me.txtLv34, Me.txtPlanName3, Me.nudStartRowNo3, 3)
                Else
                    Me.txtPlanName3.BackColor = Color.White
                    RegistTable(Me.txtLv31, Me.txtLv32, Me.txtLv33, Me.txtLv34, Me.txtPlanName3, Me.nudStartRowNo3, 3)
                End If

            End If

            'Level4の行
            If IsRowNoStartUpdate(Me.txtLv41, Me.txtLv42, Me.txtLv43, Me.txtLv44, Me.txtPlanName4, Me.nudStartRowNo4) Then
                isrnsu = True
                Me.nudStartRowNo4.BackColor = Color.Red
            Else
                Me.nudStartRowNo4.BackColor = Color.White
                RegistTable(Me.txtLv41, Me.txtLv42, Me.txtLv43, Me.txtLv44, Me.txtPlanName4, Me.nudStartRowNo4, 4)
            End If

            If isrnsu Then
                MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0066"), Me.Text)
                Return
            End If

            If ispnu Then
                MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0067") + vbCrLf + FileReader.GetMessage("MSG_0068"), Me.Text)
                Return
            End If

            '展開しているNode名を取得
            Dim expandNodeNM As ArrayList
            expandNodeNM = GetExpandAllNodes(Me.tvPlan.Nodes)

            '画面で登録したNode名を追加
            Call SetFrmNodeNm(expandNodeNM)

            'テーブル最新情報取得
            Reflesh()

            'ツリー再表示
            blnRet = SetTreeNotExpand(expandNodeNM)

            '項目をリセット
            SetIniDisp()

            '画面の値をセットする
            Call SetDisplayValue()

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "")
        End Try

    End Sub

    ''' <summary>
    ''' ノードクリック
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub tvPlan_NodeMouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeNodeMouseClickEventArgs) Handles tvPlan.NodeMouseClick

        Dim pntMouseClick As Point

        pntMouseClick.X = e.X
        pntMouseClick.Y = e.Y
        Me.tvPlan.SelectedNode = Me.tvPlan.GetNodeAt(pntMouseClick)

        Dim strFullPath As String = tvPlan.SelectedNode.FullPath    '選択されたノードのフルパス
        Dim Plan(0 To 3) As Plan                                    '
        Dim blnRet As Boolean                                       '

        'フルパスを分解・データ取得
        blnRet = SplitPlan(strFullPath, Plan)
        If blnRet = False Then
            Exit Sub
        End If

        '開始行番を取得
        blnRet = GetStartRowNo(Plan)
        If blnRet = False Then
            Exit Sub
        End If

        '上段の入力エリアに表示する
        blnRet = DispTreeData(Plan)
        If blnRet = False Then
            Exit Sub
        End If

        '画面の値をセットする
        Call SetDisplayValue()

    End Sub

    ''' <summary>
    ''' 機能：戻るボタン押下
    ''' 説明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnReturn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReturn.Click

        Dim blnRet As Boolean

        '画面の変更前の値と現在の値を比較する(True:一致　False:不一致)
        blnRet = isDisplayValue()
        If blnRet = False Then
            If MessageBox.Show(FileReader.GetMessage("MSG_0071"), Me.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = DialogResult.No Then
                Exit Sub
            End If
        End If

        Dim frm As New Frm_Menu()

        Me.Hide()
        frm.ShowDialog()
        Me.Close()

    End Sub


    ''' <summary>
    ''' 機能：画面リセットボタン押下
    ''' 説明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReset.Click

        '初期表示
        Call SetIniDisp()

        '画面の値をセットする
        Call SetDisplayValue()

    End Sub

    ''' <summary>
    ''' 機能：ログアウトボタン押下
    ''' 説明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnLogOut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogOut.Click

        Dim blnRet As Boolean

        '画面の変更前の値と現在の値を比較する(True:一致　False:不一致)
        blnRet = isDisplayValue()
        If blnRet = False Then
            If MessageBox.Show(FileReader.GetMessage("MSG_0071"), Me.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = DialogResult.No Then
                Exit Sub
            End If
        End If

        Me.Close()

    End Sub

    ''' <summary>
    ''' 機能：削除ボタンLV1
    ''' 説明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Btn_DelLv1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_DelLv1.Click

        ''案件情報削除
        Call Me.deletePlanMdb(DelLev_1)

        ''削除終了メッセージ表示
        Call MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0268"), Me.Text)

        ''画面の初期化
        Call Frm_Plan_Load(sender, e)

    End Sub

    ''' <summary>
    ''' 機能：削除ボタンLV2
    ''' 説明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Btn_DelLv2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_DelLv2.Click

        ''案件情報削除
        Call Me.deletePlanMdb(DelLev_2)

        ''削除終了メッセージ表示
        Call MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0268"), Me.Text)

        ''画面の初期化
        Call Frm_Plan_Load(sender, e)

    End Sub


    ''' <summary>
    ''' 機能：削除ボタンLV3
    ''' 説明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Btn_DelLv3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_DelLv3.Click

        ''案件情報削除
        Call Me.deletePlanMdb(DelLev_3)

        ''削除終了メッセージ表示
        Call MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0268"), Me.Text)

        ''画面の初期化
        Call Frm_Plan_Load(sender, e)

    End Sub

    ''' <summary>
    ''' 機能：削除ボタンLV4
    ''' 説明：
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Btn_DelLv4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_DelLv4.Click

        ''案件情報削除
        Call Me.deletePlanMdb(DelLev_4)

        ''削除終了メッセージ表示
        Call MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0268"), Me.Text)

        ''画面の初期化
        Call Frm_Plan_Load(sender, e)

    End Sub
#End Region

#Region "プライベートメソッド "
    ''' <summary>
    ''' 機能：初期表示
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetIniDisp()

        '案件番号（Level1-4）
        txtLv11.Text = ""
        txtLv12.Text = ""
        txtLv13.Text = ""
        txtLv14.Text = ""
        txtLv21.Text = ""
        txtLv22.Text = ""
        txtLv23.Text = ""
        txtLv24.Text = ""
        txtLv31.Text = ""
        txtLv32.Text = ""
        txtLv33.Text = ""
        txtLv34.Text = ""
        txtLv41.Text = ""
        txtLv42.Text = ""
        txtLv43.Text = ""
        txtLv44.Text = ""
        txtLv11.BackColor = Color.White
        txtLv22.BackColor = Color.White
        txtLv33.BackColor = Color.White
        txtLv44.BackColor = Color.White

        '案件名（Level1-4）
        txtPlanName1.Text = ""
        txtPlanName2.Text = ""
        txtPlanName3.Text = ""
        txtPlanName4.Text = ""
        txtPlanName1.BackColor = Color.White
        txtPlanName2.BackColor = Color.White
        txtPlanName3.BackColor = Color.White
        txtPlanName4.BackColor = Color.White

        '親案件番号
        txtParentNo11.Text = ""
        txtParentNo21.Text = ""
        txtParentNo31.Text = ""
        txtParentNo41.Text = ""

        '開始行番
        nudStartRowNo1.Value = 0
        nudStartRowNo2.Value = 0
        nudStartRowNo3.Value = 0
        nudStartRowNo4.Value = 0
        nudStartRowNo1.BackColor = Color.White
        nudStartRowNo2.BackColor = Color.White
        nudStartRowNo3.BackColor = Color.White
        nudStartRowNo4.BackColor = Color.White

    End Sub

    ''' <summary>
    ''' ツリーの表示
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function SetTree() As Boolean
        Dim i As Integer
        Dim strLevel1 As String
        Dim strLevel2 As String
        Dim strLevel3 As String
        Dim strLevel4 As String
        Dim tnLevel1 As TreeNode
        Dim tnLevel2() As TreeNode
        Dim tnLevel3() As TreeNode
        Dim tnLevel4() As TreeNode
        Dim levelTitle As New StringBuilder

        Me.tvPlan.Nodes.Clear()

        For i = 0 To Me.tbPlan.Rows.Count - 1
            tnLevel1 = Nothing

            'Level1のレコードを取得
            If Me.tbPlan.Rows(i)("LEVEL2").ToString() = "00" _
                And Me.tbPlan.Rows(i)("LEVEL3").ToString() = "00" _
                And Me.tbPlan.Rows(i)("LEVEL4").ToString() = "00" Then

                strLevel1 = Me.tbPlan.Rows(i)("LEVEL1").ToString()

                'Level2のレコードを取得
                Dim j As Integer
                Dim cntLevel2 As Integer = 0
                For j = 0 To Me.tbPlan.Rows.Count - 1
                    If Me.tbPlan.Rows(j)("LEVEL1").ToString() = strLevel1 _
                        And Me.tbPlan.Rows(j)("LEVEL2").ToString() <> "00" _
                        And Me.tbPlan.Rows(j)("LEVEL3").ToString() = "00" _
                        And Me.tbPlan.Rows(j)("LEVEL4").ToString() = "00" Then

                        strLevel2 = Me.tbPlan.Rows(j)("LEVEL2").ToString()

                        'Level3のレコードを取得
                        Dim k As Integer
                        Dim cntLevel3 As Integer = 0
                        For k = 0 To Me.tbPlan.Rows.Count - 1
                            If Me.tbPlan.Rows(k)("LEVEL1").ToString() = strLevel1 _
                                And Me.tbPlan.Rows(k)("LEVEL2").ToString() = strLevel2 _
                                And Me.tbPlan.Rows(k)("LEVEL3").ToString() <> "00" _
                                And Me.tbPlan.Rows(k)("LEVEL4").ToString() = "00" Then

                                strLevel3 = Me.tbPlan.Rows(k)("LEVEL3").ToString()

                                'Level4のレコードを取得
                                Dim l As Integer
                                Dim cntLevel4 As Integer = 0
                                For l = 0 To Me.tbPlan.Rows.Count - 1
                                    If Me.tbPlan.Rows(l)("LEVEL1").ToString() = strLevel1 _
                                        And Me.tbPlan.Rows(l)("LEVEL2").ToString() = strLevel2 _
                                        And Me.tbPlan.Rows(l)("LEVEL3").ToString() = strLevel3 _
                                        And Me.tbPlan.Rows(l)("LEVEL4").ToString() <> "00" Then

                                        ReDim Preserve tnLevel4(cntLevel4)
                                        levelTitle.Length = 0
                                        levelTitle.Append(Me.tbPlan.Rows(l)("LEVEL1").ToString() + ".")
                                        levelTitle.Append(Me.tbPlan.Rows(l)("LEVEL2").ToString() + ".")
                                        levelTitle.Append(Me.tbPlan.Rows(l)("LEVEL3").ToString() + ".")
                                        levelTitle.Append(Me.tbPlan.Rows(l)("LEVEL4").ToString() + "_")
                                        levelTitle.Append(Me.tbPlan.Rows(l)("PLAN_NAME").ToString())

                                        tnLevel4(cntLevel4) = New TreeNode(levelTitle.ToString())
                                        cntLevel4 += 1

                                    End If

                                Next

                                ReDim Preserve tnLevel3(cntLevel3)
                                levelTitle.Length = 0
                                levelTitle.Append(Me.tbPlan.Rows(k)("LEVEL1").ToString() + ".")
                                levelTitle.Append(Me.tbPlan.Rows(k)("LEVEL2").ToString() + ".")
                                levelTitle.Append(Me.tbPlan.Rows(k)("LEVEL3").ToString() + "_")
                                levelTitle.Append(Me.tbPlan.Rows(k)("PLAN_NAME").ToString())

                                If tnLevel4 Is Nothing Then
                                    tnLevel3(cntLevel3) = New TreeNode(levelTitle.ToString())
                                Else
                                    tnLevel3(cntLevel3) = New TreeNode(levelTitle.ToString(), tnLevel4)
                                    tnLevel4 = Nothing
                                End If
                                cntLevel3 += 1

                            End If
                        Next

                        ReDim Preserve tnLevel2(cntLevel2)
                        levelTitle.Length = 0
                        levelTitle.Append(Me.tbPlan.Rows(j)("LEVEL1").ToString() + ".")
                        levelTitle.Append(Me.tbPlan.Rows(j)("LEVEL2").ToString() + "_")
                        levelTitle.Append(Me.tbPlan.Rows(j)("PLAN_NAME").ToString())

                        If tnLevel3 Is Nothing Then
                            tnLevel2(cntLevel2) = New TreeNode(levelTitle.ToString())
                        Else
                            tnLevel2(cntLevel2) = New TreeNode(levelTitle.ToString(), tnLevel3)
                            tnLevel3 = Nothing
                        End If
                        cntLevel2 += 1

                    End If
                Next

                levelTitle.Length = 0
                levelTitle.Append(Me.tbPlan.Rows(i)("LEVEL1").ToString() + "_")
                levelTitle.Append(Me.tbPlan.Rows(i)("PLAN_NAME").ToString())

                If tnLevel2 Is Nothing Then
                    tnLevel1 = New TreeNode(levelTitle.ToString())
                Else
                    tnLevel1 = New TreeNode(levelTitle.ToString(), tnLevel2)
                    tnLevel2 = Nothing
                End If

                Me.tvPlan.Nodes.Add(tnLevel1)

            End If

        Next

        'ツリー展開
        Me.tvPlan.ExpandAll()

        SetTree = True

    End Function

    ''' <summary>
    ''' ツリーの表示　
    ''' ※登録したデータ以外のNodeは展開しない。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function SetTreeNotExpand(ByVal ExpandNM As ArrayList) As Boolean
        Dim i As Integer
        Dim strLevel1 As String
        Dim strLevel2 As String
        Dim strLevel3 As String
        Dim strLevel4 As String
        Dim tnLevel1 As TreeNode
        Dim tnLevel2() As TreeNode
        Dim tnLevel3() As TreeNode
        Dim tnLevel4() As TreeNode
        Dim levelTitle As New StringBuilder

        Me.tvPlan.Nodes.Clear()

        For i = 0 To Me.tbPlan.Rows.Count - 1
            tnLevel1 = Nothing

            'Level1のレコードを取得
            If Me.tbPlan.Rows(i)("LEVEL2").ToString() = "00" _
                And Me.tbPlan.Rows(i)("LEVEL3").ToString() = "00" _
                And Me.tbPlan.Rows(i)("LEVEL4").ToString() = "00" Then

                strLevel1 = Me.tbPlan.Rows(i)("LEVEL1").ToString()

                'Level2のレコードを取得
                Dim j As Integer
                Dim cntLevel2 As Integer = 0
                For j = 0 To Me.tbPlan.Rows.Count - 1
                    If Me.tbPlan.Rows(j)("LEVEL1").ToString() = strLevel1 _
                        And Me.tbPlan.Rows(j)("LEVEL2").ToString() <> "00" _
                        And Me.tbPlan.Rows(j)("LEVEL3").ToString() = "00" _
                        And Me.tbPlan.Rows(j)("LEVEL4").ToString() = "00" Then

                        strLevel2 = Me.tbPlan.Rows(j)("LEVEL2").ToString()

                        'Level3のレコードを取得
                        Dim k As Integer
                        Dim cntLevel3 As Integer = 0
                        For k = 0 To Me.tbPlan.Rows.Count - 1
                            If Me.tbPlan.Rows(k)("LEVEL1").ToString() = strLevel1 _
                                And Me.tbPlan.Rows(k)("LEVEL2").ToString() = strLevel2 _
                                And Me.tbPlan.Rows(k)("LEVEL3").ToString() <> "00" _
                                And Me.tbPlan.Rows(k)("LEVEL4").ToString() = "00" Then

                                strLevel3 = Me.tbPlan.Rows(k)("LEVEL3").ToString()

                                'Level4のレコードを取得
                                Dim l As Integer
                                Dim cntLevel4 As Integer = 0
                                For l = 0 To Me.tbPlan.Rows.Count - 1
                                    If Me.tbPlan.Rows(l)("LEVEL1").ToString() = strLevel1 _
                                        And Me.tbPlan.Rows(l)("LEVEL2").ToString() = strLevel2 _
                                        And Me.tbPlan.Rows(l)("LEVEL3").ToString() = strLevel3 _
                                        And Me.tbPlan.Rows(l)("LEVEL4").ToString() <> "00" Then

                                        ReDim Preserve tnLevel4(cntLevel4)
                                        levelTitle.Length = 0
                                        levelTitle.Append(Me.tbPlan.Rows(l)("LEVEL1").ToString() + ".")
                                        levelTitle.Append(Me.tbPlan.Rows(l)("LEVEL2").ToString() + ".")
                                        levelTitle.Append(Me.tbPlan.Rows(l)("LEVEL3").ToString() + ".")
                                        levelTitle.Append(Me.tbPlan.Rows(l)("LEVEL4").ToString() + "_")
                                        levelTitle.Append(Me.tbPlan.Rows(l)("PLAN_NAME").ToString())

                                        tnLevel4(cntLevel4) = New TreeNode(levelTitle.ToString())
                                        If ExpandNM.IndexOf(levelTitle.ToString()) <> -1 Then
                                            tnLevel4(cntLevel4).Expand()
                                        End If
                                        cntLevel4 += 1

                                    End If

                                Next

                                ReDim Preserve tnLevel3(cntLevel3)
                                levelTitle.Length = 0
                                levelTitle.Append(Me.tbPlan.Rows(k)("LEVEL1").ToString() + ".")
                                levelTitle.Append(Me.tbPlan.Rows(k)("LEVEL2").ToString() + ".")
                                levelTitle.Append(Me.tbPlan.Rows(k)("LEVEL3").ToString() + "_")
                                levelTitle.Append(Me.tbPlan.Rows(k)("PLAN_NAME").ToString())

                                If tnLevel4 Is Nothing Then
                                    tnLevel3(cntLevel3) = New TreeNode(levelTitle.ToString())
                                Else
                                    tnLevel3(cntLevel3) = New TreeNode(levelTitle.ToString(), tnLevel4)
                                    tnLevel4 = Nothing
                                End If

                                If ExpandNM.IndexOf(levelTitle.ToString()) <> -1 Then
                                    tnLevel3(cntLevel3).Expand()
                                End If
                                cntLevel3 += 1

                            End If
                        Next

                        ReDim Preserve tnLevel2(cntLevel2)
                        levelTitle.Length = 0
                        levelTitle.Append(Me.tbPlan.Rows(j)("LEVEL1").ToString() + ".")
                        levelTitle.Append(Me.tbPlan.Rows(j)("LEVEL2").ToString() + "_")
                        levelTitle.Append(Me.tbPlan.Rows(j)("PLAN_NAME").ToString())

                        If tnLevel3 Is Nothing Then
                            tnLevel2(cntLevel2) = New TreeNode(levelTitle.ToString())
                        Else
                            tnLevel2(cntLevel2) = New TreeNode(levelTitle.ToString(), tnLevel3)
                            tnLevel3 = Nothing
                        End If

                        If ExpandNM.IndexOf(levelTitle.ToString()) <> -1 Then
                            tnLevel2(cntLevel2).Expand()
                        End If

                        cntLevel2 += 1

                    End If
                Next

                levelTitle.Length = 0
                levelTitle.Append(Me.tbPlan.Rows(i)("LEVEL1").ToString() + "_")
                levelTitle.Append(Me.tbPlan.Rows(i)("PLAN_NAME").ToString())

                If tnLevel2 Is Nothing Then
                    tnLevel1 = New TreeNode(levelTitle.ToString())
                Else
                    tnLevel1 = New TreeNode(levelTitle.ToString(), tnLevel2)
                    tnLevel2 = Nothing
                End If

                If ExpandNM.IndexOf(levelTitle.ToString()) <> -1 Then
                    tnLevel1.Expand()
                End If

                Me.tvPlan.Nodes.Add(tnLevel1)

            End If

        Next

        SetTreeNotExpand = True

    End Function

    ''' <summary>
    ''' 機能：入力チェック
    ''' 説明：
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckInput() As Boolean

        CheckInput = True

        Dim chkPlanName As Boolean = True
        Dim chkPlanNoInput As Boolean = True

        '全項目空白チェック
        If Me.txtLv11.Text.Trim = "" And _
            Me.txtLv22.Text.Trim = "" And _
            Me.txtLv33.Text.Trim = "" And _
            Me.txtLv44.Text.Trim = "" And _
            Me.txtPlanName1.Text.Trim = "" And _
            Me.txtPlanName2.Text.Trim = "" And _
            Me.txtPlanName3.Text.Trim = "" And _
            Me.txtPlanName4.Text.Trim = "" Then
            Return False
        End If

        '案件番号抜けチェック
        If IsPlanNoEmpty() Then
            Return False
        End If

        '案件名入力チェック
        If Not Me.txtLv11.Text = String.Empty Then
            If Me.txtPlanName1.Text = String.Empty Then
                Me.txtPlanName1.BackColor = Color.Red
                chkPlanName = False
            Else
                Me.txtPlanName1.BackColor = Color.White
            End If
        End If
        If Not Me.txtLv22.Text = String.Empty Then
            If Me.txtPlanName2.Text = String.Empty Then
                Me.txtPlanName2.BackColor = Color.Red
                chkPlanName = False
            Else
                Me.txtPlanName2.BackColor = Color.White
            End If
        End If
        If Not Me.txtLv33.Text = String.Empty Then
            If Me.txtPlanName3.Text = String.Empty Then
                Me.txtPlanName3.BackColor = Color.Red
                chkPlanName = False
            Else
                Me.txtPlanName3.BackColor = Color.White
            End If
        End If
        If Not Me.txtLv44.Text = String.Empty Then
            If Me.txtPlanName4.Text = String.Empty Then
                Me.txtPlanName4.BackColor = Color.Red
                chkPlanName = False
            Else
                Me.txtPlanName4.BackColor = Color.White
            End If
        End If
        If Not chkPlanName Then
            MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0069"), Me.Text)
            Return False
        End If

        '案件番号入力チェック
        If Not Me.txtPlanName1.Text = String.Empty Then
            If Me.txtLv11.Text = String.Empty Then
                Me.txtLv11.BackColor = Color.Red
                chkPlanNoInput = False
            Else
                Me.txtLv11.BackColor = Color.White
            End If
        End If
        If Not Me.txtPlanName2.Text = String.Empty Then
            If Me.txtLv22.Text = String.Empty Then
                Me.txtLv22.BackColor = Color.Red
                chkPlanNoInput = False
            Else
                Me.txtLv22.BackColor = Color.White
            End If
        End If
        If Not Me.txtPlanName3.Text = String.Empty Then
            If Me.txtLv33.Text = String.Empty Then
                Me.txtLv33.BackColor = Color.Red
                chkPlanNoInput = False
            Else
                Me.txtLv33.BackColor = Color.White
            End If
        End If
        If Not Me.txtPlanName4.Text = String.Empty Then
            If Me.txtLv44.Text = String.Empty Then
                Me.txtLv44.BackColor = Color.Red
                chkPlanNoInput = False
            Else
                Me.txtLv44.BackColor = Color.White
            End If
        End If
        If Not chkPlanNoInput Then
            MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0070"), Me.Text)
            Return False
        End If

    End Function

    ''' <summary>
    ''' 機能：フルパス分解・データ取得
    ''' 説明：
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function SplitPlan(ByVal strOrignal As String, ByRef Plan() As Plan) As Boolean

        Dim strSplitData(0 To 3) As String              '管理番号、案件名、親案件番号
        Dim intCnt As Integer
        Dim intIndex As Integer = 0
        Dim strLine(0 To 3) As String
        Dim intPos As Integer
        Dim intGPos As Integer
        Dim strWork As String

        SplitPlan = False

        Try
            '初期化
            For intCnt = 0 To 3
                strSplitData(intCnt) = ""
                Plan(intCnt).Name = ""
                Plan(intCnt).No1 = ""
                Plan(intCnt).No2 = ""
                Plan(intCnt).No3 = ""
                Plan(intCnt).No4 = ""
                Plan(intCnt).ParentNo1 = ""
                Plan(intCnt).ParentNo2 = ""
                Plan(intCnt).ParentNo3 = ""
                Plan(intCnt).ParentNo4 = ""
                Plan(intCnt).PrintF = False
            Next

            'TAG分解
            strSplitData = strOrignal.Split("\")

            '値設定
            For intCnt = 0 To (strSplitData.Length - 1)
                If strSplitData(intCnt) = "" Then
                    Exit For
                End If

                '案件番号
                intPos = InStr(strSplitData(intCnt), "_")
                intGPos = InStr(strSplitData(intCnt), " ")
                If strLine.Length > 0 Then
                    strWork = Mid(strSplitData(intCnt), 1, intPos - 1)
                    If intPos > 2 Then
                        Plan(intIndex).No1 = Mid(strWork, 1, 2)
                    Else
                        Plan(intIndex).No1 = "00"
                    End If
                    If intPos > 4 Then
                        Plan(intIndex).No2 = Mid(strWork, 4, 2)
                    Else
                        Plan(intIndex).No2 = "00"
                    End If
                    If intPos > 7 Then
                        Plan(intIndex).No3 = Mid(strWork, 7, 2)
                    Else
                        Plan(intIndex).No3 = "00"
                    End If
                    If intPos > 10 Then
                        Plan(intIndex).No4 = Mid(strWork, 10, 2)
                    Else
                        Plan(intIndex).No4 = "00"
                    End If
                End If

                '案件名
                Plan(intIndex).Name = Mid(strSplitData(intCnt), intPos + 1)

                '集計フラグ
                Plan(intIndex).PrintF = False
                intIndex = intIndex + 1
            Next
        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical)
        End Try

        SplitPlan = True

    End Function

    ''' <summary>
    ''' 機能：ツリービューデータ表示
    ''' 説明：
    ''' </summary>
    ''' <param name="Plan"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function DispTreeData(ByVal Plan() As Plan) As Boolean

        DispTreeData = False

        Try
            'LEVEL1
            txtLv11.Text = Plan(0).No1
            txtLv12.Text = Plan(0).No2
            txtLv13.Text = Plan(0).No3
            txtLv14.Text = Plan(0).No4
            txtPlanName1.Text = Plan(0).Name
            txtParentNo11.Text = Plan(0).ParentNo1
            txtParentNo12.Text = Plan(0).ParentNo2
            txtParentNo13.Text = Plan(0).ParentNo3
            txtParentNo14.Text = Plan(0).ParentNo4
            nudStartRowNo1.Value = Plan(0).StartRowNo
            'LEVEL2
            txtLv21.Text = Plan(1).No1
            txtLv22.Text = Plan(1).No2
            txtLv23.Text = Plan(1).No3
            txtLv24.Text = Plan(1).No4
            txtPlanName2.Text = Plan(1).Name
            txtParentNo21.Text = Plan(1).ParentNo1
            txtParentNo22.Text = Plan(1).ParentNo2
            txtParentNo23.Text = Plan(1).ParentNo3
            txtParentNo24.Text = Plan(1).ParentNo4
            nudStartRowNo2.Value = Plan(1).StartRowNo
            'LEVEL3
            txtLv31.Text = Plan(2).No1
            txtLv32.Text = Plan(2).No2
            txtLv33.Text = Plan(2).No3
            txtLv34.Text = Plan(2).No4
            txtPlanName3.Text = Plan(2).Name
            txtParentNo31.Text = Plan(2).ParentNo1
            txtParentNo32.Text = Plan(2).ParentNo2
            txtParentNo33.Text = Plan(2).ParentNo3
            txtParentNo34.Text = Plan(2).ParentNo4
            nudStartRowNo3.Value = Plan(2).StartRowNo
            'LEVEL4
            txtLv41.Text = Plan(3).No1
            txtLv42.Text = Plan(3).No2
            txtLv43.Text = Plan(3).No3
            txtLv44.Text = Plan(3).No4
            txtPlanName4.Text = Plan(3).Name
            txtParentNo41.Text = Plan(3).ParentNo1
            txtParentNo42.Text = Plan(3).ParentNo2
            txtParentNo43.Text = Plan(3).ParentNo3
            txtParentNo44.Text = Plan(3).ParentNo4
            nudStartRowNo4.Value = Plan(3).StartRowNo

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical)
        End Try


        DispTreeData = True

    End Function

    ''' <summary>
    ''' リフレッシュ
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Reflesh()

        Dim wc As New WebDb.WebDbCommon
        Dim dt As New M_PLANTable
        Dim strMsg As String = ""
        Dim blnRet As Boolean

        Try
            '認証設定
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW
            '案件情報取得
            blnRet = wc.GetPlanData(CommonVariable.CPNO, dt, strMsg)
            If blnRet = False Then
                MsgBox(strMsg, vbCritical, "Reflesh")
                Exit Sub
            End If
            'ソート
            Dim rows() As DataRow
            rows = dt.Select(Nothing, "LEVEL1,LEVEL2,LEVEL3,LEVEL4")
            tbPlan = New M_PLANTable
            For Each row As DataRow In rows
                tbPlan.ImportRow(row)
            Next

        Catch ex As Exception
            MsgBox(ex.Message.ToString, "Reflesh")
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' 機能：テーブル登録
    ''' </summary>
    ''' <param name="txtLv1"></param>
    ''' <param name="txtLv2"></param>
    ''' <param name="txtLv3"></param>
    ''' <param name="txtLv4"></param>
    ''' <param name="txtPlanName"></param>
    ''' <param name="nudStartRowNo"></param>
    ''' <param name="flgLevel"></param>
    ''' <remarks></remarks>
    Private Sub RegistTable(ByVal txtLv1 As TextBox, _
                            ByVal txtLv2 As TextBox, _
                            ByVal txtLv3 As TextBox, _
                            ByVal txtLv4 As TextBox, _
                            ByVal txtPlanName As TextBox, _
                            ByVal nudStartRowNo As NumericUpDown, _
                            ByVal flgLevel As Integer)

        Dim strLevel As String = ""

        Select Case flgLevel
            Case 1
                strLevel = txtLv1.Text
            Case 2
                strLevel = txtLv2.Text
            Case 3
                strLevel = txtLv3.Text
            Case 4
                strLevel = txtLv4.Text
        End Select

        If strLevel <> String.Empty And 0 < strLevel.Length Then
            Dim sqlCommand As New StringBuilder
            ''LV1～3は案件番号がマッチした場合、Update
            ''LV4　 は案件番号 + 名称がマッチした場合、Update
            Dim chkupdate As Boolean = False
            Dim rows() As DataRow
            Select Case flgLevel
                Case 1
                    rows = IsUpdate(txtLv1, txtLv2, txtLv3, txtLv4)
                    If 0 < rows.Length Then
                        chkupdate = True
                    End If
                Case 2
                    rows = IsUpdate(txtLv1, txtLv2, txtLv3, txtLv4)
                    If 0 < rows.Length Then
                        chkupdate = True
                    End If
                Case 3
                    rows = IsUpdate(txtLv1, txtLv2, txtLv3, txtLv4)
                    If 0 < rows.Length Then
                        chkupdate = True
                    End If
                Case 4
                    rows = IsUpdate(txtLv1, txtLv2, txtLv3, txtLv4, txtPlanName)
                    If 0 < rows.Length Then
                        chkupdate = True
                    End If
            End Select

            Dim wc As New WebDb.WebDbCommon
            Dim dt As New M_PLANTable
            Dim strMsg As String = ""
            Dim blnRet As Boolean

            'データセット
            Dim row As DataRow = dt.NewRow
            row(M_PLANTable.COLUMN_NAME_CPNO) = CommonVariable.CPNO
            If chkupdate = False Then
                row(M_PLANTable.COLUMN_NAME_PLAN_NAME) = txtPlanName.Text.Trim
            Else
                row(M_PLANTable.COLUMN_NAME_PLAN_NAME) = rows(0).Item(M_PLANTable.COLUMN_NAME_PLAN_NAME)
            End If
            row(M_PLANTable.COLUMN_NAME_LEVEL1) = txtLv1.Text.Trim
            row(M_PLANTable.COLUMN_NAME_LEVEL2) = txtLv2.Text.Trim
            row(M_PLANTable.COLUMN_NAME_LEVEL3) = txtLv3.Text.Trim
            row(M_PLANTable.COLUMN_NAME_LEVEL4) = txtLv4.Text.Trim
            dt.Rows.Add(row)

            '認証設定
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW
            If chkupdate Then
                '更新の場合、一度削除してから新規作成する
                '削除処理
                blnRet = wc.DeletePlanData(dt, strMsg)
                If blnRet = False Then
                    MsgBox(strMsg, vbCritical, "RegistTable")
                    Exit Sub
                End If
                dt.Rows(0).Item(M_PLANTable.COLUMN_NAME_PLAN_NAME) = txtPlanName.Text.Trim
            End If
            '新規作成処理
            blnRet = wc.InsertPlanData(dt, strMsg)
            If blnRet = False Then
                MsgBox(strMsg, vbCritical, "RegistTable")
                Exit Sub
            End If
        End If

    End Sub

    ''' <summary>
    ''' 開始行番取得
    ''' </summary>
    ''' <param name="pln"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetStartRowNo(ByRef pln() As Plan) As Boolean

        Dim dr() As DataRow
        Dim strSelect As String

        GetStartRowNo = False

        Try
            Dim i As Integer
            For i = 0 To 3
                strSelect = "CPNO = '" + CommonVariable.CPNO.ToString() + _
                            "' AND LEVEL1 = '" + pln(i).No1 + _
                            "' AND LEVEL2 = '" + pln(i).No2 + _
                            "' AND LEVEL3 = '" + pln(i).No3 + _
                            "' AND LEVEL4 = '" + pln(i).No4 + "'"

                dr = Me.tbPlan.Select(strSelect)

                If 0 < dr.Length Then
                    pln(i).StartRowNo = Integer.Parse(dr(0).Item("ROW_NO_START"))
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical)
        End Try

        GetStartRowNo = True
    End Function

    ''' <summary>
    ''' 更新か新規作成かどうかのチェック
    ''' </summary>
    ''' <remarks></remarks>
    Private Function IsUpdate(ByVal txtLv1 As TextBox, _
                              ByVal txtLv2 As TextBox, _
                              ByVal txtLv3 As TextBox, _
                              ByVal txtLv4 As TextBox) As DataRow()

        Dim selectLine As New StringBuilder
        selectLine.Append("CPNO = '" + CommonVariable.CPNO.ToString() + "' ")
        selectLine.Append("AND   LEVEL1 = '" + txtLv1.Text + "' ")
        selectLine.Append("AND   LEVEL2 = '" + txtLv2.Text + "' ")
        selectLine.Append("AND   LEVEL3 = '" + txtLv3.Text + "' ")
        selectLine.Append("AND   LEVEL4 = '" + txtLv4.Text + "'")
        Dim drPlan() As DataRow = Me.tbPlan.Select(selectLine.ToString())
        Return drPlan

    End Function

    ''' <summary>
    ''' 更新か新規作成かどうかのチェック(条件に案件名あり)
    ''' </summary>
    ''' <remarks></remarks>
    Private Function IsUpdate(ByVal txtLv1 As TextBox, _
                              ByVal txtLv2 As TextBox, _
                              ByVal txtLv3 As TextBox, _
                              ByVal txtLv4 As TextBox, _
                              ByVal txtPlanName As TextBox) As DataRow()

        Dim selectLine As New StringBuilder
        selectLine.Append("CPNO = '" + CommonVariable.CPNO.ToString() + "' ")
        selectLine.Append("AND   PLAN_NAME = '" + txtPlanName.Text + "' ")
        selectLine.Append("AND   LEVEL1 = '" + txtLv1.Text + "' ")
        selectLine.Append("AND   LEVEL2 = '" + txtLv2.Text + "' ")
        selectLine.Append("AND   LEVEL3 = '" + txtLv3.Text + "' ")
        selectLine.Append("AND   LEVEL4 = '" + txtLv4.Text + "'")
        Dim drPlan() As DataRow = Me.tbPlan.Select(selectLine.ToString())
        Return drPlan

    End Function

    ''' <summary>
    ''' 開始行番が変更されているかのチェック
    ''' </summary>
    ''' <remarks></remarks>
    Private Function IsRowNoStartUpdate(ByVal txtLv1 As TextBox, _
                              ByVal txtLv2 As TextBox, _
                              ByVal txtLv3 As TextBox, _
                              ByVal txtLv4 As TextBox, _
                              ByVal txtPlanName As TextBox, _
                              ByVal nudStartRowNo As NumericUpDown) As Boolean
        IsRowNoStartUpdate = False

        If 0 < IsUpdate(txtLv1, txtLv2, txtLv3, txtLv4, txtPlanName).Length Then
            If IsUpdate(txtLv1, txtLv2, txtLv3, txtLv4, txtPlanName)(0).Item("ROW_NO_START").ToString() _
                <> nudStartRowNo.Value.ToString() Then
                Return True
            End If
        End If
    End Function

    ''' <summary>
    ''' 案件名が変更されているかのチェック
    ''' </summary>
    ''' <remarks></remarks>
    Private Function IsPlanNameUpdate(ByVal txtLv1 As TextBox, _
                                      ByVal txtLv2 As TextBox, _
                                      ByVal txtLv3 As TextBox, _
                                      ByVal txtLv4 As TextBox, _
                                      ByVal txtPlanName As TextBox, _
                                      ByVal nudStartRowNo As NumericUpDown) As Boolean

        IsPlanNameUpdate = False
        If 0 < IsUpdate(txtLv1, txtLv2, txtLv3, txtLv4).Length Then
            If IsUpdate(txtLv1, txtLv2, txtLv3, txtLv4)(0).Item("PLAN_NAME").ToString() _
                <> txtPlanName.Text Then
                Return True
            End If
        End If

    End Function

    ''' <summary>
    ''' 案件番号抜けチェック
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function IsPlanNoEmpty() As Boolean

        IsPlanNoEmpty = False

        Dim chkPlanNoEmpty As Boolean = True

        If Me.txtLv44.Text <> String.Empty Then
            If Me.txtLv33.Text = String.Empty Then
                Me.txtLv33.BackColor = Color.Red
                chkPlanNoEmpty = False
            Else
                Me.txtLv33.BackColor = Color.White
            End If
            If Me.txtLv22.Text = String.Empty Then
                Me.txtLv22.BackColor = Color.Red
                chkPlanNoEmpty = False
            Else
                Me.txtLv22.BackColor = Color.White
            End If
            If Me.txtLv11.Text = String.Empty Then
                Me.txtLv11.BackColor = Color.Red
                chkPlanNoEmpty = False
            Else
                Me.txtLv11.BackColor = Color.White
            End If
        End If
        If Me.txtLv33.Text <> String.Empty Then
            If Me.txtLv22.Text = String.Empty Then
                Me.txtLv22.BackColor = Color.Red
                chkPlanNoEmpty = False
            Else
                Me.txtLv22.BackColor = Color.White
            End If
            If Me.txtLv11.Text = String.Empty Then
                Me.txtLv11.BackColor = Color.Red
                chkPlanNoEmpty = False
            Else
                Me.txtLv11.BackColor = Color.White
            End If
        End If
        If Me.txtLv22.Text <> String.Empty Then
            If Me.txtLv11.Text = String.Empty Then
                Me.txtLv11.BackColor = Color.Red
                chkPlanNoEmpty = False
            Else
                Me.txtLv11.BackColor = Color.White
            End If
        End If
        If Not chkPlanNoEmpty Then
            MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0070"), Me.Text)
            IsPlanNoEmpty = True
        End If

    End Function

    ''' <summary>
    ''' 数値チェック
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function IsNumeric(ByVal strNum As String)

        Dim regex As New System.Text.RegularExpressions.Regex("^[0-9]+$")
        Dim m As System.Text.RegularExpressions.Match = regex.Match(strNum)

        Return m.Success

    End Function

    ''' <summary>
    ''' 開始行番チェック
    ''' </summary>
    ''' <remarks></remarks>
    Private Function ChkStartRowNo(ByVal intStartRowNo As Integer,
                                   ByRef minValue As Integer,
                                   ByRef maxValue As Integer) As DataRow()

        Dim baseArea As Integer = ROW_NO_AREA

        If intStartRowNo - baseArea < 0 Then
            minValue = 1
        ElseIf intStartRowNo - ROW_NO_AREA < ROW_NO_AREA Then
            minValue = ROW_NO_AREA
        Else

        End If

        Dim selectLine As New StringBuilder
        selectLine.Append("CPNO = '" + CommonVariable.CPNO.ToString() + "' ")
        selectLine.Append("AND   ROW_NO_START < '" + maxValue.ToString() + "' ")
        selectLine.Append("AND   ROW_NO_START >= '" + maxValue.ToString() + "' ")
        Dim drPlan() As DataRow = Me.tbPlan.Select(selectLine.ToString())

        Return drPlan

    End Function

    ''' <summary>
    ''' 機　能：画面の値をセットする
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetDisplayValue()

        With bvItem
            .strLv1 = txtLv11.Text.Trim
            .strLv2 = txtLv22.Text.Trim
            .strLv3 = txtLv33.Text.Trim
            .strLv4 = txtLv44.Text.Trim
            .strPlanName1 = txtPlanName1.Text.Trim
            .strPlanName2 = txtPlanName2.Text.Trim
            .strPlanName3 = txtPlanName3.Text.Trim
            .strPlanName4 = txtPlanName4.Text.Trim
        End With

    End Sub

    ''' <summary>
    ''' 機　能：画面の変更前の値と現在の値を比較する
    ''' 説　明：True:一致　False:不一致
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function isDisplayValue() As Boolean

        isDisplayValue = False

        With bvItem
            If .strLv1 = txtLv11.Text.Trim And _
                .strLv2 = txtLv22.Text.Trim And _
                .strLv3 = txtLv33.Text.Trim And _
                .strLv4 = txtLv44.Text.Trim And _
                .strPlanName1 = txtPlanName1.Text.Trim And _
                .strPlanName2 = txtPlanName2.Text.Trim And _
                .strPlanName3 = txtPlanName3.Text.Trim And _
                .strPlanName4 = txtPlanName4.Text.Trim Then
                isDisplayValue = True
            End If
        End With

    End Function

    ''' <summary>
    ''' 機能：案件情報の削除処理
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub deletePlanMdb(ByVal DelLev As Integer)

        Dim wc As New WebDb.WebDbCommon
        Dim blnRet As Boolean
        Dim dt As New M_PLANTable
        Dim strMsg As String = ""
        Dim lv1 As String = Me.txtLv11.Text.Trim
        Dim lv2 As String = Me.txtLv22.Text.Trim
        Dim lv3 As String = Me.txtLv33.Text.Trim
        Dim lv4 As String = Me.txtLv44.Text.Trim
        Dim lv4NM As String = Me.txtPlanName4.Text.Trim

        Try
            '認証設定
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW
            '案件情報取得
            blnRet = wc.GetPlanData(CommonVariable.CPNO, dt, strMsg)
            If blnRet = False Then
                MsgBox(strMsg, vbCritical, "deletePlanMdb")
                Exit Sub
            End If

            'フィルター
            Dim rows() As DataRow
            Dim strWhere As String = "CPNO='" & CommonVariable.CPNO & "'"
            Select Case DelLev
                Case DelLev_1
                    strWhere = strWhere & " AND LEVEL1='" & lv1 & "'"
                    rows = dt.Select(strWhere)
                Case DelLev_2
                    strWhere = strWhere & " AND LEVEL1='" & lv1 & "' AND LEVEL2='" & lv2 & "'"
                    rows = dt.Select(strWhere)
                Case DelLev_3
                    strWhere = strWhere & " AND LEVEL1='" & lv1 & "' AND LEVEL2='" & lv2 & "' AND LEVEL3='" & lv3 & "'"
                    rows = dt.Select(strWhere)
                Case DelLev_4
                    strWhere = strWhere & " AND LEVEL1='" & lv1 & "' AND LEVEL2='" & lv2 & "' AND LEVEL3='" & lv3 & "' AND LEVEL4='" & lv4 & "'"
                    rows = dt.Select(strWhere)
            End Select

            '削除データ抽出
            Dim dtDel As New M_PLANTable
            For Each row As DataRow In rows
                dtDel.ImportRow(row)
            Next

            '削除処理
            blnRet = wc.DeletePlanData(dtDel, strMsg)
            If blnRet = False Then
                MsgBox(strMsg, vbCritical, "deletePlanMdb")
                Exit Sub
            End If

        Catch ex As Exception
            MsgBox(ex.Message.ToString, "deletePlanMdb")

        End Try

    End Sub

    ''' <summary>
    ''' 機能：登録時のNode名をセット
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetFrmNodeNm(ByRef expandNodeNM As ArrayList)

        ''画面のNode名セットする。
        Dim NodeTextLV1 As String
        Dim NodeTextLV2 As String
        Dim NodeTextLV3 As String
        Dim NodeTextLV4 As String

        Dim planNo As String
        planNo = ""
        ''LV1
        If Me.txtLv11.Text.Trim <> "" Then
            planNo = planNo & Me.txtLv11.Text.Trim
            NodeTextLV1 = planNo & "_" & Me.txtPlanName1.Text.Trim
            expandNodeNM.Add(NodeTextLV1)
        End If

        ''LV2
        If Me.txtLv22.Text.Trim <> "" Then
            planNo = planNo & "." & Me.txtLv22.Text.Trim
            NodeTextLV2 = planNo & "_" & Me.txtPlanName2.Text.Trim
            expandNodeNM.Add(NodeTextLV2)
        End If

        ''LV3
        If Me.txtLv33.Text.Trim <> "" Then
            planNo = planNo & "." & Me.txtLv33.Text.Trim
            NodeTextLV3 = planNo & "_" & Me.txtPlanName3.Text.Trim
            expandNodeNM.Add(NodeTextLV3)
        End If

        ''LV4
        If Me.txtLv44.Text.Trim <> "" Then
            planNo = planNo & "." & Me.txtLv44.Text.Trim
            NodeTextLV4 = planNo & "_" & Me.txtPlanName4.Text.Trim
            expandNodeNM.Add(NodeTextLV4)
        End If

    End Sub

    ''' <summary>
    ''' 機能：展開しているNode名を全て取得
    ''' 説明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetExpandAllNodes(ByVal Nodes As TreeNodeCollection) As ArrayList
        Dim Ar As New ArrayList
        Dim Node As TreeNode

        For Each Node In Nodes

            ''選択状態のNode名を取得
            If Node.IsExpanded Then
                Ar.Add(Node.Text)
            End If
            If Node.GetNodeCount(False) > 0 Then
                Ar.AddRange(GetExpandAllNodes(Node.Nodes))
            End If
        Next

        Return Ar

    End Function

    ''' <summary>
    ''' 機能：案件情報XLSファイルを作成する。
    ''' 説明：
    ''' </summary>
    Private Sub CreatePlanImportFile(ByRef planTBL As M_PLANTable, _
                                     ByVal tmpFilePath As String, _
                                     ByVal outFilePath As String)

        ''Excel変数
        Dim xlApp As New Excel.Application
        Dim xlOutPlanBook As Excel.Workbook
        Dim xlOutInsertSheet As Excel.Worksheet
        Dim xlRange As Excel.Range

        Try

            ''テンプレファイルをコピー
            Call File.Copy(tmpFilePath, outFilePath, True)


            ''案件BookのOpen
            Const ImportSheetNM As String = "登録シート"
            xlApp.EnableEvents = False
            xlApp.DisplayAlerts = False
            xlOutPlanBook = xlApp.Workbooks.Open(outFilePath)
            xlOutInsertSheet = xlOutPlanBook.Worksheets(ImportSheetNM)


            ''値の書込　※ヘッダ情報
            Const Cells_CPNO As String = "D2"
            Const Cells_Checked As String = "D3"
            Const Cells_ErrCount As String = "D4"
            xlRange = xlOutInsertSheet.Range(Cells_CPNO)                ''CPNO
            xlRange.Value = CommonVariable.CPNO
            xlRange = xlOutInsertSheet.Range(Cells_Checked)             ''ﾁｪｯｸ済み
            xlRange.Value = "未チェック"
            xlRange = xlOutInsertSheet.Range(Cells_ErrCount)            ''ｴﾗｰ件数
            xlRange.Value = ""


            ''案件情報を出力用のデータに変換
            Dim OutCellsValue(,) As Object
            OutCellsValue = ChgOutPlanValue(planTBL)


            ''値の書込　※登録情報(ﾃﾞｰﾀ0件なら、書込せずに処理終了)
            If IsNothing(OutCellsValue) = False Then

                Const OutRange As String = "B@Str:F@End"
                Dim outArea As String
                Dim outStrRow As Integer
                Dim outEndRow As Integer
                outStrRow = 8
                outEndRow = UBound(OutCellsValue, 1) + outStrRow
                outArea = OutRange.Replace("@Str", outStrRow).Replace("@End", outEndRow)

                xlRange = xlOutInsertSheet.Range(outArea)
                xlRange.Value = OutCellsValue

            End If

            ''Bookの保存
            Call xlOutPlanBook.Save()

        Catch ex As Exception
            Throw New Exception(FileReader.GetMessage("MSG_0343") & vbCrLf & _
                                " " & ex.Message)

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlOutInsertSheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlOutPlanBook) = False Then
                xlOutPlanBook.Close()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlOutPlanBook, ExcelObjRelease.OBJECT_NOTHING)

            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()

        End Try

    End Sub


    ''' <summary>
    ''' 機能：案件情報をExcelのCell出力用配列にセットする。
    ''' 説明：
    ''' </summary>
    Private Function ChgOutPlanValue(ByRef planTBL As M_PLANTable) As Object(,)


        ''初期化　
        ''※データ0件 / 例外なしの場合Nothingを返す。
        ''※データ0件は後続の処理でエラー扱いしない。
        ChgOutPlanValue = Nothing


        ''項目の位置
        Const Idx_PlanNM As Integer = 0
        Const Idx_LV1 As Integer = 1
        Const Idx_LV2 As Integer = 2
        Const Idx_LV3 As Integer = 3
        Const Idx_LV4 As Integer = 4


        ''データが0件なら処理終了
        Dim maxRowCount As Integer
        maxRowCount = planTBL.Rows.Count
        If maxRowCount = 0 Then
            Exit Function
        End If


        Dim rtnVale(maxRowCount - 1, Idx_LV4) As Object
        Try
            Dim idx As Integer = -1
            Dim row As DataRow
            For Each row In planTBL.Rows
                idx += 1
                rtnVale(idx, Idx_PlanNM) = ExcelWrite.changeDBNullToString(row.Item(M_PLANTable.COLUMN_NAME_PLAN_NAME))
                rtnVale(idx, Idx_LV1) = ExcelWrite.changeDBNullToString(row.Item(M_PLANTable.COLUMN_NAME_LEVEL1))
                rtnVale(idx, Idx_LV2) = ExcelWrite.changeDBNullToString(row.Item(M_PLANTable.COLUMN_NAME_LEVEL2))
                rtnVale(idx, Idx_LV3) = ExcelWrite.changeDBNullToString(row.Item(M_PLANTable.COLUMN_NAME_LEVEL3))
                rtnVale(idx, Idx_LV4) = ExcelWrite.changeDBNullToString(row.Item(M_PLANTable.COLUMN_NAME_LEVEL4))
            Next

        Catch ex As Exception
            Throw ex

        End Try
        Return rtnVale

    End Function


    ''' <summary>
    ''' 機能：Xls案件情報の取込み処理
    ''' 説明：
    ''' </summary>
    Private Sub GetXLSM_PLANData(ByVal readFilePath As String, _
                                 ByRef planTBL As M_PLANTable)


        ''戻り値        
        Dim rtnTable As New M_PLANTable

        ''Excel変数
        Const ImportSheet As String = "登録シート"
        Dim xlApp As New Excel.Application
        Dim xlReadBook As Excel.WorkBook
        Dim xlImportSheet As Excel.WorkSheet
        Dim xlRange As Excel.Range

        Try

            ''シートのセット
            xlApp.EnableEvents = False
            xlApp.DisplayAlerts = False
            xlReadBook = xlApp.Workbooks.Open(readFilePath)
            xlImportSheet = xlReadBook.WorkSheets(ImportSheet)


            ''案件XLSの入力チェック ※チェックNGなら、ExceptionをThrowする。
            Dim strRow As Integer
            Dim endRow As Integer
            Call ChkXlImportSheetFormat(xlImportSheet, strRow, endRow)


            ''案件XLSの情報を取得
            planTBL = ReadXlsPlanData(xlImportSheet, strRow, endRow)

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlImportSheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlReadBook) = False Then
                xlReadBook.Close()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlReadBook, ExcelObjRelease.OBJECT_NOTHING)

            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            Call GC.Collect()

        End Try

    End Sub


    ''' <summary>
    ''' 機能：取込み対象のXLSファイルの入力チェックを行う。
    ''' 説明：
    ''' </summary>
    Private Sub ChkxlImportSheetFormat(ByRef xlImportSheet As Excel.Worksheet, _
                                       ByRef strRow As Integer, _
                                       ByRef endRow As Integer)

        Dim xlRange As Excel.Range
        Dim xlSearchRange As Excel.Range

        Try

            ''CPNOのチェック
            Const ColumnIdxCPNO As String = "D2"
            xlRange = xlImportSheet.Range(ColumnIdxCPNO)
            If ExcelWrite.changeDBNullToString(xlRange.Value) <> CommonVariable.CPNO Then
                Throw New Exception(FileReader.GetMessage("MSG_0354"))
            End If


            ''Excelファイル上で入力チェック済みかどうか判断
            Const ColumnIdxChecked As String = "D3"
            xlRange = xlImportSheet.Range(ColumnIdxChecked)
            If ExcelWrite.changeDBNullToString(xlRange.Value) <> "チェック結果：OK" Then
                Throw New Exception(FileReader.GetMessage("MSG_0346"))
            End If


            ''「処理STR」の文言検索
            Const ColumnIdxCheck As String = "A"
            xlRange = xlImportSheet.Columns(ColumnIdxCheck)
            Const SearchStrValue As String = "処理ＳＴＲ"
            xlSearchRange = xlRange.Find(What:=SearchStrValue, _
                                         LookAt:=Excel.XlLookAt.xlWhole, _
                                         MatchCase:=False)
            ''Strが見つからない場合
            If isNothing(xlSearchRange) = True Then
                Throw New Exception(FileReader.GetMessage("MSG_0347"))
            Else
                strRow = xlSearchRange.Row
            End If


            ''「処理END」の文言検索
            Const SearchEndValue As String = "処理ＥＮＤ"
            xlSearchRange = xlRange.Find(What:=SearchEndValue, _
                                         LookAt:=Excel.XlLookAt.xlWhole, _
                                         MatchCase:=False)
            ''Endが見つからない場合
            If isNothing(xlSearchRange) = True Then
                Throw New Exception(FileReader.GetMessage("MSG_0347"))
            Else
                endRow = xlSearchRange.Row
            End If


            ''「処理STR」と「処理END」の位置が逆転していないかチェック
            If strRow > endRow Then
                Throw New Exception(FileReader.GetMessage("MSG_0348"))
            End If

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSearchRange, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub


    ''' <summary>
    ''' 機能：案件情報XLSファイルのデータを取得する。
    ''' 説明：
    ''' </summary>
    Private Function ReadXlsPlanData(ByRef xlImportSheet As Excel.Worksheet, _
                                     ByVal strRow As Integer, _
                                     ByVal endRow As Integer) As M_PLANTable


        ''戻り値初期化
        ''※データ0件は後続の処理でエラーにしない。
        Dim rtnTBL As New M_PLANTable
        Dim xlRange As Excel.Range
        Try

            ''XLSの情報を一度配列に格納する。
            Const ReadArea_ALL As String = "A@Str:K@End"         ''データの読込範囲
            Dim DataCells(,) As Object
            Dim readRange As String
            readRange = ReadArea_ALL
            readRange = readRange.Replace("@Str", strRow)
            readRange = readRange.Replace("@End", endRow)
            xlRange = xlImportSheet.Range(readRange)
            DataCells = xlRange.Value


            Dim row As DataRow
            Dim idx As Integer
            For idx = 1 To UBound(DataCells, 1)
                If ExcelWrite.changeDBNullToString(DataCells(idx, XLSPlanColumns.ERRFLG)) = "" And
                   ExcelWrite.changeDBNullToString(DataCells(idx, XLSPlanColumns.LEVELALL)) <> "" Then
                    row = rtnTBL.NewRow
                    row.Item(rtnTBL.COLUMN_NAME_CPNO) = CommonVariable.CPNO
                    row.Item(rtnTBL.COLUMN_NAME_PLAN_NAME) = ExcelWrite.changeDBNullToString(DataCells(idx, XLSPlanColumns.PLAN_NAME))
                    row.Item(rtnTBL.COLUMN_NAME_LEVEL1) = ExcelWrite.changeDBNullToString(DataCells(idx, XLSPlanColumns.LEVEL1)).PadLeft(2, "00")
                    row.Item(rtnTBL.COLUMN_NAME_LEVEL2) = ExcelWrite.changeDBNullToString(DataCells(idx, XLSPlanColumns.LEVEL2)).PadLeft(2, "00")
                    row.Item(rtnTBL.COLUMN_NAME_LEVEL3) = ExcelWrite.changeDBNullToString(DataCells(idx, XLSPlanColumns.LEVEL3)).PadLeft(2, "00")
                    row.Item(rtnTBL.COLUMN_NAME_LEVEL4) = ExcelWrite.changeDBNullToString(DataCells(idx, XLSPlanColumns.LEVEL4)).PadLeft(2, "00")
                    Call rtnTBL.Rows.Add(row)
                End If
            Next
            Return rtnTBL

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Function


    ''' <summary>
    ''' 機能：XLS情報をMDBにInsertする。
    ''' 説明：
    ''' </summary>
    Private Sub InsertPlanTBL(ByRef planTBL As M_PLANTable)

        Dim wc As New WebDb.WebDbCommon
        Dim blnRet As Boolean
        Dim strMsg As String = ""
        Dim dt As New M_PLANTable

        Try
            '認証設定
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW

            '案件情報取得
            blnRet = wc.GetPlanData(CommonVariable.CPNO, dt, strMsg)
            If blnRet = False Then
                MsgBox(strMsg, vbCritical, "InsertPlanTBL")
                Exit Sub
            End If

            '案件情報削除処理
            blnRet = wc.DeletePlanData(dt, strMsg)
            If blnRet = False Then
                MsgBox(strMsg, vbCritical, "InsertPlanTBL")
                Exit Sub
            End If

            '案件情報登録
            blnRet = wc.InsertPlanData(planTBL, strMsg)
            If blnRet = False Then
                MsgBox(strMsg, vbCritical, "InsertPlanTBL")
                Exit Sub
            End If

        Catch ex As Exception
            Throw ex

        End Try

    End Sub

#End Region

End Class