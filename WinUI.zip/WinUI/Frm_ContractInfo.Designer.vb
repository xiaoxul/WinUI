﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frm_ContractInfo
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.dtpStart = New System.Windows.Forms.DateTimePicker()
        Me.dtpEnd = New System.Windows.Forms.DateTimePicker()
        Me.cmbPAAniv = New System.Windows.Forms.ComboBox()
        Me.cmbPALevel = New System.Windows.Forms.ComboBox()
        Me.tbCustomerName = New System.Windows.Forms.TextBox()
        Me.cmbCPNO = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.nudContractNo = New System.Windows.Forms.NumericUpDown()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.tbContractNoName = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.dtpPriceRequestDate = New System.Windows.Forms.DateTimePicker()
        Me.dtpContractDate = New System.Windows.Forms.DateTimePicker()
        Me.cbContractDate = New System.Windows.Forms.CheckBox()
        Me.cbPriceRequestDate = New System.Windows.Forms.CheckBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.nudExcelStartYear = New System.Windows.Forms.NumericUpDown()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.nudExcelStartMonth = New System.Windows.Forms.NumericUpDown()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.ChkDispContract = New System.Windows.Forms.CheckBox()
        Me.CmbState = New System.Windows.Forms.ComboBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.ChkInitTmpCon = New System.Windows.Forms.CheckBox()
        Me.chkAsrAll = New System.Windows.Forms.CheckBox()
        Me.cmbCpnoName = New System.Windows.Forms.ComboBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.tbTopacsCPNO = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.ChkAttachB = New System.Windows.Forms.CheckBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.nudDeploymentPeriod = New System.Windows.Forms.NumericUpDown()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.chkDspFrm = New System.Windows.Forms.CheckBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.dtpSuggestDay = New System.Windows.Forms.DateTimePicker()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnReflesh = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnGetNewData = New MUSE.UserControl.UCnt_Btn0001()
        Me.BtnCreateXls = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_DspFrm = New MUSE.UserControl.UCnt_Btn0001()
        Me.btn_Menu = New MUSE.UserControl.UCnt_Btn0001()
        Me.UCnt_Pal00011 = New MUSE.UserControl.UCnt_Pal0001()
        Me.btnRegistUpdate = New MUSE.UserControl.UCnt_Btn0001()
        Me.btnBack = New MUSE.UserControl.UCnt_Btn0001()
        Me.BtnCreateXlsData = New MUSE.UserControl.UCnt_Btn0001()
        CType(Me.nudContractNo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudExcelStartYear, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudExcelStartMonth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.nudDeploymentPeriod, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(10, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(36, 12)
        Me.Label1.TabIndex = 999
        Me.Label1.Text = "CPNO"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(10, 64)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(77, 12)
        Me.Label3.TabIndex = 999
        Me.Label3.Text = "基本契約期間"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(190, 64)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(17, 12)
        Me.Label4.TabIndex = 999
        Me.Label4.Text = "～"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(10, 86)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(76, 12)
        Me.Label5.TabIndex = 999
        Me.Label5.Text = "PA Anv Date "
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(250, 58)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(51, 12)
        Me.Label6.TabIndex = 999
        Me.Label6.Text = "PA Level"
        '
        'dtpStart
        '
        Me.dtpStart.CalendarMonthBackground = System.Drawing.SystemColors.ScrollBar
        Me.dtpStart.Location = New System.Drawing.Point(105, 61)
        Me.dtpStart.Name = "dtpStart"
        Me.dtpStart.Size = New System.Drawing.Size(83, 19)
        Me.dtpStart.TabIndex = 10
        '
        'dtpEnd
        '
        Me.dtpEnd.CalendarMonthBackground = System.Drawing.SystemColors.ScrollBar
        Me.dtpEnd.Location = New System.Drawing.Point(213, 61)
        Me.dtpEnd.Name = "dtpEnd"
        Me.dtpEnd.Size = New System.Drawing.Size(83, 19)
        Me.dtpEnd.TabIndex = 15
        '
        'cmbPAAniv
        '
        Me.cmbPAAniv.BackColor = System.Drawing.SystemColors.Window
        Me.cmbPAAniv.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbPAAniv.FormattingEnabled = True
        Me.cmbPAAniv.Location = New System.Drawing.Point(105, 83)
        Me.cmbPAAniv.Name = "cmbPAAniv"
        Me.cmbPAAniv.Size = New System.Drawing.Size(60, 20)
        Me.cmbPAAniv.TabIndex = 25
        '
        'cmbPALevel
        '
        Me.cmbPALevel.BackColor = System.Drawing.SystemColors.Window
        Me.cmbPALevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbPALevel.FormattingEnabled = True
        Me.cmbPALevel.Location = New System.Drawing.Point(320, 54)
        Me.cmbPALevel.Name = "cmbPALevel"
        Me.cmbPALevel.Size = New System.Drawing.Size(60, 20)
        Me.cmbPALevel.TabIndex = 30
        '
        'tbCustomerName
        '
        Me.tbCustomerName.BackColor = System.Drawing.SystemColors.Window
        Me.tbCustomerName.Location = New System.Drawing.Point(105, 38)
        Me.tbCustomerName.MaxLength = 110
        Me.tbCustomerName.Name = "tbCustomerName"
        Me.tbCustomerName.Size = New System.Drawing.Size(574, 19)
        Me.tbCustomerName.TabIndex = 5
        '
        'cmbCPNO
        '
        Me.cmbCPNO.BackColor = System.Drawing.SystemColors.Window
        Me.cmbCPNO.DropDownWidth = 166
        Me.cmbCPNO.FormattingEnabled = True
        Me.cmbCPNO.Location = New System.Drawing.Point(105, 14)
        Me.cmbCPNO.MaxLength = 6
        Me.cmbCPNO.Name = "cmbCPNO"
        Me.cmbCPNO.Size = New System.Drawing.Size(65, 20)
        Me.cmbCPNO.TabIndex = 0
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(320, 64)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(73, 12)
        Me.Label8.TabIndex = 999
        Me.Label8.Text = "Payment開始"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(10, 37)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(53, 12)
        Me.Label9.TabIndex = 999
        Me.Label9.Text = "契約順番"
        '
        'nudContractNo
        '
        Me.nudContractNo.Location = New System.Drawing.Point(105, 34)
        Me.nudContractNo.Maximum = New Decimal(New Integer() {999, 0, 0, 0})
        Me.nudContractNo.Name = "nudContractNo"
        Me.nudContractNo.Size = New System.Drawing.Size(51, 19)
        Me.nudContractNo.TabIndex = 5
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(250, 37)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(65, 12)
        Me.Label10.TabIndex = 999
        Me.Label10.Text = "契約順番名"
        '
        'tbContractNoName
        '
        Me.tbContractNoName.Location = New System.Drawing.Point(320, 33)
        Me.tbContractNoName.Name = "tbContractNoName"
        Me.tbContractNoName.Size = New System.Drawing.Size(360, 19)
        Me.tbContractNoName.TabIndex = 10
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(10, 81)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(89, 12)
        Me.Label11.TabIndex = 999
        Me.Label11.Text = "価格承認依頼日"
        '
        'dtpPriceRequestDate
        '
        Me.dtpPriceRequestDate.Location = New System.Drawing.Point(105, 78)
        Me.dtpPriceRequestDate.Name = "dtpPriceRequestDate"
        Me.dtpPriceRequestDate.Size = New System.Drawing.Size(105, 19)
        Me.dtpPriceRequestDate.TabIndex = 20
        '
        'dtpContractDate
        '
        Me.dtpContractDate.Location = New System.Drawing.Point(320, 76)
        Me.dtpContractDate.Name = "dtpContractDate"
        Me.dtpContractDate.Size = New System.Drawing.Size(108, 19)
        Me.dtpContractDate.TabIndex = 30
        '
        'cbContractDate
        '
        Me.cbContractDate.AutoSize = True
        Me.cbContractDate.Location = New System.Drawing.Point(434, 79)
        Me.cbContractDate.Name = "cbContractDate"
        Me.cbContractDate.Size = New System.Drawing.Size(15, 14)
        Me.cbContractDate.TabIndex = 35
        Me.cbContractDate.UseVisualStyleBackColor = True
        '
        'cbPriceRequestDate
        '
        Me.cbPriceRequestDate.AutoSize = True
        Me.cbPriceRequestDate.Location = New System.Drawing.Point(215, 80)
        Me.cbPriceRequestDate.Name = "cbPriceRequestDate"
        Me.cbPriceRequestDate.Size = New System.Drawing.Size(15, 14)
        Me.cbPriceRequestDate.TabIndex = 25
        Me.cbPriceRequestDate.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(470, 64)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(17, 12)
        Me.Label13.TabIndex = 999
        Me.Label13.Text = "年"
        '
        'nudExcelStartYear
        '
        Me.nudExcelStartYear.Location = New System.Drawing.Point(407, 61)
        Me.nudExcelStartYear.Maximum = New Decimal(New Integer() {2100, 0, 0, 0})
        Me.nudExcelStartYear.Minimum = New Decimal(New Integer() {1900, 0, 0, 0})
        Me.nudExcelStartYear.Name = "nudExcelStartYear"
        Me.nudExcelStartYear.Size = New System.Drawing.Size(60, 19)
        Me.nudExcelStartYear.TabIndex = 20
        Me.nudExcelStartYear.Value = New Decimal(New Integer() {1900, 0, 0, 0})
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(626, 430)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(17, 12)
        Me.Label14.TabIndex = 86
        Me.Label14.Text = "月"
        Me.Label14.Visible = False
        '
        'nudExcelStartMonth
        '
        Me.nudExcelStartMonth.Location = New System.Drawing.Point(582, 427)
        Me.nudExcelStartMonth.Maximum = New Decimal(New Integer() {12, 0, 0, 0})
        Me.nudExcelStartMonth.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudExcelStartMonth.Name = "nudExcelStartMonth"
        Me.nudExcelStartMonth.Size = New System.Drawing.Size(39, 19)
        Me.nudExcelStartMonth.TabIndex = 8
        Me.nudExcelStartMonth.Value = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudExcelStartMonth.Visible = False
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(30, 314)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.RowTemplate.Height = 21
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(685, 165)
        Me.DataGridView1.TabIndex = 88
        Me.DataGridView1.TabStop = False
        '
        'ChkDispContract
        '
        Me.ChkDispContract.AutoSize = True
        Me.ChkDispContract.Location = New System.Drawing.Point(13, 15)
        Me.ChkDispContract.Name = "ChkDispContract"
        Me.ChkDispContract.Size = New System.Drawing.Size(183, 16)
        Me.ChkDispContract.TabIndex = 0
        Me.ChkDispContract.TabStop = False
        Me.ChkDispContract.Text = "契約締結済み/廃案案件の表示"
        Me.ChkDispContract.UseVisualStyleBackColor = True
        '
        'CmbState
        '
        Me.CmbState.BackColor = System.Drawing.SystemColors.Window
        Me.CmbState.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmbState.FormattingEnabled = True
        Me.CmbState.Location = New System.Drawing.Point(105, 100)
        Me.CmbState.MaxLength = 6
        Me.CmbState.Name = "CmbState"
        Me.CmbState.Size = New System.Drawing.Size(106, 20)
        Me.CmbState.TabIndex = 40
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(250, 79)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(65, 12)
        Me.Label12.TabIndex = 999
        Me.Label12.Text = "契約締結日"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(10, 103)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(50, 12)
        Me.Label15.TabIndex = 999
        Me.Label15.Text = "ステータス"
        '
        'ChkInitTmpCon
        '
        Me.ChkInitTmpCon.AutoSize = True
        Me.ChkInitTmpCon.Location = New System.Drawing.Point(252, 103)
        Me.ChkInitTmpCon.Name = "ChkInitTmpCon"
        Me.ChkInitTmpCon.Size = New System.Drawing.Size(106, 16)
        Me.ChkInitTmpCon.TabIndex = 45
        Me.ChkInitTmpCon.Text = "仮契約の初期化"
        Me.ChkInitTmpCon.UseVisualStyleBackColor = True
        Me.ChkInitTmpCon.Visible = False
        '
        'chkAsrAll
        '
        Me.chkAsrAll.AutoSize = True
        Me.chkAsrAll.Location = New System.Drawing.Point(320, 14)
        Me.chkAsrAll.Name = "chkAsrAll"
        Me.chkAsrAll.Size = New System.Drawing.Size(72, 16)
        Me.chkAsrAll.TabIndex = 92
        Me.chkAsrAll.TabStop = False
        Me.chkAsrAll.Text = "一括管理"
        Me.chkAsrAll.UseVisualStyleBackColor = True
        '
        'cmbCpnoName
        '
        Me.cmbCpnoName.BackColor = System.Drawing.SystemColors.Window
        Me.cmbCpnoName.DropDownWidth = 501
        Me.cmbCpnoName.FormattingEnabled = True
        Me.cmbCpnoName.Location = New System.Drawing.Point(105, 18)
        Me.cmbCpnoName.MaxLength = 6
        Me.cmbCpnoName.Name = "cmbCpnoName"
        Me.cmbCpnoName.Size = New System.Drawing.Size(64, 20)
        Me.cmbCpnoName.TabIndex = 0
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(10, 108)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(84, 12)
        Me.Label16.TabIndex = 999
        Me.Label16.Text = "ePricer用CPNO"
        '
        'tbTopacsCPNO
        '
        Me.tbTopacsCPNO.BackColor = System.Drawing.SystemColors.Window
        Me.tbTopacsCPNO.Location = New System.Drawing.Point(105, 107)
        Me.tbTopacsCPNO.MaxLength = 20
        Me.tbTopacsCPNO.Name = "tbTopacsCPNO"
        Me.tbTopacsCPNO.Size = New System.Drawing.Size(217, 19)
        Me.tbTopacsCPNO.TabIndex = 40
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.ChkAttachB)
        Me.GroupBox1.Controls.Add(Me.Label18)
        Me.GroupBox1.Controls.Add(Me.nudDeploymentPeriod)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.chkDspFrm)
        Me.GroupBox1.Controls.Add(Me.Label17)
        Me.GroupBox1.Controls.Add(Me.cmbCPNO)
        Me.GroupBox1.Controls.Add(Me.cmbCpnoName)
        Me.GroupBox1.Controls.Add(Me.tbTopacsCPNO)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label16)
        Me.GroupBox1.Controls.Add(Me.nudExcelStartYear)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.tbCustomerName)
        Me.GroupBox1.Controls.Add(Me.chkAsrAll)
        Me.GroupBox1.Controls.Add(Me.dtpStart)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.dtpEnd)
        Me.GroupBox1.Controls.Add(Me.cmbPAAniv)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Location = New System.Drawing.Point(30, 48)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(685, 132)
        Me.GroupBox1.TabIndex = 94
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "【契約基本情報】"
        '
        'ChkAttachB
        '
        Me.ChkAttachB.AutoSize = True
        Me.ChkAttachB.Location = New System.Drawing.Point(485, 14)
        Me.ChkAttachB.Name = "ChkAttachB"
        Me.ChkAttachB.Size = New System.Drawing.Size(116, 16)
        Me.ChkAttachB.TabIndex = 1004
        Me.ChkAttachB.TabStop = False
        Me.ChkAttachB.Text = "案件別別紙B出力"
        Me.ChkAttachB.UseVisualStyleBackColor = True
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(470, 86)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(17, 12)
        Me.Label18.TabIndex = 1003
        Me.Label18.Text = "年"
        '
        'nudDeploymentPeriod
        '
        Me.nudDeploymentPeriod.Location = New System.Drawing.Point(420, 83)
        Me.nudDeploymentPeriod.Maximum = New Decimal(New Integer() {20, 0, 0, 0})
        Me.nudDeploymentPeriod.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudDeploymentPeriod.Name = "nudDeploymentPeriod"
        Me.nudDeploymentPeriod.Size = New System.Drawing.Size(47, 19)
        Me.nudDeploymentPeriod.TabIndex = 1002
        Me.nudDeploymentPeriod.Value = New Decimal(New Integer() {20, 0, 0, 0})
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(320, 86)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(97, 12)
        Me.Label7.TabIndex = 1001
        Me.Label7.Text = "Payment展開期間"
        '
        'chkDspFrm
        '
        Me.chkDspFrm.AutoSize = True
        Me.chkDspFrm.Location = New System.Drawing.Point(407, 14)
        Me.chkDspFrm.Name = "chkDspFrm"
        Me.chkDspFrm.Size = New System.Drawing.Size(72, 16)
        Me.chkDspFrm.TabIndex = 1000
        Me.chkDspFrm.TabStop = False
        Me.chkDspFrm.Text = "統合処理"
        Me.chkDspFrm.UseVisualStyleBackColor = True
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(10, 42)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(51, 12)
        Me.Label17.TabIndex = 999
        Me.Label17.Text = "お客様名"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.dtpSuggestDay)
        Me.GroupBox2.Controls.Add(Me.ChkInitTmpCon)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.Label15)
        Me.GroupBox2.Controls.Add(Me.ChkDispContract)
        Me.GroupBox2.Controls.Add(Me.CmbState)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.cbContractDate)
        Me.GroupBox2.Controls.Add(Me.cbPriceRequestDate)
        Me.GroupBox2.Controls.Add(Me.dtpContractDate)
        Me.GroupBox2.Controls.Add(Me.cmbPALevel)
        Me.GroupBox2.Controls.Add(Me.btnReflesh)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.nudContractNo)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.tbContractNoName)
        Me.GroupBox2.Controls.Add(Me.dtpPriceRequestDate)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Location = New System.Drawing.Point(29, 183)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(686, 125)
        Me.GroupBox2.TabIndex = 95
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "【契約履歴情報】"
        '
        'dtpSuggestDay
        '
        Me.dtpSuggestDay.CalendarMonthBackground = System.Drawing.SystemColors.ScrollBar
        Me.dtpSuggestDay.Location = New System.Drawing.Point(105, 56)
        Me.dtpSuggestDay.Name = "dtpSuggestDay"
        Me.dtpSuggestDay.Size = New System.Drawing.Size(83, 19)
        Me.dtpSuggestDay.TabIndex = 15
        Me.dtpSuggestDay.Value = New Date(2013, 4, 1, 0, 0, 0, 0)
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(10, 59)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(77, 12)
        Me.Label2.TabIndex = 999
        Me.Label2.Text = "提案開始年月"
        '
        'btnReflesh
        '
        Me.btnReflesh.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnReflesh.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReflesh.ForeColor = System.Drawing.Color.White
        Me.btnReflesh.Location = New System.Drawing.Point(573, 71)
        Me.btnReflesh.Name = "btnReflesh"
        Me.btnReflesh.Size = New System.Drawing.Size(107, 44)
        Me.btnReflesh.TabIndex = 50
        Me.btnReflesh.Text = "画面リセット"
        Me.btnReflesh.UseVisualStyleBackColor = False
        '
        'btnGetNewData
        '
        Me.btnGetNewData.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnGetNewData.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGetNewData.ForeColor = System.Drawing.Color.White
        Me.btnGetNewData.Location = New System.Drawing.Point(438, 487)
        Me.btnGetNewData.Name = "btnGetNewData"
        Me.btnGetNewData.Size = New System.Drawing.Size(90, 44)
        Me.btnGetNewData.TabIndex = 1001
        Me.btnGetNewData.Text = "最新ﾃﾞｰﾀ　取得"
        Me.btnGetNewData.UseVisualStyleBackColor = False
        '
        'BtnCreateXls
        '
        Me.BtnCreateXls.BackColor = System.Drawing.Color.RoyalBlue
        Me.BtnCreateXls.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnCreateXls.ForeColor = System.Drawing.Color.White
        Me.BtnCreateXls.Location = New System.Drawing.Point(358, 487)
        Me.BtnCreateXls.Name = "BtnCreateXls"
        Me.BtnCreateXls.Size = New System.Drawing.Size(74, 44)
        Me.BtnCreateXls.TabIndex = 20
        Me.BtnCreateXls.Text = "空ﾌｧｲﾙ作成"
        Me.BtnCreateXls.UseVisualStyleBackColor = False
        '
        'Btn_DspFrm
        '
        Me.Btn_DspFrm.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_DspFrm.Enabled = False
        Me.Btn_DspFrm.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_DspFrm.ForeColor = System.Drawing.Color.White
        Me.Btn_DspFrm.Location = New System.Drawing.Point(123, 487)
        Me.Btn_DspFrm.Name = "Btn_DspFrm"
        Me.Btn_DspFrm.Size = New System.Drawing.Size(98, 44)
        Me.Btn_DspFrm.TabIndex = 21
        Me.Btn_DspFrm.Text = "契約統合/削除"
        Me.Btn_DspFrm.UseVisualStyleBackColor = False
        '
        'btn_Menu
        '
        Me.btn_Menu.BackColor = System.Drawing.Color.RoyalBlue
        Me.btn_Menu.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Menu.ForeColor = System.Drawing.Color.White
        Me.btn_Menu.Location = New System.Drawing.Point(534, 487)
        Me.btn_Menu.Name = "btn_Menu"
        Me.btn_Menu.Size = New System.Drawing.Size(69, 44)
        Me.btn_Menu.TabIndex = 19
        Me.btn_Menu.Text = "メニューへ"
        Me.btn_Menu.UseVisualStyleBackColor = False
        '
        'UCnt_Pal00011
        '
        Me.UCnt_Pal00011.BackColor = System.Drawing.Color.Teal
        Me.UCnt_Pal00011.BackColro2 = System.Drawing.Color.PaleTurquoise
        Me.UCnt_Pal00011.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UCnt_Pal00011.ForeColor = System.Drawing.Color.White
        Me.UCnt_Pal00011.Location = New System.Drawing.Point(1, 1)
        Me.UCnt_Pal00011.Name = "UCnt_Pal00011"
        Me.UCnt_Pal00011.Size = New System.Drawing.Size(742, 44)
        Me.UCnt_Pal00011.TabIndex = 31
        Me.UCnt_Pal00011.TitleText = "OIO BAMA Client  契約情報登録または選択"
        '
        'btnRegistUpdate
        '
        Me.btnRegistUpdate.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnRegistUpdate.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRegistUpdate.ForeColor = System.Drawing.Color.White
        Me.btnRegistUpdate.Location = New System.Drawing.Point(618, 487)
        Me.btnRegistUpdate.Name = "btnRegistUpdate"
        Me.btnRegistUpdate.Size = New System.Drawing.Size(97, 44)
        Me.btnRegistUpdate.TabIndex = 18
        Me.btnRegistUpdate.Text = "登録/更新"
        Me.btnRegistUpdate.UseVisualStyleBackColor = False
        '
        'btnBack
        '
        Me.btnBack.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnBack.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.ForeColor = System.Drawing.Color.White
        Me.btnBack.Location = New System.Drawing.Point(30, 487)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(87, 44)
        Me.btnBack.TabIndex = 22
        Me.btnBack.Text = "ログアウト"
        Me.btnBack.UseVisualStyleBackColor = False
        '
        'BtnCreateXlsData
        '
        Me.BtnCreateXlsData.BackColor = System.Drawing.Color.RoyalBlue
        Me.BtnCreateXlsData.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnCreateXlsData.ForeColor = System.Drawing.Color.White
        Me.BtnCreateXlsData.Location = New System.Drawing.Point(228, 487)
        Me.BtnCreateXlsData.Name = "BtnCreateXlsData"
        Me.BtnCreateXlsData.Size = New System.Drawing.Size(124, 44)
        Me.BtnCreateXlsData.TabIndex = 1002
        Me.BtnCreateXlsData.Text = "レポート出力用元データ作成"
        Me.BtnCreateXlsData.UseVisualStyleBackColor = False
        '
        'Frm_ContractInfo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(746, 539)
        Me.ControlBox = False
        Me.Controls.Add(Me.BtnCreateXlsData)
        Me.Controls.Add(Me.btnGetNewData)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.nudExcelStartMonth)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.BtnCreateXls)
        Me.Controls.Add(Me.Btn_DspFrm)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.btn_Menu)
        Me.Controls.Add(Me.UCnt_Pal00011)
        Me.Controls.Add(Me.btnRegistUpdate)
        Me.Controls.Add(Me.btnBack)
        Me.MaximizeBox = False
        Me.Name = "Frm_ContractInfo"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "OIO BAMA Client"
        CType(Me.nudContractNo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudExcelStartYear, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudExcelStartMonth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.nudDeploymentPeriod, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents dtpStart As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpEnd As System.Windows.Forms.DateTimePicker
    Friend WithEvents cmbPAAniv As System.Windows.Forms.ComboBox
    Friend WithEvents cmbPALevel As System.Windows.Forms.ComboBox
    Friend WithEvents tbCustomerName As System.Windows.Forms.TextBox
    Friend WithEvents UCnt_Pal00011 As MUSE.UserControl.UCnt_Pal0001
    Friend WithEvents btnRegistUpdate As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents btnBack As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents cmbCPNO As System.Windows.Forms.ComboBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents btnReflesh As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents nudContractNo As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents tbContractNoName As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents dtpPriceRequestDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpContractDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents cbContractDate As System.Windows.Forms.CheckBox
    Friend WithEvents btn_Menu As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents cbPriceRequestDate As System.Windows.Forms.CheckBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents nudExcelStartYear As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents nudExcelStartMonth As System.Windows.Forms.NumericUpDown
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Btn_DspFrm As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents ChkDispContract As System.Windows.Forms.CheckBox
    Friend WithEvents CmbState As System.Windows.Forms.ComboBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents BtnCreateXls As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents ChkInitTmpCon As System.Windows.Forms.CheckBox
    Friend WithEvents chkAsrAll As System.Windows.Forms.CheckBox
    Friend WithEvents cmbCpnoName As System.Windows.Forms.ComboBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents tbTopacsCPNO As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents dtpSuggestDay As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnGetNewData As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents chkDspFrm As System.Windows.Forms.CheckBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents nudDeploymentPeriod As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents BtnCreateXlsData As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents ChkAttachB As System.Windows.Forms.CheckBox
End Class
