﻿Imports System.IO
Imports System.Text
Imports Microsoft.Office.Interop
Imports System.Data.OleDb
Imports MUSE.Utility
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.OioBamaCommmon
Imports MUSE.Utility.UserMessageBox
Imports MUSE.WinUI.OioBamaCommmon
Imports MUSE.Utility.UserDataTable.Master

Public Class ExcelNewKakakukaiji

#Region "構造体"
    Private Structure CostFileType
        Dim fileType As String
        Dim fileNM As String
    End Structure

    'Summaryシートの作成件数を取得
    Private Structure TopacsOutCount
        Dim AAS_HWCount As Integer
        Dim QCOS_HWCount As Integer
        Dim QCOS_SWCount As Integer
    End Structure

    Private Structure CostInfo
        Dim PSCost As Decimal
        Dim DetailCost() As Decimal
        Dim BoxQty As Decimal
    End Structure

    ''S行の情報を保持      
    Private Structure SlineInfo
        Dim KihyoNo As String           ''起票番号
        Dim ShinseiNo As String         ''申請番号
        Dim BoxCodeah As String         ''親の機械番号
        Dim BoxSeq As String            ''親の機械番号(SEQ)
        Dim SetQty As Integer           ''セット数量
    End Structure

    'Paymentの起票番号・申請番号を保持
    Public Structure BrandTable
        Public FileName As String
        Public SUFFIX As String
        Public INTR As String
        Public CONTRACT As String
        Public Brand_AP_Conf As String
        Public PATERN_NO As String
    End Structure

    'COST入力形式集計テーブル
    Public Structure CostInputData
        Public Brand_AP_Conf As String
        Public ListPrice As Long
        Public OfferingPrice As Long
        Public Cost As Long
        Public LineNo As Integer
    End Structure
#End Region

#Region "列挙体"
    Private Enum KakakukaijiFile
        Topacs = 0
        AASHW
        QCOSHW
        CISCOHW
        IASC
        AASHWServicepac
        QCOSHWServicepac
        SWServicepac
        AASHWMA
        QCOSHWMA
        AASWarrantyOption
        QCOSWarrantyOption
        IGF_USED
        FMA
        SystemService
        ISS
        'START 変更管理#39（No.1544 MA復帰料金の統合)　2017/04 sugo
        MAF
        'QCOSMAF
        'AASMAF
        'END   変更管理#39（No.1544 MA復帰料金の統合)　2017/04 sugo
        BasicSelection
        ServiceIntegrator
        ePricer
        '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) Start
        MSS
        '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) End
    End Enum
#End Region

#Region "定数"

    '==============================
    'EXCEL行位置
    '==============================
    'PaymentLine データ開始行
    Private Const EXCEL_PAYMENTLINEDATE_OUTROW As Integer = 6
    'EXCELの最終行
    Private Const EXCEL_MAX_ROW As Integer = 65536
    'Summaryシートの開始行
    Private Const EXCEL_SUMMARYDATE_OUTROW As Integer = 10

    '==============================
    'EXCEL列位置
    '==============================
    ''個別詳細
    'ファイル名
    Private Const COLDETAIL_FILE_NAME As Integer = 5
    'ファイル名サフィックス
    Private Const COLDETAIL_FILE_NAME_SUFFIX As Integer = 6
    'ファイル内サフィックス
    Private Const COLDETAIL_FILE_NAME_SUFFIX_INTR As Integer = 7
    '契約順
    Private Const COLDETAIL_CONTRACTNO As Integer = 4

    ''SEQ
    Private Const COLDETAIL_SEQ As Integer = 8
    ''識別FLG
    Private Const COLDETAIL_IDENTITY_FLAG As Integer = 9
    ''製品番号
    Private Const COLDETAIL_PROD_NO As Integer = 10
    ''製品名
    Private Const COLDETAIL_PROD_NAME As Integer = 11
    ''MESｶﾃｺﾞﾘ
    Private Const COLDETAIL_MES_CATEGORY As Integer = 15
    ''MESGroup
    Private Const COLDETAIL_MES_GROUP As Integer = 16
    ''特殊Feature
    Private Const COLDETAIL_SPECIAL_FEATURE As Integer = 17
    ''数量
    Private Const COLDETAIL_QTY_INTEGER As Integer = 18
    ''ListPrice単価_ﾘﾌﾚｯｼｭ後
    Private Const COLDETAIL_LIST_PRICE As Integer = 20
    ''ListPrice合計_ﾘﾌﾚｯｼｭ後
    Private Const COLDETAIL_LIST_PRICE_TOTA As Integer = 22
    ''COST_%
    Private Const COLDETAIL_COST_RATE As Integer = 23
    ''COST_単価
    Private Const COLDETAIL_COST As Integer = 24
    ''COST_合計
    Private Const COLDETAIL_COST_TOTAL As Integer = 25
    ''COST_入力日
    Private Const COLDETAIL_COST_INPUT_DATE As Integer = 26

    ''COST開示ファイル（OBAMA-PS）シート
    ''NO
    Private COLCOSTPS_LINE_NO As Integer = 3
    ''ﾌｧｲﾙ名
    Private COLCOSTPS_FILE_NAME As Integer = 4
    ''ﾌｧｲﾙ名Suffix
    Private COLCOSTPS_FILE_NAME_SUFFIX As Integer = 5
    ''ﾌｧｲﾙ内Suffix
    Private COLCOSTPS_FILE_NAME_SUFFIX_INTR As Integer = 6
    ''契約NO
    Private COLCOSTPS_CONTRACTNO As Integer = 7
    ''新規/既存
    Private COLCOSTPS_NEW_EXIST As Integer = 9
    ''ﾊﾟﾀｰﾝ別入力項目_ﾊﾟﾀｰﾝ NO
    Private COLCOSTPS_PATTERN_CD As Integer = 10
    ''ﾊﾟﾀｰﾝ別入力項目_ﾊﾟﾀｰﾝ 名称
    Private COLCOSTPS_PATTERN_NM As Integer = 11
    ''ﾊﾟﾀｰﾝ別入力項目_項目１
    Private COLCOSTPS_PROD_ITEM01 As Integer = 12
    ''ﾊﾟﾀｰﾝ別入力項目_項目２
    Private COLCOSTPS_PROD_ITEM02 As Integer = 13
    ''ﾊﾟﾀｰﾝ別入力項目_項目３
    Private COLCOSTPS_PROD_ITEM03 As Integer = 14
    ''ﾊﾟﾀｰﾝ別入力項目_項目11
    Private COLCOSTPS_PROD_ITEM11 As Integer = 15
    ''ﾊﾟﾀｰﾝ別入力項目_項目12
    Private COLCOSTPS_PROD_ITEM12 As Integer = 16
    ''数量
    Private COLCOSTPS_QTY As Integer = 17
    ''請求開始年月
    Private COLCOSTPS_PAYSTRYM As Integer = 18
    ''請求終了年月
    Private COLCOSTPS_PAYENDYM As Integer = 19

    Private COLCOSTPS_LIST_PRICE_REFLESH As Integer = 23
    ''COST %
    Private COLCOSTPS_COST_RATE As Integer = 25
    ''COST_単価
    Private COLCOSTPS_COST As Integer = 26


    ''COST開示ファイル（PaymentDetail）シート
    ''契約NO
    Private Const COLCOSTDETEIL_CONTRACTNO As Integer = 1
    ''ﾌｧｲﾙ名
    Private Const COLCOSTDETEIL_FILE_NAME As Integer = 2
    ''ﾌｧｲﾙ名Suffix
    Private Const COLCOSTDETEIL_FILE_NAME_SUFFIX As Integer = 3
    ''ﾌｧｲﾙ内Suffix
    Private Const COLCOSTDETEIL_FILE_NAME_SUFFIX_INTR As Integer = 4
    ''SEQ
    Private Const COLCOSTDETEIL_SEQ As Integer = 5
    ''識別FLG
    Private Const COLCOSTDETEIL_IDENTITY_FLAG As Integer = 6
    ''MESカテゴリ
    Private Const COLCOSTDETEIL_MES_CATEGORY As Integer = 7
    ''特殊Feature
    Private Const COLCOSTDETEIL_SPECIAL_FEATURE As Integer = 9
    ''製品番号
    Private Const COLCOSTDETEIL_PROD_NO As Integer = 10
    ''製品名
    Private Const COLCOSTDETEIL_PROD_NAME As Integer = 11
    ''数量
    Private Const COLCOSTDETEIL_QTY_INTEGER As Integer = 12
    ''Listprice単価_ﾘﾌﾚｯｼｭ後
    Private Const COLCOSTDETEIL_LIST_PRICE As Integer = 14
    ''COST_%
    Private Const COLCOSTDETEIL_COST_RATE As Integer = 15
    ''COST_単価
    Private Const COLCOSTDETEIL_COST As Integer = 16
    ''COST_合計
    Private Const COLCOSTDETEIL_COST_TOTAL As Integer = 17

    Private Const COLCISCODETAIL_FILE_NAME As Integer = 5
    Private Const COLCISCODETAIL_FILE_NAME_SUFFIX As Integer = 6
    Private Const COLCISCODETAIL_FILE_NAME_SUFFIX_INTR As Integer = 7

    '==============================
    '個別PS Excelファイルの項目名
    '==============================
    ''ﾛｯｸFLG
    Private Const PSEXCEL_CLOUMNMNAME_LOCK_FLAG As String = "LOCK_FLAG"
    ''有効/無効
    Private Const PSEXCEL_CLOUMNMNAME_VALID_FLAG As String = "VALID_FLAG"
    ''NO
    Private Const PSEXCEL_CLOUMNMNAME_LINE_NO As String = "LINE_NO"
    ''ﾌｧｲﾙ名
    Private Const PSEXCEL_CLOUMNMNAME_FILE_NAME As String = "FILE_NAME"
    ''ﾌｧｲﾙ名Suffix
    Private Const PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX As String = "FILE_NAME_SUFFIX"
    ''ﾌｧｲﾙ内Suffix
    Private Const PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR As String = "FILE_NAME_SUFFIX_INTR"
    ''契約順番
    Private Const PSEXCEL_CLOUMNMNAME_CONTRACTNO As String = "CONTRACTNO"
    ''COST_開示依頼
    Private Const PSEXCEL_CLOUMNMNAME_ST_COST As String = "ST_COST"
    ''新規/既存
    Private Const PSEXCEL_CLOUMNMNAME_NEW_EXIST As String = "NEW_EXIST"
    ''SubBrand
    Private Const PSEXCEL_CLOUMNMNAME_SUB_BRAND As String = "SUB_BRAND"
    ''入力項目ﾊﾟﾀｰﾝ SEQ
    Private Const PSEXCEL_CLOUMNMNAME_PATTERN_CD As String = "PATTERN_CD"
    ''ﾊﾟﾀｰﾝ別入力項目_入力項目ﾊﾟﾀｰﾝ
    Private Const PSEXCEL_CLOUMNMNAME_PATTERN As String = "PATTERN"
    ''ﾊﾟﾀｰﾝ別入力項目_項目１
    Private Const PSEXCEL_CLOUMNMNAME_PROD_ITEM01 As String = "PROD_ITEM01"
    ''ﾊﾟﾀｰﾝ別入力項目_項目２
    Private Const PSEXCEL_CLOUMNMNAME_PROD_ITEM02 As String = "PROD_ITEM02"
    ''ﾊﾟﾀｰﾝ別入力項目_項目３
    Private Const PSEXCEL_CLOUMNMNAME_PROD_ITEM03 As String = "PROD_ITEM03"
    ''ﾊﾟﾀｰﾝ別入力項目_項目４
    Private Const PSEXCEL_CLOUMNMNAME_PROD_ITEM04 As String = "PROD_ITEM04"
    ''ﾊﾟﾀｰﾝ別入力項目_項目５
    Private Const PSEXCEL_CLOUMNMNAME_PROD_ITEM05 As String = "PROD_ITEM05"
    ''ﾊﾟﾀｰﾝ別入力項目_項目８
    Private Const PSEXCEL_CLOUMNMNAME_PROD_ITEM08 As String = "PROD_ITEM08"
    ''ﾊﾟﾀｰﾝ別入力項目_項目11
    Private Const PSEXCEL_CLOUMNMNAME_PROD_ITEM11 As String = "PROD_ITEM11"
    ''ﾊﾟﾀｰﾝ別入力項目_項目12
    Private Const PSEXCEL_CLOUMNMNAME_PROD_ITEM12 As String = "PROD_ITEM12"
    ''数量
    Private Const PSEXCEL_CLOUMNMNAME_QTY As String = "QTY"
    ''請求開始年月
    Private Const PSEXCEL_CLOUMNMNAME_PAYSTRYM As String = "PAYSTRYM"
    ''請求終了年月
    Private Const PSEXCEL_CLOUMNMNAME_PAYENDYM As String = "PAYENDYM"
    ''請求期間
    Private Const PSEXCEL_CLOUMNMNAME_PAY_MONTHS As String = "PAY_MONTHS"
    ''支払方法
    Private Const PSEXCEL_CLOUMNMNAME_PAY_METHOD As String = "PAY_METHOD"
    ''Listprice(単価)_ﾘﾌﾚｯｼｭ後
    Private Const PSEXCEL_CLOUMNMNAME_LIST_PRICE_REFLESH As String = "LIST_PRICE_REFLESH"
    ''Listprice(合計)_ﾘﾌﾚｯｼｭ後
    Private Const PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH As String = "LIST_PRICE_TOTAL_REFLESH"
    ''ListPrice期間合計
    Private Const PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_IOC As String = "LIST_PRICE_TOTAL_IOC"
    ''COST%
    Private Const PSEXCEL_CLOUMNMNAME_COST_RATE As String = "COST_RATE"
    ''COST_単価
    Private Const PSEXCEL_CLOUMNMNAME_COST As String = "COST"
    ''COST_合計
    Private Const PSEXCEL_CLOUMNMNAME_COST_TOTAL As String = "COST_TOTAL"
    ''COST_合計
    Private Const PSEXCEL_CLOUMNMNAME_COST_TOTAL_IOC As String = "COST_TOTAL_IOC"
    ''COST_入力日
    Private Const PSEXCEL_CLOUMNMNAME_COST_INPUT_DATE As String = "COST_INPUT_DATE"
    ''Option1
    Private Const PSEXCEL_CLOUMNMNAME_OPTION1 As String = "OPTION1"
    ''Option2
    Private Const PSEXCEL_CLOUMNMNAME_OPTION2 As String = "OPTION2"
    ''Excel行
    Private Const PSEXCEL_CLOUMNMNAME_EXCELROW As String = "EXCELROW"
    ''参考行
    Private Const PSEXCEL_CLOUMNMNAME_REFERENCE_ROWCOUNT As String = "REFERENCE_ROWCOUNT"
    ''ost単価/Cost％の文字列チェック
    ''詳細データがNGの理由
    Private Const PSEXCEL_CLOUMNMNAME_DETAILNG As String = "DETAILNG"
    ''起票番号
    Private Const PSEXCEL_CLOUMNMNAME_BRAND_AP_FORM As String = "BRAND_AP_FORM"
    ''申請番号
    Private Const PSEXCEL_CLOUMNMNAME_BRAND_AP_REQ As String = "BRAND_AP_REQ"
    ''承認番号
    Private Const PSEXCEL_CLOUMNMNAME_BRAND_AP_CONF As String = "BRAND_AP_CONF"
    ''DetailCount
    Private Const PSEXCEL_CLOUMNMNAME_DetailCount As String = "DetailCount"         ''紐づく詳細ﾃﾞｰﾀ件数。
    ''申請番号
    Private Const PSEXCEL_CLOUMNMNAME_DP_IOC As String = "DP_IOC"
    ''申請番号
    Private Const PSEXCEL_CLOUMNMNAME_PRICE_UNIT_IOC As String = "PRICE_UNIT_IOC"
    ''申請番号
    Private Const PSEXCEL_CLOUMNMNAME_PRICE_UNIT_IOC_VAL As String = "PRICE_UNIT_IOC_VAL"
    ''申請番号
    Private Const PSEXCEL_CLOUMNMNAME_PRICE_QTY_IOC As String = "PRICE_QTY_IOC"

    '==============================
    '個別詳細 Excelファイルの項目名
    '==============================
    ''Excelの行番号
    Private Const PSDETAILEXCEL_CLOUMNMNAME_EXCELROW As String = "EXCELROW"
    ''契約順番
    Private Const PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO As String = "CONTRACTNO"
    ''ﾌｧｲﾙ名
    Private Const PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME As String = "FILE_NAME"
    ''ﾌｧｲﾙ名Suffix
    Private Const PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX As String = "FILE_NAME_SUFFIX"
    ''ﾌｧｲﾙ内Suffix
    Private Const PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR As String = "FILE_NAME_SUFFIX_INTR"
    ''SEQ
    Private Const PSDETAILEXCEL_CLOUMNMNAME_SEQ As String = "SEQ"

    ''識別FLG
    Private Const PSDETAILEXCEL_CLOUMNMNAME_IDENTITY_FLAG As String = "IDENTITY_FLAG"
    ''製品番号
    Private Const PSDETAILEXCEL_CLOUMNMNAME_PROD_NO As String = "PROD_NO"
    ''製品名
    Private Const PSDETAILEXCEL_CLOUMNMNAME_PROD_NAME As String = "PROD_NAME"
    ''MESｶﾃｺﾞﾘ
    Private Const PSDETAILEXCEL_CLOUMNMNAME_MES_CATEGORY As String = "MES_CATEGORY"
    ''MESGroup
    Private Const PSDETAILEXCEL_CLOUMNMNAME_MES_GROUP As String = "MES_GROUP"
    ''特殊Feature
    Private Const PSDETAILEXCEL_CLOUMNMNAME_SPECIAL_FEATURE As String = "SPECIAL_FEATURE"
    ''数量
    Private Const PSDETAILEXCEL_CLOUMNMNAME_QTY_INTEGER As String = "QTY_INTEGER"
    ''ListPrice単価_ﾘﾌﾚｯｼｭ後
    Private Const PSDETAILEXCEL_CLOUMNMNAME_LIST_PRICE As String = "LIST_PRICE"
    ''ListPrice合計_ﾘﾌﾚｯｼｭ後
    Private Const PSDETAILEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL As String = "LIST_PRICE_TOTAL"
    ''COST_%
    Private Const PSDETAILEXCEL_CLOUMNMNAME_COST_RATE As String = "COST_RATE"
    ''COST_単価
    Private Const PSDETAILEXCEL_CLOUMNMNAME_COST As String = "COST"
    ''COST_合計
    Private Const PSDETAILEXCEL_CLOUMNMNAME_COST_TOTAL As String = "COST_TOTAL"
    ''COST_入力日
    Private Const PSDETAILEXCEL_CLOUMNMNAME_COST_INPUT_DATE As String = "COST_INPUT_DATE"
    ''COSTが入力済みかどうか?
    Private Const PSDETAILEXCEL_CLOUMNMNAME_ISCOSTSET As String = "ISCOSTSET"           ''0:未入力　1:入力済み
    ''Boxの製品番号
    Private Const PSDETAILEXCEL_CLOUMNMNAME_PROD_ITEM01 As String = "PROD_ITEM01"
    ''MESカテゴリのソート順
    Private Const PSDETAILEXCEL_CLOUMNMNAME_SORT_MES_CATEGORY As String = "SORT_MES_CATEGORY"   ''MESの並び順に使用⇒空白:0 To:1 CA:2 A:3
    ''承認番号
    Private Const PSDETAILEXCEL_CLOUMNMNAME_BRAND_AP_CONF As String = "BRAND_AP_CONF"

    '==============================
    'COST開示 Excelファイルの項目名(OBAMA-PS)シート
    '==============================
    ''NO
    Private COSTPSEXCEL_CLOUMNMNAME_LINE_NO As String = "LINE_NO"
    ''ﾌｧｲﾙ名
    Private COSTPSEXCEL_CLOUMNMNAME_FILE_NAME As String = "FILE_NAME"
    ''ﾌｧｲﾙ名Suffix
    Private COSTPSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX As String = "FILE_NAME_SUFFIX"
    ''ﾌｧｲﾙ内Suffix
    Private COSTPSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR As String = "FILE_NAME_SUFFIX_INTR"
    ''契約NO
    Private COSTPSEXCEL_CLOUMNMNAME_CONTRACTNO As String = "CONTRACTNO"
    ''新規/既存
    Private COSTPSEXCEL_CLOUMNMNAME_NEW_EXIST As String = "NEW_EXIST"
    ''ﾊﾟﾀｰﾝ別入力項目_ﾊﾟﾀｰﾝ NO
    Private COSTPSEXCEL_CLOUMNMNAME_PATTERN_CD As String = "PATTERN_CD"
    ''ﾊﾟﾀｰﾝ別入力項目_ﾊﾟﾀｰﾝ名称
    Private COSTPSEXCEL_CLOUMNMNAME_PATTERN_NM As String = "PATTERN_NM"
    ''ﾊﾟﾀｰﾝ別入力項目_項目１
    Private COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM01 As String = "PROD_ITEM01"
    ''ﾊﾟﾀｰﾝ別入力項目_項目２
    Private COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM02 As String = "PROD_ITEM02"
    ''ﾊﾟﾀｰﾝ別入力項目_項目４
    Private COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM04 As String = "PROD_ITEM04"
    ''数量
    Private COSTPSEXCEL_CLOUMNMNAME_QTY As String = "QTY"
    ''Listprice(単価)_ﾘﾌﾚｯｼｭ後
    Private COSTPSEXCEL_CLOUMNMNAME_LIST_PRICE_REFLESH As String = "LIST_PRICE_REFLESH"
    ''COST %
    Private COSTPSEXCEL_CLOUMNMNAME_COST_RATE As String = "COST_RATE"
    ''COST_単価
    Private COSTPSEXCEL_CLOUMNMNAME_COST As String = "COST"
    ''Brand Category_Option1
    Private COSTPSEXCEL_CLOUMNMNAME_OPTION1 As String = "OPTION1"
    ''Excel行番
    Private COSTPSEXCEL_CLOUMNMNAME_EXCELROW As String = "EXCEL_ROW"

    ''Cost開示取込NG理由
    Private COSTPSEXCEL_CLOUMNMNAME_NGREASON As String = "NGREASON"

    ''Cost開示取込NG理由 値の種類
    Private COST_NGREASON_UNMATCHCOSTPSTOCOSTDETAIL As String = "UNMATCHCOSTPSTOCOSTDETAIL"             ''コスト開示PSシートに紐づくCOST開示詳細シートデータが存在しない。
    Private COST_NGREASON_COSTINPUTERR As String = "COSTINPUTERR"                                       ''Costの入力が不正
    Private COST_NGREASON_UNMATCHCOSTPSTOPSDATE As String = "UNMATCHCOSTPSTOPSDATE"                     ''CostPSシートとPaymantファイルの紐づけデータが見つからない。
    Private COST_NGREASON_QTYINPUTERR As String = "QTYINPUTERR"                                         ''Paymentファイルの数量が不正
    Private COST_NGREASON_UNMATCHCOSTDETAILTOCOSTPS As String = "UNMATCHCOSTDETAILTOCOSTPS"             ''COST開示詳細シートに紐づくCOST開示PSシートが存在しない。
    Private COST_NGREASON_UNMATCHCOSTDETAILTOPSDETAIL As String = "UNMATCHCOSTDETAILTOCOSTDETAIL"       ''COST開示詳細シートに紐づく個別詳細ファイルデータが存在しない。
    Private COST_NGREASON_UNMATCHCOSCOUNTDETAILPSDETAIL As String = "UNMATCHCOSCOUNTDETAILPSDETAIL"     ''COST開示詳細件数と個別詳細の件数が一致しない。
    Private COST_NGREASON_UNMATCHCOSCOUNTDETAILPSDETAIL_LARGE As String = "UNMATCHCOSCOUNTDETAILPSDETAIL_LARGE"   ''COST開示詳細件数個別詳細の件数が一致しない（詳細データの方がﾃﾞｰﾀが多い）。
    Private COST_NGREASON_COSTCULCULATE As String = "COSTCULCULATE"                                     ''COST %が正しく計算されていない。

    '==============================
    'COST開示 Excelファイルの項目名(PaymentDetail)シート
    '==============================
    ''契約NO    
    Private Const COSTDETAILEXCEL_CLOUMNMNAME_CONTRACTNO As String = "CONTRACTNO"
    ''ﾌｧｲﾙ名
    Private Const COSTDETAILEXCEL_CLOUMNMNAME_FILE_NAME As String = "FILE_NAME"
    ''ﾌｧｲﾙ名Suffix
    Private Const COSTDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX As String = "FILE_NAME_SUFFIX"
    ''ﾌｧｲﾙ内Suffix
    Private Const COSTDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR As String = "FILE_NAME_SUFFIX_INTR"
    ''SEQ
    Private Const COSTDETAILEXCEL_CLOUMNMNAME_SEQ As String = "SEQ"
    ''識別FLG
    Private Const COSTDETAILEXCEL_CLOUMNMNAME_IDENTITY_FLAG As String = "IDENTITY_FLAG"
    ''製品番号
    Private Const COSTDETAILEXCEL_CLOUMNMNAME_PROD_NO As String = "PROD_NO"
    ''製品名
    Private Const COSTDETAILEXCEL_CLOUMNMNAME_PROD_NAME As String = "PROD_NAME"
    ''MESカテゴリ
    Private Const COSTDETAILEXCEL_CLOUMNMNAME_MES_CATEGORY As String = "MES_CATEGORY"
    ''特殊Feature
    Private Const COSTDETAILEXCEL_CLOUMNMNAME_SPECIAL_FEATURE As String = "SPECIAL_FEATURE"
    ''数量
    Private Const COSTDETAILEXCEL_CLOUMNMNAME_QTY_INTEGER As String = "QTY_INTEGER"
    ''Listprice単価_ﾘﾌﾚｯｼｭ後
    Private Const COSTDETAILEXCEL_CLOUMNMNAME_LIST_PRICE As String = "LIST_PRICE"
    ''COST_%
    Private Const COSTDETAILEXCEL_CLOUMNMNAME_COST_RATE As String = "COST_RATE"
    ''COST_単価
    Private Const COSTDETAILEXCEL_CLOUMNMNAME_COST As String = "COST"
    ''COST_単価
    Private Const COSTDETAILEXCEL_CLOUMNMNAME_COST_TOTAL As String = "COST_TOTAL"
    ''Excel行番号
    Private Const COSTDETAILEXCEL_CLOUMNMNAME_EXCELROW As String = "EXCEL_ROW"
    ''取込失敗の理由
    Private Const COSTDETAILEXCEL_CLOUMNMNAME_NGREASON As String = "NGREASON"

    ''パターンコード対象外
    Private Const COSTFILE_FILETYPE_NONE As String = "0"

    '==============================
    'Topacsファイルの項目
    '==============================
    ''AAS HWｼｰﾄ
    Private Const TOPACSAAS_CLOUMNMNAME_SHINSEINO As String = "SHINSEINO"                 ''申請書番号
    Private Const TOPACSAAS_CLOUMNMNAME_KIHYONO As String = "KIHYONO"                     ''起票番号
    Private Const TOPACSAAS_CLOUMNMNAME_LINENO As String = "LINENO"                       ''行番号
    Private Const TOPACSAAS_CLOUMNMNAME_ADD_REC As String = "ADD_REC"                     ''追加明細区分
    Private Const TOPACSAAS_CLOUMNMNAME_FH As String = "FH"                               ''BF区分
    Private Const TOPACSAAS_CLOUMNMNAME_CODEAH As String = "CODEAH"                       ''機械番号
    Private Const TOPACSAAS_CLOUMNMNAME_ORAH As String = "ORAH"                           ''オーダーナンバー
    Private Const TOPACSAAS_CLOUMNMNAME_FCODEAH As String = "FCODEAH"                     ''FEATURE/RPQ
    Private Const TOPACSAAS_CLOUMNMNAME_NAMEAH As String = "NAMEAH"                       ''名称
    Private Const TOPACSAAS_CLOUMNMNAME_NAHD As String = "NAHD"                           ''台数
    Private Const TOPACSAAS_CLOUMNMNAME_AJAH As String = "AJAH"                           ''増減
    Private Const TOPACSAAS_CLOUMNMNAME_CAH_DSP As String = "CAH_DSP"                     ''標準価格
    Private Const TOPACSAAS_CLOUMNMNAME_TOTALAH As String = "TOTALAH"                     ''標準価格(台数分合計）
    Private Const TOPACSAAS_CLOUMNMNAME_TOTALAHMS As String = "TOTALAHMS"                 ''標準価格（単価分）
    Private Const TOPACSAAS_CLOUMNMNAME_COSTMCAH As String = "COSTMCAH"                   ''COST　TMC 
    Private Const TOPACSAAS_CLOUMNMNAME_COSTMCAHM As String = "COSTMCAHM"                 ''COST　TMC (台数分合計）
    Private Const TOPACSAAS_CLOUMNMNAME_EXISTSUPDATE As String = "EXISTSUPDATE"           ''更新済かどうか？　空白:=未更新 1：更新済み
    Private Const TOPACSAAS_CLOUMNMNAME_EXCELROW As String = "EXCELROW"                   ''Excelの行位置
    Private Const TOPACSAAS_CLOUMNMNAME_UNMATREASON As String = "UNMATREASON"             ''不一致の理由
    Private Const TOPACSAAS_CLOUMNMNAME_DETAILROW As String = "DETAILROW"                 ''紐づいている詳細ﾃﾞｰﾀの判定にしよう

    ''Key項目
    Private Const TOPACSAAS_CLOUMNMNAME_BOXCODEAH As String = "BOXCODEAH"                 ''親の機械番号
    Private Const TOPACSAAS_CLOUMNMNAME_BOXSEQ As String = "BOXSEQ"                       ''親の機械番号のSEQ番号 001⇒起票/申請番号の重複ごとにインクリメント
    Private Const TOPACSAAS_CLOUMNMNAME_MATCH_PSLINE As String = "MATCH_PSLINE"           ''マッチしたPS上の行NO

    ''QCOS HWｼｰﾄ                                                                          
    Private Const TOPACSQCOSHW_CLOUMNMNAME_SHINSEINO As String = "SHINSEINO"              ''申請書番号
    Private Const TOPACSQCOSHW_CLOUMNMNAME_KIHYONO As String = "KIHYONO"                  ''起票番号
    Private Const TOPACSQCOSHW_CLOUMNMNAME_LINENO As String = "LINENO"                    ''行番号
    Private Const TOPACSQCOSHW_CLOUMNMNAME_ADD_REC As String = "ADD_REC"                  ''追加明細区分
    Private Const TOPACSQCOSHW_CLOUMNMNAME_CODEQH As String = "CODEQH"                    ''パーツ番号
    Private Const TOPACSQCOSHW_CLOUMNMNAME_NQHD As String = "NQHD"                        ''台数
    Private Const TOPACSQCOSHW_CLOUMNMNAME_AJQH As String = "AJQH"                        ''増減
    Private Const TOPACSQCOSHW_CLOUMNMNAME_CQH_DSP As String = "CQH_DSP"                  ''標準価格(単価）
    Private Const TOPACSQCOSHW_CLOUMNMNAME_TOTALQH As String = "TOTALQH"                  ''標準価格(台数分合計）
    Private Const TOPACSQCOSHW_CLOUMNMNAME_COSTMCQH As String = "COSTMCQH"                ''COST TMC
    Private Const TOPACSQCOSHW_CLOUMNMNAME_COSTMCQHM As String = "COSTMCQHM"              ''COST TMC(台数分合計)
    Private Const TOPACSQCOSHW_CLOUMNMNAME_COSTSWQH As String = "COSTSWQH"                ''COST 内蔵SW(単価)
    Private Const TOPACSQCOSHW_CLOUMNMNAME_COSTSWQHM As String = "COSTSWQHM"              ''COST 内蔵SW(台数分合計)
    Private Const TOPACSQCOSHW_CLOUMNMNAME_EXCELROW As String = "EXCELROW"                ''Excelの行位置
    Private Const TOPACSQCOSHW_CLOUMNMNAME_UNMATREASON As String = "UNMATREASON"          ''不一致の理由

    ''Key項目
    Private Const TOPACSQCOSHW_CLOUMNMNAME_MATCH_PSLINE As String = "MATCH_PSLINE"        ''マッチしたPS上の行NO

    ''QCOS SWｼｰﾄ
    Private Const TOPACSQCOSSW_CLOUMNMNAME_SHINSEINO As String = "SHINSEINO"              ''申請書番号
    Private Const TOPACSQCOSSW_CLOUMNMNAME_KIHYONO As String = "KIHYONO"                  ''起票番号
    Private Const TOPACSQCOSSW_CLOUMNMNAME_LINENO As String = "LINENO"                    ''行番号
    Private Const TOPACSQCOSSW_CLOUMNMNAME_ADD_REC As String = "ADD_REC"                  ''追加明細区分
    Private Const TOPACSQCOSSW_CLOUMNMNAME_CODEQS As String = "CODEQS"                    ''パーツ番号
    Private Const TOPACSQCOSSW_CLOUMNMNAME_ORQS As String = "ORQS"                        ''オーダーナンバー
    Private Const TOPACSQCOSSW_CLOUMNMNAME_NAMEQS As String = "NAMEQS"                    ''名称
    Private Const TOPACSQCOSSW_CLOUMNMNAME_NQSD As String = "NQSD"                        ''台数
    Private Const TOPACSQCOSSW_CLOUMNMNAME_AJQS As String = "AJQS"                        ''増減
    Private Const TOPACSQCOSSW_CLOUMNMNAME_CQS_DSP As String = "CQS_DSP"                  ''標準価格(単価）
    Private Const TOPACSQCOSSW_CLOUMNMNAME_TOTALQS As String = "TOTALQS"                  ''標準価格(台数分合計）
    Private Const TOPACSQCOSSW_CLOUMNMNAME_COSTMCQS As String = "COSTMCQS"                ''COST TMC
    Private Const TOPACSQCOSSW_CLOUMNMNAME_COSTMCQSM As String = "COSTMCQSM"              ''COST TMC (台数分合計）
    Private Const TOPACSQCOSSW_CLOUMNMNAME_COSTRITSUQS As String = "COSTRITSUQS"          ''COST率
    Private Const TOPACSQCOSSW_CLOUMNMNAME_EXCELROW As String = "EXCELROW"                ''Excelの行位置
    Private Const TOPACSQCOSSW_CLOUMNMNAME_UNMATREASON As String = "UNMATREASON"          ''不一致の理由

    ''Key項目
    Private Const TOPACSQCOSSW_CLOUMNMNAME_MATCH_PSLINE As String = "MATCH_PSLINE"        ''マッチしたPS上の行NO

    '==============================
    'e-Pricerファイルの項目
    '==============================
    Private Const EPRICER_COMP_COLUMNNAME_ROWNO As String = "ROW_NO"                        '行
    'Req:1484 Rewrite対応 str
    'Private Const EPRICER_COMP_COLUMNNAME_TRANSACTIONID As String = "TransactionID"
    Private Const EPRICER_COMP_COLUMNNAME_QUOTEID As String = "QuoteID"
    'Req:1484 Rewrite対応 end
    Private Const EPRICER_COMP_COLUMNNAME_TYPE As String = "TYPE"
    Private Const EPRICER_COMP_COLUMNNAME_MODEL As String = "MODEL"
    Private Const EPRICER_COMP_COLUMNNAME_QTY As String = "Quantity"
    Private Const EPRICER_COMP_COLUMNNAME_LISTPRICE As String = "Listprice"
    'Req:1484 Rewrite対応 str
    'Private Const EPRICER_COMP_COLUMNNAME_ESTIMATED_TMC As String = "Estimated_Tmc"
    Private Const EPRICER_COMP_COLUMNNAME_COST As String = "COST"
    'Req:1484 Rewrite対応 end
    Private Const EPRICER_COMP_COLUMNNAME_LOG As String = "LOG"                        'ログ（値が数字の場合、Paymentの出力行の位置とする）

#End Region

#Region "プライベート変数"
    Private createFileTime As String

    Private CountB As Integer = 0
    Public BrandT() As BrandTable

    Private CountC As Integer = 0
    Public CostData() As CostInputData

    Private MaxPS As Long
    Private MaxSS As Long

    'CISCO用読込除外件数
    Private exCiscoCnt As Integer
#End Region

#Region "パブリックメソッド"

#Region "価格開示ファイル作成処理"

    ''' <summary>
    ''' 価格開示ファイル作成処理
    ''' </summary>
    ''' <param name="sourceFilePath1">>PSファイルパス</param>
    ''' <param name="intMsgKind">メッセージの種類</param>
    ''' <param name="Msg">出力メッセージ</param>
    ''' <remarks></remarks>
    Public Function OutputExcelKakakukaiji(ByVal sourceFilePath1 As String, ByRef Msg As String) As Boolean

        OutputExcelKakakukaiji = False
        ''例外処理の補足：各種価格開示ファイル作成中、エラーがあった場合、後続の処理を続行する。
        ''　　　　　　　　エラーがあった場合、エラーがあったファイルの数、例外メッセージを表示		
        ''　　　　　　　　エラーがあった場合、完了メッセージにてどのファイルが作成 or 作成できなかったのかを表示
        Try
            ''個別PS Excel情報をテーブルへ格納
            Dim PSDataTable As New DataTable
            Call GetPSDataTableInfo(PSDataTable, sourceFilePath1)

            ''個別詳細 Excel情報をテーブルへ格納
            Dim PSDetailDataTable As New DataTable
            Call GetPSDetailDataTableInfo(PSDetailDataTable, sourceFilePath1)

            ''重複情報を削除した値をテーブルへ格納
            Dim DelOverlapPSDataTable As New DataTable
            DelOverlapPSDataTable = GetDelOverlapPSDataTable(PSDataTable)

            ''各種価格開示ファイルの作成
            ''ファイルの作成が成功したかどうか
            '※列挙体KakakukaijiFileの要素数から設定
            Dim IsKakakukaijiCreate([Enum].GetValues(GetType(KakakukaijiFile)).Length) As Boolean

            ''ファイルの作成日時を保持
            Me.createFileTime = Now.ToString("yyyyMMdd_HHmmss")

            ''Cost開示フォルダの作成
            Dim ofm As New OioFileManage
            ofm.CreateLocalCostFileFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

            IsKakakukaijiCreate(KakakukaijiFile.Topacs) = CreateKakakukaijiTopacs(PSDataTable, PSDetailDataTable)                     ''Topacs用Cost開示　※AASHWとQCOSHWを新フォーマットで統一する。

            IsKakakukaijiCreate(KakakukaijiFile.CISCOHW) = CreateKakakukaijiCISCOHW(PSDataTable, PSDetailDataTable)                 ''CISCO HW

            IsKakakukaijiCreate(KakakukaijiFile.IASC) = CreateKakakukaijiIASC(DelOverlapPSDataTable)                                          ''IASC

            ''HW ServicePacのCost開示ファイルをAASとQCOSに分割する
            IsKakakukaijiCreate(KakakukaijiFile.AASHWServicepac) = CreateKakakukaijiAASHWServicepac(DelOverlapPSDataTable)          ''AAS HW Servicepac

            IsKakakukaijiCreate(KakakukaijiFile.QCOSHWServicepac) = CreateKakakukaijiQCOSHWServicepac(DelOverlapPSDataTable)        ''QCOS HW Servicepac

            IsKakakukaijiCreate(KakakukaijiFile.SWServicepac) = CreateKakakukaijiSWServicepac(DelOverlapPSDataTable)                ''SW Servicepac

            IsKakakukaijiCreate(KakakukaijiFile.AASHWMA) = CreateKakakukaijiAASHWMA(PSDataTable, DelOverlapPSDataTable, PSDetailDataTable)            ''AAS HWMA

            IsKakakukaijiCreate(KakakukaijiFile.QCOSHWMA) = CreateKakakukaijiQCOSHWMA(DelOverlapPSDataTable)                  ''QCOS HWMA


            IsKakakukaijiCreate(KakakukaijiFile.AASWarrantyOption) = CreateKakakukaijiAASWarrantyOption(DelOverlapPSDataTable)      ''AAS 保障ｵﾌﾟｼｮﾝ	

            IsKakakukaijiCreate(KakakukaijiFile.QCOSWarrantyOption) = CreateKakakukaijiQCOSWarrantyOption(DelOverlapPSDataTable)    ''QCOS 保障ｵﾌﾟｼｮﾝ	


            IsKakakukaijiCreate(KakakukaijiFile.IGF_USED) = CreateKakakukaijiIGF_USED(PSDataTable, PSDetailDataTable)                     ''IGF_USED

            IsKakakukaijiCreate(KakakukaijiFile.FMA) = CreateKakakukaijiFMA(PSDataTable)                                ''拡張保守	

            IsKakakukaijiCreate(KakakukaijiFile.SystemService) = CreateKakakukaijiSystemService(PSDataTable)                      ''システムサービス

            IsKakakukaijiCreate(KakakukaijiFile.ISS) = CreateKakakukaijiISS(PSDataTable)                      ''ISS

            'START 変更管理#39（No.1544 MA復帰料金の統合)　2017/04 sugo
            IsKakakukaijiCreate(KakakukaijiFile.MAF) = CreateKakakukaijiAASMAF(DelOverlapPSDataTable)                      ''MA復帰料金
            'IsKakakukaijiCreate(KakakukaijiFile.QCOSMAF) = CreateKakakukaijiQCOSMAF(DelOverlapPSDataTable)                      ''QCOS MA復帰料金

            'IsKakakukaijiCreate(KakakukaijiFile.AASMAF) = CreateKakakukaijiAASMAF(DelOverlapPSDataTable)                      ''AAS MA復帰料金
            'END   変更管理#39（No.1544 MA復帰料金の統合)　2017/04 sugo

            IsKakakukaijiCreate(KakakukaijiFile.BasicSelection) = CreateKakakukaijiBasicSelection(DelOverlapPSDataTable)                ''ﾍﾞｰｼｯｸｾﾚｸｼｮﾝ

            IsKakakukaijiCreate(KakakukaijiFile.ServiceIntegrator) = CreateKakakukaijiServiceIntegrator(DelOverlapPSDataTable)          ''ServiceIntegrator

            'e-Pricer
            IsKakakukaijiCreate(KakakukaijiFile.ePricer) = CreateKakakukaijiePricer(PSDataTable, PSDetailDataTable)          'e-Pricer

            ''1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) Start
            IsKakakukaijiCreate(KakakukaijiFile.MSS) = CreateKakakukaijiMSS(PSDataTable)                                ''MSS
            '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) End

            ''処理完了メッセージの作成
            Msg = CreateExitMsg(IsKakakukaijiCreate)

            OutputExcelKakakukaiji = True

        Catch ex As Exception
            Msg = ex.Message.ToString

        End Try

    End Function


#End Region

#Region "価格開示ファイルPS、個別詳細反映処理"

    ''' <summary>
    ''' 価格開示ファイルPS、個別詳細反映処理
    ''' </summary>
    ''' <remarks></remarks>
    Public Function KakakukaijiReflection(ByVal costKaijiFilePaths() As String, _
                                          ByVal PSFilePath As String, _
                                          ByRef rtnMessage As String) As Boolean


        ''Excelのオブジェト
        Dim xlApp As New Excel.Application
        Dim PSBook As Excel.Workbook
        Dim CostKaijiBook As Excel.Workbook

        ''Excel初期設定
        xlApp.EnableEvents = False
        xlApp.DisplayAlerts = False

        ''排他更新制御の補足：以下の仕様で処理を行う
        ''※個別PS,個別詳細BookのOpen、読込み等、反映処理全体の処理にエラーがあった場合
        ''  ⇒呼び出し元にエラーを返す。
        ''※各Cost開示ファイルの読込み、反映処理中にエラーがあった場合
        ''  ⇒outErrMessageにメッセージを追加し、処理完了メッセージにて表示
        Dim loopCount As Integer = 0
        Dim outCntPS As Integer = 0

        ''処理の完了メッセージ作成に使用
        Dim outFileNMes() As String
        Dim inCntPSes() As Integer
        Dim outCntPSes() As Integer
        Dim outErrMessage() As String

        Try

            ''個別PSBookをDataTableへセット
            Dim PSDataTable As New DataTable
            Call GetPSDataTableInfo(PSDataTable, PSFilePath)

            ''個別詳細BookをDataTableへセット
            Dim DetailDataTable As New DataTable
            Call GetPSDetailDataTableInfo(DetailDataTable, PSFilePath)
            Call DelSLineDate("Detail", DetailDataTable)

            ''個別PS、詳細Bookの取得
            PSBook = xlApp.Workbooks.Open(PSFilePath)

            ''返り値のリサイズ
            If IsNothing(costKaijiFilePaths) = False Then
                ReDim outFileNMes(costKaijiFilePaths.Length - 1)
                ReDim inCntPSes(costKaijiFilePaths.Length - 1)
                ReDim outCntPSes(costKaijiFilePaths.Length - 1)
                ReDim outErrMessage(costKaijiFilePaths.Length - 1)
            End If

            ''各種Costファイル毎の処理
            For Each costKaijiFilePath As String In costKaijiFilePaths

                Try
                    ''----------------------
                    ''COST開示ファイルの読込
                    ''----------------------
                    outFileNMes(loopCount) = Path.GetFileName(costKaijiFilePath)
                    CostKaijiBook = xlApp.Workbooks.Open(costKaijiFilePath)

                    ''個別PSシート
                    Dim CostKaijiPSSheetData As DataTable
                    CostKaijiPSSheetData = GetPSCostKaijiData(CostKaijiBook)

                    ''個別詳細シート
                    Dim CostKaijiDetailSheetData As DataTable
                    CostKaijiDetailSheetData = GetDetailCostKaijiData(CostKaijiBook)
                    If IsNothing(CostKaijiDetailSheetData) = False Then
                        Call DelSLineDate("Cost", CostKaijiDetailSheetData)
                    End If

                    ''参考シート
                    ''※既存AASHMAの場合、参考シートのデータを元に取込む
                    ''※既存の処理を流用するため、参考シートデータをCostKaijiPSSheetDataにセット
                    Dim CostDefSheetData As DataTable
                    CostDefSheetData = GetPSCostRefData(CostKaijiBook)
                    If IsNothing(CostDefSheetData) = False AndAlso _
                       CostDefSheetData.Rows.Count > 0 Then
                        CostKaijiPSSheetData = CostDefSheetData
                    End If

                    ''Topacsｼｰﾄ
                    Dim patternCD As String = ""
                    Dim TopacsTBL() As DataTable
                    TopacsTBL = GetTopacsCostKaijiData(CostKaijiBook, patternCD)

                    'e-Pricer用COST開示ファイルからデータ取得
                    Dim ePricerTBL() As DataTable
                    ePricerTBL = GetEPricerCostKaijiData(CostKaijiBook, patternCD)

                    ''対象のデータかどうか判定
                    Dim newExist As String
                    Call GetCostFileType(CostKaijiPSSheetData, patternCD, newExist, TopacsTBL)
                    '課題No1278 Str
                    Select Case patternCD
                        Case COSTFILE_FILETYPE_NONE, _
                             CommonConstant.PATTERNCD_TYPE_OtherMVMS, _
                             CommonConstant.PATTERNCD_TYPE_MAINTENANCE
                            CostKaijiBook.Close(False)
                            outCntPSes(loopCount) = 0
                            Continue For
                    End Select

                    ''パターンに応じて、ファイルの書き込 み
                    Call WriteCostData(PSBook, _
                                       CostKaijiBook, _
                                       PSDataTable, _
                                       DetailDataTable, _
                                       CostKaijiPSSheetData, _
                                       CostKaijiDetailSheetData, _
                                       patternCD, _
                                       newExist, _
                                       outCntPS, _
                                       TopacsTBL,
                                       ePricerTBL)

                    ''Cost開示ファイルの件数と、読込件数をセット
                    If patternCD = "Topacs" Then
                        inCntPSes(loopCount) = TopacsTBL(0).Rows.Count + TopacsTBL(1).Rows.Count + TopacsTBL(2).Rows.Count
                        outCntPSes(loopCount) = outCntPS
                    Else
                        ''個別PSの書込件数をセット
                        inCntPSes(loopCount) = CostKaijiPSSheetData.Rows.Count + exCiscoCnt
                        exCiscoCnt = 0
                        outCntPSes(loopCount) = outCntPS
                    End If

                    '処理が正常取り込みできた場合のみ、リネーム
                    CostKaijiBook.Save()
                    CostKaijiBook.Close(False)
                    Call CreateBKCostkaijiFile(costKaijiFilePath)

                Catch ex As Exception
                    ''各種Cost開示ファイルの読込み時のエラーを保存
                    outErrMessage(loopCount) = ex.Message
                    inCntPSes(loopCount) = 0
                    outCntPSes(loopCount) = 0

                Finally
                    loopCount = loopCount + 1

                End Try
            Next

            ''最新の日付のファイルを作成
            PSBook.Activate()
            '※VBActNMListに統合
            ExcelWrite.KickVBABookSave(xlApp, PSBook, ExcelWrite.VBActNMList.Cost開示取込, CommonVariable.USERID, CommonVariable.USERPW)

            rtnMessage = GreateExitMessage(outFileNMes, inCntPSes, outCntPSes, outErrMessage)

        Catch ex As Exception
            Throw ex

        Finally
            If IsNothing(PSBook) = False Then
                PSBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(PSBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(CostKaijiBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()

        End Try

    End Function

#End Region

#Region "WS1シートコピー"

    ''' <summary>
    ''' 価格開示ファイルPS、個別詳細反映処理
    ''' </summary>
    ''' <remarks></remarks>
    Public Function CopyWS1(ByRef kaijiBook As Excel.Workbook, _
                            ByRef psBook As Excel.Workbook) As Boolean

        CopyWS1 = False

        Dim psSheet As Excel.Worksheet                ''個別PS　WS1シート
        Dim kaijiSheet As Excel.Worksheet
        Dim selectRange As Excel.Range
        Dim kaijiWS1Sheet As Excel.Worksheet
        Dim shape As Excel.Shape

        Try

            ''WS1を先頭のシートへコピー
            psSheet = psBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_WS1)
            kaijiSheet = kaijiBook.Worksheets(1)
            psSheet.Copy(Before:=kaijiSheet)
            kaijiWS1Sheet = kaijiBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_WS1)
            CopyWS1 = True

        Catch ex As Exception
            Throw ex
        Finally

            ''Excelオブジェ　解放
            ExcelObjRelease.ReleaseExcelObj(selectRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(shape, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(psSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(kaijiSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(kaijiWS1Sheet, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()

        End Try

    End Function

#End Region

#End Region

#Region "プライベートメソッド"

    ''' <summary>
    ''' 機能：行チェック
    ''' 説明：行番、ファイル名、契約順番、案件番号のいずれかにデータあるかチェックする
    ''' 　　　True：ある　False：ない
    ''' </summary>
    ''' <param name="intIndex"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckRowItem(ByVal ExcelCellInfo(,) As Object) As Integer

        CheckRowItem = False

        Try
            '行番、ファイル名、契約順番、案件番号が共に空文字の場合、データ無しとみなす
            If IsNothing(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)) = True And _
                IsNothing(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.FILE_NAME)) = True And _
                IsNothing(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.CONTRACT)) = True And _
                IsNothing(ExcelCellInfo(1, ExcelWrite.ExcelPaymentLineColumn.PROJ_ID)) = True Then
                Exit Function
            End If

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical)
        End Try

        CheckRowItem = True

    End Function

    ''' <summary>
    ''' 機能：行チェック
    ''' 説明：ファイル名、契約順番のいずれかにデータあるかチェックする
    ''' 　　　True：ある　False：ない
    ''' </summary>
    ''' <param name="intIndex"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckRowItemDetail(ByVal ExcelCellInfo(,) As Object) As Integer

        CheckRowItemDetail = False

        Try
            'ファイル名、契約順番、が共に空文字の場合、データ無しとみなす
            If IsNothing(ExcelCellInfo(1, COLDETAIL_FILE_NAME)) = True And _
                IsNothing(ExcelCellInfo(1, COLDETAIL_CONTRACTNO)) = True Then
                Exit Function
            End If
        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical)
        End Try

        CheckRowItemDetail = True

    End Function

    ''' <summary>
    ''' COST欄の空チェック
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function IsCostNullCheck(ByVal ExcelCellInfo() As Object, ByRef rowNo As String) As Boolean
        IsCostNullCheck = False
        'COST%とCOST単価の空チェック
        If Convert.ToString(ExcelCellInfo(76)) = String.Empty And _
           Convert.ToString(ExcelCellInfo(77)) = String.Empty Then
            rowNo = ExcelCellInfo(4)
            Return True
        End If

        'COST入力日の空チェック
        If Convert.ToString(ExcelCellInfo(79)) = String.Empty Then
            rowNo = ExcelCellInfo(4)
            Return True
        End If

    End Function

    ''' <summary>
    ''' 機　能：個別PS Excelファイルの情報をデータテーブルへ格納
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetPSDataTableInfo(ByRef PSDataTable As DataTable, _
                                   ByVal PSFileName As String)

        ''PSDataTableの設定
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_LINE_NO)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_FILE_NAME)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_CONTRACTNO)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_ST_COST)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_NEW_EXIST)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_SUB_BRAND)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_PATTERN)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_PROD_ITEM02)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_PROD_ITEM03)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_PROD_ITEM04)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_PROD_ITEM05)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_PROD_ITEM08)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_PROD_ITEM11)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_PROD_ITEM12)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_QTY)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_PAYSTRYM)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_PAYENDYM)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_PAY_MONTHS)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_PAY_METHOD)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_LIST_PRICE_REFLESH)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_IOC)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_COST_RATE)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_COST)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_COST_TOTAL)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_COST_TOTAL_IOC)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_COST_INPUT_DATE)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_OPTION1)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_OPTION2)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_EXCELROW)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_REFERENCE_ROWCOUNT)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_BRAND_AP_FORM)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_BRAND_AP_REQ)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_DetailCount)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_DP_IOC)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_PRICE_UNIT_IOC)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_PRICE_UNIT_IOC_VAL)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_PRICE_QTY_IOC)
        PSDataTable.Columns.Add(PSEXCEL_CLOUMNMNAME_BRAND_AP_CONF)

        Dim ii As Integer
        Dim fFind As Boolean

        ''Excelオブジェクトの宣言
        Dim excelWrite As New ExcelWrite
        Dim xlApp As New Excel.Application
        Dim xlInBook As Excel.Workbook = Nothing
        Dim xlInSheet As Excel.Worksheet = Nothing
        Dim xlCell As Excel.Range = Nothing
        Dim ExcelLine(,) As Object

        Try
            ''Excelの初期設定
            xlApp.EnableEvents = False
            xlApp.DisplayAlerts = False

            ''BookのOpen
            xlInBook = xlApp.Workbooks.Open(PSFileName)
            xlInSheet = xlInBook.Worksheets(excelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)

            ''Excelのオートフィルタを初期化
            Call ExcelWrite.CrearAutoFilter(xlInSheet)

            ''OBAMA-PSシートのデータの取得
            For i As Integer = excelWrite.EXCEL_PAYMENTLINEDATE_OUTROW To EXCEL_MAX_ROW

                ''行データの取得
                xlCell = xlInSheet.Range("A" & i & ":" & "IT" & i)
                ExcelLine = xlCell.Value

                ''Eofの判定
                If CheckRowItem(ExcelLine) = False Then
                    Exit For
                End If

                ''個別PSの値をセットする。
                Dim row As DataRow
                row = PSDataTable.NewRow()
                row(PSEXCEL_CLOUMNMNAME_EXCELROW) = i.ToString.PadLeft(6, "0")

                row(PSEXCEL_CLOUMNMNAME_LOCK_FLAG) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.LOCK_FLAG))
                row(PSEXCEL_CLOUMNMNAME_VALID_FLAG) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.VALID_FLAG))
                row(PSEXCEL_CLOUMNMNAME_LINE_NO) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.LINE_NO))
                row(PSEXCEL_CLOUMNMNAME_FILE_NAME) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.FILE_NAME))
                row(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX))
                row(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR))
                row(PSEXCEL_CLOUMNMNAME_CONTRACTNO) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.CONTRACT))
                row(PSEXCEL_CLOUMNMNAME_ST_COST) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.ST_COST))
                row(PSEXCEL_CLOUMNMNAME_NEW_EXIST) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.NEW_EXIST))
                row(PSEXCEL_CLOUMNMNAME_SUB_BRAND) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.BRAND_SUB))
                row(PSEXCEL_CLOUMNMNAME_PATTERN_CD) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.PATTERN_CD))
                row(PSEXCEL_CLOUMNMNAME_PATTERN) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.PATTERN))
                row(PSEXCEL_CLOUMNMNAME_PROD_ITEM01) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.PROD_ITEM01))
                row(PSEXCEL_CLOUMNMNAME_PROD_ITEM02) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.PROD_ITEM02))
                row(PSEXCEL_CLOUMNMNAME_PROD_ITEM03) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.PROD_ITEM03))
                row(PSEXCEL_CLOUMNMNAME_PROD_ITEM04) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.PROD_ITEM04))
                row(PSEXCEL_CLOUMNMNAME_PROD_ITEM05) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.PROD_ITEM05))
                row(PSEXCEL_CLOUMNMNAME_PROD_ITEM08) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.PROD_ITEM08))
                row(PSEXCEL_CLOUMNMNAME_PROD_ITEM11) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.PROD_ITEM11))
                row(PSEXCEL_CLOUMNMNAME_PROD_ITEM12) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.PROD_ITEM12))
                row(PSEXCEL_CLOUMNMNAME_QTY) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.QTY))
                ''契約開始/終了年月のセット
                Dim payStrYm As String
                Dim payEndYm As String
                payStrYm = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.PAY_START_DATE))
                payEndYm = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.PAY_END_DATE))
                If IsDate(payStrYm) = True Then
                    row(PSEXCEL_CLOUMNMNAME_PAYSTRYM) = payStrYm
                Else
                    row(PSEXCEL_CLOUMNMNAME_PAYSTRYM) = ""
                End If
                If IsDate(payEndYm) Then
                    row(PSEXCEL_CLOUMNMNAME_PAYENDYM) = payEndYm
                Else
                    row(PSEXCEL_CLOUMNMNAME_PAYENDYM) = ""
                End If
                If ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.PAY_METHOD)) = "月額" Then
                    row(PSEXCEL_CLOUMNMNAME_PAY_MONTHS) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.PAY_MONTHS))
                Else
                    row(PSEXCEL_CLOUMNMNAME_PAY_MONTHS) = "1"
                End If
                row(PSEXCEL_CLOUMNMNAME_PAY_METHOD) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.PAY_METHOD))
                row(PSEXCEL_CLOUMNMNAME_LIST_PRICE_REFLESH) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH))
                row(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_REFLESH))
                row(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_IOC) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.LIST_PRICE_TOTAL_IOC))
                row(PSEXCEL_CLOUMNMNAME_COST_RATE) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.COST_RATE))
                row(PSEXCEL_CLOUMNMNAME_COST) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.COST))
                row(PSEXCEL_CLOUMNMNAME_COST_TOTAL) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.COST_TOTAL))
                row(PSEXCEL_CLOUMNMNAME_COST_TOTAL_IOC) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.COST_TOTAL_IOC))
                row(PSEXCEL_CLOUMNMNAME_COST_INPUT_DATE) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.COST_INPUT_DATE))
                row(PSEXCEL_CLOUMNMNAME_OPTION1) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.OP1))
                row(PSEXCEL_CLOUMNMNAME_OPTION2) = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.OP2))
                row(PSEXCEL_CLOUMNMNAME_REFERENCE_ROWCOUNT) = ""
                row(PSEXCEL_CLOUMNMNAME_BRAND_AP_FORM) = excelWrite.changeDBNullToString(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.BRAND_AP_FORM)).Trim
                row(PSEXCEL_CLOUMNMNAME_BRAND_AP_REQ) = excelWrite.changeDBNullToString(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.BRAND_AP_REQ)).Trim
                row(PSEXCEL_CLOUMNMNAME_BRAND_AP_CONF) = excelWrite.changeDBNullToString(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.BRAND_AP_CONF)).Trim
                row(PSEXCEL_CLOUMNMNAME_DetailCount) = "0"
                row(PSEXCEL_CLOUMNMNAME_DP_IOC) = excelWrite.changeDBNullToString(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.DP_IOC)).Trim
                row(PSEXCEL_CLOUMNMNAME_PRICE_UNIT_IOC) = excelWrite.changeDBNullToString(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC)).Trim
                row(PSEXCEL_CLOUMNMNAME_PRICE_UNIT_IOC_VAL) = excelWrite.changeDBNullToString(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.PRICE_UNIT_IOC_VAL)).Trim
                row(PSEXCEL_CLOUMNMNAME_PRICE_QTY_IOC) = excelWrite.changeDBNullToString(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.PRICE_QTY_IOC)).Trim

                '詳細突き合わせ用テーブル保存
                CountB = CountB + 1
                ReDim Preserve BrandT(CountB)

                BrandT(CountB - 1).FileName = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.FILE_NAME))
                BrandT(CountB - 1).SUFFIX = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX))
                BrandT(CountB - 1).INTR = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.FILE_NAME_SUFFIX_INTR))
                BrandT(CountB - 1).CONTRACT = ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.CONTRACT))
                BrandT(CountB - 1).Brand_AP_Conf = excelWrite.changeDBNullToString(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.BRAND_AP_CONF)).Trim
                BrandT(CountB - 1).PATERN_NO = excelWrite.changeDBNullToString(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.PATTERN_CD)).Trim

                'Cost入力シート用テーブル保存
                If (excelWrite.changeDBNullToString(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.BRAND_AP_CONF)).Trim <> "") And _
                   (excelWrite.changeDBNullToString(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.PATTERN_CD)).Trim = "4") And _
                                        (ChangeNothingToBrank(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.ST_COST)) = "Y") Then
                    fFind = False
                    '保存テーブル検索
                    For ii = 0 To CountC - 1
                        If CostData(ii).Brand_AP_Conf = excelWrite.changeDBNullToString(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.BRAND_AP_CONF)).Trim Then
                            fFind = True
                            Exit For
                        End If
                    Next

                    '既保存値に同一キーが無かった場合→新規保存
                    If fFind = False Then
                        CountC = CountC + 1
                        ReDim Preserve CostData(CountC)
                        CostData(CountC - 1).Brand_AP_Conf = excelWrite.changeDBNullToString(ExcelLine(1, excelWrite.ExcelPaymentLineColumn.BRAND_AP_CONF)).Trim
                        CostData(CountC - 1).ListPrice = 0
                        CostData(CountC - 1).OfferingPrice = 0
                        CostData(CountC - 1).Cost = 0
                        CostData(CountC - 1).LineNo = CountC + 4
                    End If
                End If

                PSDataTable.Rows.Add(row)
            Next

        Catch ex As Exception
            Throw ex

        Finally
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True

            ''オブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(ExcelLine, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlInSheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlInBook) = False Then
                xlInBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlInBook, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()

        End Try

    End Sub

    Private Function ChangeNothingToBrank(ByVal obj As Object)
        If IsNothing(obj) = True Or IsDBNull(obj) = True Then
            Return ""
        Else
            Return obj
        End If
    End Function


    ''' <summary>
    ''' 機　能：個別詳細 Excelファイルの情報をデータテーブルへ格納
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetPSDetailDataTableInfo(ByRef PSDetailDataTable As DataTable, _
                                         ByVal PSDetailFileName As String)

        ''PSDetailDataTableの設定
        PSDetailDataTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_EXCELROW)
        PSDetailDataTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME)
        PSDetailDataTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
        PSDetailDataTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
        PSDetailDataTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)
        PSDetailDataTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_SEQ)
        PSDetailDataTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_IDENTITY_FLAG)
        PSDetailDataTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_PROD_NO)
        PSDetailDataTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_PROD_NAME)
        PSDetailDataTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_MES_CATEGORY)
        PSDetailDataTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_MES_GROUP)
        PSDetailDataTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_SPECIAL_FEATURE)
        PSDetailDataTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_QTY_INTEGER)
        PSDetailDataTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_LIST_PRICE)
        PSDetailDataTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL)
        PSDetailDataTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_COST_RATE)
        PSDetailDataTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_COST)
        PSDetailDataTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_COST_TOTAL)
        PSDetailDataTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_COST_INPUT_DATE)
        PSDetailDataTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_ISCOSTSET)
        PSDetailDataTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_PROD_ITEM01)
        PSDetailDataTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_SORT_MES_CATEGORY)
        PSDetailDataTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_BRAND_AP_CONF)

        ''Excelオブジェクトの宣言
        Dim xlApp As New Excel.Application
        Dim xlInBook As Excel.Workbook = Nothing
        Dim xlInSheet As Excel.Worksheet = Nothing
        Dim xlCell As Excel.Range
        Dim wB_CONF As String
        Dim wRet As Boolean

        Try
            ''Excelの初期設定
            xlApp.EnableEvents = False
            xlApp.DisplayAlerts = False

            ''BookのOpen
            xlInBook = xlApp.Workbooks.Open(PSDetailFileName)
            xlInSheet = xlInBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)

            ''データの取得
            Dim boxProdId As String         ''親Boxの製品番号
            Dim ExcelLine(,) As Object

            For i As Integer = ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW To EXCEL_MAX_ROW

                ''行データの取得
                xlCell = xlInSheet.Range("A" & i & ":" & "Z" & i)
                ExcelLine = xlCell.Value

                ''Eofの判定
                If CheckRowItemDetail(ExcelLine) = False Then
                    Exit For
                End If

                ''個別詳細の値をセットする。
                Dim row As DataRow
                row = PSDetailDataTable.NewRow()
                row(PSDETAILEXCEL_CLOUMNMNAME_EXCELROW) = i.ToString.PadLeft(6, "0")
                row(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME) = ChangeNothingToBrank(ExcelLine(1, COLDETAIL_FILE_NAME))
                row(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX) = ChangeNothingToBrank(ExcelLine(1, COLDETAIL_FILE_NAME_SUFFIX))
                row(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR) = ChangeNothingToBrank(ExcelLine(1, COLDETAIL_FILE_NAME_SUFFIX_INTR))
                row(PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO) = ChangeNothingToBrank(ExcelLine(1, COLDETAIL_CONTRACTNO))

                row(PSDETAILEXCEL_CLOUMNMNAME_SEQ) = ChangeNothingToBrank(ExcelLine(1, COLDETAIL_SEQ))
                row(PSDETAILEXCEL_CLOUMNMNAME_IDENTITY_FLAG) = ChangeNothingToBrank(ExcelLine(1, COLDETAIL_IDENTITY_FLAG))
                row(PSDETAILEXCEL_CLOUMNMNAME_PROD_NO) = ChangeNothingToBrank(ExcelLine(1, COLDETAIL_PROD_NO))
                row(PSDETAILEXCEL_CLOUMNMNAME_PROD_NAME) = ChangeNothingToBrank(ExcelLine(1, COLDETAIL_PROD_NAME))
                row(PSDETAILEXCEL_CLOUMNMNAME_MES_CATEGORY) = ChangeNothingToBrank(ExcelLine(1, COLDETAIL_MES_CATEGORY))
                row(PSDETAILEXCEL_CLOUMNMNAME_MES_GROUP) = ChangeNothingToBrank(ExcelLine(1, COLDETAIL_MES_GROUP))
                row(PSDETAILEXCEL_CLOUMNMNAME_SPECIAL_FEATURE) = ChangeNothingToBrank(ExcelLine(1, COLDETAIL_SPECIAL_FEATURE))
                row(PSDETAILEXCEL_CLOUMNMNAME_QTY_INTEGER) = ChangeNothingToBrank(ExcelLine(1, COLDETAIL_QTY_INTEGER))
                row(PSDETAILEXCEL_CLOUMNMNAME_LIST_PRICE) = ChangeNothingToBrank(ExcelLine(1, COLDETAIL_LIST_PRICE))
                row(PSDETAILEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL) = ChangeNothingToBrank(ExcelLine(1, COLDETAIL_LIST_PRICE_TOTA))
                row(PSDETAILEXCEL_CLOUMNMNAME_COST_RATE) = ChangeNothingToBrank(ExcelLine(1, COLDETAIL_COST_RATE))
                row(PSDETAILEXCEL_CLOUMNMNAME_COST) = ChangeNothingToBrank(ExcelLine(1, COLDETAIL_COST))
                row(PSDETAILEXCEL_CLOUMNMNAME_COST_TOTAL) = ChangeNothingToBrank(ExcelLine(1, COLDETAIL_COST_TOTAL))
                row(PSDETAILEXCEL_CLOUMNMNAME_COST_INPUT_DATE) = ChangeNothingToBrank(ExcelLine(1, COLDETAIL_COST_INPUT_DATE))

                If ChangeNothingToBrank(ExcelLine(1, COLDETAIL_IDENTITY_FLAG)) = "B" And _
                   ChangeNothingToBrank(ExcelLine(1, COLDETAIL_MES_CATEGORY)) <> "F" Then
                    boxProdId = ChangeNothingToBrank(ExcelLine(1, COLDETAIL_PROD_NO))
                End If
                row(PSDETAILEXCEL_CLOUMNMNAME_PROD_ITEM01) = boxProdId
                row(PSDETAILEXCEL_CLOUMNMNAME_ISCOSTSET) = "0"

                ''MESカテゴリ毎のソート順をセット
                Select Case row(PSDETAILEXCEL_CLOUMNMNAME_MES_CATEGORY).ToString.Trim
                    Case ""
                        row(PSDETAILEXCEL_CLOUMNMNAME_SORT_MES_CATEGORY) = "0"
                    Case "T"
                        row(PSDETAILEXCEL_CLOUMNMNAME_SORT_MES_CATEGORY) = "1"
                    Case "CA"
                        row(PSDETAILEXCEL_CLOUMNMNAME_SORT_MES_CATEGORY) = "2"
                    Case "A"
                        row(PSDETAILEXCEL_CLOUMNMNAME_SORT_MES_CATEGORY) = "3"
                End Select

                '起票番号・申請番号を取得
                wRet = GetPaymentPRM(ExcelLine(1, COLDETAIL_FILE_NAME), _
                                     ExcelLine(1, COLDETAIL_FILE_NAME_SUFFIX), _
                                     ExcelLine(1, COLDETAIL_FILE_NAME_SUFFIX_INTR), _
                                     ExcelLine(1, COLDETAIL_CONTRACTNO), _
                                     wB_CONF)
                row(PSDETAILEXCEL_CLOUMNMNAME_BRAND_AP_CONF) = wB_CONF

                PSDetailDataTable.Rows.Add(row)
            Next

        Catch ex As Exception
            Throw ex

        Finally
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True

            ''オブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlInSheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlInBook) = False Then
                xlInBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlInBook, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' 機　能：価格開示Topacsファイルの作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateKakakukaijiTopacs(ByVal PSDataTable As DataTable, _
                                             ByVal PSDetailDataTable As DataTable) As Boolean

        ''初期化
        CreateKakakukaijiTopacs = False

        ''例外処理の補足：ファイル作成時のエラーはすべてCreateKakakukaijiTopacsでメッセージを処理する。
        Try


            ''                ▼以下、AAS/MESに紐づく詳細ﾃﾞｰﾀ取得
            ''----------------------------------------------------------------------
            ''AAS/MESのPaymentﾃﾞｰﾀを抽出
            Dim AAS_PSRows() As DataRow
            Dim filter As String
            filter = GetCostKaijiFiler("1", CommonConstant.PATTERNNM_IBM_HW_AAS_BOX)
            AAS_PSRows = PSDataTable.Select(filter, PSEXCEL_CLOUMNMNAME_EXCELROW)

            ''AASの個別PSに紐づく個別詳細　.xlsデータを抽出 ※注意：ﾃﾞｰﾀなし = Nothingを返す
            Dim AAS_DetailRows() As DataRow
            Call GetCostKaijiDetailRows("1", AAS_PSRows, PSDetailDataTable, AAS_DetailRows)


            ''                ▼以下、Topacs出力用PSﾃﾞｰﾀを取得
            ''----------------------------------------------------------------------
            Dim Topacs_PSRows() As DataRow
            filter = GetCostKaijiFiler("Topacs", CommonConstant.PATTERNNM_IBM_HW_AAS_BOX)
            Topacs_PSRows = PSDataTable.Select(filter, PSEXCEL_CLOUMNMNAME_EXCELROW)


            ''作成対象のデータが存在するかどうか？
            If IsNothing(Topacs_PSRows) = True OrElse _
               Topacs_PSRows.Length < 1 Then
                Exit Function
            End If

            ''出力する価格開示ファイル名の取得
            Dim ofm As New OioFileManage
            Dim TopacsFileDir As String
            Dim TopacsFileFileNM As String
            Dim TopacsFilePath As String

            ''フォルダ
            TopacsFileDir = ofm.GetLocalCostOutputFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

            ''ファイル名
            TopacsFileFileNM = GetOutKakakukaijiFileNM("Topacs")

            ''パス
            TopacsFilePath = TopacsFileDir & TopacsFileFileNM

            ''価格開示ファイルの作成
            Return CreateTopacsFile("Topacs", Topacs_PSRows, AAS_DetailRows, TopacsFilePath, PSDetailDataTable)

        Catch ex As Exception
            MsgBox(ex.Message, vbCritical, "")
        End Try

    End Function

    ''' <summary>
    ''' 機　能：価格開示AASHWファイルの作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateKakakukaijiAASHW(ByVal PSDataTable As DataTable, _
                                            ByVal PSDetailDataTable As DataTable) As Boolean

        ''初期化
        CreateKakakukaijiAASHW = False

        ''例外処理の補足：ファイル作成時のエラーはすべてCreateKakakukaijiAASHWでメッセージを処理する。
        Try

            ''価格開示ファイルに出力するファイルの抽出
            ''個別PS　.xlsデータを抽出
            Dim PSRows() As DataRow
            Dim filter As String
            filter = GetCostKaijiFiler("1", CommonConstant.PATTERNNM_IBM_HW_AAS_BOX)
            PSRows = PSDataTable.Select(filter, PSEXCEL_CLOUMNMNAME_EXCELROW)

            ''個別PSに紐づく個別詳細　.xlsデータを抽出
            Dim PSDetailRows() As DataRow
            Call GetCostKaijiDetailRows("1", PSRows, PSDetailDataTable, PSDetailRows)

            ''作成対象のデータが存在するかどうか？
            If IsNothing(PSDetailRows) = True OrElse _
               PSDetailRows.Length < 1 Then
                Exit Function
            End If

            ''出力する価格開示ファイル名の取得
            Dim ofm As New OioFileManage
            Dim AASHWFileDir As String
            Dim AASHWFileFileNM As String
            Dim AASHWFilePath As String

            ''フォルダ
            AASHWFileDir = ofm.GetLocalCostOutputFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

            ''ファイル名
            AASHWFileFileNM = GetOutKakakukaijiFileNM("1")

            ''パス
            AASHWFilePath = AASHWFileDir & AASHWFileFileNM

            ''価格開示ファイルの作成
            Return CreateAASHWFile("1", "", PSRows, PSDetailRows, AASHWFilePath, PSDetailDataTable)

        Catch ex As Exception
            MsgBox(ex.Message, vbCritical, "")
        End Try

    End Function

    ''' <summary>
    ''' 機　能：価格開示QCOSHWファイルの作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateKakakukaijiQCOSHW(ByVal PSDataTable As DataTable) As Boolean

        ''初期化
        CreateKakakukaijiQCOSHW = False

        ''例外処理の補足：ファイル作成時のエラーはすべてCreateKakakukaijiQCOSHWでメッセージを処理する。
        Try

            ''価格開示ファイルに出力するファイルの抽出
            Dim rows() As DataRow
            Dim filter As String
            filter = GetCostKaijiFiler("3", CommonConstant.PATTERNNM_IBM_HW_QCOS)
            rows = PSDataTable.Select(filter, PSEXCEL_CLOUMNMNAME_EXCELROW)

            ''作成対象のデータが存在するかどうか？
            If rows.Length < 1 Then
                Exit Function
            End If

            ''出力する価格開示ファイル名の取得
            Dim ofm As New OioFileManage
            Dim QCOSHWFileDir As String
            Dim QCOSHWFileFileNM As String
            Dim QCOSHWFilePath As String

            ''フォルダ
            QCOSHWFileDir = ofm.GetLocalCostOutputFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

            ''ファイル名
            QCOSHWFileFileNM = GetOutKakakukaijiFileNM("3")

            ''パス
            QCOSHWFilePath = QCOSHWFileDir & QCOSHWFileFileNM

            ''価格開示ファイルの作成
            Return CreateQCOSHWFile("3", "", rows, QCOSHWFilePath)

        Catch ex As Exception
            MsgBox(ex.Message, vbCritical, "")
        End Try

    End Function

    ''' <summary>
    ''' 機　能：価格開示CISCOHWファイルの作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateKakakukaijiCISCOHW(ByVal PSDataTable As DataTable, _
                                            ByVal PSDetailDataTable As DataTable) As Boolean

        ''初期化
        CreateKakakukaijiCISCOHW = False

        ''例外処理の補足：ファイル作成時のエラーはすべてCreateKakakukaijiCISCOHWでメッセージを処理する。
        Try

            ''価格開示ファイルに出力するファイルの抽出
            ''個別PS　.xlsデータを抽出
            Dim PSRows() As DataRow
            Dim filter As String
            filter = GetCostKaijiFiler("4", CommonConstant.PATTERNNM_HW_CISCO)
            PSRows = PSDataTable.Select(filter, PSEXCEL_CLOUMNMNAME_EXCELROW)

            ''個別PSに紐づく個別詳細　.xlsデータを抽出
            Dim PSDetailRows() As DataRow
            Call GetCostKaijiDetailRows("4", PSRows, PSDetailDataTable, PSDetailRows)

            ''作成対象のデータが存在するかどうか？
            If IsNothing(PSDetailRows) = True OrElse _
               PSDetailRows.Length < 1 Then
                Exit Function
            End If

            MaxPS = PSRows.Length
            MaxSS = PSDetailRows.Length

            ''出力する価格開示ファイル名の取得
            Dim ofm As New OioFileManage
            Dim CISCOHWFileDir As String
            Dim CISCOHWFileFileNM As String
            Dim CISCOHWFilePath As String

            ''フォルダ
            CISCOHWFileDir = ofm.GetLocalCostOutputFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

            ''ファイル名
            CISCOHWFileFileNM = GetOutKakakukaijiFileNM("4")

            ''パス
            CISCOHWFilePath = CISCOHWFileDir & CISCOHWFileFileNM

            ''価格開示ファイルの作成
            Return CreateCISCOHWFile("4", "", PSRows, PSDetailRows, CISCOHWFilePath, PSDetailDataTable)

        Catch ex As Exception
            MsgBox(ex.Message, vbCritical, "")
        End Try

    End Function




    ''' <summary>
    ''' 機　能：価格開示AASHWServicepacファイルの作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateKakakukaijiAASHWServicepac(ByVal PSDataTable As DataTable) As Boolean

        ''初期化
        CreateKakakukaijiAASHWServicepac = False

        ''例外処理の補足：ファイル作成時のエラーはすべてCreateKakakukaijiAASHWServicepacでメッセージを処理する。
        Try

            ''価格開示ファイルに出力するファイルの抽出
            Dim rows() As DataRow
            Dim filter As String
            filter = GetCostKaijiFiler("13", CommonConstant.PATTERNNM_HWServicePac, "AAS")
            rows = PSDataTable.Select(filter, PSEXCEL_CLOUMNMNAME_EXCELROW)

            ''作成対象のデータが存在するかどうか？
            If rows.Length < 1 Then
                Exit Function
            End If

            ''出力する価格開示ファイル名の取得
            Dim ofm As New OioFileManage
            Dim AASHWServicepacFileDir As String
            Dim AASHWServicepacFileFileNM As String
            Dim AASHWServicepacFilePath As String

            ''フォルダ
            AASHWServicepacFileDir = ofm.GetLocalCostOutputFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

            ''ファイル名
            AASHWServicepacFileFileNM = GetOutKakakukaijiFileNM("13", "AAS")

            ''パス
            AASHWServicepacFilePath = AASHWServicepacFileDir & AASHWServicepacFileFileNM

            ''価格開示ファイルの作成
            Return CreateAASHWServicepacFile("13", "AAS", rows, AASHWServicepacFilePath)

        Catch ex As Exception
            MsgBox(ex.Message, vbCritical, "")
        End Try

    End Function


    ''' <summary>
    ''' 機　能：価格開示QCOSHWServicepacファイルの作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateKakakukaijiQCOSHWServicepac(ByVal PSDataTable As DataTable) As Boolean

        ''初期化
        CreateKakakukaijiQCOSHWServicepac = False

        ''例外処理の補足：ファイル作成時のエラーはすべてCreateKakakukaijiQCOSHWServicepacでメッセージを処理する。
        Try

            ''価格開示ファイルに出力するファイルの抽出
            Dim rows() As DataRow
            Dim filter As String
            filter = GetCostKaijiFiler("13", CommonConstant.PATTERNNM_HWServicePac, "QCOS")
            rows = PSDataTable.Select(filter, PSEXCEL_CLOUMNMNAME_EXCELROW)

            ''作成対象のデータが存在するかどうか？
            If rows.Length < 1 Then
                Exit Function
            End If

            ''出力する価格開示ファイル名の取得
            Dim ofm As New OioFileManage
            Dim QCOSHWServicepacFileDir As String
            Dim QCOSHWServicepacFileFileNM As String
            Dim QCOSHWServicepacFilePath As String

            ''フォルダ
            QCOSHWServicepacFileDir = ofm.GetLocalCostOutputFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

            ''ファイル名
            QCOSHWServicepacFileFileNM = GetOutKakakukaijiFileNM("13", "QCOS")

            ''パス
            QCOSHWServicepacFilePath = QCOSHWServicepacFileDir & QCOSHWServicepacFileFileNM

            ''価格開示ファイルの作成
            Return CreateQCOSHWServicepacFile("13", "QCOS", rows, QCOSHWServicepacFilePath)

        Catch ex As Exception
            MsgBox(ex.Message, vbCritical, "")
        End Try

    End Function


    ''' <summary>
    ''' 機　能：価格開示IASCファイルの作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateKakakukaijiIASC(ByVal PSDataTable As DataTable) As Boolean

        ''初期化
        CreateKakakukaijiIASC = False

        ''例外処理の補足：ファイル作成時のエラーはすべてCreateKakakukaijiIASCでメッセージを処理する。
        Try

            ''価格開示ファイルに出力するファイルの抽出
            Dim rows() As DataRow
            Dim filter As String
            filter = GetCostKaijiFiler("12", CommonConstant.PATTERNNM_VLS)
            rows = PSDataTable.Select(filter, PSEXCEL_CLOUMNMNAME_EXCELROW)

            ''作成対象のデータが存在するかどうか？
            If rows.Length < 1 Then
                Exit Function
            End If

            ''出力する価格開示ファイル名の取得
            Dim ofm As New OioFileManage
            Dim IASCFileDir As String
            Dim IASCFileFileNM As String
            Dim IASCFilePath As String

            ''フォルダ
            IASCFileDir = ofm.GetLocalCostOutputFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

            ''ファイル名
            IASCFileFileNM = GetOutKakakukaijiFileNM("12")

            ''パス
            IASCFilePath = IASCFileDir & IASCFileFileNM

            ''価格開示ファイルの作成
            Return CreateIASCFile("12", "", rows, IASCFilePath)

        Catch ex As Exception
            Throw ex
        End Try

    End Function

    ''' <summary>
    ''' 機　能：価格開示ISSファイルの作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateKakakukaijiISS(ByVal PSDataTable As DataTable) As Boolean

        ''初期化
        CreateKakakukaijiISS = False

        ''例外処理の補足：ファイル作成時のエラーはすべてCreateKakakukaijiISSでメッセージを処理する。
        Try

            ''価格開示ファイルに出力するファイルの抽出
            Dim rows() As DataRow
            Dim filter As String
            filter = GetCostKaijiFiler("39", CommonConstant.PATTERNNM_ISS)
            rows = PSDataTable.Select(filter, PSEXCEL_CLOUMNMNAME_EXCELROW)

            ''作成対象のデータが存在するかどうか？
            If rows.Length < 1 Then
                Exit Function
            End If

            ''出力する価格開示ファイル名の取得
            Dim ofm As New OioFileManage
            Dim ISSFileDir As String
            Dim ISSFileFileNM As String
            Dim ISSFilePath As String

            ''フォルダ
            ISSFileDir = ofm.GetLocalCostOutputFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

            ''ファイル名
            ISSFileFileNM = GetOutKakakukaijiFileNM("39")

            ''パス
            ISSFilePath = ISSFileDir & ISSFileFileNM

            ''価格開示ファイルの作成
            Return CreateISSFile("39", "", rows, ISSFilePath)

        Catch ex As Exception
            MsgBox(ex.Message, vbCritical, "")
        End Try

    End Function

    'START 変更管理#39（No.1544 MA復帰料金の統合)　2017/04 sugo
    ' ''' <summary>
    ' ''' 機　能：価格開示QCOS MA復帰料金ファイルの作成
    ' ''' 説　明：
    ' ''' </summary>
    ' ''' <remarks></remarks>
    'Private Function CreateKakakukaijiQCOSMAF(ByVal PSDataTable As DataTable) As Boolean

    '    ''初期化
    '    CreateKakakukaijiQCOSMAF = False

    '    ''例外処理の補足：ファイル作成時のエラーはすべてCreateKakakukaijiQCOSMAFでメッセージを処理する。
    '    Try

    '        ''価格開示ファイルに出力するファイルの抽出
    '        Dim rows() As DataRow
    '        Dim filter As String
    '        filter = GetCostKaijiFiler("40", CommonConstant.PATTERNNM_QCOSMAF)
    '        rows = PSDataTable.Select(filter, PSEXCEL_CLOUMNMNAME_EXCELROW)

    '        ''作成対象のデータが存在するかどうか？
    '        If rows.Length < 1 Then
    '            Exit Function
    '        End If

    '        ''出力する価格開示ファイル名の取得
    '        Dim ofm As New OioFileManage
    '        Dim QCOSMAFFileDir As String
    '        Dim QCOSMAFFileFileNM As String
    '        Dim QCOSMAFFilePath As String

    '        ''フォルダ
    '        QCOSMAFFileDir = ofm.GetLocalCostOutputFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

    '        ''ファイル名
    '        QCOSMAFFileFileNM = GetOutKakakukaijiFileNM("40")

    '        ''パス
    '        QCOSMAFFilePath = QCOSMAFFileDir & QCOSMAFFileFileNM

    '        ''価格開示ファイルの作成
    '        Return CreateQCOSMAFFile("40", "", rows, QCOSMAFFilePath)

    '    Catch ex As Exception
    '        MsgBox(ex.Message, vbCritical, "")
    '    End Try

    'End Function
    'END   変更管理#39（No.1544 MA復帰料金の統合)　2017/04 sugo


    ''' <summary>
    ''' 機　能：価格開示復帰料金ファイルの作成
    ''' 説　明：※QCOS、AAS復帰料金を統合
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateKakakukaijiAASMAF(ByVal PSDataTable As DataTable) As Boolean

        ''初期化
        CreateKakakukaijiAASMAF = False

        ''例外処理の補足：ファイル作成時のエラーはすべてCreateKakakukaijiAASMAFでメッセージを処理する。
        Try

            ''価格開示ファイルに出力するファイルの抽出
            Dim rows() As DataRow
            Dim filter As String
            'START 変更管理#39（No.1544 MA復帰料金の統合)　2017/04 sugo
            filter = "(" & GetCostKaijiFiler("40", CommonConstant.PATTERNNM_AASMAF) &
                     ") OR (" &
                     GetCostKaijiFiler("41", CommonConstant.PATTERNNM_AASMAF) & ")"
            'filter = GetCostKaijiFiler("41", CommonConstant.PATTERNNM_AASMAF)
            'END   変更管理#39（No.1544 MA復帰料金の統合)　2017/04 sugo
            rows = PSDataTable.Select(filter, PSEXCEL_CLOUMNMNAME_EXCELROW)

            ''作成対象のデータが存在するかどうか？
            If rows.Length < 1 Then
                Exit Function
            End If

            ''出力する価格開示ファイル名の取得
            Dim ofm As New OioFileManage
            Dim AASMAFFileDir As String
            Dim AASMAFFileFileNM As String
            Dim AASMAFFilePath As String

            ''フォルダ
            AASMAFFileDir = ofm.GetLocalCostOutputFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

            ''ファイル名
            AASMAFFileFileNM = GetOutKakakukaijiFileNM("41")

            ''パス
            AASMAFFilePath = AASMAFFileDir & AASMAFFileFileNM

            ''価格開示ファイルの作成
            Return CreateAASMAFFile("41", "", rows, AASMAFFilePath)

        Catch ex As Exception
            MsgBox(ex.Message, vbCritical, "")
        End Try

    End Function

    ''' <summary>
    ''' 機　能：価格開示SystemServiceファイルの作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateKakakukaijiSystemService(ByVal PSDataTable As DataTable) As Boolean

        ''初期化
        CreateKakakukaijiSystemService = False

        ''例外処理の補足：ファイル作成時のエラーはすべてCreateKakakukaijiSystemServiceでメッセージを処理する。
        Try

            ''価格開示ファイルに出力するファイルの抽出
            Dim rows() As DataRow
            Dim filter As String
            filter = GetCostKaijiFiler("34", CommonConstant.PATTERNNM_SYSTEMSERVICE)
            rows = PSDataTable.Select(filter, PSEXCEL_CLOUMNMNAME_EXCELROW)

            ''作成対象のデータが存在するかどうか？
            If rows.Length < 1 Then
                Exit Function
            End If

            ''出力する価格開示ファイル名の取得
            Dim ofm As New OioFileManage
            Dim SystemServiceFileDir As String
            Dim SystemServiceFileFileNM As String
            Dim SystemServiceFilePath As String

            ''フォルダ
            SystemServiceFileDir = ofm.GetLocalCostOutputFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

            ''ファイル名
            SystemServiceFileFileNM = GetOutKakakukaijiFileNM("34")

            ''パス
            SystemServiceFilePath = SystemServiceFileDir & SystemServiceFileFileNM

            ''価格開示ファイルの作成
            Return CreateSystemServiceFile("34", "", rows, SystemServiceFilePath)

        Catch ex As Exception
            MsgBox(ex.Message, vbCritical, "")
        End Try

    End Function

    ''' <summary>
    ''' 機　能：価格開示SWServicepacファイルの作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateKakakukaijiSWServicepac(ByVal PSDataTable As DataTable) As Boolean

        ''初期化
        CreateKakakukaijiSWServicepac = False

        ''例外処理の補足：ファイル作成時のエラーはすべてCreateKakakukaijiSWServicepacでメッセージを処理する。
        Try

            ''価格開示ファイルに出力するファイルの抽出
            Dim rows() As DataRow
            Dim filter As String
            filter = GetCostKaijiFiler("14", CommonConstant.PATTERNNM_SWServicePac)
            rows = PSDataTable.Select(filter, PSEXCEL_CLOUMNMNAME_EXCELROW)

            ''作成対象のデータが存在するかどうか？
            If rows.Length < 1 Then
                Exit Function
            End If

            ''出力する価格開示ファイル名の取得
            Dim ofm As New OioFileManage
            Dim SWServicepacFileDir As String
            Dim SWServicepacFileFileNM As String
            Dim SWServicepacFilePath As String

            ''フォルダ
            SWServicepacFileDir = ofm.GetLocalCostOutputFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

            ''ファイル名
            SWServicepacFileFileNM = GetOutKakakukaijiFileNM("14")

            ''パス
            SWServicepacFilePath = SWServicepacFileDir & SWServicepacFileFileNM

            ''価格開示ファイルの作成
            Return CreateSWServicepacFile("14", "", rows, SWServicepacFilePath)

        Catch ex As Exception
            MsgBox(ex.Message, vbCritical, "")
        End Try

    End Function

    ''' <summary>
    ''' 機　能：価格開示AASHWMAファイルの作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateKakakukaijiAASHWMA(ByVal PSDataTable As DataTable, _
                                              ByVal DelOverlapPSDataTable As DataTable, _
                                              ByVal PSDetailDataTable As DataTable) As Boolean

        ''初期化
        CreateKakakukaijiAASHWMA = False

        Dim tes As New TestClass2
        ''例外処理の補足：ファイル作成時のエラーはすべてCreateKakakukaijiAASHWMAでメッセージを処理する。
        Try

            ''Paymentシート出力ﾃﾞｰﾀ
            Dim rows() As DataRow
            Dim filter As String
            filter = GetCostKaijiFiler("15", CommonConstant.PATTERNNM_IBM_HWMA_AAS_BOX)
            rows = DelOverlapPSDataTable.Select(filter, PSEXCEL_CLOUMNMNAME_EXCELROW)

            ''作成対象のデータが存在するかどうか？
            If rows.Length < 1 Then
                Exit Function
            End If

            ''参考シート出力ﾃﾞｰﾀ
            ''※Selectで取得した値をRows(dataRowCollection)に入れ替えるため、新しくTBLを作成
            Dim tmpPSTBL As DataTable
            tmpPSTBL = PSDataTable.Clone
            For Each insRow As DataRow In PSDataTable.Select(filter.ToString, PSEXCEL_CLOUMNMNAME_EXCELROW)
                insRow.Item(PSEXCEL_CLOUMNMNAME_LINE_NO) = ExcelWrite.changeDBNullToString(insRow.Item(PSEXCEL_CLOUMNMNAME_LINE_NO)).PadLeft(10, "0")
                tmpPSTBL.ImportRow(insRow)
            Next
            Dim referenceRows As DataRowCollection
            referenceRows = GetReferenceRows(tmpPSTBL, DelOverlapPSDataTable)

            ''詳細シート出力ﾃﾞｰﾀ
            Dim detailRows() As DataRow
            Dim tmpPSRows() As DataRow
            If referenceRows.Count = 0 Then
                ReDim tmpPSRows(0)
            Else
                ReDim tmpPSRows(referenceRows.Count - 1)
            End If
            Call referenceRows.CopyTo(tmpPSRows, 0)
            Call GetCostKaijiDetailRows("15", tmpPSRows, PSDetailDataTable, detailRows)

            ''出力する価格開示ファイル名の取得
            Dim ofm As New OioFileManage
            Dim AASHWMAFileDir As String
            Dim AASHWMAFileFileNM As String
            Dim AASHWMAFilePath As String

            ''フォルダ
            AASHWMAFileDir = ofm.GetLocalCostOutputFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

            ''ファイル名
            AASHWMAFileFileNM = GetOutKakakukaijiFileNM("15")

            ''パス
            AASHWMAFilePath = AASHWMAFileDir & AASHWMAFileFileNM

            ''価格開示ファイルの作成
            Return CreateAASHWMAFile("15", rows, referenceRows, detailRows, PSDetailDataTable, AASHWMAFilePath)

        Catch ex As Exception
            MsgBox(ex.Message, vbCritical, "")

        End Try

    End Function


    ''' <summary>
    ''' 機　能：価格開示NEWQCOSHWMAファイルの作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateKakakukaijiQCOSHWMA(ByVal PSDataTable As DataTable) As Boolean

        ''初期化
        CreateKakakukaijiQCOSHWMA = False

        ''例外処理の補足：ファイル作成時のエラーはすべてCreateKakakukaijiQCOSHWMAでメッセージを処理する。
        Try

            ''価格開示ファイルに出力するファイルの抽出
            Dim rows() As DataRow
            Dim filter As String
            filter = GetCostKaijiFiler("17", CommonConstant.PATTERNNM_IBM_HWMA_QCOS, "新規")
            rows = PSDataTable.Select(filter, PSEXCEL_CLOUMNMNAME_EXCELROW)

            ''作成対象のデータが存在するかどうか？
            If rows.Length < 1 Then
                Exit Function
            End If

            ''出力する価格開示ファイル名の取得
            Dim ofm As New OioFileManage
            Dim QCOSHWMAFileDir As String
            Dim QCOSHWMAFileFileNM As String
            Dim QCOSHWMAFilePath As String

            ''フォルダ
            QCOSHWMAFileDir = ofm.GetLocalCostOutputFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

            ''ファイル名
            QCOSHWMAFileFileNM = GetOutKakakukaijiFileNM("17", "新規")

            ''パス
            QCOSHWMAFilePath = QCOSHWMAFileDir & QCOSHWMAFileFileNM

            ''価格開示ファイルの作成
            Return CreateQCOSHWMAFile("17", "新規", rows, QCOSHWMAFilePath)

        Catch ex As Exception
            MsgBox(ex.Message, vbCritical, "")
        End Try

    End Function

    ''' <summary>
    ''' 機　能：価格開示AASWarrantyOptionファイルの作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateKakakukaijiAASWarrantyOption(ByVal PSDataTable As DataTable) As Boolean

        ''初期化
        CreateKakakukaijiAASWarrantyOption = False

        ''例外処理の補足：ファイル作成時のエラーはすべてCreateKakakukaijiAASWarrantyOptionでメッセージを処理する。
        Try

            ''価格開示ファイルに出力するファイルの抽出
            Dim rows() As DataRow
            Dim filter As String
            filter = GetCostKaijiFiler("18", CommonConstant.PATTERNNM_IBM_HWMA_AAS_WarrantyOP)
            rows = PSDataTable.Select(filter, PSEXCEL_CLOUMNMNAME_EXCELROW)

            ''作成対象のデータが存在するかどうか？
            If rows.Length < 1 Then
                Exit Function
            End If

            ''出力する価格開示ファイル名の取得
            Dim ofm As New OioFileManage
            Dim AASWarrantyOptionFileDir As String
            Dim AASWarrantyOptionFileFileNM As String
            Dim AASWarrantyOptionFilePath As String

            ''フォルダ
            AASWarrantyOptionFileDir = ofm.GetLocalCostOutputFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

            ''ファイル名
            AASWarrantyOptionFileFileNM = GetOutKakakukaijiFileNM("18")

            ''パス
            AASWarrantyOptionFilePath = AASWarrantyOptionFileDir & AASWarrantyOptionFileFileNM

            ''価格開示ファイルの作成
            Return CreateAASWarrantyOptionFile("18", "", rows, AASWarrantyOptionFilePath)

        Catch ex As Exception
            MsgBox(ex.Message, vbCritical, "")
        End Try

    End Function

    ''' <summary>
    ''' 機　能：価格開示QCOSWarrantyOptionファイルの作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateKakakukaijiQCOSWarrantyOption(ByVal PSDataTable As DataTable) As Boolean

        ''初期化
        CreateKakakukaijiQCOSWarrantyOption = False

        ''例外処理の補足：ファイル作成時のエラーはすべてCreateKakakukaijiQCOSWarrantyOptionでメッセージを処理する。
        Try

            ''価格開示ファイルに出力するファイルの抽出
            Dim rows() As DataRow
            Dim filter As String
            filter = GetCostKaijiFiler("19", CommonConstant.PATTERNNM_IBM_HWMA_QCOS_WarrantyOP)
            rows = PSDataTable.Select(filter, PSEXCEL_CLOUMNMNAME_EXCELROW)

            ''作成対象のデータが存在するかどうか？
            If rows.Length < 1 Then
                Exit Function
            End If

            ''出力する価格開示ファイル名の取得
            Dim ofm As New OioFileManage
            Dim QCOSWarrantyOptionFileDir As String
            Dim QCOSWarrantyOptionFileFileNM As String
            Dim QCOSWarrantyOptionFilePath As String

            ''フォルダ
            QCOSWarrantyOptionFileDir = ofm.GetLocalCostOutputFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

            ''ファイル名
            QCOSWarrantyOptionFileFileNM = GetOutKakakukaijiFileNM("19")

            ''パス
            QCOSWarrantyOptionFilePath = QCOSWarrantyOptionFileDir & QCOSWarrantyOptionFileFileNM

            ''価格開示ファイルの作成
            Return CreateQCOSWarrantyOptionFile("19", "", rows, QCOSWarrantyOptionFilePath)

        Catch ex As Exception
            MsgBox(ex.Message, vbCritical, "")
        End Try

    End Function

    ''' <summary>
    ''' 機　能：価格開示MVMSファイルの作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateKakakukaijiMVMS(ByVal PSDataTable As DataTable) As Boolean

        ''初期化
        CreateKakakukaijiMVMS = False

        ''例外処理の補足：ファイル作成時のエラーはすべてCreateKakakukaijiMVMSでメッセージを処理する。
        Try

            ''価格開示ファイルに出力するファイルの抽出
            Dim rows() As DataRow
            Dim filter As String
            filter = GetCostKaijiFiler("20", CommonConstant.PATTERNNM_OtherMVMS)
            rows = PSDataTable.Select(filter, PSEXCEL_CLOUMNMNAME_EXCELROW)

            ''作成対象のデータが存在するかどうか？
            If rows.Length < 1 Then
                Exit Function
            End If

            ''出力する価格開示ファイル名の取得
            Dim ofm As New OioFileManage
            Dim MVMSFileDir As String
            Dim MVMSFileFileNM As String
            Dim MVMSFilePath As String

            ''フォルダ
            MVMSFileDir = ofm.GetLocalCostOutputFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

            ''ファイル名
            MVMSFileFileNM = GetOutKakakukaijiFileNM("20")

            ''パス
            MVMSFilePath = MVMSFileDir & MVMSFileFileNM

            ''価格開示ファイルの作成
            Return CreateMVMSFile("20", "", rows, MVMSFilePath)

        Catch ex As Exception
            MsgBox(ex.Message, vbCritical, "")
        End Try

    End Function

    ''' <summary>
    ''' 機　能：価格開示拡張保守ファイルの作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateKakakukaijiExpansionOption(ByVal PSDataTable As DataTable) As Boolean

        ''初期化
        CreateKakakukaijiExpansionOption = False

        ''例外処理の補足：ファイル作成時のエラーはすべてCreateKakakukaijiExpansionOptionでメッセージを処理する。
        Try

            ''価格開示ファイルに出力するファイルの抽出
            Dim rows() As DataRow
            Dim filter As String
            filter = GetCostKaijiFiler("23", CommonConstant.PATTERNNM_MAINTENANCE)
            rows = PSDataTable.Select(filter, PSEXCEL_CLOUMNMNAME_EXCELROW)

            ''作成対象のデータが存在するかどうか？
            If rows.Length < 1 Then
                Exit Function
            End If

            ''出力する価格開示ファイル名の取得
            Dim ofm As New OioFileManage
            Dim ExpansionOptionFileDir As String
            Dim ExpansionOptionFileFileNM As String
            Dim ExpansionOptionFilePath As String

            ''フォルダ
            ExpansionOptionFileDir = ofm.GetLocalCostOutputFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

            ''ファイル名
            ExpansionOptionFileFileNM = GetOutKakakukaijiFileNM("23")

            ''パス
            ExpansionOptionFilePath = ExpansionOptionFileDir & ExpansionOptionFileFileNM

            ''価格開示ファイルの作成
            Return CreateExpansionOptionFile("23", "", rows, ExpansionOptionFilePath)

        Catch ex As Exception
            MsgBox(ex.Message, vbCritical, "")
        End Try

    End Function


    ''' <summary>
    ''' 機　能：価格開示IGF_USEDファイルの作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateKakakukaijiIGF_USED(ByVal PSDataTable As DataTable, _
                                               ByVal PSDetailDataTable As DataTable) As Boolean

        ''初期化
        CreateKakakukaijiIGF_USED = False

        ''例外処理の補足：ファイル作成時のエラーはすべてCreateKakakukaijiIGF_USEDでメッセージを処理する。
        Try

            ''価格開示ファイルに出力するファイルの抽出
            ''個別PS　.xlsデータを抽出
            Dim PSRows() As DataRow
            Dim filter As String
            filter = GetCostKaijiFiler("31", CommonConstant.PATTERNNM_IGF_USED)
            PSRows = PSDataTable.Select(filter, PSEXCEL_CLOUMNMNAME_EXCELROW)

            ''個別PSに紐づく個別詳細　.xlsデータを抽出
            Dim PSDetailRows() As DataRow
            Call GetCostKaijiDetailRows("31", PSRows, PSDetailDataTable, PSDetailRows)

            ''作成対象のデータが存在するかどうか？
            If IsNothing(PSDetailRows) = True OrElse _
               PSDetailRows.Length < 1 Then
                Exit Function
            End If

            ''出力する価格開示ファイル名の取得
            Dim ofm As New OioFileManage
            Dim IGF_USEDFileDir As String
            Dim IGF_USEDFileFileNM As String
            Dim IGF_USEDFilePath As String

            ''フォルダ
            IGF_USEDFileDir = ofm.GetLocalCostOutputFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

            ''ファイル名
            IGF_USEDFileFileNM = GetOutKakakukaijiFileNM("31")

            ''パス
            IGF_USEDFilePath = IGF_USEDFileDir & IGF_USEDFileFileNM

            ''価格開示ファイルの作成
            Return CreateIGF_USEDFile("31", "", PSRows, PSDetailRows, IGF_USEDFilePath, PSDetailDataTable)

        Catch ex As Exception
            MsgBox(ex.Message, vbCritical, "")

        End Try

    End Function

    ''' <summary>
    ''' 機　能：FMAファイルの作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateKakakukaijiFMA(ByVal PSDataTable As DataTable) As Boolean

        ''初期化
        CreateKakakukaijiFMA = False

        ''例外処理の補足：ファイル作成時のエラーはすべてCreateKakakukaijiFMAでメッセージを処理する。
        Try

            ''価格開示ファイルに出力するファイルの抽出
            Dim rows() As DataRow
            Dim filter As String
            filter = GetCostKaijiFiler("32", CommonConstant.PATTERNNM_FMA)
            rows = PSDataTable.Select(filter, PSEXCEL_CLOUMNMNAME_EXCELROW)

            ''作成対象のデータが存在するかどうか？
            If rows.Length < 1 Then
                Exit Function
            End If

            ''出力する価格開示ファイル名の取得
            Dim ofm As New OioFileManage
            Dim FMAFileDir As String
            Dim FMAFileFileNM As String
            Dim FMAFilePath As String

            ''フォルダ
            FMAFileDir = ofm.GetLocalCostOutputFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

            ''ファイル名
            FMAFileFileNM = GetOutKakakukaijiFileNM("32")

            ''パス
            FMAFilePath = FMAFileDir & FMAFileFileNM

            ''価格開示ファイルの作成
            Return CreateFMAFile("32", "", rows, FMAFilePath)

        Catch ex As Exception
            MsgBox(ex.Message, vbCritical, "")
        End Try

    End Function
    '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) Start
    ''' <summary>
    ''' 機　能：MSSファイルの作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateKakakukaijiMSS(ByVal PSDataTable As DataTable) As Boolean

        ''初期化
        CreateKakakukaijiMSS = False

        ''例外処理の補足：ファイル作成時のエラーはすべてCreateKakakukaijiMSSでメッセージを処理する。
        Try

            ''価格開示ファイルに出力するファイルの抽出
            Dim rows() As DataRow
            Dim filter As String
            filter = GetCostKaijiFiler("47", CommonConstant.PATTERNNM_MSS)
            rows = PSDataTable.Select(filter, PSEXCEL_CLOUMNMNAME_EXCELROW)

            ''作成対象のデータが存在するかどうか？
            If rows.Length < 1 Then
                Exit Function
            End If

            ''出力する価格開示ファイル名の取得
            Dim ofm As New OioFileManage
            Dim MSSFileDir As String
            Dim MSSFileFileNM As String
            Dim MSSFilePath As String

            ''フォルダ
            MSSFileDir = ofm.GetLocalCostOutputFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

            ''ファイル名
            MSSFileFileNM = GetOutKakakukaijiFileNM("47")

            ''パス
            MSSFilePath = MSSFileDir & MSSFileFileNM

            ''価格開示ファイルの作成
            Return CreateMSSFile("47", "", rows, MSSFilePath)

        Catch ex As Exception
            MsgBox(ex.Message, vbCritical, "")
        End Try

    End Function
    '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) End

    ''' <summary>
    ''' 機　能：AASHWのファイルの価格開示ファイルのテンプレート作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateAASHWFile(ByVal patternCD As String, _
                                     ByVal newExist As String, _
                                     ByVal PSRows() As DataRow, _
                                     ByVal PSDetailRows() As DataRow, _
                                     ByVal outFileNm As String, _
                                     ByRef PSdetailTable As DataTable) As Boolean

        ''初期化
        CreateAASHWFile = False

        Dim xlApp As New Excel.Application
        Dim xlPSBook As Excel.Workbook
        Dim xlTempleBook As Excel.Workbook

        'Excel初期化
        xlApp.EnableEvents = False
        xlApp.DisplayAlerts = False

        Try
            ''Templeファイルのパス取得
            Dim ofm As New OioFileManage
            Dim TempleFileDir As String = ofm.GetLocalTemplateFolder()
            Dim TempleFileNM As String = GetTemplateFileNM(patternCD)
            Dim TempleFilePath As String = TempleFileDir & TempleFileNM

            ''TempleファイルのOpen
            xlTempleBook = xlApp.Workbooks.Open(TempleFilePath)

            ''個別PSファイルの行コピー
            Call CopyPSRows(xlTempleBook, PSRows)

            ''個別詳細ファイルの行コピー
            Call CopyPSDetailRows(xlTempleBook, PSDetailRows, PSdetailTable)

            ''個別詳細ファイルのパス取得
            Dim PSFileDir As String = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            Dim PSFileNM As String = ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            Dim PSFilePath As String = PSFileDir & PSFileNM

            ''個別PSファイルのOPEN
            xlPSBook = xlApp.Workbooks.Open(PSFilePath)

            ''WS1シートのコピー
            Call CopyWS1(xlTempleBook, xlPSBook)

            ''価格開示ファイルの保存(テンプレートファイルを別名保存)
            xlTempleBook.Activate()
            Call DelXlsNames(xlTempleBook)
            xlTempleBook.SaveAs(Filename:=outFileNm, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

            CreateAASHWFile = True

        Catch ex As Exception
            Throw ex

        Finally

            ''オブジェクトの解放
            If IsNothing(xlTempleBook) = False Then
                xlTempleBook.Close(False)
            End If
            If IsNothing(xlPSBook) = False Then
                xlPSBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlTempleBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
        End Try

    End Function


    ''' <summary>
    ''' 機　能：QCOS HWのファイルの価格開示ファイルのテンプレート作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateQCOSHWFile(ByVal patternCD As String, _
                                      ByVal newExist As String, _
                                      ByVal PSRows() As DataRow, _
                                      ByVal outFileNm As String) As Boolean

        ''初期化
        CreateQCOSHWFile = False

        Dim xlApp As New Excel.Application
        Dim xlOutBook As Excel.Workbook
        Dim xlPSBook As Excel.Workbook

        'Excel初期化
        xlApp.EnableEvents = False
        xlApp.DisplayAlerts = False

        Try

            ''価格開示ファイルの取得
            Dim ofm As New OioFileManage
            Dim TemplateFileDir As String
            Dim TemplateFileNM As String
            Dim TemplateFilePath As String
            TemplateFileDir = ofm.GetLocalTemplateFolder
            TemplateFileNM = GetTemplateFileNM(patternCD)
            TemplateFilePath = TemplateFileDir & TemplateFileNM
            xlOutBook = xlApp.Workbooks.Open(TemplateFilePath)

            ''個別PSBookの取得
            Dim PsFileDir As String
            Dim PsFileNM As String
            Dim PsFilePath As String
            PsFileDir = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFileNM = ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFilePath = PsFileDir & PsFileNM

            ''個別PSBookのOpen
            xlPSBook = xlApp.Workbooks.Open(PsFilePath)

            ''個別PSファイルの行コピー
            Call CopyPSRows(xlOutBook, PSRows)

            ''WS1シートのコピー
            Call CopyWS1(xlOutBook, xlPSBook)

            ''価格開示ファイルの保存
            Call DelXlsNames(xlOutBook)
            xlOutBook.Activate()
            xlOutBook.SaveAs(Filename:=outFileNm, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

            CreateQCOSHWFile = True

        Catch ex As Exception
            Throw ex
        Finally

            ''オブジェクトの解放
            If IsNothing(xlOutBook) = False Then
                xlOutBook.Close(False)
            End If
            If IsNothing(xlPSBook) = False Then
                xlPSBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlOutBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
        End Try

    End Function

    ''' <summary>
    ''' 機　能：CISCOHWのファイルの価格開示ファイルのテンプレート作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateCISCOHWFile(ByVal patternCD As String, _
                                     ByVal newExist As String, _
                                     ByVal PSRows() As DataRow, _
                                     ByVal PSDetailRows() As DataRow, _
                                     ByVal outFileNm As String, _
                                     ByRef PSdetailTable As DataTable) As Boolean

        ''初期化
        CreateCISCOHWFile = False

        Dim xlApp As New Excel.Application
        Dim xlPSBook As Excel.Workbook
        Dim xlTempleBook As Excel.Workbook

        'Excel初期化
        xlApp.EnableEvents = False
        xlApp.DisplayAlerts = False

        Try

            ''Templeファイルのパス取得
            Dim ofm As New OioFileManage
            Dim TempleFileDir As String = ofm.GetLocalTemplateFolder()
            Dim TempleFileNM As String = GetTemplateFileNM(patternCD)
            Dim TempleFilePath As String = TempleFileDir & TempleFileNM

            ''TempleファイルのOpen
            xlTempleBook = xlApp.Workbooks.Open(TempleFilePath)

            ''`不要なﾎﾞﾀﾝの削除

            ''個別PSファイルの行コピー
            Call CopyPSRows2(xlTempleBook, PSRows)

            ''個別詳細ファイルの行コピー
            Call CopyPSDetailRows2(xlTempleBook, PSDetailRows, PSdetailTable)

            ''COST入力シートの編集コピー
            Call EditCostSheet(xlTempleBook)

            ''個別詳細ファイルのパス取得
            Dim PSFileDir As String = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            Dim PSFileNM As String = ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            Dim PSFilePath As String = PSFileDir & PSFileNM

            ''個別PSファイルのOPEN
            xlPSBook = xlApp.Workbooks.Open(PSFilePath)

            ''WS1シートのコピー
            Call CopyWS1(xlTempleBook, xlPSBook)

            ''価格開示ファイルの保存(テンプレートファイルを別名保存)
            Call DelXlsNames(xlTempleBook)
            xlTempleBook.Activate()
            xlTempleBook.SaveAs(Filename:=outFileNm, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

            CreateCISCOHWFile = True

        Catch ex As Exception
            Throw ex

        Finally

            ''オブジェクトの解放
            If IsNothing(xlTempleBook) = False Then
                xlTempleBook.Close(False)
            End If
            If IsNothing(xlPSBook) = False Then
                xlPSBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlTempleBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
        End Try

    End Function



    ''' <summary>
    ''' 機　能：IASCのファイルの価格開示ファイルのテンプレート作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateIASCFile(ByVal patternCD As String, _
                                      ByVal newExist As String, _
                                      ByVal PSRows() As DataRow, _
                                      ByVal outFileNm As String) As Boolean

        ''初期化
        CreateIASCFile = False

        Dim xlApp As New Excel.Application
        Dim xlOutBook As Excel.Workbook
        Dim xlPSBook As Excel.Workbook

        'Excel初期化
        xlApp.EnableEvents = False
        xlApp.DisplayAlerts = False

        Try

            ''テンプレートファイルのOPEN
            Dim ofm As New OioFileManage
            Dim TemplateFileDir As String
            Dim TemplateFileNM As String
            Dim TemplateFilePath As String
            TemplateFileDir = ofm.GetLocalTemplateFolder
            TemplateFileNM = GetTemplateFileNM(patternCD)
            TemplateFilePath = TemplateFileDir & TemplateFileNM
            xlOutBook = xlApp.Workbooks.Open(TemplateFilePath)

            ''個別PSBookの取得
            Dim PsFileDir As String
            Dim PsFileNM As String
            Dim PsFilePath As String
            PsFileDir = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFileNM = ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFilePath = PsFileDir & PsFileNM

            ''個別PSBookのOpen
            xlPSBook = xlApp.Workbooks.Open(PsFilePath)

            ''個別PSファイルの行コピー
            Call CopyPSRows(xlOutBook, PSRows)

            ''WS1シートのコピー
            Call CopyWS1(xlOutBook, xlPSBook)

            ''価格開示ファイルの保存
            Call DelXlsNames(xlOutBook)
            xlOutBook.Activate()
            xlOutBook.SaveAs(Filename:=outFileNm, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

            CreateIASCFile = True

        Catch ex As Exception
            Throw ex
        Finally

            ''オブジェクトの解放
            If IsNothing(xlOutBook) = False Then
                xlOutBook.Close(False)
            End If
            If IsNothing(xlPSBook) = False Then
                xlPSBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlOutBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
        End Try

    End Function


    ''' <summary>
    ''' 機　能：SystemServiceのファイルの価格開示ファイルのテンプレート作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateSystemServiceFile(ByVal patternCD As String, _
                                             ByVal newExist As String, _
                                             ByVal PSRows() As DataRow, _
                                             ByVal outFileNm As String) As Boolean

        ''初期化
        CreateSystemServiceFile = False

        Dim xlApp As New Excel.Application
        Dim xlOutBook As Excel.Workbook
        Dim xlPSBook As Excel.Workbook

        'Excel初期化
        xlApp.EnableEvents = False
        xlApp.DisplayAlerts = False

        Try

            ''テンプレートファイルのOPEN
            Dim ofm As New OioFileManage
            Dim TemplateFileDir As String
            Dim TemplateFileNM As String
            Dim TemplateFilePath As String
            TemplateFileDir = ofm.GetLocalTemplateFolder
            TemplateFileNM = GetTemplateFileNM(patternCD)
            TemplateFilePath = TemplateFileDir & TemplateFileNM
            xlOutBook = xlApp.Workbooks.Open(TemplateFilePath)

            ''個別PSBookの取得
            Dim PsFileDir As String
            Dim PsFileNM As String
            Dim PsFilePath As String
            PsFileDir = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFileNM = ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFilePath = PsFileDir & PsFileNM

            ''個別PSBookのOpen
            xlPSBook = xlApp.Workbooks.Open(PsFilePath)

            ''個別PSファイルの行コピー
            Call CopyPSRows(xlOutBook, PSRows)

            ''WS1シートのコピー
            Call CopyWS1(xlOutBook, xlPSBook)

            ''価格開示ファイルの保存
            Call DelXlsNames(xlOutBook)
            xlOutBook.Activate()
            xlOutBook.SaveAs(Filename:=outFileNm, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

            CreateSystemServiceFile = True

        Catch ex As Exception
            Throw ex

        Finally

            ''オブジェクトの解放
            If IsNothing(xlOutBook) = False Then
                xlOutBook.Close(False)
            End If
            If IsNothing(xlPSBook) = False Then
                xlPSBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlOutBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
        End Try

    End Function

    ''' <summary>
    ''' 機　能：ISSのファイルの価格開示ファイルのテンプレート作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateISSFile(ByVal patternCD As String, _
                                   ByVal newExist As String, _
                                   ByVal PSRows() As DataRow, _
                                   ByVal outFileNm As String) As Boolean

        ''初期化
        CreateISSFile = False

        Dim xlApp As New Excel.Application
        Dim xlOutBook As Excel.Workbook
        Dim xlPSBook As Excel.Workbook

        'Excel初期化
        xlApp.EnableEvents = False
        xlApp.DisplayAlerts = False

        Try

            ''テンプレートファイルのOPEN
            Dim ofm As New OioFileManage
            Dim TemplateFileDir As String
            Dim TemplateFileNM As String
            Dim TemplateFilePath As String
            TemplateFileDir = ofm.GetLocalTemplateFolder
            TemplateFileNM = GetTemplateFileNM(patternCD)
            TemplateFilePath = TemplateFileDir & TemplateFileNM
            xlOutBook = xlApp.Workbooks.Open(TemplateFilePath)

            ''個別PSBookの取得
            Dim PsFileDir As String
            Dim PsFileNM As String
            Dim PsFilePath As String
            PsFileDir = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFileNM = ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFilePath = PsFileDir & PsFileNM

            ''個別PSBookのOpen
            xlPSBook = xlApp.Workbooks.Open(PsFilePath)

            ''個別PSファイルの行コピー
            Call CopyPSRows(xlOutBook, PSRows)

            ''WS1シートのコピー
            Call CopyWS1(xlOutBook, xlPSBook)

            ''価格開示ファイルの保存
            Call DelXlsNames(xlOutBook)
            xlOutBook.Activate()
            xlOutBook.SaveAs(Filename:=outFileNm, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

            CreateISSFile = True

        Catch ex As Exception
            Throw ex

        Finally

            ''オブジェクトの解放
            If IsNothing(xlOutBook) = False Then
                xlOutBook.Close(False)
            End If
            If IsNothing(xlPSBook) = False Then
                xlPSBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlOutBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
        End Try

    End Function

    'START 変更管理#39（No.1544 MA復帰料金の統合)　2017/04 sugo
    ' ''' <summary>
    ' ''' 機　能：QCOSMA復帰料金のファイルの価格開示ファイルのテンプレート作成
    ' ''' 説　明：
    ' ''' </summary>
    ' ''' <remarks></remarks>
    'Private Function CreateQCOSMAFFile(ByVal patternCD As String, _
    '                                   ByVal newExist As String, _
    '                                   ByVal PSRows() As DataRow, _
    '                                   ByVal outFileNm As String) As Boolean

    '    ''初期化
    '    CreateQCOSMAFFile = False

    '    Dim xlApp As New Excel.Application
    '    Dim xlOutBook As Excel.Workbook
    '    Dim xlPSBook As Excel.Workbook

    '    'Excel初期化
    '    xlApp.EnableEvents = False
    '    xlApp.DisplayAlerts = False

    '    Try

    '        ''テンプレートファイルのOPEN
    '        Dim ofm As New OioFileManage
    '        Dim TemplateFileDir As String
    '        Dim TemplateFileNM As String
    '        Dim TemplateFilePath As String
    '        TemplateFileDir = ofm.GetLocalTemplateFolder
    '        TemplateFileNM = GetTemplateFileNM(patternCD)
    '        TemplateFilePath = TemplateFileDir & TemplateFileNM
    '        xlOutBook = xlApp.Workbooks.Open(TemplateFilePath)

    '        ''個別PSBookの取得
    '        Dim PsFileDir As String
    '        Dim PsFileNM As String
    '        Dim PsFilePath As String
    '        PsFileDir = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
    '        PsFileNM = ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
    '        PsFilePath = PsFileDir & PsFileNM

    '        ''個別PSBookのOpen
    '        xlPSBook = xlApp.Workbooks.Open(PsFilePath)

    '        ''個別PSファイルの行コピー
    '        Call CopyPSRows(xlOutBook, PSRows)

    '        ''WS1シートのコピー
    '        Call CopyWS1(xlOutBook, xlPSBook)

    '        ''価格開示ファイルの保存
    '        Call DelXlsNames(xlOutBook)
    '        xlOutBook.Activate()
    '        xlOutBook.SaveAs(Filename:=outFileNm, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

    '        CreateQCOSMAFFile = True

    '    Catch ex As Exception
    '        Throw ex

    '    Finally

    '        ''オブジェクトの解放
    '        If IsNothing(xlOutBook) = False Then
    '            xlOutBook.Close(False)
    '        End If
    '        If IsNothing(xlPSBook) = False Then
    '            xlPSBook.Close(False)
    '        End If
    '        ExcelObjRelease.ReleaseExcelObj(xlOutBook, ExcelObjRelease.OBJECT_NOTHING)
    '        ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
    '        xlApp.EnableEvents = True
    '        xlApp.DisplayAlerts = True
    '        If IsNothing(xlApp) = False Then
    '            xlApp.Quit()
    '        End If
    '        ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
    '    End Try

    'End Function
    'END   変更管理#39（No.1544 MA復帰料金の統合)　2017/04 sugo

    ''' <summary>
    ''' 機　能：AASMA復帰料金のファイルの価格開示ファイルのテンプレート作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateAASMAFFile(ByVal patternCD As String, _
                                      ByVal newExist As String, _
                                      ByVal PSRows() As DataRow, _
                                      ByVal outFileNm As String) As Boolean

        ''初期化
        CreateAASMAFFile = False

        Dim xlApp As New Excel.Application
        Dim xlOutBook As Excel.Workbook
        Dim xlPSBook As Excel.Workbook

        'Excel初期化
        xlApp.EnableEvents = False
        xlApp.DisplayAlerts = False

        Try

            ''テンプレートファイルのOPEN
            Dim ofm As New OioFileManage
            Dim TemplateFileDir As String
            Dim TemplateFileNM As String
            Dim TemplateFilePath As String
            TemplateFileDir = ofm.GetLocalTemplateFolder
            TemplateFileNM = GetTemplateFileNM(patternCD)
            TemplateFilePath = TemplateFileDir & TemplateFileNM
            xlOutBook = xlApp.Workbooks.Open(TemplateFilePath)

            ''個別PSBookの取得
            Dim PsFileDir As String
            Dim PsFileNM As String
            Dim PsFilePath As String
            PsFileDir = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFileNM = ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFilePath = PsFileDir & PsFileNM

            ''個別PSBookのOpen
            xlPSBook = xlApp.Workbooks.Open(PsFilePath)

            ''個別PSファイルの行コピー
            Call CopyPSRows(xlOutBook, PSRows)

            ''WS1シートのコピー
            Call CopyWS1(xlOutBook, xlPSBook)

            ''価格開示ファイルの保存
            Call DelXlsNames(xlOutBook)
            xlOutBook.Activate()
            xlOutBook.SaveAs(Filename:=outFileNm, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

            CreateAASMAFFile = True

        Catch ex As Exception
            Throw ex

        Finally

            ''オブジェクトの解放
            If IsNothing(xlOutBook) = False Then
                xlOutBook.Close(False)
            End If
            If IsNothing(xlPSBook) = False Then
                xlPSBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlOutBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
        End Try

    End Function


    ''' <summary>
    ''' 機　能：AASHWServicepacのファイルの価格開示ファイルのテンプレート作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateAASHWServicepacFile(ByVal patternCD As String, _
                                               ByVal newExist As String, _
                                               ByVal PSRows() As DataRow, _
                                               ByVal outFileNm As String) As Boolean

        ''初期化
        CreateAASHWServicepacFile = False

        Dim xlApp As New Excel.Application
        Dim xlOutBook As Excel.Workbook
        Dim xlPSBook As Excel.Workbook

        'Excel初期化
        xlApp.EnableEvents = False
        xlApp.DisplayAlerts = False

        Try

            ''テンプレートファイルのOPEN
            Dim ofm As New OioFileManage
            Dim TemplateFileDir As String
            Dim TemplateFileNM As String
            Dim TemplateFilePath As String
            TemplateFileDir = ofm.GetLocalTemplateFolder
            TemplateFileNM = GetTemplateFileNM(patternCD)
            TemplateFilePath = TemplateFileDir & TemplateFileNM
            xlOutBook = xlApp.Workbooks.Open(TemplateFilePath)

            ''個別PSBookの取得
            Dim PsFileDir As String
            Dim PsFileNM As String
            Dim PsFilePath As String
            PsFileDir = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFileNM = ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFilePath = PsFileDir & PsFileNM

            ''個別PSBookのOpen
            xlPSBook = xlApp.Workbooks.Open(PsFilePath)

            ''個別PSファイルの行コピー
            Call CopyPSRows(xlOutBook, PSRows)

            ''WS1シートのコピー
            Call CopyWS1(xlOutBook, xlPSBook)

            ''価格開示ファイルの保存
            Call DelXlsNames(xlOutBook)
            xlOutBook.Activate()
            xlOutBook.SaveAs(Filename:=outFileNm, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

            CreateAASHWServicepacFile = True

        Catch ex As Exception
            Throw ex
        Finally

            ''オブジェクトの解放
            If IsNothing(xlOutBook) = False Then
                xlOutBook.Close(False)
            End If
            If IsNothing(xlPSBook) = False Then
                xlPSBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlOutBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
        End Try

    End Function


    ''' <summary>
    ''' 機　能：QCOSHWServicepacのファイルの価格開示ファイルのテンプレート作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateQCOSHWServicepacFile(ByVal patternCD As String, _
                                                ByVal newExist As String, _
                                                ByVal PSRows() As DataRow, _
                                                ByVal outFileNm As String) As Boolean

        ''初期化
        CreateQCOSHWServicepacFile = False

        Dim xlApp As New Excel.Application
        Dim xlOutBook As Excel.Workbook
        Dim xlPSBook As Excel.Workbook

        'Excel初期化
        xlApp.EnableEvents = False
        xlApp.DisplayAlerts = False

        Try

            ''テンプレートファイルのOPEN
            Dim ofm As New OioFileManage
            Dim TemplateFileDir As String
            Dim TemplateFileNM As String
            Dim TemplateFilePath As String
            TemplateFileDir = ofm.GetLocalTemplateFolder
            TemplateFileNM = GetTemplateFileNM(patternCD)
            TemplateFilePath = TemplateFileDir & TemplateFileNM
            xlOutBook = xlApp.Workbooks.Open(TemplateFilePath)

            ''個別PSBookの取得
            Dim PsFileDir As String
            Dim PsFileNM As String
            Dim PsFilePath As String
            PsFileDir = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFileNM = ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFilePath = PsFileDir & PsFileNM

            ''個別PSBookのOpen
            xlPSBook = xlApp.Workbooks.Open(PsFilePath)

            ''個別PSファイルの行コピー
            Call CopyPSRows(xlOutBook, PSRows)

            ''WS1シートのコピー
            Call CopyWS1(xlOutBook, xlPSBook)

            ''価格開示ファイルの保存
            Call DelXlsNames(xlOutBook)
            xlOutBook.Activate()
            xlOutBook.SaveAs(Filename:=outFileNm, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

            CreateQCOSHWServicepacFile = True

        Catch ex As Exception
            Throw ex
        Finally

            ''オブジェクトの解放
            If IsNothing(xlOutBook) = False Then
                xlOutBook.Close(False)
            End If
            If IsNothing(xlPSBook) = False Then
                xlPSBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlOutBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
        End Try

    End Function


    ''' <summary>
    ''' 機　能：SWServicepacのファイルの価格開示ファイルのテンプレート作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateSWServicepacFile(ByVal patternCD As String, _
                                            ByVal newExist As String, _
                                            ByVal PSRows() As DataRow, _
                                            ByVal outFileNm As String) As Boolean

        ''初期化
        CreateSWServicepacFile = False

        Dim xlApp As New Excel.Application
        Dim xlOutBook As Excel.Workbook
        Dim xlPSBook As Excel.Workbook

        'Excel初期化
        xlApp.EnableEvents = False
        xlApp.DisplayAlerts = False

        Try

            ''テンプレートファイルのOPEN
            Dim ofm As New OioFileManage
            Dim TemplateFileDir As String
            Dim TemplateFileNM As String
            Dim TemplateFilePath As String
            TemplateFileDir = ofm.GetLocalTemplateFolder
            TemplateFileNM = GetTemplateFileNM(patternCD)
            TemplateFilePath = TemplateFileDir & TemplateFileNM
            xlOutBook = xlApp.Workbooks.Open(TemplateFilePath)

            ''個別PSBookの取得
            Dim PsFileDir As String
            Dim PsFileNM As String
            Dim PsFilePath As String
            PsFileDir = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFileNM = ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFilePath = PsFileDir & PsFileNM

            ''個別PSBookのOpen
            xlPSBook = xlApp.Workbooks.Open(PsFilePath)

            ''個別PSファイルの行コピー
            Call CopyPSRows(xlOutBook, PSRows)

            ''WS1シートのコピー
            Call CopyWS1(xlOutBook, xlPSBook)

            ''価格開示ファイルの保存
            Call DelXlsNames(xlOutBook)
            xlOutBook.Activate()
            xlOutBook.SaveAs(Filename:=outFileNm, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

            CreateSWServicepacFile = True

        Catch ex As Exception
            Throw ex
        Finally

            ''オブジェクトの解放
            If IsNothing(xlOutBook) = False Then
                xlOutBook.Close(False)
            End If
            If IsNothing(xlPSBook) = False Then
                xlPSBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlOutBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
        End Try

    End Function

    ''' <summary>
    ''' 機　能：AASHWMAのファイルの価格開示ファイルのテンプレート作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateAASHWMAFile(ByVal patternCD As String, _
                                       ByVal PSRows() As DataRow, _
                                       ByVal referenceRows As DataRowCollection, _
                                       ByVal detailRows() As DataRow, _
                                       ByVal PSDetailDataTable As DataTable, _
                                       ByVal outFileNm As String) As Boolean

        ''初期化
        CreateAASHWMAFile = False

        Dim xlApp As New Excel.Application
        Dim xlOutBook As Excel.Workbook
        Dim xlPSBook As Excel.Workbook

        'Excel初期化
        xlApp.EnableEvents = False
        xlApp.DisplayAlerts = False
        Try

            ''テンプレートファイルのOPEN
            Dim ofm As New OioFileManage
            Dim TemplateFileDir As String
            Dim TemplateFileNM As String
            Dim TemplateFilePath As String
            TemplateFileDir = ofm.GetLocalTemplateFolder
            TemplateFileNM = GetTemplateFileNM(patternCD)
            TemplateFilePath = TemplateFileDir & TemplateFileNM
            xlOutBook = xlApp.Workbooks.Open(TemplateFilePath)

            ''個別PSBookの取得
            Dim PsFileDir As String
            Dim PsFileNM As String
            Dim PsFilePath As String
            PsFileDir = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFileNM = ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFilePath = PsFileDir & PsFileNM

            ''個別PSBookのOpen
            xlPSBook = xlApp.Workbooks.Open(PsFilePath)

            ''PSシート出力
            Call CopyPSRows(xlOutBook, PSRows, "既存")

            ''詳細シート出力
            Call CopyPSDetailRows(xlOutBook, detailRows, PSDetailDataTable)

            ''参考シート出力
            Call CopyReferenceRows(xlOutBook, referenceRows, UBound(PSRows))

            ''WS1シートのコピー
            Call CopyWS1(xlOutBook, xlPSBook)

            '2014/12/18 ※エラー対策　複数のBookOpenでシートを移動するとエラーになる。 Str
            xlPSBook.Close(False)
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            Call MoveSheets(xlOutBook)

            ''価格開示ファイルの保存
            Call DelXlsNames(xlOutBook)
            xlOutBook.Activate()
            xlOutBook.SaveAs(Filename:=outFileNm, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

            CreateAASHWMAFile = True

        Catch ex As Exception
            Throw ex

        Finally
            ''オブジェクトの解放
            If IsNothing(xlOutBook) = False Then
                xlOutBook.Close(False)
            End If
            If IsNothing(xlPSBook) = False Then
                xlPSBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlOutBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
        End Try

    End Function


    ''' <summary>
    ''' 機　能：QCOSHWMAのファイルの価格開示ファイルのテンプレート作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateQCOSHWMAFile(ByVal patternCD As String, _
                                        ByVal newExist As String, _
                                        ByVal PSRows() As DataRow, _
                                        ByVal outFileNm As String) As Boolean

        ''初期化
        CreateQCOSHWMAFile = False

        Dim xlApp As New Excel.Application
        Dim xlOutBook As Excel.Workbook
        Dim xlPSBook As Excel.Workbook

        'Excel初期化
        xlApp.EnableEvents = False
        xlApp.DisplayAlerts = False

        Try

            ''テンプレートファイルのOPEN
            Dim ofm As New OioFileManage
            Dim TemplateFileDir As String
            Dim TemplateFileNM As String
            Dim TemplateFilePath As String
            TemplateFileDir = ofm.GetLocalTemplateFolder
            TemplateFileNM = GetTemplateFileNM(patternCD, newExist)
            TemplateFilePath = TemplateFileDir & TemplateFileNM
            xlOutBook = xlApp.Workbooks.Open(TemplateFilePath)

            ''個別PSBookの取得
            Dim PsFileDir As String
            Dim PsFileNM As String
            Dim PsFilePath As String
            PsFileDir = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFileNM = ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFilePath = PsFileDir & PsFileNM

            ''個別PSBookのOpen
            xlPSBook = xlApp.Workbooks.Open(PsFilePath)

            ''個別PSファイルの行コピー
            Call CopyPSRows(xlOutBook, PSRows)

            ''WS1シートのコピー
            Call CopyWS1(xlOutBook, xlPSBook)

            ''価格開示ファイルの保存
            Call DelXlsNames(xlOutBook)
            xlOutBook.Activate()
            xlOutBook.SaveAs(Filename:=outFileNm, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

            CreateQCOSHWMAFile = True

        Catch ex As Exception
            Throw ex
        Finally
            ''オブジェクトの解放
            If IsNothing(xlOutBook) = False Then
                xlOutBook.Close(False)
            End If
            If IsNothing(xlPSBook) = False Then
                xlPSBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlOutBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
        End Try

    End Function

    ''' <summary>
    ''' 機　能：AASWarrantyOptionのファイルの価格開示ファイルのテンプレート作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateAASWarrantyOptionFile(ByVal patternCD As String, _
                                            ByVal newExist As String, _
                                            ByVal PSRows() As DataRow, _
                                            ByVal outFileNm As String) As Boolean

        ''初期化
        CreateAASWarrantyOptionFile = False

        Dim xlApp As New Excel.Application
        Dim xlOutBook As Excel.Workbook
        Dim xlPSBook As Excel.Workbook

        'Excel初期化
        xlApp.EnableEvents = False
        xlApp.DisplayAlerts = False

        Try

            ''テンプレートファイルのOPEN
            Dim ofm As New OioFileManage
            Dim TemplateFileDir As String
            Dim TemplateFileNM As String
            Dim TemplateFilePath As String
            TemplateFileDir = ofm.GetLocalTemplateFolder
            TemplateFileNM = GetTemplateFileNM(patternCD)
            TemplateFilePath = TemplateFileDir & TemplateFileNM
            xlOutBook = xlApp.Workbooks.Open(TemplateFilePath)

            ''個別PSBookの取得
            Dim PsFileDir As String
            Dim PsFileNM As String
            Dim PsFilePath As String
            PsFileDir = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFileNM = ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFilePath = PsFileDir & PsFileNM

            ''個別PSBookのOpen
            xlPSBook = xlApp.Workbooks.Open(PsFilePath)

            ''個別PSファイルの行コピー
            Call CopyPSRows(xlOutBook, PSRows)

            ''WS1シートのコピー
            Call CopyWS1(xlOutBook, xlPSBook)

            ''価格開示ファイルの保存
            Call DelXlsNames(xlOutBook)
            xlOutBook.Activate()
            xlOutBook.SaveAs(Filename:=outFileNm, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

            CreateAASWarrantyOptionFile = True

        Catch ex As Exception
            Throw ex
        Finally

            ''オブジェクトの解放
            If IsNothing(xlOutBook) = False Then
                xlOutBook.Close(False)
            End If
            If IsNothing(xlPSBook) = False Then
                xlPSBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlOutBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
        End Try

    End Function

    ''' <summary>
    ''' 機　能：QCOSWarrantyOptionのファイルの価格開示ファイルのテンプレート作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateQCOSWarrantyOptionFile(ByVal patternCD As String, _
                                                  ByVal newExist As String, _
                                                  ByVal PSRows() As DataRow, _
                                                  ByVal outFileNm As String) As Boolean

        ''初期化
        CreateQCOSWarrantyOptionFile = False

        Dim xlApp As New Excel.Application
        Dim xlOutBook As Excel.Workbook
        Dim xlPSBook As Excel.Workbook

        'Excel初期化
        xlApp.EnableEvents = False
        xlApp.DisplayAlerts = False

        Try

            ''テンプレートファイルのOPEN
            Dim ofm As New OioFileManage
            Dim TemplateFileDir As String
            Dim TemplateFileNM As String
            Dim TemplateFilePath As String
            TemplateFileDir = ofm.GetLocalTemplateFolder
            TemplateFileNM = GetTemplateFileNM(patternCD)
            TemplateFilePath = TemplateFileDir & TemplateFileNM
            xlOutBook = xlApp.Workbooks.Open(TemplateFilePath)

            ''個別PSBookの取得
            Dim PsFileDir As String
            Dim PsFileNM As String
            Dim PsFilePath As String
            PsFileDir = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFileNM = ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFilePath = PsFileDir & PsFileNM

            ''個別PSBookのOpen
            xlPSBook = xlApp.Workbooks.Open(PsFilePath)

            ''個別PSファイルの行コピー
            Call CopyPSRows(xlOutBook, PSRows)

            ''WS1シートのコピー
            Call CopyWS1(xlOutBook, xlPSBook)

            ''価格開示ファイルの保存
            Call DelXlsNames(xlOutBook)
            xlOutBook.Activate()
            xlOutBook.SaveAs(Filename:=outFileNm, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

            CreateQCOSWarrantyOptionFile = True

        Catch ex As Exception
            Throw ex
        Finally

            ''オブジェクトの解放
            If IsNothing(xlOutBook) = False Then
                xlOutBook.Close(False)
            End If
            If IsNothing(xlPSBook) = False Then
                xlPSBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlOutBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
        End Try

    End Function


    ''' <summary>
    ''' 機　能：拡張保守のファイルの価格開示ファイルのテンプレート作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateExpansionOptionFile(ByVal patternCD As String, _
                                      ByVal newExist As String, _
                                      ByVal PSRows() As DataRow, _
                                      ByVal outFileNm As String) As Boolean

        ''初期化
        CreateExpansionOptionFile = False

        Dim xlApp As New Excel.Application
        Dim xlOutBook As Excel.Workbook
        Dim xlPSBook As Excel.Workbook

        'Excel初期化
        xlApp.EnableEvents = False
        xlApp.DisplayAlerts = False

        Try

            ''テンプレートファイルのOPEN
            Dim ofm As New OioFileManage
            Dim TemplateFileDir As String
            Dim TemplateFileNM As String
            Dim TemplateFilePath As String
            TemplateFileDir = ofm.GetLocalTemplateFolder
            TemplateFileNM = GetTemplateFileNM(patternCD)
            TemplateFilePath = TemplateFileDir & TemplateFileNM
            xlOutBook = xlApp.Workbooks.Open(TemplateFilePath)

            ''個別PSBookの取得
            Dim PsFileDir As String
            Dim PsFileNM As String
            Dim PsFilePath As String
            PsFileDir = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFileNM = ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFilePath = PsFileDir & PsFileNM

            ''個別PSBookのOpen
            xlPSBook = xlApp.Workbooks.Open(PsFilePath)

            ''個別PSファイルの行コピー
            Call CopyPSRows(xlOutBook, PSRows)

            ''WS1シートのコピー
            Call CopyWS1(xlOutBook, xlPSBook)

            ''価格開示ファイルの保存
            Call DelXlsNames(xlOutBook)
            xlOutBook.Activate()
            xlOutBook.SaveAs(Filename:=outFileNm, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

            CreateExpansionOptionFile = True

        Catch ex As Exception
            Throw ex
        Finally

            ''オブジェクトの解放
            If IsNothing(xlOutBook) = False Then
                xlOutBook.Close(False)
            End If
            If IsNothing(xlPSBook) = False Then
                xlPSBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlOutBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
        End Try

    End Function

    ''' <summary>
    ''' 機　能：IGF_USEDのファイルの価格開示ファイルのテンプレート作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateIGF_USEDFile(ByVal patternCD As String, _
                                        ByVal newExist As String, _
                                        ByVal PSRows() As DataRow, _
                                        ByVal PSDetailRows() As DataRow, _
                                        ByVal outFileNm As String, _
                                        ByRef PSdetailTable As DataTable) As Boolean

        ''初期化
        CreateIGF_USEDFile = False

        Dim xlApp As New Excel.Application
        Dim xlPSBook As Excel.Workbook
        Dim xlTempleBook As Excel.Workbook

        'Excel初期化
        xlApp.EnableEvents = False
        xlApp.DisplayAlerts = False

        Try

            ''Templeファイルのパス取得
            Dim ofm As New OioFileManage
            Dim TempleFileDir As String = ofm.GetLocalTemplateFolder()
            Dim TempleFileNM As String = GetTemplateFileNM(patternCD)
            Dim TempleFilePath As String = TempleFileDir & TempleFileNM

            ''TempleファイルのOpen
            xlTempleBook = xlApp.Workbooks.Open(TempleFilePath)

            ''`不要なﾎﾞﾀﾝの削除
            Call DelButton(xlTempleBook)

            ''個別PSファイルの行コピー
            Call CopyPSRows(xlTempleBook, PSRows)

            ''個別詳細ファイルの行コピー
            Call CopyPSDetailRows(xlTempleBook, PSDetailRows, PSdetailTable)

            ''個別詳細ファイルのパス取得
            Dim PSFileDir As String = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            Dim PSFileNM As String = ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            Dim PSFilePath As String = PSFileDir & PSFileNM

            ''個別PSファイルのOPEN
            xlPSBook = xlApp.Workbooks.Open(PSFilePath)

            ''WS1シートのコピー
            Call CopyWS1(xlTempleBook, xlPSBook)

            ''価格開示ファイルの保存(テンプレートファイルを別名保存)
            Call DelXlsNames(xlTempleBook)
            xlTempleBook.Activate()
            xlTempleBook.SaveAs(Filename:=outFileNm, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

            CreateIGF_USEDFile = True

        Catch ex As Exception
            Throw ex

        Finally

            ''オブジェクトの解放
            If IsNothing(xlTempleBook) = False Then
                xlTempleBook.Close(False)
            End If
            If IsNothing(xlPSBook) = False Then
                xlPSBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlTempleBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
        End Try

    End Function

    ''' <summary>
    ''' 機　能：FMAのファイルの価格開示ファイルのテンプレート作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateFMAFile(ByVal patternCD As String, _
                                      ByVal newExist As String, _
                                      ByVal PSRows() As DataRow, _
                                      ByVal outFileNm As String) As Boolean

        ''初期化
        CreateFMAFile = False

        Dim xlApp As New Excel.Application
        Dim xlOutBook As Excel.Workbook
        Dim xlPSBook As Excel.Workbook

        'Excel初期化
        xlApp.EnableEvents = False
        xlApp.DisplayAlerts = False

        Try

            ''テンプレートファイルのOPEN
            Dim ofm As New OioFileManage
            Dim TemplateFileDir As String
            Dim TemplateFileNM As String
            Dim TemplateFilePath As String
            TemplateFileDir = ofm.GetLocalTemplateFolder
            TemplateFileNM = GetTemplateFileNM(patternCD)
            TemplateFilePath = TemplateFileDir & TemplateFileNM
            xlOutBook = xlApp.Workbooks.Open(TemplateFilePath)

            ''個別PSBookの取得
            Dim PsFileDir As String
            Dim PsFileNM As String
            Dim PsFilePath As String
            PsFileDir = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFileNM = ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFilePath = PsFileDir & PsFileNM

            ''個別PSBookのOpen
            xlPSBook = xlApp.Workbooks.Open(PsFilePath)

            ''個別PSファイルの行コピー
            Call CopyPSRows(xlOutBook, PSRows)

            ''WS1シートのコピー
            Call CopyWS1(xlOutBook, xlPSBook)

            ''価格開示ファイルの保存
            Call DelXlsNames(xlOutBook)
            xlOutBook.Activate()
            xlOutBook.SaveAs(Filename:=outFileNm, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

            CreateFMAFile = True

        Catch ex As Exception
            Throw ex
        Finally

            ''オブジェクトの解放
            If IsNothing(xlOutBook) = False Then
                xlOutBook.Close(False)
            End If
            If IsNothing(xlPSBook) = False Then
                xlPSBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlOutBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
        End Try

    End Function
    '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) Start
    ''' <summary>
    ''' 機　能：MSSのファイルの価格開示ファイルのテンプレート作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateMSSFile(ByVal patternCD As String, _
                                      ByVal newExist As String, _
                                      ByVal PSRows() As DataRow, _
                                      ByVal outFileNm As String) As Boolean

        ''初期化
        CreateMSSFile = False

        Dim xlApp As New Excel.Application
        Dim xlOutBook As Excel.Workbook
        Dim xlPSBook As Excel.Workbook

        'Excel初期化
        xlApp.EnableEvents = False
        xlApp.DisplayAlerts = False

        Try

            ''テンプレートファイルのOPEN
            Dim ofm As New OioFileManage
            Dim TemplateFileDir As String
            Dim TemplateFileNM As String
            Dim TemplateFilePath As String
            TemplateFileDir = ofm.GetLocalTemplateFolder
            TemplateFileNM = GetTemplateFileNM(patternCD)
            TemplateFilePath = TemplateFileDir & TemplateFileNM
            xlOutBook = xlApp.Workbooks.Open(TemplateFilePath)

            ''個別PSBookの取得
            Dim PsFileDir As String
            Dim PsFileNM As String
            Dim PsFilePath As String
            PsFileDir = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFileNM = ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFilePath = PsFileDir & PsFileNM

            ''個別PSBookのOpen
            xlPSBook = xlApp.Workbooks.Open(PsFilePath)

            ''個別PSファイルの行コピー
            Call CopyPSRows(xlOutBook, PSRows)

            ''WS1シートのコピー
            Call CopyWS1(xlOutBook, xlPSBook)

            ''価格開示ファイルの保存
            Call DelXlsNames(xlOutBook)
            xlOutBook.Activate()
            xlOutBook.SaveAs(Filename:=outFileNm, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

            CreateMSSFile = True

        Catch ex As Exception
            Throw ex
        Finally

            ''オブジェクトの解放
            If IsNothing(xlOutBook) = False Then
                xlOutBook.Close(False)
            End If
            If IsNothing(xlPSBook) = False Then
                xlPSBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlOutBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
        End Try

    End Function
    '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) End

    ''' <summary>
    ''' 機　能：MVMSのファイルの価格開示ファイルのテンプレート作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateMVMSFile(ByVal patternCD As String, _
                                      ByVal newExist As String, _
                                      ByVal PSRows() As DataRow, _
                                      ByVal outFileNm As String) As Boolean

        ''初期化
        CreateMVMSFile = False

        Dim xlApp As New Excel.Application
        Dim xlOutBook As Excel.Workbook
        Dim xlPSBook As Excel.Workbook

        'Excel初期化
        xlApp.EnableEvents = False
        xlApp.DisplayAlerts = False

        Try

            ''テンプレートファイルのOPEN
            Dim ofm As New OioFileManage
            Dim TemplateFileDir As String
            Dim TemplateFileNM As String
            Dim TemplateFilePath As String
            TemplateFileDir = ofm.GetLocalTemplateFolder
            TemplateFileNM = GetTemplateFileNM(patternCD)
            TemplateFilePath = TemplateFileDir & TemplateFileNM
            xlOutBook = xlApp.Workbooks.Open(TemplateFilePath)

            ''個別PSBookの取得
            Dim PsFileDir As String
            Dim PsFileNM As String
            Dim PsFilePath As String
            PsFileDir = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFileNM = ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFilePath = PsFileDir & PsFileNM

            ''個別PSBookのOpen
            xlPSBook = xlApp.Workbooks.Open(PsFilePath)

            ''個別PSファイルの行コピー
            Call CopyPSRows(xlOutBook, PSRows)

            ''WS1シートのコピー
            Call CopyWS1(xlOutBook, xlPSBook)

            ''価格開示ファイルの保存
            Call DelXlsNames(xlOutBook)
            xlOutBook.Activate()
            xlOutBook.SaveAs(Filename:=outFileNm, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

            CreateMVMSFile = True

        Catch ex As Exception
            Throw ex
        Finally

            ''オブジェクトの解放
            If IsNothing(xlOutBook) = False Then
                xlOutBook.Close(False)
            End If
            If IsNothing(xlPSBook) = False Then
                xlPSBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlOutBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
        End Try

    End Function

    ''' <summary>
    ''' 機　能：Topacsのファイルの価格開示ファイルのテンプレート作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateTopacsFile(ByVal patternCD As String, _
                                      ByVal PSRows() As DataRow, _
                                      ByVal PSDetailRows() As DataRow, _
                                      ByVal outFileNm As String, _
                                      ByRef PSDetailDataTable As DataTable) As Boolean

        ''初期化
        CreateTopacsFile = False

        Dim xlApp As New Excel.Application
        Dim xlTempleBook As Excel.Workbook

        'Excel初期化
        xlApp.EnableEvents = False
        xlApp.DisplayAlerts = False

        Try

            ''Templeファイルのパス取得
            Dim ofm As New OioFileManage
            Dim TempleFileDir As String = ofm.GetLocalTemplateFolder()
            Dim TempleFileNM As String = GetTemplateFileNM(patternCD)
            Dim TempleFilePath As String = TempleFileDir & TempleFileNM

            ''TempleファイルのOpen
            xlTempleBook = xlApp.Workbooks.Open(TempleFilePath)

            ''Summaryシートの行ｺﾋﾟｰ
            Call CopyTopacsSummaryRows(xlTempleBook, PSRows)

            ''個別PSファイルの行コピー
            Call CopyTopacsPSRows(xlTempleBook, PSRows)

            ''個別詳細ファイルの行コピー
            If IsNothing(PSDetailRows) = False Then
                Call CopyTopacsDetailRows(xlTempleBook, PSDetailRows, PSDetailDataTable)
            End If

            ''個別詳細ファイルのパス取得
            Dim PSFileDir As String = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            Dim PSFileNM As String = ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            Dim PSFilePath As String = PSFileDir & PSFileNM

            ''価格開示ファイルの保存(テンプレートファイルを別名保存)
            xlTempleBook.Activate()
            Call DelXlsNames(xlTempleBook)
            xlTempleBook.SaveAs(Filename:=outFileNm, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

            CreateTopacsFile = True

        Catch ex As Exception
            Throw ex

        Finally

            ''オブジェクトの解放
            If IsNothing(xlTempleBook) = False Then
                xlTempleBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlTempleBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try

    End Function

    ''' <summary>
    ''' 機　能：e-PricerのCOST開示ファイル作成
    ''' 説　明：
    ''' </summary>
    ''' <param name="strPattern"></param>
    ''' <param name="drPs"></param>
    ''' <param name="drPsd"></param>
    ''' <param name="strOutputFileName"></param>
    ''' <param name="PSDetailDataTable"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CreateePricerFile(ByVal strPattern As String, _
                                       ByVal drPs() As DataRow, _
                                       ByVal drPsd() As DataRow, _
                                       ByVal strOutputFileName As String, _
                                       ByRef PSDetailDataTable As DataTable) As Boolean

        Dim xlApp As New Excel.Application
        Dim xlBooks As Excel.Workbooks
        Dim xlBook As Excel.Workbook
        Dim ofm As New OioFileManage
        Dim strTmpDir As String
        Dim strTmpFileName As String
        Dim strTmpPath As String

        CreateePricerFile = False

        Try
            'Templeファイルのパス取得
            strTmpDir = ofm.GetLocalTemplateFolder()
            strTmpFileName = GetTemplateFileNM(strPattern)
            strTmpPath = strTmpDir & strTmpFileName

            'Excel初期化
            xlApp.EnableEvents = False
            xlApp.DisplayAlerts = False

            'TempleファイルのOpen
            xlBooks = xlApp.Workbooks
            xlBook = xlBooks.Open(strTmpPath)

            'Summaryシートの行ｺﾋﾟｰ
            Call CopyePricerSummaryRows(xlBook, drPs)

            '個別PSファイルの行コピー
            Call CopyePricerPSRows(xlBook, drPs)

            '個別詳細ファイルの行コピー
            If IsNothing(drPsd) = False Then
                Call CopyepricerDetailRows(xlBook, drPsd, PSDetailDataTable)
            End If

            '価格開示ファイルの保存(テンプレートファイルを別名保存)
            xlBook.Activate()
            Call DelXlsNames(xlBook)
            xlBook.SaveAs(Filename:=strOutputFileName, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

            CreateePricerFile = True

        Catch ex As Exception
            Throw ex

        Finally

            ''オブジェクトの解放
            If IsNothing(xlBook) = False Then
                xlBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlBooks, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try

    End Function

    ''' <summary>
    ''' 機　能：価格開示Templateファイル名の取得
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetTemplateFileNM(ByVal PatternCD As String, _
                                       Optional ByVal NewExist As String = "") As String

        GetTemplateFileNM = ""
        ''パターンコードに応じて、ファイル名を変更
        Dim fileNMDetail As String = ""
        Select Case PatternCD
            Case "1"
                If NewExist = "SI" Then
                    Return "COST開示PSSample.xlsm"
                Else
                    Return "COST開示PS_DetailSample.xlsm"
                End If
            Case "2"
                Return "COST開示PS_DetailSample.xlsm"
            Case "3"
                Return "COST開示PSSample.xlsm"
            Case "4"
                Return "COST開示_CISCOSample.xlsm"
            Case "12"
                Return "COST開示PSSample.xlsm"
            Case "13"
                Return "COST開示PSSample.xlsm"
            Case "14"
                Return "COST開示PSSample.xlsm"
            Case "15", "16"
                Return "COST開示PS_DetailSample.xlsm"
            Case "17"
                Return "COST開示PSSample.xlsm"
            Case "18"
                Return "COST開示PSSample.xlsm"
            Case "19"
                Return "COST開示PSSample.xlsm"
            Case "20"
                Return "COST開示PSSample.xlsm"
            Case "23"
                Return "COST開示PSSample.xlsm"
            Case "31"
                Return "COST開示PS_DetailSample.xlsm"
            Case "32"
                Return "COST開示PSSample.xlsm"
            Case "34"
                Return "COST開示PSSample.xlsm"
            Case "39"
                Return "COST開示PSSample.xlsm"
                'START 変更管理#39（No.1544 MA復帰料金の統合)　2017/04 sugo
            Case "40", "41"
                Return "COST開示PSSample.xlsm"
                'Case "40"
                '    Return "COST開示PSSample.xlsm"
                'Case "41"
                '    Return "COST開示PSSample.xlsm"
                'END   変更管理#39（No.1544 MA復帰料金の統合)　2017/04 sugo
            Case "43", "44"
                Return "COST開示PSSample.xlsm"
                '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) Start
            Case "47"
                Return "COST開示PSSample.xlsm"
                '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) End
            Case "Topacs"
                Return "COST開示TopacsSample.xlsm"
            Case "e-Pricer"
                Return "COST開示e-PricerSample.xlsm"
        End Select

    End Function

    ''' <summary>
    ''' 機　能：価格開示ファイル名の取得
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetOutKakakukaijiFileNM(ByVal PatternCD As String, _
                                             Optional ByVal NewExistorQCOSAAS As String = "") As String

        GetOutKakakukaijiFileNM = ""

        ''パターンコードに応じて、ファイル名を変更
        Dim fileNMDetail As String = ""
        Select Case PatternCD
            Case "1", "2"
                fileNMDetail = "AASHW"
            Case "3"
                fileNMDetail = "QCOSHW"
            Case "4"
                fileNMDetail = "CISCOHW"
            Case "12"
                fileNMDetail = "VLS"
            Case "13"
                If NewExistorQCOSAAS = "AAS" Then
                    fileNMDetail = "AASHWServicepac"
                Else
                    fileNMDetail = "QCOSHWServicepac"
                End If
            Case "14"
                fileNMDetail = "SWServicepac"
            Case "15"
                fileNMDetail = "AASHWMA"
            Case "16"
                fileNMDetail = "AASHWMA"
            Case "17"
                fileNMDetail = "QCOSHWMA"
            Case "18"
                fileNMDetail = "AAS保証ｵﾌﾟｼｮﾝ"
            Case "19"
                fileNMDetail = "QCOS保証ｵﾌﾟｼｮﾝ"
            Case "20"
                fileNMDetail = "MVMS"
            Case "23"
                fileNMDetail = "拡張保守"
            Case "31"
                fileNMDetail = "IGF中古"
            Case "32"
                fileNMDetail = "FMA"
            Case "34"
                fileNMDetail = "ｼｽﾃﾑ･ｻｰﾋﾞｽ"
            Case "39"
                fileNMDetail = "ISS"
                'START 変更管理#39（No.1544 MA復帰料金の統合)　2017/04 sugo
            Case "40", "41"
                fileNMDetail = "MA復帰料金"
                'Case "40"
                '    fileNMDetail = "QCOS_MA復帰料金"
                'Case "41"
                '    fileNMDetail = "AAS_MA復帰料金"
                'END   変更管理#39（No.1544 MA復帰料金の統合)　2017/04 sugo
            Case "43", "44"
                fileNMDetail = "ﾍﾞｰｼｯｸ･ｾﾚｸｼｮﾝ"
                '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) Start
            Case "47"
                fileNMDetail = "MSS"
                '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) End
            Case "SI"
                fileNMDetail = "Service Integrator"
            Case "Topacs"
                fileNMDetail = "TopacsCOST"
            Case "e-Pricer"
                fileNMDetail = "e-PricerCOST"


        End Select

        GetOutKakakukaijiFileNM = "COST開示_" & _
                                  CommonVariable.CPNO.Trim.PadLeft(6, "0") & _
                                  "(" & CommonVariable.CUSTOMERNAME & ")" & _
                                  "_NO" & _
                                  CommonVariable.CONTRACTNO.ToString().PadLeft(3, "0c") & _
                                  "_" & _
                                  Me.createFileTime & _
                                  "_" & _
                                  fileNMDetail & _
                                  ".xlsm"

    End Function



    ''' <summary>
    ''' 機　能：個別PS　テーブルデータのファイル毎のフィルタ条件を取得
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetCostKaijiFiler(ByVal PatternCd As String,
                                       ByVal PatternNM As String,
                                       Optional ByVal NewExistorQCOSAAS As String = "") As String

        GetCostKaijiFiler = ""

        Dim Filter As New StringBuilder

        ''AASHWの場合、パターンコード 1と2が出力対象
        Select Case PatternCd
            Case "1", "2"

                ''基本条件
                ''※数量マイナスは対象外
                Filter.Append(PSEXCEL_CLOUMNMNAME_QTY)
                Filter.Append(CommonConstant.SQL_STR_NOT)
                Filter.Append(CommonConstant.SQL_STR_LIKE)
                Filter.Append(StringEdit.EncloseSingleQuotation("-*"))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(""))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_ST_COST)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("Y"))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
                Filter.Append(CommonConstant.SQL_STR_NOT)
                Filter.Append(CommonConstant.SQL_STR_IN)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(StringEdit.EncloseSingleQuotation("C"))
                Filter.Append(CommonConstant.STR_COMMA)
                Filter.Append(StringEdit.EncloseSingleQuotation("N"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_BRAND_AP_FORM)
                Filter.Append(CommonConstant.SQL_STR_NOT_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(""))
                Filter.Append(CommonConstant.SQL_STR_OR)
                Filter.Append(PSEXCEL_CLOUMNMNAME_BRAND_AP_REQ)
                Filter.Append(CommonConstant.SQL_STR_NOT_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(""))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)

                ''パターンCD毎の条件
                ''AAS Box/Mes
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("1"))
                Filter.Append(CommonConstant.SQL_STR_OR)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("2"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_OPTION1)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(""))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                Filter.Append(CommonConstant.SQL_STR_OR)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("25"))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_IBM_HW_AAS_BOX))
                Filter.Append(CommonConstant.SQL_STR_OR)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_IBM_HW_AAS_MES))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_OPTION1)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(""))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)


            Case "3"

                ''=====================================
                ''				直接入力以外
                ''=====================================
                ''基本条件
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(""))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_ST_COST)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("Y"))

                ''コメント行は出力しない。
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
                Filter.Append(CommonConstant.SQL_STR_NOT)
                Filter.Append(CommonConstant.SQL_STR_IN)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(StringEdit.EncloseSingleQuotation("C"))
                Filter.Append(CommonConstant.STR_COMMA)
                Filter.Append(StringEdit.EncloseSingleQuotation("N"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                ''パターンCD毎の条件
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("3"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                ''=====================================
                ''		直接入力以外（QcosSWのCost有り）
                ''=====================================
                Filter.Append(CommonConstant.SQL_STR_OR)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)

                ''基本条件
                Filter.Append(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(""))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_ST_COST)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("Y"))

                ''コメント行は出力しない。
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
                Filter.Append(CommonConstant.SQL_STR_NOT)
                Filter.Append(CommonConstant.SQL_STR_IN)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(StringEdit.EncloseSingleQuotation("C"))
                Filter.Append(CommonConstant.STR_COMMA)
                Filter.Append(StringEdit.EncloseSingleQuotation("N"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                ''パターンCD毎の条件
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("6"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                Filter.Append(CommonConstant.SQL_STR_OR)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)

                ''基本条件
                Filter.Append(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(""))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_ST_COST)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("Y"))

                ''コメント行は出力しない。
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
                Filter.Append(CommonConstant.SQL_STR_NOT)
                Filter.Append(CommonConstant.SQL_STR_IN)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(StringEdit.EncloseSingleQuotation("C"))
                Filter.Append(CommonConstant.STR_COMMA)
                Filter.Append(StringEdit.EncloseSingleQuotation("N"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                ''パターンCD毎の条件
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("8"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                ''=====================================
                ''		 直接入力（IBM HW QCOS）
                ''=====================================
                Filter.Append(CommonConstant.SQL_STR_OR)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)

                ''基本条件
                Filter.Append(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(""))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_ST_COST)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("Y"))

                ''コメント行は出力しない。
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
                Filter.Append(CommonConstant.SQL_STR_NOT)
                Filter.Append(CommonConstant.SQL_STR_IN)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(StringEdit.EncloseSingleQuotation("C"))
                Filter.Append(CommonConstant.STR_COMMA)
                Filter.Append(StringEdit.EncloseSingleQuotation("N"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                ''パターンCD毎の条件
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("25"))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_IBM_HW_QCOS))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)


                ''=====================================
                ''		 直接入力（HWBrandSW QCOS）
                ''=====================================
                Filter.Append(CommonConstant.SQL_STR_OR)

                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)

                ''基本条件
                Filter.Append(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(""))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_ST_COST)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("Y"))

                ''コメント行は出力しない。
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
                Filter.Append(CommonConstant.SQL_STR_NOT)
                Filter.Append(CommonConstant.SQL_STR_IN)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(StringEdit.EncloseSingleQuotation("C"))
                Filter.Append(CommonConstant.STR_COMMA)
                Filter.Append(StringEdit.EncloseSingleQuotation("N"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                ''パターンCD毎の条件
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("25"))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_HWBrandSW_QCOS))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                ''=====================================
                ''		 直接入力(HWBrandSWMA QCOS)
                ''=====================================
                Filter.Append(CommonConstant.SQL_STR_OR)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)

                ''基本条件
                Filter.Append(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(""))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_ST_COST)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("Y"))

                ''コメント行は出力しない。
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
                Filter.Append(CommonConstant.SQL_STR_NOT)
                Filter.Append(CommonConstant.SQL_STR_IN)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(StringEdit.EncloseSingleQuotation("C"))
                Filter.Append(CommonConstant.STR_COMMA)
                Filter.Append(StringEdit.EncloseSingleQuotation("N"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                ''パターンCD毎の条件
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("25"))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_HWBrandSWMA_QCOS))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

            Case "13"

                ''=====================================
                ''				直接入力以外
                ''=====================================

                ''基本条件
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(""))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_ST_COST)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("Y"))

                ''コメント行は出力しない。
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
                Filter.Append(CommonConstant.SQL_STR_NOT)
                Filter.Append(CommonConstant.SQL_STR_IN)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(StringEdit.EncloseSingleQuotation("C"))
                Filter.Append(CommonConstant.STR_COMMA)
                Filter.Append(StringEdit.EncloseSingleQuotation("N"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                ''パターンCD毎の条件
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(PatternCd))

                ''HW ServicePacは"AAS"と"QCOS"でファイルを分割する。　
                ''※製品番号に"-"を含むかどうかで判定を行う。
                If NewExistorQCOSAAS = "AAS" Then
                    Filter.Append(CommonConstant.SQL_STR_AND)
                    Filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM04)
                    Filter.Append(CommonConstant.SQL_STR_LIKE)
                    Filter.Append(StringEdit.EncloseSingleQuotation("*-*"))
                Else
                    Filter.Append(CommonConstant.SQL_STR_AND)
                    Filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM04)
                    Filter.Append(CommonConstant.SQL_STR_NOT)
                    Filter.Append(CommonConstant.SQL_STR_LIKE)
                    Filter.Append(StringEdit.EncloseSingleQuotation("*-*"))
                End If
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                ''=====================================
                ''		 直接入力(IBM HW AAS BOX)
                ''=====================================
                Filter.Append(CommonConstant.SQL_STR_OR)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)

                ''基本条件				
                Filter.Append(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(""))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_ST_COST)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("Y"))

                ''コメント行は出力しない。
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
                Filter.Append(CommonConstant.SQL_STR_NOT)
                Filter.Append(CommonConstant.SQL_STR_IN)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(StringEdit.EncloseSingleQuotation("C"))
                Filter.Append(CommonConstant.STR_COMMA)
                Filter.Append(StringEdit.EncloseSingleQuotation("N"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                ''HW ServicePacは"AAS"と"QCOS"でファイルを分割する。　
                ''※製品番号に"-"を含むかどうかで判定を行う。
                If NewExistorQCOSAAS = "AAS" Then
                    Filter.Append(CommonConstant.SQL_STR_AND)
                    Filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM04)
                    Filter.Append(CommonConstant.SQL_STR_LIKE)
                    Filter.Append(StringEdit.EncloseSingleQuotation("*-*"))
                Else
                    Filter.Append(CommonConstant.SQL_STR_AND)
                    Filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM04)
                    Filter.Append(CommonConstant.SQL_STR_NOT)
                    Filter.Append(CommonConstant.SQL_STR_LIKE)
                    Filter.Append(StringEdit.EncloseSingleQuotation("*-*"))
                End If
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("25"))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_HWServicePac))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

            Case "15", "16"

                ''=====================================
                ''				直接入力以外
                ''=====================================
                Filter.Append(PSEXCEL_CLOUMNMNAME_QTY)
                Filter.Append(CommonConstant.SQL_STR_NOT)
                Filter.Append(CommonConstant.SQL_STR_LIKE)
                Filter.Append(StringEdit.EncloseSingleQuotation("-*"))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)

                ''基本条件
                Filter.Append(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(""))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_ST_COST)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("Y"))

                ''コメント行は出力しない。
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
                Filter.Append(CommonConstant.SQL_STR_NOT)
                Filter.Append(CommonConstant.SQL_STR_IN)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(StringEdit.EncloseSingleQuotation("C"))
                Filter.Append(CommonConstant.STR_COMMA)
                Filter.Append(StringEdit.EncloseSingleQuotation("N"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                ''パターンCD毎の条件
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("15"))
                Filter.Append(CommonConstant.SQL_STR_OR)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("16"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                ''=====================================
                ''		 直接入力(IBM HWMA AAS BOX)
                ''=====================================
                Filter.Append(CommonConstant.SQL_STR_OR)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)

                ''基本条件
                Filter.Append(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(""))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_ST_COST)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("Y"))

                ''コメント行は出力しない。
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
                Filter.Append(CommonConstant.SQL_STR_NOT)
                Filter.Append(CommonConstant.SQL_STR_IN)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(StringEdit.EncloseSingleQuotation("C"))
                Filter.Append(CommonConstant.STR_COMMA)
                Filter.Append(StringEdit.EncloseSingleQuotation("N"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                ''パターンCD毎の条件
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("25"))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_IBM_HWMA_AAS_BOX))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                ''=====================================
                ''		 直接入力(IBM HWMA MES)
                ''=====================================
                Filter.Append(CommonConstant.SQL_STR_OR)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)

                ''基本条件
                Filter.Append(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(""))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_ST_COST)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("Y"))

                ''コメント行は出力しない。
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
                Filter.Append(CommonConstant.SQL_STR_NOT)
                Filter.Append(CommonConstant.SQL_STR_IN)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(StringEdit.EncloseSingleQuotation("C"))
                Filter.Append(CommonConstant.STR_COMMA)
                Filter.Append(StringEdit.EncloseSingleQuotation("N"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                ''パターンCD毎の条件
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("25"))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_IBM_HWMA_AAS_MES))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

            Case "17"

                ''=====================================
                ''				直接入力以外
                ''=====================================
                ''基本条件
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(""))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_ST_COST)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("Y"))

                ''コメント行は出力しない。
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
                Filter.Append(CommonConstant.SQL_STR_NOT)
                Filter.Append(CommonConstant.SQL_STR_IN)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(StringEdit.EncloseSingleQuotation("C"))
                Filter.Append(CommonConstant.STR_COMMA)
                Filter.Append(StringEdit.EncloseSingleQuotation("N"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                ''パターンCD毎の条件
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(PatternCd))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                ''=====================================
                ''		          直接入力
                ''=====================================
                Filter.Append(CommonConstant.SQL_STR_OR)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)

                ''基本条件
                Filter.Append(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(""))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_ST_COST)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("Y"))

                ''コメント行は出力しない。
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
                Filter.Append(CommonConstant.SQL_STR_NOT)
                Filter.Append(CommonConstant.SQL_STR_IN)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(StringEdit.EncloseSingleQuotation("C"))
                Filter.Append(CommonConstant.STR_COMMA)
                Filter.Append(StringEdit.EncloseSingleQuotation("N"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                ''パターンCD毎の条件
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("25"))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(PatternNM))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

            Case "31"

                ''                      以下、基本条件
                ''--------------------------------------------------------------
                Filter.Append(PSEXCEL_CLOUMNMNAME_QTY)
                Filter.Append(CommonConstant.SQL_STR_NOT)
                Filter.Append(CommonConstant.SQL_STR_LIKE)
                Filter.Append(StringEdit.EncloseSingleQuotation("-*"))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(""))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_ST_COST)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("Y"))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
                Filter.Append(CommonConstant.SQL_STR_NOT)
                Filter.Append(CommonConstant.SQL_STR_IN)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(StringEdit.EncloseSingleQuotation("C"))
                Filter.Append(CommonConstant.STR_COMMA)
                Filter.Append(StringEdit.EncloseSingleQuotation("N"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                Filter.Append(CommonConstant.SQL_STR_AND)


                ''             以下、パターンCD個別の抽出条件
                ''--------------------------------------------------------------
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)

                ''パターンCDで判別
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("31"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                Filter.Append(CommonConstant.SQL_STR_OR)

                ''直接入力のため、パターン名称で判別
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("25"))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_IGF_USED))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

            Case "Topacs"
                ''基本条件
                Filter.Append(PSEXCEL_CLOUMNMNAME_QTY)
                Filter.Append(CommonConstant.SQL_STR_NOT)
                Filter.Append(CommonConstant.SQL_STR_LIKE)
                Filter.Append(StringEdit.EncloseSingleQuotation("-*"))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(""))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_ST_COST)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("Y"))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
                Filter.Append(CommonConstant.SQL_STR_NOT)
                Filter.Append(CommonConstant.SQL_STR_IN)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(StringEdit.EncloseSingleQuotation("C"))
                Filter.Append(CommonConstant.STR_COMMA)
                Filter.Append(StringEdit.EncloseSingleQuotation("N"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_BRAND_AP_FORM)
                Filter.Append(CommonConstant.SQL_STR_NOT_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(""))
                Filter.Append(CommonConstant.SQL_STR_OR)
                Filter.Append(PSEXCEL_CLOUMNMNAME_BRAND_AP_REQ)
                Filter.Append(CommonConstant.SQL_STR_NOT_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(""))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)

                ''パターン毎の条件         
                ''AAS/MES       
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("1"))
                Filter.Append(CommonConstant.SQL_STR_OR)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("2"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_OPTION1)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(""))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                Filter.Append(CommonConstant.SQL_STR_OR)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("25"))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_IBM_HW_AAS_BOX))
                Filter.Append(CommonConstant.SQL_STR_OR)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_IBM_HW_AAS_MES))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_OPTION1)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(""))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                ''QCOS
                Filter.Append(CommonConstant.SQL_STR_OR)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("3"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                Filter.Append(CommonConstant.SQL_STR_OR)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("25"))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_IBM_HW_QCOS))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                ''HWBrandSW QCOS
                Filter.Append(CommonConstant.SQL_STR_OR)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("6"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                Filter.Append(CommonConstant.SQL_STR_OR)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("25"))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_HWBrandSW_QCOS))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                ''HWBrandSWMA QCOS
                Filter.Append(CommonConstant.SQL_STR_OR)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("8"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                Filter.Append(CommonConstant.SQL_STR_OR)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("25"))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_HWBrandSWMA_QCOS))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

            Case "e-Pricer"
                '基本条件
                Filter.Append(PSEXCEL_CLOUMNMNAME_QTY)
                Filter.Append(CommonConstant.SQL_STR_NOT)
                Filter.Append(CommonConstant.SQL_STR_LIKE)
                Filter.Append(StringEdit.EncloseSingleQuotation("-*"))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(""))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_ST_COST)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("Y"))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
                Filter.Append(CommonConstant.SQL_STR_NOT)
                Filter.Append(CommonConstant.SQL_STR_IN)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(StringEdit.EncloseSingleQuotation("C"))
                Filter.Append(CommonConstant.STR_COMMA)
                Filter.Append(StringEdit.EncloseSingleQuotation("N"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                '追加条件
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_BRAND_AP_CONF)
                Filter.Append(CommonConstant.SQL_STR_NOT_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(""))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                ''パターンCD毎の条件
                ''AAS Box/Mes
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("1"))
                Filter.Append(CommonConstant.SQL_STR_OR)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("2"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                Filter.Append(CommonConstant.SQL_STR_OR)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("25"))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_IBM_HW_AAS_BOX))
                Filter.Append(CommonConstant.SQL_STR_OR)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_IBM_HW_AAS_MES))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

            Case Else

                ''=====================================
                ''				直接入力以外
                ''=====================================

                ''基本条件
                Filter.Append(PSEXCEL_CLOUMNMNAME_QTY)
                Filter.Append(CommonConstant.SQL_STR_NOT)
                Filter.Append(CommonConstant.SQL_STR_LIKE)
                Filter.Append(StringEdit.EncloseSingleQuotation("-*"))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(""))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_ST_COST)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("Y"))

                ''コメント行は出力しない。
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
                Filter.Append(CommonConstant.SQL_STR_NOT)
                Filter.Append(CommonConstant.SQL_STR_IN)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(StringEdit.EncloseSingleQuotation("C"))
                Filter.Append(CommonConstant.STR_COMMA)
                Filter.Append(StringEdit.EncloseSingleQuotation("N"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                ''パターンCD毎の条件
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(PatternCd))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                ''=====================================
                ''				直接入力
                ''=====================================
                Filter.Append(CommonConstant.SQL_STR_OR)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)

                ''基本条件
                Filter.Append(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(""))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_ST_COST)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("Y"))

                ''コメント行は出力しない。
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
                Filter.Append(CommonConstant.SQL_STR_NOT)
                Filter.Append(CommonConstant.SQL_STR_IN)
                Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                Filter.Append(StringEdit.EncloseSingleQuotation("C"))
                Filter.Append(CommonConstant.STR_COMMA)
                Filter.Append(StringEdit.EncloseSingleQuotation("N"))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                ''パターンCD毎の条件
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation("25"))
                Filter.Append(CommonConstant.SQL_STR_AND)
                Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN)
                Filter.Append(CommonConstant.SQL_STR_EQUAL)
                Filter.Append(StringEdit.EncloseSingleQuotation(PatternNM))
                Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

        End Select

        Return Filter.ToString

    End Function


    ''' <summary>
    ''' 機　能：個別詳細　テーブルデータの出力対象データを取得
    ''' 説　明：対象データが存在しない場合、rtnRowsはNothingを返す
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetCostKaijiDetailRows(ByVal PatternCd As String, _
                                       ByVal PSRows() As DataRow, _
                                       ByVal PSDetail As DataTable, _
                                       ByRef rtnRows() As DataRow)

        ''出力対象の個別詳細データを抽出
        Dim PSDetailRows As DataRow
        Dim tempRow As DataRow
        Dim tempRows() As DataRow
        Dim filter As New StringBuilder
        Dim isFirst As Boolean = True

        rtnRows = Nothing

        For i As Integer = 0 To PSRows.Length - 1

            ''初期化
            filter.Remove(0, filter.Length)

            ''抽出条件のセット
            filter.Append(PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(PSRows(i).Item(PSEXCEL_CLOUMNMNAME_CONTRACTNO)))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(PSRows(i).Item(PSEXCEL_CLOUMNMNAME_FILE_NAME)))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(PSRows(i).Item(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(PSRows(i).Item(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)))
            tempRows = PSDetail.Select(filter.ToString, PSDETAILEXCEL_CLOUMNMNAME_EXCELROW)

            ''一致するデータを追加
            Dim DelRow As Integer
            If tempRows.Length >= 1 Then

                ''Select結果をrtnRowsに反映する。
                DelRow = 0
                For Each tempRow In tempRows

                    ''初回のみ配列に0をセット
                    If isFirst Then
                        ReDim Preserve rtnRows(0)
                        isFirst = False
                    Else
                        ReDim Preserve rtnRows(rtnRows.Length)
                    End If

                    ''R,CR,Fは作成件数に含めない。
                    Select Case tempRow.Item(PSDETAILEXCEL_CLOUMNMNAME_MES_CATEGORY)
                        Case "R", _
                             "CR", _
                             "F"
                            DelRow = DelRow + 1
                    End Select
                    rtnRows(rtnRows.Length - 1) = tempRow
                Next

                ''紐づく詳細の件数をセット
                PSRows(i).Item(PSEXCEL_CLOUMNMNAME_DetailCount) = tempRows.Length - DelRow - 1

            End If
        Next

    End Sub



    ''' <summary>
    ''' 機　能：個別詳細テンプレートファイルのコピー
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub CopyPSDetailTemplateFile(ByVal outFileNm As String)

        ''個別PSのテンプレートファイルのパスを取得
        Dim ofm As New OioFileManage
        Dim PsDetailTemplateDir As String
        Dim PsDetailTemplateFileNM As String
        Dim PsDetailTemplateFilePath As String

        PsDetailTemplateDir = ofm.GetLocalTemplateCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
        PsDetailTemplateFileNM = CommonConstant.FILENAME_XLS_PAYMENTDETAILSAMPLE
        PsDetailTemplateFilePath = PsDetailTemplateDir & PsDetailTemplateFileNM

        ''Excelオブジェクト
        Dim xlApp As New Excel.Application
        Dim xlInBook As Excel.Workbook
        Dim xlInSheet As Excel.Worksheet
        Dim xlOutBook As Excel.Workbook
        Dim xlOutSheet As Excel.Worksheet
        Dim xlDelShape As Excel.Shape

        ''Excelの初期設定
        xlApp.EnableEvents = False
        xlApp.DisplayAlerts = False

        Try

            ''価格開示BOOKを作成
            xlOutBook = xlApp.Workbooks.Open(outFileNm)

            ''テンプレートファイルのOPEN
            xlInBook = xlApp.Workbooks.Open(PsDetailTemplateFilePath)

            ''テンプレートファイルのコピー
            xlOutSheet = xlOutBook.Worksheets("OBAMA-PS")
            xlInSheet = xlInBook.Worksheets("PaymentLineDetail")
            xlInSheet.Copy(After:=xlOutSheet)

            ''不要なボタンを削除
            xlOutSheet = xlOutBook.Worksheets("PaymentLineDetail")
            xlDelShape = xlOutSheet.Shapes.Item("PS表示ボタン")
            xlDelShape.Delete()
            xlDelShape = xlOutSheet.Shapes.Item("行挿入複写ボタン")
            xlDelShape.Delete()

            ''コピー結果の保存
            xlOutBook.Save()

        Catch ex As Exception
            Throw ex
        Finally
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True

            ''オブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlDelShape, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlInSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlOutSheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlInBook) = False Then
                xlInBook.Close(False)
            End If
            If IsNothing(xlOutBook) = False Then
                xlOutBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlInBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlOutBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.Quit()
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try
    End Sub


    ''' <summary>
    ''' 機　能：個別PSファイルから価格開示ファイルへ出力対象の行をコピー&ペーストする。
    ''' 説　明：
    ''※修正箇所：Template行にExcel式があれば、Template式をセットする。
    ''      　　：Cost期間合計と、請求期間を項目追加する。
    ''      　　：項目追加によってセルの出力位置がズレるため修正する。
    ''      　　：修正箇所多数のため、元のモジュールをコピー/コメントアウトして新規作成する。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub CopyPSRows(ByRef xlOutBook As Excel.Workbook, _
                           ByVal rows() As DataRow, _
                           Optional ByVal newExist As String = "新規")

        Dim outSheet As Excel.Worksheet
        Dim inRange As Excel.Range
        Dim outRange As Excel.Range
        Dim entryRange As Excel.Range
        Dim enColumns As Excel.Range
        Try

            'シートのセット
            outSheet = xlOutBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)

            ''既存AASHWMAのBrandの算出に変換テーブルを使用
            Dim ConvertClientValueData As DataTable
            Dim con As OleDbConnection
            Dim mmc As New MasterMdbControl
            Dim mdbContrl As New MUSE.DataAccess.OleDb.OleDbConvertClientValue
            con = mmc.GetOleDBConnection(CommonVariable.MdbPW)
            ConvertClientValueData = mdbContrl.SelectDataTable(con)
            If rows(0).Item(PSEXCEL_CLOUMNMNAME_PATTERN_CD) = "15" And _
               newExist = "既存" Then

                ''備考 ～ Payment対象行を再表示する。
                Const DispArea As String = "AD:AI"
                enColumns = outSheet.Columns(DispArea)
                enColumns.Hidden = False

            End If

            ''テンプレート行の式をセット
            Dim formulaObj(,) As Object
            inRange = outSheet.Range("A2:AI2")
            formulaObj = inRange.FormulaR1C1

            Dim patternCD As String
            Dim patternNM As String
            Dim copyValue(rows.Length, 34) As Object
            For i As Integer = 0 To rows.Length - 1

                ''対象の出力データを格納
                patternCD = rows(0).Item(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                patternNM = rows(0).Item(PSEXCEL_CLOUMNMNAME_PATTERN)
                copyValue(i, 0) = rows(i).Item(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)
                copyValue(i, 1) = rows(i).Item(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
                copyValue(i, 2) = rows(i).Item(PSEXCEL_CLOUMNMNAME_LINE_NO)
                copyValue(i, 3) = rows(i).Item(PSEXCEL_CLOUMNMNAME_FILE_NAME)
                copyValue(i, 4) = rows(i).Item(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
                copyValue(i, 5) = rows(i).Item(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
                copyValue(i, 6) = rows(i).Item(PSEXCEL_CLOUMNMNAME_CONTRACTNO)
                copyValue(i, 7) = rows(i).Item(PSEXCEL_CLOUMNMNAME_ST_COST)
                copyValue(i, 8) = rows(i).Item(PSEXCEL_CLOUMNMNAME_NEW_EXIST)
                copyValue(i, 9) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                copyValue(i, 10) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PATTERN)
                copyValue(i, 11) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                copyValue(i, 12) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM03)


                ''既存AASHWMA以外は空白をセット
                copyValue(i, 29) = ""
                copyValue(i, 30) = ""
                copyValue(i, 31) = ""
                copyValue(i, 32) = ""
                copyValue(i, 33) = ""
                copyValue(i, 34) = ""

                Select Case rows(i).Item(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                    Case "15", "16"
                        Const CommentValue As String = "指定機械毎にCostが異なる場合は参考シートに入力して下さい"
                        Dim comment As String
                        Dim subBrand As String

                        ''変換TBL使用後のSUBBrand取得
                        subBrand = ExcelWrite.changeDBNullToString(rows(i).Item(PSEXCEL_CLOUMNMNAME_SUB_BRAND))
                        subBrand = GetBuBrandInfo(ConvertClientValueData, subBrand)

                        ''Sys-ZとSSDは備考欄に固定文言を書込
                        If subBrand = "Sys-z" Then
                            comment = CommentValue
                        Else
                            comment = ""
                        End If

                        copyValue(i, 29) = ""
                        copyValue(i, 30) = comment
                        copyValue(i, 31) = subBrand
                        copyValue(i, 32) = CInt(rows(i).Item(PSEXCEL_CLOUMNMNAME_REFERENCE_ROWCOUNT))
                        copyValue(i, 33) = ""
                        copyValue(i, 34) = ""

                        copyValue(i, 13) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM04)

                    Case "17", "18", "19"
                        copyValue(i, 13) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM04)

                    Case "20"
                        copyValue(i, 13) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM08)
                    Case "23"
                        copyValue(i, 13) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM08)
                    Case "32"
                        copyValue(i, 13) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM08)
                        '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) Start
                    Case "47"
                        copyValue(i, 13) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM08)
                        '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) End
                    Case "25"
                        ''直接入力でかつパターン名称が一致した場合も出力
                        Select Case rows(i).Item(PSEXCEL_CLOUMNMNAME_PATTERN)
                            Case CommonConstant.PATTERNNM_OtherMVMS
                                copyValue(i, 13) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM08)
                            Case CommonConstant.PATTERNNM_MAINTENANCE
                                copyValue(i, 13) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM08)
                            Case CommonConstant.PATTERNNM_FMA
                                copyValue(i, 13) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM08)
                                '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) Start
                            Case CommonConstant.PATTERNNM_MSS
                                copyValue(i, 13) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM08)
                                '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) End
                            Case CommonConstant.PATTERNNM_IBM_HWMA_AAS_BOX,
                                 CommonConstant.PATTERNNM_IBM_HWMA_AAS_MES
                                If newExist = "既存" Then
                                    Const CommentValue As String = "指定機械毎にCostが異なる場合はPaymentに入力して下さい"
                                    Dim comment As String
                                    Dim subBrand As String

                                    ''変換TBL使用後のSUBBrand取得
                                    subBrand = ExcelWrite.changeDBNullToString(rows(i).Item(PSEXCEL_CLOUMNMNAME_SUB_BRAND))
                                    subBrand = GetBuBrandInfo(ConvertClientValueData, subBrand)

                                    ''Sys-ZとSSDは備考欄に固定文言を書込
                                    If subBrand = "Sys-z" Or subBrand = "SSD" Then
                                        comment = CommentValue
                                    Else
                                        comment = ""
                                    End If

                                    copyValue(i, 29) = ""
                                    copyValue(i, 30) = comment
                                    copyValue(i, 31) = subBrand
                                    ''OIOデータ1行に紐づく参考シートの行数をセット
                                    copyValue(i, 32) = CInt(rows(i).Item(PSEXCEL_CLOUMNMNAME_REFERENCE_ROWCOUNT))
                                End If
                            Case Else
                                copyValue(i, 13) = ""
                        End Select
                    Case "34"
                        copyValue(i, 13) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM02)
                    Case "43", "44"
                        copyValue(i, 13) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM04)
                    Case Else
                        copyValue(i, 13) = ""
                End Select
                copyValue(i, 14) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM11)
                copyValue(i, 15) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM12)
                copyValue(i, 16) = rows(i).Item(PSEXCEL_CLOUMNMNAME_QTY)
                copyValue(i, 17) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PAYSTRYM)
                copyValue(i, 18) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PAYENDYM)
                copyValue(i, 19) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PAY_MONTHS)
                copyValue(i, 20) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PAY_METHOD)
                copyValue(i, 21) = rows(i).Item(PSEXCEL_CLOUMNMNAME_LIST_PRICE_REFLESH)
                copyValue(i, 22) = rows(i).Item(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH)
                copyValue(i, 23) = rows(i).Item(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_IOC)
                copyValue(i, 24) = rows(i).Item(PSEXCEL_CLOUMNMNAME_COST_RATE)
                copyValue(i, 25) = rows(i).Item(PSEXCEL_CLOUMNMNAME_COST)
                copyValue(i, 26) = rows(i).Item(PSEXCEL_CLOUMNMNAME_COST_TOTAL)
                copyValue(i, 27) = rows(i).Item(PSEXCEL_CLOUMNMNAME_COST_TOTAL_IOC)
                copyValue(i, 28) = rows(i).Item(PSEXCEL_CLOUMNMNAME_COST_INPUT_DATE)

                ''Template行にExcel式があれば、Template行のExcel式をセットする。
                Call SetTemplateFormula(i, copyValue, formulaObj)

            Next

            ''書式をコピー & ペースト
            Dim copyArea As String = "A" & ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW & ":" & "AI" & ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + rows.Length - 1

            inRange = outSheet.Range("A2:AI2")
            inRange.Copy()
            outRange = outSheet.Range(copyArea)
            outRange.PasteSpecial()

            ''グループ化した列を再表示する
            Select Case patternCD
                Case "20",
                     "23",
                     "32",
                     "47"


                    ''ｻｰﾋﾞｽ提供期間
                    entryRange = outSheet.Range("O2:P2")
                    enColumns = entryRange.EntireColumn
                    enColumns.Hidden = False

                    ''請求開始/終了年月/支払方法			                          
                    entryRange = outSheet.Range("R2:U2")
                    enColumns = entryRange.EntireColumn
                    enColumns.Hidden = False

                    ''Listprice(期間合計)			                          
                    entryRange = outSheet.Range("X2")
                    enColumns = entryRange.EntireColumn
                    enColumns.Hidden = False

                    ''Cost(期間合計)			                          
                    entryRange = outSheet.Range("AB2")
                    enColumns = entryRange.EntireColumn
                    enColumns.Hidden = False

                Case "25"

                    ''直接入力でかつパターン名称が一致した場合も出力
                    Select Case patternNM
                        Case CommonConstant.PATTERNNM_OtherMVMS,
                             CommonConstant.PATTERNNM_MAINTENANCE,
                             CommonConstant.PATTERNNM_FMA,
                            CommonConstant.PATTERNNM_MSS

                            ''ｻｰﾋﾞｽ提供期間
                            entryRange = outSheet.Range("O2:P2")
                            enColumns = entryRange.EntireColumn
                            enColumns.Hidden = False

                            ''請求開始/終了年月/支払方法			                          
                            entryRange = outSheet.Range("R2:U2")
                            enColumns = entryRange.EntireColumn
                            enColumns.Hidden = False

                            ''Listprice(期間合計)	
                            entryRange = outSheet.Range("X2")
                            enColumns = entryRange.EntireColumn
                            enColumns.Hidden = False

                            ''Cost(期間合計)
                            entryRange = outSheet.Range("AB2")
                            enColumns = entryRange.EntireColumn
                            enColumns.Hidden = False

                    End Select
            End Select

            ''値をセット
            outRange.Formula = copyValue

        Catch ex As Exception
            Throw ex

        Finally
            ''オブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(outSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(inRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(outRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(entryRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(enColumns, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Sub

    ''' <summary>
    ''' 機　能：Summaryシートを作成する。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub CopyTopacsSummaryRows(ByRef xlOutBook As Excel.Workbook, _
                                      ByVal rows() As DataRow)


        Dim outSheet As Excel.Worksheet
        Dim inRange As Excel.Range
        Dim outRange As Excel.Range
        Dim entryRange As Excel.Range
        Dim enColumns As Excel.Range
        Try

            'シートのセット
            outSheet = xlOutBook.Worksheets("Summary")

            ''              ▼以下、ヘッダ情報をセット
            ''-----------------------------------------------------
            Const HeadContract As String = "D5"
            Const HeadContractNM As String = "D6"
            Const HeadCreateDay As String = "J3"
            outRange = outSheet.Range(HeadContract)             ''契約順番
            outRange.Value = CommonVariable.CONTRACTNO
            outRange = outSheet.Range(HeadContractNM)           ''契約順番名
            outRange.Value = CommonVariable.CUSTOMERNAME
            outRange = outSheet.Range(HeadCreateDay)            ''作成日
            outRange.Value = Now.ToString("yyyy/MM/dd")


            ''              ▼以下、起票番号/申請番号毎の出力件数を取得
            ''-------------------------------------------------------------------
            Dim distinctKey As String
            Dim distinctChkList As New System.Collections.Generic.Dictionary(Of String, TopacsOutCount)
            Dim tmpValue As TopacsOutCount
            Dim PattenCD As String
            For i As Integer = 0 To rows.Length - 1

                ''パターンCD取得
                PattenCD = ExcelWrite.GetPatternCD(rows(i).Item(PSEXCEL_CLOUMNMNAME_PATTERN_CD), _
                                                   rows(i).Item(PSEXCEL_CLOUMNMNAME_PATTERN))

                ''起票番号/申請番号でKEYを作成
                distinctKey = rows(i).Item(PSEXCEL_CLOUMNMNAME_BRAND_AP_FORM) & "@" & _
                              rows(i).Item(PSEXCEL_CLOUMNMNAME_BRAND_AP_REQ)

                If distinctChkList.ContainsKey(distinctKey) = False Then

                    ''出力件数を初期化                                        
                    tmpValue.AAS_HWCount = 0
                    tmpValue.QCOS_HWCount = 0
                    tmpValue.QCOS_SWCount = 0

                    ''Dictionalyを追加
                    Call distinctChkList.Add(distinctKey, tmpValue)

                Else
                    tmpValue = distinctChkList.Item(distinctKey)
                End If

                ''ﾃﾞｰﾀをAAS/QCOS_HW/QCOS_SWの出力件数をカウントUp
                Select Case PattenCD
                    Case CommonConstant.PATTERNCD_TYPE_IBM_HW_AAS_BOX, _
                         CommonConstant.PATTERNCD_TYPE_IBM_HW_AAS_MES
                        ''AAS/MESは詳細の件数を数える。　　　　　　　　　　　
                        tmpValue.AAS_HWCount = tmpValue.AAS_HWCount + CInt(rows(i).Item(PSEXCEL_CLOUMNMNAME_DetailCount))

                    Case CommonConstant.PATTERNCD_TYPE_IBM_HW_QCOS
                        tmpValue.QCOS_HWCount = tmpValue.QCOS_HWCount + 1

                    Case CommonConstant.PATTERNCD_TYPE_HWBrandSW_QCOS, _
                         CommonConstant.PATTERNCD_TYPE_HWBrandSWMA_QCOS
                        tmpValue.QCOS_SWCount = tmpValue.QCOS_SWCount + 1
                End Select
                distinctChkList.Item(distinctKey) = tmpValue
            Next

            ''              ▼以下、Summaryｼｰﾄ明細書き込み
            ''-------------------------------------------------------------------
            ''対象の出力データを格納
            Dim Index As Integer = -1
            Dim copyValue(distinctChkList.Count, 12) As Object
            Dim tmpKey() As String
            For Each listItem As Generic.KeyValuePair(Of String, TopacsOutCount) In distinctChkList

                Index = Index + 1

                tmpKey = Split(listItem.Key, "@")
                copyValue(Index, 0) = tmpKey(0)            ''※セルの結合
                copyValue(Index, 1) = tmpKey(0)            ''※セルの結合
                copyValue(Index, 2) = tmpKey(1)            ''※セルの結合
                copyValue(Index, 3) = tmpKey(1)            ''※セルの結合
                copyValue(Index, 4) = listItem.Value.AAS_HWCount
                copyValue(Index, 5) = ""
                copyValue(Index, 6) = ""
                copyValue(Index, 7) = listItem.Value.QCOS_HWCount
                copyValue(Index, 8) = ""
                copyValue(Index, 9) = ""
                copyValue(Index, 10) = listItem.Value.QCOS_SWCount
                copyValue(Index, 11) = ""
                copyValue(Index, 12) = ""
            Next

            ''書式をコピー & ペースト
            Dim copyArea As String = "B" & EXCEL_SUMMARYDATE_OUTROW & ":" & "N" & EXCEL_SUMMARYDATE_OUTROW + Index
            inRange = outSheet.Range("B2:N2")
            inRange.Copy()
            outRange = outSheet.Range(copyArea)
            outRange.PasteSpecial()

            ''値をセット
            outRange.Formula = copyValue

            ''書式をコピー & ペースト
            copyArea = "P" & EXCEL_SUMMARYDATE_OUTROW & ":" & "S" & EXCEL_SUMMARYDATE_OUTROW + Index
            inRange = outSheet.Range("P2:S2")
            inRange.Copy()
            outRange = outSheet.Range(copyArea)
            outRange.PasteSpecial()

        Catch ex As Exception
            Throw ex

        Finally
            ''オブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(inRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(outRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(entryRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(enColumns, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(outSheet, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Sub


    ''' <summary>
    ''' 機　能：個別Topacsファイルから価格開示ファイルへ出力対象の行をコピー&ペーストする。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub CopyTopacsPSRows(ByRef xlOutBook As Excel.Workbook, _
                                 ByVal rows() As DataRow)

        Dim outSheet As Excel.Worksheet
        Dim inRange As Excel.Range
        Dim outRange As Excel.Range
        Dim entryRange As Excel.Range
        Dim enColumns As Excel.Range
        Try

            'シートのセット
            outSheet = xlOutBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)

            ''テンプレート行の式をセット
            Dim formulaObj(,) As Object
            inRange = outSheet.Range("A2:N2")
            formulaObj = inRange.FormulaR1C1

            Dim patternCD As String
            Dim patternNM As String
            Dim copyValue(rows.Length, 13) As Object
            For i As Integer = 0 To rows.Length - 1

                ''対象の出力データを格納
                copyValue(i, 0) = rows(i).Item(PSEXCEL_CLOUMNMNAME_LINE_NO)
                copyValue(i, 1) = rows(i).Item(PSEXCEL_CLOUMNMNAME_FILE_NAME)
                copyValue(i, 2) = rows(i).Item(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
                copyValue(i, 3) = rows(i).Item(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
                copyValue(i, 4) = rows(i).Item(PSEXCEL_CLOUMNMNAME_CONTRACTNO)
                copyValue(i, 5) = rows(i).Item(PSEXCEL_CLOUMNMNAME_BRAND_AP_FORM)
                copyValue(i, 6) = rows(i).Item(PSEXCEL_CLOUMNMNAME_BRAND_AP_REQ)
                copyValue(i, 7) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                copyValue(i, 8) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PATTERN)
                copyValue(i, 9) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                copyValue(i, 10) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM02)
                copyValue(i, 11) = rows(i).Item(PSEXCEL_CLOUMNMNAME_QTY)
                copyValue(i, 12) = rows(i).Item(PSEXCEL_CLOUMNMNAME_LIST_PRICE_REFLESH)
                copyValue(i, 13) = rows(i).Item(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH)

                ''Template行にExcel式があれば、Template行のExcel式をセットする。
                Call SetTemplateFormula(i, copyValue, formulaObj)

            Next

            ''書式をコピー & ペースト
            Dim copyArea As String = "A" & ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW & ":" & "N" & ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + rows.Length - 1
            inRange = outSheet.Range("A2:N2")
            inRange.Copy()
            outRange = outSheet.Range(copyArea)
            outRange.PasteSpecial()

            ''値をセット
            outRange.Formula = copyValue

        Catch ex As Exception
            Throw ex

        Finally
            ''オブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(inRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(outRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(entryRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(enColumns, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(outSheet, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Sub

    ''' <summary>
    ''' 機　能：個別詳細ファイルから価格開示ファイルへ出力対象の行をコピー&ペーストする。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub CopyTopacsDetailRows(ByVal xlOutBook As Excel.Workbook, _
                                     ByVal rows() As DataRow, _
                                     ByRef PSDetailDataTable As DataTable)

        Dim outSheet As Excel.Worksheet
        Dim inRange As Excel.Range
        Dim outRange As Excel.Range
        Try

            'シートのセット
            outSheet = xlOutBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)
            Dim copyValue(rows.Length, 16) As Object

            ''テンプレート行の式をセット
            Dim formulaObj(,) As Object                     ''通常行
            Dim formulaSumObj(,) As Object                  ''集計行
            inRange = outSheet.Range("A3:N3")
            formulaObj = inRange.FormulaR1C1
            inRange = outSheet.Range("A2:N2")
            formulaSumObj = inRange.FormulaR1C1

            Dim SLineList As New ArrayList                  ''S行の情報をListでまとめる。
            For i As Integer = 0 To rows.Length - 1

                ''対象のセルへ出力するデータを配列に保存
                copyValue(i, 0) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)
                copyValue(i, 1) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME)
                copyValue(i, 2) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
                copyValue(i, 3) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
                copyValue(i, 4) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_SEQ)
                copyValue(i, 5) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_IDENTITY_FLAG)
                copyValue(i, 6) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_MES_CATEGORY)
                copyValue(i, 7) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_MES_GROUP)
                copyValue(i, 8) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_SPECIAL_FEATURE)
                copyValue(i, 9) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_PROD_NO)
                copyValue(i, 10) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_PROD_NAME)
                copyValue(i, 11) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_QTY_INTEGER)
                copyValue(i, 12) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_LIST_PRICE)
                copyValue(i, 13) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL)

                ''Template行にExcel式があれば、Template行のExcel式をセットする。
                If rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_IDENTITY_FLAG) = "S" Then
                    Call SetSumTemplateFormula(i, copyValue, formulaSumObj, rows, PSDetailDataTable)
                    Call SLineList.Add(i)                   ''S行の位置をセット
                Else
                    Call SetTemplateFormula(i, copyValue, formulaObj)
                End If
            Next

            ''通常行のコピペ   ※グループの設定もコピーしたいので、行を指定。
            Dim copyArea As String = ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW & ":" & ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW + rows.Length
            inRange = outSheet.Rows("3:3")
            inRange.Copy()
            outRange = outSheet.Range(copyArea)
            outRange.PasteSpecial()

            ''S行のコピペ    
            inRange = outSheet.Rows("2:2")
            inRange.Hidden = False
            inRange.Copy()
            For Each SLine As Integer In SLineList
                copyArea = ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW + SLine & ":" & ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW + SLine
                outRange = outSheet.Rows(copyArea)
                outRange.PasteSpecial()
            Next
            inRange.Hidden = True

            ''値のセット
            copyArea = "A" & ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW & ":" & "N" & ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW + rows.Length
            outRange = outSheet.Range(copyArea)
            outRange.Value = copyValue

        Catch ex As Exception
            Throw ex

        Finally
            ''オブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(inRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(outRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(outSheet, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Sub

    ''' <summary>
    ''' 機　能：Template行にExcel式が入力されていれば、セットする。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetSumTemplateFormula(ByVal i As Integer, _
                                      ByRef copyValue(,) As Object, _
                                      ByRef formulaObj(,) As Object, _
                                      ByRef rows() As DataRow, _
                                      ByRef PSDetailDataTable As DataTable)

        ''詳細と一致するPSを取得
        Dim Count As Integer
        Dim filter As New StringBuilder
        filter.Append(PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME)))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)))
        Count = PSDetailDataTable.Select(filter.ToString).Length - 1

        Dim j As Integer
        For j = 1 To UBound(formulaObj, 2)

            If formulaObj(1, j).IndexOf("=") <> -1 Then

                ''Sum式以外
                copyValue(i, j - 1) = formulaObj(1, j)

                ''Sumの式の開始/終了位置をセット
                If formulaObj(1, j).IndexOf("@") Then
                    copyValue(i, j - 1) = formulaObj(1, j).ToString.Replace("@1", ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW + i + 1) _
                                                                   .Replace("@2", ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW + i + Count)
                End If

            End If
        Next

    End Sub


    ''' <summary>
    ''' 機　能：Template行にExcel式が入力されていれば、セットする。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetTemplateFormula(ByVal i As Integer, _
                                   ByRef copyValue(,) As Object, _
                                   ByRef formulaObj(,) As Object)

        Dim j As Integer
        For j = 1 To UBound(formulaObj, 2)

            If formulaObj(1, j).IndexOf("=") <> -1 Then
                copyValue(i, j - 1) = formulaObj(1, j)
            End If

        Next

    End Sub

    ''' <summary>
    ''' 機　能：個別詳細ファイルから価格開示ファイルへ出力対象の行をコピー&ペーストする。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub CopyPSDetailRows(ByVal xlOutBook As Excel.Workbook, _
                                 ByVal rows() As DataRow, _
                                 ByRef PSdetailTable As DataTable)

        Dim outSheet As Excel.Worksheet
        Dim inRange As Excel.Range
        Dim outRange As Excel.Range

        If rows Is Nothing Then
            Exit Sub
        End If

        Try

            'シートのセット
            outSheet = xlOutBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)
            Dim copyValue(rows.Length, 27) As Object

            ''テンプレート行の式をセット
            Dim formulaObj(,) As Object                     ''通常行
            Dim formulaSumObj(,) As Object                  ''集計行
            inRange = outSheet.Range("A3:R3")
            formulaObj = inRange.FormulaR1C1
            inRange = outSheet.Range("A2:R2")
            formulaSumObj = inRange.FormulaR1C1

            Dim SLineList As New ArrayList                  ''S行の情報をListでまとめる。
            For i As Integer = 0 To rows.Length - 1

                ''対象のセルへ出力するデータを配列に保存
                copyValue(i, 0) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)
                copyValue(i, 1) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME)
                copyValue(i, 2) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
                copyValue(i, 3) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
                copyValue(i, 4) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_SEQ)
                copyValue(i, 5) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_IDENTITY_FLAG)
                copyValue(i, 6) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_MES_CATEGORY)
                copyValue(i, 7) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_MES_GROUP)
                copyValue(i, 8) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_SPECIAL_FEATURE)
                copyValue(i, 9) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_PROD_NO)
                copyValue(i, 10) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_PROD_NAME)
                copyValue(i, 11) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_QTY_INTEGER)
                copyValue(i, 12) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_LIST_PRICE)
                copyValue(i, 13) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL)
                copyValue(i, 14) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_COST_RATE)
                copyValue(i, 15) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_COST)
                copyValue(i, 16) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_COST_TOTAL)
                copyValue(i, 17) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_COST_INPUT_DATE)

                If rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_IDENTITY_FLAG) = "S" Then
                    Call SetSumTemplateFormula(i, copyValue, formulaSumObj, rows, PSdetailTable)
                    Call SLineList.Add(i)                   ''S行の位置をセット
                Else
                    Call SetTemplateFormula(i, copyValue, formulaObj)
                End If
            Next

            ''通常行のコピペ   ※グループの設定もコピーしたいので、行を指定。
            Dim copyArea As String = ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW & ":" & ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW + rows.Length
            inRange = outSheet.Rows("3:3")
            inRange.Copy()
            outRange = outSheet.Range(copyArea)
            outRange.PasteSpecial()

            ''S行のコピペ    
            inRange = outSheet.Rows("2:2")
            inRange.Hidden = False
            inRange.Copy()
            For Each SLine As Integer In SLineList
                copyArea = ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW + SLine & ":" & ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW + SLine
                outRange = outSheet.Rows(copyArea)
                outRange.PasteSpecial()
            Next
            inRange.Hidden = True


            copyArea = "A" & ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW & ":" & "R" & ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW + rows.Length
            outRange = outSheet.Range(copyArea)
            outRange.Value = copyValue

        Catch ex As Exception
            Throw ex

        Finally
            ''オブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(outSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(inRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(outRange, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Sub

    ''' <summary>
    ''' 機　能：価格開示ファイル作成完了メッセージの作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateExitMsg(ByVal IsKakakukaijiCreate() As Boolean) As String

        ''初期化
        CreateExitMsg = ""

        CreateExitMsg = "以下のファイルをOutputフォルダに作成しました。"
        For i As Integer = 0 To IsKakakukaijiCreate.Length - 1
            Select Case i
                Case KakakukaijiFile.Topacs
                    If IsKakakukaijiCreate(KakakukaijiFile.Topacs) Then
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 作成完了：" & "Topacs"
                    Else
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 未作成  ：" & "Topacs"
                    End If
                Case KakakukaijiFile.CISCOHW
                    If IsKakakukaijiCreate(KakakukaijiFile.CISCOHW) Then
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 作成完了：" & "CISCOHW"
                    Else
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 未作成  ：" & "CISCOHW"
                    End If
                Case KakakukaijiFile.IASC
                    If IsKakakukaijiCreate(KakakukaijiFile.IASC) Then
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 作成完了：" & "VLS"
                    Else
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 未作成  ：" & "VLS"
                    End If
                Case KakakukaijiFile.AASHWServicepac
                    If IsKakakukaijiCreate(KakakukaijiFile.AASHWServicepac) Then
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 作成完了：" & "AASHWServicepac"
                    Else
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 未作成  ：" & "AASHWServicepac"
                    End If
                Case KakakukaijiFile.QCOSHWServicepac
                    If IsKakakukaijiCreate(KakakukaijiFile.QCOSHWServicepac) Then
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 作成完了：" & "QCOSHWServicepac"
                    Else
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 未作成  ：" & "QCOSHWServicepac"
                    End If
                Case KakakukaijiFile.SWServicepac
                    If IsKakakukaijiCreate(KakakukaijiFile.SWServicepac) Then
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 作成完了：" & "SWServicepac"
                    Else
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 未作成  ：" & "SWServicepac"
                    End If
                Case KakakukaijiFile.AASHWMA
                    If IsKakakukaijiCreate(KakakukaijiFile.AASHWMA) Then
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 作成完了：" & "AASHWMA"
                    Else
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 未作成  ：" & "AASHWMA"
                    End If
                Case KakakukaijiFile.QCOSHWMA
                    If IsKakakukaijiCreate(KakakukaijiFile.QCOSHWMA) Then
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 作成完了：" & "QCOSHWMA"
                    Else
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 未作成  ：" & "QCOSHWMA"
                    End If
                Case KakakukaijiFile.AASWarrantyOption
                    If IsKakakukaijiCreate(KakakukaijiFile.AASWarrantyOption) Then
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 作成完了：" & "AASWarrantyOption"
                    Else
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 未作成  ：" & "AASWarrantyOption"
                    End If
                Case KakakukaijiFile.QCOSWarrantyOption
                    If IsKakakukaijiCreate(KakakukaijiFile.QCOSWarrantyOption) Then
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 作成完了：" & "QCOSWarrantyOption"
                    Else
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 未作成  ：" & "QCOSWarrantyOption"
                    End If
                Case KakakukaijiFile.IGF_USED
                    If IsKakakukaijiCreate(KakakukaijiFile.IGF_USED) Then
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 作成完了：" & "IGF中古"
                    Else
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 未作成  ：" & "IGF中古"
                    End If
                Case KakakukaijiFile.FMA
                    If IsKakakukaijiCreate(KakakukaijiFile.FMA) Then
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 作成完了：" & "FMA"
                    Else
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 未作成  ：" & "FMA"
                    End If
                Case KakakukaijiFile.SystemService
                    If IsKakakukaijiCreate(KakakukaijiFile.SystemService) Then
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 作成完了：" & "ｼｽﾃﾑ･ｻｰﾋﾞｽ"
                    Else
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 未作成  ：" & "ｼｽﾃﾑ･ｻｰﾋﾞｽ"
                    End If
                Case KakakukaijiFile.ISS
                    If IsKakakukaijiCreate(KakakukaijiFile.ISS) Then
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 作成完了：" & "ISS"
                    Else
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 未作成  ：" & "ISS"
                    End If
                    'START 変更管理#39（No.1544 MA復帰料金の統合)　2017/04 sugo
                Case KakakukaijiFile.MAF
                    If IsKakakukaijiCreate(KakakukaijiFile.MAF) Then
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 作成完了：" & "MA復帰料金"
                    Else
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 未作成  ：" & "MA復帰料金"
                    End If
                    'Case KakakukaijiFile.QCOSMAF
                    '    If IsKakakukaijiCreate(KakakukaijiFile.QCOSMAF) Then
                    '        CreateExitMsg = CreateExitMsg & vbCrLf & " 作成完了：" & "QCOSMA復帰料金"
                    '    Else
                    '        CreateExitMsg = CreateExitMsg & vbCrLf & " 未作成  ：" & "QCOSMA復帰料金"
                    '    End If
                    'Case KakakukaijiFile.AASMAF
                    '    If IsKakakukaijiCreate(KakakukaijiFile.AASMAF) Then
                    '        CreateExitMsg = CreateExitMsg & vbCrLf & " 作成完了：" & "AASMA復帰料金"
                    '    Else
                    '        CreateExitMsg = CreateExitMsg & vbCrLf & " 未作成  ：" & "AASMA復帰料金"
                    '    End If
                    'END   変更管理#39（No.1544 MA復帰料金の統合)　2017/04 sugo
                Case KakakukaijiFile.BasicSelection
                    If IsKakakukaijiCreate(KakakukaijiFile.BasicSelection) Then
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 作成完了：" & "ﾍﾞｰｼｯｸ･ｾﾚｸｼｮﾝ"
                    Else
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 未作成  ：" & "ﾍﾞｰｼｯｸ･ｾﾚｸｼｮﾝ"
                    End If
                Case KakakukaijiFile.ServiceIntegrator
                    If IsKakakukaijiCreate(KakakukaijiFile.ServiceIntegrator) Then
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 作成完了：" & "ServiceIntegrator"
                    Else
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 未作成  ：" & "ServiceIntegrator"
                    End If
                Case KakakukaijiFile.ePricer
                    If IsKakakukaijiCreate(KakakukaijiFile.ePricer) Then
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 作成完了：" & "e-Pricer"
                    Else
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 未作成  ：" & "e-Pricer"
                    End If
                    '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) Start
                Case KakakukaijiFile.MSS
                    If IsKakakukaijiCreate(KakakukaijiFile.MSS) Then
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 作成完了：" & "MSS"
                    Else
                        CreateExitMsg = CreateExitMsg & vbCrLf & " 未作成  ：" & "MSS"
                    End If
                    '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) End
            End Select
        Next
    End Function

    ''' <summary>
    ''' 機　能：重複情報を削除した個別PSの値をテーブルへ格納
    ''' 説　明：契約順番、パターンコード、製品番号で重複した値を削除する。
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetDelOverlapPSDataTable(ByVal PSDataTable As DataTable) As DataTable

        ''個別PSTableより、重複行を削除したKEY項目を取得　
        Dim TempKeyDataTable As DataTable
        TempKeyDataTable = DelOverlapKeyPsDataTable(PSDataTable)


        ''KEY項目でSelectし、一番最初に取得したデータを正とする。
        Dim row As DataRow
        Dim rows() As DataRow
        Dim filter As New StringBuilder
        Dim rtnTable As New DataTable
        rtnTable = PSDataTable.Clone
        For Each row In TempKeyDataTable.Rows

            ''抽出条件のセット
            filter.Remove(0, filter.Length)
            filter.Append(PSEXCEL_CLOUMNMNAME_CONTRACTNO)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(row(PSEXCEL_CLOUMNMNAME_CONTRACTNO)))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(row(PSEXCEL_CLOUMNMNAME_PATTERN_CD)))

            ''LockFlg = 作成中、数量プラスのみ出力
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(""))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append(PSEXCEL_CLOUMNMNAME_QTY)
            filter.Append(CommonConstant.SQL_STR_NOT)
            filter.Append(CommonConstant.SQL_STR_LIKE)
            filter.Append(StringEdit.EncloseSingleQuotation("-*"))

            ''コメント行は出力しない。
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
            filter.Append(CommonConstant.SQL_STR_NOT)
            filter.Append(CommonConstant.SQL_STR_IN)
            filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            filter.Append(StringEdit.EncloseSingleQuotation("C"))
            filter.Append(CommonConstant.STR_COMMA)
            filter.Append(StringEdit.EncloseSingleQuotation("N"))
            filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

            ''COST開示 = "Y"のみ
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append(PSEXCEL_CLOUMNMNAME_ST_COST)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation("Y"))

            ''パターンコードに応じて、製品番号の位置が異なる
            ''※現状では、全てのパターンでITEM01が製品番号の予定だが、拡張性確保のため、以下のSelect処理を残す。
            Select Case row(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Case "1"
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                Case "2"
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                Case "3"
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                Case "4"
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                Case "12"
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                Case "13"
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                Case "14"
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                Case "15"
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))

                Case "16"
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                Case "17"
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                Case "18"
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                Case "19"
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                Case "20"
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                Case "23"
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                Case "32"
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(PSEXCEL_CLOUMNMNAME_NEW_EXIST)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(row(PSEXCEL_CLOUMNMNAME_NEW_EXIST)))
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                    'START 変更管理#39（No.1544 MA復帰料金の統合)　2017/04 sugo
                Case "40", "41"
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                    'Case "40"
                    '    filter.Append(CommonConstant.SQL_STR_AND)
                    '    filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                    '    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    '    filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                    'Case "41"
                    '    filter.Append(CommonConstant.SQL_STR_AND)
                    '    filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                    '    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    '    filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                    'END   変更管理#39（No.1544 MA復帰料金の統合)　2017/04 sugo
                Case "43", "44"
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM04)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("SERVICE_KIND"))))
                    '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) Start
                Case "47"
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(PSEXCEL_CLOUMNMNAME_NEW_EXIST)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(row(PSEXCEL_CLOUMNMNAME_NEW_EXIST)))
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                    '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) End
            End Select

            ''直接入力の場合、パターン名称から直接入力変更前のパターンを割り出す。
            If row(PSEXCEL_CLOUMNMNAME_PATTERN_CD) = "25" Then
                filter.Append(CommonConstant.SQL_STR_AND)
                filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN)
                filter.Append(CommonConstant.SQL_STR_EQUAL)
                filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row(PSEXCEL_CLOUMNMNAME_PATTERN))))
                Select Case row(PSEXCEL_CLOUMNMNAME_PATTERN)
                    Case CommonConstant.PATTERNNM_IBM_HW_AAS_BOX
                        filter.Append(CommonConstant.SQL_STR_AND)
                        filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                    Case CommonConstant.PATTERNNM_IBM_HW_AAS_MES
                        filter.Append(CommonConstant.SQL_STR_AND)
                        filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                    Case CommonConstant.PATTERNNM_IBM_HW_QCOS
                        filter.Append(CommonConstant.SQL_STR_AND)
                        filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                    Case CommonConstant.PATTERNNM_HW_CISCO
                        filter.Append(CommonConstant.SQL_STR_AND)
                        filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                    Case CommonConstant.PATTERNNM_VLS
                        filter.Append(CommonConstant.SQL_STR_AND)
                        filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                    Case CommonConstant.PATTERNNM_HWServicePac
                        filter.Append(CommonConstant.SQL_STR_AND)
                        filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                    Case CommonConstant.PATTERNNM_SWServicePac
                        filter.Append(CommonConstant.SQL_STR_AND)
                        filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                    Case CommonConstant.PATTERNNM_IBM_HWMA_AAS_BOX
                        filter.Append(CommonConstant.SQL_STR_AND)
                        filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                    Case CommonConstant.PATTERNNM_IBM_HWMA_AAS_MES
                        filter.Append(CommonConstant.SQL_STR_AND)
                        filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                    Case CommonConstant.PATTERNNM_IBM_HWMA_QCOS
                        filter.Append(CommonConstant.SQL_STR_AND)
                        filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                    Case CommonConstant.PATTERNNM_IBM_HWMA_AAS_WarrantyOP
                        filter.Append(CommonConstant.SQL_STR_AND)
                        filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                    Case CommonConstant.PATTERNNM_IBM_HWMA_QCOS_WarrantyOP
                        filter.Append(CommonConstant.SQL_STR_AND)
                        filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                    Case CommonConstant.PATTERNNM_OtherMVMS
                        filter.Append(CommonConstant.SQL_STR_AND)
                        filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                    Case CommonConstant.PATTERNNM_MAINTENANCE
                        filter.Append(CommonConstant.SQL_STR_AND)
                        filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                    Case CommonConstant.PATTERNNM_FMA
                        filter.Append(CommonConstant.SQL_STR_AND)
                        filter.Append(PSEXCEL_CLOUMNMNAME_NEW_EXIST)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(row(PSEXCEL_CLOUMNMNAME_NEW_EXIST)))
                        filter.Append(CommonConstant.SQL_STR_AND)
                        filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                    Case CommonConstant.PATTERNNM_QCOSMAF
                        filter.Append(CommonConstant.SQL_STR_AND)
                        filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                    Case CommonConstant.PATTERNNM_AASMAF
                        filter.Append(CommonConstant.SQL_STR_AND)
                        filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                    Case CommonConstant.PATTERNNM_BASICSELECTION
                        filter.Append(CommonConstant.SQL_STR_AND)
                        filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                        '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) Start
                    Case CommonConstant.PATTERNNM_MSS
                        filter.Append(CommonConstant.SQL_STR_AND)
                        filter.Append(PSEXCEL_CLOUMNMNAME_NEW_EXIST)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(row(PSEXCEL_CLOUMNMNAME_NEW_EXIST)))
                        filter.Append(CommonConstant.SQL_STR_AND)
                        filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(row("PROD_NO"))))
                        '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) End
                End Select
            End If

            rows = PSDataTable.Select(filter.ToString)
            If rows.Length > 0 Then
                row = rtnTable.NewRow
                row.ItemArray = rows(0).ItemArray

                rtnTable.Rows.Add(row)
            End If
        Next

        Return rtnTable

    End Function


    ''' <summary>
    ''' 機　能：個別PSのKey項目の値をテーブルへ格納する。
    '''　　　　 重複した個別PSのデータを削除する。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function DelOverlapKeyPsDataTable(ByVal PSDataTable As DataTable) As DataTable

        ''データテーブルの作成
        Dim rtnTable As New DataTable
        rtnTable.Columns.Add(PSEXCEL_CLOUMNMNAME_CONTRACTNO)
        rtnTable.Columns.Add(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
        rtnTable.Columns.Add(PSEXCEL_CLOUMNMNAME_PATTERN)
        rtnTable.Columns.Add(PSEXCEL_CLOUMNMNAME_NEW_EXIST)
        rtnTable.Columns.Add("PROD_NO")
        rtnTable.Columns.Add("SERVICE_KIND")

        ''rtnTableに個別PSデータのKey項目のみ値を格納する。
        Dim PSrow As DataRow
        For Each PSrow In PSDataTable.Rows

            Dim rtnTableRow As DataRow
            rtnTableRow = rtnTable.NewRow()
            rtnTableRow(PSEXCEL_CLOUMNMNAME_CONTRACTNO) = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_CONTRACTNO))
            rtnTableRow(PSEXCEL_CLOUMNMNAME_PATTERN_CD) = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PATTERN_CD))
            rtnTableRow(PSEXCEL_CLOUMNMNAME_PATTERN) = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PATTERN))
            rtnTableRow(PSEXCEL_CLOUMNMNAME_NEW_EXIST) = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_NEW_EXIST))

            ''パターンコードに応じて、製品番号の位置が異なる
            ''※現状では、全てのパターンでITEM01が製品番号の予定だが、拡張性確保のため、以下のSelect処理を残す。
            Select Case PSrow(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Case "1"
                    rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                Case "2"
                    rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                Case "3"
                    rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                Case "4"
                    rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                Case "12"
                    rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                Case "13"
                    rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                Case "14"
                    rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                Case "15"
                    rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                Case "16"
                    rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                Case "17"
                    rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                Case "18"
                    rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                Case "19"
                    rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                Case "20"
                    rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                Case "23"
                    rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                Case "32"
                    rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                    rtnTableRow(PSEXCEL_CLOUMNMNAME_NEW_EXIST) = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_NEW_EXIST))
                    'START 変更管理#39（No.1544 MA復帰料金の統合)　2017/04 sugo
                Case "40", "41"
                    rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                    'Case "40"
                    '    rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                    'Case "41"
                    '    rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                    'END   変更管理#39（No.1544 MA復帰料金の統合)　2017/04 sugo
                Case "43", "44"
                    rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                    rtnTableRow("SERVICE_KIND") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM04))
                    '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) Start
                Case "47"
                    rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                    rtnTableRow(PSEXCEL_CLOUMNMNAME_NEW_EXIST) = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_NEW_EXIST))
                    '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) End
            End Select

            ''直接入力の場合、パターン名称に応じて処理を分岐
            ''※直接入力の場合、名称から直接入力へ変更前のパターンを取得する。
            If PSrow(PSEXCEL_CLOUMNMNAME_PATTERN_CD) = "25" Then
                Select Case PSrow(PSEXCEL_CLOUMNMNAME_PATTERN)
                    Case CommonConstant.PATTERNNM_IBM_HW_AAS_BOX
                        rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                        rtnTableRow(PSEXCEL_CLOUMNMNAME_PATTERN) = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PATTERN))
                    Case CommonConstant.PATTERNNM_IBM_HW_AAS_MES
                        rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                        rtnTableRow(PSEXCEL_CLOUMNMNAME_PATTERN) = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PATTERN))
                    Case CommonConstant.PATTERNNM_IBM_HW_QCOS
                        rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                        rtnTableRow(PSEXCEL_CLOUMNMNAME_PATTERN) = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PATTERN))
                    Case CommonConstant.PATTERNNM_HW_CISCO
                        rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                        rtnTableRow(PSEXCEL_CLOUMNMNAME_PATTERN) = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PATTERN))
                    Case CommonConstant.PATTERNNM_VLS
                        rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                        rtnTableRow(PSEXCEL_CLOUMNMNAME_PATTERN) = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PATTERN))
                    Case CommonConstant.PATTERNNM_HWServicePac
                        rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                        rtnTableRow(PSEXCEL_CLOUMNMNAME_PATTERN) = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PATTERN))
                    Case CommonConstant.PATTERNNM_SWServicePac
                        rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                        rtnTableRow(PSEXCEL_CLOUMNMNAME_PATTERN) = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PATTERN))
                    Case CommonConstant.PATTERNNM_IBM_HWMA_AAS_BOX
                        rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                        rtnTableRow(PSEXCEL_CLOUMNMNAME_PATTERN) = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PATTERN))
                    Case CommonConstant.PATTERNNM_IBM_HWMA_AAS_MES
                        rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                        rtnTableRow(PSEXCEL_CLOUMNMNAME_PATTERN) = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PATTERN))
                    Case CommonConstant.PATTERNNM_IBM_HWMA_QCOS
                        rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                        rtnTableRow(PSEXCEL_CLOUMNMNAME_PATTERN) = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PATTERN))
                    Case CommonConstant.PATTERNNM_IBM_HWMA_AAS_WarrantyOP
                        rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                        rtnTableRow(PSEXCEL_CLOUMNMNAME_PATTERN) = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PATTERN))
                    Case CommonConstant.PATTERNNM_IBM_HWMA_QCOS_WarrantyOP
                        rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                        rtnTableRow(PSEXCEL_CLOUMNMNAME_PATTERN) = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PATTERN))
                    Case CommonConstant.PATTERNNM_OtherMVMS
                        rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                        rtnTableRow(PSEXCEL_CLOUMNMNAME_PATTERN) = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PATTERN))
                    Case CommonConstant.PATTERNNM_MAINTENANCE
                        rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                        rtnTableRow(PSEXCEL_CLOUMNMNAME_PATTERN) = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PATTERN))
                    Case CommonConstant.PATTERNNM_FMA
                        rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                        rtnTableRow(PSEXCEL_CLOUMNMNAME_NEW_EXIST) = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_NEW_EXIST))
                        rtnTableRow(PSEXCEL_CLOUMNMNAME_PATTERN) = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PATTERN))
                    Case CommonConstant.PATTERNNM_QCOSMAF
                        rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                        rtnTableRow(PSEXCEL_CLOUMNMNAME_PATTERN) = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PATTERN))
                    Case CommonConstant.PATTERNNM_AASMAF
                        rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                        rtnTableRow(PSEXCEL_CLOUMNMNAME_PATTERN) = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PATTERN))
                    Case CommonConstant.PATTERNNM_BASICSELECTION
                        rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                        rtnTableRow(PSEXCEL_CLOUMNMNAME_PATTERN) = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PATTERN))
                        '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) Start
                    Case CommonConstant.PATTERNNM_MSS
                        rtnTableRow("PROD_NO") = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))
                        rtnTableRow(PSEXCEL_CLOUMNMNAME_NEW_EXIST) = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_NEW_EXIST))
                        rtnTableRow(PSEXCEL_CLOUMNMNAME_PATTERN) = ChangeNothingToBrank(PSrow(PSEXCEL_CLOUMNMNAME_PATTERN))
                        '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) End
                    Case Else
                        ''パターン名称が一致しない直接入力は、Cost開示ファイルに出力しない。
                        Continue For
                End Select
            End If

            ''既に元のパターン名称で重複するデータがあれば追加しない。
            Dim filter As New StringBuilder
            Select Case PSrow(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                Case "43", "44"
                    filter.Append(PSEXCEL_CLOUMNMNAME_CONTRACTNO)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(rtnTableRow(PSEXCEL_CLOUMNMNAME_CONTRACTNO)))
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(rtnTableRow(PSEXCEL_CLOUMNMNAME_PATTERN_CD)))
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(rtnTableRow(PSEXCEL_CLOUMNMNAME_PATTERN)))
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append("PROD_NO")
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(rtnTableRow("PROD_NO"))))
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append("SERVICE_KIND")
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(rtnTableRow("SERVICE_KIND"))))
                Case Else
                    filter.Append(PSEXCEL_CLOUMNMNAME_CONTRACTNO)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(rtnTableRow(PSEXCEL_CLOUMNMNAME_CONTRACTNO)))
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(rtnTableRow(PSEXCEL_CLOUMNMNAME_PATTERN_CD)))
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(rtnTableRow(PSEXCEL_CLOUMNMNAME_PATTERN)))
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append("PROD_NO")
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(rtnTableRow("PROD_NO"))))
            End Select
            If rtnTable.Select(filter.ToString).Length > 0 Then
                Continue For
            End If

            ''数量マイナスは追加しない
            If IsNumeric(PSrow(PSEXCEL_CLOUMNMNAME_QTY)) = True Then
                If CDbl(PSrow(PSEXCEL_CLOUMNMNAME_QTY)) < 0 Then
                    Continue For
                End If
            End If

            ''作成中以外は出力しない。
            If ExcelWrite.changeDBNullToString(PSrow(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)) <> "" Then
                Continue For
            End If
            rtnTable.Rows.Add(rtnTableRow)
        Next

        ''rtnTableから、重複行を削除する
        ''※重複削除に、DataViewのToTableメソッドを使用
        Dim TempDataView As DataView
        TempDataView = rtnTable.DefaultView
        rtnTable = TempDataView.ToTable("KeyPSData", True, PSEXCEL_CLOUMNMNAME_CONTRACTNO, PSEXCEL_CLOUMNMNAME_PATTERN_CD, PSEXCEL_CLOUMNMNAME_PATTERN, PSEXCEL_CLOUMNMNAME_NEW_EXIST, "PROD_NO", "SERVICE_KIND")

        Return rtnTable

    End Function

    ''' <summary>
    ''' 機　能：Cost開示ファイルの情報をデータテーブルへ格納する
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetPSCostKaijiData(ByRef CostBook As Excel.Workbook) As DataTable
 
        Dim xlSheet As Excel.Worksheet
        Dim xlrange As Excel.Range
        Dim xlObj(,) As Object

        Try
            ''EOF行の判定
            Dim EofLine As Integer
            EofLine = GetCostPSEofLine(CostBook)

            ''データが存在しない場合、処理を抜ける
            If EofLine = -1 Then
                Exit Function
            End If

            ''Cost開示データを配列に格納
            Dim rangeArea As String
            rangeArea = "A" & ExcelWrite.EXCEL_COST_PAYMENT_OUTROW & ":" & "AC" & ExcelWrite.EXCEL_COST_PAYMENT_OUTROW + EofLine
            xlSheet = CostBook.Worksheets(ExcelWrite.EXCEL_COSTDATE_PSSHEET)
            xlrange = xlSheet.Range(rangeArea)
            xlObj = xlrange.Value

            ''Excelの値をデータテーブルへ格納
            Dim rtnDataTable As DataTable
            If CostBook.Name.IndexOf("CISCOHW") = -1 Then
                rtnDataTable = GetCostKaijiDataTable(xlObj)
            Else
                'CISCO HW用読込
                rtnDataTable = GetCostKaijiDataTable2(xlObj)
            End If

            Return rtnDataTable

        Catch ex As Exception
            Throw ex
        Finally
            ''Excelオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlObj, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlrange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()

        End Try

    End Function


    ''' <summary>
    ''' 機　能：Cost開示ファイルの参照シート情報をデータテーブルへ格納する
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetPSCostRefData(ByRef CostBook As Excel.Workbook) As DataTable

        ''初期化
        GetPSCostRefData = Nothing

        Dim xlSheet As Excel.Worksheet
        Dim xlrange As Excel.Range
        Dim xlObj(,) As Object

        Try
            ''参考シートの存在チェック
            Dim isSheetExist As Boolean = False
            isSheetExist = isResSheetExist(CostBook)
            If isSheetExist = False Then
                Exit Function
            End If

            ''EOF行の判定
            Dim EofLine As Integer
            EofLine = GetCostDefEofLine(CostBook)

            ''データが存在しない場合、処理を抜ける
            If EofLine = -1 Then
                Exit Function
            End If

            ''Cost開示データを配列に格納
            Dim rangeArea As String
            rangeArea = "A" & ExcelWrite.EXCEL_COST_REF_OUTROW & ":" & "AB" & ExcelWrite.EXCEL_COST_REF_OUTROW + EofLine
            xlSheet = CostBook.Worksheets(ExcelWrite.EXCEL_COSTDATE_REFSHEET)

            xlrange = xlSheet.Range(rangeArea)
            xlObj = xlrange.Value

            ''Excelの値をデータテーブルへ格納
            Dim rtnDataTable As DataTable
            rtnDataTable = GetCostRefDataTable(xlObj)

            Return rtnDataTable
        Catch ex As Exception
            Throw ex

        Finally
            ''Excelオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlObj, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlrange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()

        End Try

    End Function


    ''' <summary>
    ''' COST開示ファイル個別PSシートのEOF行の判定
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetCostPSEofLine(ByVal costBook As Excel.Workbook) As Integer

        ''初期化
        GetCostPSEofLine = -1

        Dim xlSheet As Excel.Worksheet
        Dim xlRan As Excel.Range
        Try
            ''Eof行の判定
            Dim rtnEofLine As Integer = -1
            Dim isOIOSheet As Boolean = False
            For Each xlSheet In costBook.Worksheets
                If xlSheet.Name = ExcelWrite.EXCEL_COSTDATE_PSSHEET Then
                    isOIOSheet = True
                    Exit For
                End If
            Next
            If isOIOSheet = False Then
                Exit Function
            End If

            For i As Integer = ExcelWrite.EXCEL_COST_PAYMENT_OUTROW To EXCEL_MAX_ROW

                ''行番 = Nullの場合、EOFと判定
                xlRan = xlSheet.Cells(i, COLCOSTPS_LINE_NO)

                '※EOFの条件の書き方を他のモジュールに合わせる。
                If ExcelWrite.changeDBNullToString(xlRan.Value) = "" Then
                    Exit For
                End If
                rtnEofLine = rtnEofLine + 1

            Next

            Return rtnEofLine

        Catch ex As Exception
            Throw ex

        Finally
            ''Excelオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlRan, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Function


    ''' <summary>
    ''' COST開示ファイル参考シートのEOF行の判定
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetCostDefEofLine(ByVal costBook As Excel.Workbook) As Integer

        ''初期化
        GetCostDefEofLine = -1

        Dim xlSheet As Excel.Worksheet
        Dim xlRan As Excel.Range
        Try
            ''Eof行の判定
            Dim rtnEofLine As Integer = -1
            xlSheet = costBook.Worksheets(ExcelWrite.EXCEL_COSTDATE_REFSHEET)
            For i As Integer = ExcelWrite.EXCEL_COST_REF_OUTROW To EXCEL_MAX_ROW

                ''行番 = Nullの場合、EOFと判定
                xlRan = xlSheet.Cells(i, COLCOSTPS_LINE_NO)
                If IsNothing(xlRan.Value) = True Then
                    Exit For
                End If

                rtnEofLine = rtnEofLine + 1

            Next

            Return rtnEofLine

        Catch ex As Exception
            Throw ex

        Finally
            ''Excelオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlRan, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Function

    ''' <summary>
    ''' 機　能：Cost開示ファイルの配列情報をデータテーブルへ格納する
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetCostKaijiDataTable(ByVal Obj(,) As Object) As DataTable

        ''データテーブルの定義
        Dim rtnDataTable As New DataTable

        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_LINE_NO)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_CONTRACTNO)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_NEW_EXIST)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_PATTERN_CD)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_PATTERN_NM)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM01)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM02)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM04)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_QTY)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_LIST_PRICE_REFLESH)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_COST_RATE)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_COST)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_EXCELROW)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_NGREASON)


        ''Excelの値をデータテーブルへセット
        Dim row As DataRow
        For i As Integer = 1 To Obj.GetLength(0)

            row = rtnDataTable.NewRow
            row(COSTPSEXCEL_CLOUMNMNAME_EXCELROW) = i

            row(COSTPSEXCEL_CLOUMNMNAME_LINE_NO) = ChangeNothingToBrank(Obj(i, COLCOSTPS_LINE_NO))
            row(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME) = ChangeNothingToBrank(Obj(i, COLCOSTPS_FILE_NAME))
            row(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX) = ChangeNothingToBrank(Obj(i, COLCOSTPS_FILE_NAME_SUFFIX))
            row(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR) = ChangeNothingToBrank(Obj(i, COLCOSTPS_FILE_NAME_SUFFIX_INTR))
            row(COSTPSEXCEL_CLOUMNMNAME_CONTRACTNO) = ChangeNothingToBrank(Obj(i, COLCOSTPS_CONTRACTNO))
            row(COSTPSEXCEL_CLOUMNMNAME_NEW_EXIST) = ChangeNothingToBrank(Obj(i, COLCOSTPS_NEW_EXIST))
            row(COSTPSEXCEL_CLOUMNMNAME_PATTERN_CD) = ChangeNothingToBrank(Obj(i, COLCOSTPS_PATTERN_CD))
            row(COSTPSEXCEL_CLOUMNMNAME_PATTERN_NM) = ChangeNothingToBrank(Obj(i, COLCOSTPS_PATTERN_NM))
            row(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM01) = ChangeNothingToBrank(Obj(i, COLCOSTPS_PROD_ITEM01))
            row(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM02) = ChangeNothingToBrank(Obj(i, COLCOSTPS_PROD_ITEM02))
            row(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM04) = ChangeNothingToBrank(Obj(i, COLCOSTPS_PROD_ITEM03))
            row(COSTPSEXCEL_CLOUMNMNAME_QTY) = ChangeNothingToBrank(Obj(i, COLCOSTPS_QTY))
            row(COSTPSEXCEL_CLOUMNMNAME_LIST_PRICE_REFLESH) = ChangeNothingToBrank(Obj(i, COLCOSTPS_LIST_PRICE_REFLESH))
            row(COSTPSEXCEL_CLOUMNMNAME_COST_RATE) = ChangeNothingToBrank(Obj(i, COLCOSTPS_COST_RATE))
            row(COSTPSEXCEL_CLOUMNMNAME_COST) = ChangeNothingToBrank(Obj(i, COLCOSTPS_COST))
            row(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = ""
            rtnDataTable.Rows.Add(row)
        Next

        Return rtnDataTable

    End Function

    ''' <summary>
    ''' 機　能：Cost開示ファイルの情報をデータテーブルへ格納する
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetDetailCostKaijiData(ByRef CostBook As Excel.Workbook) As DataTable

        Dim xlSheet As Excel.Worksheet
        Dim xlrange As Excel.Range
        Dim xlObj(,) As Object

        Try
            ''PaymentLineDetailシートが存在するかどうか？
            Dim isExistDetailSheet As Boolean = False
            For i As Integer = 1 To CostBook.Worksheets.Count
                xlSheet = CostBook.Worksheets(i)
                If xlSheet.Name = ExcelWrite.EXCEL_COSTDATE_DETAILSHEET Then
                    isExistDetailSheet = True
                End If
            Next
            If isExistDetailSheet = False Then
                Exit Function
            End If

            ''EOF行の判定
            Dim EofLine As Integer
            EofLine = GetCostDetailEofLine(CostBook)

            ''対象のデータが存在しない場合、処理を抜ける。
            If EofLine = -1 Then
                Exit Function
            End If

            ''Cost開示データを配列に格納
            Dim rangeArea As String
            rangeArea = "A" & ExcelWrite.EXCEL_COST_DETAIL_OUTROW & ":" & "R" & ExcelWrite.EXCEL_COST_DETAIL_OUTROW + EofLine
            xlSheet = CostBook.Worksheets(ExcelWrite.EXCEL_COSTDATE_DETAILSHEET)
            xlrange = xlSheet.Range(rangeArea)
            xlObj = xlrange.Value

            ''Excelの値をデータテーブルへ格納
            Dim rtnDataTable As DataTable
            If CostBook.Name.IndexOf("CISCOHW") = -1 Then
                rtnDataTable = GetCostKaijiDetailDataTable(xlObj)
            Else
                rtnDataTable = GetCostKaijiDetailDataTable2(xlObj)
            End If

            Return rtnDataTable

        Catch ex As Exception
            Throw ex

        Finally

            ''Excelオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlObj, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlrange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()

        End Try

    End Function


    ''' <summary>
    ''' COST開示ファイル個別詳細シートのEOF行の判定
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetCostDetailEofLine(ByVal costBook As Excel.Workbook) As Integer

        ''初期化
        GetCostDetailEofLine = -1

        Dim xlSheet As Excel.Worksheet
        Dim xlRan As Excel.Range
        Try
            ''Eof行の判定
            Dim rtnEofLine As Integer = -1
            xlSheet = costBook.Worksheets(ExcelWrite.EXCEL_COSTDATE_DETAILSHEET)
            For i As Integer = ExcelWrite.EXCEL_COST_DETAIL_OUTROW To EXCEL_MAX_ROW

                ''ファイル名、ﾌｧｲﾙ名Suffix、ﾌｧｲﾙ内Suffix、全てがNullの場合、EOFと判定
                xlRan = xlSheet.Range(i & ":" & i)
                If costBook.Name.IndexOf("CISCOHW") = -1 Then
                    If xlRan(1, COLCOSTDETEIL_FILE_NAME).value = "" And _
                       (ExcelWrite.changeDBNullToString(xlRan(1, COLCOSTDETEIL_FILE_NAME_SUFFIX).value).ToString = "0" Or _
                        ExcelWrite.changeDBNullToString(xlRan(1, COLCOSTDETEIL_FILE_NAME_SUFFIX).value).ToString = "") And _
                       (ExcelWrite.changeDBNullToString(xlRan(1, COLCOSTDETEIL_FILE_NAME_SUFFIX_INTR).value).ToString = "0" Or _
                        ExcelWrite.changeDBNullToString(xlRan(1, COLCOSTDETEIL_FILE_NAME_SUFFIX_INTR).value).ToString = "") Then
                        Exit For
                    End If

                    rtnEofLine = rtnEofLine + 1
                Else
                    If xlRan(1, COLCISCODETAIL_FILE_NAME).value = "" And _
                       (ExcelWrite.changeDBNullToString(xlRan(1, COLCISCODETAIL_FILE_NAME_SUFFIX).value).ToString = "0" Or _
                        ExcelWrite.changeDBNullToString(xlRan(1, COLCISCODETAIL_FILE_NAME_SUFFIX).value).ToString = "") And _
                       (ExcelWrite.changeDBNullToString(xlRan(1, COLCISCODETAIL_FILE_NAME_SUFFIX_INTR).value).ToString = "0" Or _
                        ExcelWrite.changeDBNullToString(xlRan(1, COLCISCODETAIL_FILE_NAME_SUFFIX_INTR).value).ToString = "") Then
                        Exit For
                    End If

                    rtnEofLine = rtnEofLine + 1
                End If
            Next

            Return rtnEofLine

        Catch ex As Exception
            Throw ex

        Finally
            ''Excelオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlRan, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Function

    ''' <summary>
    ''' 機　能：Cost開示ファイルの配列情報をデータテーブルへ格納する
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetCostKaijiDetailDataTable(ByVal Obj(,) As Object) As DataTable

        ''データテーブルの定義
        Dim rtnDataTable As New DataTable

        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_FILE_NAME)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_SEQ)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_IDENTITY_FLAG)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_PROD_NO)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_PROD_NAME)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_MES_CATEGORY)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_SPECIAL_FEATURE)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_QTY_INTEGER)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_LIST_PRICE)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_COST_RATE)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_COST)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_COST_TOTAL)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_EXCELROW)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_NGREASON)

        ''Excelの値をデータテーブルへセット
        Dim row As DataRow
        For i As Integer = 1 To Obj.GetLength(0)

            row = rtnDataTable.NewRow
            row(COSTDETAILEXCEL_CLOUMNMNAME_EXCELROW) = i

            row(COSTDETAILEXCEL_CLOUMNMNAME_CONTRACTNO) = ChangeNothingToBrank(Obj(i, COLCOSTDETEIL_CONTRACTNO))
            row(COSTDETAILEXCEL_CLOUMNMNAME_FILE_NAME) = ChangeNothingToBrank(Obj(i, COLCOSTDETEIL_FILE_NAME))
            row(COSTDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX) = ChangeNothingToBrank(Obj(i, COLCOSTDETEIL_FILE_NAME_SUFFIX))
            row(COSTDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR) = ChangeNothingToBrank(Obj(i, COLCOSTDETEIL_FILE_NAME_SUFFIX_INTR))
            row(COSTDETAILEXCEL_CLOUMNMNAME_SEQ) = ChangeNothingToBrank(Obj(i, COLCOSTDETEIL_SEQ))
            row(COSTDETAILEXCEL_CLOUMNMNAME_IDENTITY_FLAG) = ChangeNothingToBrank(Obj(i, COLCOSTDETEIL_IDENTITY_FLAG))
            row(COSTDETAILEXCEL_CLOUMNMNAME_PROD_NO) = ChangeNothingToBrank(Obj(i, COLCOSTDETEIL_PROD_NO))
            row(COSTDETAILEXCEL_CLOUMNMNAME_PROD_NAME) = ChangeNothingToBrank(Obj(i, COLCOSTDETEIL_PROD_NAME))
            row(COSTDETAILEXCEL_CLOUMNMNAME_MES_CATEGORY) = ChangeNothingToBrank(Obj(i, COLCOSTDETEIL_MES_CATEGORY))
            row(COSTDETAILEXCEL_CLOUMNMNAME_SPECIAL_FEATURE) = ChangeNothingToBrank(Obj(i, COLCOSTDETEIL_SPECIAL_FEATURE))
            row(COSTDETAILEXCEL_CLOUMNMNAME_QTY_INTEGER) = ChangeNothingToBrank(Obj(i, COLCOSTDETEIL_QTY_INTEGER))
            row(COSTDETAILEXCEL_CLOUMNMNAME_LIST_PRICE) = ChangeNothingToBrank(Obj(i, COLCOSTDETEIL_LIST_PRICE))
            row(COSTDETAILEXCEL_CLOUMNMNAME_COST_RATE) = ChangeNothingToBrank(Obj(i, COLCOSTDETEIL_COST_RATE))
            row(COSTDETAILEXCEL_CLOUMNMNAME_COST) = ChangeNothingToBrank(Obj(i, COLCOSTDETEIL_COST))
            row(COSTDETAILEXCEL_CLOUMNMNAME_COST_TOTAL) = ChangeNothingToBrank(Obj(i, COLCOSTDETEIL_COST_TOTAL))
            row(COSTDETAILEXCEL_CLOUMNMNAME_NGREASON) = ""

            rtnDataTable.Rows.Add(row)
        Next

        Return rtnDataTable

    End Function

    ''' <summary>
    ''' 機　能：Cost開示対象のデータかどうか判定し、パターンコードを返す。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetCostFileType(ByVal CostKaijiPSSheetData As DataTable,
                                ByRef fileType As String,
                                ByRef newExist As String, _
                                ByRef TopacsTBL() As DataTable)


        ''Cost開示ファイルのパターンコードを1件取得
        Dim firstPatternCD As String
        Dim firstPatternNM As String
        Dim firstNewExist As String

        'データが存在しない場合
        Select Case fileType
            Case "Topacs",
                 "e-Pricer"
                'Topacsまたはe-Pricerの場合、処理を抜ける
                Exit Sub
            Case Else
                '初期化
                fileType = COSTFILE_FILETYPE_NONE
        End Select
        ' ''データが存在しない場合

        If IsNothing(CostKaijiPSSheetData) = True OrElse _
           CostKaijiPSSheetData.Rows.Count = 0 Then
            Exit Sub
        End If
        Dim rows() As DataRow
        rows = CostKaijiPSSheetData.Select

        firstPatternCD = rows(0).Item(COSTPSEXCEL_CLOUMNMNAME_PATTERN_CD)
        firstPatternNM = rows(0).Item(COSTPSEXCEL_CLOUMNMNAME_PATTERN_NM)
        firstNewExist = rows(0).Item(COSTPSEXCEL_CLOUMNMNAME_NEW_EXIST)

        ''パターンコードの異なるデータが存在するかどうか？
        Dim filter As New StringBuilder
        Select Case firstPatternCD
            Case "15", "16"
                filter.Append(COSTPSEXCEL_CLOUMNMNAME_PATTERN_CD)
                filter.Append(CommonConstant.SQL_STR_NOT)
                filter.Append(" IN ")
                filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                filter.Append(StringEdit.EncloseSingleQuotation("15"))
                filter.Append(CommonConstant.STR_COMMA)
                filter.Append(StringEdit.EncloseSingleQuotation("16"))
                filter.Append(CommonConstant.STR_COMMA)
                filter.Append(StringEdit.EncloseSingleQuotation("25"))
                filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
            Case "17"
                filter.Append(COSTPSEXCEL_CLOUMNMNAME_PATTERN_CD)
                filter.Append(CommonConstant.SQL_STR_NOT)
                filter.Append(" IN ")
                filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                filter.Append(StringEdit.EncloseSingleQuotation("17"))
                filter.Append(CommonConstant.STR_COMMA)
                filter.Append(StringEdit.EncloseSingleQuotation("25"))
                filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
            Case "25"
                ''直接入力の場合、パターンコードで処理が分岐
                Select Case firstPatternNM
                    Case CommonConstant.PATTERNNM_IBM_HW_AAS_BOX,
                         CommonConstant.PATTERNNM_IBM_HW_AAS_MES
                        filter.Append(COSTPSEXCEL_CLOUMNMNAME_PATTERN_NM)
                        filter.Append(CommonConstant.SQL_STR_NOT)
                        filter.Append(" IN ")
                        filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                        filter.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_IBM_HW_AAS_BOX))
                        filter.Append(CommonConstant.STR_COMMA)
                        filter.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_IBM_HW_AAS_MES))
                        filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                    Case CommonConstant.PATTERNNM_IBM_HW_QCOS,
                         CommonConstant.PATTERNNM_HWBrandSW_QCOS,
                         CommonConstant.PATTERNNM_HWBrandSWMA_QCOS
                        filter.Append(COSTPSEXCEL_CLOUMNMNAME_PATTERN_NM)
                        filter.Append(CommonConstant.SQL_STR_NOT)
                        filter.Append(" IN ")
                        filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                        filter.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_IBM_HW_QCOS))
                        filter.Append(CommonConstant.STR_COMMA)
                        filter.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_HWBrandSW_QCOS))
                        filter.Append(CommonConstant.STR_COMMA)
                        filter.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_HWBrandSWMA_QCOS))
                        filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                    Case CommonConstant.PATTERNNM_IBM_HWMA_AAS_BOX,
                         CommonConstant.PATTERNNM_IBM_HWMA_AAS_MES
                        filter.Append(COSTPSEXCEL_CLOUMNMNAME_PATTERN_NM)
                        filter.Append(CommonConstant.SQL_STR_NOT)
                        filter.Append(" IN ")
                        filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                        filter.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_IBM_HWMA_AAS_BOX))
                        filter.Append(CommonConstant.STR_COMMA)
                        filter.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_IBM_HWMA_AAS_MES))
                        filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                    Case CommonConstant.PATTERNNM_IBM_HWMA_QCOS
                        filter.Append(COSTPSEXCEL_CLOUMNMNAME_PATTERN_NM)
                        filter.Append(CommonConstant.SQL_STR_NOT_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(firstPatternNM))
                        filter.Append(CommonConstant.SQL_STR_AND)
                        filter.Append(COSTPSEXCEL_CLOUMNMNAME_NEW_EXIST)
                        filter.Append(CommonConstant.SQL_STR_NOT_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(firstNewExist))
                    Case Else
                        filter.Append(COSTPSEXCEL_CLOUMNMNAME_PATTERN_NM)
                        filter.Append(CommonConstant.SQL_STR_NOT_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(firstPatternNM))
                End Select
                'START 変更管理#39（No.1544 MA復帰料金の統合)　2017/04 sugo
            Case "40", "41"
                filter.Append(COSTPSEXCEL_CLOUMNMNAME_PATTERN_CD)
                filter.Append(CommonConstant.SQL_STR_NOT)
                filter.Append(" IN ")
                filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                filter.Append(StringEdit.EncloseSingleQuotation("40"))
                filter.Append(CommonConstant.STR_COMMA)
                filter.Append(StringEdit.EncloseSingleQuotation("41"))
                filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                'END   変更管理#39（No.1544 MA復帰料金の統合)　2017/04 sugo
            Case "43", "44"
                filter.Append(COSTPSEXCEL_CLOUMNMNAME_PATTERN_CD)
                filter.Append(CommonConstant.SQL_STR_NOT)
                filter.Append(" IN ")
                filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                filter.Append(StringEdit.EncloseSingleQuotation("43"))
                filter.Append(CommonConstant.STR_COMMA)
                filter.Append(StringEdit.EncloseSingleQuotation("44"))
                filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
            Case "1"
                ''ServiceIntegrator
                filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                filter.Append(COSTPSEXCEL_CLOUMNMNAME_PATTERN_CD)
                filter.Append(CommonConstant.SQL_STR_NOT_EQUAL)
                filter.Append(StringEdit.EncloseSingleQuotation(firstPatternCD))
                filter.Append(CommonConstant.SQL_STR_AND)
                filter.Append(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                filter.Append(CommonConstant.SQL_STR_LIKE)
                filter.Append(StringEdit.EncloseSingleQuotation("666%"))
                filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
            Case Else
                filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                filter.Append(COSTPSEXCEL_CLOUMNMNAME_PATTERN_CD)
                filter.Append(CommonConstant.SQL_STR_NOT_EQUAL)
                filter.Append(StringEdit.EncloseSingleQuotation(firstPatternCD))
                filter.Append(CommonConstant.SQL_STR_AND)
                filter.Append(COSTPSEXCEL_CLOUMNMNAME_PATTERN_CD)
                filter.Append(CommonConstant.SQL_STR_NOT_EQUAL)
                filter.Append(StringEdit.EncloseSingleQuotation("25"))
                filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
        End Select

        ''異なるデータが存在する場合、対象外とする
        rows = CostKaijiPSSheetData.Select(filter.ToString)
        If rows.Length > 0 Then
            Exit Sub
        End If

        ''パターンCDが直接入力の場合、パターン名称から処理を分岐
        If firstPatternCD = "25" Then
            Select Case firstPatternNM
                Case CommonConstant.PATTERNNM_INPUTORDER
                    fileType = CommonConstant.PATTERNCD_TYPE_INPUTORDER
                Case CommonConstant.PATTERNNM_IBM_HW_AAS_BOX
                    fileType = CommonConstant.PATTERNCD_TYPE_IBM_HW_AAS_BOX
                Case CommonConstant.PATTERNNM_IBM_HW_AAS_MES
                    fileType = CommonConstant.PATTERNCD_TYPE_IBM_HW_AAS_MES
                Case CommonConstant.PATTERNNM_IBM_HW_QCOS
                    fileType = CommonConstant.PATTERNCD_TYPE_IBM_HW_QCOS
                Case CommonConstant.PATTERNNM_HW_CISCO
                    fileType = CommonConstant.PATTERNCD_TYPE_HW_CISCO
                Case CommonConstant.PATTERNNM_HWBrandSW_AAS
                    fileType = CommonConstant.PATTERNCD_TYPE_HWBrandSW_AAS
                Case CommonConstant.PATTERNNM_HWBrandSW_QCOS
                    fileType = CommonConstant.PATTERNCD_TYPE_HWBrandSW_QCOS
                Case CommonConstant.PATTERNNM_HWBrandSWMA_AAS
                    fileType = CommonConstant.PATTERNCD_TYPE_HWBrandSWMA_AAS
                Case CommonConstant.PATTERNNM_HWBrandSWMA_QCOS
                    fileType = CommonConstant.PATTERNCD_TYPE_HWBrandSWMA_QCOS
                Case CommonConstant.PATTERNNM_SWBrandSW
                    fileType = CommonConstant.PATTERNCD_TYPE_SWBrandSW
                Case CommonConstant.PATTERNNM_SWBrandSWMA
                    fileType = CommonConstant.PATTERNCD_TYPE_SWBrandSWMA
                Case CommonConstant.PATTERNNM_PA
                    fileType = CommonConstant.PATTERNCD_TYPE_PA
                Case CommonConstant.PATTERNNM_VLS
                    fileType = CommonConstant.PATTERNCD_TYPE_VLS
                Case CommonConstant.PATTERNNM_HWServicePac
                    fileType = CommonConstant.PATTERNCD_TYPE_HWServicePac
                Case CommonConstant.PATTERNNM_SWServicePac
                    fileType = CommonConstant.PATTERNCD_TYPE_SWServicePac
                Case CommonConstant.PATTERNNM_IBM_HWMA_AAS_BOX
                    fileType = CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_BOX
                Case CommonConstant.PATTERNNM_IBM_HWMA_AAS_MES
                    fileType = CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_MES
                Case CommonConstant.PATTERNNM_IBM_HWMA_QCOS
                    fileType = CommonConstant.PATTERNCD_TYPE_IBM_HWMA_QCOS
                Case CommonConstant.PATTERNNM_IBM_HWMA_AAS_WarrantyOP
                    fileType = CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_WarrantyOP
                Case CommonConstant.PATTERNNM_IBM_HWMA_QCOS_WarrantyOP
                    fileType = CommonConstant.PATTERNCD_TYPE_IBM_HWMA_QCOS_WarrantyOP
                Case CommonConstant.PATTERNNM_OtherMVMS
                    fileType = CommonConstant.PATTERNCD_TYPE_OtherMVMS
                Case CommonConstant.PATTERNNM_CISCO_MAINTENANCE
                    fileType = CommonConstant.PATTERNCD_TYPE_CISCO_MAINTENANCE
                Case CommonConstant.PATTERNNM_SLink
                    fileType = CommonConstant.PATTERNCD_TYPE_SLink
                Case CommonConstant.PATTERNNM_MAINTENANCE
                    fileType = CommonConstant.PATTERNCD_TYPE_MAINTENANCE
                Case CommonConstant.PATTERNNM_HOST_SW
                    fileType = CommonConstant.PATTERNCD_TYPE_HOST_SW
                Case CommonConstant.PATTERNNM_DIRECTINPUT
                    fileType = CommonConstant.PATTERNCD_TYPE_DIRECTINPUT
                Case CommonConstant.PATTERNNM_HW_Brand_Service
                    fileType = CommonConstant.PATTERNCD_TYPE_HW_Brand_Service
                Case CommonConstant.PATTERNNM_SW_Brand_Service
                    fileType = CommonConstant.PATTERNCD_TYPE_SW_Brand_Service
                Case CommonConstant.PATTERNNM_UNIFICATION
                    fileType = CommonConstant.PATTERNCD_TYPE_UNIFICATION
                Case CommonConstant.PATTERNNM_IGF_INTERESTRATE
                    fileType = CommonConstant.PATTERNCD_TYPE_IGF_INTERESTRATE
                Case CommonConstant.PATTERNNM_IGF_RELEASE
                    fileType = CommonConstant.PATTERNCD_TYPE_IGF_RELEASE
                Case CommonConstant.PATTERNNM_IGF_USED
                    fileType = CommonConstant.PATTERNCD_TYPE_IGF_USED
                Case CommonConstant.PATTERNNM_FMA
                    fileType = CommonConstant.PATTERNCD_TYPE_FMA
                Case CommonConstant.PATTERNNM_SYSTEMSERVICE
                    fileType = CommonConstant.PATTERNCD_TYPE_SYSTEMSERVICE
                Case CommonConstant.PATTERNNM_ISS
                    fileType = CommonConstant.PATTERNCD_TYPE_ISS
                Case CommonConstant.PATTERNNM_QCOSMAF
                    fileType = CommonConstant.PATTERNCD_TYPE_QCOS_MAF
                Case CommonConstant.PATTERNNM_AASMAF
                    fileType = CommonConstant.PATTERNCD_TYPE_AAS_MAF
                Case CommonConstant.PATTERNNM_BASICSELECTION
                    fileType = CommonConstant.PATTERNCD_TYPE_BASICSELECTION
                Case CommonConstant.PATTERNNM_COMMENT
                    fileType = CommonConstant.PATTERNCD_TYPE_COMMENT
                    '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) Start
                Case CommonConstant.PATTERNNM_MSS
                    fileType = CommonConstant.PATTERNCD_TYPE_MSS
                    '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) End
                Case Else
                    fileType = ""
            End Select
        Else
            fileType = firstPatternCD
        End If

        newExist = firstNewExist

    End Sub

    ''' <summary>
    ''' 機　能：Cost開示対象のデータを個別PS、個別詳細に書込
    ''' 説　明：
    ''※補足：PGの構造変更　修正前：GetOut[PS/Detail]LogTargetDataでログ情報取得
    ''                      修正後：GetCostOutput[PS/Detail]Dataでログ情報も取得
    ''' </summary>
    ''' <param name="PSBook"></param>
    ''' <param name="CostKaijiBook"></param>
    ''' <param name="PSDataTable">PaymentﾌｧｲﾙのPaymentｼｰﾄのデータ</param>
    ''' <param name="DetailDataTable"></param>
    ''' <param name="CostKaijiPSSheetData"></param>
    ''' <param name="CostKaijiDetailSheetData"></param>
    ''' <param name="patternCd"></param>
    ''' <param name="newExist"></param>
    ''' <param name="outCntPS"></param>
    ''' <param name="TopacsTBL"></param>
    ''' <param name="ePricerTBL"></param>
    ''' <remarks></remarks>
    Private Sub WriteCostData(ByRef PSBook As Excel.Workbook,
                              ByRef CostKaijiBook As Excel.Workbook,
                              ByVal PSDataTable As DataTable,
                              ByVal DetailDataTable As DataTable,
                              ByVal CostKaijiPSSheetData As DataTable,
                              ByVal CostKaijiDetailSheetData As DataTable,
                              ByVal patternCd As String,
                              ByVal newExist As String,
                              ByRef outCntPS As Integer,
                              ByRef TopacsTBL() As DataTable,
                              ByRef ePricerTBL() As DataTable)

        Try

            ''個別ＰＳの出力件数初期化
            outCntPS = 0

            ''出力対象のCost開示データを取得
            Dim outputTargerPSDataTable As DataTable                    ''Cost開示PS取込対象ﾃﾞｰﾀ　
            Dim outputTargerDetailDataTable As DataTable                ''Cost開示詳細取込対象ﾃﾞｰﾀ　
            Dim outputLogPSDataTable As DataTable                       ''Cost開示PS取込失敗ﾃﾞｰﾀ　
            Dim outputLogDetailDataTable As DataTable                   ''Cost開示詳細取込失敗ﾃﾞｰﾀ

            If IsNothing(CostKaijiPSSheetData) = False Then
                outputLogPSDataTable = CostKaijiPSSheetData.Clone
            Else
                outputLogPSDataTable = New DataTable
            End If
            If IsNothing(CostKaijiDetailSheetData) = False Then
                outputLogDetailDataTable = CostKaijiDetailSheetData.Clone
            Else
                outputLogDetailDataTable = New DataTable
            End If

            If TopacsTBL(0).Rows.Count <> 0 Or _
               TopacsTBL(1).Rows.Count <> 0 Or _
               TopacsTBL(2).Rows.Count <> 0 Then
                Call GetWritePSCostKaijiRowTopacs(PSDataTable, DetailDataTable, TopacsTBL, outputTargerPSDataTable, outputTargerDetailDataTable)
            ElseIf ePricerTBL(0).Rows.Count <> 0 Then
                Call WritePSCostKaijiRowEPricer(PSDataTable,
                                                ePricerTBL,
                                                outputTargerPSDataTable)
                outputTargerDetailDataTable = New DataTable
            Else
                outputTargerPSDataTable = GetCostOutputPSData(outputLogPSDataTable, PSDataTable, DetailDataTable, CostKaijiPSSheetData, CostKaijiDetailSheetData, patternCd, newExist)
                outputTargerDetailDataTable = GetCostOutputDetailData(outputLogPSDataTable, outputLogDetailDataTable, DetailDataTable, CostKaijiPSSheetData, CostKaijiDetailSheetData, patternCd, newExist)
            End If

            ''個別PS、個別詳細シートに値をCost情報を出力する。
            If outputTargerPSDataTable.Rows.Count > 0 Then
                Call WritePSCostKaijiInfo(outputTargerPSDataTable, patternCd, newExist, PSBook)
            End If
            If outputTargerDetailDataTable.Rows.Count > 0 Then
                Call WriteDetailCostKaijiInfo(outputTargerDetailDataTable, patternCd, newExist, PSBook)
            End If

            ''Cost開示ファイルにログを出力
            Dim topacsOutCount As Integer
            Dim ePricerOutCount As Integer
            Select Case patternCd
                Case "Topacs"
                    Call OutTopacsLogSheet(TopacsTBL, CostKaijiBook, topacsOutCount)

                Case "e-Pricer"
                    'e-Pricer用ログ出力
                    Call OutEPricerLogSheet(ePricerTBL, CostKaijiBook, ePricerOutCount)

                Case "4", "31"
                    Call OutCostKaijiDetailLogSheet(outputLogDetailDataTable, CostKaijiBook, CostKaijiDetailSheetData.Rows.Count)
                Case Else
                    Call OutCostKaijiPSLogSheet(outputLogPSDataTable, CostKaijiBook, CostKaijiPSSheetData.Rows.Count)
            End Select

            ''出力件数をセット
            If IsNothing(outputLogPSDataTable) = False Then
                If patternCd = "Topacs" Then
                    outCntPS = topacsOutCount

                ElseIf patternCd = "e-Pricer" Then
                    outCntPS = ePricerOutCount

                Else
                    outCntPS = CostKaijiPSSheetData.Rows.Count - outputLogPSDataTable.Rows.Count
                End If
            Else
                outCntPS = outputTargerPSDataTable.Rows.Count
            End If

        Catch ex As Exception
            Throw ex

        End Try
    End Sub

    ''' <summary>
    ''' 機　能：Cost開示対象のデータを取得
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetCostOutputPSData(ByRef outputLogPSDataTable As DataTable,
                                         ByVal PSDataTable As DataTable,
                                         ByVal DetailDataTable As DataTable,
                                         ByVal CostKaijiPSSheetData As DataTable,
                                         ByVal CostKaijiDetailSheetData As DataTable,
                                         ByVal patternCd As String,
                                         ByVal newExist As String) As DataTable

        ''戻り値の定義
        Dim rtnTable As New DataTable
        Dim rtnRows() As DataRow
        rtnTable.Columns.Add(PSEXCEL_CLOUMNMNAME_LINE_NO)
        rtnTable.Columns.Add(PSEXCEL_CLOUMNMNAME_EXCELROW)
        rtnTable.Columns.Add(PSEXCEL_CLOUMNMNAME_COST)
        rtnTable.Columns.Add(PSEXCEL_CLOUMNMNAME_COST_RATE)

        rtnTable.Columns.Add(PSEXCEL_CLOUMNMNAME_NEW_EXIST)
        rtnTable.Columns.Add(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
        rtnTable.Columns.Add(PSEXCEL_CLOUMNMNAME_PATTERN)
        rtnTable.Columns.Add(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH)
        rtnTable.Columns.Add(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
        rtnTable.Columns.Add(PSEXCEL_CLOUMNMNAME_PROD_ITEM04)

        Select Case patternCd
            Case "4"
                Call GetWritePSCostKaijiRowPattern1(outputLogPSDataTable, PSDataTable, DetailDataTable, CostKaijiPSSheetData, CostKaijiDetailSheetData, rtnTable)
            Case "12"
                ''Cost開示の作成方法をLineNo毎　⇒ 製品番号毎
                Call GetWritePSCostKaijiRowPattern5(outputLogPSDataTable, PSDataTable, CostKaijiPSSheetData, rtnTable)
            Case "13"
                Call GetWritePSCostKaijiRowPattern4(outputLogPSDataTable, PSDataTable, CostKaijiPSSheetData, rtnTable)
            Case "14"
                Call GetWritePSCostKaijiRowPattern4(outputLogPSDataTable, PSDataTable, CostKaijiPSSheetData, rtnTable)
            Case "15"
                Call GetWritePSCostKaijiRowPattern3(outputLogPSDataTable, PSDataTable, CostKaijiPSSheetData, rtnTable)
            Case "16"
                Call GetWritePSCostKaijiRowPattern3(outputLogPSDataTable, PSDataTable, CostKaijiPSSheetData, rtnTable)
            Case "17"
                Call GetWritePSCostKaijiRowPattern4(outputLogPSDataTable, PSDataTable, CostKaijiPSSheetData, rtnTable)
            Case "18"
                Call GetWritePSCostKaijiRowPattern4(outputLogPSDataTable, PSDataTable, CostKaijiPSSheetData, rtnTable)
            Case "19"
                Call GetWritePSCostKaijiRowPattern4(outputLogPSDataTable, PSDataTable, CostKaijiPSSheetData, rtnTable)
            Case "20"
                Call GetWritePSCostKaijiRowPattern2(outputLogPSDataTable, PSDataTable, CostKaijiPSSheetData, rtnTable)
            Case "23"
                Call GetWritePSCostKaijiRowPattern2(outputLogPSDataTable, PSDataTable, CostKaijiPSSheetData, rtnTable)
            Case "31"
                Call GetWritePSCostKaijiRowPattern1(outputLogPSDataTable, PSDataTable, DetailDataTable, CostKaijiPSSheetData, CostKaijiDetailSheetData, rtnTable)
            Case "32"
                Call GetWritePSCostKaijiRowPattern2(outputLogPSDataTable, PSDataTable, CostKaijiPSSheetData, rtnTable)
            Case "34"
                Call GetWritePSCostKaijiRowPattern2(outputLogPSDataTable, PSDataTable, CostKaijiPSSheetData, rtnTable)
            Case "39"
                Call GetWritePSCostKaijiRowPattern2(outputLogPSDataTable, PSDataTable, CostKaijiPSSheetData, rtnTable)
                'START 変更管理#39（No.1544 MA復帰料金の統合)　2017/04 sugo
            Case "40", "41"
                Call GetWritePSCostKaijiRowPattern4(outputLogPSDataTable, PSDataTable, CostKaijiPSSheetData, rtnTable)
                'Case "40"
                '    Call GetWritePSCostKaijiRowPattern4(outputLogPSDataTable, PSDataTable, CostKaijiPSSheetData, rtnTable)
                'Case "41"
                '    Call GetWritePSCostKaijiRowPattern4(outputLogPSDataTable, PSDataTable, CostKaijiPSSheetData, rtnTable)
                'END   変更管理#39（No.1544 MA復帰料金の統合)　2017/04 sugo
            Case "43", "44"
                Call GetWritePSCostKaijiRowPattern6(outputLogPSDataTable, PSDataTable, CostKaijiPSSheetData, rtnTable)
                '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) Start
            Case "47"
                Call GetWritePSCostKaijiRowPattern2(outputLogPSDataTable, PSDataTable, CostKaijiPSSheetData, rtnTable)
                '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) End
            Case "1"
                Call GetWritePSCostKaijiRowPattern7(outputLogPSDataTable, PSDataTable, CostKaijiPSSheetData, rtnTable)
        End Select

        Return rtnTable

    End Function

    ''' <summary>
    ''' 機　能：Cost開示対象のPSシートデータを取得（パターン１）
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetWritePSCostKaijiRowPattern1(ByRef outputLogPSDataTable As DataTable,
                                               ByVal PSDataTable As DataTable,
                                               ByVal DetailDataTable As DataTable,
                                               ByVal CostKaijiPSSheetData As DataTable,
                                               ByVal CostKaijiDetailSheetData As DataTable,
                                               ByRef rtnTable As DataTable)

        ''Cost開示ファイルのPSシートデータ抽出
        Dim rtnRow As DataRow
        For Each costKaijiRow As DataRow In CostKaijiPSSheetData.Select


            ''              反映対象データのチェック
            ''==================================================

            ''コスト開示PSシートに紐づく詳細データが存在するかどうか
            Dim CostDetailRows() As DataRow
            CostDetailRows = GetMatchDetailCostRows(CostKaijiDetailSheetData, costKaijiRow)
            If CostDetailRows.Length = 0 Then
                costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = COST_NGREASON_UNMATCHCOSTPSTOCOSTDETAIL
                outputLogPSDataTable.ImportRow(costKaijiRow)
                Continue For
            End If


            ''コスト開示詳細ファイルのCostに不正な値がセットされているかどうか
            Dim subCostTotal As Decimal = 0
            Dim chkCostTotal As Boolean = False
            chkCostTotal = GetDetailCostTotal(CostDetailRows, subCostTotal)
            If chkCostTotal = False Then
                costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = COST_NGREASON_COSTINPUTERR
                outputLogPSDataTable.ImportRow(costKaijiRow)
                Continue For
            End If


            ''反映対象のPaymentシートが存在するかどうか
            Dim PSRows() As DataRow
            PSRows = GetConsInputPSRows(PSDataTable, costKaijiRow)
            If PSRows.Length = 0 Then
                costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = COST_NGREASON_UNMATCHCOSTPSTOPSDATE
                outputLogPSDataTable.ImportRow(costKaijiRow)
                Continue For
            End If


            ''反映先のPaymentSheetの数量が正しいかどうか
            If IsNumeric(PSRows(0).Item(PSEXCEL_CLOUMNMNAME_QTY)) = False OrElse
               CDbl(PSRows(0).Item(PSEXCEL_CLOUMNMNAME_QTY)) <= 0 Then

                costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = COST_NGREASON_QTYINPUTERR
                outputLogPSDataTable.ImportRow(costKaijiRow)
                Continue For
            End If

            ''Cost単価取得
            Dim PSCost As Decimal
            PSCost = subCostTotal / CDec(PSRows(0).Item(PSEXCEL_CLOUMNMNAME_QTY))

            ''Payment個別詳細データよりCost個別詳細データの個数が異なる
            Dim CostDetailCount As Integer
            Dim PSDetailCount As Integer
            Dim PSDetailRows() As DataRow
            PSDetailRows = GetMatchDetailCostRows(DetailDataTable, costKaijiRow)
            CostDetailCount = CostDetailRows.Length
            PSDetailCount = PSDetailRows.Length
            If CostDetailCount <> PSDetailCount Then
                costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = COST_NGREASON_UNMATCHCOSCOUNTDETAILPSDETAIL
                outputLogPSDataTable.ImportRow(costKaijiRow)
                Continue For
            End If


            ''--------------------------------------------------------
            ''出力対象データのセット
            ''--------------------------------------------------------
            ''※補足：PSRowsは、明示的にExcelの行番号でソート処理を行っていないが、
            ''　　　　Excelの行番号順にデータが格納されている想定(データのInset順が保証されている想定)
            For Each row As DataRow In PSRows
                rtnRow = rtnTable.NewRow
                rtnRow(PSEXCEL_CLOUMNMNAME_LINE_NO) = row(PSEXCEL_CLOUMNMNAME_LINE_NO)
                rtnRow(PSEXCEL_CLOUMNMNAME_EXCELROW) = row(PSEXCEL_CLOUMNMNAME_EXCELROW)
                rtnRow(PSEXCEL_CLOUMNMNAME_COST_RATE) = row(PSEXCEL_CLOUMNMNAME_COST_RATE)
                rtnRow(PSEXCEL_CLOUMNMNAME_COST) = PSCost

                rtnRow(PSEXCEL_CLOUMNMNAME_NEW_EXIST) = row(PSEXCEL_CLOUMNMNAME_NEW_EXIST)
                rtnRow(PSEXCEL_CLOUMNMNAME_PATTERN_CD) = row(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                rtnRow(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH) = row(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH)
                rtnRow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01) = row(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                rtnRow(PSEXCEL_CLOUMNMNAME_PATTERN) = row(PSEXCEL_CLOUMNMNAME_PATTERN)

                rtnTable.Rows.Add(rtnRow)

                Exit For

            Next
        Next

    End Sub

    ''' <summary>
    ''' 機　能：Cost開示ファイルの個別詳細シートより、Cost合計金額を集計する。
    '''        :個別PS1件に紐づく、複数件数の個別詳細データのコストを集計する。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetDetailCostTotal(ByVal CostDetailRows As DataRow(),
                                        ByRef subCostTotal As Decimal) As Decimal


        Dim rtnSubCostTotal As Decimal
        rtnSubCostTotal = 0
        GetDetailCostTotal = False

        ''合計金額のセット
        Dim row As DataRow
        For Each row In CostDetailRows
            ''※16進数/8進数表記もNGとする。
            If chkNumber(row(COSTDETAILEXCEL_CLOUMNMNAME_COST_TOTAL)) = True And _
                chkNumber(row(COSTDETAILEXCEL_CLOUMNMNAME_COST)) = True Then
                ''※COST_RATEが数字で無い→NGとする。
                If chkNumber(row(COSTDETAILEXCEL_CLOUMNMNAME_COST_TOTAL)) = True And _
                    chkNumber(row(COSTDETAILEXCEL_CLOUMNMNAME_COST_RATE)) = True Then
                    rtnSubCostTotal = rtnSubCostTotal + GetRoundUpCost(row(COSTDETAILEXCEL_CLOUMNMNAME_COST_TOTAL))
                Else
                    Exit Function
                End If
            Else
                Exit Function
            End If
        Next

        ''戻り値
        subCostTotal = rtnSubCostTotal
        Return True

    End Function


    ''' <summary>
    ''' 機　能：Cost開示ファイルの個別詳細シートより、Cost合計金額を集計する。
    '''        :個別PS1件に紐づく、複数件数の個別詳細データのコストを集計する。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetDetailCostTotal(ByVal CostKaijiDetailSheetData As DataTable,
                                        ByVal costKaijiRow As DataRow) As Decimal

        ''初期化
        ''※Cost空白のﾌｭｰﾁｬｰﾃﾞｰﾀは、0円で取込む
        GetDetailCostTotal = 0

        ''対象のCost開示ファイルのコスト合計金額を取得

        ''取込み対象のMESカテゴリ
        Dim UptakeMesCategory As String
        UptakeMesCategory = " '' , 'A' , 'CA' "
        Dim filter As New StringBuilder
        filter.Append(PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME)))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(PSDETAILEXCEL_CLOUMNMNAME_COST)
        filter.Append(CommonConstant.SQL_STR_NOT_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(""))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(PSDETAILEXCEL_CLOUMNMNAME_MES_CATEGORY)
        filter.Append(" IN ")
        filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        filter.Append(UptakeMesCategory)
        filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

        ''個別詳細データの抽出
        Dim CostRows() As DataRow
        CostRows = CostKaijiDetailSheetData.Select(filter.ToString)
        If CostRows.Length < 1 Then
            Exit Function
        End If

        ''Cost合計金額の集計
        Dim rtnSumCostTotal As Decimal = 0
        For Each CostRow As DataRow In CostRows
            rtnSumCostTotal = rtnSumCostTotal + GetRoundUpCost(CostRow(COSTDETAILEXCEL_CLOUMNMNAME_COST_TOTAL))
        Next

        Return rtnSumCostTotal

    End Function


    ''' <summary>
    ''' 機　能：個別詳細.xls　と一致するCost開示情報を取得(パターン１)
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetWriteDetailCostKaijiRowPattern1(ByRef outputLogPSDataTable As DataTable,
                                                   ByRef outputLogDetailDataTable As DataTable,
                                                   ByVal DetailDataTable As DataTable,
                                                   ByVal CostPSTable As DataTable,
                                                   ByVal CostDetailTable As DataTable,
                                                   ByRef rtnTable As DataTable)


        ''Cost空白も出力対象データとみなす。
        ''※Cost開示ファイルの最終列にエラーメッセージを表示しない。
        For Each CostDetailRow As DataRow In CostDetailTable.Select("")

            ''              反映対象データのチェック
            ''==================================================
            ''条件：MESカテゴリが追加のもの以外はチェック対象外
            If CostDetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_MES_CATEGORY) = "" Or _
               CostDetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_MES_CATEGORY) = "A" Or _
               CostDetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_MES_CATEGORY) = "CA" Then

                ''条件：紐づくPSデータが存在するか
                Dim costPSRows() As DataRow
                Dim filterPS As New StringBuilder
                filterPS.Append(PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)
                filterPS.Append(CommonConstant.SQL_STR_EQUAL)
                filterPS.Append(StringEdit.EncloseSingleQuotation(CostDetailRow(PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)))
                filterPS.Append(CommonConstant.SQL_STR_AND)
                filterPS.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME)
                filterPS.Append(CommonConstant.SQL_STR_EQUAL)
                filterPS.Append(StringEdit.EncloseSingleQuotation(CostDetailRow(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME)))
                filterPS.Append(CommonConstant.SQL_STR_AND)
                filterPS.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
                filterPS.Append(CommonConstant.SQL_STR_EQUAL)
                filterPS.Append(StringEdit.EncloseSingleQuotation(CostDetailRow(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)))
                filterPS.Append(CommonConstant.SQL_STR_AND)
                filterPS.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
                filterPS.Append(CommonConstant.SQL_STR_EQUAL)
                filterPS.Append(StringEdit.EncloseSingleQuotation(CostDetailRow(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)))
                costPSRows = CostPSTable.Select(filterPS.ToString)
                If costPSRows.Length = 0 Then
                    CostDetailRow(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = COST_NGREASON_UNMATCHCOSTDETAILTOCOSTPS
                    outputLogDetailDataTable.ImportRow(CostDetailRow)
                    Continue For
                End If


                ''条件：紐づくPSデータにエラーの場合、その値を引き継ぐ
                Dim costNGPSRows() As DataRow
                costNGPSRows = outputLogPSDataTable.Select(filterPS.ToString)
                If costNGPSRows.Length <> 0 _
                    AndAlso costNGPSRows(0).Item(COSTPSEXCEL_CLOUMNMNAME_NGREASON) <> COST_NGREASON_COSTINPUTERR _
                    AndAlso costNGPSRows(0).Item(COSTPSEXCEL_CLOUMNMNAME_NGREASON) <> COST_NGREASON_UNMATCHCOSCOUNTDETAILPSDETAIL Then
                    CostDetailRow(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = costNGPSRows(0).Item(COSTPSEXCEL_CLOUMNMNAME_NGREASON)
                    outputLogDetailDataTable.ImportRow(CostDetailRow)
                    Continue For
                End If


                ''条件：Cost開示ファイルのCostの入力チェック
                ''8進数/16進数もエラーとする
                If chkNumber(CostDetailRow(PSDETAILEXCEL_CLOUMNMNAME_COST)) = False Then
                    CostDetailRow(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = COST_NGREASON_COSTINPUTERR
                    outputLogDetailDataTable.ImportRow(CostDetailRow)
                    Continue For
                End If

                ''条件：Cost開示ファイルのCostの入力チェック
                ''COSTに文字が入っている場合：エラー
                If Not IsNumeric(CostDetailRow(PSDETAILEXCEL_CLOUMNMNAME_COST_RATE)) Then
                    CostDetailRow(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = COST_NGREASON_COSTCULCULATE
                    outputLogDetailDataTable.ImportRow(CostDetailRow)
                    Continue For
                End If


                ''条件：Cost開示ファイルの個別詳細シートと紐づく個別詳細ﾌｧｲﾙチェック
                ''取込み対象の特殊フューチャー
                Dim UptakeMesCategory
                UptakeMesCategory = " '' , 'A' , 'CA' "
                Dim filterDetail As New StringBuilder
                filterDetail.Append(COSTDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)
                filterDetail.Append(CommonConstant.SQL_STR_EQUAL)
                filterDetail.Append(StringEdit.EncloseSingleQuotation(CostDetailRow(COSTDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)))
                filterDetail.Append(CommonConstant.SQL_STR_AND)
                filterDetail.Append(COSTDETAILEXCEL_CLOUMNMNAME_FILE_NAME)
                filterDetail.Append(CommonConstant.SQL_STR_EQUAL)
                filterDetail.Append(StringEdit.EncloseSingleQuotation(CostDetailRow(COSTDETAILEXCEL_CLOUMNMNAME_FILE_NAME)))
                filterDetail.Append(CommonConstant.SQL_STR_AND)
                filterDetail.Append(COSTDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
                filterDetail.Append(CommonConstant.SQL_STR_EQUAL)
                filterDetail.Append(StringEdit.EncloseSingleQuotation(CostDetailRow(COSTDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)))
                filterDetail.Append(CommonConstant.SQL_STR_AND)
                filterDetail.Append(COSTDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
                filterDetail.Append(CommonConstant.SQL_STR_EQUAL)
                filterDetail.Append(StringEdit.EncloseSingleQuotation(CostDetailRow(COSTDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)))
                filterDetail.Append(CommonConstant.SQL_STR_AND)
                filterDetail.Append(COSTDETAILEXCEL_CLOUMNMNAME_SEQ)
                filterDetail.Append(CommonConstant.SQL_STR_EQUAL)
                filterDetail.Append(StringEdit.EncloseSingleQuotation(CostDetailRow(COSTDETAILEXCEL_CLOUMNMNAME_SEQ)))
                filterDetail.Append(CommonConstant.SQL_STR_AND)
                filterDetail.Append(COSTDETAILEXCEL_CLOUMNMNAME_MES_CATEGORY)
                filterDetail.Append(" IN ")
                filterDetail.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                filterDetail.Append(UptakeMesCategory)
                filterDetail.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                If DetailDataTable.Select(filterDetail.ToString).Length = 0 Then
                    CostDetailRow(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = COST_NGREASON_UNMATCHCOSTDETAILTOPSDETAIL
                    outputLogDetailDataTable.ImportRow(CostDetailRow)
                    Continue For
                End If

                Dim rtnRow As DataRow
                For Each DetailRow As DataRow In DetailDataTable.Select(filterDetail.ToString)
                    ''--------------------------------------------------------
                    ''出力対象データのセット
                    ''--------------------------------------------------------
                    rtnRow = rtnTable.NewRow()
                    rtnRow.Item(PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO) = DetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)
                    rtnRow.Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME) = DetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME)
                    rtnRow.Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX) = DetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
                    rtnRow.Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR) = DetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
                    rtnRow.Item(PSDETAILEXCEL_CLOUMNMNAME_SEQ) = DetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_SEQ)
                    rtnRow.Item(PSDETAILEXCEL_CLOUMNMNAME_EXCELROW) = DetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_EXCELROW)
                    rtnRow.Item(PSDETAILEXCEL_CLOUMNMNAME_COST_RATE) = CostDetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_COST_RATE)
                    rtnRow.Item(PSDETAILEXCEL_CLOUMNMNAME_COST) = changeDBNullToZero(CostDetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_COST))
                    rtnRow.Item(PSDETAILEXCEL_CLOUMNMNAME_MES_CATEGORY) = ExcelWrite.changeDBNullToString(CostDetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_MES_CATEGORY))

                    rtnTable.Rows.Add(rtnRow)

                Next
            End If
        Next

        ''詳細１件取込対象外なら、紐づくBOX情報を全て取込対象外とする。
        Dim testLog As New TestClass2
        Call DelBoxLogDataInLogTBL(rtnTable, DetailDataTable)

    End Sub


    ''' <summary>
    ''' 機　能：取込対象のCost開示の詳細ﾃﾞｰﾀ情報１件が取込エラーなら、BOXの情報全てを取込み対象外とする。
    ''' 説　明：以下の処理を行い、ｴﾗｰﾃﾞｰﾀに紐づくBOXを取得する。
    '''         ・個別詳細ファイルのBOXの件数を取得する。　
    '''         ・取込対象のCost詳細データのBOXの件数を取得する。
    '''         ・個別詳細ファイルと、Cost詳細データの件数が不一致だった場合、取込失敗情報と判定する。
    '''
    '''         　※補足：・申請ファイル作成後、以下の手入力等によって個別詳細とKEYが不一致なデータが作成される。
    '''               　　・その場合、個別詳細ファイルのBOXに中途半端にCOSTが入力されることを防ぐため、
    '''　　　　　　　　　 　取込件数の比較で完全に一致したもののみを反映する。
    '''
    '''           <<不正なデータが作成される例>>
    '''           ・Cost申請ファイル作成後、個別詳細の構成を追加したパターン。
    '''             ⇒個別詳細：データ件数 > Cost開示詳細：データ件数
    '''
    '''           ・Cost申請ファイルのKEY項目の情報を間違って変更、又は行を削除した場合
    '''             ⇒Cost開示詳細：データ件数 > 個別詳細：データ件数
    '''
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub DelBoxLogDataInLogTBL(ByRef rtnTable As DataTable, _
                                      ByRef DetailDataTable As DataTable)


        Dim loopTBL As DataTable
        Dim chkRow As DataRow
        Dim filter As New StringBuilder
        Dim UptakeMesCategory
        Dim detailFileCount             ''詳細ファイルのBOX件数
        Dim constDetailFileCount        ''Cost詳細のBOX件数
        UptakeMesCategory = " '' , 'A' , 'CA' "
        loopTBL = rtnTable.Copy
        For Each chkRow In loopTBL.Select("")


            ''件数初期化
            detailFileCount = 0
            constDetailFileCount = 0


            ''詳細データの件数取得
            filter.Length = 0
            filter.Append(COSTDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(chkRow(COSTDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append(COSTDETAILEXCEL_CLOUMNMNAME_FILE_NAME)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(chkRow(COSTDETAILEXCEL_CLOUMNMNAME_FILE_NAME)))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append(COSTDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(chkRow(COSTDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append(COSTDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(chkRow(COSTDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append(COSTDETAILEXCEL_CLOUMNMNAME_MES_CATEGORY)
            filter.Append(" IN ")
            filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            filter.Append(UptakeMesCategory)
            filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
            detailFileCount = DetailDataTable.Select(filter.ToString).Length


            ''Cost詳細データの件数取得
            constDetailFileCount = rtnTable.Select(filter.ToString).Length


            If constDetailFileCount <> detailFileCount Then

                ''※補足：delTargetCollection　と　searchRowsはデータ型が異なる。
                ''　　　　delTargetCollectionはテーブルの行情報を管理するCollectionで、Remove命令でﾃｰﾌﾞﾙﾃﾞｰﾀを破棄するため使用。
                Dim delTargetCollection As DataRowCollection        ''Tableの行情報を管理するCollection
                Dim searchRows() As DataRow                         ''削除対象の行情報（BOX情報一覧）            
                Dim delRow As DataRow                               ''削除対象の行情報（BOX情報のうちの１件）
                Dim delIdx As Integer                               ''削除する行のIndex位置
                delTargetCollection = rtnTable.Rows
                searchRows = rtnTable.Select(filter.ToString)
                For Each delRow In searchRows
                    delIdx = delTargetCollection.IndexOf(delRow)
                    Call delTargetCollection.RemoveAt(delIdx)
                Next

            End If
        Next

    End Sub

    ''' <summary>
    ''' 機　能：Cost開示対象のPSデータに紐づくCost開示詳細データを取得
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetMatchDetailCostRows(ByRef CostKaijiDetailSheetData As DataTable, _
                                            ByRef costKaijiRow As DataRow) As DataRow()

        ''取込み対象のMESカテゴリ
        Dim UptakeMesCategory As String
        UptakeMesCategory = " '' , 'A' , 'CA' "

        ''Cost開示PSシートに紐づく詳細シートの取得
        Dim filter As New StringBuilder
        filter.Append(PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME)))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(PSDETAILEXCEL_CLOUMNMNAME_MES_CATEGORY)
        filter.Append(" IN ")
        filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        filter.Append(UptakeMesCategory)
        filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

        ''戻り値のセット
        Return CostKaijiDetailSheetData.Select(filter.ToString)

    End Function

    ''' <summary>
    ''' 機　能：Cost開示ファイル1行分データに紐づく、個別PSデータを抽出する。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetConsInputPSRows(ByVal PSDataTable As DataTable,
                                        ByVal costKaijiRow As DataRow) As DataRow()

        ''コスト入力済みの個別PSのデータを抽出
        Dim filter As New StringBuilder
        filter.Append(PSEXCEL_CLOUMNMNAME_CONTRACTNO)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_CONTRACTNO)))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(PSEXCEL_CLOUMNMNAME_FILE_NAME)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME)))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)))

        ''特殊フューチャーは出力対象外とする
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(CommonConstant.SQL_STR_NOT)
        filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation("2"))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM04)
        filter.Append(CommonConstant.SQL_STR_NOT_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(""))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM05)
        filter.Append(CommonConstant.SQL_STR_NOT_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(""))
        filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

        ''パターンCDを条件に追加
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_PATTERN_CD)))

        ''作成中のデータのみ反映
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(""))

        ''コメント行は出力しない。
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
        filter.Append(CommonConstant.SQL_STR_NOT)
        filter.Append(CommonConstant.SQL_STR_IN)
        filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        filter.Append(StringEdit.EncloseSingleQuotation("C"))
        filter.Append(CommonConstant.STR_COMMA)
        filter.Append(StringEdit.EncloseSingleQuotation("N"))
        filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

        ''個別PSより、対象データを抽出
        Dim PsRows() As DataRow
        Dim rtnRows() As DataRow
        PsRows = PSDataTable.Select(filter.ToString)
        rtnRows = PsRows

        Return rtnRows

    End Function


    ''' <summary>
    ''' 機　能：Cost開示対象のPSシートデータを取得（パターン２）
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetWritePSCostKaijiRowPattern2(ByRef outputLogPSDataTable As DataTable,
                                               ByVal PSDataTable As DataTable,
                                               ByVal costKaijiTable As DataTable,
                                               ByRef rtnTable As DataTable)


        For Each costKaijiRow As DataRow In costKaijiTable.Select("")

            ''                   取込対象外データかどうか判定
            ''====================================================================

            ''NG条件：Cost単価に不正な値がセットされている。
            If chkNumber(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_COST)) = False Then
                costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = COST_NGREASON_COSTINPUTERR
                outputLogPSDataTable.ImportRow(costKaijiRow)
                Continue For
            End If


            ''NG条件：Cost開示PSシートに紐づくPaymentシートが存在するかどうか
            Dim filterPS As New StringBuilder
            filterPS.Append(PSEXCEL_CLOUMNMNAME_LINE_NO)
            filterPS.Append(CommonConstant.SQL_STR_EQUAL)
            filterPS.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_LINE_NO)))

            ''パターンコード、ListPrice、項目１
            filterPS.Append(CommonConstant.SQL_STR_AND)
            filterPS.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
            filterPS.Append(CommonConstant.SQL_STR_EQUAL)
            filterPS.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_PATTERN_CD)))
            filterPS.Append(CommonConstant.SQL_STR_AND)
            filterPS.Append(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH)
            filterPS.Append(CommonConstant.SQL_STR_EQUAL)
            filterPS.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_LIST_PRICE_REFLESH)))
            filterPS.Append(CommonConstant.SQL_STR_AND)
            filterPS.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
            filterPS.Append(CommonConstant.SQL_STR_EQUAL)
            filterPS.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM01)))

            ''コメント行は出力しない。
            filterPS.Append(CommonConstant.SQL_STR_AND)
            filterPS.Append(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
            filterPS.Append(CommonConstant.SQL_STR_NOT)
            filterPS.Append(CommonConstant.SQL_STR_IN)
            filterPS.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            filterPS.Append(StringEdit.EncloseSingleQuotation("C"))
            filterPS.Append(CommonConstant.STR_COMMA)
            filterPS.Append(StringEdit.EncloseSingleQuotation("N"))
            filterPS.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

            ''Cost開示PSシートに紐づく個別PS .xls情報を取得
            If PSDataTable.Select(filterPS.ToString).Length = 0 Then
                costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = COST_NGREASON_UNMATCHCOSTPSTOPSDATE
                outputLogPSDataTable.ImportRow(costKaijiRow)
                Continue For
            End If

            Dim rtnRow As DataRow
            For Each PSRow As DataRow In PSDataTable.Select(filterPS.ToString)

                ''--------------------------------------------------------
                ''出力対象データのセット
                ''--------------------------------------------------------
                rtnRow = rtnTable.NewRow()
                rtnRow(PSEXCEL_CLOUMNMNAME_LINE_NO) = PSRow.Item(PSEXCEL_CLOUMNMNAME_LINE_NO)
                rtnRow(PSEXCEL_CLOUMNMNAME_EXCELROW) = PSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)
                rtnRow(PSEXCEL_CLOUMNMNAME_COST_RATE) = costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_COST_RATE)
                rtnRow(PSEXCEL_CLOUMNMNAME_COST) = costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_COST)

                rtnRow(PSEXCEL_CLOUMNMNAME_NEW_EXIST) = PSRow(PSEXCEL_CLOUMNMNAME_NEW_EXIST)
                rtnRow(PSEXCEL_CLOUMNMNAME_PATTERN_CD) = PSRow(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                rtnRow(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH) = PSRow(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH)
                rtnRow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01) = PSRow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                rtnRow(PSEXCEL_CLOUMNMNAME_PATTERN) = PSRow(PSEXCEL_CLOUMNMNAME_PATTERN)

                rtnTable.Rows.Add(rtnRow)

            Next
        Next

    End Sub

    ''' <summary>
    ''' 機　能：Cost開示対象のPSシートデータを取得（パターン3）
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetWritePSCostKaijiRowPattern3(ByRef outputLogPSDataTable As DataTable,
                                               ByVal PSDataTable As DataTable,
                                               ByVal costKaijiTable As DataTable,
                                               ByRef rtnTable As DataTable)


        For Each costKaijiRow As DataRow In costKaijiTable.Select()


            ''                   取込対象外データかどうか判定
            ''====================================================================            

            ''条件：Costの入力値が不正な場合
            If chkNumber(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_COST_RATE)) = False Then
                costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = COST_NGREASON_COSTINPUTERR
                outputLogPSDataTable.ImportRow(costKaijiRow)
                Continue For
            End If


            ''条件：Cost開示PSシートに紐づくPaymentシートが存在しない場合
            Dim filterPS As New StringBuilder
            filterPS.Append(PSEXCEL_CLOUMNMNAME_LINE_NO)
            filterPS.Append(CommonConstant.SQL_STR_EQUAL)
            filterPS.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_LINE_NO)))

            ''パターンコード、ListPrice、項目１
            filterPS.Append(CommonConstant.SQL_STR_AND)
            filterPS.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
            filterPS.Append(CommonConstant.SQL_STR_EQUAL)
            filterPS.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_PATTERN_CD)))
            filterPS.Append(CommonConstant.SQL_STR_AND)
            filterPS.Append(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH)
            filterPS.Append(CommonConstant.SQL_STR_EQUAL)
            filterPS.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_LIST_PRICE_REFLESH)))
            filterPS.Append(CommonConstant.SQL_STR_AND)
            filterPS.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
            filterPS.Append(CommonConstant.SQL_STR_EQUAL)
            filterPS.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM01)))

            ''コメント行は出力しない。
            filterPS.Append(CommonConstant.SQL_STR_AND)
            filterPS.Append(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
            filterPS.Append(CommonConstant.SQL_STR_NOT)
            filterPS.Append(CommonConstant.SQL_STR_IN)
            filterPS.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            filterPS.Append(StringEdit.EncloseSingleQuotation("C"))
            filterPS.Append(CommonConstant.STR_COMMA)
            filterPS.Append(StringEdit.EncloseSingleQuotation("N"))
            filterPS.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

            If PSDataTable.Select(filterPS.ToString).Length = 0 Then
                costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = COST_NGREASON_UNMATCHCOSTPSTOPSDATE
                outputLogPSDataTable.ImportRow(costKaijiRow)
                Continue For
            End If


            Dim rtnRow As DataRow
            For Each PSRow As DataRow In PSDataTable.Select(filterPS.ToString)

                ''--------------------------------------------------------
                ''出力対象データのセット
                ''--------------------------------------------------------
                rtnRow = rtnTable.NewRow()
                rtnRow(PSEXCEL_CLOUMNMNAME_LINE_NO) = PSRow.Item(PSEXCEL_CLOUMNMNAME_LINE_NO)
                rtnRow(PSEXCEL_CLOUMNMNAME_COST_RATE) = costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_COST_RATE)
                rtnRow(PSEXCEL_CLOUMNMNAME_COST) = costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_COST)
                rtnRow(PSEXCEL_CLOUMNMNAME_EXCELROW) = PSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)

                rtnRow(PSEXCEL_CLOUMNMNAME_NEW_EXIST) = PSRow(PSEXCEL_CLOUMNMNAME_NEW_EXIST)
                rtnRow(PSEXCEL_CLOUMNMNAME_PATTERN_CD) = PSRow(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                rtnRow(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH) = PSRow(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH)
                rtnRow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01) = PSRow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                rtnRow(PSEXCEL_CLOUMNMNAME_PATTERN) = PSRow(PSEXCEL_CLOUMNMNAME_PATTERN)

                rtnTable.Rows.Add(rtnRow)

            Next
        Next

    End Sub

    ''' <summary>
    ''' 機　能：Cost開示対象のPSシートデータを取得（パターン4）
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetWritePSCostKaijiRowPattern4(ByRef outputLogPSDataTable As DataTable,
                                               ByVal PSDataTable As DataTable,
                                               ByVal costKaijiTable As DataTable,
                                               ByRef rtnTable As DataTable)


        For Each costKaijiRow As DataRow In costKaijiTable.Select()


            ''                   取込対象外データかどうか判定
            ''====================================================================            
            ''条件：Costの入力値が不正な場合
            If chkNumber(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_COST_RATE)) = False Then
                costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = COST_NGREASON_COSTINPUTERR
                outputLogPSDataTable.ImportRow(costKaijiRow)
                Continue For
            End If

            ''条件：Cost開示PSシートに紐づく個別PSデータの判定
            Dim filterPS As New StringBuilder
            filterPS.Append(PSEXCEL_CLOUMNMNAME_PATTERN)
            filterPS.Append(CommonConstant.SQL_STR_EQUAL)
            filterPS.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_PATTERN_NM)))
            filterPS.Append(CommonConstant.SQL_STR_AND)
            filterPS.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
            filterPS.Append(CommonConstant.SQL_STR_EQUAL)
            filterPS.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM01)))

            ''作成中のデータのみ反映
            filterPS.Append(CommonConstant.SQL_STR_AND)
            filterPS.Append(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)
            filterPS.Append(CommonConstant.SQL_STR_EQUAL)
            filterPS.Append(StringEdit.EncloseSingleQuotation(""))

            ''コメント行は出力しない。
            filterPS.Append(CommonConstant.SQL_STR_AND)
            filterPS.Append(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
            filterPS.Append(CommonConstant.SQL_STR_NOT)
            filterPS.Append(CommonConstant.SQL_STR_IN)
            filterPS.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            filterPS.Append(StringEdit.EncloseSingleQuotation("C"))
            filterPS.Append(CommonConstant.STR_COMMA)
            filterPS.Append(StringEdit.EncloseSingleQuotation("N"))
            filterPS.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

            If PSDataTable.Select(filterPS.ToString).Length = 0 Then
                costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = COST_NGREASON_UNMATCHCOSTPSTOPSDATE
                outputLogPSDataTable.ImportRow(costKaijiRow)
                Continue For
            End If


            Dim rtnRow As DataRow
            For Each PSRow As DataRow In PSDataTable.Select(filterPS.ToString)
                ''--------------------------------------------------------
                ''出力対象データのセット
                ''--------------------------------------------------------
                rtnRow = rtnTable.NewRow()
                rtnRow(PSEXCEL_CLOUMNMNAME_LINE_NO) = PSRow.Item(PSEXCEL_CLOUMNMNAME_LINE_NO)
                rtnRow(PSEXCEL_CLOUMNMNAME_COST_RATE) = costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_COST_RATE)
                rtnRow(PSEXCEL_CLOUMNMNAME_COST) = costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_COST)
                rtnRow(PSEXCEL_CLOUMNMNAME_EXCELROW) = PSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)

                rtnRow(PSEXCEL_CLOUMNMNAME_NEW_EXIST) = PSRow(PSEXCEL_CLOUMNMNAME_NEW_EXIST)
                rtnRow(PSEXCEL_CLOUMNMNAME_PATTERN_CD) = PSRow(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                rtnRow(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH) = PSRow(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH)
                rtnRow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01) = PSRow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                rtnRow(PSEXCEL_CLOUMNMNAME_PATTERN) = PSRow(PSEXCEL_CLOUMNMNAME_PATTERN)

                rtnTable.Rows.Add(rtnRow)
            Next
        Next

    End Sub


    ''' <summary>
    ''' 機　能：Cost開示対象のPSシートデータを取得（パターン5）
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetWritePSCostKaijiRowPattern5(ByRef outputLogPSDataTable As DataTable,
                                               ByVal PSDataTable As DataTable,
                                               ByVal costKaijiTable As DataTable,
                                               ByRef rtnTable As DataTable)


        For Each costKaijiRow As DataRow In costKaijiTable.Select()


            ''                   取込対象外データかどうか判定
            ''====================================================================            
            ''条件：Costの入力値が不正な場合
            If chkNumber(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_COST)) = False Then
                costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = COST_NGREASON_COSTINPUTERR
                outputLogPSDataTable.ImportRow(costKaijiRow)
                Continue For
            End If

            ''条件：Cost開示PSシートに紐づく個別PSデータの判定
            Dim filterPS As New StringBuilder
            filterPS.Append(PSEXCEL_CLOUMNMNAME_PATTERN)
            filterPS.Append(CommonConstant.SQL_STR_EQUAL)
            filterPS.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_PATTERN_NM)))
            filterPS.Append(CommonConstant.SQL_STR_AND)
            filterPS.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
            filterPS.Append(CommonConstant.SQL_STR_EQUAL)
            filterPS.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM01)))

            ''作成中のデータのみ反映
            filterPS.Append(CommonConstant.SQL_STR_AND)
            filterPS.Append(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)
            filterPS.Append(CommonConstant.SQL_STR_EQUAL)
            filterPS.Append(StringEdit.EncloseSingleQuotation(""))

            ''コメント行は出力しない。
            filterPS.Append(CommonConstant.SQL_STR_AND)
            filterPS.Append(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
            filterPS.Append(CommonConstant.SQL_STR_NOT)
            filterPS.Append(CommonConstant.SQL_STR_IN)
            filterPS.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            filterPS.Append(StringEdit.EncloseSingleQuotation("C"))
            filterPS.Append(CommonConstant.STR_COMMA)
            filterPS.Append(StringEdit.EncloseSingleQuotation("N"))
            filterPS.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

            If PSDataTable.Select(filterPS.ToString).Length = 0 Then
                costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = COST_NGREASON_UNMATCHCOSTPSTOPSDATE
                outputLogPSDataTable.ImportRow(costKaijiRow)
                Continue For
            End If


            Dim rtnRow As DataRow
            For Each PSRow As DataRow In PSDataTable.Select(filterPS.ToString)
                ''--------------------------------------------------------
                ''出力対象データのセット
                ''--------------------------------------------------------
                rtnRow = rtnTable.NewRow()
                rtnRow(PSEXCEL_CLOUMNMNAME_LINE_NO) = PSRow.Item(PSEXCEL_CLOUMNMNAME_LINE_NO)
                rtnRow(PSEXCEL_CLOUMNMNAME_COST_RATE) = costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_COST_RATE)
                rtnRow(PSEXCEL_CLOUMNMNAME_COST) = costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_COST)
                rtnRow(PSEXCEL_CLOUMNMNAME_EXCELROW) = PSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)

                rtnRow(PSEXCEL_CLOUMNMNAME_NEW_EXIST) = PSRow(PSEXCEL_CLOUMNMNAME_NEW_EXIST)
                rtnRow(PSEXCEL_CLOUMNMNAME_PATTERN_CD) = PSRow(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                rtnRow(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH) = PSRow(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH)
                rtnRow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01) = PSRow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                rtnRow(PSEXCEL_CLOUMNMNAME_PATTERN) = PSRow(PSEXCEL_CLOUMNMNAME_PATTERN)

                rtnTable.Rows.Add(rtnRow)
            Next
        Next

    End Sub

    ''' <summary>
    ''' 機　能：Cost開示対象のPSシートデータを取得（パターン6）
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetWritePSCostKaijiRowPattern6(ByRef outputLogPSDataTable As DataTable,
                                               ByVal PSDataTable As DataTable,
                                               ByVal costKaijiTable As DataTable,
                                               ByRef rtnTable As DataTable)


        For Each costKaijiRow As DataRow In costKaijiTable.Select()


            ''                   取込対象外データかどうか判定
            ''====================================================================            
            ''条件：Costの入力値が不正な場合
            If chkNumber(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_COST_RATE)) = False Then
                costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = COST_NGREASON_COSTINPUTERR
                outputLogPSDataTable.ImportRow(costKaijiRow)
                Continue For
            End If

            ''条件：Cost開示PSシートに紐づく個別PSデータの判定
            Dim filterPS As New StringBuilder
            filterPS.Append(PSEXCEL_CLOUMNMNAME_PATTERN)
            filterPS.Append(CommonConstant.SQL_STR_EQUAL)
            filterPS.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_PATTERN_NM)))
            filterPS.Append(CommonConstant.SQL_STR_AND)
            filterPS.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
            filterPS.Append(CommonConstant.SQL_STR_EQUAL)
            filterPS.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM01)))
            filterPS.Append(CommonConstant.SQL_STR_AND)
            filterPS.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM04)
            filterPS.Append(CommonConstant.SQL_STR_EQUAL)
            filterPS.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM04)))

            ''作成中のデータのみ反映
            filterPS.Append(CommonConstant.SQL_STR_AND)
            filterPS.Append(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)
            filterPS.Append(CommonConstant.SQL_STR_EQUAL)
            filterPS.Append(StringEdit.EncloseSingleQuotation(""))

            ''コメント行は出力しない。
            filterPS.Append(CommonConstant.SQL_STR_AND)
            filterPS.Append(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
            filterPS.Append(CommonConstant.SQL_STR_NOT)
            filterPS.Append(CommonConstant.SQL_STR_IN)
            filterPS.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            filterPS.Append(StringEdit.EncloseSingleQuotation("C"))
            filterPS.Append(CommonConstant.STR_COMMA)
            filterPS.Append(StringEdit.EncloseSingleQuotation("N"))
            filterPS.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

            If PSDataTable.Select(filterPS.ToString).Length = 0 Then
                costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = COST_NGREASON_UNMATCHCOSTPSTOPSDATE
                outputLogPSDataTable.ImportRow(costKaijiRow)
                Continue For
            End If


            Dim rtnRow As DataRow
            For Each PSRow As DataRow In PSDataTable.Select(filterPS.ToString)
                ''--------------------------------------------------------
                ''出力対象データのセット
                ''--------------------------------------------------------
                rtnRow = rtnTable.NewRow()
                rtnRow(PSEXCEL_CLOUMNMNAME_LINE_NO) = PSRow.Item(PSEXCEL_CLOUMNMNAME_LINE_NO)
                rtnRow(PSEXCEL_CLOUMNMNAME_COST_RATE) = costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_COST_RATE)
                rtnRow(PSEXCEL_CLOUMNMNAME_COST) = costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_COST)
                rtnRow(PSEXCEL_CLOUMNMNAME_EXCELROW) = PSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)

                rtnRow(PSEXCEL_CLOUMNMNAME_NEW_EXIST) = PSRow(PSEXCEL_CLOUMNMNAME_NEW_EXIST)
                rtnRow(PSEXCEL_CLOUMNMNAME_PATTERN_CD) = PSRow(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                rtnRow(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH) = PSRow(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH)
                rtnRow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01) = PSRow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                rtnRow(PSEXCEL_CLOUMNMNAME_PROD_ITEM04) = PSRow(PSEXCEL_CLOUMNMNAME_PROD_ITEM04)
                rtnRow(PSEXCEL_CLOUMNMNAME_PATTERN) = PSRow(PSEXCEL_CLOUMNMNAME_PATTERN)

                rtnTable.Rows.Add(rtnRow)
            Next
        Next

    End Sub

    ''' <summary>
    ''' 機　能：Cost開示対象のPSシートデータを取得（パターン７）
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetWritePSCostKaijiRowPattern7(ByRef outputLogPSDataTable As DataTable,
                                               ByVal PSDataTable As DataTable,
                                               ByVal costKaijiTable As DataTable,
                                               ByRef rtnTable As DataTable)

        For Each costKaijiRow As DataRow In costKaijiTable.Select("")

            ''                   取込対象外データかどうか判定
            ''====================================================================

            ''NG条件：Cost単価に不正な値がセットされている。
            If chkNumber(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_COST)) = False Then
                costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = COST_NGREASON_COSTINPUTERR
                outputLogPSDataTable.ImportRow(costKaijiRow)
                Continue For
            End If


            ''NG条件：Cost開示PSシートに紐づくPaymentシートが存在するかどうか
            Dim filterPS As New StringBuilder

            ''パターンコード、項目１
            filterPS.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
            filterPS.Append(CommonConstant.SQL_STR_EQUAL)
            filterPS.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_PATTERN_CD)))
            filterPS.Append(CommonConstant.SQL_STR_AND)

            filterPS.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
            filterPS.Append(CommonConstant.SQL_STR_EQUAL)
            filterPS.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM01)))

            ''コメント行は出力しない。
            filterPS.Append(CommonConstant.SQL_STR_AND)
            filterPS.Append(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
            filterPS.Append(CommonConstant.SQL_STR_NOT)
            filterPS.Append(CommonConstant.SQL_STR_IN)
            filterPS.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            filterPS.Append(StringEdit.EncloseSingleQuotation("C"))
            filterPS.Append(CommonConstant.STR_COMMA)
            filterPS.Append(StringEdit.EncloseSingleQuotation("N"))
            filterPS.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

            ''Cost開示PSシートに紐づく個別PS .xls情報を取得
            If PSDataTable.Select(filterPS.ToString).Length = 0 Then
                costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = COST_NGREASON_UNMATCHCOSTPSTOPSDATE
                outputLogPSDataTable.ImportRow(costKaijiRow)
                Continue For
            End If

            Dim rtnRow As DataRow
            For Each PSRow As DataRow In PSDataTable.Select(filterPS.ToString)

                ''--------------------------------------------------------
                ''出力対象データのセット
                ''--------------------------------------------------------
                rtnRow = rtnTable.NewRow()
                rtnRow(PSEXCEL_CLOUMNMNAME_LINE_NO) = PSRow.Item(PSEXCEL_CLOUMNMNAME_LINE_NO)
                rtnRow(PSEXCEL_CLOUMNMNAME_EXCELROW) = PSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)
                rtnRow(PSEXCEL_CLOUMNMNAME_COST_RATE) = costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_COST_RATE)
                rtnRow(PSEXCEL_CLOUMNMNAME_COST) = costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_COST)

                rtnRow(PSEXCEL_CLOUMNMNAME_NEW_EXIST) = PSRow(PSEXCEL_CLOUMNMNAME_NEW_EXIST)
                rtnRow(PSEXCEL_CLOUMNMNAME_PATTERN_CD) = PSRow(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                rtnRow(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH) = PSRow(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH)
                rtnRow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01) = PSRow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                rtnRow(PSEXCEL_CLOUMNMNAME_PATTERN) = PSRow(PSEXCEL_CLOUMNMNAME_PATTERN)

                rtnTable.Rows.Add(rtnRow)

            Next
        Next

    End Sub

    ''' <summary>
    ''' 機　能：Cost開示対象の個別詳細シートデータを取得
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetCostOutputDetailData(ByRef outputLogPSDataTable As DataTable,
                                             ByRef outputLogDetailDataTable As DataTable,
                                             ByVal DetailDataTable As DataTable,
                                             ByVal CostKaijiPSSheetData As DataTable,
                                             ByVal CostKaijiDetailSheetData As DataTable,
                                             ByVal patternCD As String,
                                             ByVal newExist As String) As DataTable

        ''戻り値の定義
        Dim rtnTable As New DataTable
        rtnTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)
        rtnTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME)
        rtnTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
        rtnTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
        rtnTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_SEQ)
        rtnTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_MES_CATEGORY)
        rtnTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_SPECIAL_FEATURE)
        rtnTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_EXCELROW)
        rtnTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_COST_RATE)
        rtnTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_COST)

        Select Case patternCD
            Case "4"
                Call GetWriteDetailCostKaijiRowPattern1(outputLogPSDataTable, outputLogDetailDataTable, DetailDataTable, CostKaijiPSSheetData, CostKaijiDetailSheetData, rtnTable)
            Case "31"
                Call GetWriteDetailCostKaijiRowPattern1(outputLogPSDataTable, outputLogDetailDataTable, DetailDataTable, CostKaijiPSSheetData, CostKaijiDetailSheetData, rtnTable)
        End Select

        Return rtnTable

    End Function

    ''' <summary>
    ''' 機　能：Cost開示PS情報を個別PS　.xlsへ反映する。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub WritePSCostKaijiInfo(ByVal outputTargerPSDataTable As DataTable,
                                     ByVal patternCD As String,
                                     ByVal newExist As String,
                                     ByRef PSBook As Excel.Workbook)

        ''-----------------------------------
        ''個別PSBookへコスト情報を書き込む
        ''-----------------------------------
        Dim xlSheet As Excel.Worksheet
        Dim xlRan As Excel.Range
        Dim InputDay As String
        InputDay = Now.ToString("yyyy/MM/dd")

        Dim excelWrite As New ExcelWrite
        Try
            xlSheet = PSBook.Worksheets(excelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)

            ''Excelのオートフィルタを初期化
            Call excelWrite.CrearAutoFilter(xlSheet)
            For Each costPSRow As DataRow In outputTargerPSDataTable.Select

                ''Costをセット
                Select Case patternCD
                    Case "Topacs"
                        xlRan = xlSheet.Cells(CInt(costPSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)), excelWrite.ExcelPaymentLineColumn.COST)
                        xlRan.Value = GetRoundUpCost(changeDBNullToZero(costPSRow.Item(PSEXCEL_CLOUMNMNAME_COST)))

                    Case "e-Pricer"
                        xlRan = xlSheet.Cells(CInt(costPSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)), excelWrite.ExcelPaymentLineColumn.COST)
                        xlRan.Value = GetRoundCost(changeDBNullToZero(costPSRow.Item(PSEXCEL_CLOUMNMNAME_COST)))

                    Case "4"
                        ''Cost単価
                        xlRan = xlSheet.Cells(CInt(costPSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)), excelWrite.ExcelPaymentLineColumn.COST)
                        xlRan.Value = GetRoundUpCost(costPSRow.Item(PSEXCEL_CLOUMNMNAME_COST))

                    Case "12"
                        ''Cost単価
                        xlRan = xlSheet.Cells(CInt(costPSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)), excelWrite.ExcelPaymentLineColumn.COST)
                        xlRan.Value = GetRoundUpCost(costPSRow.Item(PSEXCEL_CLOUMNMNAME_COST))
                    Case "13"
                        ''Cost%
                        xlRan = xlSheet.Cells(CInt(costPSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)), excelWrite.ExcelPaymentLineColumn.COST_RATE)
                        xlRan.Value = costPSRow.Item(PSEXCEL_CLOUMNMNAME_COST_RATE)
                    Case "14"
                        ''Cost%
                        xlRan = xlSheet.Cells(CInt(costPSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)), excelWrite.ExcelPaymentLineColumn.COST_RATE)
                        xlRan.Value = costPSRow.Item(PSEXCEL_CLOUMNMNAME_COST_RATE)
                    Case "15"
                        ''Cost%
                        xlRan = xlSheet.Cells(CInt(costPSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)), excelWrite.ExcelPaymentLineColumn.COST_RATE)
                        xlRan.Value = costPSRow.Item(PSEXCEL_CLOUMNMNAME_COST_RATE)
                    Case "16"
                        ''Cost%
                        xlRan = xlSheet.Cells(CInt(costPSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)), excelWrite.ExcelPaymentLineColumn.COST_RATE)
                        xlRan.Value = costPSRow.Item(PSEXCEL_CLOUMNMNAME_COST_RATE)
                    Case "17"
                        ''Cost%
                        xlRan = xlSheet.Cells(CInt(costPSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)), excelWrite.ExcelPaymentLineColumn.COST_RATE)
                        xlRan.Value = costPSRow.Item(PSEXCEL_CLOUMNMNAME_COST_RATE)
                    Case "18"
                        ''Cost%
                        xlRan = xlSheet.Cells(CInt(costPSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)), excelWrite.ExcelPaymentLineColumn.COST_RATE)
                        xlRan.Value = costPSRow.Item(PSEXCEL_CLOUMNMNAME_COST_RATE)
                    Case "19"
                        ''Cost%
                        xlRan = xlSheet.Cells(CInt(costPSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)), excelWrite.ExcelPaymentLineColumn.COST_RATE)
                        xlRan.Value = costPSRow.Item(PSEXCEL_CLOUMNMNAME_COST_RATE)
                    Case "20"
                        ''Cost単価
                        xlRan = xlSheet.Cells(CInt(costPSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)), excelWrite.ExcelPaymentLineColumn.COST)
                        xlRan.Value = costPSRow.Item(PSEXCEL_CLOUMNMNAME_COST)
                    Case "23"
                        ''Cost単価
                        xlRan = xlSheet.Cells(CInt(costPSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)), excelWrite.ExcelPaymentLineColumn.COST)
                        xlRan.Value = GetRoundUpCost(costPSRow.Item(PSEXCEL_CLOUMNMNAME_COST))
                    Case "31"
                        ''Cost単価
                        xlRan = xlSheet.Cells(CInt(costPSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)), excelWrite.ExcelPaymentLineColumn.COST)
                        xlRan.Value = GetRoundUpCost(changeDBNullToZero(costPSRow.Item(PSEXCEL_CLOUMNMNAME_COST)))
                    Case "32"
                        ''Cost単価
                        xlRan = xlSheet.Cells(CInt(costPSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)), excelWrite.ExcelPaymentLineColumn.COST)
                        xlRan.Value = GetRoundUpCost(costPSRow.Item(PSEXCEL_CLOUMNMNAME_COST))
                    Case "34"
                        ''Cost単価
                        xlRan = xlSheet.Cells(CInt(costPSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)), excelWrite.ExcelPaymentLineColumn.COST)
                        xlRan.Value = GetRoundUpCost(costPSRow.Item(PSEXCEL_CLOUMNMNAME_COST))
                    Case "39"
                        ''Cost単価
                        xlRan = xlSheet.Cells(CInt(costPSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)), excelWrite.ExcelPaymentLineColumn.COST)
                        xlRan.Value = GetRoundUpCost(costPSRow.Item(PSEXCEL_CLOUMNMNAME_COST))
                        'START 変更管理#39（No.1544 MA復帰料金の統合)　2017/04 sugo
                    Case "40", "41"
                        ''Cost%
                        xlRan = xlSheet.Cells(CInt(costPSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)), excelWrite.ExcelPaymentLineColumn.COST_RATE)
                        xlRan.Value = costPSRow.Item(PSEXCEL_CLOUMNMNAME_COST_RATE)
                        'Case "40"
                        '    ''Cost%
                        '    xlRan = xlSheet.Cells(CInt(costPSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)), excelWrite.ExcelPaymentLineColumn.COST_RATE)
                        '    xlRan.Value = costPSRow.Item(PSEXCEL_CLOUMNMNAME_COST_RATE)
                        'Case "41"
                        '    ''Cost%
                        '    xlRan = xlSheet.Cells(CInt(costPSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)), excelWrite.ExcelPaymentLineColumn.COST_RATE)
                        '    xlRan.Value = costPSRow.Item(PSEXCEL_CLOUMNMNAME_COST_RATE)
                        'END   変更管理#39（No.1544 MA復帰料金の統合)　2017/04 sugo

                    Case "43", "44"
                        xlRan = xlSheet.Cells(CInt(costPSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)), excelWrite.ExcelPaymentLineColumn.COST_RATE)
                        xlRan.Value = costPSRow.Item(PSEXCEL_CLOUMNMNAME_COST_RATE)
                        '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) Start
                    Case "47"
                        ''Cost単価
                        xlRan = xlSheet.Cells(CInt(costPSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)), excelWrite.ExcelPaymentLineColumn.COST)
                        xlRan.Value = GetRoundUpCost(costPSRow.Item(PSEXCEL_CLOUMNMNAME_COST))
                        '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) End
                    Case "1"
                        xlRan = xlSheet.Cells(CInt(costPSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)), excelWrite.ExcelPaymentLineColumn.COST_RATE)
                        xlRan.Value = costPSRow.Item(PSEXCEL_CLOUMNMNAME_COST_RATE)
                    Case Else
                        Continue For
                End Select

                ''Cost入力日をセット			
                xlRan = xlSheet.Cells(CInt(costPSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)), excelWrite.ExcelPaymentLineColumn.COST_INPUT_DATE)
                xlRan.Value = InputDay

                ''COST開示依頼をNにする
                xlRan = xlSheet.Cells(CInt(costPSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)), excelWrite.ExcelPaymentLineColumn.ST_COST)
                xlRan.Value = "N"

            Next

        Catch Ex As Exception
            Throw Ex

        Finally
            ''オブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlRan, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
        End Try

    End Sub


    ''' <summary>
    ''' 機　能：Cost開示PS情報を個別詳細　.xlsへ反映する。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub WriteDetailCostKaijiInfo(ByVal outputTargerDetailDataTable As DataTable,
                                         ByVal patternCD As String,
                                         ByVal newExist As String,
                                         ByRef DetailBook As Excel.Workbook)


        ''-----------------------------------
        ''個別詳細Bookへコスト情報を書き込む
        ''-----------------------------------
        Dim xlSheet As Excel.Worksheet
        Dim xlRan As Excel.Range
        Dim InputDay As String
        InputDay = Now.ToString("yyyy/MM/dd")

        Try
            xlSheet = DetailBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)
            For Each costDetailRow As DataRow In outputTargerDetailDataTable.Select


                ''Costをセット
                Select Case patternCD
                    Case "Topacs"
                        xlRan = xlSheet.Cells(CInt(costDetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_EXCELROW)), COLDETAIL_COST)
                        xlRan.Value = GetRoundUpCost(changeDBNullToZero(costDetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_COST)))
                    Case "4"
                        ''Cost単価
                        xlRan = xlSheet.Cells(CInt(costDetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_EXCELROW)), COLDETAIL_COST)
                        xlRan.Value = GetRoundUpCost(changeDBNullToZero(costDetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_COST)))
                    Case "31"
                        ''Cost単価
                        xlRan = xlSheet.Cells(CInt(costDetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_EXCELROW)), COLDETAIL_COST)
                        xlRan.Value = GetRoundUpCost(changeDBNullToZero(costDetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_COST)))
                    Case Else
                        Exit Sub
                End Select

                ''Cost入力日をセット			
                xlRan = xlSheet.Cells(CInt(costDetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_EXCELROW)), COLDETAIL_COST_INPUT_DATE)
                xlRan.Value = InputDay

            Next

        Catch Ex As Exception
            Throw Ex

        Finally
            ''オブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlRan, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
        End Try

    End Sub

    ''' <summary>
    ''' 機能：Cost開示ファイルのバックアップファイルの作成
    ''' 説明：
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Sub CreateBKCostkaijiFile(ByVal costKaijiFilePath As String)
        Try
            ''バックアップファイル名の取得
            Dim CostFileNM As String
            Dim BKFilePath As String
            Dim BKFileDir As String
            Dim BKFileNM As String

            ''フォルダ取得
            BKFileDir = Path.GetDirectoryName(costKaijiFilePath)

            ''ファイル名取得
            CostFileNM = Path.GetFileName(costKaijiFilePath)
            BKFileNM = GetCostKaijiBKFileNM(BKFileDir, CostFileNM)

            ''パス取得			
            BKFilePath = BKFileDir & "\" & BKFileNM

            ''BKファイルの作成(リネーム)
            System.IO.File.Move(costKaijiFilePath, BKFilePath)

        Catch ex As Exception

            Throw ex
        End Try

    End Sub


    ''' <summary>
    ''' 機能：Cost開示ファイルのバックアップファイル名の取得
    ''' 説明：
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>	
    Private Function GetCostKaijiBKFileNM(ByVal BKFileDir As String,
                                          ByVal CostFileNM As String) As String

        GetCostKaijiBKFileNM = ""

        ''フォルダ内の.xlsファイル名を全て取得
        Dim dirFileNMs() As String
        Dim costFolder As String
        dirFileNMs = System.IO.Directory.GetFiles(BKFileDir, "BK_*.xlsm")

        ''---------------------------------
        ''ファイル名プレフィクスの取得
        ''---------------------------------
        Dim filePrefix As String = ""
        Dim matchFileCount As Integer = 0
        Dim matchBKFileNMes() As String
        For Each dirFileNm As String In dirFileNMs

            dirFileNm = Path.GetFileName(dirFileNm)
            ''ファイル名が一致するBKファイルの取得
            If dirFileNm.IndexOf(CostFileNM) = ("BK_999").Length And
               CostFileNM.Length = dirFileNm.Length - ("BK_999").Length Then

                ReDim Preserve matchBKFileNMes(matchFileCount)
                matchBKFileNMes(matchFileCount) = dirFileNm
                matchFileCount = matchFileCount + 1

            End If
        Next

        ''プレフィクス番号が最大のファイル名を取得
        Dim tempFileNm As String
        If IsNothing(matchBKFileNMes) = False Then
            Call Array.Sort(matchBKFileNMes)
            tempFileNm = matchBKFileNMes(matchBKFileNMes.Length - 1)
            filePrefix = (CInt(tempFileNm.Substring("BK_".Length, "000".Length)) + 1).ToString.PadLeft(3, "0")
        End If

        ''BKファイルが存在しなければ、"000"とする。
        If filePrefix = "" Then
            filePrefix = "000"
        End If

        ''---------------------------------
        ''ファイル名の取得
        ''---------------------------------
        Dim rtnFileNM As String
        rtnFileNM = "BK_" & filePrefix & CostFileNM

        Return rtnFileNM

    End Function


    ''' <summary>
    ''' 機能：Cost開示ファイル取込処理の完了メッセージを作成する。
    ''' 説明：
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>	
    Private Function GreateExitMessage(ByVal outFileNMes() As String,
                                       ByVal inCntPSes() As Integer,
                                       ByVal outCntPSes() As Integer,
                                       ByVal outErrMessage() As String) As String

        Dim rtnMessage As String
        Dim isFirst As Boolean = True
        Dim outMessageLine As New StringBuilder
        Dim ImportErrFileNm As New ArrayList

        For i As Integer = 0 To outFileNMes.Length - 1

            ''エラー行の初期化
            outMessageLine.Remove(0, outMessageLine.Length)

            ''-----------------------------------
            ''ファイル名記入
            ''-----------------------------------
            outMessageLine.Append("【")
            outMessageLine.Append(outFileNMes(i).PadRight(40))
            outMessageLine.Append("】")

            ''-----------------------------------
            ''例外エラーの処理			
            ''-----------------------------------
            If IsNothing(outErrMessage(i)) = False AndAlso
                outErrMessage(i) <> "" Then

                outMessageLine.Append(" ■処理中にエラーが発生しました：")
                outMessageLine.Append(outErrMessage(i))
                outMessageLine.Append(vbCrLf)
                rtnMessage = rtnMessage & outMessageLine.ToString

                Continue For

            End If

            ''-----------------------------------
            ''処理件数記述			
            ''-----------------------------------
            ''個別PSのデータ反映件数 < COST開示のデータ件数の場合、個別PSのデータ件数に合わせる。
            If outCntPSes(i) > inCntPSes(i) Then
                outCntPSes(i) = inCntPSes(i)
            End If

            ''Cost開示ファイルの件数 < 個別ＰＳファイルの反映件数の場合、取込残があるファイル名を保管
            If outCntPSes(i) < inCntPSes(i) Then
                ImportErrFileNm.Add(outFileNMes(i).PadRight(40))
            End If

            outMessageLine.Append(vbCrLf)
            outMessageLine.Append("　■正常：" & outCntPSes(i) & "件")
            outMessageLine.Append(Space(8 - CStr(outCntPSes(i)).Length))
            outMessageLine.Append("未取込：" & inCntPSes(i) - outCntPSes(i) & "件")

            If isFirst Then
                isFirst = False
                rtnMessage = rtnMessage & outMessageLine.ToString
            Else
                rtnMessage = rtnMessage & vbCrLf & outMessageLine.ToString
            End If
        Next

        ''取込残があるファイル名を一覧で出力
        isFirst = True
        For Each fileNm As String In ImportErrFileNm
            If isFirst Then
                rtnMessage = rtnMessage + vbCrLf
                rtnMessage = rtnMessage + vbCrLf
                rtnMessage = rtnMessage + "以下のCost開示ファイルに取込残があります。確認してください。"
                rtnMessage = rtnMessage + vbCrLf
                isFirst = False
            Else
                rtnMessage = rtnMessage + vbCrLf
            End If
            rtnMessage = rtnMessage + "  " + fileNm
        Next

        Return rtnMessage

    End Function

    Private Sub GetOutputLine(ByVal patternCD As String,
                              ByVal CostKaijiPSSheetData As DataTable,
                              ByVal CostKaijiDetailSheetData As DataTable,
                              ByRef outCntPS As Integer)

        outCntPS = 0

        Dim filter As New StringBuilder
        Dim rows() As DataRow
        Select Case patternCD
            Case "1", "2", "4"
                For Each costKaijiRow As DataRow In CostKaijiPSSheetData.Select
                    filter.Remove(0, filter.Length)
                    filter.Append(PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)))
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME)))
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)))
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(costKaijiRow(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)))
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(PSDETAILEXCEL_CLOUMNMNAME_SPECIAL_FEATURE)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(""))
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(COSTPSEXCEL_CLOUMNMNAME_COST)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(""))
                    rows = CostKaijiDetailSheetData.Select(filter.ToString)

                    ''コストが不正なデータは出力件から除外する。
                    If rows.Length > 0 Then
                        Continue For
                    End If

                    outCntPS = outCntPS + 1

                Next

            Case "3", "12", "20", "23"
                filter.Append(COSTPSEXCEL_CLOUMNMNAME_COST)
                filter.Append(CommonConstant.SQL_STR_NOT_EQUAL)
                filter.Append(StringEdit.EncloseSingleQuotation(""))
                rows = CostKaijiPSSheetData.Select(filter.ToString)
                outCntPS = rows.Length

            Case "13", "14", "15", "16", "17", "18", "19"
                filter.Append(COSTPSEXCEL_CLOUMNMNAME_COST_RATE)
                filter.Append(CommonConstant.SQL_STR_NOT_EQUAL)
                filter.Append(StringEdit.EncloseSingleQuotation(""))
                rows = CostKaijiPSSheetData.Select(filter.ToString)
                outCntPS = rows.Length

        End Select

    End Sub

    ''' <summary>
    ''' 機　能：Cost単価の切り上げを行う。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetRoundUpCost(ByVal value As Object) As String

        ''初期値
        GetRoundUpCost = ""

        If IsNumeric(value) = True Then
            ''小数点以下切り上げ
            Return Math.Ceiling(CDec(value))
        End If

    End Function

    ''' <summary>
    ''' 機　能：Cost単価の四捨五入を行う。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetRoundCost(ByVal value As Object) As String

        ''初期値
        GetRoundCost = ""

        If IsNumeric(value) = True Then
            ''小数点以下四捨五入
            Return Math.Round(CDec(value))
        End If

    End Function

    ''' <summary>
    ''' 機　能：Warrent Logシート出力対象の個別PSのCost開示情報を取得
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetOutPSLogTargetData(ByVal CostKaijiPSSheetData As DataTable, _
                                           ByVal outputTargerPSDataTable As DataTable) As DataTable

        Dim rtnTable As DataTable
        rtnTable = CostKaijiPSSheetData.Copy

        ''Cost開示に出力済みのデータを削除
        Dim filter As New StringBuilder
        For Each outRow As DataRow In outputTargerPSDataTable.Rows

            ''行番号をKeyに検索　
            ''※行番号がプライマリになる。
            Dim tempRows() As DataRow
            filter.Remove(0, filter.Length)

            Dim patternCd As String
            Dim patternNm As String
            Dim newExist As String
            patternCd = outRow.Item(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
            patternNm = outRow.Item(PSEXCEL_CLOUMNMNAME_PATTERN)
            newExist = outRow.Item(PSEXCEL_CLOUMNMNAME_NEW_EXIST)

            ''取込み失敗情報を取得
            ''※概要：Cost開示ファイルのデータと出力対象のデータを比較して、取込み失敗データを取得する。
            Select Case patternCd
                Case "3",
                     "6",
                     "8",
                     "12",
                     "20",
                     "23",
                     "32",
                     "34",
                     "47"

                    ''パターン②
                    filter.Append(COSTPSEXCEL_CLOUMNMNAME_LINE_NO)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(outRow(PSEXCEL_CLOUMNMNAME_LINE_NO)))
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(COSTPSEXCEL_CLOUMNMNAME_PATTERN_CD)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(outRow(PSEXCEL_CLOUMNMNAME_PATTERN_CD)))
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(COSTPSEXCEL_CLOUMNMNAME_LIST_PRICE_REFLESH)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(outRow(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH)))
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(outRow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)))

                Case "13",
                     "14",
                     "17",
                     "18",
                     "19"
                    ''パターン④
                    filter.Append(COSTPSEXCEL_CLOUMNMNAME_PATTERN_CD)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(outRow(PSEXCEL_CLOUMNMNAME_PATTERN_CD)))
                    filter.Append(CommonConstant.SQL_STR_AND)
                    filter.Append(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                    filter.Append(CommonConstant.SQL_STR_EQUAL)
                    filter.Append(StringEdit.EncloseSingleQuotation(outRow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)))

                Case "15",
                     "16"
                    ''新規/既存に応じて変更
                    If newExist <> "既存" Then
                        ''パターン③
                        filter.Append(COSTPSEXCEL_CLOUMNMNAME_LINE_NO)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(outRow(PSEXCEL_CLOUMNMNAME_LINE_NO)))
                        filter.Append(CommonConstant.SQL_STR_AND)
                        filter.Append(COSTPSEXCEL_CLOUMNMNAME_PATTERN_CD)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(outRow(PSEXCEL_CLOUMNMNAME_PATTERN_CD)))
                        filter.Append(CommonConstant.SQL_STR_AND)
                        filter.Append(COSTPSEXCEL_CLOUMNMNAME_LIST_PRICE_REFLESH)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(outRow(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH)))
                        filter.Append(CommonConstant.SQL_STR_AND)
                        filter.Append(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(outRow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)))

                    Else
                        ''パターン③
                        filter.Append(COSTPSEXCEL_CLOUMNMNAME_LINE_NO)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(outRow(PSEXCEL_CLOUMNMNAME_LINE_NO)))
                        filter.Append(CommonConstant.SQL_STR_AND)
                        filter.Append(COSTPSEXCEL_CLOUMNMNAME_PATTERN_CD)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(outRow(PSEXCEL_CLOUMNMNAME_PATTERN_CD)))
                        filter.Append(CommonConstant.SQL_STR_AND)
                        filter.Append(COSTPSEXCEL_CLOUMNMNAME_LIST_PRICE_REFLESH)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(outRow(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH)))
                        filter.Append(CommonConstant.SQL_STR_AND)
                        filter.Append(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(outRow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)))
                    End If
                Case "25"
                    ''取込み失敗情報を取得
                    ''※概要：Cost開示ファイルのデータと出力対象のデータを比較して、取込み失敗データを取得する。
                    Select Case patternNm
                        Case CommonConstant.PATTERNNM_IBM_HW_QCOS,
                             CommonConstant.PATTERNNM_HWBrandSW_QCOS,
                             CommonConstant.PATTERNNM_HWBrandSWMA_QCOS,
                             CommonConstant.PATTERNNM_VLS,
                             CommonConstant.PATTERNNM_OtherMVMS,
                             CommonConstant.PATTERNNM_MAINTENANCE,
                             CommonConstant.PATTERNNM_FMA,
                             CommonConstant.PATTERNNM_SYSTEMSERVICE,
                             CommonConstant.PATTERNNM_MSS

                            ''パターン②
                            filter.Append(COSTPSEXCEL_CLOUMNMNAME_LINE_NO)
                            filter.Append(CommonConstant.SQL_STR_EQUAL)
                            filter.Append(StringEdit.EncloseSingleQuotation(outRow(PSEXCEL_CLOUMNMNAME_LINE_NO)))
                            filter.Append(CommonConstant.SQL_STR_AND)
                            filter.Append(COSTPSEXCEL_CLOUMNMNAME_PATTERN_CD)
                            filter.Append(CommonConstant.SQL_STR_EQUAL)
                            filter.Append(StringEdit.EncloseSingleQuotation(outRow(PSEXCEL_CLOUMNMNAME_PATTERN_CD)))
                            filter.Append(CommonConstant.SQL_STR_AND)
                            filter.Append(COSTPSEXCEL_CLOUMNMNAME_LIST_PRICE_REFLESH)
                            filter.Append(CommonConstant.SQL_STR_EQUAL)
                            filter.Append(StringEdit.EncloseSingleQuotation(outRow(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH)))
                            filter.Append(CommonConstant.SQL_STR_AND)
                            filter.Append(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                            filter.Append(CommonConstant.SQL_STR_EQUAL)
                            filter.Append(StringEdit.EncloseSingleQuotation(outRow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)))

                        Case CommonConstant.PATTERNNM_HWServicePac,
                             CommonConstant.PATTERNNM_SWServicePac,
                             CommonConstant.PATTERNNM_IBM_HWMA_QCOS,
                             CommonConstant.PATTERNNM_IBM_HWMA_AAS_WarrantyOP,
                             CommonConstant.PATTERNNM_IBM_HWMA_QCOS_WarrantyOP

                            ''パターン④
                            filter.Append(COSTPSEXCEL_CLOUMNMNAME_PATTERN_CD)
                            filter.Append(CommonConstant.SQL_STR_EQUAL)
                            filter.Append(StringEdit.EncloseSingleQuotation(outRow(PSEXCEL_CLOUMNMNAME_PATTERN_CD)))
                            filter.Append(CommonConstant.SQL_STR_AND)
                            filter.Append(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                            filter.Append(CommonConstant.SQL_STR_EQUAL)
                            filter.Append(StringEdit.EncloseSingleQuotation(outRow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)))

                        Case CommonConstant.PATTERNNM_IBM_HWMA_AAS_BOX,
                             CommonConstant.PATTERNNM_IBM_HWMA_AAS_MES
                            ''新規/既存に応じて変更
                            If newExist <> "既存" Then
                                ''パターン③
                                filter.Append(COSTPSEXCEL_CLOUMNMNAME_LINE_NO)
                                filter.Append(CommonConstant.SQL_STR_EQUAL)
                                filter.Append(StringEdit.EncloseSingleQuotation(outRow(PSEXCEL_CLOUMNMNAME_LINE_NO)))
                                filter.Append(CommonConstant.SQL_STR_AND)
                                filter.Append(COSTPSEXCEL_CLOUMNMNAME_PATTERN_CD)
                                filter.Append(CommonConstant.SQL_STR_EQUAL)
                                filter.Append(StringEdit.EncloseSingleQuotation(outRow(PSEXCEL_CLOUMNMNAME_PATTERN_CD)))
                                filter.Append(CommonConstant.SQL_STR_AND)
                                filter.Append(COSTPSEXCEL_CLOUMNMNAME_LIST_PRICE_REFLESH)
                                filter.Append(CommonConstant.SQL_STR_EQUAL)
                                filter.Append(StringEdit.EncloseSingleQuotation(outRow(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH)))
                                filter.Append(CommonConstant.SQL_STR_AND)
                                filter.Append(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                                filter.Append(CommonConstant.SQL_STR_EQUAL)
                                filter.Append(StringEdit.EncloseSingleQuotation(outRow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)))

                            Else
                                ''パターン③
                                filter.Append(COSTPSEXCEL_CLOUMNMNAME_LINE_NO)
                                filter.Append(CommonConstant.SQL_STR_EQUAL)
                                filter.Append(StringEdit.EncloseSingleQuotation(outRow(PSEXCEL_CLOUMNMNAME_LINE_NO)))
                                filter.Append(CommonConstant.SQL_STR_AND)
                                filter.Append(COSTPSEXCEL_CLOUMNMNAME_PATTERN_CD)
                                filter.Append(CommonConstant.SQL_STR_EQUAL)
                                filter.Append(StringEdit.EncloseSingleQuotation(outRow(PSEXCEL_CLOUMNMNAME_PATTERN_CD)))
                                filter.Append(CommonConstant.SQL_STR_AND)
                                filter.Append(COSTPSEXCEL_CLOUMNMNAME_LIST_PRICE_REFLESH)
                                filter.Append(CommonConstant.SQL_STR_EQUAL)
                                filter.Append(StringEdit.EncloseSingleQuotation(outRow(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH)))
                                filter.Append(CommonConstant.SQL_STR_AND)
                                filter.Append(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                                filter.Append(CommonConstant.SQL_STR_EQUAL)
                                filter.Append(StringEdit.EncloseSingleQuotation(outRow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)))
                            End If
                    End Select
            End Select

            tempRows = rtnTable.Select(filter.ToString)

            ''Cost開示読込み対象のデータを削除する。
            If tempRows.Length > 0 Then
                rtnTable.Rows.Remove(tempRows(0))
            End If
        Next

        Return rtnTable

    End Function


    ''' <summary>
    ''' 機　能：Warrent Logシート出力対象の個別詳細のCost開示情報を取得
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetOutDetailLogTargetData(ByVal CostKaijiDetailSheetData As DataTable, _
                                               ByVal outputTargerDetailDataTable As DataTable) As DataTable

        Dim rtnTable As DataTable
        rtnTable = CostKaijiDetailSheetData.Copy

        ''-----------------------------------
        ''Cost開示に出力済みのデータを削除
        ''-----------------------------------
        Dim filter As New StringBuilder
        For Each outRow As DataRow In outputTargerDetailDataTable.Rows

            Dim tempRows() As DataRow
            filter.Remove(0, filter.Length)
            filter.Append(PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(outRow.Item(PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(outRow.Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME)))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(outRow.Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(outRow.Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append(PSDETAILEXCEL_CLOUMNMNAME_SEQ)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(outRow.Item(PSDETAILEXCEL_CLOUMNMNAME_SEQ)))

            tempRows = rtnTable.Select(filter.ToString)

            If tempRows.Length > 0 Then
                ''Cost開示読込み対象のデータを削除する。
                rtnTable.Rows.Remove(tempRows(0))
            End If

        Next

        ''-----------------------------------
        ''特殊フューチャー、変更前構成データを削除
        ''-----------------------------------
        filter.Remove(0, filter.Length)
        filter.Append(PSDETAILEXCEL_CLOUMNMNAME_MES_CATEGORY)
        filter.Append(" IN ")
        filter.Append("( 'F','T','R','CR' )")
        filter.Append(CommonConstant.SQL_STR_OR)
        filter.Append(PSDETAILEXCEL_CLOUMNMNAME_SPECIAL_FEATURE)
        filter.Append(CommonConstant.SQL_STR_NOT_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(""))
        For Each tempRow As DataRow In rtnTable.Select(filter.ToString)
            ''特殊フューチャー、変更前構成データを削除する。
            rtnTable.Rows.Remove(tempRow)
        Next

        Return rtnTable

    End Function


    ''' <summary>
    ''' 機　能：Cost開示ファイルのWarrent Logシート出力処理
    ''' 説　明：※個別PSで開示した場合の処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub OutCostKaijiPSLogSheet(ByVal PSLogTargetData As DataTable, _
                                       ByRef CostKaijiBook As Excel.Workbook, _
                                       ByVal PsRowsCounst As Integer)

        Dim xlWarrentLogSheet As Excel.Worksheet
        Dim xlTempSheet As Excel.Worksheet
        Dim xlRange As Excel.Range

        Try

            ''Err情報がなければ終了
            If PSLogTargetData.Rows.Count = 0 Then
                If PsRowsCounst > 0 Then
                    Dim sheetCount As Integer
                    sheetCount = CostKaijiBook.Worksheets.Count
                    Dim i As Integer
                    For i = 1 To sheetCount
                        If CostKaijiBook.Worksheets(i).Name = ExcelWrite.EXCEL_COSTDATE_REFSHEET Then
                            xlWarrentLogSheet = CostKaijiBook.Worksheets(ExcelWrite.EXCEL_COSTDATE_REFSHEET)
                            xlRange = xlWarrentLogSheet.Range("AC" & ExcelWrite.EXCEL_COST_REF_OUTROW & ":" & "AC" & ExcelWrite.EXCEL_COST_REF_OUTROW + PsRowsCounst - 1)
                            xlRange.Value = ""
                        End If
                        If CostKaijiBook.Worksheets(i).Name = ExcelWrite.EXCEL_COSTDATE_PSSHEET Then
                            xlWarrentLogSheet = CostKaijiBook.Worksheets(ExcelWrite.EXCEL_COSTDATE_PSSHEET)
                            xlRange = xlWarrentLogSheet.Range("AJ" & ExcelWrite.EXCEL_COST_PAYMENT_OUTROW & ":" & "AJ" & ExcelWrite.EXCEL_COST_PAYMENT_OUTROW + PsRowsCounst - 1)
                            xlRange.Value = ""
                        End If
                    Next
                End If
                Exit Sub
            End If

            ''既存HWMAAASの場合、参考シートにログを書く
            Dim patternCd As String
            Dim newExist As String
            patternCd = ChangePatternCD(ExcelWrite.changeDBNullToString(PSLogTargetData.Rows(0).Item(COSTPSEXCEL_CLOUMNMNAME_PATTERN_CD)), _
                                        ExcelWrite.changeDBNullToString(PSLogTargetData.Rows(0).Item(COSTPSEXCEL_CLOUMNMNAME_PATTERN_NM)))
            newExist = PSLogTargetData.Rows(0).Item(COSTPSEXCEL_CLOUMNMNAME_NEW_EXIST)
            If (patternCd = CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_BOX Or patternCd = CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_MES) And _
               newExist = "既存" Then
                xlWarrentLogSheet = CostKaijiBook.Worksheets(ExcelWrite.EXCEL_COSTDATE_REFSHEET)
                If PsRowsCounst > 0 Then
                    xlRange = xlWarrentLogSheet.Range("AC" & ExcelWrite.EXCEL_COST_REF_OUTROW & ":" & "AC" & ExcelWrite.EXCEL_COST_REF_OUTROW + PsRowsCounst - 1)
                    xlRange.Value = ""
                End If
            Else
                xlWarrentLogSheet = CostKaijiBook.Worksheets(ExcelWrite.EXCEL_COSTDATE_PSSHEET)
                If PsRowsCounst > 0 Then
                    xlRange = xlWarrentLogSheet.Range("AJ" & ExcelWrite.EXCEL_COST_PAYMENT_OUTROW & ":" & "AJ" & ExcelWrite.EXCEL_COST_PAYMENT_OUTROW + PsRowsCounst - 1)
                    xlRange.Value = ""
                End If
            End If

            ''ログを出力
            Dim outMesseage As String
            For Each row As DataRow In PSLogTargetData.Rows

                If (patternCd = CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_BOX Or patternCd = CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_MES) And _
                    newExist = "既存" Then
                    xlRange = xlWarrentLogSheet.Range("AC" & ExcelWrite.EXCEL_COST_REF_OUTROW + CInt(row.Item(COSTPSEXCEL_CLOUMNMNAME_EXCELROW)) - 1)
                Else
                    xlRange = xlWarrentLogSheet.Range("AJ" & ExcelWrite.EXCEL_COST_PAYMENT_OUTROW + CInt(row.Item(COSTPSEXCEL_CLOUMNMNAME_EXCELROW)) - 1)
                End If

                outMesseage = "行番" +
                                row.Item(PSEXCEL_CLOUMNMNAME_LINE_NO) +
                                "の取込が失敗しました。"

                Select Case patternCd

                    Case "3",
                         "6",
                         "8",
                         "20",
                         "23",
                         "32",
                         "34",
                         "39",
                         "47"

                        ''パターン②
                        Select Case row.Item(COSTPSEXCEL_CLOUMNMNAME_NGREASON)
                            Case COST_NGREASON_COSTINPUTERR
                                outMesseage = outMesseage + "取込ﾃﾞｰﾀに空白、もしくは文字列が設定されています。"
                            Case COST_NGREASON_UNMATCHCOSTPSTOPSDATE
                                outMesseage = outMesseage + "行番号、パターンコード、項目１、ListPriceが一致するデータが存在しません。"
                        End Select

                    Case "1",
                         "12",
                         "13",
                         "14",
                         "17",
                         "18",
                         "19",
                         "40",
                         "41",
                         "43",
                         "44"

                        ''パターン④

                        Select Case row.Item(COSTPSEXCEL_CLOUMNMNAME_NGREASON)
                            Case COST_NGREASON_COSTINPUTERR
                                outMesseage = outMesseage + "取込ﾃﾞｰﾀに空白、もしくは文字列が設定されています。"
                            Case COST_NGREASON_UNMATCHCOSTPSTOPSDATE
                                outMesseage = outMesseage + "パターンコード、項目１が一致するデータが存在しません。"
                        End Select

                    Case "15",
                         "16"

                        ''新規/既存に応じて変更
                        If newExist <> "既存" Then
                            ''パターン③
                            Select Case row.Item(COSTPSEXCEL_CLOUMNMNAME_NGREASON)
                                Case COST_NGREASON_COSTINPUTERR
                                    outMesseage = outMesseage + "取込ﾃﾞｰﾀに空白、もしくは文字列が設定されています。"
                                Case COST_NGREASON_UNMATCHCOSTPSTOPSDATE
                                    outMesseage = outMesseage + "行番号、パターンコード、項目１、ListPriceが一致するデータが存在しません。"
                            End Select

                        Else
                            ''パターン③
                            Select Case row.Item(COSTPSEXCEL_CLOUMNMNAME_NGREASON)
                                Case COST_NGREASON_COSTINPUTERR
                                    outMesseage = outMesseage + "取込ﾃﾞｰﾀに空白、もしくは文字列が設定されています。"
                                Case COST_NGREASON_UNMATCHCOSTPSTOPSDATE
                                    outMesseage = outMesseage + "行番号、パターンコード、項目１、ListPriceが一致するデータが存在しません。"
                            End Select

                        End If
                End Select
                xlRange.Value = outMesseage

            Next
        Catch ex As Exception
            Throw ex

        Finally
            ''Excelオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlTempSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlWarrentLogSheet, ExcelObjRelease.OBJECT_NOTHING)
        End Try
    End Sub

    ''' <summary>
    ''' 機　能：Cost開示ファイルのWarrent Logシート出力処理
    ''' 説　明：※個別詳細シートで開示した場合の処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub OutCostKaijiDetailLogSheet(ByVal DetailLogTargetData As DataTable, _
                                           ByRef CostKaijiBook As Excel.Workbook,
                                           ByVal DetailRowCount As Integer)

        Dim xlWarrentLogSheet As Excel.Worksheet
        Dim xlTempSheet As Excel.Worksheet
        Dim xlRange As Excel.Range

        Try

            ''シートをセット
            Dim outMesseage As String
            xlWarrentLogSheet = CostKaijiBook.Worksheets(ExcelWrite.EXCEL_COSTDATE_DETAILSHEET)

            ''書込前に初期化
            If DetailRowCount > 0 Then
                xlRange = xlWarrentLogSheet.Range("S" & ExcelWrite.EXCEL_COST_DETAIL_OUTROW & ":" & "S" & ExcelWrite.EXCEL_COST_DETAIL_OUTROW + DetailRowCount - 1)
                xlRange.Value = ""
            End If

            ''ログを出力
            For Each row As DataRow In DetailLogTargetData.Rows

                ''メッセージの作成
                outMesseage = ""
                Select Case row.Item(COSTPSEXCEL_CLOUMNMNAME_NGREASON)
                    Case COST_NGREASON_COSTINPUTERR
                        outMesseage = "取込ﾃﾞｰﾀに空白、もしくは文字列が設定されています。"

                    Case COST_NGREASON_UNMATCHCOSTPSTOCOSTDETAIL
                        outMesseage = "Cost開示ファイルのOBAMA-PSAシートとKEY情報が一致しませんでした。" & _
                                      "    KEY情報：契約順番、ﾌｧｲﾙ名、ﾌｧｲﾙ名Suffix、ﾌｧｲﾙ内Suffix"

                    Case COST_NGREASON_UNMATCHCOSTPSTOPSDATE
                        outMesseage = "Cost開示ファイルのOBAMA-PSシートと個別PSファイルのOBAMA-PSシートのKEY情報が一致しませんでした。" & _
                                      "    KEY情報：契約順番、ﾌｧｲﾙ名、ﾌｧｲﾙ名Suffix、ﾌｧｲﾙ内Suffix"

                    Case COST_NGREASON_QTYINPUTERR
                        outMesseage = "個別PSファイルの数量にマイナス、もしくは文字列が入力されているためCOST単価が算出できませんでした。"

                    Case COST_NGREASON_UNMATCHCOSTDETAILTOCOSTPS
                        outMesseage = "Cost開示ファイルのOBAMA-PSシートのKEY情報が一致しませんでした。" & _
                                      "    KEY情報：契約順番、ﾌｧｲﾙ名、ﾌｧｲﾙ名Suffix、ﾌｧｲﾙ内Suffix"

                    Case COST_NGREASON_UNMATCHCOSTDETAILTOPSDETAIL
                        outMesseage = "Cost開示ファイルの詳細シートとの個別詳細ファイルのKEY情報が一致しませんでした。" & _
                                      "    KEY情報：契約順番、ﾌｧｲﾙ名、ﾌｧｲﾙ名Suffix、ﾌｧｲﾙ内Suffix、SEQ"

                    Case COST_NGREASON_COSTCULCULATE
                        outMesseage = "COST %が正しく計算されていない為、取込対象外です。"
                End Select

                xlRange = xlWarrentLogSheet.Range("S" & ExcelWrite.EXCEL_COST_DETAIL_OUTROW + CInt(row.Item(COSTDETAILEXCEL_CLOUMNMNAME_EXCELROW)) - 1)
                xlRange.Value = outMesseage

            Next

        Catch ex As Exception
            Throw ex

        Finally
            ''Excelオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlTempSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlWarrentLogSheet, ExcelObjRelease.OBJECT_NOTHING)
        End Try

    End Sub

    ''' <summary>
    ''' 機　能：特殊フューチャーを含むデータかを判定する。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function ChkSFeature(ByVal PatternCd As String, _
                                 ByVal Pattern As String, _
                                 ByVal OPTION1 As Object) As Boolean

        ''初期化
        ChkSFeature = False

        ''パターンコードが直接入力以外
        If (PatternCd = "1" Or PatternCd = "2") And _
           (ExcelWrite.changeDBNullToString(PSEXCEL_CLOUMNMNAME_OPTION1) = "CBUﾌｨｰﾁｬｰ" Or _
            ExcelWrite.changeDBNullToString(PSEXCEL_CLOUMNMNAME_OPTION1) = "ﾏｲｸﾛｺｰﾄﾞﾌｨｰﾁｬｰ") Then

            ChkSFeature = True

        End If

        ''パターンコードが直接
        If (PatternCd = "25" And (Pattern = CommonConstant.PATTERNNM_IBM_HW_AAS_BOX Or Pattern = CommonConstant.PATTERNNM_IBM_HW_AAS_MES)) And _
           (ExcelWrite.changeDBNullToString(PSEXCEL_CLOUMNMNAME_OPTION1) = "CBUﾌｨｰﾁｬｰ" Or _
            ExcelWrite.changeDBNullToString(PSEXCEL_CLOUMNMNAME_OPTION1) = "ﾏｲｸﾛｺｰﾄﾞﾌｨｰﾁｬｰ") Then

            ChkSFeature = True

        End If

    End Function

    ''' <summary>
    ''' 機能：Nullチェック
    ''' 説明：値がNullの場合、0を返す
    ''' </summary>
    ''' <param name="Value"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Shared Function changeDBNullToZero(ByVal Value As Object) As String
        If IsNumeric(Value) Then
            Return Value.ToString
        Else
            Return "0"
        End If
    End Function


    ''' <summary>
    ''' 機能：直接入力のパターンCDを取得する。
    ''' 説明：
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ChangePatternCD(ByVal PatternCD As String, _
                                     ByVal PatternRN As String) As String

        ''初期化
        ChangePatternCD = ""

        If PatternCD <> CommonConstant.PATTERNCD_TYPE_DIRECTINPUT Then
            Return PatternCD
        Else
            Select Case PatternRN
                Case CommonConstant.PATTERNNM_INPUTORDER
                    Return CommonConstant.PATTERNCD_TYPE_INPUTORDER
                Case CommonConstant.PATTERNNM_IBM_HW_AAS_BOX
                    Return CommonConstant.PATTERNCD_TYPE_IBM_HW_AAS_BOX
                Case CommonConstant.PATTERNNM_IBM_HW_AAS_MES
                    Return CommonConstant.PATTERNCD_TYPE_IBM_HW_AAS_MES
                Case CommonConstant.PATTERNNM_IBM_HW_QCOS
                    Return CommonConstant.PATTERNCD_TYPE_IBM_HW_QCOS
                Case CommonConstant.PATTERNNM_HW_CISCO
                    Return CommonConstant.PATTERNCD_TYPE_HW_CISCO
                Case CommonConstant.PATTERNNM_HWBrandSW_AAS
                    Return CommonConstant.PATTERNCD_TYPE_HWBrandSW_AAS
                Case CommonConstant.PATTERNNM_HWBrandSW_QCOS
                    Return CommonConstant.PATTERNCD_TYPE_HWBrandSW_QCOS
                Case CommonConstant.PATTERNNM_HWBrandSWMA_AAS
                    Return CommonConstant.PATTERNCD_TYPE_HWBrandSWMA_AAS
                Case CommonConstant.PATTERNNM_HWBrandSWMA_QCOS
                    Return CommonConstant.PATTERNCD_TYPE_HWBrandSWMA_QCOS
                Case CommonConstant.PATTERNNM_SWBrandSW
                    Return CommonConstant.PATTERNCD_TYPE_SWBrandSW
                Case CommonConstant.PATTERNNM_SWBrandSWMA
                    Return CommonConstant.PATTERNCD_TYPE_SWBrandSWMA
                Case CommonConstant.PATTERNNM_PA
                    Return CommonConstant.PATTERNCD_TYPE_PA
                Case CommonConstant.PATTERNNM_VLS
                    Return CommonConstant.PATTERNCD_TYPE_VLS
                Case CommonConstant.PATTERNNM_HWServicePac
                    Return CommonConstant.PATTERNCD_TYPE_HWServicePac
                Case CommonConstant.PATTERNNM_SWServicePac
                    Return CommonConstant.PATTERNCD_TYPE_SWServicePac
                Case CommonConstant.PATTERNNM_IBM_HWMA_AAS_BOX
                    Return CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_BOX
                Case CommonConstant.PATTERNNM_IBM_HWMA_AAS_MES
                    Return CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_MES
                Case CommonConstant.PATTERNNM_IBM_HWMA_QCOS
                    Return CommonConstant.PATTERNCD_TYPE_IBM_HWMA_QCOS
                Case CommonConstant.PATTERNNM_IBM_HWMA_AAS_WarrantyOP
                    Return CommonConstant.PATTERNCD_TYPE_IBM_HWMA_AAS_WarrantyOP
                Case CommonConstant.PATTERNNM_IBM_HWMA_QCOS_WarrantyOP
                    Return CommonConstant.PATTERNCD_TYPE_IBM_HWMA_QCOS_WarrantyOP
                Case CommonConstant.PATTERNNM_OtherMVMS
                    Return CommonConstant.PATTERNCD_TYPE_OtherMVMS
                Case CommonConstant.PATTERNNM_CISCO_MAINTENANCE
                    Return CommonConstant.PATTERNCD_TYPE_CISCO_MAINTENANCE
                Case CommonConstant.PATTERNNM_SLink
                    Return CommonConstant.PATTERNCD_TYPE_SLink
                Case CommonConstant.PATTERNNM_MAINTENANCE
                    Return CommonConstant.PATTERNCD_TYPE_MAINTENANCE
                Case CommonConstant.PATTERNNM_HOST_SW
                    Return CommonConstant.PATTERNCD_TYPE_HOST_SW
                Case CommonConstant.PATTERNNM_DIRECTINPUT
                    Return CommonConstant.PATTERNCD_TYPE_DIRECTINPUT
                Case CommonConstant.PATTERNNM_HW_Brand_Service
                    Return CommonConstant.PATTERNCD_TYPE_HW_Brand_Service
                Case CommonConstant.PATTERNNM_SW_Brand_Service
                    Return CommonConstant.PATTERNCD_TYPE_SW_Brand_Service
                Case CommonConstant.PATTERNNM_UNIFICATION
                    Return CommonConstant.PATTERNCD_TYPE_UNIFICATION
                Case CommonConstant.PATTERNNM_IGF_INTERESTRATE
                    Return CommonConstant.PATTERNCD_TYPE_IGF_INTERESTRATE
                Case CommonConstant.PATTERNNM_IGF_RELEASE
                    Return CommonConstant.PATTERNCD_TYPE_IGF_RELEASE
                Case CommonConstant.PATTERNNM_IGF_USED
                    Return CommonConstant.PATTERNCD_TYPE_IGF_USED
                Case CommonConstant.PATTERNNM_FMA
                    Return CommonConstant.PATTERNCD_TYPE_FMA
                Case CommonConstant.PATTERNNM_OFFER
                    Return CommonConstant.PATTERNCD_TYPE_OFFER
                Case CommonConstant.PATTERNNM_SYSTEMSERVICE
                    Return CommonConstant.PATTERNCD_TYPE_SYSTEMSERVICE
                Case CommonConstant.PATTERNNM_COMMENT
                    Return CommonConstant.PATTERNCD_TYPE_COMMENT
                    '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) Start
                Case CommonConstant.PATTERNNM_MSS
                    Return CommonConstant.PATTERNCD_TYPE_MSS
                    '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) End
            End Select

        End If

    End Function


    ''' <summary>
    ''' 機能：Paymentの情報をArrayListに格納する。
    ''' 説明：
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetPaymentRowArrayList(ByVal PSFilePath As String) As ArrayList

        Dim rtnValue As New ArrayList

        ''Excelオブジェクトの宣言
        Dim xlApp As New Excel.Application
        Dim xlInBook As Excel.Workbook = Nothing
        Dim xlInSheet As Excel.Worksheet = Nothing
        Dim xlCell As Excel.Range = Nothing

        Try
            ''Excelの初期設定
            xlApp.EnableEvents = False
            xlApp.DisplayAlerts = False

            ''BookのOpen
            xlInBook = xlApp.Workbooks.Open(PSFilePath)
            xlInSheet = xlInBook.Worksheets("OBAMA-PS")

            ''Excelのオートフィルタを初期化
            Dim excelWrite As New ExcelWrite
            Call excelWrite.CrearAutoFilter(xlInSheet)

            ''OBAMA-PSシートのデータの取得
            Dim ExcelLine(,) As Object
            For i As Integer = EXCEL_PAYMENTLINEDATE_OUTROW To EXCEL_MAX_ROW

                ''行データの取得
                xlCell = xlInSheet.Range("A" & i & ":" & "IT" & i)
                ExcelLine = xlCell.Formula

                ''Eofの判定
                If CheckRowItem(ExcelLine) = False Then
                    Exit For
                End If

                ''値の追加
                Call rtnValue.Add(ExcelLine)

            Next

            Return rtnValue

        Catch ex As Exception
            Throw ex

        Finally
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True

            ''オブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlInSheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlInBook) = False Then
                xlInBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlInBook, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()

        End Try

    End Function

    '--------------------------------------------------------
    'メソッド名：GetBuBrandInfo
    '概    要  ：LOB名称が一致するConvertClientValueテーブルのBUとBrandを取得
    '説    明  ：※該当するデータが存在しなければ処理を行わない。
    '--------------------------------------------------------
    Private Function GetBuBrandInfo(ByVal ConvertClientValueData As DataTable, _
                                    ByVal subBrand As String) As String


        ''初期化 ※変換前の値で初期化
        GetBuBrandInfo = subBrand

        ''抽出条件
        Dim filter As New StringBuilder
        filter.Append(ConvertClientValueTable.COLUMN_NAME_ServerValue)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(subBrand))
        filter.Append(CommonConstant.SQL_STR_AND)
        filter.Append(ConvertClientValueTable.COLUMN_NAME_ClassCode)
        filter.Append(CommonConstant.SQL_STR_EQUAL)
        filter.Append(StringEdit.EncloseSingleQuotation(ConvertClientValueTable.CLASSCODE_IMPORTBRANDNAME))

        ''LOB名称と一致する変換テーブルの値を取得
        For Each row As DataRow In ConvertClientValueData.Select(filter.ToString)

            GetBuBrandInfo = ExcelWrite.changeDBNullToString(row.Item(ConvertClientValueTable.COLUMN_NAME_ClientValue))
            Exit Function

        Next

    End Function


    ''' <summary>
    ''' 機　能：参考シート出力用のデータを取得する。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetReferenceRows(ByRef PSDataTable As DataTable, _
                                      ByRef DelOverlapPSDataTable As DataTable) As DataRowCollection

        ''初期化
        Dim rtnValueTBL As DataTable
        rtnValueTBL = PSDataTable.Clone
        GetReferenceRows = rtnValueTBL.Rows

        ''依頼シートに紐づくPayment情報を取得する。
        Dim orderRow As DataRow
        Dim filter As New StringBuilder
        Dim refExcelRow As Integer = 5
        Dim refRowCount As Integer
        For Each orderRow In DelOverlapPSDataTable.Select("", PSEXCEL_CLOUMNMNAME_EXCELROW)

            filter.Length = 0
            filter.Append(PSEXCEL_CLOUMNMNAME_CONTRACTNO)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(orderRow(PSEXCEL_CLOUMNMNAME_CONTRACTNO)))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(orderRow(PSEXCEL_CLOUMNMNAME_PATTERN_CD)))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(orderRow(PSEXCEL_CLOUMNMNAME_PATTERN)))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(ChangeNothingToBrank(orderRow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01))))

            Dim isFirst As Boolean = True
            refRowCount = 0
            For Each insRows As DataRow In PSDataTable.Select(filter.ToString, PSEXCEL_CLOUMNMNAME_LINE_NO)
                ''参考シートの参照元のExcel行位置
                ''※例)参照元：7行目 ⇒ 参考シート：10～12行目（7をセット）　
                If isFirst = True Then
                    refExcelRow += 1
                End If
                isFirst = False
                insRows(PSEXCEL_CLOUMNMNAME_EXCELROW) = refExcelRow

                ''参照元1行につき、何件の参考シート行が存在するかカウント
                refRowCount += 1
                orderRow(PSEXCEL_CLOUMNMNAME_REFERENCE_ROWCOUNT) = refRowCount

                rtnValueTBL.ImportRow(insRows)
            Next
        Next
        Return rtnValueTBL.Rows
    End Function

    ''' <summary>
    ''' 機　能：個別PSファイルから参考シートへ出力対象の行をコピー&ペーストする。
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub CopyReferenceRows(ByRef xlOutBook As Excel.Workbook, _
                                  ByVal rows As DataRowCollection, _
                                  ByVal PSRowCount As Integer)

        Dim outSheet As Excel.Worksheet
        Dim inRange As Excel.Range
        Dim outRange As Excel.Range
        Dim entryRange As Excel.Range
        Dim enColumns As Excel.Range

        Try

            'シートのセット
            outSheet = xlOutBook.Worksheets("参考シート")
            outSheet.Visible = True

            '書式行のExcel式を取得する。
            Dim excelFormula(,) As Object
            inRange = outSheet.Rows(2)
            excelFormula = inRange.FormulaR1C1

            Dim copyValue(rows.Count, 27) As Object
            Dim TmpFomula As String
            Const CostFomula As String = "=VLookUp( J@1" & "&" & """" & "," & """" & "&" & _
                                                   "K@1" & "&" & """" & "," & """" & "&" & _
                                                   "L@1" & "," & _
                                                   "'Payment'!AH$@2:AI$@3" & "," & _
                                                   "2" & "," & _
                                                   "FALSE" & ")"

            For i As Integer = 0 To rows.Count - 1

                ''対象の出力データを格納
                copyValue(i, 0) = rows(i).Item(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)
                copyValue(i, 1) = rows(i).Item(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
                If IsNumeric(rows(i).Item(PSEXCEL_CLOUMNMNAME_LINE_NO)) = True Then
                    copyValue(i, 2) = CInt(rows(i).Item(PSEXCEL_CLOUMNMNAME_LINE_NO))
                Else
                    copyValue(i, 2) = ""
                End If
                copyValue(i, 3) = rows(i).Item(PSEXCEL_CLOUMNMNAME_FILE_NAME)
                copyValue(i, 4) = rows(i).Item(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
                copyValue(i, 5) = rows(i).Item(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
                copyValue(i, 6) = rows(i).Item(PSEXCEL_CLOUMNMNAME_CONTRACTNO)
                copyValue(i, 7) = rows(i).Item(PSEXCEL_CLOUMNMNAME_ST_COST)
                copyValue(i, 8) = rows(i).Item(PSEXCEL_CLOUMNMNAME_NEW_EXIST)
                copyValue(i, 9) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                copyValue(i, 10) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PATTERN)
                copyValue(i, 11) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                copyValue(i, 12) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM03)
                copyValue(i, 13) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM02)
                copyValue(i, 14) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM11)
                copyValue(i, 15) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM12)
                copyValue(i, 16) = rows(i).Item(PSEXCEL_CLOUMNMNAME_QTY)
                copyValue(i, 17) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PAYSTRYM)
                copyValue(i, 18) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PAYENDYM)
                copyValue(i, 19) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PAY_MONTHS)
                copyValue(i, 20) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PAY_METHOD)
                copyValue(i, 21) = rows(i).Item(PSEXCEL_CLOUMNMNAME_LIST_PRICE_REFLESH)
                copyValue(i, 22) = rows(i).Item(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH)
                copyValue(i, 23) = rows(i).Item(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_IOC)
                copyValue(i, 24) = rows(i).Item(PSEXCEL_CLOUMNMNAME_COST_RATE)
                copyValue(i, 25) = rows(i).Item(PSEXCEL_CLOUMNMNAME_COST)
                copyValue(i, 26) = rows(i).Item(PSEXCEL_CLOUMNMNAME_COST_TOTAL)
                copyValue(i, 27) = rows(i).Item(PSEXCEL_CLOUMNMNAME_COST_INPUT_DATE)

                'Cost%は、依頼シートの値の参照式をセット                
                TmpFomula = CostFomula
                TmpFomula = TmpFomula.Replace("@1", i + EXCEL_PAYMENTLINEDATE_OUTROW)
                TmpFomula = TmpFomula.Replace("@2", EXCEL_PAYMENTLINEDATE_OUTROW)
                TmpFomula = TmpFomula.Replace("@3", EXCEL_PAYMENTLINEDATE_OUTROW + PSRowCount)
                copyValue(i, 24) = TmpFomula

                'Template行にExcel式がある場合、式をセットする。
                Dim j As Integer
                For j = 0 To 27
                    If excelFormula(1, j + 1).IndexOf("=") <> -1 Then
                        copyValue(i, j) = excelFormula(1, j + 1)
                    End If
                Next

            Next

            ''書式をコピー & ペースト
            Dim copyArea As String = "A" & EXCEL_PAYMENTLINEDATE_OUTROW & ":" & "AB" & EXCEL_PAYMENTLINEDATE_OUTROW + rows.Count - 1
            inRange = outSheet.Range("A2:AB2")
            inRange.Copy()
            outRange = outSheet.Range(copyArea)
            outRange.PasteSpecial()

            ''値をセット
            outRange.Formula = copyValue

        Catch ex As Exception
            Throw ex

        Finally
            ''オブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(outSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(inRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(outRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(entryRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(enColumns, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Sub

    ''' <summary>
    ''' 機　能：Cost開示ファイルの参考シート配列情報をデータテーブルへ格納する
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetCostRefDataTable(ByVal Obj(,) As Object) As DataTable

        ''データテーブルの定義
        Dim rtnDataTable As New DataTable

        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_LINE_NO)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_CONTRACTNO)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_NEW_EXIST)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_PATTERN_CD)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_PATTERN_NM)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM01)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM02)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_QTY)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_LIST_PRICE_REFLESH)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_COST_RATE)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_COST)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_EXCELROW)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_NGREASON)

        ''項目の位置
        Const Column_LINE_NO As Integer = 3
        Const Column_FILE_NAME As Integer = 4
        Const Column_FILE_NAME_SUFFIX As Integer = 5
        Const Column_FILE_NAME_SUFFIX_INTR As Integer = 6
        Const Column_CONTRACTNO As Integer = 7
        Const Column_NEW_EXIST As Integer = 9
        Const Column_PATTERN_CD As Integer = 10
        Const Column_PATTERN_NM As Integer = 11
        Const Column_PROD_ITEM01 As Integer = 12
        Const Column_PROD_ITEM02 As Integer = 13
        Const Column_QTY As Integer = 17
        Const Column_LIST_PRICE_REFLESH As Integer = 23
        Const Column_COST_RATE As Integer = 25
        Const Column_COST As Integer = 26

        ''Excelの値をデータテーブルへセット
        Dim row As DataRow
        For i As Integer = 1 To Obj.GetLength(0)

            row = rtnDataTable.NewRow
            row(COSTPSEXCEL_CLOUMNMNAME_EXCELROW) = i

            row(COSTPSEXCEL_CLOUMNMNAME_LINE_NO) = ChangeNothingToBrank(Obj(i, Column_LINE_NO))
            row(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME) = ChangeNothingToBrank(Obj(i, Column_FILE_NAME))
            row(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX) = ChangeNothingToBrank(Obj(i, Column_FILE_NAME_SUFFIX))
            row(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR) = ChangeNothingToBrank(Obj(i, Column_FILE_NAME_SUFFIX_INTR))
            row(COSTPSEXCEL_CLOUMNMNAME_CONTRACTNO) = ChangeNothingToBrank(Obj(i, Column_CONTRACTNO))
            row(COSTPSEXCEL_CLOUMNMNAME_NEW_EXIST) = ChangeNothingToBrank(Obj(i, Column_NEW_EXIST))
            row(COSTPSEXCEL_CLOUMNMNAME_PATTERN_CD) = ChangeNothingToBrank(Obj(i, Column_PATTERN_CD))
            row(COSTPSEXCEL_CLOUMNMNAME_PATTERN_NM) = ChangeNothingToBrank(Obj(i, Column_PATTERN_NM))
            row(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM01) = ChangeNothingToBrank(Obj(i, Column_PROD_ITEM01))
            row(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM02) = ChangeNothingToBrank(Obj(i, Column_PROD_ITEM02))
            row(COSTPSEXCEL_CLOUMNMNAME_QTY) = ChangeNothingToBrank(Obj(i, Column_QTY))
            row(COSTPSEXCEL_CLOUMNMNAME_LIST_PRICE_REFLESH) = ChangeNothingToBrank(Obj(i, Column_LIST_PRICE_REFLESH))
            row(COSTPSEXCEL_CLOUMNMNAME_COST_RATE) = ChangeNothingToBrank(Obj(i, Column_COST_RATE))
            row(COSTPSEXCEL_CLOUMNMNAME_COST) = ChangeNothingToBrank(Obj(i, Column_COST))
            row(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = ""

            rtnDataTable.Rows.Add(row)
        Next

        Return rtnDataTable

    End Function

    ''' <summary>
    ''' 機　能：数値のチェック
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function chkNumber(ByVal Value As Object) As Boolean

        ''初期化
        chkNumber = False

        ''Null値チェック
        If ExcelWrite.changeDBNullToString(Value) = "" Then
            Exit Function
        End If

        ''標準関数で数値チェック
        If IsNumeric(Value) = False Then
            Exit Function
        End If

        ''IsNumericだと、8進数/16進数表現をOKにしてしまうため、文字列の入力チェックを行う。
        ''※補足：指数表現はOK
        Dim idx As Integer
        Dim valueLen As Integer
        Dim chkChar As Char
        valueLen = Value.ToString.Length - 1
        For idx = 0 To valueLen
            chkChar = Value.ToString.Substring(idx, 1)
            Select Case chkChar
                Case "0" To "9"
                Case "+", "-", ",", ".", "e", "E"
                Case Else
                    Exit Function
            End Select
        Next

        Return True
    End Function

    ''' <summary>
    ''' 機　能：Cost開示ファイルの情報をデータテーブルへ格納する
    ''' 説　明：※Topacs用の開示ﾌｧｲﾙを読込み
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetTopacsCostKaijiData(ByRef CostBook As Excel.Workbook, ByRef patternCD As String) As DataTable()

        ''初期化　※ﾃﾞｰﾀ0件 ⇒ Rows.count = 0で判定
        Dim rtnValue(2) As DataTable
        rtnValue(0) = New DataTable
        rtnValue(1) = New DataTable
        rtnValue(2) = New DataTable
        GetTopacsCostKaijiData = rtnValue

        ''Excel変数
        Dim xlAASSheet As Excel.Worksheet
        Dim xlQCOSHWSheet As Excel.Worksheet
        Dim xlQCOSSWSheet As Excel.Worksheet

        Try
            ''ｼｰﾄの存在ﾁｪｯｸ
            If ExistsTopacsSheet(CostBook) = False Then
                Exit Function
            Else
                patternCD = "Topacs"
            End If

            ''                      ▼以下、各シートの値を取得
            '' --------------------------------------------------------------------
            Call GetTopacsWorkSheet(CostBook, xlAASSheet, xlQCOSHWSheet, xlQCOSSWSheet)
            If IsNothing(xlAASSheet) = False Then
                rtnValue(0) = GetTopacsAASSheetData(xlAASSheet)
            End If

            If IsNothing(xlQCOSHWSheet) = False Then
                rtnValue(1) = GetTopacsQCOSHWSheetData(xlQCOSHWSheet)
            End If

            If IsNothing(xlQCOSSWSheet) = False Then
                rtnValue(2) = GetTopacsQCOSSWSheetData(xlQCOSSWSheet)
            End If

        Catch ex As Exception
            Throw ex

        Finally

            ''Excelオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlAASSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlQCOSHWSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlQCOSSWSheet, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()

        End Try

    End Function


    ''' <summary>
    ''' 機　能：Topacs用のCostシートチェック
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function ExistsTopacsSheet(ByRef CostBook As Excel.Workbook) As Boolean

        ''初期化
        ExistsTopacsSheet = False
        Dim xlSheet As Excel.Worksheet
        Try
            For Each xlSheet In CostBook.Worksheets

                ''1シートでも存在すればOK            
                Select Case xlSheet.Name
                    Case ExcelWrite.EXCEL_TOPACSDATE_AAS, _
                         ExcelWrite.EXCEL_TOPACSDATE_QCOSHW, _
                         ExcelWrite.EXCEL_TOPACSDATE_QCOSSW
                        ExistsTopacsSheet = True
                        Exit Function
                    Case Else
                End Select
            Next
        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Function


    ''' <summary>
    ''' 機　能：Topacs用シートの取得
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetTopacsWorkSheet(ByRef CostBook As Excel.Workbook, _
                                   ByRef xlAASSheet As Excel.Worksheet, _
                                   ByRef xlQCOSHWSheet As Excel.Worksheet, _
                                   ByRef xlQCOSSWSheet As Excel.Worksheet)

        ''初期化
        xlAASSheet = Nothing
        xlQCOSHWSheet = Nothing
        xlQCOSSWSheet = Nothing

        ''シートを取得
        Dim xlSheet As Excel.Worksheet
        Try
            For Each xlSheet In CostBook.Worksheets
                Select Case xlSheet.Name
                    Case ExcelWrite.EXCEL_TOPACSDATE_AAS
                        xlAASSheet = xlSheet

                    Case ExcelWrite.EXCEL_TOPACSDATE_QCOSHW
                        xlQCOSHWSheet = xlSheet

                    Case ExcelWrite.EXCEL_TOPACSDATE_QCOSSW
                        xlQCOSSWSheet = xlSheet

                End Select

            Next

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub


    ''' <summary>
    ''' 機　能：AASHWｼｰﾄをデータテーブルへ格納する
    ''' 説　明：※Topacs用の開示ﾌｧｲﾙを読込み
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetTopacsAASSheetData(ByRef xlAASSheet As Excel.Worksheet) As DataTable

        ''初期化
        Dim rtnTBL As New DataTable
        GetTopacsAASSheetData = rtnTBL

        ''AAS HWｼｰﾄのTBL定義
        rtnTBL.Columns.Add(TOPACSAAS_CLOUMNMNAME_SHINSEINO)
        rtnTBL.Columns.Add(TOPACSAAS_CLOUMNMNAME_KIHYONO)
        rtnTBL.Columns.Add(TOPACSAAS_CLOUMNMNAME_LINENO)
        rtnTBL.Columns.Add(TOPACSAAS_CLOUMNMNAME_ADD_REC)
        rtnTBL.Columns.Add(TOPACSAAS_CLOUMNMNAME_FH)
        rtnTBL.Columns.Add(TOPACSAAS_CLOUMNMNAME_CODEAH)
        rtnTBL.Columns.Add(TOPACSAAS_CLOUMNMNAME_ORAH)
        rtnTBL.Columns.Add(TOPACSAAS_CLOUMNMNAME_FCODEAH)
        rtnTBL.Columns.Add(TOPACSAAS_CLOUMNMNAME_NAMEAH)
        rtnTBL.Columns.Add(TOPACSAAS_CLOUMNMNAME_NAHD)
        rtnTBL.Columns.Add(TOPACSAAS_CLOUMNMNAME_AJAH)
        rtnTBL.Columns.Add(TOPACSAAS_CLOUMNMNAME_CAH_DSP)
        rtnTBL.Columns.Add(TOPACSAAS_CLOUMNMNAME_TOTALAH)
        rtnTBL.Columns.Add(TOPACSAAS_CLOUMNMNAME_TOTALAHMS)
        rtnTBL.Columns.Add(TOPACSAAS_CLOUMNMNAME_COSTMCAH)
        rtnTBL.Columns.Add(TOPACSAAS_CLOUMNMNAME_COSTMCAHM)
        rtnTBL.Columns.Add(TOPACSAAS_CLOUMNMNAME_EXCELROW)
        rtnTBL.Columns.Add(TOPACSAAS_CLOUMNMNAME_UNMATREASON)
        rtnTBL.Columns.Add(TOPACSAAS_CLOUMNMNAME_EXISTSUPDATE)
        rtnTBL.Columns.Add(TOPACSAAS_CLOUMNMNAME_DETAILROW)

        ''Key項目
        rtnTBL.Columns.Add(TOPACSAAS_CLOUMNMNAME_BOXCODEAH)
        rtnTBL.Columns.Add(TOPACSAAS_CLOUMNMNAME_BOXSEQ)
        rtnTBL.Columns.Add(TOPACSAAS_CLOUMNMNAME_MATCH_PSLINE)

        Dim xlCell As Excel.Range

        Try
            ''EOF行の取得
            Dim kihyoNo As String
            Dim sinseiNo As String
            Dim Eof As Integer
            For Eof = ExcelWrite.EXCEL_TOPACS_AASDATE_OUTROW To 65553
                xlCell = xlAASSheet.Cells(Eof, 1)
                kihyoNo = ExcelWrite.changeDBNullToString(xlCell.Value)
                xlCell = xlAASSheet.Cells(Eof, 2)
                sinseiNo = ExcelWrite.changeDBNullToString(xlCell.Value)
                If kihyoNo = "" And sinseiNo = "" Then
                    Exit For
                End If
            Next

            ''ﾃﾞｰﾀ0件の処理
            If Eof = ExcelWrite.EXCEL_TOPACS_AASDATE_OUTROW Then
                Exit Function
            Else
                Eof = Eof - 1
            End If

            ''シートの値を取得
            Dim SlineList As New ArrayList
            Dim SlineItem As SlineInfo
            Dim BoxCodeah As String
            Dim BoxSeqList As New System.Collections.Generic.Dictionary(Of String, String)  ''Boxの重複を調べるのに使用
            Dim BoxSeqListKey As String
            Dim obj(,) As Object
            Dim Area As String
            Dim insRow As DataRow
            Area = "A@Str:R@End".Replace("@Str", ExcelWrite.EXCEL_TOPACS_AASDATE_OUTROW) _
                                .Replace("@End", Eof)
            xlCell = xlAASSheet.Range(Area)
            obj = xlCell.Value
            For idx As Integer = 1 To UBound(obj, 1)
                ''S行は取込対象外
                If ExcelWrite.changeDBNullToString(obj(idx, 5)) <> "S" Then
                    insRow = rtnTBL.NewRow
                    insRow.Item(TOPACSAAS_CLOUMNMNAME_KIHYONO) = ExcelWrite.changeDBNullToString(obj(idx, 1)).Trim
                    insRow.Item(TOPACSAAS_CLOUMNMNAME_SHINSEINO) = ExcelWrite.changeDBNullToString(obj(idx, 2)).Trim
                    insRow.Item(TOPACSAAS_CLOUMNMNAME_LINENO) = ExcelWrite.changeDBNullToString(obj(idx, 3)).PadLeft(5, "0")
                    insRow.Item(TOPACSAAS_CLOUMNMNAME_ADD_REC) = ExcelWrite.changeDBNullToString(obj(idx, 4))
                    insRow.Item(TOPACSAAS_CLOUMNMNAME_FH) = ExcelWrite.changeDBNullToString(obj(idx, 5))
                    insRow.Item(TOPACSAAS_CLOUMNMNAME_CODEAH) = ExcelWrite.changeDBNullToString(obj(idx, 6)).Trim
                    insRow.Item(TOPACSAAS_CLOUMNMNAME_ORAH) = ExcelWrite.changeDBNullToString(obj(idx, 7))
                    insRow.Item(TOPACSAAS_CLOUMNMNAME_FCODEAH) = ExcelWrite.changeDBNullToString(obj(idx, 8))
                    insRow.Item(TOPACSAAS_CLOUMNMNAME_NAMEAH) = ExcelWrite.changeDBNullToString(obj(idx, 9))
                    insRow.Item(TOPACSAAS_CLOUMNMNAME_NAHD) = ExcelWrite.changeDBNullToString(obj(idx, 10))
                    insRow.Item(TOPACSAAS_CLOUMNMNAME_AJAH) = ExcelWrite.changeDBNullToString(obj(idx, 11))
                    insRow.Item(TOPACSAAS_CLOUMNMNAME_CAH_DSP) = ExcelWrite.changeDBNullToString(obj(idx, 12))
                    insRow.Item(TOPACSAAS_CLOUMNMNAME_TOTALAH) = ExcelWrite.changeDBNullToString(obj(idx, 13))
                    insRow.Item(TOPACSAAS_CLOUMNMNAME_TOTALAHMS) = ExcelWrite.changeDBNullToString(obj(idx, 14))
                    insRow.Item(TOPACSAAS_CLOUMNMNAME_COSTMCAH) = ExcelWrite.changeDBNullToString(obj(idx, 15))
                    insRow.Item(TOPACSAAS_CLOUMNMNAME_COSTMCAHM) = ExcelWrite.changeDBNullToString(obj(idx, 16))
                    insRow.Item(TOPACSAAS_CLOUMNMNAME_EXCELROW) = ExcelWrite.EXCEL_TOPACS_AASDATE_OUTROW + idx - 1
                    insRow.Item(TOPACSAAS_CLOUMNMNAME_DETAILROW) = ""
                    insRow.Item(TOPACSAAS_CLOUMNMNAME_UNMATREASON) = ""
                    insRow.Item(TOPACSAAS_CLOUMNMNAME_EXISTSUPDATE) = ""
                    insRow.Item(TOPACSAAS_CLOUMNMNAME_MATCH_PSLINE) = ""

                    ''親の機械番号/Seqを取得
                    If ExcelWrite.changeDBNullToString(obj(idx, 5)) = "B" Or _
                       ExcelWrite.changeDBNullToString(obj(idx, 5)) = "M" Then
                        BoxCodeah = ExcelWrite.changeDBNullToString(obj(idx, 6))
                        BoxSeqListKey = ExcelWrite.changeDBNullToString(obj(idx, 1)).Trim & "@" & _
                                        ExcelWrite.changeDBNullToString(obj(idx, 2)).Trim & "@" & _
                                        BoxCodeah

                        If BoxSeqList.ContainsKey(BoxSeqListKey) = True Then
                            BoxSeqList(BoxSeqListKey) = (CInt(BoxSeqList(BoxSeqListKey)) + 1).ToString.PadLeft(3, "0")
                        Else
                            BoxSeqList.Add(BoxSeqListKey, "001")
                        End If
                    End If
                    insRow.Item(TOPACSAAS_CLOUMNMNAME_BOXCODEAH) = BoxCodeah
                    insRow.Item(TOPACSAAS_CLOUMNMNAME_BOXSEQ) = BoxSeqList(BoxSeqListKey)

                    rtnTBL.Rows.Add(insRow)
                Else
                    ''Ｓ行の情報を取得　※Box/Featuerの数量UPDに使用する。
                    SlineItem.KihyoNo = ExcelWrite.changeDBNullToString(obj(idx, 1))
                    SlineItem.ShinseiNo = ExcelWrite.changeDBNullToString(obj(idx, 2)).Trim
                    SlineItem.BoxCodeah = BoxCodeah
                    SlineItem.BoxSeq = BoxSeqList(BoxSeqListKey)
                    SlineItem.SetQty = CInt(ExcelWrite.changeDBNullToZero(obj(idx, 10))) +
                                       CInt(ExcelWrite.changeDBNullToZero(obj(idx, 11)))
                    Call SlineList.Add(SlineItem)

                End If
            Next

            ''Box/Featureの数量をセット品数を乗算する
            Dim SQL As New StringBuilder
            For Each SlineItem In SlineList

                ''S行に一致するBox/Featuerを取得
                SQL.Length = 0
                SQL.Append(TOPACSAAS_CLOUMNMNAME_FH)
                SQL.Append(CommonConstant.SQL_STR_NOT_EQUAL)
                SQL.Append(StringEdit.EncloseSingleQuotation("S"))
                SQL.Append(CommonConstant.SQL_STR_AND)
                SQL.Append(TOPACSAAS_CLOUMNMNAME_SHINSEINO)
                SQL.Append(CommonConstant.SQL_STR_EQUAL)
                SQL.Append(StringEdit.EncloseSingleQuotation(SlineItem.ShinseiNo))
                SQL.Append(CommonConstant.SQL_STR_AND)
                SQL.Append(TOPACSAAS_CLOUMNMNAME_KIHYONO)
                SQL.Append(CommonConstant.SQL_STR_EQUAL)
                SQL.Append(StringEdit.EncloseSingleQuotation(SlineItem.KihyoNo))
                SQL.Append(CommonConstant.SQL_STR_AND)
                SQL.Append(TOPACSAAS_CLOUMNMNAME_BOXCODEAH)
                SQL.Append(CommonConstant.SQL_STR_EQUAL)
                SQL.Append(StringEdit.EncloseSingleQuotation(SlineItem.BoxCodeah))
                SQL.Append(CommonConstant.SQL_STR_AND)
                SQL.Append(TOPACSAAS_CLOUMNMNAME_BOXSEQ)
                SQL.Append(CommonConstant.SQL_STR_EQUAL)
                SQL.Append(StringEdit.EncloseSingleQuotation(SlineItem.BoxSeq))

                ''数量を更新
                Dim NAHD As Integer
                Dim AJAH As Integer
                For Each UpdRow As DataRow In rtnTBL.Select(SQL.ToString)

                    NAHD = CInt(ExcelWrite.changeDBNullToZero(UpdRow.Item(TOPACSAAS_CLOUMNMNAME_NAHD)))
                    AJAH = CInt(ExcelWrite.changeDBNullToZero(UpdRow.Item(TOPACSAAS_CLOUMNMNAME_AJAH)))
                    NAHD = NAHD * SlineItem.SetQty
                    AJAH = AJAH * SlineItem.SetQty

                    UpdRow.Item(TOPACSAAS_CLOUMNMNAME_NAHD) = NAHD
                    UpdRow.Item(TOPACSAAS_CLOUMNMNAME_AJAH) = AJAH
                Next
            Next
            Return rtnTBL

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try

    End Function


    ''' <summary>
    ''' 機　能：QCOSHWｼｰﾄをデータテーブルへ格納する
    ''' 説　明：※Topacs用の開示ﾌｧｲﾙを読込み
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetTopacsQCOSHWSheetData(ByRef xlQCOSHWSheet As Excel.Worksheet) As DataTable

        ''初期化
        Dim rtnTBL As New DataTable
        GetTopacsQCOSHWSheetData = rtnTBL

        ''AAS HWｼｰﾄのTBL定義
        rtnTBL.Columns.Add(TOPACSQCOSHW_CLOUMNMNAME_SHINSEINO)
        rtnTBL.Columns.Add(TOPACSQCOSHW_CLOUMNMNAME_KIHYONO)
        rtnTBL.Columns.Add(TOPACSQCOSHW_CLOUMNMNAME_LINENO)
        rtnTBL.Columns.Add(TOPACSQCOSHW_CLOUMNMNAME_ADD_REC)
        rtnTBL.Columns.Add(TOPACSQCOSHW_CLOUMNMNAME_CODEQH)
        rtnTBL.Columns.Add(TOPACSQCOSHW_CLOUMNMNAME_NQHD)
        rtnTBL.Columns.Add(TOPACSQCOSHW_CLOUMNMNAME_AJQH)
        rtnTBL.Columns.Add(TOPACSQCOSHW_CLOUMNMNAME_CQH_DSP)
        rtnTBL.Columns.Add(TOPACSQCOSHW_CLOUMNMNAME_TOTALQH)
        rtnTBL.Columns.Add(TOPACSQCOSHW_CLOUMNMNAME_COSTMCQH)
        rtnTBL.Columns.Add(TOPACSQCOSHW_CLOUMNMNAME_COSTMCQHM)
        rtnTBL.Columns.Add(TOPACSQCOSHW_CLOUMNMNAME_COSTSWQH)
        rtnTBL.Columns.Add(TOPACSQCOSHW_CLOUMNMNAME_COSTSWQHM)
        rtnTBL.Columns.Add(TOPACSQCOSHW_CLOUMNMNAME_EXCELROW)
        rtnTBL.Columns.Add(TOPACSQCOSHW_CLOUMNMNAME_UNMATREASON)
        rtnTBL.Columns.Add(TOPACSQCOSHW_CLOUMNMNAME_MATCH_PSLINE)

        Dim xlCell As Excel.Range
        Try
            ''EOF行の取得
            Dim kihyoNo As String
            Dim sinseiNo As String
            Dim Eof As Integer
            For Eof = ExcelWrite.EXCEL_TOPACS_QCOSHWDATE_OUTROW To 65553
                xlCell = xlQCOSHWSheet.Cells(Eof, 1)
                kihyoNo = xlCell.Value
                xlCell = xlQCOSHWSheet.Cells(Eof, 2)
                sinseiNo = xlCell.Value
                If kihyoNo = "" And sinseiNo = "" Then
                    Exit For
                End If
            Next
            If Eof = ExcelWrite.EXCEL_TOPACS_QCOSHWDATE_OUTROW Then
                Exit Function
            Else
                Eof = Eof - 1
            End If

            ''シートの値を取得
            Dim obj(,) As Object
            Dim Area As String
            Dim insRow As DataRow
            Area = "A@Str:N@End".Replace("@Str", ExcelWrite.EXCEL_TOPACS_QCOSHWDATE_OUTROW) _
                                .Replace("@End", Eof)
            xlCell = xlQCOSHWSheet.Range(Area)
            obj = xlCell.Value
            For idx As Integer = 1 To UBound(obj, 1)
                insRow = rtnTBL.NewRow
                insRow.Item(TOPACSQCOSHW_CLOUMNMNAME_SHINSEINO) = ExcelWrite.changeDBNullToString(obj(idx, 1)).Trim
                insRow.Item(TOPACSQCOSHW_CLOUMNMNAME_KIHYONO) = ExcelWrite.changeDBNullToString(obj(idx, 2)).Trim
                insRow.Item(TOPACSQCOSHW_CLOUMNMNAME_LINENO) = ExcelWrite.changeDBNullToString(obj(idx, 3)).Trim.PadLeft(5, "0")
                insRow.Item(TOPACSQCOSHW_CLOUMNMNAME_ADD_REC) = ExcelWrite.changeDBNullToString(obj(idx, 4)).Trim
                insRow.Item(TOPACSQCOSHW_CLOUMNMNAME_CODEQH) = ExcelWrite.changeDBNullToString(obj(idx, 5)).Trim
                insRow.Item(TOPACSQCOSHW_CLOUMNMNAME_NQHD) = ExcelWrite.changeDBNullToString(obj(idx, 6))
                insRow.Item(TOPACSQCOSHW_CLOUMNMNAME_AJQH) = ExcelWrite.changeDBNullToString(obj(idx, 7))
                insRow.Item(TOPACSQCOSHW_CLOUMNMNAME_CQH_DSP) = ExcelWrite.changeDBNullToString(obj(idx, 8))
                insRow.Item(TOPACSQCOSHW_CLOUMNMNAME_TOTALQH) = ExcelWrite.changeDBNullToString(obj(idx, 9))
                insRow.Item(TOPACSQCOSHW_CLOUMNMNAME_COSTMCQH) = ExcelWrite.changeDBNullToString(obj(idx, 10))
                insRow.Item(TOPACSQCOSHW_CLOUMNMNAME_COSTMCQHM) = ExcelWrite.changeDBNullToString(obj(idx, 11))
                insRow.Item(TOPACSQCOSHW_CLOUMNMNAME_COSTSWQH) = ExcelWrite.changeDBNullToString(obj(idx, 12))
                insRow.Item(TOPACSQCOSHW_CLOUMNMNAME_COSTSWQHM) = ExcelWrite.changeDBNullToString(obj(idx, 13))
                insRow.Item(TOPACSQCOSHW_CLOUMNMNAME_EXCELROW) = ExcelWrite.EXCEL_TOPACS_QCOSHWDATE_OUTROW + idx - 1
                insRow.Item(TOPACSQCOSHW_CLOUMNMNAME_UNMATREASON) = ""
                insRow.Item(TOPACSQCOSHW_CLOUMNMNAME_MATCH_PSLINE) = ""
                rtnTBL.Rows.Add(insRow)
            Next
            Return rtnTBL

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Function


    ''' <summary>
    ''' 機　能：QCOSSWｼｰﾄをデータテーブルへ格納する
    ''' 説　明：※Topacs用の開示ﾌｧｲﾙを読込み
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetTopacsQCOSSWSheetData(ByRef xlQCOSSWSheet As Excel.Worksheet) As DataTable

        ''初期化
        Dim rtnTBL As New DataTable
        GetTopacsQCOSSWSheetData = rtnTBL

        ''AAS SWｼｰﾄのTBL定義
        rtnTBL.Columns.Add(TOPACSQCOSSW_CLOUMNMNAME_SHINSEINO)
        rtnTBL.Columns.Add(TOPACSQCOSSW_CLOUMNMNAME_KIHYONO)
        rtnTBL.Columns.Add(TOPACSQCOSSW_CLOUMNMNAME_LINENO)
        rtnTBL.Columns.Add(TOPACSQCOSSW_CLOUMNMNAME_ADD_REC)
        rtnTBL.Columns.Add(TOPACSQCOSSW_CLOUMNMNAME_CODEQS)
        rtnTBL.Columns.Add(TOPACSQCOSSW_CLOUMNMNAME_ORQS)
        rtnTBL.Columns.Add(TOPACSQCOSSW_CLOUMNMNAME_NAMEQS)
        rtnTBL.Columns.Add(TOPACSQCOSSW_CLOUMNMNAME_NQSD)
        rtnTBL.Columns.Add(TOPACSQCOSSW_CLOUMNMNAME_AJQS)
        rtnTBL.Columns.Add(TOPACSQCOSSW_CLOUMNMNAME_CQS_DSP)
        rtnTBL.Columns.Add(TOPACSQCOSSW_CLOUMNMNAME_TOTALQS)
        rtnTBL.Columns.Add(TOPACSQCOSSW_CLOUMNMNAME_COSTMCQS)
        rtnTBL.Columns.Add(TOPACSQCOSSW_CLOUMNMNAME_COSTMCQSM)
        rtnTBL.Columns.Add(TOPACSQCOSSW_CLOUMNMNAME_COSTRITSUQS)
        rtnTBL.Columns.Add(TOPACSQCOSSW_CLOUMNMNAME_EXCELROW)
        rtnTBL.Columns.Add(TOPACSQCOSSW_CLOUMNMNAME_UNMATREASON)
        rtnTBL.Columns.Add(TOPACSQCOSSW_CLOUMNMNAME_MATCH_PSLINE)

        Dim xlCell As Excel.Range
        Try
            ''EOF行の取得
            Dim kihyoNo As String
            Dim sinseiNo As String
            Dim Eof As Integer
            For Eof = ExcelWrite.EXCEL_TOPACS_QCOSSWDATE_OUTROW To 65553
                xlCell = xlQCOSSWSheet.Cells(Eof, 1)
                kihyoNo = xlCell.Value
                xlCell = xlQCOSSWSheet.Cells(Eof, 2)
                sinseiNo = xlCell.Value
                If kihyoNo = "" And sinseiNo = "" Then
                    Exit For
                End If
            Next
            If Eof = ExcelWrite.EXCEL_TOPACS_QCOSSWDATE_OUTROW Then
                Exit Function
            Else
                Eof = Eof - 1
            End If

            ''シートの値を取得
            Dim obj(,) As Object
            Dim Area As String
            Dim insRow As DataRow
            Area = "A@Str:N@End".Replace("@Str", ExcelWrite.EXCEL_TOPACS_QCOSHWDATE_OUTROW) _
                                .Replace("@End", Eof)
            xlCell = xlQCOSSWSheet.Range(Area)
            obj = xlCell.Value
            For idx As Integer = 1 To UBound(obj, 1)
                insRow = rtnTBL.NewRow
                insRow.Item(TOPACSQCOSSW_CLOUMNMNAME_SHINSEINO) = ExcelWrite.changeDBNullToString(obj(idx, 1)).Trim
                insRow.Item(TOPACSQCOSSW_CLOUMNMNAME_KIHYONO) = ExcelWrite.changeDBNullToString(obj(idx, 2)).Trim
                insRow.Item(TOPACSQCOSSW_CLOUMNMNAME_LINENO) = ExcelWrite.changeDBNullToString(obj(idx, 3)).PadLeft(5, "0")
                insRow.Item(TOPACSQCOSSW_CLOUMNMNAME_ADD_REC) = ExcelWrite.changeDBNullToString(obj(idx, 4))
                insRow.Item(TOPACSQCOSSW_CLOUMNMNAME_CODEQS) = ExcelWrite.changeDBNullToString(obj(idx, 5)).Trim
                insRow.Item(TOPACSQCOSSW_CLOUMNMNAME_NQSD) = ExcelWrite.changeDBNullToString(obj(idx, 6))
                insRow.Item(TOPACSQCOSSW_CLOUMNMNAME_AJQS) = ExcelWrite.changeDBNullToString(obj(idx, 7))
                insRow.Item(TOPACSQCOSSW_CLOUMNMNAME_CQS_DSP) = ExcelWrite.changeDBNullToString(obj(idx, 8))
                insRow.Item(TOPACSQCOSSW_CLOUMNMNAME_TOTALQS) = ExcelWrite.changeDBNullToString(obj(idx, 9))
                insRow.Item(TOPACSQCOSSW_CLOUMNMNAME_COSTMCQS) = ExcelWrite.changeDBNullToString(obj(idx, 10))
                insRow.Item(TOPACSQCOSSW_CLOUMNMNAME_COSTMCQSM) = ExcelWrite.changeDBNullToString(obj(idx, 11))
                insRow.Item(TOPACSQCOSSW_CLOUMNMNAME_COSTRITSUQS) = ExcelWrite.changeDBNullToString(obj(idx, 12))
                insRow.Item(TOPACSQCOSSW_CLOUMNMNAME_EXCELROW) = ExcelWrite.EXCEL_TOPACS_QCOSSWDATE_OUTROW + idx - 1
                insRow.Item(TOPACSQCOSSW_CLOUMNMNAME_UNMATREASON) = ""
                insRow.Item(TOPACSQCOSSW_CLOUMNMNAME_MATCH_PSLINE) = ""
                rtnTBL.Rows.Add(insRow)
            Next
            Return rtnTBL

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Function


    ''' <summary>
    ''' 機　能：Cost開示対象のTopacsﾃﾞｰﾀを取得
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetWritePSCostKaijiRowTopacs(ByVal PSDataTable As DataTable,
                                             ByVal DetailDataTable As DataTable,
                                             ByVal CostKaijiTopacsSheetData() As DataTable,
                                             ByRef outputTargerPSDataTable As DataTable,
                                             ByRef outputTargerDetailDataTable As DataTable)


        Dim rtnPSTBL As DataTable                 ''Cost反映用：Paymentﾃﾞｰﾀ
        Dim rtnDetailTBL As New DataTable         ''Cost反映用：詳細ﾃﾞｰﾀ
        rtnPSTBL = CreateOutTopacsPSTBL()
        rtnDetailTBL = CreateOutTopacsDetailTBL()

        Try
            ''AAS HW
            If CostKaijiTopacsSheetData(0).Rows.Count <> 0 Then
                Call AddOutTopacsAASData(CostKaijiTopacsSheetData(0), _
                                         PSDataTable, _
                                         DetailDataTable, _
                                         rtnPSTBL, _
                                         rtnDetailTBL)
            End If

            ''QCOS HW
            If CostKaijiTopacsSheetData(1).Rows.Count <> 0 Then
                Call AddOutTopacsQCOSHWData(CostKaijiTopacsSheetData(1), _
                                            PSDataTable, _
                                            rtnPSTBL)
            End If

            ''QCOS SW
            If CostKaijiTopacsSheetData(2).Rows.Count <> 0 Then
                Call AddOutTopacsQCOSSWData(CostKaijiTopacsSheetData(2), _
                                            PSDataTable, _
                                            rtnPSTBL)
            End If

            ''戻り値
            outputTargerPSDataTable = rtnPSTBL
            outputTargerDetailDataTable = rtnDetailTBL

        Catch ex As Exception
            Throw ex

        End Try

    End Sub


    ''' <summary>
    ''' 機　能：Topacs出力用TBL作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateOutTopacsPSTBL() As DataTable

        ''初期化
        Dim rtnTable As New DataTable
        CreateOutTopacsPSTBL = rtnTable

        rtnTable.Columns.Add(PSEXCEL_CLOUMNMNAME_LINE_NO)
        rtnTable.Columns.Add(PSEXCEL_CLOUMNMNAME_EXCELROW)
        rtnTable.Columns.Add(PSEXCEL_CLOUMNMNAME_COST)
        rtnTable.Columns.Add(PSEXCEL_CLOUMNMNAME_COST_RATE)
        rtnTable.Columns.Add(PSEXCEL_CLOUMNMNAME_NEW_EXIST)
        rtnTable.Columns.Add(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
        rtnTable.Columns.Add(PSEXCEL_CLOUMNMNAME_PATTERN)
        rtnTable.Columns.Add(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH)
        rtnTable.Columns.Add(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
        rtnTable.Columns.Add(PSEXCEL_CLOUMNMNAME_QTY)

        ''詳細の紐づけ
        rtnTable.Columns.Add(PSEXCEL_CLOUMNMNAME_CONTRACTNO)
        rtnTable.Columns.Add(PSEXCEL_CLOUMNMNAME_FILE_NAME)
        rtnTable.Columns.Add(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
        rtnTable.Columns.Add(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)

        Return rtnTable

    End Function


    ''' <summary>
    ''' 機　能：Topacs出力用TBL作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateOutTopacsDetailTBL() As DataTable

        ''初期化
        Dim rtnTable As New DataTable
        CreateOutTopacsDetailTBL = rtnTable

        rtnTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)
        rtnTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME)
        rtnTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
        rtnTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
        rtnTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_SEQ)
        rtnTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_MES_CATEGORY)
        rtnTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_SPECIAL_FEATURE)
        rtnTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_EXCELROW)
        rtnTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_COST_RATE)
        rtnTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_COST)
        rtnTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_QTY_INTEGER)
        rtnTable.Columns.Add(PSDETAILEXCEL_CLOUMNMNAME_PROD_ITEM01)

        Return rtnTable

    End Function

    ''' <summary>
    ''' 機　能：QCOS HWシートのマッチデータを取得
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub AddOutTopacsQCOSHWData(ByRef CostKaijiTopacsSheetData As DataTable, _
                                       ByRef PSDataTable As DataTable, _
                                       ByRef rtnPSTBL As DataTable)

        Try
            Dim Cost As Decimal
            Dim insRow As DataRow
            Dim MatchPSList() As DataRow
            Dim UnmatchPSReason As String
            For Each Row As DataRow In CostKaijiTopacsSheetData.Rows

                ''Payment情報に一致する情報が存在するか判定
                MatchPSList = MatchTopaceQcosHWPSRow(Row, PSDataTable, UnmatchPSReason)
                If UnmatchPSReason <> "" Then
                    Row.Item(TOPACSQCOSHW_CLOUMNMNAME_UNMATREASON) = UnmatchPSReason
                    Continue For
                Else

                    ''MatchしたPS行をセット
                    Row.Item(TOPACSQCOSHW_CLOUMNMNAME_MATCH_PSLINE) = MatchPSList(0).Item(PSEXCEL_CLOUMNMNAME_LINE_NO)

                    For Each tmpRow As DataRow In MatchPSList

                        insRow = rtnPSTBL.NewRow

                        ''Cost取得
                        Cost = 0
                        If IsNumeric(Row.Item(TOPACSQCOSHW_CLOUMNMNAME_COSTMCQH)) = True Then
                            Cost = Cost + CDec(Row.Item(TOPACSQCOSHW_CLOUMNMNAME_COSTMCQH))
                        End If
                        If IsNumeric(Row.Item(TOPACSQCOSHW_CLOUMNMNAME_COSTSWQH)) = True Then
                            Cost = Cost + CDec(Row.Item(TOPACSQCOSHW_CLOUMNMNAME_COSTSWQH))
                        End If

                        ''値をセット
                        insRow.Item(PSEXCEL_CLOUMNMNAME_LINE_NO) = tmpRow.Item(PSEXCEL_CLOUMNMNAME_LINE_NO)
                        insRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW) = tmpRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)
                        insRow.Item(PSEXCEL_CLOUMNMNAME_COST) = Cost
                        insRow.Item(PSEXCEL_CLOUMNMNAME_COST_RATE) = tmpRow.Item(PSEXCEL_CLOUMNMNAME_COST_RATE)
                        insRow.Item(PSEXCEL_CLOUMNMNAME_NEW_EXIST) = tmpRow.Item(PSEXCEL_CLOUMNMNAME_NEW_EXIST)
                        insRow.Item(PSEXCEL_CLOUMNMNAME_PATTERN_CD) = tmpRow.Item(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                        insRow.Item(PSEXCEL_CLOUMNMNAME_PATTERN) = tmpRow.Item(PSEXCEL_CLOUMNMNAME_PATTERN)
                        insRow.Item(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH) = tmpRow.Item(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH)
                        insRow.Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM01) = tmpRow.Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                        rtnPSTBL.Rows.Add(insRow)
                    Next

                End If
            Next

        Catch ex As Exception
            Throw ex

        End Try

    End Sub


    ''' <summary>
    ''' 機　能：Paymentと一致するﾃﾞｰﾀを取得
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function MatchTopaceQcosHWPSRow(ByRef Row As DataRow, _
                                            ByRef PSDataTable As DataTable, _
                                            ByRef UnmatchPSReason As String) As DataRow()

        ''ﾒｯｾｰｼﾞ
        Dim Msg As String
        Const ErrMsg001 As String = "Topacs起票番号、申請番号、製品番号、数量が一致するﾃﾞｰﾀがありません。"
        Const ErrMsg003 As String = "COST情報がありません。"

        ''初期化
        Dim rtnRow() As DataRow
        MatchTopaceQcosHWPSRow = rtnRow

        Try

            ''数量取得
            Dim qty As Decimal
            qty = CDec(Row.Item(TOPACSQCOSHW_CLOUMNMNAME_NQHD)) + _
                  CDec(Row.Item(TOPACSQCOSHW_CLOUMNMNAME_AJQH))

            ''Sql発行
            Dim SQL As New StringBuilder
            SQL.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            SQL.Append(PSEXCEL_CLOUMNMNAME_BRAND_AP_FORM)
            SQL.Append(CommonConstant.SQL_STR_EQUAL)
            SQL.Append(StringEdit.EncloseSingleQuotation(Row.Item(TOPACSQCOSHW_CLOUMNMNAME_KIHYONO)))
            SQL.Append(CommonConstant.SQL_STR_OR)
            SQL.Append(PSEXCEL_CLOUMNMNAME_BRAND_AP_REQ)
            SQL.Append(CommonConstant.SQL_STR_EQUAL)
            SQL.Append(StringEdit.EncloseSingleQuotation(Row.Item(TOPACSQCOSHW_CLOUMNMNAME_SHINSEINO)))
            SQL.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
            SQL.Append(CommonConstant.SQL_STR_AND)
            SQL.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
            SQL.Append(CommonConstant.SQL_STR_EQUAL)
            SQL.Append(StringEdit.EncloseSingleQuotation(Row.Item(TOPACSQCOSHW_CLOUMNMNAME_CODEQH)))
            SQL.Append(CommonConstant.SQL_STR_AND)
            SQL.Append(PSEXCEL_CLOUMNMNAME_QTY)
            SQL.Append(CommonConstant.SQL_STR_EQUAL)
            SQL.Append(StringEdit.EncloseSingleQuotation(qty))
            SQL.Append(CommonConstant.SQL_STR_AND)
            SQL.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
            SQL.Append(CommonConstant.SQL_STR_EQUAL)
            SQL.Append(StringEdit.EncloseSingleQuotation("3"))

            ''紐づくﾃﾞｰﾀがなければ、エラー
            rtnRow = PSDataTable.Select(SQL.ToString)
            If rtnRow.Length = 0 Then
                Msg = Msg & ErrMsg001 & vbCrLf
            End If

            ''③Costの入力チェック
            If ExcelWrite.changeDBNullToString(Row.Item(TOPACSQCOSHW_CLOUMNMNAME_COSTMCQH)) = "" And _
               ExcelWrite.changeDBNullToString(Row.Item(TOPACSQCOSHW_CLOUMNMNAME_COSTSWQH)) = "" Then
                Msg = Msg & ErrMsg003 & vbCrLf
            End If

            ''不一致理由をセット
            If Msg <> "" Then
                UnmatchPSReason = Msg.Substring(0, _
                                                Msg.Length - vbCrLf.Length)
            Else
                UnmatchPSReason = ""
            End If

            Return rtnRow
        Catch ex As Exception
            Throw ex

        End Try

    End Function


    ''' <summary>
    ''' 機　能：QCOS SWシートのマッチデータを取得
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub AddOutTopacsQCOSSWData(ByRef CostKaijiTopacsSheetData As DataTable, _
                                       ByRef PSDataTable As DataTable, _
                                       ByRef rtnPSTBL As DataTable)

        Dim Cost As Decimal
        Dim insRow As DataRow
        Dim MatchPSList() As DataRow
        Dim UnmatchPSReason As String
        For Each Row As DataRow In CostKaijiTopacsSheetData.Rows

            ''Payment情報に一致する情報が存在するか判定
            MatchPSList = MatchTopaceQcosSWPSRow(Row, PSDataTable, UnmatchPSReason)
            If UnmatchPSReason <> "" Then
                Row.Item(TOPACSQCOSSW_CLOUMNMNAME_UNMATREASON) = UnmatchPSReason
                Continue For
            Else
                ''MatchしたPS行をセット
                Row.Item(TOPACSQCOSSW_CLOUMNMNAME_MATCH_PSLINE) = MatchPSList(0).Item(PSEXCEL_CLOUMNMNAME_LINE_NO)
                For Each tmpRow As DataRow In MatchPSList

                    insRow = rtnPSTBL.NewRow

                    ''値をセット
                    insRow.Item(PSEXCEL_CLOUMNMNAME_LINE_NO) = tmpRow.Item(PSEXCEL_CLOUMNMNAME_LINE_NO)
                    insRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW) = tmpRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)
                    insRow.Item(PSEXCEL_CLOUMNMNAME_COST) = Row.Item(TOPACSQCOSSW_CLOUMNMNAME_COSTMCQS)
                    insRow.Item(PSEXCEL_CLOUMNMNAME_COST_RATE) = tmpRow.Item(PSEXCEL_CLOUMNMNAME_COST_RATE)
                    insRow.Item(PSEXCEL_CLOUMNMNAME_NEW_EXIST) = tmpRow.Item(PSEXCEL_CLOUMNMNAME_NEW_EXIST)
                    insRow.Item(PSEXCEL_CLOUMNMNAME_PATTERN_CD) = tmpRow.Item(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                    insRow.Item(PSEXCEL_CLOUMNMNAME_PATTERN) = tmpRow.Item(PSEXCEL_CLOUMNMNAME_PATTERN)
                    insRow.Item(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH) = tmpRow.Item(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH)
                    insRow.Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM01) = tmpRow.Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)

                    rtnPSTBL.Rows.Add(insRow)
                Next
            End If
        Next

    End Sub


    ''' <summary>
    ''' 機　能：Paymentと一致するﾃﾞｰﾀを取得
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function MatchTopaceQcosSWPSRow(ByRef Row As DataRow, _
                                            ByRef PSDataTable As DataTable, _
                                            ByRef UnmatchPSReason As String) As DataRow()

        ''ﾒｯｾｰｼﾞ
        Dim Msg As String
        Const ErrMsg001 As String = "Topacs起票番号、申請番号、製品番号、数量が一致するﾃﾞｰﾀがありません。"
        Const ErrMsg003 As String = "COST情報がありません。"

        ''初期化
        Dim rtnRow() As DataRow
        MatchTopaceQcosSWPSRow = rtnRow

        ''数量取得
        Dim qty As Decimal
        qty = CDbl(Row.Item(TOPACSQCOSSW_CLOUMNMNAME_NQSD)) + _
              CDbl(Row.Item(TOPACSQCOSSW_CLOUMNMNAME_AJQS))

        ''Sql発行
        Dim SQL As New StringBuilder
        SQL.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        SQL.Append(PSEXCEL_CLOUMNMNAME_BRAND_AP_FORM)
        SQL.Append(CommonConstant.SQL_STR_EQUAL)
        SQL.Append(StringEdit.EncloseSingleQuotation(Row.Item(TOPACSQCOSSW_CLOUMNMNAME_KIHYONO)))
        SQL.Append(CommonConstant.SQL_STR_OR)
        SQL.Append(PSEXCEL_CLOUMNMNAME_BRAND_AP_REQ)
        SQL.Append(CommonConstant.SQL_STR_EQUAL)
        SQL.Append(StringEdit.EncloseSingleQuotation(Row.Item(TOPACSQCOSSW_CLOUMNMNAME_SHINSEINO)))
        SQL.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
        SQL.Append(CommonConstant.SQL_STR_AND)
        SQL.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
        SQL.Append(CommonConstant.SQL_STR_EQUAL)
        SQL.Append(StringEdit.EncloseSingleQuotation(Row.Item(TOPACSQCOSSW_CLOUMNMNAME_CODEQS)))
        SQL.Append(CommonConstant.SQL_STR_AND)
        SQL.Append(PSEXCEL_CLOUMNMNAME_QTY)
        SQL.Append(CommonConstant.SQL_STR_EQUAL)
        SQL.Append(StringEdit.EncloseSingleQuotation(qty))
        SQL.Append(CommonConstant.SQL_STR_AND)
        SQL.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        SQL.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
        SQL.Append(CommonConstant.SQL_STR_EQUAL)
        SQL.Append(StringEdit.EncloseSingleQuotation("6"))
        SQL.Append(CommonConstant.SQL_STR_OR)
        SQL.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
        SQL.Append(CommonConstant.SQL_STR_EQUAL)
        SQL.Append(StringEdit.EncloseSingleQuotation("8"))
        SQL.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

        ''紐づくﾃﾞｰﾀがなければ、エラー
        rtnRow = PSDataTable.Select(SQL.ToString)
        If rtnRow.Length = 0 Then
            Msg = Msg & ErrMsg001 & vbCrLf
        End If

        ''③Costの入力チェック
        If ExcelWrite.changeDBNullToString(Row.Item(TOPACSQCOSSW_CLOUMNMNAME_COSTMCQS)) = "" Then
            Msg = Msg & ErrMsg003 & vbCrLf
        End If

        ''不一致理由をセット
        If Msg <> "" Then
            UnmatchPSReason = Msg.Substring(0, _
                                            Msg.Length - vbCrLf.Length)
        Else
            UnmatchPSReason = ""
        End If

        Return rtnRow

    End Function

    Private Sub OutTopacsLogSheet(ByRef TopacsTBL() As DataTable, _
                                  ByRef CostKaijiBook As Excel.Workbook, _
                                  ByRef topacsOutCount As Integer)

        Dim SQL As String
        Dim tmpRow() As DataRow
        Dim AASHW_TBL As DataTable
        Dim QCOSHW_TBL As DataTable
        Dim QCOSSW_TBL As DataTable
        Dim xlLogSheet As Excel.Worksheet
        Try
            ''Summary
            xlLogSheet = CostKaijiBook.Worksheets(ExcelWrite.EXCEL_TOPACSDATE_Summary)
            Call OutTopacsSummaryLog(TopacsTBL, xlLogSheet)

            ''AAS HW 
            xlLogSheet = CostKaijiBook.Worksheets(ExcelWrite.EXCEL_TOPACSDATE_AAS)
            AASHW_TBL = TopacsTBL(0)
            SQL = TOPACSAAS_CLOUMNMNAME_UNMATREASON & " <>  '' And " & _
                  TOPACSAAS_CLOUMNMNAME_FH & " <> 'S'"
            tmpRow = AASHW_TBL.Select(SQL)
            Call OutTopacsLog("AAS", tmpRow, xlLogSheet)
            Call OutTopacsReadLinno("AAS", AASHW_TBL, xlLogSheet)

            ''Match件数を取得
            SQL = TOPACSAAS_CLOUMNMNAME_UNMATREASON & " =  '' And " & _
                  TOPACSAAS_CLOUMNMNAME_FH & " <> 'S'"
            tmpRow = AASHW_TBL.Select(SQL)
            topacsOutCount = topacsOutCount + tmpRow.Length

            ''QCOS HW
            xlLogSheet = CostKaijiBook.Worksheets(ExcelWrite.EXCEL_TOPACSDATE_QCOSHW)
            QCOSHW_TBL = TopacsTBL(1)
            SQL = TOPACSQCOSHW_CLOUMNMNAME_UNMATREASON & " <>  '' "       ''アンマッチ理由がNull以外
            tmpRow = QCOSHW_TBL.Select(SQL)
            Call OutTopacsLog("QCOSHW", tmpRow, xlLogSheet)
            Call OutTopacsReadLinno("QCOSHW", QCOSHW_TBL, xlLogSheet)

            ''Match件数を取得
            SQL = TOPACSQCOSHW_CLOUMNMNAME_UNMATREASON & " =  '' "
            tmpRow = QCOSHW_TBL.Select(SQL)
            topacsOutCount = topacsOutCount + tmpRow.Length

            ''QCOS SW
            xlLogSheet = CostKaijiBook.Worksheets(ExcelWrite.EXCEL_TOPACSDATE_QCOSSW)
            QCOSSW_TBL = TopacsTBL(2)
            SQL = TOPACSQCOSSW_CLOUMNMNAME_UNMATREASON & " <>  '' "       ''アンマッチ理由がNull以外
            tmpRow = QCOSSW_TBL.Select(SQL)
            Call OutTopacsLog("QCOSSW", tmpRow, xlLogSheet)
            Call OutTopacsReadLinno("QCOSSW", QCOSSW_TBL, xlLogSheet)

            ''Match件数を取得
            SQL = TOPACSQCOSSW_CLOUMNMNAME_UNMATREASON & " =  '' "
            tmpRow = QCOSSW_TBL.Select(SQL)
            topacsOutCount = topacsOutCount + tmpRow.Length

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlLogSheet, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub


    Private Sub OutTopacsLog(ByVal ActKB As String,
                             ByRef tmpRows() As DataRow, _
                             ByRef xlLogSheet As Excel.Worksheet)

        ''ログの書込列取得
        Dim logRow As String
        Dim logExcelRow As String           ''TBL項目名：Excel行位置
        Dim logReason As String             ''TBL項目名：Unmatch理由
        Select Case ActKB
            Case "AAS"
                logRow = "R"
                logExcelRow = TOPACSAAS_CLOUMNMNAME_EXCELROW
                logReason = TOPACSAAS_CLOUMNMNAME_UNMATREASON
            Case "QCOSHW"
                logRow = "O"
                logExcelRow = TOPACSQCOSHW_CLOUMNMNAME_EXCELROW
                logReason = TOPACSQCOSHW_CLOUMNMNAME_UNMATREASON
            Case "QCOSSW"
                logRow = "N"
                logExcelRow = TOPACSQCOSSW_CLOUMNMNAME_EXCELROW
                logReason = TOPACSQCOSSW_CLOUMNMNAME_UNMATREASON
        End Select

        Dim Area As String
        Dim xlCell As Excel.Range       ''セル
        Try
            For Each tmpRow As DataRow In tmpRows
                Area = logRow & CInt(tmpRow.Item(logExcelRow))
                xlCell = xlLogSheet.Range(Area)
                xlCell.Value = tmpRow.Item(logReason)
            Next
        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try
    End Sub

    Private Sub OutTopacsSummaryLog(ByRef TopacsTBL() As DataTable, _
                                    ByRef xlLogSheet As Excel.Worksheet)

        Dim xlCell As Excel.Range

        Dim tmpRow() As DataRow
        Dim AASCount As Integer             ''AASシートの出力件数
        Dim QCOSHWCount As Integer          ''QCOSHWシートの出力件数
        Dim QCOSSWCount As Integer          ''QCOSSWシートの出力件数 

        Dim Sql As New StringBuilder
        Dim Area As String
        Dim KihyoNo As String               ''起票番号
        Dim SinseiNo As String              ''申請番号
        Try
            For idx As Integer = ExcelWrite.EXCEL_TOPACS_SUMMARY_OUTROW To 65536

                ''起票番号取得
                Area = "B" & idx
                xlCell = xlLogSheet.Range(Area)
                KihyoNo = xlCell.Value

                ''申請番号取得
                Area = "D" & idx
                xlCell = xlLogSheet.Range(Area)
                SinseiNo = xlCell.Value

                ''Eofの判定
                If ExcelWrite.changeDBNullToString(KihyoNo) = "" And _
                   ExcelWrite.changeDBNullToString(SinseiNo) = "" Then
                    Exit For
                End If

                ''AASHW 出力件数
                Sql.Length = 0
                Sql.Append(TOPACSAAS_CLOUMNMNAME_UNMATREASON)
                Sql.Append(CommonConstant.SQL_STR_EQUAL)
                Sql.Append(StringEdit.EncloseSingleQuotation(""))
                Sql.Append(CommonConstant.SQL_STR_AND)
                Sql.Append(TOPACSAAS_CLOUMNMNAME_FH)
                Sql.Append(CommonConstant.SQL_STR_NOT_EQUAL)
                Sql.Append(StringEdit.EncloseSingleQuotation("S"))

                ''起票 or 申請番号で検索
                If ExcelWrite.changeDBNullToString(KihyoNo) <> "" Then
                    Sql.Append(CommonConstant.SQL_STR_AND)
                    Sql.Append(TOPACSAAS_CLOUMNMNAME_KIHYONO)
                    Sql.Append(CommonConstant.SQL_STR_EQUAL)
                    Sql.Append(StringEdit.EncloseSingleQuotation(KihyoNo))
                Else
                    If ExcelWrite.changeDBNullToString(SinseiNo) <> "" Then
                        Sql.Append(CommonConstant.SQL_STR_AND)
                        Sql.Append(TOPACSAAS_CLOUMNMNAME_SHINSEINO)
                        Sql.Append(CommonConstant.SQL_STR_EQUAL)
                        Sql.Append(StringEdit.EncloseSingleQuotation(SinseiNo))
                    End If
                End If
                AASCount = TopacsTBL(0).Select(Sql.ToString).Length

                ''書込
                Area = "H" & idx
                xlCell = xlLogSheet.Range(Area)
                xlCell.Value = AASCount

                ''QcosHW 出力件数
                Sql.Length = 0
                Sql.Append(TOPACSQCOSHW_CLOUMNMNAME_UNMATREASON)
                Sql.Append(CommonConstant.SQL_STR_EQUAL)
                Sql.Append(StringEdit.EncloseSingleQuotation(""))

                ''起票 or 申請番号で検索
                If ExcelWrite.changeDBNullToString(KihyoNo) <> "" Then
                    Sql.Append(CommonConstant.SQL_STR_AND)
                    Sql.Append(TOPACSQCOSHW_CLOUMNMNAME_KIHYONO)
                    Sql.Append(CommonConstant.SQL_STR_EQUAL)
                    Sql.Append(StringEdit.EncloseSingleQuotation(KihyoNo))
                Else
                    If ExcelWrite.changeDBNullToString(SinseiNo) <> "" Then
                        Sql.Append(CommonConstant.SQL_STR_AND)
                        Sql.Append(TOPACSQCOSHW_CLOUMNMNAME_SHINSEINO)
                        Sql.Append(CommonConstant.SQL_STR_EQUAL)
                        Sql.Append(StringEdit.EncloseSingleQuotation(SinseiNo))
                    End If
                End If
                QCOSHWCount = TopacsTBL(1).Select(Sql.ToString).Length

                ''書込
                Area = "K" & idx
                xlCell = xlLogSheet.Range(Area)
                xlCell.Value = QCOSHWCount

                ''QcosSW 出力件数
                Sql.Length = 0
                Sql.Append(TOPACSQCOSSW_CLOUMNMNAME_UNMATREASON)
                Sql.Append(CommonConstant.SQL_STR_EQUAL)
                Sql.Append(StringEdit.EncloseSingleQuotation(""))

                ''起票 or 申請番号で検索
                If ExcelWrite.changeDBNullToString(KihyoNo) <> "" Then
                    Sql.Append(CommonConstant.SQL_STR_AND)
                    Sql.Append(TOPACSQCOSSW_CLOUMNMNAME_KIHYONO)
                    Sql.Append(CommonConstant.SQL_STR_EQUAL)
                    Sql.Append(StringEdit.EncloseSingleQuotation(KihyoNo))
                Else
                    If ExcelWrite.changeDBNullToString(SinseiNo) <> "" Then
                        Sql.Append(CommonConstant.SQL_STR_AND)
                        Sql.Append(TOPACSQCOSSW_CLOUMNMNAME_SHINSEINO)
                        Sql.Append(CommonConstant.SQL_STR_EQUAL)
                        Sql.Append(StringEdit.EncloseSingleQuotation(SinseiNo))
                    End If
                End If
                QCOSHWCount = TopacsTBL(2).Select(Sql.ToString).Length

                ''書込
                Area = "N" & idx
                xlCell = xlLogSheet.Range(Area)
                xlCell.Value = QCOSHWCount
            Next

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub


    Private Sub AddOutTopacsAASData(ByRef CostKaijiTopacsSheetData As DataTable, _
                                    ByRef PSDataTable As DataTable, _
                                    ByRef DetailDataTable As DataTable, _
                                    ByRef rtnPSTBL As DataTable, _
                                    ByRef rtnDetailTBL As DataTable)
        ''ﾒｯｾｰｼﾞ
        Dim unmatchReason As String
        Const ErrMsg001 As String = "Topacs起票番号、申請番号が一致するﾃﾞｰﾀがありません。"
        Const ErrMsg002 As String = "製品番号、数量が一致するﾃﾞｰﾀがありません。"
        Const ErrMsg003 As String = "COST情報がありません。"

        ''チェック結果
        Const ChkResult_Match As String = "Match"
        Const ChkResult_CostNG As String = "CostNG"         ''チェック結果：CostNull
        Const ChkResult_DetailNG As String = "DetailNG"     ''チェック結果：詳細ﾃﾞｰﾀが存在なし
        Dim ChkResult As Boolean
        Dim CostData As CostInfo

        ''紐付けのKey
        Dim Key_BRAND_AP_FORM As String            ''起票番号
        Dim Key_BRAND_AP_REQ As String             ''申請番号

        ''一時変数
        Dim insRow As DataRow
        Dim IsCostNull As Boolean                  ''CostがNullかどうか?
        Dim IsPSExists As Boolean                  ''PSが存在するかどうか?
        Dim isDetailExists As Boolean              ''詳細が存在するかどうか？
        Dim tmpBoxTopacsRow As DataRow             ''TopacsのBox情報
        Dim tmpDetailTopacsRow() As DataRow        ''Topacsの詳細情報
        Dim tmpPSRowA() As DataRow                 ''TopacsのBoxに紐づくPS情報
        Dim tmpPSRowB() As DataRow                 ''TopacsのBoxに紐づくPS情報
        Dim tmpDetailRow() As DataRow              ''PS情報に紐づく詳細情報

        ''SQL
        Dim BoxTopacsSQL As String                 ''BoxTopacsの抽出条件
        Dim DetailTopacsSQL As String              ''Topacsの詳細情報
        Dim PSSQL As String                        ''TopacsのBoxに紐づくPS情報
        Dim DetailSQL As String                    ''PS情報に紐づく詳細情報


        Try
            ''Box単位でTopacsﾃﾞｰﾀを検索
            BoxTopacsSQL = GetOutTopacsSQL()
            For Each tmpBoxTopacsRow In CostKaijiTopacsSheetData.Select(BoxTopacsSQL)

                ''初期化
                IsPSExists = True
                unmatchReason = ""

                ''一致するPSを検索
                Key_BRAND_AP_FORM = ExcelWrite.changeDBNullToString(tmpBoxTopacsRow.Item(TOPACSAAS_CLOUMNMNAME_KIHYONO))
                Key_BRAND_AP_REQ = ExcelWrite.changeDBNullToString(tmpBoxTopacsRow.Item(TOPACSAAS_CLOUMNMNAME_SHINSEINO)).Trim
                If Key_BRAND_AP_FORM.Trim <> "" Then
                    PSSQL = GetOutTopacsPSSQL(Key_BRAND_AP_FORM, Key_BRAND_AP_REQ, True)
                    tmpPSRowA = PSDataTable.Select(PSSQL)
                Else
                    ReDim tmpPSRowA(-1)
                End If
                If Key_BRAND_AP_REQ.Trim <> "" Then
                    PSSQL = GetOutTopacsPSSQL(Key_BRAND_AP_FORM, Key_BRAND_AP_REQ, False)
                    tmpPSRowB = PSDataTable.Select(PSSQL)
                Else
                    ReDim tmpPSRowB(-1)
                End If
                Call GetSumTmpPSRows(tmpPSRowA, tmpPSRowB)

                ''Topacsの詳細ﾃﾞｰﾀ取得　※詳細ﾃﾞｰﾀと突合せ
                DetailTopacsSQL = GetOutTopacsDetailSQL(tmpBoxTopacsRow)
                tmpDetailTopacsRow = CostKaijiTopacsSheetData.Select(DetailTopacsSQL, TOPACSAAS_CLOUMNMNAME_LINENO)

                ''不一致の場合
                If tmpPSRowA.Length = 0 Then
                    IsPSExists = False
                    GoTo NextTopacs
                End If

                ''PSﾃﾞｰﾀをループし、一致する詳細ﾃﾞｰﾀを探す
                IsCostNull = False
                isDetailExists = False
                For Each tmpPSRow As DataRow In tmpPSRowA

                    ''詳細のデータを取得
                    DetailSQL = GetOutDetailSQL(tmpPSRow)
                    tmpDetailRow = DetailDataTable.Select(DetailSQL, PSDETAILEXCEL_CLOUMNMNAME_IDENTITY_FLAG & " , " & PSDETAILEXCEL_CLOUMNMNAME_SORT_MES_CATEGORY & " , " & PSDETAILEXCEL_CLOUMNMNAME_EXCELROW)

                    ''完全に一致する構成かどうか調べる。
                    ChkResult = ChkDetailTopacs(tmpDetailTopacsRow, tmpDetailRow, CostData)

                    ''一致した場合、結果を書込
                    If ChkResult = True Then

                        ''CostのNullチェック　※製品不一致を優先してエラー出力
                        If ChkIsCostNull(tmpDetailTopacsRow) = False Then

                            ''PSの情報をセット
                            insRow = rtnPSTBL.NewRow
                            Call SetRtnPSTBLRow(insRow, tmpPSRow)
                            If IsNumeric(CostData.BoxQty) = True Then
                                insRow.Item(PSEXCEL_CLOUMNMNAME_COST) = CStr(CostData.PSCost / CostData.BoxQty)
                            Else
                                insRow.Item(PSEXCEL_CLOUMNMNAME_COST) = CStr(CostData.PSCost)
                            End If
                            rtnPSTBL.Rows.Add(insRow)

                            ''詳細の情報をセット
                            For Idx As Integer = 0 To UBound(tmpDetailRow)
                                ''セット済みの詳細は再取込みしない。
                                tmpDetailRow(Idx).Item(PSDETAILEXCEL_CLOUMNMNAME_ISCOSTSET) = "1"

                                insRow = rtnDetailTBL.NewRow
                                Call SetRtnDetailTBLRow(insRow, tmpDetailRow(Idx))
                                insRow.Item(PSDETAILEXCEL_CLOUMNMNAME_COST) = CStr(CostData.DetailCost(Idx))
                                rtnDetailTBL.Rows.Add(insRow)
                            Next

                            ''一致したPS行の取得
                            For Idx As Integer = 0 To UBound(tmpDetailTopacsRow)
                                tmpDetailTopacsRow(Idx).Item(TOPACSAAS_CLOUMNMNAME_MATCH_PSLINE) = tmpPSRow.Item(PSEXCEL_CLOUMNMNAME_LINE_NO)
                            Next
                            Exit For

                        Else
                            ''Cost不一致は取込済のFLGを立てる。
                            For Idx As Integer = 0 To UBound(tmpDetailRow)
                                tmpDetailRow(Idx).Item(PSDETAILEXCEL_CLOUMNMNAME_ISCOSTSET) = "1"
                            Next
                            IsCostNull = True
                            Exit For
                        End If
                    End If
                Next
NextTopacs:
                ''NGだった場合、NGだった構成に理由を書込
                ''申請/起票が存在しない。
                If unmatchReason = "" And _
                   IsPSExists = False Then
                    unmatchReason = ErrMsg001
                End If


                ''製品/数量が存在しない。
                If unmatchReason = "" And _
                   ChkResult = False Then
                    unmatchReason = ErrMsg002
                End If

                ''CostがNull
                If unmatchReason = "" And _
                   IsCostNull = True Then
                    unmatchReason = ErrMsg003
                End If

                ''不一致理由の書込 ※構成単位で書込
                If unmatchReason <> "" Then
                    For Each tmpRow As DataRow In tmpDetailTopacsRow
                        tmpRow.Item(TOPACSAAS_CLOUMNMNAME_UNMATREASON) = unmatchReason
                    Next
                End If

            Next
        Catch ex As Exception
            Throw ex

        End Try

    End Sub

    Private Function GetOutTopacsSQL() As String

        ''初期化
        Dim rtnValue As New StringBuilder
        GetOutTopacsSQL = rtnValue.ToString

        ''SQL取得
        rtnValue.Append(TOPACSAAS_CLOUMNMNAME_FH)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation("M"))
        rtnValue.Append(CommonConstant.SQL_STR_OR)
        rtnValue.Append(TOPACSAAS_CLOUMNMNAME_FH)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation("B"))

        Return rtnValue.ToString

    End Function

    Private Function GetOutTopacsPSSQL(ByVal Key_BRAND_AP_FORM As String, _
                                       ByVal Key_BRAND_AP_REQ As String, _
                                       ByVal isKihyo As Boolean) As String

        ''初期化
        Dim rtnValue As New StringBuilder
        GetOutTopacsPSSQL = rtnValue.ToString

        ''SQL取得
        rtnValue.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        rtnValue.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
        rtnValue.Append(CommonConstant.SQL_STR_IN)
        rtnValue.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        rtnValue.Append(StringEdit.EncloseSingleQuotation("1"))
        rtnValue.Append(CommonConstant.STR_COMMA)
        rtnValue.Append(StringEdit.EncloseSingleQuotation("2"))
        rtnValue.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
        rtnValue.Append(CommonConstant.SQL_STR_OR)
        rtnValue.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        rtnValue.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation("25"))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(PSEXCEL_CLOUMNMNAME_PATTERN)
        rtnValue.Append(CommonConstant.SQL_STR_IN)
        rtnValue.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_IBM_HW_AAS_BOX))
        rtnValue.Append(CommonConstant.STR_COMMA)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_IBM_HW_AAS_MES))
        rtnValue.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
        rtnValue.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
        rtnValue.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(PSEXCEL_CLOUMNMNAME_ST_COST)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation("Y"))
        If isKihyo = True Then
            ''起票情報でのみ検索
            rtnValue.Append(CommonConstant.SQL_STR_AND)
            rtnValue.Append(PSEXCEL_CLOUMNMNAME_BRAND_AP_FORM)
            rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
            rtnValue.Append(StringEdit.EncloseSingleQuotation(Key_BRAND_AP_FORM))
        Else
            ''申請情報でのみ検索
            rtnValue.Append(CommonConstant.SQL_STR_AND)
            rtnValue.Append(PSEXCEL_CLOUMNMNAME_BRAND_AP_REQ)
            rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
            rtnValue.Append(StringEdit.EncloseSingleQuotation(Key_BRAND_AP_REQ))
        End If

        Return rtnValue.ToString

    End Function

    Private Function GetOutChkDetailSQL(ByRef TmpPSRow As DataRow) As String

        ''初期化
        Dim rtnValue As New StringBuilder
        GetOutChkDetailSQL = rtnValue.ToString

        ''SQL取得
        rtnValue.Append(PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_CONTRACTNO)))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_FILE_NAME)))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(PSDETAILEXCEL_CLOUMNMNAME_PROD_ITEM01)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)))

        Return rtnValue.ToString

    End Function

    Private Sub DelMatchDetailDate(ByVal TmpPSRow As DataRow, _
                                   ByRef rtnDetailTBL As DataTable)

        ''Paymentに紐づく詳細の値を取得
        Dim tmpRows() As DataRow
        Dim Sql As New StringBuilder
        Sql.Append(PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)
        Sql.Append(CommonConstant.SQL_STR_EQUAL)
        Sql.Append(StringEdit.EncloseSingleQuotation(TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_CONTRACTNO)))
        Sql.Append(CommonConstant.SQL_STR_AND)
        Sql.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME)
        Sql.Append(CommonConstant.SQL_STR_EQUAL)
        Sql.Append(StringEdit.EncloseSingleQuotation(TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_FILE_NAME)))
        Sql.Append(CommonConstant.SQL_STR_AND)
        Sql.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
        Sql.Append(CommonConstant.SQL_STR_EQUAL)
        Sql.Append(StringEdit.EncloseSingleQuotation(TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)))
        Sql.Append(CommonConstant.SQL_STR_AND)
        Sql.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
        Sql.Append(CommonConstant.SQL_STR_EQUAL)
        Sql.Append(StringEdit.EncloseSingleQuotation(TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)))

        ''ﾃﾞｰﾀを削除する。
        tmpRows = rtnDetailTBL.Select(Sql.ToString)
        If tmpRows.Length = 0 Then
            Exit Sub
        End If
        For Idx As Integer = tmpRows.Length - 1 To 0 Step -1
            Call rtnDetailTBL.Rows.Remove(tmpRows(Idx))
        Next

    End Sub

    Private Sub UpdUnmatchReason(ByRef DetailRows() As DataRow, _
                                 ByRef TopacsSheetData As DataTable)

        Const ErrMsg001 As String = "構成の一部が未取込のため、取込ませんでした。"

        ''対象のﾃﾞｰﾀのNG理由を書き換える。        
        Dim Sql As New StringBuilder
        Dim tmpRows() As DataRow
        For Each tmpRow As DataRow In DetailRows

            ''一致ﾃﾞｰﾀの上書き
            Sql.Length = 0
            Sql.Append(TOPACSAAS_CLOUMNMNAME_DETAILROW)
            Sql.Append(CommonConstant.SQL_STR_EQUAL)
            Sql.Append(StringEdit.EncloseSingleQuotation(tmpRow.Item(PSDETAILEXCEL_CLOUMNMNAME_EXCELROW)))
            tmpRows = TopacsSheetData.Select(Sql.ToString)
            If tmpRows.Length <> 0 Then
                tmpRows(0).Item(TOPACSAAS_CLOUMNMNAME_UNMATREASON) = ErrMsg001
            End If
        Next

    End Sub

    Private Function GetOutTopacsDetailSQL(ByRef TmpPSRow As DataRow, _
                                           ByVal Key_BOXPROD_NO As String, _
                                           ByVal Key_PROD_NO As String, _
                                           ByVal Key_QTY As String) As String

        ''初期化
        Dim rtnValue As New StringBuilder
        GetOutTopacsDetailSQL = rtnValue.ToString

        ''SQL取得
        rtnValue.Append(PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_CONTRACTNO)))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_FILE_NAME)))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(PSDETAILEXCEL_CLOUMNMNAME_PROD_NO)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(Key_PROD_NO))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(PSDETAILEXCEL_CLOUMNMNAME_QTY_INTEGER)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(Key_QTY))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(PSDETAILEXCEL_CLOUMNMNAME_MES_CATEGORY)
        rtnValue.Append(CommonConstant.SQL_STR_NOT)
        rtnValue.Append(CommonConstant.SQL_STR_IN)
        rtnValue.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        rtnValue.Append(StringEdit.EncloseSingleQuotation("F"))
        rtnValue.Append(CommonConstant.STR_COMMA)
        rtnValue.Append(StringEdit.EncloseSingleQuotation("R"))
        rtnValue.Append(CommonConstant.STR_COMMA)
        rtnValue.Append(StringEdit.EncloseSingleQuotation("CR"))
        rtnValue.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(PSDETAILEXCEL_CLOUMNMNAME_ISCOSTSET)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation("0"))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(PSDETAILEXCEL_CLOUMNMNAME_PROD_ITEM01)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(Key_BOXPROD_NO))

        Return rtnValue.ToString

    End Function


    Private Function GetOutTopacsDetailSQL(ByRef tmpBoxTopacsRow As DataRow) As String

        ''初期化
        Dim rtnValue As New StringBuilder
        GetOutTopacsDetailSQL = rtnValue.ToString

        ''SQL取得
        rtnValue.Append(TOPACSAAS_CLOUMNMNAME_SHINSEINO)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(tmpBoxTopacsRow.Item(TOPACSAAS_CLOUMNMNAME_SHINSEINO)))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(TOPACSAAS_CLOUMNMNAME_KIHYONO)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(tmpBoxTopacsRow.Item(TOPACSAAS_CLOUMNMNAME_KIHYONO)))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(TOPACSAAS_CLOUMNMNAME_BOXCODEAH)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(tmpBoxTopacsRow.Item(TOPACSAAS_CLOUMNMNAME_BOXCODEAH)))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(TOPACSAAS_CLOUMNMNAME_BOXSEQ)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(tmpBoxTopacsRow.Item(TOPACSAAS_CLOUMNMNAME_BOXSEQ)))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(TOPACSAAS_CLOUMNMNAME_FH)
        rtnValue.Append(CommonConstant.SQL_STR_NOT_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation("S"))

        Return rtnValue.ToString

    End Function

    Private Function GetOutDetailSQL(ByRef TmpPSRow As DataRow) As String

        ''初期化
        Dim rtnValue As New StringBuilder
        GetOutDetailSQL = rtnValue.ToString

        ''SQL取得
        rtnValue.Append(PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_CONTRACTNO)))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_FILE_NAME)))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation(TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(PSDETAILEXCEL_CLOUMNMNAME_ISCOSTSET)
        rtnValue.Append(CommonConstant.SQL_STR_EQUAL)
        rtnValue.Append(StringEdit.EncloseSingleQuotation("0"))
        rtnValue.Append(CommonConstant.SQL_STR_AND)
        rtnValue.Append(PSDETAILEXCEL_CLOUMNMNAME_MES_CATEGORY)
        rtnValue.Append(CommonConstant.SQL_STR_NOT)
        rtnValue.Append(CommonConstant.SQL_STR_IN)
        rtnValue.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        rtnValue.Append(StringEdit.EncloseSingleQuotation("F"))
        rtnValue.Append(CommonConstant.STR_COMMA)
        rtnValue.Append(StringEdit.EncloseSingleQuotation("R"))
        rtnValue.Append(CommonConstant.STR_COMMA)
        rtnValue.Append(StringEdit.EncloseSingleQuotation("CR"))
        rtnValue.Append(CommonConstant.STR_RIGHT_PARENTHESIS)


        Return rtnValue.ToString

    End Function


    Private Sub SetRtnPSTBLRow(ByRef InsRow As DataRow, _
                               ByRef TmpPSRow As DataRow)

        InsRow.Item(PSEXCEL_CLOUMNMNAME_LINE_NO) = TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_LINE_NO)
        InsRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW) = TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_EXCELROW)
        InsRow.Item(PSEXCEL_CLOUMNMNAME_COST) = TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_COST)
        InsRow.Item(PSEXCEL_CLOUMNMNAME_COST_RATE) = TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_COST_RATE)
        InsRow.Item(PSEXCEL_CLOUMNMNAME_NEW_EXIST) = TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_NEW_EXIST)
        InsRow.Item(PSEXCEL_CLOUMNMNAME_PATTERN_CD) = TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
        InsRow.Item(PSEXCEL_CLOUMNMNAME_PATTERN) = TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_PATTERN)
        InsRow.Item(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH) = TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH)
        InsRow.Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM01) = TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
        InsRow.Item(PSEXCEL_CLOUMNMNAME_QTY) = TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_QTY)

        InsRow.Item(PSEXCEL_CLOUMNMNAME_CONTRACTNO) = TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_CONTRACTNO)
        InsRow.Item(PSEXCEL_CLOUMNMNAME_FILE_NAME) = TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_FILE_NAME)
        InsRow.Item(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX) = TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
        InsRow.Item(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR) = TmpPSRow.Item(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)

    End Sub

    Private Sub SetRtnDetailTBLRow(ByRef InsRow As DataRow, _
                                   ByRef TmpDetailRow As DataRow)

        InsRow.Item(PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO) = TmpDetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)
        InsRow.Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME) = TmpDetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME)
        InsRow.Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX) = TmpDetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
        InsRow.Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR) = TmpDetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
        InsRow.Item(PSDETAILEXCEL_CLOUMNMNAME_SEQ) = TmpDetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_SEQ)
        InsRow.Item(PSDETAILEXCEL_CLOUMNMNAME_MES_CATEGORY) = TmpDetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_MES_CATEGORY)
        InsRow.Item(PSDETAILEXCEL_CLOUMNMNAME_SPECIAL_FEATURE) = TmpDetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_SPECIAL_FEATURE)
        InsRow.Item(PSDETAILEXCEL_CLOUMNMNAME_EXCELROW) = TmpDetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_EXCELROW)
        InsRow.Item(PSDETAILEXCEL_CLOUMNMNAME_COST_RATE) = TmpDetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_COST_RATE)
        InsRow.Item(PSDETAILEXCEL_CLOUMNMNAME_COST) = TmpDetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_COST)
        InsRow.Item(PSDETAILEXCEL_CLOUMNMNAME_QTY_INTEGER) = TmpDetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_QTY_INTEGER)
        InsRow.Item(PSDETAILEXCEL_CLOUMNMNAME_PROD_ITEM01) = TmpDetailRow.Item(PSDETAILEXCEL_CLOUMNMNAME_PROD_ITEM01)

    End Sub


    Private Sub GetSumTmpPSRows(ByRef tmpPSRows() As DataRow, _
                                ByRef tmpSinseiRows() As DataRow)

        ''起票/申請の検索件数が0件なら、終了
        If tmpSinseiRows.Length = 0 Then
            Exit Sub
        End If

        ''申請のみの検索結果
        Dim tmpRow As DataRow
        For Each tmpRow In tmpSinseiRows
            If Array.IndexOf(tmpPSRows, tmpRow) = -1 Then
                ReDim Preserve tmpPSRows(UBound(tmpPSRows) + 1)
                tmpPSRows(UBound(tmpPSRows)) = tmpRow
            End If
        Next

    End Sub

    Private Function ChkDetailTopacs(ByRef tmpDetailTopacsRow() As DataRow, _
                                     ByRef tmpDetailRow() As DataRow, _
                                     ByRef CostData As CostInfo) As Boolean


        ''初期化
        Dim rtnCostData As CostInfo
        ChkDetailTopacs = True

        Dim boxQty As Decimal
        Dim Key_PROD_NO As String
        Dim Key_QTY As String

        ''              ▼以下、一致/不一致を判定
        ''-------------------------------------------------------------
        ''詳細とTopacsの構成が完全に一致するか判定
        Dim isCostNull As Boolean = False
        Dim isMatch As Boolean = False
        Dim isMatchDetail As Boolean = True
        Dim PROD_NO As String
        Dim Qty As String
        Dim SumCost As Decimal
        Dim CostList() As Decimal
        ReDim CostList(-1)

        ''製品構成不一致
        If tmpDetailTopacsRow.Length <> tmpDetailRow.Length Then
            Return False
            Exit Function
        End If

        ''Topacsﾙｰﾌﾟ
        For Idx As Integer = 0 To UBound(tmpDetailTopacsRow)

            ''製品番号/数量の加工
            Select Case tmpDetailTopacsRow(Idx).Item(TOPACSAAS_CLOUMNMNAME_FH)
                Case "M", _
                     "B"
                    boxQty = CDec(tmpDetailTopacsRow(Idx).Item(TOPACSAAS_CLOUMNMNAME_NAHD)) + _
                             CDec(tmpDetailTopacsRow(Idx).Item(TOPACSAAS_CLOUMNMNAME_AJAH))
                    Key_PROD_NO = tmpDetailTopacsRow(Idx).Item(TOPACSAAS_CLOUMNMNAME_CODEAH).Substring(0, 4) & "-" & _
                                  tmpDetailTopacsRow(Idx).Item(TOPACSAAS_CLOUMNMNAME_CODEAH).Substring(4, 3)
                Case Else
                    Key_PROD_NO = tmpDetailTopacsRow(Idx).Item(TOPACSAAS_CLOUMNMNAME_CODEAH).PadLeft(4, "0")
            End Select
            Key_QTY = CDec(tmpDetailTopacsRow(Idx).Item(TOPACSAAS_CLOUMNMNAME_NAHD)) + _
                      CDec(tmpDetailTopacsRow(Idx).Item(TOPACSAAS_CLOUMNMNAME_AJAH))


            ''製品/数量の一致を確認
            If Key_PROD_NO = tmpDetailRow(Idx).Item(PSDETAILEXCEL_CLOUMNMNAME_PROD_NO) And _
               Key_QTY = tmpDetailRow(Idx).Item(PSDETAILEXCEL_CLOUMNMNAME_QTY_INTEGER) And _
               tmpDetailRow(Idx).Item(PSDETAILEXCEL_CLOUMNMNAME_ISCOSTSET) = "0" Then

                ''一致の場合
                ReDim Preserve CostList(UBound(CostList) + 1)
                If IsNumeric(tmpDetailTopacsRow(Idx).Item(TOPACSAAS_CLOUMNMNAME_COSTMCAH)) = True Then
                    SumCost = SumCost + (CDec(tmpDetailTopacsRow(Idx).Item(TOPACSAAS_CLOUMNMNAME_COSTMCAH)) * _
                                         CDec(tmpDetailRow(Idx).Item(PSDETAILEXCEL_CLOUMNMNAME_QTY_INTEGER)))
                    CostList(UBound(CostList)) = tmpDetailTopacsRow(Idx).Item(TOPACSAAS_CLOUMNMNAME_COSTMCAH)
                End If
            Else
                ''不一致の場合
                isMatchDetail = False
                Exit For
            End If
        Next

        ''一致/不一致を返す。
        ''製品不一致
        If isMatchDetail = False Then
            Return False
        End If

        ''一致
        CostData.BoxQty = boxQty
        CostData.PSCost = SumCost
        CostData.DetailCost = CostList
        Return True

    End Function

    Private Function ChkIsCostNull(ByRef tmpDetailTopacsRow() As DataRow) As Boolean

        ''初期化
        ChkIsCostNull = False

        ''Cost = Nullを検索する。
        For Each tmpRow As DataRow In tmpDetailTopacsRow
            If IsNumeric(tmpRow.Item(TOPACSAAS_CLOUMNMNAME_COSTMCAH)) = False Then
                Return True
            End If
        Next

    End Function

    Private Sub OutTopacsReadLinno(ByVal SheetNM As String, _
                                   ByRef TopacsTBL As DataTable, _
                                   ByRef xlLogSheet As Excel.Worksheet)

        Const MSG_001 As String = "行番号：@00000000にCostを書込ました。"

        Dim xlCell As Excel.Range
        Dim logRow As String                                    ''ログの書込位置
        Dim logStr As Integer                                   ''ログの開始位置
        Dim logLinnoNm As String                                ''DataTableの項目名
        Dim logLinnoList(TopacsTBL.Rows.Count - 1, 0) As Object   ''出力するLinnoの配列

        Try
            ''1件もﾃﾞｰﾀが存在しなければ、処理終了
            If TopacsTBL.Rows.Count = 0 Then
                Exit Sub
            End If

            ''書込位置/項目名取得
            Select Case SheetNM
                Case "AAS"
                    logRow = "S"
                    logStr = ExcelWrite.EXCEL_TOPACS_AASDATE_OUTROW
                    logLinnoNm = TOPACSAAS_CLOUMNMNAME_MATCH_PSLINE
                Case "QCOSHW"
                    logRow = "P"
                    logStr = ExcelWrite.EXCEL_TOPACS_QCOSHWDATE_OUTROW
                    logLinnoNm = TOPACSQCOSHW_CLOUMNMNAME_MATCH_PSLINE
                Case "QCOSSW"
                    logRow = "O"
                    logStr = ExcelWrite.EXCEL_TOPACS_QCOSSWDATE_OUTROW
                    logLinnoNm = TOPACSQCOSSW_CLOUMNMNAME_MATCH_PSLINE
            End Select

            ''書込範囲/ﾃﾞｰﾀを取得
            Dim Area As String
            Dim outLog As String
            If SheetNM <> "AAS" Then
                Area = logRow & logStr & _
                       ":" & _
                       logRow & logStr + TopacsTBL.Rows.Count - 1
                For idx As Integer = 0 To UBound(logLinnoList, 1)
                    If TopacsTBL.Rows(idx).Item(logLinnoNm) <> "" Then
                        logLinnoList(idx, 0) = MSG_001.Replace("@00000000", _
                                                               TopacsTBL.Rows(idx).Item(logLinnoNm).ToString.PadLeft(8, "0"))
                    Else
                        logLinnoList(idx, 0) = ""
                    End If
                Next
                ''書込
                xlCell = xlLogSheet.Range(Area)
                xlCell.Value = logLinnoList
            Else
                For idx As Integer = 0 To UBound(logLinnoList, 1)
                    Area = logRow & CInt(TopacsTBL.Rows(idx).Item(TOPACSAAS_CLOUMNMNAME_EXCELROW))
                    If TopacsTBL.Rows(idx).Item(logLinnoNm) <> "" Then
                        outLog = MSG_001.Replace("@00000000", _
                                                  TopacsTBL.Rows(idx).Item(logLinnoNm).ToString.PadLeft(8, "0"))
                    Else
                        outLog = ""
                    End If
                    ''書込
                    xlCell = xlLogSheet.Range(Area)
                    xlCell.Value = outLog
                Next
            End If

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, True)
            GC.Collect()

        End Try

    End Sub

    ''' <summary>
    ''' 機能：DetailTBLから、S行を削除する。
    ''' 説明：
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>	
    Private Sub DelSLineDate(ByVal Type As String, _
                             ByRef DetailTBL As DataTable)

        ''S行検索    
        Dim SQL As New StringBuilder
        Dim delRows() As DataRow
        Select Case Type
            Case "Detail"
                SQL.Append(PSDETAILEXCEL_CLOUMNMNAME_IDENTITY_FLAG)
                SQL.Append(CommonConstant.SQL_STR_EQUAL)
                SQL.Append(StringEdit.EncloseSingleQuotation("S"))
            Case "Cost"
                SQL.Append(COSTDETAILEXCEL_CLOUMNMNAME_IDENTITY_FLAG)
                SQL.Append(CommonConstant.SQL_STR_EQUAL)
                SQL.Append(StringEdit.EncloseSingleQuotation("S"))
        End Select

        ''S行削除
        For Each delRow As DataRow In DetailTBL.Select(SQL.ToString)
            Call DetailTBL.Rows.Remove(delRow)
        Next

    End Sub

    ''' <summary>
    ''' 機　能：参考シートの存在判定
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function isResSheetExist(ByRef xlBook As Excel.Workbook) As Boolean

        ''初期化
        isResSheetExist = False
        Dim xlSheet As Excel.Worksheet
        Try
            For Idx As Integer = 1 To xlBook.Worksheets.Count
                xlSheet = xlBook.Worksheets(Idx)
                If xlSheet.Name = ExcelWrite.EXCEL_COSTDATE_REFSHEET And _
                   xlSheet.Visible = True Then
                    isResSheetExist = True
                    Exit Function
                End If
            Next
        Catch ex As Exception
            Throw ex
        Finally
            ''Excelオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try

    End Function

    ''' <summary>
    ''' 機　能：Bookから、不要なボタンを削除
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub DelButton(ByRef xlBook As Excel.Workbook)

        Dim Idx As Integer
        Dim xlRow As Excel.Range
        Dim delSheet As Excel.Worksheet
        Dim shape As Excel.Shape
        Try
            ''ﾎﾞﾀﾝ削除/行の高さ変更
            delSheet = xlBook.Worksheets(ExcelWrite.EXCEL_COSTDATE_REFSHEET)
            For Each shape In delSheet.Shapes
                If shape.Name = "PS⇔詳細表示" Then
                    Call shape.Delete()
                End If
            Next
            xlRow = delSheet.Rows("1:1")
            xlRow.RowHeight = 11.25

            delSheet = xlBook.Worksheets(ExcelWrite.EXCEL_COSTDATE_DETAILSHEET)
            For Each shape In delSheet.Shapes
                If shape.Name = "PS⇔詳細表示" Then
                    Call shape.Delete()
                End If
            Next
            xlRow = delSheet.Rows("1:1")
            xlRow.RowHeight = 11.25

        Catch ex As Exception
            Throw ex
        Finally
            ExcelObjRelease.ReleaseExcelObj(shape, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlRow, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(delSheet, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try
    End Sub


    ''' <summary>
    ''' WorkSheetの位置を移動する。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub MoveSheets(ByRef xlBook As Excel.Workbook)

        Dim xlmovSheet As Excel.Worksheet
        Dim xlidxSheet As Excel.Worksheet
        Try
            ''シート順：WS1⇒Payment⇒参考シート⇒詳細シート
            xlidxSheet = xlBook.Worksheets(1)
            xlmovSheet = xlBook.Worksheets(ExcelWrite.EXCEL_COSTDATE_WS1)
            xlBook.Activate()
            Call xlmovSheet.Move(Before:=xlidxSheet)

            xlidxSheet = xlBook.Worksheets(ExcelWrite.EXCEL_COSTDATE_WS1)
            xlmovSheet = xlBook.Worksheets(ExcelWrite.EXCEL_COSTDATE_PSSHEET)
            xlBook.Activate()
            Call xlmovSheet.Move(After:=xlidxSheet)

            xlidxSheet = xlBook.Worksheets(ExcelWrite.EXCEL_COSTDATE_PSSHEET)
            xlmovSheet = xlBook.Worksheets(ExcelWrite.EXCEL_COSTDATE_REFSHEET)
            xlBook.Activate()
            Call xlmovSheet.Move(After:=xlidxSheet)

            xlidxSheet = xlBook.Worksheets(ExcelWrite.EXCEL_COSTDATE_REFSHEET)
            xlmovSheet = xlBook.Worksheets(ExcelWrite.EXCEL_COSTDATE_DETAILSHEET)
            xlBook.Activate()
            Call xlmovSheet.Move(After:=xlidxSheet)
        Catch ex As Exception
            Throw ex
        Finally
            ExcelObjRelease.ReleaseExcelObj(xlmovSheet, True)
            ExcelObjRelease.ReleaseExcelObj(xlidxSheet, True)
            Call GC.Collect()
        End Try
    End Sub

    '名前の定義を削除
    Private Sub DelXlsNames(ByRef xlBook As Excel.Workbook)
        Dim xlName As Excel.Name
        Try
            For Each xlName In xlBook.Names
                If xlName.Name.ToString.IndexOf("SUMIFS") = -1 Then
                    xlName.Delete()
                End If
            Next
        Catch ex As Exception
            Throw (ex)
        Finally
            ExcelObjRelease.ReleaseExcelObj(xlName, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try
    End Sub

    ''' <summary>
    ''' 機　能：価格開示 ベーシックセレクションファイルの作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateKakakukaijiBasicSelection(ByVal PSDataTable As DataTable) As Boolean

        ''初期化
        CreateKakakukaijiBasicSelection = False

        Try

            ''価格開示ファイルに出力するファイルの抽出
            Dim rows() As DataRow
            Dim filter As String
            Dim filter2 As String
            filter = GetCostKaijiFiler("43", CommonConstant.PATTERNNM_BASICSELECTION)
            filter2 = GetCostKaijiFiler("44", CommonConstant.PATTERNNM_BASICSELECTION)
            filter = "(" & filter & ") OR (" & filter2 & ")"
            rows = PSDataTable.Select(filter, PSEXCEL_CLOUMNMNAME_EXCELROW)

            ''作成対象のデータが存在するかどうか？
            If rows.Length < 1 Then
                Exit Function
            End If

            ''出力する価格開示ファイル名の取得
            Dim ofm As New OioFileManage
            Dim BSFileDir As String
            Dim BSFileFileNM As String
            Dim BSFilePath As String

            ''フォルダ
            BSFileDir = ofm.GetLocalCostOutputFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

            ''ファイル名
            BSFileFileNM = GetOutKakakukaijiFileNM("43")

            ''パス
            BSFilePath = BSFileDir & BSFileFileNM

            ''価格開示ファイルの作成
            Return CreateBasicSelectionFile("43", "", rows, BSFilePath)

        Catch ex As Exception
            MsgBox(ex.Message, vbCritical, "")
        End Try

    End Function


    ''' <summary>
    ''' 機　能：ベーシックセレクション料金のファイルの価格開示ファイルのテンプレート作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateBasicSelectionFile(ByVal patternCD As String, _
                                              ByVal newExist As String, _
                                              ByVal PSRows() As DataRow, _
                                              ByVal outFileNm As String) As Boolean
        ''初期化
        CreateBasicSelectionFile = False

        Dim xlApp As New Excel.Application
        Dim xlOutBook As Excel.Workbook
        Dim xlPSBook As Excel.Workbook

        'Excel初期化
        xlApp.EnableEvents = False
        xlApp.DisplayAlerts = False

        Try

            ''テンプレートファイルのOPEN
            Dim ofm As New OioFileManage
            Dim TemplateFileDir As String
            Dim TemplateFileNM As String
            Dim TemplateFilePath As String
            TemplateFileDir = ofm.GetLocalTemplateFolder
            TemplateFileNM = GetTemplateFileNM(patternCD)
            TemplateFilePath = TemplateFileDir & TemplateFileNM
            xlOutBook = xlApp.Workbooks.Open(TemplateFilePath)

            ''個別PSBookの取得
            Dim PsFileDir As String
            Dim PsFileNM As String
            Dim PsFilePath As String
            PsFileDir = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFileNM = ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFilePath = PsFileDir & PsFileNM

            ''個別PSBookのOpen
            xlPSBook = xlApp.Workbooks.Open(PsFilePath)

            ''個別PSファイルの行コピー
            Call CopyPSRows(xlOutBook, PSRows)

            ''WS1シートのコピー
            Call CopyWS1(xlOutBook, xlPSBook)

            ''価格開示ファイルの保存
            Call DelXlsNames(xlOutBook)
            xlOutBook.Activate()
            xlOutBook.SaveAs(Filename:=outFileNm, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

            CreateBasicSelectionFile = True

        Catch ex As Exception
            Throw ex

        Finally

            ''オブジェクトの解放
            If IsNothing(xlOutBook) = False Then
                xlOutBook.Close(False)
            End If
            If IsNothing(xlPSBook) = False Then
                xlPSBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlOutBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
        End Try

    End Function

    ''' <summary>
    ''' 機　能：ベーシックセレクション追加サービス料金のファイルの価格開示ファイルのテンプレート作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateBasicSelectionServiceFile(ByVal patternCD As String, _
                                                     ByVal newExist As String, _
                                                     ByVal PSRows() As DataRow, _
                                                     ByVal outFileNm As String) As Boolean

        ''初期化
        CreateBasicSelectionServiceFile = False

        Dim xlApp As New Excel.Application
        Dim xlOutBook As Excel.Workbook
        Dim xlPSBook As Excel.Workbook

        'Excel初期化
        xlApp.EnableEvents = False
        xlApp.DisplayAlerts = False

        Try

            ''テンプレートファイルのOPEN
            Dim ofm As New OioFileManage
            Dim TemplateFileDir As String
            Dim TemplateFileNM As String
            Dim TemplateFilePath As String
            TemplateFileDir = ofm.GetLocalTemplateFolder
            TemplateFileNM = GetTemplateFileNM(patternCD)
            TemplateFilePath = TemplateFileDir & TemplateFileNM
            xlOutBook = xlApp.Workbooks.Open(TemplateFilePath)

            ''個別PSBookの取得
            Dim PsFileDir As String
            Dim PsFileNM As String
            Dim PsFilePath As String
            PsFileDir = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFileNM = ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFilePath = PsFileDir & PsFileNM

            ''個別PSBookのOpen
            xlPSBook = xlApp.Workbooks.Open(PsFilePath)

            ''個別PSファイルの行コピー
            Call CopyPSRows(xlOutBook, PSRows)

            ''WS1シートのコピー
            Call CopyWS1(xlOutBook, xlPSBook)

            ''価格開示ファイルの保存
            Call DelXlsNames(xlOutBook)
            xlOutBook.Activate()
            xlOutBook.SaveAs(Filename:=outFileNm, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

            CreateBasicSelectionServiceFile = True

        Catch ex As Exception
            Throw ex

        Finally

            ''オブジェクトの解放
            If IsNothing(xlOutBook) = False Then
                xlOutBook.Close(False)
            End If
            If IsNothing(xlPSBook) = False Then
                xlPSBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlOutBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
        End Try

    End Function

    ''' <summary>
    ''' 機　能：価格開示 ServiceIntegratorファイルの作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateKakakukaijiServiceIntegrator(ByVal PSDataTable As DataTable) As Boolean

        ''初期化
        CreateKakakukaijiServiceIntegrator = False

        Try

            ''価格開示ファイルに出力するファイルの抽出
            Dim rows() As DataRow
            Dim filter As String
            Dim filter2 As String
            filter = GetCostKaijiFiler_SI("")    '独自フィルター記述
            rows = PSDataTable.Select(filter, PSEXCEL_CLOUMNMNAME_EXCELROW)

            ''作成対象のデータが存在するかどうか？
            If rows.Length < 1 Then
                Exit Function
            End If

            ''出力する価格開示ファイル名の取得
            Dim ofm As New OioFileManage
            Dim SIFileDir As String
            Dim SIFileFileNM As String
            Dim SIFilePath As String

            ''フォルダ
            SIFileDir = ofm.GetLocalCostOutputFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)

            ''ファイル名
            SIFileFileNM = GetOutKakakukaijiFileNM("SI")

            ''パス
            SIFilePath = SIFileDir & SIFileFileNM

            ''価格開示ファイルの作成
            Return CreateServiceIntegtatorFile("1", "", rows, SIFilePath)

        Catch ex As Exception
            MsgBox(ex.Message, vbCritical, "")
        End Try

    End Function

    ''' <summary>
    ''' 機　能：価格開示Topacsファイルの作成
    ''' </summary>
    ''' <param name="PSDataTable"></param>
    ''' <param name="PSDetailDataTable"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CreateKakakukaijiePricer(ByVal PSDataTable As DataTable,
                                              ByVal PSDetailDataTable As DataTable) As Boolean

        Const Pattern As String = "e-Pricer"

        Dim drPs() As DataRow
        Dim drPsd() As DataRow
        Dim strfilter As String
        Dim ofm As New OioFileManage
        Dim strOutputFolder As String
        Dim strFileName As String
        Dim strPath As String

        CreateKakakukaijiePricer = False

        Try
            '承認番号が入力されているのPaymentﾃﾞｰﾀを抽出
            strfilter = GetCostKaijiFiler(Pattern, "")
            drPs = PSDataTable.Select(strfilter, PSEXCEL_CLOUMNMNAME_EXCELROW)

            'Paymentに紐づく詳細データを抽出 
            '※注意：ﾃﾞｰﾀなし = Nothingを返す
            Call GetCostKaijiDetailRows(Pattern, drPs, PSDetailDataTable, drPsd)

            '作成対象のデータが存在するかどうか？
            If IsNothing(drPs) = True OrElse _
               drPs.Length < 1 Then
                Exit Function
            End If

            '出力するCOST開示ファイル名の取得
            'フォルダ名取得
            strOutputFolder = ofm.GetLocalCostOutputFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO, Me.createFileTime)
            'ファイル名取得
            strFileName = GetOutKakakukaijiFileNM(Pattern)
            '出力パス設定
            strPath = strOutputFolder & strFileName

            'COST開示ファイルの作成
            Return CreateePricerFile(Pattern, drPs, drPsd, strPath, PSDetailDataTable)

        Catch ex As Exception
            MsgBox(ex.Message, vbCritical, "CreateKakakukaijiePricer")
        End Try

    End Function

    ''' <summary>
    ''' 機　能：個別PS　テーブルデータのファイル毎のフィルタ条件を取得
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetCostKaijiFiler_SI(ByVal PatternNM As String) As String

        GetCostKaijiFiler_SI = ""

        Dim Filter As New StringBuilder

        ''=====================================
        ''				直接入力以外
        ''=====================================

        ''基本条件
        ''※数量マイナスは対象外
        Filter.Append(PSEXCEL_CLOUMNMNAME_QTY)
        Filter.Append(CommonConstant.SQL_STR_NOT)
        Filter.Append(CommonConstant.SQL_STR_LIKE)
        Filter.Append(StringEdit.EncloseSingleQuotation("-*"))
        Filter.Append(CommonConstant.SQL_STR_AND)

        ''※
        Filter.Append(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)
        Filter.Append(CommonConstant.SQL_STR_EQUAL)
        Filter.Append(StringEdit.EncloseSingleQuotation(""))
        Filter.Append(CommonConstant.SQL_STR_AND)
        Filter.Append(PSEXCEL_CLOUMNMNAME_ST_COST)
        Filter.Append(CommonConstant.SQL_STR_EQUAL)
        Filter.Append(StringEdit.EncloseSingleQuotation("Y"))

        ''コメント行は出力しない。
        Filter.Append(CommonConstant.SQL_STR_AND)
        Filter.Append(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
        Filter.Append(CommonConstant.SQL_STR_NOT)
        Filter.Append(CommonConstant.SQL_STR_IN)
        Filter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
        Filter.Append(StringEdit.EncloseSingleQuotation("C"))
        Filter.Append(CommonConstant.STR_COMMA)
        Filter.Append(StringEdit.EncloseSingleQuotation("N"))
        Filter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

        ''パターンCD毎の条件
        Filter.Append(CommonConstant.SQL_STR_AND)
        Filter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
        Filter.Append(CommonConstant.SQL_STR_EQUAL)
        Filter.Append(StringEdit.EncloseSingleQuotation("1"))

        Filter.Append(CommonConstant.SQL_STR_AND)
        Filter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
        Filter.Append(CommonConstant.SQL_STR_LIKE)
        Filter.Append(StringEdit.EncloseSingleQuotation("666%"))

        Return Filter.ToString

    End Function

    ''' <summary>
    ''' 機　能：ServiceIntegratorファイルの価格開示ファイルのテンプレート作成
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CreateServiceIntegtatorFile(ByVal patternCD As String, _
                                                 ByVal newExist As String, _
                                                 ByVal PSRows() As DataRow, _
                                                 ByVal outFileNm As String) As Boolean
        ''初期化
        CreateServiceIntegtatorFile = False

        Dim xlApp As New Excel.Application
        Dim xlOutBook As Excel.Workbook
        Dim xlPSBook As Excel.Workbook

        'Excel初期化
        xlApp.EnableEvents = False
        xlApp.DisplayAlerts = False

        Try

            ''テンプレートファイルのOPEN
            Dim ofm As New OioFileManage
            Dim TemplateFileDir As String
            Dim TemplateFileNM As String
            Dim TemplateFilePath As String
            TemplateFileDir = ofm.GetLocalTemplateFolder
            TemplateFileNM = GetTemplateFileNM(patternCD, "SI")
            TemplateFilePath = TemplateFileDir & TemplateFileNM
            xlOutBook = xlApp.Workbooks.Open(TemplateFilePath)

            ''個別PSBookの取得
            Dim PsFileDir As String
            Dim PsFileNM As String
            Dim PsFilePath As String
            PsFileDir = ofm.GetLocalCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFileNM = ofm.GetPaymentLineExcelFileNm(CommonVariable.CPNO, CommonVariable.CONTRACTNO)
            PsFilePath = PsFileDir & PsFileNM

            ''個別PSBookのOpen
            xlPSBook = xlApp.Workbooks.Open(PsFilePath)

            ''個別PSファイルの行コピー
            Call CopyPSRows(xlOutBook, PSRows)

            ''WS1シートのコピー
            Call CopyWS1(xlOutBook, xlPSBook)

            ''価格開示ファイルの保存
            Call DelXlsNames(xlOutBook)
            xlOutBook.Activate()
            xlOutBook.SaveAs(Filename:=outFileNm, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

            CreateServiceIntegtatorFile = True

        Catch ex As Exception
            Throw ex

        Finally

            ''オブジェクトの解放
            If IsNothing(xlOutBook) = False Then
                xlOutBook.Close(False)
            End If
            If IsNothing(xlPSBook) = False Then
                xlPSBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlOutBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPSBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = True
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
        End Try

    End Function

    ''' <summary>
    ''' 機　能：指定IDを持つ行の起票番号・申請番号を取得する。
    ''' 説　明：
    ''' </summary>
    ''' <param name="FileName"></param>
    ''' <param name="SUFFIX"></param>
    ''' <param name="SUFFIX_INTR"></param>
    ''' <param name="CONTRACT"></param>
    ''' <param name="Brand_AP_CONF"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetPaymentPRM(ByVal FileName As String, _
                                   ByVal SUFFIX As String, _
                                   ByVal SUFFIX_INTR As String, _
                                   ByVal CONTRACT As String, _
                                   ByRef Brand_AP_CONF As String) As Boolean

        ''初期化
        GetPaymentPRM = False

        Brand_AP_CONF = ""

        Try
            For ii As Integer = 0 To CountB - 1
                ''PSのキー値を比較
                If BrandT(ii).FileName = FileName And _
                   BrandT(ii).SUFFIX = SUFFIX And _
                   BrandT(ii).INTR = SUFFIX_INTR And _
                   BrandT(ii).CONTRACT = CONTRACT And _
                   BrandT(ii).PATERN_NO = "4" Then

                    Brand_AP_CONF = BrandT(ii).Brand_AP_Conf
                    Exit For
                End If
            Next

            GetPaymentPRM = True

        Catch ex As Exception
            Throw ex

        Finally

        End Try

    End Function

    ''' <summary>
    ''' 機　能：指定起票番号・申請番号の行数を取得する。
    ''' </summary>
    ''' <param name="Brand_AP_CONF"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetCostRow(ByVal Brand_AP_CONF As String) As Integer

        ''初期化
        GetCostRow = 0

        Try
            For ii As Integer = 0 To CountB - 1
                ''PSのキー値を比較
                If CostData(ii).Brand_AP_Conf = Brand_AP_CONF Then
                    GetCostRow = CostData(ii).LineNo
                    Exit For
                End If
            Next

        Catch ex As Exception
            Throw ex

        Finally

        End Try

    End Function

    ''' <summary>
    ''' 機　能：COST入力シートを編集する。
    ''' </summary>
    ''' <param name="xlOutBook"></param>
    ''' <remarks></remarks>
    Private Sub EditCostSheet(ByRef xlOutBook As Excel.Workbook)

        Const EXCEL_PAYMENTLINEDATA_COSTINPUTSHEET As String = "COST入力"
        Const EXCEL_PAYMENTLINEDATA_OUTROW As Integer = 5

        Dim outSheet As Excel.Worksheet
        Dim inRange As Excel.Range
        Dim outRange As Excel.Range
        Dim entryRange As Excel.Range
        Dim enColumns As Excel.Range

        Try
            'シートのセット
            outSheet = xlOutBook.Worksheets(EXCEL_PAYMENTLINEDATA_COSTINPUTSHEET)

            Dim copyValue(CountC, 12) As Object

            ''テンプレート行の式をセット
            Dim formulaObj(,) As Object
            inRange = outSheet.Range("A2:M2")
            formulaObj = inRange.FormulaR1C1

            For ii As Integer = 0 To CountC - 1

                ''対象の出力データを格納
                copyValue(ii, 0) = CostData(ii).Brand_AP_Conf
                copyValue(ii, 1) = ""
                copyValue(ii, 2) = ""
                copyValue(ii, 3) = ""
                copyValue(ii, 5) = ""

                copyValue(ii, 6) = "=SUMIFS(詳細!$N$5:$N$" & ExcelWrite.CISCO_EXCEL_DETAILLINEDATE_OUTROW + MaxSS - 1 & _
                                   ",詳細!$C$5:$C$" & ExcelWrite.CISCO_EXCEL_DETAILLINEDATE_OUTROW + MaxSS - 1 & _
                                   ",COST入力!F" & EXCEL_PAYMENTLINEDATA_OUTROW + ii & _
                                   ",詳細!$I$5:$I$" & ExcelWrite.CISCO_EXCEL_DETAILLINEDATE_OUTROW + MaxSS - 1 & ",""S"")"

                copyValue(ii, 7) = "=SUMIF(Payment!$H$6:$H$" & ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + MaxPS - 1 & _
                                   ",COST入力!F" & EXCEL_PAYMENTLINEDATA_OUTROW + ii & _
                                   ",Payment!$V$6:$V$" & ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + MaxPS - 1 & ")"

                copyValue(ii, 8) = "=SUMIFS(詳細!$Q$5:$Q$" & ExcelWrite.CISCO_EXCEL_DETAILLINEDATE_OUTROW + MaxSS - 1 & _
                                   ",詳細!$C$5:$C$" & ExcelWrite.CISCO_EXCEL_DETAILLINEDATE_OUTROW + MaxSS - 1 & _
                                   ",COST入力!F" & EXCEL_PAYMENTLINEDATA_OUTROW + ii & _
                                   ",詳細!$I$5:$I$" & ExcelWrite.CISCO_EXCEL_DETAILLINEDATE_OUTROW + MaxSS - 1 & ",""S"")"

                ''Template行にExcel式があれば、Template行のExcel式をセットする。
                Call SetTemplateFormula(ii, copyValue, formulaObj)
            Next

            ''書式をコピー & ペースト
            Dim copyArea As String = "A5:M" & EXCEL_PAYMENTLINEDATA_OUTROW + CountC - 1

            inRange = outSheet.Range("A2:M2")
            inRange.Copy()
            outRange = outSheet.Range(copyArea)
            outRange.PasteSpecial()

            ''値をセット
            outRange.Formula = copyValue

        Catch ex As Exception
            Throw ex

        Finally

        End Try

    End Sub


    ''' <summary>
    ''' 機　能：個別PSファイルから価格開示ファイルへ出力対象の行をコピー&ペーストする。(CISCO HW用)
    ''' 説　明：
    ''※修正箇所：Template行にExcel式があれば、Template式をセットする。
    ''      　　：Cost期間合計と、請求期間を項目追加する。
    ''      　　：項目追加によってセルの出力位置がズレるため修正する。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub CopyPSRows2(ByRef xlOutBook As Excel.Workbook, _
                            ByVal rows() As DataRow, _
                            Optional ByVal newExist As String = "新規")

        Dim outSheet As Excel.Worksheet
        Dim inRange As Excel.Range
        Dim outRange As Excel.Range
        Dim entryRange As Excel.Range
        Dim enColumns As Excel.Range
        Try

            'シートのセット
            outSheet = xlOutBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)

            ''既存AASHWMAのBrandの算出に変換テーブルを使用
            Dim ConvertClientValueData As DataTable
            Dim con As OleDbConnection
            Dim mmc As New MasterMdbControl
            Dim mdbContrl As New MUSE.DataAccess.OleDb.OleDbConvertClientValue
            con = mmc.GetOleDBConnection(CommonVariable.MdbPW)
            ConvertClientValueData = mdbContrl.SelectDataTable(con)
            If rows(0).Item(PSEXCEL_CLOUMNMNAME_PATTERN_CD) = "15" And _
               newExist = "既存" Then

                ''備考 ～ Payment対象行を再表示する。
                Const DispArea As String = "AD:AI"
                enColumns = outSheet.Columns(DispArea)
                enColumns.Hidden = False

            End If

            ''テンプレート行の式をセット
            Dim formulaObj(,) As Object
            inRange = outSheet.Range("A2:AB2")
            formulaObj = inRange.FormulaR1C1

            Dim patternCD As String
            Dim patternNM As String
            Dim copyValue(rows.Length, 34) As Object

            For i As Integer = 0 To rows.Length - 1

                ''対象の出力データを格納
                patternCD = rows(0).Item(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                patternNM = rows(0).Item(PSEXCEL_CLOUMNMNAME_PATTERN)
                copyValue(i, 0) = rows(i).Item(PSEXCEL_CLOUMNMNAME_LINE_NO)
                copyValue(i, 1) = rows(i).Item(PSEXCEL_CLOUMNMNAME_FILE_NAME)
                copyValue(i, 2) = rows(i).Item(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
                copyValue(i, 3) = rows(i).Item(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
                copyValue(i, 4) = rows(i).Item(PSEXCEL_CLOUMNMNAME_CONTRACTNO)
                copyValue(i, 5) = rows(i).Item(PSEXCEL_CLOUMNMNAME_BRAND_AP_CONF)
                copyValue(i, 8) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                copyValue(i, 9) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PATTERN)
                copyValue(i, 10) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                copyValue(i, 11) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM02)

                ''既存AASHWMA以外は空白をセット
                copyValue(i, 22) = ""
                copyValue(i, 23) = ""
                copyValue(i, 24) = ""
                copyValue(i, 25) = ""
                copyValue(i, 26) = ""
                copyValue(i, 27) = ""

                Select Case rows(i).Item(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                    Case "15", "16"
                    Case "17", "18", "19"
                    Case "20"
                    Case "23"
                    Case "32"
                    Case "25"
                    Case "34"
                    Case "43", "44"
                        '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) Start
                    Case "47"
                        '1587 パターンNOの新設対応(Allotment、VarianceCash、MSS) End
                    Case Else
                        copyValue(i, 13) = ""
                End Select

                copyValue(i, 12) = rows(i).Item(PSEXCEL_CLOUMNMNAME_QTY)
                copyValue(i, 13) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PAYSTRYM)
                copyValue(i, 14) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PAYENDYM)
                copyValue(i, 15) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PAY_MONTHS)
                copyValue(i, 16) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PAY_METHOD)
                copyValue(i, 17) = rows(i).Item(PSEXCEL_CLOUMNMNAME_LIST_PRICE_REFLESH)
                copyValue(i, 18) = rows(i).Item(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH)

                copyValue(i, 19) = rows(i).Item(PSEXCEL_CLOUMNMNAME_DP_IOC)
                If IsDBNull(rows(i).Item(PSEXCEL_CLOUMNMNAME_PRICE_UNIT_IOC_VAL)) Then
                    copyValue(i, 20) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PRICE_UNIT_IOC)
                Else
                    If Val(rows(i).Item(PSEXCEL_CLOUMNMNAME_PRICE_UNIT_IOC_VAL)) <> 0 Then
                        copyValue(i, 20) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PRICE_UNIT_IOC_VAL)
                    Else
                        copyValue(i, 20) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PRICE_UNIT_IOC)
                    End If
                End If
                copyValue(i, 21) = rows(i).Item(PSEXCEL_CLOUMNMNAME_PRICE_QTY_IOC)

                ''Template行にExcel式があれば、Template行のExcel式をセットする。
                Call SetTemplateFormula(i, copyValue, formulaObj)
            Next

            ''書式をコピー & ペースト
            Dim copyArea As String = "A" & ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW & ":" & "AB" & ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + rows.Length - 1
            inRange = outSheet.Range("A2:AB2")

            inRange.Copy()
            outRange = outSheet.Range(copyArea)
            outRange.PasteSpecial()

            ''グループ化した列を再表示する
            Select Case patternCD
                Case "20",
                     "23",
                     "32",
                     "47"
                Case "25"
            End Select

            ''値をセット
            outRange.Formula = copyValue

        Catch ex As Exception
            Throw ex

        Finally
            ''オブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(outSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(inRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(outRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(entryRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(enColumns, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Sub

    ''' <summary>
    ''' 機　能：個別詳細ファイルから価格開示ファイルへ出力対象の行をコピー&ペーストする。(CISCO HW用)
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub CopyPSDetailRows2(ByVal xlOutBook As Excel.Workbook, _
                                  ByVal rows() As DataRow, _
                                  ByRef PSdetailTable As DataTable)

        Dim outSheet As Excel.Worksheet
        Dim inRange As Excel.Range
        Dim outRange As Excel.Range

        If rows Is Nothing Then
            Exit Sub
        End If

        Try

            'シートのセット
            outSheet = xlOutBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)
            Dim copyValue(rows.Length - 1, 16) As Object

            ''テンプレート行の式をセット
            Dim formulaObj(,) As Object                     ''通常行
            Dim formulaSumObj(,) As Object                  ''集計行

            inRange = outSheet.Range("A2:Q2")

            formulaObj = inRange.FormulaR1C1
            'カスタマイズするテンプレート式を上書きする
            formulaObj(1, 13) = ""
            formulaObj(1, 15) = ""
            formulaObj(1, 16) = "=ROUND(RC[-3]*RC[-1],0)"

            inRange = outSheet.Range("A2:Q2")
            formulaSumObj = inRange.FormulaR1C1
            'カスタマイズするテンプレート式を上書きする
            formulaSumObj(1, 13) = ""
            formulaSumObj(1, 16) = ""

            Dim SLineList As New ArrayList                  ''S行の情報をListでまとめる。
            Dim SList() As Integer
            Dim startrow() As Integer
            Dim EndRow() As Integer
            Dim sCount As Integer = 0

            For i As Integer = 0 To rows.Length - 1

                ''対象のセルへ出力するデータを配列に保存
                copyValue(i, 0) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_BRAND_AP_CONF)
                copyValue(i, 3) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)
                copyValue(i, 4) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME)
                copyValue(i, 5) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
                copyValue(i, 6) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
                copyValue(i, 7) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_SEQ)
                copyValue(i, 8) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_IDENTITY_FLAG)
                copyValue(i, 9) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_PROD_NO)
                copyValue(i, 10) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_PROD_NAME)
                copyValue(i, 11) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_QTY_INTEGER)
                copyValue(i, 12) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_LIST_PRICE)
                copyValue(i, 13) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL)
                copyValue(i, 14) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_COST_RATE)
                copyValue(i, 15) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_COST)
                copyValue(i, 16) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_COST_TOTAL)

                If rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_IDENTITY_FLAG) = "S" Then
                    Call SetSumTemplateFormula(i, copyValue, formulaSumObj, rows, PSdetailTable)
                    Call SLineList.Add(i)                   ''S行の位置をセット

                    sCount = sCount + 1
                    ReDim Preserve SList(sCount)
                    ReDim Preserve startrow(sCount)
                    ReDim Preserve EndRow(sCount)

                    SList(sCount - 1) = i
                    startrow(sCount - 1) = i + 1
                    If sCount >= 2 Then
                        EndRow(sCount - 2) = i - 1
                    End If
                Else
                    Call SetTemplateFormula(i, copyValue, formulaObj)

                    If rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_BRAND_AP_CONF) = "" Then
                        copyValue(i, 14) = ""
                    Else
                        copyValue(i, 14) = "=COST入力!$J$" & GetCostRow(rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_BRAND_AP_CONF))
                    End If

                    EndRow(sCount - 1) = i
                End If
            Next

            ''通常行のコピペ
            Dim copyArea As String = ExcelWrite.CISCO_EXCEL_DETAILLINEDATE_OUTROW & ":" & ExcelWrite.CISCO_EXCEL_DETAILLINEDATE_OUTROW + rows.Length - 1

            inRange = outSheet.Rows("2:2")
            inRange.Hidden = False
            inRange.Copy()
            outRange = outSheet.Range(copyArea)
            outRange.PasteSpecial(Excel.XlPasteType.xlPasteFormats)

            'S行での縦計式設定
            Dim ii As Integer
            For ii = 0 To sCount - 1
                copyValue(SList(ii), 13) = "=sum(N" & ExcelWrite.CISCO_EXCEL_DETAILLINEDATE_OUTROW + startrow(ii) & _
                                               ":N" & ExcelWrite.CISCO_EXCEL_DETAILLINEDATE_OUTROW + EndRow(ii) & ")"
                copyValue(SList(ii), 16) = "=sum(Q" & ExcelWrite.CISCO_EXCEL_DETAILLINEDATE_OUTROW + startrow(ii) & _
                                               ":Q" & ExcelWrite.CISCO_EXCEL_DETAILLINEDATE_OUTROW + EndRow(ii) & ")"
            Next

            inRange = outSheet.Rows("2:2")
            inRange.Hidden = True

            copyArea = "A" & ExcelWrite.CISCO_EXCEL_DETAILLINEDATE_OUTROW & ":" & "Q" & ExcelWrite.CISCO_EXCEL_DETAILLINEDATE_OUTROW + rows.Length - 1

            outRange = outSheet.Range(copyArea)
            outRange.Value = copyValue

        Catch ex As Exception
            Throw ex

        Finally
            ''オブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(outSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(inRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(outRange, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Sub

    ''' <summary>
    ''' 機　能：Cost開示対象のPSシートデータを取得（パターン８）CISCO HW用
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub GetWritePSCostKaijiRowPattern8(ByRef outputLogPSDataTable As DataTable,
                                               ByVal PSDataTable As DataTable,
                                               ByVal DetailDataTable As DataTable,
                                               ByVal CostKaijiPSSheetData As DataTable,
                                               ByVal CostKaijiDetailSheetData As DataTable,
                                               ByRef rtnTable As DataTable)

        ''Cost開示ファイルのPSシートデータ抽出
        Dim rtnRow As DataRow
        For Each costKaijiRow As DataRow In CostKaijiPSSheetData.Select


            ''              反映対象データのチェック
            ''==================================================

            ''コスト開示PSシートに紐づく詳細データが存在するかどうか
            Dim CostDetailRows() As DataRow
            CostDetailRows = GetMatchDetailCostRows(CostKaijiDetailSheetData, costKaijiRow)
            If CostDetailRows.Length = 0 Then
                costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = COST_NGREASON_UNMATCHCOSTPSTOCOSTDETAIL
                outputLogPSDataTable.ImportRow(costKaijiRow)
                Continue For
            End If


            ''コスト開示詳細ファイルのCostに不正な値がセットされているかどうか
            Dim subCostTotal As Decimal = 0
            Dim chkCostTotal As Boolean = False
            chkCostTotal = GetDetailCostTotal(CostDetailRows, subCostTotal)
            If chkCostTotal = False Then
                costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = COST_NGREASON_COSTINPUTERR
                outputLogPSDataTable.ImportRow(costKaijiRow)
                Continue For
            End If


            ''反映対象のPaymentシートが存在するかどうか
            Dim PSRows() As DataRow
            PSRows = GetConsInputPSRows(PSDataTable, costKaijiRow)
            If PSRows.Length = 0 Then
                costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = COST_NGREASON_UNMATCHCOSTPSTOPSDATE
                outputLogPSDataTable.ImportRow(costKaijiRow)
                Continue For
            End If


            ''反映先のPaymentSheetの数量が正しいかどうか
            If IsNumeric(PSRows(0).Item(PSEXCEL_CLOUMNMNAME_QTY)) = False OrElse
               CDbl(PSRows(0).Item(PSEXCEL_CLOUMNMNAME_QTY)) <= 0 Then

                costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = COST_NGREASON_QTYINPUTERR
                outputLogPSDataTable.ImportRow(costKaijiRow)
                Continue For
            End If

            ''Cost単価取得
            Dim PSCost As Decimal
            PSCost = subCostTotal / CDec(PSRows(0).Item(PSEXCEL_CLOUMNMNAME_QTY))

            ''Payment個別詳細データよりCost個別詳細データの個数が異なる
            Dim CostDetailCount As Integer
            Dim PSDetailCount As Integer
            Dim PSDetailRows() As DataRow
            PSDetailRows = GetMatchDetailCostRows(DetailDataTable, costKaijiRow)
            CostDetailCount = CostDetailRows.Length
            PSDetailCount = PSDetailRows.Length
            If CostDetailCount <> PSDetailCount Then
                costKaijiRow(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = COST_NGREASON_UNMATCHCOSCOUNTDETAILPSDETAIL
                outputLogPSDataTable.ImportRow(costKaijiRow)
                Continue For
            End If


            ''--------------------------------------------------------
            ''出力対象データのセット
            ''--------------------------------------------------------
            ''※補足：PSRowsは、明示的にExcelの行番号でソート処理を行っていないが、
            ''　　　　Excelの行番号順にデータが格納されている想定(データのInset順が保証されている想定)
            For Each row As DataRow In PSRows
                rtnRow = rtnTable.NewRow
                rtnRow(PSEXCEL_CLOUMNMNAME_LINE_NO) = row(PSEXCEL_CLOUMNMNAME_LINE_NO)
                rtnRow(PSEXCEL_CLOUMNMNAME_EXCELROW) = row(PSEXCEL_CLOUMNMNAME_EXCELROW)
                rtnRow(PSEXCEL_CLOUMNMNAME_COST_RATE) = row(PSEXCEL_CLOUMNMNAME_COST_RATE)
                rtnRow(PSEXCEL_CLOUMNMNAME_COST) = PSCost

                rtnRow(PSEXCEL_CLOUMNMNAME_NEW_EXIST) = row(PSEXCEL_CLOUMNMNAME_NEW_EXIST)
                rtnRow(PSEXCEL_CLOUMNMNAME_PATTERN_CD) = row(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                rtnRow(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH) = row(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH)
                rtnRow(PSEXCEL_CLOUMNMNAME_PROD_ITEM01) = row(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                rtnRow(PSEXCEL_CLOUMNMNAME_PATTERN) = row(PSEXCEL_CLOUMNMNAME_PATTERN)

                rtnTable.Rows.Add(rtnRow)

                Exit For

            Next
        Next

    End Sub

    ''' <summary>
    ''' 機　能：Cost開示ファイルの配列情報をデータテーブルへ格納する
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetCostKaijiDataTable2(ByVal Obj(,) As Object) As DataTable

        ''データテーブルの定義
        Dim rtnDataTable As New DataTable

        Dim COLPSCISCO_LINE_NO As Integer = 1
        Dim COLPSCISCO_FILE_NAME As Integer = 2
        Dim COLPSCISCO_FILE_NAME_SUFFIX As Integer = 3
        Dim COLPSCISCO_FILE_NAME_SUFFIX_INTR As Integer = 4
        Dim COLPSCISCO_CONTRACTNO As Integer = 5

        Dim COLPSCISCO_KIHYONO As Integer = 6
        Dim COLPSCISCO_SINSEINO As Integer = 7

        Dim COLPSCISCO_NEW_EXIST As Integer = 8
        Dim COLPSCISCO_PATTERN_CD As Integer = 9
        Dim COLPSCISCO_PATTERN_NM As Integer = 10
        Dim COLPSCISCO_PROD_ITEM01 As Integer = 11
        Dim COLPSCISCO_PROD_ITEM02 As Integer = 12

        Dim COLPSCISCO_PROD_ITEM03 As Integer = 13
        Dim COLPSCISCO_PROD_ITEM11 As Integer = 14
        Dim COLPSCISCO_PROD_ITEM12 As Integer = 15

        Dim COLPSCISCO_QTY As Integer = 13
        Dim COLPSCISCO_PAYSTRYM As Integer = 14
        Dim COLPSCISCO_PAYENDYM As Integer = 15
        Dim COLPSCISCO_SEIKYU_KIKAN As Integer = 16
        Dim COLPSCISCO_PAY As Integer = 17
        Dim COLPSCISCO_LIST_TANKA As Integer = 18
        Dim COLPSCISCO_LIST_TOTAL As Integer = 19
        Dim COLPSCISCO_RATE As Integer = 20
        Dim COLPSCISCO_OFFERING_TANKA As Integer = 21
        Dim COLPSCISCO_OFFERING_TOTAL As Integer = 22

        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_LINE_NO)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_CONTRACTNO)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_NEW_EXIST)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_PATTERN_CD)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_PATTERN_NM)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM01)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM02)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM04)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_QTY)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_LIST_PRICE_REFLESH)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_COST_RATE)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_COST)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_EXCELROW)
        rtnDataTable.Columns.Add(COSTPSEXCEL_CLOUMNMNAME_NGREASON)

        ''Excelの値をデータテーブルへセット
        Dim row As DataRow
        For i As Integer = 1 To Obj.GetLength(0)

            '起票番号・申請番号が空白でないものを対象とする
            If ChangeNothingToBrank(Obj(i, COLPSCISCO_KIHYONO)).ToString <> "" Or _
               ChangeNothingToBrank(Obj(i, COLPSCISCO_SINSEINO)).ToString <> "" Then

                row = rtnDataTable.NewRow
                row(COSTPSEXCEL_CLOUMNMNAME_EXCELROW) = i

                row(COSTPSEXCEL_CLOUMNMNAME_LINE_NO) = ChangeNothingToBrank(Obj(i, COLPSCISCO_LINE_NO))
                row(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME) = ChangeNothingToBrank(Obj(i, COLPSCISCO_FILE_NAME))
                row(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX) = ChangeNothingToBrank(Obj(i, COLPSCISCO_FILE_NAME_SUFFIX))
                row(COSTPSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR) = ChangeNothingToBrank(Obj(i, COLPSCISCO_FILE_NAME_SUFFIX_INTR))
                row(COSTPSEXCEL_CLOUMNMNAME_CONTRACTNO) = ChangeNothingToBrank(Obj(i, COLPSCISCO_CONTRACTNO))

                row(COSTPSEXCEL_CLOUMNMNAME_NEW_EXIST) = ""

                row(COSTPSEXCEL_CLOUMNMNAME_PATTERN_CD) = ChangeNothingToBrank(Obj(i, COLPSCISCO_PATTERN_CD))
                row(COSTPSEXCEL_CLOUMNMNAME_PATTERN_NM) = ChangeNothingToBrank(Obj(i, COLPSCISCO_PATTERN_NM))
                row(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM01) = ChangeNothingToBrank(Obj(i, COLPSCISCO_PROD_ITEM01))
                row(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM02) = ChangeNothingToBrank(Obj(i, COLPSCISCO_PROD_ITEM02))

                row(COSTPSEXCEL_CLOUMNMNAME_PROD_ITEM04) = ""

                row(COSTPSEXCEL_CLOUMNMNAME_QTY) = ChangeNothingToBrank(Obj(i, COLPSCISCO_QTY))
                row(COSTPSEXCEL_CLOUMNMNAME_LIST_PRICE_REFLESH) = ChangeNothingToBrank(Obj(i, COLPSCISCO_LIST_TOTAL))
                row(COSTPSEXCEL_CLOUMNMNAME_COST_RATE) = ChangeNothingToBrank(Obj(i, COLPSCISCO_RATE))

                row(COSTPSEXCEL_CLOUMNMNAME_COST) = ""

                row(COSTPSEXCEL_CLOUMNMNAME_NGREASON) = ""
                rtnDataTable.Rows.Add(row)
            Else
                '未取込に計上
                exCiscoCnt = exCiscoCnt + 1
            End If

        Next

        Return rtnDataTable

    End Function

    ''' <summary>
    ''' 機　能：Cost開示ファイルの配列情報をデータテーブルへ格納する(CISCO HW用)
    ''' 説　明：
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetCostKaijiDetailDataTable2(ByVal Obj(,) As Object) As DataTable

        ''データテーブルの定義
        Dim rtnDataTable As New DataTable

        Dim COLCISCODETAIL_KIHYONO As Integer = 1
        Dim COLCISCODETAIL_SINSEINO As Integer = 2

        Dim COLCISCODETAIL_CONTRACTNO As Integer = 4
        Dim COLCISCODETAIL_FILE_NAME As Integer = 5
        Dim COLCISCODETAIL_FILE_NAME_SUFFIX As Integer = 6
        Dim COLCISCODETAIL_FILE_NAME_SUFFIX_INTR As Integer = 7
        Dim COLCISCODETAIL_SEQ As Integer = 8
        Dim COLCISCODETAIL_IDENTITY_FLAG As Integer = 9
        Dim COLCISCODETAIL_PROD_NO As Integer = 10
        Dim COLCISCODETAIL_PROD_NAME As Integer = 11
        Dim COLCISCODETAIL_QTY_INTEGER As Integer = 12
        Dim COLCISCODETAIL_LIST_PRICE As Integer = 13
        Dim COLCISCODETAIL_LIST_TOTAL As Integer = 14
        Dim COLCISCODETAIL_COST_RATE As Integer = 15
        Dim COLCISCODETAIL_COST As Integer = 16
        Dim COLCISCODETAIL_COST_TOTAL As Integer = 17

        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_FILE_NAME)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_SEQ)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_IDENTITY_FLAG)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_PROD_NO)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_PROD_NAME)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_MES_CATEGORY)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_SPECIAL_FEATURE)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_QTY_INTEGER)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_LIST_PRICE)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_COST_RATE)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_COST)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_COST_TOTAL)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_EXCELROW)
        rtnDataTable.Columns.Add(COSTDETAILEXCEL_CLOUMNMNAME_NGREASON)

        ''Excelの値をデータテーブルへセット
        Dim row As DataRow
        For i As Integer = 1 To Obj.GetLength(0)

            '起票番号・申請番号が空白でないものを対象とする
            If ChangeNothingToBrank(Obj(i, COLCISCODETAIL_KIHYONO)).ToString <> "" Or _
                ChangeNothingToBrank(Obj(i, COLCISCODETAIL_SINSEINO)).ToString <> "" Then

                row = rtnDataTable.NewRow
                row(COSTDETAILEXCEL_CLOUMNMNAME_EXCELROW) = i

                row(COSTDETAILEXCEL_CLOUMNMNAME_CONTRACTNO) = ChangeNothingToBrank(Obj(i, COLCISCODETAIL_CONTRACTNO))
                row(COSTDETAILEXCEL_CLOUMNMNAME_FILE_NAME) = ChangeNothingToBrank(Obj(i, COLCISCODETAIL_FILE_NAME))
                row(COSTDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX) = ChangeNothingToBrank(Obj(i, COLCISCODETAIL_FILE_NAME_SUFFIX))
                row(COSTDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR) = ChangeNothingToBrank(Obj(i, COLCISCODETAIL_FILE_NAME_SUFFIX_INTR))
                row(COSTDETAILEXCEL_CLOUMNMNAME_SEQ) = ChangeNothingToBrank(Obj(i, COLCISCODETAIL_SEQ))
                row(COSTDETAILEXCEL_CLOUMNMNAME_IDENTITY_FLAG) = ChangeNothingToBrank(Obj(i, COLCISCODETAIL_IDENTITY_FLAG))
                row(COSTDETAILEXCEL_CLOUMNMNAME_PROD_NO) = ChangeNothingToBrank(Obj(i, COLCISCODETAIL_PROD_NO))
                row(COSTDETAILEXCEL_CLOUMNMNAME_PROD_NAME) = ChangeNothingToBrank(Obj(i, COLCISCODETAIL_PROD_NAME))

                row(COSTDETAILEXCEL_CLOUMNMNAME_MES_CATEGORY) = ""
                row(COSTDETAILEXCEL_CLOUMNMNAME_SPECIAL_FEATURE) = ""

                row(COSTDETAILEXCEL_CLOUMNMNAME_QTY_INTEGER) = ChangeNothingToBrank(Obj(i, COLCISCODETAIL_QTY_INTEGER))
                row(COSTDETAILEXCEL_CLOUMNMNAME_LIST_PRICE) = ChangeNothingToBrank(Obj(i, COLCISCODETAIL_LIST_PRICE))
                row(COSTDETAILEXCEL_CLOUMNMNAME_COST_RATE) = ChangeNothingToBrank(Obj(i, COLCISCODETAIL_COST_RATE))
                row(COSTDETAILEXCEL_CLOUMNMNAME_COST) = ChangeNothingToBrank(Obj(i, COLCISCODETAIL_COST))
                row(COSTDETAILEXCEL_CLOUMNMNAME_COST_TOTAL) = ChangeNothingToBrank(Obj(i, COLCISCODETAIL_COST_TOTAL))

                rtnDataTable.Rows.Add(row)
            End If
        Next

        Return rtnDataTable

    End Function

    ''' <summary>
    ''' 機　能：e-PricerCOST開示のSummaryシートを作成する。
    ''' 説　明：
    ''' </summary>
    ''' <param name="xlOutBook"></param>
    ''' <param name="rows"></param>
    ''' <remarks></remarks>
    Private Sub CopyePricerSummaryRows(ByRef xlBook As Excel.Workbook, _
                                       ByVal rows() As DataRow)

        Dim xlSheet As Excel.Worksheet
        Dim xlRangeIn As Excel.Range
        Dim xlRangeOut As Excel.Range
        Dim objData(,) As Object
        Dim intRow As Integer
        Dim strRange As String
        Dim alBrandApConf As New ArrayList
        Dim strWork As String
        Dim intCnt As Integer
        Dim strData() As String

        Try
            'シートのセット
            xlSheet = xlBook.Worksheets("Summary")

            '出力データ作成
            intCnt = 0
            For intRow = 0 To (rows.Length - 1)
                strWork = rows(intRow).Item(PSEXCEL_CLOUMNMNAME_BRAND_AP_CONF)
                If alBrandApConf.Contains(strWork) = False Then
                    alBrandApConf.Add(strWork)
                    ReDim Preserve strData(intCnt)
                    strData(intCnt) = strWork
                    intCnt = intCnt + 1
                End If
            Next

            ''書式をコピー & ペースト
            strRange = "A" & EXCEL_SUMMARYDATE_OUTROW & ":" & "J" & EXCEL_SUMMARYDATE_OUTROW + (strData.Length - 1)
            xlRangeIn = xlSheet.Range("A2:J2")
            xlRangeIn.Copy()
            ExcelObjRelease.ReleaseExcelObj(xlRangeIn, ExcelObjRelease.OBJECT_NOTHING)
            xlRangeOut = xlSheet.Range(strRange)
            xlRangeOut.PasteSpecial()
            ExcelObjRelease.ReleaseExcelObj(xlRangeOut, ExcelObjRelease.OBJECT_NOTHING)

            ''値をセット
            strRange = "A" & EXCEL_SUMMARYDATE_OUTROW & ":" & "B" & EXCEL_SUMMARYDATE_OUTROW + (strData.Length - 1)
            xlRangeOut = xlSheet.Range(strRange)
            objData = xlRangeOut.Value
            For intCnt = 0 To (strData.Length - 1)
                objData(intCnt + 1, 1) = (intCnt + 1).ToString
                objData(intCnt + 1, 2) = strData(intCnt)
            Next
            xlRangeOut.Formula = objData
            ExcelObjRelease.ReleaseExcelObj(xlRangeOut, ExcelObjRelease.OBJECT_NOTHING)

        Catch ex As Exception
            Throw ex

        Finally
            ''オブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlRangeIn, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlRangeOut, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Sub

    ''' <summary>
    ''' 機　能：Paymentファイルからe-PricerCOST開示ファイルに対象Paymentを出力する
    ''' 説　明：
    ''' </summary>
    ''' <param name="xlBook"></param>
    ''' <param name="rows"></param>
    ''' <remarks></remarks>
    Private Sub CopyePricerPSRows(ByRef xlBook As Excel.Workbook, _
                                  ByVal rows() As DataRow)

        Dim xlSheet As Excel.Worksheet
        Dim xlRangeIn As Excel.Range
        Dim xlRangeOut As Excel.Range
        Dim objFormula(,) As Object
        Dim objData(rows.Length, 16) As Object
        Dim intRowCnt As Integer
        Dim strRange As String

        Try

            'シートのセット
            xlSheet = xlBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)

            'テンプレート行の式をセット
            xlRangeIn = xlSheet.Range("A2:P2")
            objFormula = xlRangeIn.FormulaR1C1
            ExcelObjRelease.ReleaseExcelObj(xlRangeIn, ExcelObjRelease.OBJECT_NOTHING)

            For intRowCnt = 0 To (rows.Length - 1)
                '対象の出力データを格納
                objData(intRowCnt, 0) = rows(intRowCnt).Item(PSEXCEL_CLOUMNMNAME_LINE_NO)
                objData(intRowCnt, 1) = rows(intRowCnt).Item(PSEXCEL_CLOUMNMNAME_FILE_NAME)
                objData(intRowCnt, 2) = rows(intRowCnt).Item(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
                objData(intRowCnt, 3) = rows(intRowCnt).Item(PSEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
                objData(intRowCnt, 4) = rows(intRowCnt).Item(PSEXCEL_CLOUMNMNAME_CONTRACTNO)
                objData(intRowCnt, 5) = rows(intRowCnt).Item(PSEXCEL_CLOUMNMNAME_BRAND_AP_CONF)
                objData(intRowCnt, 6) = rows(intRowCnt).Item(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                objData(intRowCnt, 7) = rows(intRowCnt).Item(PSEXCEL_CLOUMNMNAME_PATTERN)
                objData(intRowCnt, 8) = rows(intRowCnt).Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                objData(intRowCnt, 9) = rows(intRowCnt).Item(PSEXCEL_CLOUMNMNAME_PROD_ITEM02)
                objData(intRowCnt, 10) = rows(intRowCnt).Item(PSEXCEL_CLOUMNMNAME_QTY)
                objData(intRowCnt, 11) = rows(intRowCnt).Item(PSEXCEL_CLOUMNMNAME_LIST_PRICE_REFLESH)
                objData(intRowCnt, 12) = rows(intRowCnt).Item(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH)
                objData(intRowCnt, 13) = rows(intRowCnt).Item(PSEXCEL_CLOUMNMNAME_COST_RATE)
                objData(intRowCnt, 14) = rows(intRowCnt).Item(PSEXCEL_CLOUMNMNAME_COST)
                objData(intRowCnt, 15) = rows(intRowCnt).Item(PSEXCEL_CLOUMNMNAME_COST_TOTAL)

                'Template行にExcel式があれば、Template行のExcel式をセットする。
                Call SetTemplateFormula(intRowCnt, objData, objFormula)
            Next

            '書式をコピー & ペースト
            xlRangeIn = xlSheet.Range("A2:P2")
            xlRangeIn.Copy()
            ExcelObjRelease.ReleaseExcelObj(xlRangeIn, ExcelObjRelease.OBJECT_NOTHING)
            strRange = "A" & ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW & ":" & "P" & ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + rows.Length - 1
            xlRangeOut = xlSheet.Range(strRange)
            xlRangeOut.PasteSpecial()
            ExcelObjRelease.ReleaseExcelObj(xlRangeOut, ExcelObjRelease.OBJECT_NOTHING)

            ''値をセット
            strRange = "A" & ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW & ":" & "P" & ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + rows.Length - 1
            xlRangeOut = xlSheet.Range(strRange)
            xlRangeOut.Formula = objData
            ExcelObjRelease.ReleaseExcelObj(xlRangeOut, ExcelObjRelease.OBJECT_NOTHING)

        Catch ex As Exception
            Throw ex

        Finally
            ''オブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlRangeIn, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlRangeOut, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Sub

    ''' <summary>
    ''' 機　能：Paymentファイルからe-PricerCOST開示ファイルに対象Paymentに紐付く詳細を出力する
    ''' 説　明：
    ''' </summary>
    ''' <param name="xlOutBook"></param>
    ''' <param name="rows"></param>
    ''' <param name="PSDetailDataTable"></param>
    ''' <remarks></remarks>
    Private Sub CopyePricerDetailRows(ByVal xlBook As Excel.Workbook, _
                                      ByVal rows() As DataRow, _
                                      ByRef PSDetailDataTable As DataTable)

        Dim xlSheet As Excel.Worksheet
        Dim xlRangeIn As Excel.Range
        Dim xlRangeOut As Excel.Range
        Dim strRange As String
        Dim objData(rows.Length, 16) As Object
        Dim objFormula(,) As Object                         '通常行
        Dim objFomulaSum(,) As Object                       '集計行
        Dim alSammary As New ArrayList                      'S行の情報をListでまとめる

        Try

            'シートのセット
            xlSheet = xlBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)

            ''テンプレート行の式をセット
            xlRangeIn = xlSheet.Range("A3:P3")
            objFormula = xlRangeIn.FormulaR1C1
            ExcelObjRelease.ReleaseExcelObj(xlRangeIn, ExcelObjRelease.OBJECT_NOTHING)
            xlRangeIn = xlSheet.Range("A2:P2")
            objFomulaSum = xlRangeIn.FormulaR1C1
            ExcelObjRelease.ReleaseExcelObj(xlRangeIn, ExcelObjRelease.OBJECT_NOTHING)

            For i As Integer = 0 To rows.Length - 1

                ''対象のセルへ出力するデータを配列に保存
                objData(i, 0) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_CONTRACTNO)
                objData(i, 1) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME)
                objData(i, 2) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX)
                objData(i, 3) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_FILE_NAME_SUFFIX_INTR)
                objData(i, 4) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_SEQ)
                objData(i, 5) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_IDENTITY_FLAG)
                objData(i, 6) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_PROD_NO)
                objData(i, 7) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_PROD_NAME)
                objData(i, 8) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_MES_CATEGORY)
                objData(i, 9) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_MES_GROUP)
                objData(i, 10) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_SPECIAL_FEATURE)
                objData(i, 11) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_QTY_INTEGER)
                objData(i, 12) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_LIST_PRICE)
                objData(i, 13) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL)
                objData(i, 14) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_COST_RATE)
                objData(i, 15) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_COST)
                objData(i, 16) = rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_COST_TOTAL)

                'Template行にExcel式があれば、Template行のExcel式をセットする。
                If rows(i).Item(PSDETAILEXCEL_CLOUMNMNAME_IDENTITY_FLAG) = "S" Then
                    Call SetSumTemplateFormula(i, objData, objFomulaSum, rows, PSDetailDataTable)
                    alSammary.Add(i)                   'S行の位置をセット
                Else
                    Call SetTemplateFormula(i, objData, objFormula)
                End If
            Next

            ''通常行のコピペ   ※グループの設定もコピーしたいので、行を指定。
            strRange = ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW & ":" & ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW + rows.Length - 1
            xlRangeIn = xlSheet.Rows("3:3")
            xlRangeIn.Hidden = False
            xlRangeIn.Copy()
            xlRangeOut = xlSheet.Range(strRange)
            xlRangeOut.PasteSpecial()
            ExcelObjRelease.ReleaseExcelObj(xlRangeOut, ExcelObjRelease.OBJECT_NOTHING)
            xlRangeIn.Hidden = True
            ExcelObjRelease.ReleaseExcelObj(xlRangeIn, ExcelObjRelease.OBJECT_NOTHING)

            ''S行のコピペ    
            xlRangeIn = xlSheet.Rows("2:2")
            xlRangeIn.Hidden = False
            xlRangeIn.Copy()
            For Each SLine As Integer In alSammary
                strRange = ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW + SLine & ":" & ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW + SLine
                xlRangeOut = xlSheet.Rows(strRange)
                xlRangeOut.PasteSpecial()
                ExcelObjRelease.ReleaseExcelObj(xlRangeOut, ExcelObjRelease.OBJECT_NOTHING)
            Next
            xlRangeIn.Hidden = True
            ExcelObjRelease.ReleaseExcelObj(xlRangeIn, ExcelObjRelease.OBJECT_NOTHING)

            ''値のセット
            strRange = "A" & ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW & ":" & "Q" & ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW + rows.Length
            xlRangeOut = xlSheet.Range(strRange)
            xlRangeOut.Value = objData

        Catch ex As Exception
            Throw ex

        Finally
            ''オブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlRangeIn, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlRangeOut, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Sub

    ''' <summary>
    ''' e-Pricer用COST開示ファイルからデータ取得
    ''' </summary>
    ''' <param name="xlBookCost"></param>
    ''' <param name="strPatternCd"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetEPricerCostKaijiData(ByRef xlBookCost As Excel.Workbook, ByRef strPatternCd As String) As DataTable()

        Dim dtRet(1) As DataTable
        dtRet(0) = New DataTable

        Dim xlComponent As Excel.Worksheet
        Dim xlSheets As Excel.Sheets
        Dim xlSheet As Excel.Worksheet
        Dim blnSheet As Boolean
        Dim wRet As Boolean = True

        GetEPricerCostKaijiData = dtRet

        Try
            'ｼｰﾄの存在ﾁｪｯｸ
            blnSheet = False
            For Each xlSheet In xlBookCost.Worksheets
                'Req:1484 Rewrite対応 str
                'If xlSheet.Name = ExcelWrite.EXCEL_COST_EP_COMPONENT Then
                If xlSheet.Name = ExcelWrite.EXCEL_COST_EP_COMP_PRICES Then
                    'Req:1484 Rewrite対応 end
                    blnSheet = True
                    Exit For
                End If
            Next
            If blnSheet = False Then
                wRet = False
            Else
                strPatternCd = "e-Pricer"
            End If

            'Req:1484 Rewrite対応 str
            'Componentｼｰﾄの値を取得
            'If wRet = True Then
            '    xlSheets = xlBookCost.Worksheets
            '    xlSheet = xlSheets.Item(ExcelWrite.EXCEL_COST_EP_COMPONENT)
            '    dtRet(0) = GetEPricerComponentData(xlSheet)

            '    GetEPricerCostKaijiData = dtRet
            'End If

            If wRet = True Then
                xlSheets = xlBookCost.Worksheets
                xlSheet = xlSheets.Item(ExcelWrite.EXCEL_COST_EP_COMP_PRICES)
                dtRet(0) = GetEPricerComp_PricesData(xlSheet)

                GetEPricerCostKaijiData = dtRet
            End If
            'Req:1484 Rewrite対応 end

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Function

    'Req:1484 Rewrite対応 str
    ' ''' <summary>
    ' ''' 機能：Componentｼｰﾄの値を取得
    ' ''' </summary>
    ' ''' <param name="xlSheet"></param>
    ' ''' <returns></returns>
    ' ''' <remarks></remarks>
    'Private Function GetEPricerComponentData(ByRef xlSheet As Excel.Worksheet) As DataTable

    '    Dim dtComp As New DataTable
    '    Dim xlCell As Excel.Range
    '    Dim objData(,) As Object
    '    Dim lngRowCnt As Long
    '    Dim row As DataRow

    '    GetEPricerComponentData = dtComp

    '    Try
    '        'ComponentのTable作成
    '        With dtComp.Columns
    '            .Add(EPRICER_COMP_COLUMNNAME_ROWNO)
    '            .Add(EPRICER_COMP_COLUMNNAME_TRANSACTIONID)
    '            .Add(EPRICER_COMP_COLUMNNAME_TYPE)
    '            .Add(EPRICER_COMP_COLUMNNAME_MODEL)
    '            .Add(EPRICER_COMP_COLUMNNAME_QTY)
    '            .Add(EPRICER_COMP_COLUMNNAME_LISTPRICE)
    '            .Add(EPRICER_COMP_COLUMNNAME_ESTIMATED_TMC)
    '            .Add(EPRICER_COMP_COLUMNNAME_LOG)
    '        End With

    '        'データ取得
    '        lngRowCnt = 3
    '        Do
    '            '1行取得
    '            xlCell = xlSheet.Range("A@:HN@".Replace("@", lngRowCnt))
    '            objData = xlCell.Value
    '            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

    '            'EOF判定(TransactionID)
    '            If ExcelWrite.changeDBNullToString(objData(1, 5)) = "" Then
    '                Exit Do
    '            End If

    '            row = dtComp.NewRow
    '            row.Item(EPRICER_COMP_COLUMNNAME_ROWNO) = lngRowCnt.ToString
    '            row.Item(EPRICER_COMP_COLUMNNAME_TRANSACTIONID) = ExcelWrite.changeDBNullToString(objData(1, 5)).Trim
    '            row.Item(EPRICER_COMP_COLUMNNAME_TYPE) = ExcelWrite.changeDBNullToString(objData(1, 10)).Trim
    '            row.Item(EPRICER_COMP_COLUMNNAME_MODEL) = ExcelWrite.changeDBNullToString(objData(1, 11)).Trim
    '            row.Item(EPRICER_COMP_COLUMNNAME_QTY) = ExcelWrite.changeDBNullToString(objData(1, 12)).Trim
    '            row.Item(EPRICER_COMP_COLUMNNAME_LISTPRICE) = ExcelWrite.changeDBNullToString(objData(1, 29)).Trim
    '            row.Item(EPRICER_COMP_COLUMNNAME_ESTIMATED_TMC) = ExcelWrite.changeDBNullToString(objData(1, 56)).Trim
    '            row.Item(EPRICER_COMP_COLUMNNAME_LOG) = ""
    '            dtComp.Rows.Add(row)
    '            lngRowCnt = lngRowCnt + 1
    '        Loop

    '    Catch ex As Exception
    '        Throw ex

    '    Finally
    '        ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

    '    End Try

    'End Function

    ''' <summary>
    ''' 機能：Comp_Pricesｼｰﾄの値を取得
    ''' </summary>
    ''' <param name="xlSheet"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetEPricerComp_PricesData(ByRef xlSheet As Excel.Worksheet) As DataTable

        Dim dtComp As New DataTable
        Dim xlCell As Excel.Range
        Dim objData(,) As Object
        Dim lngRowCnt As Long
        Dim row As DataRow

        GetEPricerComp_PricesData = dtComp

        Try
            'Comp_PricesのTable作成
            With dtComp.Columns
                .Add(EPRICER_COMP_COLUMNNAME_ROWNO)
                .Add(EPRICER_COMP_COLUMNNAME_QUOTEID)
                .Add(EPRICER_COMP_COLUMNNAME_TYPE)
                .Add(EPRICER_COMP_COLUMNNAME_MODEL)
                .Add(EPRICER_COMP_COLUMNNAME_QTY)
                .Add(EPRICER_COMP_COLUMNNAME_LISTPRICE)
                .Add(EPRICER_COMP_COLUMNNAME_COST)
                .Add(EPRICER_COMP_COLUMNNAME_LOG)
            End With

            'データ取得
            lngRowCnt = 3
            Do
                '1行取得
                xlCell = xlSheet.Range("A@:J@".Replace("@", lngRowCnt))
                objData = xlCell.Value
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

                'EOF判定(TransactionID)
                If ExcelWrite.changeDBNullToString(objData(1, 1)) = "" Then
                    Exit Do
                End If

                row = dtComp.NewRow
                row.Item(EPRICER_COMP_COLUMNNAME_ROWNO) = lngRowCnt.ToString
                row.Item(EPRICER_COMP_COLUMNNAME_QUOTEID) = ExcelWrite.changeDBNullToString(objData(1, 1)).Trim
                row.Item(EPRICER_COMP_COLUMNNAME_TYPE) = ExcelWrite.changeDBNullToString(objData(1, 6)).Trim
                row.Item(EPRICER_COMP_COLUMNNAME_MODEL) = ExcelWrite.changeDBNullToString(objData(1, 7)).Trim
                row.Item(EPRICER_COMP_COLUMNNAME_QTY) = ExcelWrite.changeDBNullToString(objData(1, 5)).Trim
                row.Item(EPRICER_COMP_COLUMNNAME_LISTPRICE) = ExcelWrite.changeDBNullToString(objData(1, 8)).Trim
                row.Item(EPRICER_COMP_COLUMNNAME_COST) = ExcelWrite.changeDBNullToString(objData(1, 9)).Trim
                row.Item(EPRICER_COMP_COLUMNNAME_LOG) = ""
                dtComp.Rows.Add(row)
                lngRowCnt = lngRowCnt + 1
            Loop

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

        End Try

    End Function
    'Req:1484 Rewrite対応 end


    Private Sub WritePSCostKaijiRowEPricer(ByVal dtPs As DataTable,
                                           ByRef dtEPricerCost() As DataTable,
                                           ByRef outputTargerPSDataTable As DataTable)

        Dim dtPsOut As New DataTable

        Try
            'Paymentｼｰﾄ出力用テーブル作成
            dtPsOut.Columns.Add(PSEXCEL_CLOUMNMNAME_LINE_NO)
            dtPsOut.Columns.Add(PSEXCEL_CLOUMNMNAME_EXCELROW)
            dtPsOut.Columns.Add(PSEXCEL_CLOUMNMNAME_COST)
            dtPsOut.Columns.Add(PSEXCEL_CLOUMNMNAME_COST_RATE)
            dtPsOut.Columns.Add(PSEXCEL_CLOUMNMNAME_NEW_EXIST)
            dtPsOut.Columns.Add(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
            dtPsOut.Columns.Add(PSEXCEL_CLOUMNMNAME_PATTERN)
            dtPsOut.Columns.Add(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH)
            dtPsOut.Columns.Add(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
            dtPsOut.Columns.Add(PSEXCEL_CLOUMNMNAME_QTY)

            'Req:1484 str
            'Componentデータから出力用Paymentデータを作成
            'If dtEPricerCost(0).Rows.Count > 0 Then
            '    Call AddPsDataFromEPricerComponentData(dtEPricerCost(0),
            '                                           dtPs,
            '                                           dtPsOut)
            'End If

            If dtEPricerCost(0).Rows.Count > 0 Then
                Call AddPsDataFromEPricerComp_PricesData(dtEPricerCost(0),
                                                       dtPs,
                                                       dtPsOut)
            End If
            'Req:1484 end

            outputTargerPSDataTable = dtPsOut

        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' 機能：Componentデータから出力用Paymentデータを作成
    ''' </summary>
    ''' <param name="dtEPricerComponentData"></param>
    ''' <param name="dtPs"></param>
    ''' <param name="dtPsReturn"></param>
    ''' <remarks></remarks>
    Private Sub AddPsDataFromEPricerComp_PricesData(ByRef dtEPricerComp_PricesData As DataTable, _
                                                  ByRef dtPs As DataTable, _
                                                  ByRef dtPsReturn As DataTable)

        Const ERR_MSG_001 As String = "QuoteID、製品番号、数量、Listpriceが一致するﾃﾞｰﾀがありません。"
        Const ERR_MSG_002 As String = "COST情報がありません。"

        Dim drEPricer As DataRow
        Dim strFilter As New StringBuilder
        Dim drInsert As DataRow
        Dim drPs() As DataRow
        Dim strTransactionId As String          '承認番号
        Dim strProductNo As String              '製品番号
        Dim strQty As String                    '数量
        Dim strListPrice As String              'ListPrice
        Dim strCostTotal As String              'COST合計
        Dim strLog As String
        Dim alExcelWrite As New ArrayList       'EXCEL出力行
        Dim strExcelRow As String               '現EXCEL行
        Dim intPsCnt As Integer

        Try
            For Each drEPricer In dtEPricerComp_PricesData.Select

                strLog = ""

                'e-PricerデータのEstimated_TmcがNullの場合、エラーログに出力
                strCostTotal = ExcelWrite.changeDBNullToString(drEPricer.Item(EPRICER_COMP_COLUMNNAME_COST))
                If strCostTotal = "" Then
                    strLog = ERR_MSG_002
                Else

                    'TransactionID(承認番号)、製品番号、数量、ListPriceが一致するPaymentを検索
                    strTransactionId = ExcelWrite.changeDBNullToString(drEPricer.Item(EPRICER_COMP_COLUMNNAME_QUOTEID))
                    strProductNo = ExcelWrite.changeDBNullToString(drEPricer.Item(EPRICER_COMP_COLUMNNAME_TYPE)) &
                                   "-" &
                                   ExcelWrite.changeDBNullToString(drEPricer.Item(EPRICER_COMP_COLUMNNAME_MODEL))
                    strQty = ExcelWrite.changeDBNullToString(drEPricer.Item(EPRICER_COMP_COLUMNNAME_QTY))
                    strListPrice = ExcelWrite.changeDBNullToString(drEPricer.Item(EPRICER_COMP_COLUMNNAME_LISTPRICE))

                    'Paymentの該当行抽出
                    '初期化
                    strFilter.Remove(0, strFilter.Length)
                    '基本条件
                    strFilter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                    strFilter.Append(PSEXCEL_CLOUMNMNAME_LOCK_FLAG)
                    strFilter.Append(CommonConstant.SQL_STR_EQUAL)
                    strFilter.Append(StringEdit.EncloseSingleQuotation(""))
                    strFilter.Append(CommonConstant.SQL_STR_AND)
                    strFilter.Append(PSEXCEL_CLOUMNMNAME_ST_COST)
                    strFilter.Append(CommonConstant.SQL_STR_EQUAL)
                    strFilter.Append(StringEdit.EncloseSingleQuotation("Y"))
                    strFilter.Append(CommonConstant.SQL_STR_AND)
                    strFilter.Append(PSEXCEL_CLOUMNMNAME_VALID_FLAG)
                    strFilter.Append(CommonConstant.SQL_STR_NOT)
                    strFilter.Append(CommonConstant.SQL_STR_IN)
                    strFilter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                    strFilter.Append(StringEdit.EncloseSingleQuotation("C"))
                    strFilter.Append(CommonConstant.STR_COMMA)
                    strFilter.Append(StringEdit.EncloseSingleQuotation("N"))
                    strFilter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                    '追加条件
                    '承認番号
                    strFilter.Append(CommonConstant.SQL_STR_AND)
                    strFilter.Append(PSEXCEL_CLOUMNMNAME_BRAND_AP_CONF)
                    strFilter.Append(CommonConstant.SQL_STR_EQUAL)
                    strFilter.Append(StringEdit.EncloseSingleQuotation(strTransactionId))
                    '項目１（承認番号）
                    strFilter.Append(CommonConstant.SQL_STR_AND)
                    strFilter.Append(PSEXCEL_CLOUMNMNAME_PROD_ITEM01)
                    strFilter.Append(CommonConstant.SQL_STR_EQUAL)
                    strFilter.Append(StringEdit.EncloseSingleQuotation(strProductNo))
                    '数量
                    strFilter.Append(CommonConstant.SQL_STR_AND)
                    strFilter.Append(PSEXCEL_CLOUMNMNAME_QTY)
                    strFilter.Append(CommonConstant.SQL_STR_EQUAL)
                    strFilter.Append(StringEdit.EncloseSingleQuotation(strQty))
                    'Listprice(単価)_ﾘﾌﾚｯｼｭ後
                    strFilter.Append(CommonConstant.SQL_STR_AND)

                    'Req:1484 str
                    'strFilter.Append(PSEXCEL_CLOUMNMNAME_LIST_PRICE_TOTAL_REFLESH)
                    ''修正

                    strFilter.Append(PSEXCEL_CLOUMNMNAME_LIST_PRICE_REFLESH)
                    'Req:1484 end

                    strFilter.Append(CommonConstant.SQL_STR_EQUAL)
                    strFilter.Append(StringEdit.EncloseSingleQuotation(strListPrice))
                    strFilter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                    ''パターンCD毎の条件
                    ''AAS Box/Mes
                    strFilter.Append(CommonConstant.SQL_STR_AND)
                    strFilter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                    strFilter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                    strFilter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                    strFilter.Append(CommonConstant.SQL_STR_EQUAL)
                    strFilter.Append(StringEdit.EncloseSingleQuotation("1"))
                    strFilter.Append(CommonConstant.SQL_STR_OR)
                    strFilter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                    strFilter.Append(CommonConstant.SQL_STR_EQUAL)
                    strFilter.Append(StringEdit.EncloseSingleQuotation("2"))
                    strFilter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                    strFilter.Append(CommonConstant.SQL_STR_OR)
                    strFilter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                    strFilter.Append(PSEXCEL_CLOUMNMNAME_PATTERN_CD)
                    strFilter.Append(CommonConstant.SQL_STR_EQUAL)
                    strFilter.Append(StringEdit.EncloseSingleQuotation("25"))
                    strFilter.Append(CommonConstant.SQL_STR_AND)
                    strFilter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                    strFilter.Append(PSEXCEL_CLOUMNMNAME_PATTERN)
                    strFilter.Append(CommonConstant.SQL_STR_EQUAL)
                    strFilter.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_IBM_HW_AAS_BOX))
                    strFilter.Append(CommonConstant.SQL_STR_OR)
                    strFilter.Append(PSEXCEL_CLOUMNMNAME_PATTERN)
                    strFilter.Append(CommonConstant.SQL_STR_EQUAL)
                    strFilter.Append(StringEdit.EncloseSingleQuotation(CommonConstant.PATTERNNM_IBM_HW_AAS_MES))
                    strFilter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                    strFilter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                    strFilter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                    drPs = dtPs.Select(strFilter.ToString)
                    If drPs.Length > 0 Then
                        For intPsCnt = 0 To (drPs.Length - 1)

                            '既に出力されたExcel行か判定
                            strExcelRow = ExcelWrite.changeDBNullToString(drPs(intPsCnt).Item(PSEXCEL_CLOUMNMNAME_EXCELROW))
                            If alExcelWrite.Contains(strExcelRow) = False Then
                                'まだ出力されていない場合、以下の処理を行う

                                strQty = ExcelWrite.changeDBNullToString(drEPricer.Item(EPRICER_COMP_COLUMNNAME_QTY))
                                drInsert = dtPsReturn.NewRow
                                drInsert.Item(PSEXCEL_CLOUMNMNAME_EXCELROW) = drPs(intPsCnt).Item(PSEXCEL_CLOUMNMNAME_EXCELROW)
                                'e-PricerのCOST合計と数量が数値の場合、COST単価を求める
                                If IsNumeric(strCostTotal) = True And
                                    IsNumeric(strQty) = True Then
                                    drInsert.Item(PSEXCEL_CLOUMNMNAME_COST) = Double.Parse(strCostTotal)
                                    strLog = ExcelWrite.changeDBNullToString(drPs(intPsCnt).Item(PSEXCEL_CLOUMNMNAME_LINE_NO))
                                Else
                                    drInsert.Item(PSEXCEL_CLOUMNMNAME_COST) = ""
                                End If
                                'Excel出力行設定
                                alExcelWrite.Add(strExcelRow)

                                dtPsReturn.Rows.Add(drInsert)

                                Exit For
                            End If
                        Next
                    Else
                        strLog = ERR_MSG_001
                    End If
                End If
                If strLog <> "" Then
                    drEPricer.Item(EPRICER_COMP_COLUMNNAME_LOG) = strLog
                    'Req:1484 str 同一keyの反映データが存在し、Payment側が少ない場合にメッセージが空白になる
                Else
                    drEPricer.Item(EPRICER_COMP_COLUMNNAME_LOG) = ERR_MSG_001
                    'Req:1484 end
                End If
            Next

        Catch ex As Exception
            Throw ex
        End Try

    End Sub
    'Req:1484 end

    ''' <summary>
    ''' e-Pricer用ログ出力
    ''' </summary>
    ''' <param name="ePricerTBL"></param>
    ''' <param name="xlBookCost"></param>
    ''' <param name="intEPricerOutCount"></param>
    ''' <remarks></remarks>
    Private Sub OutEPricerLogSheet(ByRef ePricerTBL() As DataTable, _
                                   ByRef xlBookCost As Excel.Workbook, _
                                   ByRef intEPricerOutCount As Integer)

        Dim dt As DataTable
        Dim xlSheet As Excel.Worksheet
        Dim intMatchCount As Integer

        Try
            'Req:1484 str
            'Componentのログ出力
            'xlSheet = xlBookCost.Worksheets(ExcelWrite.EXCEL_COST_EP_COMPONENT)
            xlSheet = xlBookCost.Worksheets(ExcelWrite.EXCEL_COST_EP_COMP_PRICES)
            'Req:1484 end
            dt = ePricerTBL(0)
            intMatchCount = 0
            'Req:1484 str
            'Call OutEPricerComponentLog(dt, xlSheet, intMatchCount)
            Call OutEPricerComp_PricesLog(dt, xlSheet, intMatchCount)
            'Req:1484 end
            intEPricerOutCount = intEPricerOutCount + intMatchCount

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Sub

    ' ''' <summary>
    ' ''' 機能：Componentのログ出力
    ' ''' </summary>
    ' ''' <param name="dtComp"></param>
    ' ''' <param name="xlSheet"></param>
    ' ''' <param name="intMatchCount"></param>
    ' ''' <remarks></remarks>
    'Private Sub OutEPricerComponentLog(ByVal dtComp As DataTable, ByRef xlSheet As Excel.Worksheet, ByRef intMatchCount As Integer)

    '    Dim dr As DataRow
    '    Dim strLog As String
    '    Dim xlCell As Excel.Range
    '    Dim strRange As String

    '    Try
    '        intMatchCount = 0
    '        For Each dr In dtComp.Select
    '            strLog = ExcelWrite.changeDBNullToString(dr.Item(EPRICER_COMP_COLUMNNAME_LOG))
    '            If strLog <> "" Then
    '                strRange = "HU" & ExcelWrite.changeDBNullToString(dr.Item(EPRICER_COMP_COLUMNNAME_ROWNO))
    '                xlCell = xlSheet.Range(strRange)
    '                If IsNumeric(strLog) = True Then
    '                    strLog = "行番号：" & strLog & "にCostを書込ました。"
    '                    intMatchCount = intMatchCount + 1
    '                End If
    '                xlCell.Value = strLog
    '                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
    '            End If
    '        Next

    '    Catch ex As Exception
    '        Throw ex

    '    Finally
    '        ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
    '        GC.Collect()
    '    End Try

    'End Sub

    ''' <summary>
    ''' 機能：Comp_Pricesのログ出力
    ''' </summary>
    ''' <param name="dtComp"></param>
    ''' <param name="xlSheet"></param>
    ''' <param name="intMatchCount"></param>
    ''' <remarks></remarks>
    Private Sub OutEPricerComp_PricesLog(ByVal dtComp As DataTable, ByRef xlSheet As Excel.Worksheet, ByRef intMatchCount As Integer)

        Dim dr As DataRow
        Dim strLog As String
        Dim xlCell As Excel.Range
        Dim strRange As String

        Try
            intMatchCount = 0
            For Each dr In dtComp.Select
                strLog = ExcelWrite.changeDBNullToString(dr.Item(EPRICER_COMP_COLUMNNAME_LOG))
                If strLog <> "" Then
                    strRange = "K" & ExcelWrite.changeDBNullToString(dr.Item(EPRICER_COMP_COLUMNNAME_ROWNO))
                    xlCell = xlSheet.Range(strRange)
                    If IsNumeric(strLog) = True Then
                        strLog = "行番号：" & strLog & "にCostを書込ました。"
                        intMatchCount = intMatchCount + 1
                    End If
                    xlCell.Value = strLog
                    ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                End If
            Next

        Catch ex As Exception
            Throw ex

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try

    End Sub

    ''' <summary>
    ''' 機能：Cost開示ファイルの種別を取得
    ''' </summary>
    ''' <param name="dtComp"></param>
    ''' <param name="xlSheet"></param>
    ''' <param name="intMatchCount"></param>
    ''' <remarks></remarks>
    Public Function GetFileType(costFileNM As String) As String

        ''Excelのオブジェト
        Dim xlApp As New Excel.Application
        Dim CostKaijiBook As Excel.Workbook

        Try
            ''----------------------
            ''COST開示ファイルの読込
            ''----------------------
            CostKaijiBook = xlApp.Workbooks.Open(costFileNM)

            ''個別PSシート
            Dim CostKaijiPSSheetData As DataTable
            CostKaijiPSSheetData = GetPSCostKaijiData(CostKaijiBook)

            ''個別詳細シート
            Dim CostKaijiDetailSheetData As DataTable
            CostKaijiDetailSheetData = GetDetailCostKaijiData(CostKaijiBook)
            If IsNothing(CostKaijiDetailSheetData) = False Then
                Call DelSLineDate("Cost", CostKaijiDetailSheetData)
            End If

            ''参考シート
            ''※既存AASHMAの場合、参考シートのデータを元に取込む
            ''※既存の処理を流用するため、参考シートデータをCostKaijiPSSheetDataにセット
            Dim CostDefSheetData As DataTable
            CostDefSheetData = GetPSCostRefData(CostKaijiBook)
            If IsNothing(CostDefSheetData) = False AndAlso _
               CostDefSheetData.Rows.Count > 0 Then
                CostKaijiPSSheetData = CostDefSheetData
            End If

            ''Topacsｼｰﾄ
            Dim patternCD As String = ""
            Dim TopacsTBL() As DataTable
            TopacsTBL = GetTopacsCostKaijiData(CostKaijiBook, patternCD)

            'e-Pricer用COST開示ファイルからデータ取得
            Dim ePricerTBL() As DataTable
            ePricerTBL = GetEPricerCostKaijiData(CostKaijiBook, patternCD)

            ''対象のデータかどうか判定
            Dim newExist As String
            Call GetCostFileType(CostKaijiPSSheetData, patternCD, newExist, TopacsTBL)

            GetFileType = patternCD

        Catch ex As Exception

            Throw ex

        Finally
            If IsNothing(CostKaijiBook) = False Then
                CostKaijiBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(CostKaijiBook, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Function

#End Region

End Class
