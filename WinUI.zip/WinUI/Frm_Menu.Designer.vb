﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frm_Menu
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblCPNO = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblContractName = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.cboContractNo = New System.Windows.Forms.ComboBox()
        Me.Btn_RegistPlan = New MUSE.UserControl.UCnt_Btn0001()
        Me.UCnt_Btn00013 = New MUSE.UserControl.UCnt_Btn0001()
        Me.UCnt_Btn00012 = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_ReadStructInf = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_PmoManage = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_DataOutput = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_ExpImp = New MUSE.UserControl.UCnt_Btn0001()
        Me.UCnt_Pal00011 = New MUSE.UserControl.UCnt_Pal0001()
        Me.Btn_PaymentEditing = New MUSE.UserControl.UCnt_Btn0001()
        Me.UCnt_Btn00011 = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_DspFrmTmp = New MUSE.UserControl.UCnt_Btn0001()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.lblDetailMDBCount = New System.Windows.Forms.Label()
        Me.lblDetailCreateTime = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblPSMDBCount = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.lblPSCreateTime = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label1.Location = New System.Drawing.Point(13, 26)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(130, 15)
        Me.Label1.TabIndex = 51
        Me.Label1.Text = "お客様名（CPNO）"
        '
        'lblCPNO
        '
        Me.lblCPNO.AutoSize = True
        Me.lblCPNO.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblCPNO.Location = New System.Drawing.Point(156, 26)
        Me.lblCPNO.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblCPNO.Name = "lblCPNO"
        Me.lblCPNO.Size = New System.Drawing.Size(57, 15)
        Me.lblCPNO.TabIndex = 52
        Me.lblCPNO.Text = "@----*"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label2.Location = New System.Drawing.Point(13, 50)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(71, 15)
        Me.Label2.TabIndex = 53
        Me.Label2.Text = "契約順番"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label3.Location = New System.Drawing.Point(13, 74)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(87, 15)
        Me.Label3.TabIndex = 53
        Me.Label3.Text = "契約順番名"
        '
        'lblContractName
        '
        Me.lblContractName.AutoSize = True
        Me.lblContractName.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblContractName.Location = New System.Drawing.Point(156, 74)
        Me.lblContractName.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblContractName.Name = "lblContractName"
        Me.lblContractName.Size = New System.Drawing.Size(335, 15)
        Me.lblContractName.TabIndex = 54
        Me.lblContractName.Text = "@--------*@--------*@--------*@--------*"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.cboContractNo)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.lblContractName)
        Me.GroupBox1.Controls.Add(Me.lblCPNO)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(1, 64)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Size = New System.Drawing.Size(497, 106)
        Me.GroupBox1.TabIndex = 55
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "契約情報"
        '
        'cboContractNo
        '
        Me.cboContractNo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboContractNo.DropDownWidth = 300
        Me.cboContractNo.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.cboContractNo.FormattingEnabled = True
        Me.cboContractNo.Location = New System.Drawing.Point(159, 46)
        Me.cboContractNo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cboContractNo.Name = "cboContractNo"
        Me.cboContractNo.Size = New System.Drawing.Size(57, 23)
        Me.cboContractNo.TabIndex = 56
        '
        'Btn_RegistPlan
        '
        Me.Btn_RegistPlan.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_RegistPlan.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_RegistPlan.ForeColor = System.Drawing.Color.White
        Me.Btn_RegistPlan.Location = New System.Drawing.Point(1, 182)
        Me.Btn_RegistPlan.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Btn_RegistPlan.Name = "Btn_RegistPlan"
        Me.Btn_RegistPlan.Size = New System.Drawing.Size(413, 80)
        Me.Btn_RegistPlan.TabIndex = 0
        Me.Btn_RegistPlan.Text = "案件情報登録"
        Me.Btn_RegistPlan.UseVisualStyleBackColor = False
        '
        'UCnt_Btn00013
        '
        Me.UCnt_Btn00013.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.UCnt_Btn00013.BackColor = System.Drawing.Color.RoyalBlue
        Me.UCnt_Btn00013.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UCnt_Btn00013.ForeColor = System.Drawing.Color.White
        Me.UCnt_Btn00013.Location = New System.Drawing.Point(216, 482)
        Me.UCnt_Btn00013.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.UCnt_Btn00013.Name = "UCnt_Btn00013"
        Me.UCnt_Btn00013.Size = New System.Drawing.Size(199, 55)
        Me.UCnt_Btn00013.TabIndex = 7
        Me.UCnt_Btn00013.Text = "契約情報登録へ"
        Me.UCnt_Btn00013.UseVisualStyleBackColor = False
        '
        'UCnt_Btn00012
        '
        Me.UCnt_Btn00012.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.UCnt_Btn00012.BackColor = System.Drawing.Color.RoyalBlue
        Me.UCnt_Btn00012.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UCnt_Btn00012.ForeColor = System.Drawing.Color.White
        Me.UCnt_Btn00012.Location = New System.Drawing.Point(1, 482)
        Me.UCnt_Btn00012.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.UCnt_Btn00012.Name = "UCnt_Btn00012"
        Me.UCnt_Btn00012.Size = New System.Drawing.Size(199, 55)
        Me.UCnt_Btn00012.TabIndex = 6
        Me.UCnt_Btn00012.Text = "ログアウト"
        Me.UCnt_Btn00012.UseVisualStyleBackColor = False
        '
        'Btn_ReadStructInf
        '
        Me.Btn_ReadStructInf.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_ReadStructInf.Enabled = False
        Me.Btn_ReadStructInf.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_ReadStructInf.ForeColor = System.Drawing.Color.White
        Me.Btn_ReadStructInf.Location = New System.Drawing.Point(1, 368)
        Me.Btn_ReadStructInf.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Btn_ReadStructInf.Name = "Btn_ReadStructInf"
        Me.Btn_ReadStructInf.Size = New System.Drawing.Size(413, 80)
        Me.Btn_ReadStructInf.TabIndex = 2
        Me.Btn_ReadStructInf.Text = "構成情報読込"
        Me.Btn_ReadStructInf.UseVisualStyleBackColor = False
        '
        'Btn_PmoManage
        '
        Me.Btn_PmoManage.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_PmoManage.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_PmoManage.ForeColor = System.Drawing.Color.White
        Me.Btn_PmoManage.Location = New System.Drawing.Point(429, 368)
        Me.Btn_PmoManage.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Btn_PmoManage.Name = "Btn_PmoManage"
        Me.Btn_PmoManage.Size = New System.Drawing.Size(413, 80)
        Me.Btn_PmoManage.TabIndex = 5
        Me.Btn_PmoManage.Text = "連携ファイル管理"
        Me.Btn_PmoManage.UseVisualStyleBackColor = False
        '
        'Btn_DataOutput
        '
        Me.Btn_DataOutput.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_DataOutput.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_DataOutput.ForeColor = System.Drawing.Color.White
        Me.Btn_DataOutput.Location = New System.Drawing.Point(429, 275)
        Me.Btn_DataOutput.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Btn_DataOutput.Name = "Btn_DataOutput"
        Me.Btn_DataOutput.Size = New System.Drawing.Size(413, 80)
        Me.Btn_DataOutput.TabIndex = 5
        Me.Btn_DataOutput.Text = "集計及び台帳作成"
        Me.Btn_DataOutput.UseVisualStyleBackColor = False
        '
        'Btn_ExpImp
        '
        Me.Btn_ExpImp.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_ExpImp.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_ExpImp.ForeColor = System.Drawing.Color.White
        Me.Btn_ExpImp.Location = New System.Drawing.Point(429, 182)
        Me.Btn_ExpImp.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Btn_ExpImp.Name = "Btn_ExpImp"
        Me.Btn_ExpImp.Size = New System.Drawing.Size(413, 80)
        Me.Btn_ExpImp.TabIndex = 4
        Me.Btn_ExpImp.Text = "エクスポート EXCEL→CSV変換/" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "インポート CSV→EXCEL変換"
        Me.Btn_ExpImp.UseVisualStyleBackColor = False
        '
        'UCnt_Pal00011
        '
        Me.UCnt_Pal00011.BackColor = System.Drawing.Color.Teal
        Me.UCnt_Pal00011.BackColro2 = System.Drawing.Color.PaleTurquoise
        Me.UCnt_Pal00011.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UCnt_Pal00011.ForeColor = System.Drawing.Color.White
        Me.UCnt_Pal00011.Location = New System.Drawing.Point(1, 1)
        Me.UCnt_Pal00011.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.UCnt_Pal00011.Name = "UCnt_Pal00011"
        Me.UCnt_Pal00011.Size = New System.Drawing.Size(841, 55)
        Me.UCnt_Pal00011.TabIndex = 30
        Me.UCnt_Pal00011.TitleText = "OIO BAMA Client  メニュー"
        '
        'Btn_PaymentEditing
        '
        Me.Btn_PaymentEditing.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_PaymentEditing.Enabled = False
        Me.Btn_PaymentEditing.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_PaymentEditing.ForeColor = System.Drawing.Color.White
        Me.Btn_PaymentEditing.Location = New System.Drawing.Point(1, 275)
        Me.Btn_PaymentEditing.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Btn_PaymentEditing.Name = "Btn_PaymentEditing"
        Me.Btn_PaymentEditing.Size = New System.Drawing.Size(413, 80)
        Me.Btn_PaymentEditing.TabIndex = 1
        Me.Btn_PaymentEditing.Text = "Payment Sheet 編集"
        Me.Btn_PaymentEditing.UseVisualStyleBackColor = False
        '
        'UCnt_Btn00011
        '
        Me.UCnt_Btn00011.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.UCnt_Btn00011.BackColor = System.Drawing.Color.RoyalBlue
        Me.UCnt_Btn00011.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UCnt_Btn00011.ForeColor = System.Drawing.Color.White
        Me.UCnt_Btn00011.Location = New System.Drawing.Point(644, 482)
        Me.UCnt_Btn00011.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.UCnt_Btn00011.Name = "UCnt_Btn00011"
        Me.UCnt_Btn00011.Size = New System.Drawing.Size(199, 55)
        Me.UCnt_Btn00011.TabIndex = 9
        Me.UCnt_Btn00011.Text = "ﾌｫﾙﾀﾞ表示"
        Me.UCnt_Btn00011.UseVisualStyleBackColor = False
        '
        'Btn_DspFrmTmp
        '
        Me.Btn_DspFrmTmp.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Btn_DspFrmTmp.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_DspFrmTmp.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_DspFrmTmp.ForeColor = System.Drawing.Color.White
        Me.Btn_DspFrmTmp.Location = New System.Drawing.Point(429, 482)
        Me.Btn_DspFrmTmp.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Btn_DspFrmTmp.Name = "Btn_DspFrmTmp"
        Me.Btn_DspFrmTmp.Size = New System.Drawing.Size(199, 55)
        Me.Btn_DspFrmTmp.TabIndex = 8
        Me.Btn_DspFrmTmp.Text = "契約統合/削除"
        Me.Btn_DspFrmTmp.UseVisualStyleBackColor = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.lblDetailMDBCount)
        Me.GroupBox2.Controls.Add(Me.lblDetailCreateTime)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.lblPSMDBCount)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.lblPSCreateTime)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(509, 64)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox2.Size = New System.Drawing.Size(333, 106)
        Me.GroupBox2.TabIndex = 58
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "MDB情報"
        '
        'lblDetailMDBCount
        '
        Me.lblDetailMDBCount.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblDetailMDBCount.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblDetailMDBCount.Location = New System.Drawing.Point(244, 68)
        Me.lblDetailMDBCount.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblDetailMDBCount.Name = "lblDetailMDBCount"
        Me.lblDetailMDBCount.Size = New System.Drawing.Size(84, 24)
        Me.lblDetailMDBCount.TabIndex = 298
        Me.lblDetailMDBCount.Text = "9999999件"
        Me.lblDetailMDBCount.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblDetailCreateTime
        '
        Me.lblDetailCreateTime.AutoSize = True
        Me.lblDetailCreateTime.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblDetailCreateTime.Location = New System.Drawing.Point(83, 68)
        Me.lblDetailCreateTime.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblDetailCreateTime.Name = "lblDetailCreateTime"
        Me.lblDetailCreateTime.Size = New System.Drawing.Size(154, 15)
        Me.lblDetailCreateTime.TabIndex = 297
        Me.lblDetailCreateTime.Text = "yyyy/MM/dd HH:mm:ss"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label7.Location = New System.Drawing.Point(9, 68)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(37, 15)
        Me.Label7.TabIndex = 296
        Me.Label7.Text = "詳細"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label6.Location = New System.Drawing.Point(9, 44)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(62, 15)
        Me.Label6.TabIndex = 295
        Me.Label6.Text = "Payment"
        '
        'lblPSMDBCount
        '
        Me.lblPSMDBCount.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblPSMDBCount.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblPSMDBCount.Location = New System.Drawing.Point(244, 45)
        Me.lblPSMDBCount.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblPSMDBCount.Name = "lblPSMDBCount"
        Me.lblPSMDBCount.Size = New System.Drawing.Size(84, 24)
        Me.lblPSMDBCount.TabIndex = 294
        Me.lblPSMDBCount.Text = "9999999件"
        Me.lblPSMDBCount.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label8.Location = New System.Drawing.Point(83, 22)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(67, 15)
        Me.Label8.TabIndex = 51
        Me.Label8.Text = "作成日時"
        '
        'lblPSCreateTime
        '
        Me.lblPSCreateTime.AutoSize = True
        Me.lblPSCreateTime.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblPSCreateTime.Location = New System.Drawing.Point(83, 44)
        Me.lblPSCreateTime.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblPSCreateTime.Name = "lblPSCreateTime"
        Me.lblPSCreateTime.Size = New System.Drawing.Size(154, 15)
        Me.lblPSCreateTime.TabIndex = 52
        Me.lblPSCreateTime.Text = "yyyy/MM/dd HH:mm:ss"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label12.Location = New System.Drawing.Point(257, 22)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(68, 15)
        Me.Label12.TabIndex = 53
        Me.Label12.Text = "ﾃﾞｰﾀ件数"
        '
        'Frm_Menu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(848, 545)
        Me.ControlBox = False
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.Btn_DspFrmTmp)
        Me.Controls.Add(Me.UCnt_Btn00011)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Btn_RegistPlan)
        Me.Controls.Add(Me.UCnt_Btn00013)
        Me.Controls.Add(Me.UCnt_Btn00012)
        Me.Controls.Add(Me.Btn_ReadStructInf)
        Me.Controls.Add(Me.Btn_PmoManage)
        Me.Controls.Add(Me.Btn_DataOutput)
        Me.Controls.Add(Me.Btn_ExpImp)
        Me.Controls.Add(Me.UCnt_Pal00011)
        Me.Controls.Add(Me.Btn_PaymentEditing)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.MaximizeBox = False
        Me.Name = "Frm_Menu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "OIO BAMA Client"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents UCnt_Pal00011 As MUSE.UserControl.UCnt_Pal0001
    Friend WithEvents Btn_ExpImp As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_DataOutput As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_ReadStructInf As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents UCnt_Btn00012 As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_PaymentEditing As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents UCnt_Btn00013 As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_RegistPlan As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblCPNO As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lblContractName As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Btn_PmoManage As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents UCnt_Btn00011 As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_DspFrmTmp As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents lblPSCreateTime As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents lblDetailMDBCount As System.Windows.Forms.Label
    Friend WithEvents lblDetailCreateTime As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents lblPSMDBCount As System.Windows.Forms.Label
    Friend WithEvents cboContractNo As System.Windows.Forms.ComboBox
End Class
