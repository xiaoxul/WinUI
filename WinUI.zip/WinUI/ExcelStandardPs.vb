﻿Imports System.IO
Imports System.Text
Imports System.Data.OleDb
Imports Microsoft.Office.Interop
Imports MUSE.Utility
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.OioBamaCommmon
Imports MUSE.Utility.UserMessageBox
Imports MUSE.Utility.UserDataTable.Master

Public Class ExcelStandardPs

#Region "Constract"
    Private Const STR_SHEETNAME_SETTING As String = "表示設定"
    Private Const STR_SHEETNAME_TEMPLATE As String = "Template"
    Private Const STR_SHEETNAME_OUTPUTINFO As String = "出力情報"
    Private Const STR_SHEETNAME_IMAGE As String = "IMAGE"
    Private Const STR_SHEETNAME_DETAIL As String = ExcelWrite.EXCEL_TOPACSDATE_DETAILSHEET
    Private Const ROW_DATA_START As Integer = ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW
    Private Const ROW_DETAIL_DATA_START As Integer = ExcelWrite.EXCEL_DETAILLINEDATE_OUTROW
    Private Const DIVISION_LINES As Integer = 1000
    Private Const ROW_TOTAL_DETAIL As String = "2:2"
    Private Const ROW_SAMPLE_DETAIL As String = "3:3"
    Private Const RANGE_VALUE_DETAIL As String = "A@:AG@"
    Private Const ROW_SAMPLE_PAYMENT As String = "2:2"
    Private Const CD_STROUT_STANDARD As Integer = 0         '標準帳票
    Private Const CD_STROUT_DATA_ALL As Integer = 1         '提供ﾃﾞｰﾀ（全ｶﾗﾑ）
    Private Const CD_STROUT_DATA_DEL As Integer = 2         '提供ﾃﾞｰﾀ（削除ｶﾗﾑ有）
    Private Const IDX_WORK_PS1 As Integer = 0               'TBL1,TBL2(過去の合計金額以外)
    Private Const IDX_WORK_PS2 As Integer = 1               'TBL3(年額)1
    Private Const IDX_WORK_PS3 As Integer = 2               'TBL3(年額)2
    Private Const IDX_WORK_PS4 As Integer = 3               'TBL3(月額)1
    Private Const IDX_WORK_PS5 As Integer = 4               'TBL3(月額)2
#End Region

#Region "Public Method"

    ''' <summary>
    ''' 機　能：標準帳表設定処理
    ''' 概　要：
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function MakeStandardExcelPs(ByRef strMsg As String) As Boolean

        Dim blnRet As Boolean
        Dim strDbFileName As String = ""
        Dim strStdExcelFileName As String = ""
        Dim strExcelStart As String = ""
        Dim strContractStart As String = ""
        Dim strContractEnd As String = ""

        MakeStandardExcelPs = False

        Try
            strExcelStart = CommonVariable.PaymentStart.ToString("yyyy")
            strContractStart = CommonVariable.ContractStart.ToString("yyyyMM")
            strContractEnd = CommonVariable.ContractEnd.ToString("yyyyMM")

            'Templateファイル（標準帳表設定PS.xls）をOutputフォルダにコピー
            blnRet = CopyTemplate(strStdExcelFileName, strMsg)
            If blnRet = False Then
                Exit Function
            End If

            '標準帳表起動
            blnRet = OpenStdExcelPs(strStdExcelFileName, strExcelStart, strContractStart, strContractEnd, strMsg)
            If blnRet = False Then
                Exit Function
            End If

            MakeStandardExcelPs = True

        Catch ex As Exception
            strMsg = ex.Message.ToString & "(MakeStandardExcelPs)"

        End Try

    End Function

    ''' <summary>
    ''' 機　能：標準帳表でデータ出力
    ''' 概　要：
    ''' </summary>
    ''' <param name="strStdExcelFileName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function OutputStdExcelPs(ByVal strStdExcelFileName As String, ByRef strMsg As String) As Boolean

        Dim blnRet As Boolean
        Dim strExcelStart As String = ""
        Dim strDbFileName As String = ""
        Dim strContractStart As String = ""
        Dim strContractEnd As String = ""
        Dim strNewStdExcelFileName As String = ""
        Dim mmc As New MasterMdbControl
        Dim con As OleDbConnection
        Dim strCsvPath As String
        Dim strCreateDate As String
        Dim ofm As New OioFileManage

        OutputStdExcelPs = False

        Try
            strExcelStart = CommonVariable.PaymentStart.ToString("yyyy")
            strContractStart = CommonVariable.ContractStart.ToString("yyyyMM")
            strContractEnd = CommonVariable.ContractEnd.ToString("yyyyMM")

            '-------------------------------------------
            'DB OPEN
            '-------------------------------------------
            con = mmc.GetOleTmpDBConnection(CommonVariable.CPNO, CommonVariable.MdbPW)

            '-------------------------------------------
            'データ出力
            '-------------------------------------------
            strCsvPath = Path.GetFullPath("../log/")
            strCreateDate = Now.ToString("yyyyMMdd_HHmmss")
            'Payment
            strDbFileName = ofm.GetDataKeepMDBPath(CommonVariable.CPNO)
            blnRet = OutputDataPs(con, strStdExcelFileName, strNewStdExcelFileName, strCsvPath, strCreateDate, strMsg)
            If blnRet = False Then
                Exit Function
            End If
            '詳細
            blnRet = OutputDataDetail(con, strNewStdExcelFileName, strCsvPath, strCreateDate, strMsg)
            If blnRet = False Then
                Exit Function
            End If

            OutputStdExcelPs = True

        Catch ex As Exception
            strMsg = ex.Message.ToString & "(OutputStdExcelPs)"

        Finally
            If IsNothing(con) = False AndAlso con.State = ConnectionState.Open Then
                con.Close()
            End If

            'ﾜｰｸﾌｧｲﾙ削除
            Call ofm.DeleteWorkFile(strCsvPath)
        End Try

    End Function

    ''' <summary>
    ''' 機　能：ﾃﾞｰﾀ提供用出力
    ''' 概　要：
    ''' </summary>
    ''' <param name="intImportCd"></param>
    ''' <param name="strExcelStart"></param>
    ''' <param name="strMsg"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function OutputSubmittedData(ByVal intImportCd As Integer,
                                        ByVal strExcelStart As String,
                                        ByVal dtOutputDate As Date,
                                        ByVal intPaymentPeriod As Integer,
                                        ByRef strMsg As String) As Boolean

        Dim blnRet As Boolean
        Dim strExcelFileName As String = ""
        Dim strNewPath As String
        Dim mmc As New MasterMdbControl
        Dim con As OleDbConnection
        Dim strTmpExcelFileName As String
        Dim ofm As New OioFileManage
        Dim strCsvPath As String
        Dim strCsvFileNamePs(5) As String
        Dim strCsvFileNamePsd As String
        Dim intCnt As Integer
        Dim strCreateDate As String

        Dim xlApp As Excel.Application = Nothing
        Dim xlBooks As Excel.Workbooks = Nothing
        Dim xlBook As Excel.Workbook = Nothing
        Dim xlSheets As Excel.Sheets = Nothing
        Dim xlSheet As Excel.Worksheet = Nothing
        Dim xlRange As Excel.Range = Nothing
        Dim xlTmpBook As Excel.Workbook = Nothing
        Dim xlTmpSheets As Excel.Sheets = Nothing
        Dim xlTmpSheet As Excel.Worksheet = Nothing
        Dim xlNames As Excel.Names = Nothing
        Dim xlName As Excel.Name = Nothing

        OutputSubmittedData = False

        Try
            '----------------------------------------------------
            'DB OPEN
            '----------------------------------------------------
            con = mmc.GetOleTmpDBConnection(CommonVariable.CPNO, CommonVariable.MdbPW)

            '----------------------------------------------------
            'EXCEL 初期化
            '----------------------------------------------------
            'EXCEL OPEN
            xlApp = New Excel.Application
            xlApp.DisplayAlerts = False
            xlBooks = xlApp.Workbooks
            'Templateファイル名
            strTmpExcelFileName = ofm.GetLocalTemplateFolder
            strTmpExcelFileName = strTmpExcelFileName & CommonConstant.FILENAME_XLS_PAYMENTSAMPLE
            xlApp.EnableEvents = False
            xlTmpBook = xlBooks.Open(strTmpExcelFileName)
            'ｼｰﾄ追加
            xlBook = xlBooks.Add()
            xlSheets = xlBook.Sheets
            xlTmpSheets = xlTmpBook.Worksheets
            'Paymentｼｰﾄｺﾋﾟｰ
            xlTmpSheet = xlTmpSheets.Item(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)
            xlTmpSheet.Copy(Before:=xlSheets.Item(xlSheets.Count))
            ExcelObjRelease.ReleaseExcelObj(xlTmpSheet, ExcelObjRelease.OBJECT_NOTHING)
            '詳細ｼｰﾄｺﾋﾟｰ
            xlTmpSheet = xlTmpSheets.Item(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)
            xlTmpSheet.Copy(Before:=xlSheets.Item(xlSheets.Count))
            ExcelObjRelease.ReleaseExcelObj(xlTmpSheet, ExcelObjRelease.OBJECT_NOTHING)

            ExcelObjRelease.ReleaseExcelObj(xlTmpSheets, ExcelObjRelease.OBJECT_NOTHING)
            xlTmpBook.Close(False)
            ExcelObjRelease.ReleaseExcelObj(xlTmpBook, ExcelObjRelease.OBJECT_NOTHING)

            '空白ｼｰﾄ削除
            For Each xlSheet In xlSheets
                If xlSheet.Name <> ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET And
                    xlSheet.Name <> ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET Then
                    xlSheet.Delete()
                End If
                ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            Next
            xlApp.EnableEvents = True

            'Paymentの開始年を出力
            xlSheet = xlSheets.Item(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)
            xlRange = xlSheet.Range(ExcelWrite.EXCEL_COL_PAYMENT_START_YEAR)
            xlRange.Value = strExcelStart
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            '期間内・期間外設定
            Dim objTerm(240) As Object
            Dim strWork As String
            For intCnt1 As Integer = 1 To 20
                For intCnt2 As Integer = 1 To 12
                    strWork = (Integer.Parse(strExcelStart) + (intCnt1 - 1)).ToString("00") & intCnt2.ToString("00")
                    If Integer.Parse(strWork) >= Integer.Parse(CommonVariable.ContractStart.ToString("yyyyMM")) And Integer.Parse(strWork) <= Integer.Parse(CommonVariable.ContractEnd.ToString("yyyyMM")) Then
                        objTerm(((intCnt1 - 1) * 12 + intCnt2 - 1)) = "契約期間内"
                    ElseIf Integer.Parse(strWork) > Integer.Parse(CommonVariable.ContractEnd.ToString("yyyyMM")) Then
                        objTerm(((intCnt1 - 1) * 12 + intCnt2 - 1)) = "契約期間外"
                    Else
                        objTerm(((intCnt1 - 1) * 12 + intCnt2 - 1)) = ""
                    End If
                Next
            Next
            xlSheet = xlSheets.Item(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)
            xlRange = xlSheet.Range("DN3:MS3")
            xlRange.Value = objTerm
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            '名前定義削除
            xlNames = xlBook.Names
            For Each xlName In xlNames
                xlName.Delete()
                ExcelObjRelease.ReleaseExcelObj(xlName, ExcelObjRelease.OBJECT_NOTHING)
            Next
            ExcelObjRelease.ReleaseExcelObj(xlNames, ExcelObjRelease.OBJECT_NOTHING)

            '----------------------------------------------------
            'データ出力
            '----------------------------------------------------
            strCsvPath = Path.GetFullPath("../log/")
            strCreateDate = Now.ToString("yyyyMMdd_HHmmss")
            'Payment
            For intCnt = IDX_WORK_PS1 To IDX_WORK_PS5
                strCsvFileNamePs(intCnt) = strCsvPath & "WorkCsv_SubmittedDataPs" & intCnt.ToString & "_" & strCreateDate & ".csv"
            Next
            xlSheet = xlSheets.Item(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)
            blnRet = OutputSubmittedDataPs(intImportCd,
                                           con,
                                           strCsvFileNamePs,
                                           strExcelStart,
                                           dtOutputDate,
                                           intPaymentPeriod,
                                           xlSheet,
                                           strMsg)
            If blnRet = False Then
                Exit Function
            End If
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            '詳細
            strCsvFileNamePsd = strCsvPath & "WorkCsv_SubmittedDataPsd_" & strCreateDate & ".csv"
            xlSheet = xlSheets.Item(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)
            blnRet = OutputSubmittedDataPsd(con, strCsvFileNamePsd, xlSheet, strMsg)
            If blnRet = False Then
                Exit Function
            End If
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            '----------------------------------------------------
            '保存
            '----------------------------------------------------
            strNewPath = FileManager.GetLocalFolderPath("Bat_Output\EXCEL\StandardReport\Report")
            strExcelFileName = strNewPath & _
                                        "標準帳表PS(" & _
                                        CommonVariable.CPNO & _
                                        "(" & _
                                        CommonVariable.CUSTOMERNAME & _
                                        ")_" & _
                                        Format(Now, "yyyyMMdd_HHmmss") & ".xlsm"
            xlSheet = xlSheets.Item(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)
            xlSheet.Activate()
            xlRange = xlSheet.Range("A1")
            xlRange.Select()
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            xlBook.CheckCompatibility = False
            xlBook.SaveAs(strExcelFileName, Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

            OutputSubmittedData = True

        Catch ex As Exception
            strMsg = ex.Message.ToString & "(OutputSubmittedData)"

        Finally
            'ﾜｰｸﾌｧｲﾙ削除
            Call ofm.DeleteWorkFile(strCsvPath)

            'Excelｵﾌﾞｼﾞｪｸﾄ開放
            ExcelObjRelease.ReleaseExcelObj(xlTmpSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlTmpSheets, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlTmpBook) = False Then
                xlTmpBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlTmpBook, ExcelObjRelease.OBJECT_NOTHING)

            ExcelObjRelease.ReleaseExcelObj(xlName, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlNames, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBook) = False Then
                xlBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlBooks, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            If IsNothing(con) = False AndAlso con.State = ConnectionState.Open Then
                con.Close()
            End If

            ''ガベージコレクトの起動
            GC.Collect()
        End Try

    End Function
#End Region

#Region "Private  Method"
    ''' <summary>
    ''' 機　能：Templateファイル（標準帳表設定PS.xls）をOutputフォルダにコピー
    ''' 概　要：
    ''' </summary>
    ''' <param name="strDestFileName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CopyTemplate(ByRef strDestFileName As String, ByRef strMsg As String) As Boolean

        Dim ofm As New OioFileManage
        Dim strSrcFileName As String
        Dim strPath As String

        CopyTemplate = False

        Try
            strSrcFileName = ofm.GetLocalTemplateFolder & "標準帳表設定PS.xlsm"
            strPath = FileManager.GetLocalFolderPath("Bat_Output") & "EXCEL\StandardReport\Setting"
            strDestFileName = strPath & "\" & _
                                    "標準帳表設定PS_" & _
                                     CommonVariable.CPNO & _
                                     "(" & CommonVariable.CUSTOMERNAME & ")_" & _
                                     Now.ToString("yyyyMMdd_HHmmss") & ".xlsm"
            File.Copy(strSrcFileName, strDestFileName)

            CopyTemplate = True

        Catch ex As Exception
            strMsg = ex.Message.ToString & "(CopyTemplate)"

        Finally
            ofm = Nothing

        End Try

    End Function

    ''' <summary>
    ''' 機　能：標準帳表起動
    ''' 概　要：
    ''' </summary>
    ''' <param name="strStdExcelFileName"></param>
    ''' <param name="strExcelStart"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function OpenStdExcelPs(ByVal strStdExcelFileName As String, ByVal strExcelStart As String, ByVal strContractStart As String, ByVal strContractEnd As String, ByRef strMsg As String) As Boolean

        Dim strOutputYear As String = ""
        Dim strOutputMonth As String = ""
        Dim strOutputMonthlyYear As String = ""
        Dim strOutputTerm As String = ""
        Dim intCnt1 As Integer
        Dim intCnt2 As Integer
        Dim strWork As String
        'Excelオブジェクト
        Dim xlApp As Excel.Application = Nothing
        Dim xlBooks As Excel.Workbooks = Nothing
        Dim xlBook As Excel.Workbook = Nothing
        Dim xlSheet As Excel.Worksheet = Nothing
        Dim xlSheets As Excel.Sheets = Nothing
        Dim xlCell As Excel.Range = Nothing
        Dim xlRange As Excel.Range = Nothing

        OpenStdExcelPs = False

        Try
            'EXCEL OPEN
            xlApp = New Excel.Application
            xlApp.DisplayAlerts = True
            xlApp.Visible = False
            xlBooks = xlApp.Workbooks
            xlApp.EnableEvents = False
            xlBook = xlBooks.Open(strStdExcelFileName)
            xlApp.EnableEvents = True
            xlSheets = xlBook.Worksheets

            'EXCEL開始年書き込み
            xlSheet = xlSheets.Item(STR_SHEETNAME_SETTING)
            xlCell = xlSheet.Range("F3")
            xlCell.Value = strExcelStart
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            '年額展開の年度書き込み
            For intCnt1 = 1 To 20
                strOutputYear = strOutputYear & (Integer.Parse(strExcelStart) + (intCnt1 - 1)).ToString & vbTab
                For intCnt2 = 1 To 12
                    If intCnt2 = 1 Then
                        strOutputMonthlyYear = strOutputMonthlyYear & (Integer.Parse(strExcelStart) + (intCnt1 - 1)).ToString
                    End If
                    strOutputMonthlyYear = strOutputMonthlyYear & vbTab
                    strOutputMonth = strOutputMonth & (Integer.Parse(strExcelStart) + (intCnt1 - 1)).ToString & "/" & intCnt2.ToString & "/1" & vbTab
                    strWork = (Integer.Parse(strExcelStart) + (intCnt1 - 1)).ToString("00") & intCnt2.ToString("00")
                    If Integer.Parse(strWork) >= Integer.Parse(strContractStart) And Integer.Parse(strWork) <= Integer.Parse(strContractEnd) Then
                        strOutputTerm = strOutputTerm & "契約期間内" & vbTab
                    ElseIf Integer.Parse(strWork) > Integer.Parse(CommonVariable.ContractEnd.ToString("yyyyMM")) Then
                        strOutputTerm = strOutputTerm & "契約期間外" & vbTab
                    Else
                        strOutputTerm = strOutputTerm & "" & vbTab
                    End If
                Next
            Next
            xlSheet = xlSheets.Item(STR_SHEETNAME_TEMPLATE)
            '年額展開（年）
            Clipboard.Clear()
            Clipboard.SetText(strOutputYear)
            xlCell = xlSheet.Range("CS8")
            xlCell.PasteSpecial()
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            '月額展開（契約期間内外）
            Clipboard.Clear()
            Clipboard.SetText(strOutputTerm)
            xlCell = xlSheet.Range("DN6")
            xlCell.PasteSpecial()
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            '月額展開（年）
            Clipboard.Clear()
            Clipboard.SetText(strOutputMonthlyYear)
            xlCell = xlSheet.Range("DN7")
            xlCell.PasteSpecial()
            '月額展開（年月）
            Clipboard.Clear()
            Clipboard.SetText(strOutputMonth)
            xlCell = xlSheet.Range("DN8")
            xlCell.PasteSpecial()
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            xlSheet = xlSheets.Item(STR_SHEETNAME_SETTING)
            xlSheet.Activate()

            xlBook.Save()

            OpenStdExcelPs = True

        Catch ex As Exception
            strMsg = ex.Message.ToString & "(OpenStdExcelPs)"

        Finally
            ''エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBook) = False Then
                xlBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlBooks, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            ''ガベージコレクトの起動
            GC.Collect()
        End Try

    End Function

    ''' <summary>
    ''' 機　能：Paymentデータ出力
    ''' 説　明：
    ''' </summary>
    ''' <param name="con"></param>
    ''' <param name="strStdExcelFileName"></param>
    ''' <param name="strNewStdExcelFileName"></param>
    ''' <param name="strMsg"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function OutputDataPs(ByVal con As OleDbConnection,
                                  ByVal strStdExcelFileName As String,
                                  ByRef strNewStdExcelFileName As String,
                                  ByVal strCsvPath As String,
                                  ByVal strCreateDate As String,
                                  ByRef strMsg As String) As Boolean

        Dim blnRet As Boolean
        Dim strSelectSQL As String
        Dim strYear() As String                 '年額展開の年度
        Dim strMonth() As String                '月額展開の年度
        Dim intDataType() As Integer
        Dim strWork As String
        Dim intRecCnt As Integer = 0
        Dim strNewPath As String

        'Excelオブジェクト
        Dim xlApp As Excel.Application = Nothing
        Dim xlBooks As Excel.Workbooks = Nothing
        Dim xlBook As Excel.Workbook = Nothing
        Dim xlSheet As Excel.Worksheet = Nothing
        Dim xlSheets As Excel.Sheets = Nothing
        Dim xlCell As Excel.Range = Nothing
        Dim xlRange As Excel.Range = Nothing
        Dim xlNewBook As Excel.Workbook = Nothing
        Dim xlNewSheets As Excel.Sheets = Nothing
        Dim xlNewSheet As Excel.Worksheet = Nothing

        OutputDataPs = False

        Try
            'EXCEL OPEN
            xlApp = New Excel.Application
            xlApp.DisplayAlerts = False
            xlBooks = xlApp.Workbooks
            xlApp.EnableEvents = False
            xlBook = xlBooks.Open(strStdExcelFileName)
            xlApp.EnableEvents = True
            xlSheets = xlBook.Worksheets

            '状態取得
            xlSheet = xlSheets.Item(STR_SHEETNAME_SETTING)
            xlCell = xlSheet.Range("F4")
            strWork = xlCell.Value
            If strWork <> "OK" Then
                strMsg = "表示設定シートのチェック状態が「OK」ではありません。"
                Exit Function
            End If
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            'IMAGEを新しいBookにコピー
            xlNewBook = xlBooks.Add()
            xlNewSheets = xlNewBook.Sheets
            xlSheet = xlSheets.Item(STR_SHEETNAME_IMAGE)
            xlSheet.Copy(Before:=xlNewSheets.Item(1))
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            '出力情報シートからデータを取得
            xlSheet = xlSheets.Item(STR_SHEETNAME_OUTPUTINFO)
            blnRet = GetOutputInfo(xlSheet, strSelectSQL, strYear, strMonth, intDataType, strMsg)
            If blnRet = False Then
                Exit Function
            End If
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            'データ件数取得
            blnRet = GetDbDataCnt(con, strSelectSQL, intRecCnt, strMsg)
            If blnRet = False Then
                Exit Function
            End If

            xlNewSheet = xlNewSheets.Item(STR_SHEETNAME_IMAGE)
            xlNewSheet.Name = ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET

            '罫線
            Dim intSho As Integer = intRecCnt \ DIVISION_LINES
            Dim intAmari As Integer = intRecCnt Mod DIVISION_LINES
            Dim strRange As String
            Dim intCnt As Integer

            For intCnt = 1 To intSho
                xlCell = xlNewSheet.Range(ROW_DATA_START.ToString & ":" & ROW_DATA_START.ToString)
                xlCell.Copy()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                strRange = (ROW_DATA_START + (intCnt - 1) * DIVISION_LINES).ToString() & ":" & (ROW_DATA_START - 1 + intCnt * DIVISION_LINES).ToString()
                Debug.Print(strRange)
                xlCell = xlNewSheet.Range(strRange)
                xlCell.PasteSpecial(Excel.XlPasteType.xlPasteFormats)
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            Next
            If intAmari <> 0 Then
                xlCell = xlNewSheet.Range(ROW_DATA_START.ToString & ":" & ROW_DATA_START.ToString)
                xlCell.Copy()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                strRange = (ROW_DATA_START + (intSho * DIVISION_LINES)).ToString() & ":" & (ROW_DATA_START + 1 + (intSho * DIVISION_LINES + intAmari) - 1).ToString()
                Debug.Print(strRange)
                xlCell = xlNewSheet.Range(strRange)
                xlCell.PasteSpecial(Excel.XlPasteType.xlPasteFormats)
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            End If

            'データ出力
            If intRecCnt > 0 Then
                blnRet = DbToExcelPs(con,
                                     strCsvPath,
                                     strCreateDate,
                                     xlNewSheet,
                                     strSelectSQL,
                                     strYear,
                                     strMonth,
                                     intDataType,
                                     strMsg)
                If blnRet = False Then
                    Exit Function
                End If
            End If

            'ダミー行削除
            xlCell = xlNewSheet.Range((intRecCnt + ROW_DATA_START).ToString & ":" & (intRecCnt + ROW_DATA_START).ToString)
            xlCell.Delete()
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            '空白シート削除
            For Each xlNewSheet In xlNewSheets
                If xlNewSheet.Name <> ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET And
                    xlNewSheet.Name <> ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET Then
                    xlNewSheet.Delete()
                End If
                ExcelObjRelease.ReleaseExcelObj(xlNewSheet, ExcelObjRelease.OBJECT_NOTHING)
            Next

            'EXCEL保存
            strNewPath = FileManager.GetLocalFolderPath("Bat_Output\EXCEL\StandardReport\Report")
            strNewStdExcelFileName = strNewPath & _
                                        "標準帳表PS(" & _
                                        CommonVariable.CPNO & _
                                        "(" & _
                                        CommonVariable.CUSTOMERNAME & _
                                        ")_" & _
                                        Format(Now, "yyyyMMdd_HHmmss") & ".xlsm"
            xlNewBook.CheckCompatibility = False
            xlNewBook.SaveAs(strNewStdExcelFileName, Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)

            OutputDataPs = True

        Catch ex As Exception
            strMsg = ex.Message.ToString & "(OutputDataPs)"

        Finally
            ''エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlNewSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlNewSheets, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlNewBook) = False Then
                xlNewBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlNewBook, ExcelObjRelease.OBJECT_NOTHING)

            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBook) = False Then
                xlBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlBooks, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            ''ガベージコレクトの起動
            GC.Collect()
        End Try

    End Function

    ''' <summary>
    ''' 機　能：詳細データ出力
    ''' </summary>
    ''' <param name="con"></param>
    ''' <param name="strStdExcelFileName"></param>
    ''' <param name="strCsvPath"></param>
    ''' <param name="strCreateDate"></param>
    ''' <param name="strMsg"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function OutputDataDetail(ByVal con As OleDbConnection,
                                      ByVal strStdExcelFileName As String,
                                      ByVal strCsvPath As String,
                                      ByVal strCreateDate As String,
                                      ByRef strMsg As String) As Boolean

        Const COL_MAX As Integer = 33

        Dim blnRet As Boolean
        Dim strCsvFileNamePsd As String

        'Excelオブジェクト
        Dim xlApp As Excel.Application = Nothing
        Dim xlBooks As Excel.Workbooks = Nothing
        Dim xlBook As Excel.Workbook = Nothing
        Dim xlSheet As Excel.Worksheet = Nothing
        Dim xlSheets As Excel.Sheets = Nothing
        Dim xlTmpBook As Excel.Workbook = Nothing
        Dim xlTmpSheets As Excel.Sheets = Nothing
        Dim xlTmpSheet As Excel.Worksheet = Nothing
        Dim xlNames As Excel.Names = Nothing
        Dim xlName As Excel.Name = Nothing

        OutputDataDetail = False

        Try
            'EXCEL OPEN
            xlApp = New Excel.Application
            xlApp.DisplayAlerts = False
            xlBooks = xlApp.Workbooks
            xlApp.EnableEvents = False
            xlBook = xlBooks.Open(strStdExcelFileName)
            xlSheets = xlBook.Worksheets

            'Templateの詳細シートをコピー
            Dim ofm As New OioFileManage
            Dim strTmpExcelFileName As String = ofm.GetLocalTemplateFolder
            strTmpExcelFileName = strTmpExcelFileName & CommonConstant.FILENAME_XLS_PAYMENTSAMPLE
            xlTmpBook = xlBooks.Open(strTmpExcelFileName)
            xlTmpSheets = xlTmpBook.Worksheets
            xlTmpSheet = xlTmpSheets.Item(STR_SHEETNAME_DETAIL)
            xlTmpSheet.Copy(After:=xlSheets.Item(1))
            ExcelObjRelease.ReleaseExcelObj(xlTmpSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlTmpSheets, ExcelObjRelease.OBJECT_NOTHING)
            xlTmpBook.Close(False)
            ExcelObjRelease.ReleaseExcelObj(xlTmpBook, ExcelObjRelease.OBJECT_NOTHING)
            xlApp.EnableEvents = True

            'ﾃﾞｰﾀ出力
            strCsvFileNamePsd = strCsvPath & "WorkCsv_StandardDataPsd_" & strCreateDate & ".csv"
            xlSheet = xlSheets.Item(ExcelWrite.EXCEL_PAYMENTLINEDATE_DETAILSHEET)
            blnRet = OutputSubmittedDataPsd(con, strCsvFileNamePsd, xlSheet, strMsg)
            If blnRet = False Then
                Exit Function
            End If
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            '名前定義削除
            xlNames = xlBook.Names
            For Each xlName In xlNames
                xlName.Delete()
                ExcelObjRelease.ReleaseExcelObj(xlName, ExcelObjRelease.OBJECT_NOTHING)
            Next
            ExcelObjRelease.ReleaseExcelObj(xlNames, ExcelObjRelease.OBJECT_NOTHING)

            'EXCEL保存
            xlBook.Save()

            OutputDataDetail = True

        Catch ex As Exception
            strMsg = ex.Message.ToString & "(OutputDataDetail)"

        Finally
            ''エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlTmpSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlTmpSheets, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlTmpBook) = False Then
                xlTmpBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlTmpBook, ExcelObjRelease.OBJECT_NOTHING)

            ExcelObjRelease.ReleaseExcelObj(xlName, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlNames, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheets, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBook) = False Then
                xlBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlBooks, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

            ''ガベージコレクトの起動
            GC.Collect()
        End Try

    End Function

    Private Function OutputSubmittedDataPs(ByVal intImportCd As Integer,
                                           ByVal con As OleDbConnection,
                                           ByVal strCsvFileName() As String,
                                           ByVal strExcelStart As String,
                                           ByVal dtOutputDate As Date,
                                           ByVal intPaymentPeriod As Integer,
                                           ByRef xlSheet As Excel.Worksheet,
                                           ByRef strMsg As String) As Boolean

        Dim blnRet As Boolean
        Dim strSelectSQL(5) As String
        Dim strYear() As String                 '年額展開の年度
        Dim strMonth() As String                '月額展開の年度
        Dim strWork As String
        Dim intRecCnt As Integer = 0
        Dim strNewPath As String
        Dim strInstDate As String
        Dim intCnt As Integer
        Dim strStartRange() As String = {"A6", "CS6", "DC6", "DN6", "ID6"}
        Dim intDataTypeWk(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12 - 1) As Integer
        Dim intStartEnd(,) As Integer = {
                                         {(ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG - 1), (ExcelWrite.ExcelPaymentLineColumn.PRICE_DEFF_IGF - 1)},
                                         {(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1 - 1), (ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10 - 1)},
                                         {(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11 - 1), (ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL - 1)},
                                         {(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1 - 1), (ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR10_MONTH12 - 1)},
                                         {(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR11_MONTH1 - 1), (ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR20_MONTH12 - 1)}
                                        }

        'Excelオブジェクト
        Dim xlCell As Excel.Range = Nothing
        Dim xlRange As Excel.Range = Nothing

        OutputSubmittedDataPs = False

        Try
            '--------------------------------------------------------
            'データ件数取得
            '--------------------------------------------------------
            Select Case intImportCd
                Case CD_STROUT_DATA_ALL
                    strSelectSQL(IDX_WORK_PS1) = "PSALL_STD_TBL1TBL2"
                    strSelectSQL(IDX_WORK_PS2) = "PSALL_STD_YEAR1"
                    strSelectSQL(IDX_WORK_PS3) = "PSALL_STD_YEAR2"
                    strSelectSQL(IDX_WORK_PS4) = "PSALL_STD_MONTH1"
                    strSelectSQL(IDX_WORK_PS5) = "PSALL_STD_MONTH2"
                    strInstDate = ""
                Case CD_STROUT_DATA_DEL
                    strSelectSQL(IDX_WORK_PS1) = "PSDEL_STD_TBL1TBL2"
                    strSelectSQL(IDX_WORK_PS2) = "PSDEL_STD_YEAR1"
                    strSelectSQL(IDX_WORK_PS3) = "PSDEL_STD_YEAR2"
                    strSelectSQL(IDX_WORK_PS4) = "PSDEL_STD_MONTH1"
                    strSelectSQL(IDX_WORK_PS5) = "PSDEL_STD_MONTH2"
                    strInstDate = dtOutputDate.AddMonths(-3).ToString("yyyy/MM/dd")
            End Select
            blnRet = GetDbDataCnt(con, strSelectSQL(IDX_WORK_PS1), intRecCnt, strMsg, strInstDate)
            If blnRet = False Then
                Exit Function
            End If
            If intRecCnt = 0 Then
                OutputSubmittedDataPs = True
                Exit Function
            End If

            '--------------------------------------------------------
            '罫線
            '--------------------------------------------------------
            Dim intSho As Integer = intRecCnt \ DIVISION_LINES
            Dim intAmari As Integer = intRecCnt Mod DIVISION_LINES
            Dim strRange As String

            For intCnt = 1 To intSho
                xlCell = xlSheet.Range(ROW_SAMPLE_PAYMENT)
                xlCell.Copy()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                strRange = (ROW_DATA_START + (intCnt - 1) * DIVISION_LINES).ToString() & ":" & (ROW_DATA_START - 1 + intCnt * DIVISION_LINES).ToString()
                Debug.Print(strRange)
                xlCell = xlSheet.Range(strRange)
                xlCell.PasteSpecial(Excel.XlPasteType.xlPasteFormats)
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            Next
            If intAmari <> 0 Then
                xlCell = xlSheet.Range(ROW_SAMPLE_PAYMENT)
                xlCell.Copy()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                strRange = (ROW_DATA_START + (intSho * DIVISION_LINES)).ToString() & ":" & (ROW_DATA_START + (intSho * DIVISION_LINES + intAmari) - 1).ToString()
                Debug.Print(strRange)
                xlCell = xlSheet.Range(strRange)
                xlCell.PasteSpecial(Excel.XlPasteType.xlPasteFormats)
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            End If

            '--------------------------------------------------------
            'データ出力
            '--------------------------------------------------------
            Call ExcelWrite.SetExcelDataTypePayment(intDataTypeWk)
            For intCnt = IDX_WORK_PS1 To IDX_WORK_PS5
                '中間ﾌｧｲﾙ作成
                If intCnt = IDX_WORK_PS1 Then
                    blnRet = CreateWorkFile(con, strSelectSQL(intCnt), strCsvFileName(intCnt), strMsg, "", strInstDate)
                Else
                    blnRet = CreateWorkFile(con, strSelectSQL(intCnt), strCsvFileName(intCnt), strMsg, strExcelStart, strInstDate)
                End If
                If blnRet = False Then
                    Exit Function
                End If
                'Paymentに中間ﾌｧｲﾙを出力
                Dim intDataType() As Integer
                Dim intIdx As Integer = 0
                Erase intDataType
                ReDim intDataType(intStartEnd(intCnt, 1) - intStartEnd(intCnt, 0))
                For intColCnt As Integer = intStartEnd(intCnt, 0) To intStartEnd(intCnt, 1)
                    intDataType(intIdx) = intDataTypeWk(intColCnt)
                    intIdx = intIdx + 1
                Next
                Call ExcelWrite.LoadCsvToExcel(strCsvFileName(intCnt), 1, "Payment", strStartRange(intCnt), xlSheet, intDataType)
            Next

            '--------------------------------------------------------
            '総合計金額出力
            '--------------------------------------------------------
            If intImportCd = CD_STROUT_DATA_ALL Then
                blnRet = CreateTotalRow(intRecCnt, 20, xlSheet, strMsg)
                If blnRet = False Then
                    Exit Function
                End If
            End If

            '--------------------------------------------------------
            'Payment展開期間分列削除
            '--------------------------------------------------------
            Call ExcelWrite.CreatePaymentPeriod(xlSheet,
                                                ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1),
                                                intPaymentPeriod)


            OutputSubmittedDataPs = True

        Catch ex As Exception
            strMsg = ex.Message.ToString & "(OutputSubmittedDataPs)"

        Finally
            ''エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            ''ガベージコレクトの起動
            GC.Collect()
        End Try

    End Function

    ''' <summary>
    ''' 機　能：詳細データ出力
    ''' </summary>
    ''' <param name="con"></param>
    ''' <param name="strCsvFileName"></param>
    ''' <param name="xlSheet"></param>
    ''' <param name="strMsg"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function OutputSubmittedDataPsd(ByVal con As OleDbConnection,
                                            ByVal strCsvFileName As String,
                                            ByRef xlSheet As Excel.Worksheet,
                                            ByRef strMsg As String) As Boolean

        Dim blnRet As Boolean
        Dim intRecCnt As Integer = 0
        Dim intDataType(ExcelWrite.ExcelPaymentLineDetailColumn.MA_EXT_SCALE - 1) As Integer

        'Excelオブジェクト
        Dim xlCell As Excel.Range = Nothing
        Dim xlRange As Excel.Range = Nothing

        OutputSubmittedDataPsd = False

        Try
            '--------------------------------------------------------
            'データ件数取得
            '--------------------------------------------------------
            blnRet = GetDbDataCnt(con, "PSDALL_STD", intRecCnt, strMsg)
            If blnRet = False Then
                Exit Function
            End If
            If intRecCnt = 0 Then
                OutputSubmittedDataPsd = True
                Exit Function
            End If

            '--------------------------------------------------------
            '罫線
            '--------------------------------------------------------
            Dim intSho As Integer = intRecCnt \ DIVISION_LINES
            Dim intAmari As Integer = intRecCnt Mod DIVISION_LINES
            Dim strRange As String
            Dim intCnt As Integer

            For intCnt = 1 To intSho
                xlCell = xlSheet.Range(ROW_SAMPLE_DETAIL)
                xlCell.Copy()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                strRange = (ROW_DETAIL_DATA_START + (intCnt - 1) * DIVISION_LINES).ToString() & ":" & (ROW_DETAIL_DATA_START - 1 + intCnt * DIVISION_LINES).ToString()
                Debug.Print(strRange)
                xlCell = xlSheet.Range(strRange)
                xlCell.PasteSpecial(Excel.XlPasteType.xlPasteFormats)
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            Next
            If intAmari <> 0 Then
                xlCell = xlSheet.Range(ROW_SAMPLE_DETAIL)
                xlCell.Copy()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                strRange = (ROW_DETAIL_DATA_START + (intSho * DIVISION_LINES)).ToString() & ":" & (ROW_DETAIL_DATA_START + (intSho * DIVISION_LINES + intAmari) - 1).ToString()
                Debug.Print(strRange)
                xlCell = xlSheet.Range(strRange)
                xlCell.PasteSpecial(Excel.XlPasteType.xlPasteFormats)
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            End If

            '--------------------------------------------------------
            'データ出力
            '--------------------------------------------------------
            '中間ﾌｧｲﾙ作成
            blnRet = CreateWorkFile(con, "PSDALL_STD", strCsvFileName, strMsg)
            If blnRet = False Then
                Exit Function
            End If
            'Paymentに中間ﾌｧｲﾙを出力
            Call ExcelWrite.SetExcelDataTypeDetail(intDataType)
            Call ExcelWrite.LoadCsvToExcel(strCsvFileName, 1, "詳細", "A7", xlSheet, intDataType)

            OutputSubmittedDataPsd = True

        Catch ex As Exception
            strMsg = ex.Message.ToString & "(OutputSubmittedDataPsd)"

        Finally
            ''エクセルオブジェクトの解放

            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            ''ガベージコレクトの起動
            GC.Collect()
        End Try

    End Function

    ''' <summary>
    ''' 機　能：出力情報シートデータ取得
    ''' 説　明：
    ''' </summary>
    ''' <param name="xlSheet"></param>
    ''' <param name="strSQL"></param>
    ''' <param name="strYear"></param>
    ''' <param name="strMonth"></param>
    ''' <param name="intDataType"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetOutputInfo(ByVal xlSheet As Excel.Worksheet,
                                   ByRef strSQL As String,
                                   ByRef strYear() As String,
                                   ByRef strMonth() As String,
                                   ByRef intDataType() As Integer,
                                   ByRef strMsg As String) As Boolean

        Const CD_ROW_MAX As Integer = 1000
        Const CD_COL_NO As Integer = 1
        Const CD_COL_SQL As Integer = 2
        Const CD_COL_YEAR As Integer = 3
        Const CD_COL_MONTH As Integer = 4
        Const CD_COL_DATATYPE As Integer = 5

        Dim objExcel(CD_ROW_MAX, 5) As Object
        Dim blnRet As Boolean
        Dim intCnt As Integer
        Dim intIdxYear As Integer = 0
        Dim intIdxMonth As Integer = 0
        Dim intIdxDataType As Integer = -1
        Dim strWork As String

        GetOutputInfo = False

        Try
            '出力情報シートからデータを取得
            blnRet = GetCellValue(xlSheet, "A2:E1000", objExcel, strMsg)
            If blnRet = False Then
                Exit Function
            End If

            'SQL取得
            strSQL = ""
            For intCnt = 1 To CD_ROW_MAX
                strWork = CheckNothingData(objExcel(intCnt, CD_COL_SQL))
                If strWork.Trim = "" Then
                    Exit For
                End If
                strSQL = strSQL & strWork & vbCrLf
            Next
            Debug.Print(strSQL)

            '年額展開の年度取得
            ReDim strYear(intIdxYear)
            intIdxYear = intIdxYear + 1
            For intCnt = 1 To CD_ROW_MAX
                strWork = CheckNothingData(objExcel(intCnt, CD_COL_YEAR))
                If strWork.Trim = "" Then
                    Exit For
                End If
                ReDim Preserve strYear(intIdxYear)
                strYear(intIdxYear) = strWork
                intIdxYear = intIdxYear + 1
            Next

            '月額展開の年度取得
            ReDim strMonth(intIdxMonth)
            intIdxMonth = intIdxMonth + 1
            For intCnt = 1 To CD_ROW_MAX
                strWork = CheckNothingData(objExcel(intCnt, CD_COL_MONTH))
                If strWork.Trim = "" Then
                    Exit For
                End If
                ReDim Preserve strMonth(intIdxMonth)
                strMonth(intIdxMonth) = strWork
                intIdxMonth = intIdxMonth + 1
            Next

            For intCnt = 1 To CD_ROW_MAX
                strWork = CheckNothingData(objExcel(intCnt, CD_COL_DATATYPE))
                If strWork.Trim = "" Then
                    Exit For
                End If
                intIdxDataType = intIdxDataType + 1
                ReDim Preserve intDataType(intIdxDataType)
                intDataType(intIdxDataType) = strWork
            Next

            GetOutputInfo = True

        Catch ex As Exception
            strMsg = ex.Message.ToString & "(GetOutputInfo)"

        End Try

    End Function

    ''' <summary>
    ''' 機　能：セル値取得
    ''' 説　明：
    ''' </summary>
    ''' <param name="xlSheet"></param>
    ''' <param name="strRange"></param>
    ''' <param name="ExcelData"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetCellValue(ByVal xlSheet As Excel.Worksheet, ByVal strRange As String, ByRef ExcelData(,) As Object, ByRef strMsg As String) As Boolean

        Dim xlCell As Excel.Range = Nothing

        GetCellValue = False

        Try
            xlCell = xlSheet.Range(strRange)
            ExcelData = xlCell.Value

            GetCellValue = True

        Catch ex As Exception
            strMsg = ex.Message.ToString & "(GetCellValue)"

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Function

    ''' <summary>
    ''' 機　能：データ(Nothing)をチェックする
    ''' 説　明：
    ''' </summary>
    ''' <param name="objData"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckNothingData(ByVal objData As Object) As String

        CheckNothingData = ""

        If IsNothing(objData) = False Then
            CheckNothingData = objData.ToString.Replace(vbLf, "")
        End If

    End Function

    ''' <summary>
    ''' 機　能：Paymentデータ出力
    ''' 説　明：
    ''' </summary>
    ''' <param name="con"></param>
    ''' <param name="strCsvPath"></param>
    ''' <param name="strCreateDate"></param>
    ''' <param name="xlSheet"></param>
    ''' <param name="strSQL"></param>
    ''' <param name="strYear"></param>
    ''' <param name="strMonth"></param>
    ''' <param name="intDataType"></param>
    ''' <param name="strMsg"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function DbToExcelPs(ByVal con As OleDbConnection,
                                 ByVal strCsvPath As String,
                                 ByVal strCreateDate As String,
                                 ByVal xlSheet As Excel.Worksheet,
                                 ByVal strSQL As String,
                                 ByVal strYear() As String,
                                 ByVal strMonth() As String,
                                 ByVal intDataType() As Integer,
                                 ByRef strMsg As String) As Boolean

        Dim cmd As New OleDbCommand
        Dim dr As OleDbDataReader
        Dim strOutput As String = ""
        Dim intFldCnt As Integer
        Dim strFldName As String
        Dim strIdValue As String
        Dim strYearSelectSQL As String
        Dim strMonthSelectSQL As String
        Dim intYearCnt As Integer
        Dim intMonthCnt As Integer
        Dim cmdPt3 As New OleDbCommand
        Dim drPt3 As OleDbDataReader
        Dim intCnt As Integer
        Dim intTotalCnt As Integer = 0
        Dim strWork As String
        Dim strRange As String
        Dim xlCell As Excel.Range = Nothing

        Dim sw As StreamWriter
        Dim strFileName As String
        Dim blnPastPriceTotal As Boolean = False
        Dim strPastPriceTotal As String = ""

        DbToExcelPs = False

        Try
            cmd.Connection = con
            cmd.CommandText = strSQL
            dr = cmd.ExecuteReader

            '中間ﾌｧｲﾙ作成
            strFileName = strCsvPath & "WorkCsv_StandardDataPs_" & strCreateDate & ".csv"
            sw = New StreamWriter(strFileName, False, System.Text.Encoding.Default)
            While dr.Read = True
                strOutput = ""
                '年額月額展開以外の項目
                For intFldCnt = 0 To (dr.FieldCount - 1)
                    strFldName = dr.GetName(intFldCnt)
                    If strFldName = "ID" Then
                        strIdValue = GetDbData(dr, strFldName)
                    ElseIf strFldName = "PAST_PRICE_TOTAL" Then
                        blnPastPriceTotal = True
                        strPastPriceTotal = GetDbData(dr, strFldName)
                    Else
                        strWork = GetDbData(dr, strFldName)
                        strWork = strWork.Replace("""", """""")
                        strOutput = strOutput & """" & strWork & ""","
                    End If
                Next

                '年額展開
                cmdPt3.Connection = con
                If strYear.Length > 0 Then
                    For intYearCnt = 1 To (strYear.Length - 1)
                        strYearSelectSQL = "SELECT * FROM PaymentTBL3 WHERE ID='" & strIdValue & "' AND IOC_YEAER='" & strYear(intYearCnt) & "'"
                        cmdPt3.CommandText = strYearSelectSQL
                        drPt3 = cmdPt3.ExecuteReader
                        drPt3.Read()
                        strWork = GetDbData(drPt3, "IOC_YYYY")
                        strWork = strWork.Replace("""", """""")
                        strOutput = strOutput & """" & strWork & ""","
                        drPt3.Close()
                    Next
                End If

                '過去金額
                If blnPastPriceTotal = True Then
                    strOutput = strOutput & """" & strPastPriceTotal & ""","
                End If

                '月額展開
                If strMonth.Length > 0 Then
                    For intMonthCnt = 1 To (strMonth.Length - 1)
                        strMonthSelectSQL = "SELECT * FROM PaymentTBL3 WHERE ID='" & strIdValue & "' AND IOC_YEAER='" & strMonth(intMonthCnt) & "'"
                        cmdPt3.CommandText = strMonthSelectSQL
                        drPt3 = cmdPt3.ExecuteReader
                        drPt3.Read()
                        For intCnt = 1 To 12
                            strWork = GetDbData(drPt3, "IOC_" & intCnt.ToString("00"))
                            strWork = strWork.Replace("""", """""")
                            strOutput = strOutput & """" & strWork & ""","
                        Next
                        drPt3.Close()
                    Next
                End If

                sw.WriteLine(strOutput)
            End While
            sw.Close()

            'Paymentに中間ﾌｧｲﾙを出力
            Call ExcelWrite.LoadCsvToExcel(strFileName, 1, "Payment", "A6", xlSheet, intDataType)

            DbToExcelPs = True

        Catch ex As Exception
            strMsg = ex.Message.ToString & "(DbToExcelPs)"

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            cmdPt3.Dispose()
            cmd.Dispose()

        End Try

    End Function

    ''' <summary>
    ''' 機　能：Null値変換
    ''' 概　要：Null値の場合、空文字に変換
    ''' </summary>
    ''' <param name="drData"></param>
    ''' <param name="strFieldName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetDbData(ByVal drData As OleDbDataReader, ByVal strFieldName As String) As String

        GetDbData = ""

        Try
            If IsDBNull(drData.Item(strFieldName)) = True Then
                GetDbData = ""
            Else
                GetDbData = drData.Item(strFieldName)
            End If

        Catch ex As Exception
            Throw ex
        End Try

    End Function

    ''' <summary>
    ''' 機　能：DBのデータ数取得
    ''' </summary>
    ''' <param name="con"></param>
    ''' <param name="strSQL"></param>
    ''' <param name="intRecCnt"></param>
    ''' <param name="strMsg"></param>
    ''' <param name="strInstDate"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetDbDataCnt(ByVal con As OleDbConnection,
                                  ByVal strSQL As String,
                                  ByRef intRecCnt As Integer,
                                  ByRef strMsg As String,
                                  Optional ByVal strInstDate As String = "") As Boolean

        Dim cmd As New OleDbCommand
        Dim dt As New DataTable
        Dim da As New OleDbDataAdapter

        GetDbDataCnt = False

        Try
            cmd.Connection = con
            cmd.CommandText = strSQL
            If strSQL.IndexOf("SELECT") = -1 Then
                cmd.CommandType = CommandType.StoredProcedure
                If strInstDate <> "" Then
                    cmd.Parameters.Add("@2", strInstDate)
                End If
            End If
            da.SelectCommand = cmd
            da.Fill(dt)
            intRecCnt = dt.Rows.Count

            GetDbDataCnt = True

        Catch ex As Exception
            strMsg = ex.Message.ToString & "(GetDbDataCnt)"

        Finally
            dt.Dispose()
            cmd.Dispose()

        End Try

    End Function

    Private Function CreateWorkFile(ByVal con As OleDbConnection,
                                    ByVal strSQL As String, ByVal strCsvFileName As String,
                                    ByRef strMsg As String,
                                    Optional ByVal strExcelStart As String = "",
                                    Optional ByVal strInstDate As String = "") As Boolean

        Dim sw As StreamWriter
        Dim strOutput As String
        Dim intFldCnt As Integer
        Dim intFldMax As Integer
        Dim cmd As New OleDbCommand
        Dim adpt As OleDbDataAdapter
        Dim dt As New DataTable
        Dim strWork As String

        CreateWorkFile = False

        Try
            'クエリでデータ取得
            cmd.Connection = con
            cmd.CommandText = strSQL
            If strSQL.ToUpper.IndexOf("SELECT") = -1 Then
                cmd.CommandType = CommandType.StoredProcedure
                If strExcelStart <> "" Then
                    cmd.Parameters.Add("@1", strExcelStart)
                End If
                If strInstDate <> "" Then
                    cmd.Parameters.Add("@2", strInstDate)
                End If
            End If
            adpt = New OleDbDataAdapter(cmd)
            adpt.Fill(dt)

            '中間ファイル作成
            intFldMax = dt.Columns.Count
            sw = New StreamWriter(strCsvFileName, False, System.Text.Encoding.Default)
            For Each row As DataRow In dt.Select()
                strOutput = ""
                For intFldCnt = 1 To intFldMax
                    strWork = row.Item("CellNM" & intFldCnt.ToString)
                    strWork = strWork.Replace("""", """""")
                    strOutput = strOutput & """" & strWork & ""","
                Next
                sw.WriteLine(strOutput)
            Next
            sw.Close()

            CreateWorkFile = True

        Catch ex As Exception
            strMsg = ex.Message.ToString & "(CreateWorkFile)"

        End Try

    End Function

    Private Function CreateTotalRow(ByVal intRecCnt As Integer,
                                    ByVal intIocYear As Integer,
                                    ByRef xlSheet As Excel.Worksheet,
                                    ByRef strMsg As String) As Boolean

        Dim objData() As Object
        Dim intCol As Integer
        Dim intCnt As Integer
        Dim strColName As String
        Dim strStart As String
        Dim strEnd As String
        Dim xlRange As Excel.Range
        Dim xlBorders As Excel.Borders

        Const COL_START As String = "CK"        '名称からの位置

        CreateTotalRow = False

        Try
            '列名を列番号に変換
            intCol = ExcelWrite.GetColumnNoFromColumnName(COL_START) + 1
            '月額展開（intIocYear * 12）＋期間合計（7）+年額展開（intIocYear）＋名称（1）＋過去の合計金額（1）
            ReDim objData(intIocYear * 12 + 7 + intIocYear + 1 + 1)
            objData(0) = "総合計"
            For intCnt = 1 To (intIocYear * 12 + intIocYear + 7 + 1)
                '列番号を列名に変換
                strColName = ExcelWrite.chgExcelColumnIdxToChar(intCol)
                strStart = strColName & ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW.ToString
                strEnd = strColName & (ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + intRecCnt - 1).ToString
                objData(intCnt) = "=SUM(" & strStart & ":" & strEnd & ")"
                intCol = intCol + 1
            Next

            'ﾃﾞｰﾀ貼付
            strStart = COL_START & (ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + intRecCnt + 1).ToString
            strEnd = strColName & (ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW + intRecCnt + 1).ToString
            xlRange = xlSheet.Range(strStart & ":" & strEnd)
            xlRange.Value = objData

            '罫線
            xlBorders = xlRange.Borders
            xlBorders.LineStyle = True

            CreateTotalRow = True

        Catch ex As Exception
            strMsg = ex.Message.ToString & "(CreateTotalRow)"
        Finally
            ExcelObjRelease.ReleaseExcelObj(xlBorders, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
        End Try

    End Function
#End Region

End Class
