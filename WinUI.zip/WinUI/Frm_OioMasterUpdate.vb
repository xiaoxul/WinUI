Imports System.Text
Imports System.IO
Imports System.Reflection
Imports MUSE.Utility
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.UserDataSet
Imports MUSE.Utility.UserDataTable.Master
Imports MUSE.Utility.UserDataTable.Transaction
Imports MUSE.Utility.UserDataTable.Work
Imports MUSE.Utility.UserMessageBox
Imports MUSE.Utility.UserException
Imports MUSE.Utility.XmlClass.Parameter
Imports MUSE.Utility.XmlClass.SystemInfo
Imports MUSE.Utility.XmlClass.ConnectionInfo
Imports MUSE.Controller

'==========================================================================
'�N���X���FFrm_MasterUpdate
'�T    �v�FFrm_MasterUpdate�N���X
'��    ���F�}�X�^�X�V���
'��    ���F[Ver1.0]  2008/09/08  �����@���K
'==========================================================================
Public Class Frm_OioMasterUpdate
    Inherits System.Windows.Forms.Form

#Region " Windows �t�H�[�� �f�U�C�i�Ő������ꂽ�R�[�h "

    Public Sub New()
        MyBase.New()

        ' ���̌Ăяo���� Windows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
        InitializeComponent()
        ' InitializeComponent() �Ăяo���̌�ɏ�������ǉ����܂��B

    End Sub

    ' Form �́A�R���|�[�l���g�ꗗ�Ɍ㏈�������s���邽�߂� dispose ���I�[�o�[���C�h���܂��B
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    ' Windows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
    Private components As System.ComponentModel.IContainer

    ' ���� : �ȉ��̃v���V�[�W���́AWindows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
    'Windows �t�H�[�� �f�U�C�i���g���ĕύX���Ă��������B  
    ' �R�[�h �G�f�B�^���g���ĕύX���Ȃ��ł��������B
    Friend WithEvents UCnt_Pal00011 As UserControl.UCnt_Pal0001
    Friend WithEvents UCnt_Btn00012 As UserControl.UCnt_Btn0001
    Friend WithEvents UCnt_Btn00013 As UserControl.UCnt_Btn0001
    Friend WithEvents UCnt_Pal00012 As UserControl.UCnt_Pal0001
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Cmb_MasterName As System.Windows.Forms.ComboBox
    Friend WithEvents Btn_Clear As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Update As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Grd_Master As System.Windows.Forms.DataGrid
    Friend WithEvents Btn_OutputCsv As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents lbl_MasterName As System.Windows.Forms.Label
    Friend WithEvents Lbl_RecCnt As System.Windows.Forms.Label
    Friend WithEvents Btn_ReadCsv As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_HolidayAdd As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Cal_Holiday As System.Windows.Forms.MonthCalendar
    Friend WithEvents Lbl_Holiday As System.Windows.Forms.Label
    Friend WithEvents Lbl_ServicePacComment As System.Windows.Forms.Label
    Friend WithEvents Grp_CsvSource As System.Windows.Forms.GroupBox
    Friend WithEvents Rdo_CsvSource_Muse As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_CsvSource_Web As System.Windows.Forms.RadioButton
    Friend WithEvents Grp_CsvReadType As System.Windows.Forms.GroupBox
    Friend WithEvents Rdo_CsvReadType_Diff As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_CsvReadType_All As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_CsvSource_Slk As System.Windows.Forms.RadioButton
    Friend WithEvents Btn_Serch As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Txt_SerchString As System.Windows.Forms.TextBox
    Friend WithEvents Cmb_SerchColumn As System.Windows.Forms.ComboBox
    Friend WithEvents Lbl_RecCnt_Tiltle As System.Windows.Forms.Label
    Friend WithEvents Btn_FirstRec As System.Windows.Forms.Button
    Friend WithEvents Btn_LastRec As System.Windows.Forms.Button
    Friend WithEvents Btn_Delete As System.Windows.Forms.Button
    Friend WithEvents Btn_ClearSort As System.Windows.Forms.Button
    Friend WithEvents chkOpenPrice As System.Windows.Forms.CheckBox
    Friend WithEvents Btn_LogOut As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents chk_Wcat As System.Windows.Forms.CheckBox
    Friend WithEvents Btn_GetData As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents lblNow As System.Windows.Forms.Label
    Friend WithEvents tmNow As System.Windows.Forms.Timer

    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lbl_MasterName = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Btn_GetData = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_ClearSort = New System.Windows.Forms.Button()
        Me.Btn_Delete = New System.Windows.Forms.Button()
        Me.Btn_LastRec = New System.Windows.Forms.Button()
        Me.Btn_FirstRec = New System.Windows.Forms.Button()
        Me.Lbl_Holiday = New System.Windows.Forms.Label()
        Me.Btn_HolidayAdd = New MUSE.UserControl.UCnt_Btn0001()
        Me.Cal_Holiday = New System.Windows.Forms.MonthCalendar()
        Me.Grd_Master = New System.Windows.Forms.DataGrid()
        Me.Btn_ReadCsv = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Clear = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_OutputCsv = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Update = New MUSE.UserControl.UCnt_Btn0001()
        Me.Grp_CsvSource = New System.Windows.Forms.GroupBox()
        Me.Rdo_CsvSource_Slk = New System.Windows.Forms.RadioButton()
        Me.Rdo_CsvSource_Muse = New System.Windows.Forms.RadioButton()
        Me.Rdo_CsvSource_Web = New System.Windows.Forms.RadioButton()
        Me.Grp_CsvReadType = New System.Windows.Forms.GroupBox()
        Me.Rdo_CsvReadType_Diff = New System.Windows.Forms.RadioButton()
        Me.Rdo_CsvReadType_All = New System.Windows.Forms.RadioButton()
        Me.Lbl_RecCnt = New System.Windows.Forms.Label()
        Me.Lbl_RecCnt_Tiltle = New System.Windows.Forms.Label()
        Me.Lbl_ServicePacComment = New System.Windows.Forms.Label()
        Me.Cmb_SerchColumn = New System.Windows.Forms.ComboBox()
        Me.Txt_SerchString = New System.Windows.Forms.TextBox()
        Me.Cmb_MasterName = New System.Windows.Forms.ComboBox()
        Me.UCnt_Pal00012 = New MUSE.UserControl.UCnt_Pal0001()
        Me.Btn_Serch = New MUSE.UserControl.UCnt_Btn0001()
        Me.chkOpenPrice = New System.Windows.Forms.CheckBox()
        Me.Btn_LogOut = New MUSE.UserControl.UCnt_Btn0001()
        Me.chk_Wcat = New System.Windows.Forms.CheckBox()
        Me.lblNow = New System.Windows.Forms.Label()
        Me.tmNow = New System.Windows.Forms.Timer(Me.components)
        Me.GroupBox3.SuspendLayout()
        CType(Me.Grd_Master, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Grp_CsvSource.SuspendLayout()
        Me.Grp_CsvReadType.SuspendLayout()
        Me.SuspendLayout()
        '
        'lbl_MasterName
        '
        Me.lbl_MasterName.Location = New System.Drawing.Point(52, 68)
        Me.lbl_MasterName.Name = "lbl_MasterName"
        Me.lbl_MasterName.Size = New System.Drawing.Size(80, 16)
        Me.lbl_MasterName.TabIndex = 62
        Me.lbl_MasterName.Text = "�X�V�}�X�^��"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Btn_GetData)
        Me.GroupBox3.Controls.Add(Me.Btn_ClearSort)
        Me.GroupBox3.Controls.Add(Me.Btn_Delete)
        Me.GroupBox3.Controls.Add(Me.Btn_LastRec)
        Me.GroupBox3.Controls.Add(Me.Btn_FirstRec)
        Me.GroupBox3.Controls.Add(Me.Lbl_Holiday)
        Me.GroupBox3.Controls.Add(Me.Btn_HolidayAdd)
        Me.GroupBox3.Controls.Add(Me.Cal_Holiday)
        Me.GroupBox3.Controls.Add(Me.Grd_Master)
        Me.GroupBox3.Controls.Add(Me.Btn_ReadCsv)
        Me.GroupBox3.Controls.Add(Me.Btn_Clear)
        Me.GroupBox3.Controls.Add(Me.Btn_OutputCsv)
        Me.GroupBox3.Controls.Add(Me.Btn_Update)
        Me.GroupBox3.Controls.Add(Me.Grp_CsvSource)
        Me.GroupBox3.Controls.Add(Me.Grp_CsvReadType)
        Me.GroupBox3.Controls.Add(Me.Lbl_RecCnt)
        Me.GroupBox3.Controls.Add(Me.Lbl_RecCnt_Tiltle)
        Me.GroupBox3.Controls.Add(Me.Lbl_ServicePacComment)
        Me.GroupBox3.Location = New System.Drawing.Point(52, 88)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(844, 488)
        Me.GroupBox3.TabIndex = 4
        Me.GroupBox3.TabStop = False
        '
        'Btn_GetData
        '
        Me.Btn_GetData.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_GetData.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_GetData.ForeColor = System.Drawing.Color.White
        Me.Btn_GetData.Location = New System.Drawing.Point(584, 400)
        Me.Btn_GetData.Name = "Btn_GetData"
        Me.Btn_GetData.Size = New System.Drawing.Size(112, 44)
        Me.Btn_GetData.TabIndex = 77
        Me.Btn_GetData.Text = "�f�[�^�擾"
        Me.Btn_GetData.UseVisualStyleBackColor = False
        '
        'Btn_ClearSort
        '
        Me.Btn_ClearSort.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Btn_ClearSort.Location = New System.Drawing.Point(68, 16)
        Me.Btn_ClearSort.Name = "Btn_ClearSort"
        Me.Btn_ClearSort.Size = New System.Drawing.Size(40, 20)
        Me.Btn_ClearSort.TabIndex = 76
        Me.Btn_ClearSort.TabStop = False
        Me.Btn_ClearSort.Text = "����"
        '
        'Btn_Delete
        '
        Me.Btn_Delete.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Btn_Delete.Location = New System.Drawing.Point(28, 16)
        Me.Btn_Delete.Name = "Btn_Delete"
        Me.Btn_Delete.Size = New System.Drawing.Size(40, 20)
        Me.Btn_Delete.TabIndex = 75
        Me.Btn_Delete.TabStop = False
        Me.Btn_Delete.Text = "�폜"
        '
        'Btn_LastRec
        '
        Me.Btn_LastRec.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Btn_LastRec.Location = New System.Drawing.Point(180, 400)
        Me.Btn_LastRec.Name = "Btn_LastRec"
        Me.Btn_LastRec.Size = New System.Drawing.Size(25, 17)
        Me.Btn_LastRec.TabIndex = 72
        Me.Btn_LastRec.TabStop = False
        Me.Btn_LastRec.Text = ">>"
        Me.Btn_LastRec.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Btn_FirstRec
        '
        Me.Btn_FirstRec.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Btn_FirstRec.Location = New System.Drawing.Point(156, 400)
        Me.Btn_FirstRec.Name = "Btn_FirstRec"
        Me.Btn_FirstRec.Size = New System.Drawing.Size(25, 17)
        Me.Btn_FirstRec.TabIndex = 71
        Me.Btn_FirstRec.TabStop = False
        Me.Btn_FirstRec.Text = "<<"
        Me.Btn_FirstRec.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Lbl_Holiday
        '
        Me.Lbl_Holiday.Font = New System.Drawing.Font("MS UI Gothic", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Lbl_Holiday.Location = New System.Drawing.Point(204, 88)
        Me.Lbl_Holiday.Name = "Lbl_Holiday"
        Me.Lbl_Holiday.Size = New System.Drawing.Size(32, 20)
        Me.Lbl_Holiday.TabIndex = 70
        Me.Lbl_Holiday.Text = "=>"
        Me.Lbl_Holiday.Visible = False
        '
        'Btn_HolidayAdd
        '
        Me.Btn_HolidayAdd.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_HolidayAdd.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_HolidayAdd.ForeColor = System.Drawing.Color.White
        Me.Btn_HolidayAdd.Location = New System.Drawing.Point(124, 208)
        Me.Btn_HolidayAdd.Name = "Btn_HolidayAdd"
        Me.Btn_HolidayAdd.Size = New System.Drawing.Size(72, 32)
        Me.Btn_HolidayAdd.TabIndex = 1
        Me.Btn_HolidayAdd.Text = "�ǉ�"
        Me.Btn_HolidayAdd.UseVisualStyleBackColor = False
        Me.Btn_HolidayAdd.Visible = False
        '
        'Cal_Holiday
        '
        Me.Cal_Holiday.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Cal_Holiday.Location = New System.Drawing.Point(28, 16)
        Me.Cal_Holiday.MaxSelectionCount = 1
        Me.Cal_Holiday.Name = "Cal_Holiday"
        Me.Cal_Holiday.ShowToday = False
        Me.Cal_Holiday.ShowTodayCircle = False
        Me.Cal_Holiday.TabIndex = 0
        Me.Cal_Holiday.Visible = False
        '
        'Grd_Master
        '
        Me.Grd_Master.BackColor = System.Drawing.Color.Gainsboro
        Me.Grd_Master.DataMember = ""
        Me.Grd_Master.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.Grd_Master.Location = New System.Drawing.Point(28, 16)
        Me.Grd_Master.Name = "Grd_Master"
        Me.Grd_Master.Size = New System.Drawing.Size(788, 384)
        Me.Grd_Master.TabIndex = 2
        '
        'Btn_ReadCsv
        '
        Me.Btn_ReadCsv.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_ReadCsv.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_ReadCsv.ForeColor = System.Drawing.Color.White
        Me.Btn_ReadCsv.Location = New System.Drawing.Point(344, 428)
        Me.Btn_ReadCsv.Name = "Btn_ReadCsv"
        Me.Btn_ReadCsv.Size = New System.Drawing.Size(112, 44)
        Me.Btn_ReadCsv.TabIndex = 5
        Me.Btn_ReadCsv.Text = "CSV�Ǎ�"
        Me.Btn_ReadCsv.UseVisualStyleBackColor = False
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Clear.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Clear.ForeColor = System.Drawing.Color.White
        Me.Btn_Clear.Location = New System.Drawing.Point(584, 428)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(112, 44)
        Me.Btn_Clear.TabIndex = 7
        Me.Btn_Clear.Text = "�N���A"
        Me.Btn_Clear.UseVisualStyleBackColor = False
        '
        'Btn_OutputCsv
        '
        Me.Btn_OutputCsv.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_OutputCsv.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_OutputCsv.ForeColor = System.Drawing.Color.White
        Me.Btn_OutputCsv.Location = New System.Drawing.Point(464, 428)
        Me.Btn_OutputCsv.Name = "Btn_OutputCsv"
        Me.Btn_OutputCsv.Size = New System.Drawing.Size(112, 44)
        Me.Btn_OutputCsv.TabIndex = 6
        Me.Btn_OutputCsv.Text = "CSV�o��"
        Me.Btn_OutputCsv.UseVisualStyleBackColor = False
        '
        'Btn_Update
        '
        Me.Btn_Update.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Update.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Update.ForeColor = System.Drawing.Color.White
        Me.Btn_Update.Location = New System.Drawing.Point(704, 428)
        Me.Btn_Update.Name = "Btn_Update"
        Me.Btn_Update.Size = New System.Drawing.Size(112, 44)
        Me.Btn_Update.TabIndex = 8
        Me.Btn_Update.Text = "�X�V"
        Me.Btn_Update.UseVisualStyleBackColor = False
        '
        'Grp_CsvSource
        '
        Me.Grp_CsvSource.Controls.Add(Me.Rdo_CsvSource_Slk)
        Me.Grp_CsvSource.Controls.Add(Me.Rdo_CsvSource_Muse)
        Me.Grp_CsvSource.Controls.Add(Me.Rdo_CsvSource_Web)
        Me.Grp_CsvSource.Location = New System.Drawing.Point(28, 428)
        Me.Grp_CsvSource.Name = "Grp_CsvSource"
        Me.Grp_CsvSource.Size = New System.Drawing.Size(136, 44)
        Me.Grp_CsvSource.TabIndex = 3
        Me.Grp_CsvSource.TabStop = False
        Me.Grp_CsvSource.Text = "CSV�Ǎ���"
        Me.Grp_CsvSource.Visible = False
        '
        'Rdo_CsvSource_Slk
        '
        Me.Rdo_CsvSource_Slk.Checked = True
        Me.Rdo_CsvSource_Slk.Location = New System.Drawing.Point(12, 20)
        Me.Rdo_CsvSource_Slk.Name = "Rdo_CsvSource_Slk"
        Me.Rdo_CsvSource_Slk.Size = New System.Drawing.Size(56, 16)
        Me.Rdo_CsvSource_Slk.TabIndex = 2
        Me.Rdo_CsvSource_Slk.TabStop = True
        Me.Rdo_CsvSource_Slk.Text = "SLK"
        '
        'Rdo_CsvSource_Muse
        '
        Me.Rdo_CsvSource_Muse.Location = New System.Drawing.Point(72, 20)
        Me.Rdo_CsvSource_Muse.Name = "Rdo_CsvSource_Muse"
        Me.Rdo_CsvSource_Muse.Size = New System.Drawing.Size(56, 16)
        Me.Rdo_CsvSource_Muse.TabIndex = 1
        Me.Rdo_CsvSource_Muse.Text = "MUSE"
        '
        'Rdo_CsvSource_Web
        '
        Me.Rdo_CsvSource_Web.Checked = True
        Me.Rdo_CsvSource_Web.Location = New System.Drawing.Point(12, 21)
        Me.Rdo_CsvSource_Web.Name = "Rdo_CsvSource_Web"
        Me.Rdo_CsvSource_Web.Size = New System.Drawing.Size(56, 16)
        Me.Rdo_CsvSource_Web.TabIndex = 0
        Me.Rdo_CsvSource_Web.TabStop = True
        Me.Rdo_CsvSource_Web.Text = "WEB"
        '
        'Grp_CsvReadType
        '
        Me.Grp_CsvReadType.Controls.Add(Me.Rdo_CsvReadType_Diff)
        Me.Grp_CsvReadType.Controls.Add(Me.Rdo_CsvReadType_All)
        Me.Grp_CsvReadType.Location = New System.Drawing.Point(184, 428)
        Me.Grp_CsvReadType.Name = "Grp_CsvReadType"
        Me.Grp_CsvReadType.Size = New System.Drawing.Size(136, 44)
        Me.Grp_CsvReadType.TabIndex = 4
        Me.Grp_CsvReadType.TabStop = False
        Me.Grp_CsvReadType.Text = "CSV�Ǎ��`��"
        '
        'Rdo_CsvReadType_Diff
        '
        Me.Rdo_CsvReadType_Diff.Location = New System.Drawing.Point(72, 20)
        Me.Rdo_CsvReadType_Diff.Name = "Rdo_CsvReadType_Diff"
        Me.Rdo_CsvReadType_Diff.Size = New System.Drawing.Size(56, 16)
        Me.Rdo_CsvReadType_Diff.TabIndex = 1
        Me.Rdo_CsvReadType_Diff.Text = "����"
        '
        'Rdo_CsvReadType_All
        '
        Me.Rdo_CsvReadType_All.Checked = True
        Me.Rdo_CsvReadType_All.Location = New System.Drawing.Point(12, 20)
        Me.Rdo_CsvReadType_All.Name = "Rdo_CsvReadType_All"
        Me.Rdo_CsvReadType_All.Size = New System.Drawing.Size(56, 16)
        Me.Rdo_CsvReadType_All.TabIndex = 0
        Me.Rdo_CsvReadType_All.TabStop = True
        Me.Rdo_CsvReadType_All.Text = "�S��"
        '
        'Lbl_RecCnt
        '
        Me.Lbl_RecCnt.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lbl_RecCnt.Location = New System.Drawing.Point(60, 400)
        Me.Lbl_RecCnt.Name = "Lbl_RecCnt"
        Me.Lbl_RecCnt.Size = New System.Drawing.Size(96, 16)
        Me.Lbl_RecCnt.TabIndex = 67
        Me.Lbl_RecCnt.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Lbl_RecCnt_Tiltle
        '
        Me.Lbl_RecCnt_Tiltle.Location = New System.Drawing.Point(28, 402)
        Me.Lbl_RecCnt_Tiltle.Name = "Lbl_RecCnt_Tiltle"
        Me.Lbl_RecCnt_Tiltle.Size = New System.Drawing.Size(36, 16)
        Me.Lbl_RecCnt_Tiltle.TabIndex = 65
        Me.Lbl_RecCnt_Tiltle.Text = "�����F"
        '
        'Lbl_ServicePacComment
        '
        Me.Lbl_ServicePacComment.BackColor = System.Drawing.SystemColors.Control
        Me.Lbl_ServicePacComment.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_ServicePacComment.ForeColor = System.Drawing.Color.Red
        Me.Lbl_ServicePacComment.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Lbl_ServicePacComment.Location = New System.Drawing.Point(344, 400)
        Me.Lbl_ServicePacComment.Name = "Lbl_ServicePacComment"
        Me.Lbl_ServicePacComment.Size = New System.Drawing.Size(468, 16)
        Me.Lbl_ServicePacComment.TabIndex = 64
        Me.Lbl_ServicePacComment.Text = "���K�p����(RegistrationTerm)���߂��Ă��Ȃ��f�[�^�̂݃f�[�^�x�[�X�ɔ��f����܂��B"
        Me.Lbl_ServicePacComment.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Cmb_SerchColumn
        '
        Me.Cmb_SerchColumn.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_SerchColumn.Location = New System.Drawing.Point(356, 64)
        Me.Cmb_SerchColumn.MaxDropDownItems = 20
        Me.Cmb_SerchColumn.Name = "Cmb_SerchColumn"
        Me.Cmb_SerchColumn.Size = New System.Drawing.Size(120, 20)
        Me.Cmb_SerchColumn.TabIndex = 1
        '
        'Txt_SerchString
        '
        Me.Txt_SerchString.Location = New System.Drawing.Point(476, 64)
        Me.Txt_SerchString.Name = "Txt_SerchString"
        Me.Txt_SerchString.Size = New System.Drawing.Size(108, 19)
        Me.Txt_SerchString.TabIndex = 2
        '
        'Cmb_MasterName
        '
        Me.Cmb_MasterName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_MasterName.Location = New System.Drawing.Point(132, 64)
        Me.Cmb_MasterName.MaxDropDownItems = 20
        Me.Cmb_MasterName.Name = "Cmb_MasterName"
        Me.Cmb_MasterName.Size = New System.Drawing.Size(192, 20)
        Me.Cmb_MasterName.TabIndex = 0
        '
        'UCnt_Pal00012
        '
        Me.UCnt_Pal00012.BackColor = System.Drawing.Color.Teal
        Me.UCnt_Pal00012.BackColro2 = System.Drawing.Color.PaleTurquoise
        Me.UCnt_Pal00012.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UCnt_Pal00012.ForeColor = System.Drawing.Color.White
        Me.UCnt_Pal00012.Location = New System.Drawing.Point(0, 0)
        Me.UCnt_Pal00012.Name = "UCnt_Pal00012"
        Me.UCnt_Pal00012.Size = New System.Drawing.Size(920, 44)
        Me.UCnt_Pal00012.TabIndex = 7
        Me.UCnt_Pal00012.TitleText = "Administrator"
        '
        'Btn_Serch
        '
        Me.Btn_Serch.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Serch.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Serch.ForeColor = System.Drawing.Color.White
        Me.Btn_Serch.Location = New System.Drawing.Point(588, 60)
        Me.Btn_Serch.Name = "Btn_Serch"
        Me.Btn_Serch.Size = New System.Drawing.Size(60, 24)
        Me.Btn_Serch.TabIndex = 3
        Me.Btn_Serch.Text = "����"
        Me.Btn_Serch.UseVisualStyleBackColor = False
        '
        'chkOpenPrice
        '
        Me.chkOpenPrice.AutoSize = True
        Me.chkOpenPrice.Location = New System.Drawing.Point(685, 66)
        Me.chkOpenPrice.Name = "chkOpenPrice"
        Me.chkOpenPrice.Size = New System.Drawing.Size(76, 16)
        Me.chkOpenPrice.TabIndex = 66
        Me.chkOpenPrice.Text = "OpenPrice"
        Me.chkOpenPrice.UseVisualStyleBackColor = True
        '
        'Btn_LogOut
        '
        Me.Btn_LogOut.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_LogOut.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_LogOut.ForeColor = System.Drawing.Color.White
        Me.Btn_LogOut.Location = New System.Drawing.Point(52, 589)
        Me.Btn_LogOut.Name = "Btn_LogOut"
        Me.Btn_LogOut.Size = New System.Drawing.Size(112, 44)
        Me.Btn_LogOut.TabIndex = 6
        Me.Btn_LogOut.Text = "���O�A�E�g"
        Me.Btn_LogOut.UseVisualStyleBackColor = False
        '
        'chk_Wcat
        '
        Me.chk_Wcat.AutoSize = True
        Me.chk_Wcat.Location = New System.Drawing.Point(685, 50)
        Me.chk_Wcat.Name = "chk_Wcat"
        Me.chk_Wcat.Size = New System.Drawing.Size(49, 16)
        Me.chk_Wcat.TabIndex = 67
        Me.chk_Wcat.Text = "Wcat"
        Me.chk_Wcat.UseVisualStyleBackColor = True
        '
        'lblNow
        '
        Me.lblNow.AutoSize = True
        Me.lblNow.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblNow.Location = New System.Drawing.Point(772, 68)
        Me.lblNow.Name = "lblNow"
        Me.lblNow.Size = New System.Drawing.Size(144, 12)
        Me.lblNow.TabIndex = 68
        Me.lblNow.Text = "yyyy/mm/dd HH:mm:ss"
        '
        'tmNow
        '
        Me.tmNow.Enabled = True
        '
        'Frm_OioMasterUpdate
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.AutoScroll = True
        Me.AutoSize = True
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(920, 645)
        Me.Controls.Add(Me.lblNow)
        Me.Controls.Add(Me.chk_Wcat)
        Me.Controls.Add(Me.Btn_LogOut)
        Me.Controls.Add(Me.chkOpenPrice)
        Me.Controls.Add(Me.Cmb_MasterName)
        Me.Controls.Add(Me.UCnt_Pal00012)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.lbl_MasterName)
        Me.Controls.Add(Me.Cmb_SerchColumn)
        Me.Controls.Add(Me.Txt_SerchString)
        Me.Controls.Add(Me.Btn_Serch)
        Me.MaximizeBox = False
        Me.Name = "Frm_OioMasterUpdate"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "�}�X�^�X�V"
        Me.GroupBox3.ResumeLayout(False)
        CType(Me.Grd_Master, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Grp_CsvSource.ResumeLayout(False)
        Me.Grp_CsvReadType.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

#Region " �萔 "

    '������
    Private Const STR_OUTPUTTING As String = "�o�͒��E�E�E"
    Private Const STR_UPDATING As String = "�X�V���E�E�E"
    Private Const STR_UPLOADING As String = "�A�b�v���[�h���E�E�E"
    Private Const STR_READING As String = "�Ǎ����E�E�E"
    Private Const STR_MESSAGE_READ_CSV As String = "CSV�t�@�C����Ǎ����ł��B"
    Private Const STR_MESSAGE_OUTPUT_CSV As String = "CSV�t�@�C�����o�͒��ł��B"
    Private Const STR_MESSAGE_UPDATE_TABLE As String = "�e�[�u�����X�V���ł��B"
    Private Const STR_MESSAGE_UPLOAD_MASTER As String = "�}�X�^��GSA�ɃA�b�v���[�h���ł��B"
    Private Const COMBOTABLE_COLUMN_NAME_TEXT As String = "text"
    Private Const COMBOTABLE_COLUMN_NAME_VALUE As String = "value"
    Private Const STR_TESTING As String = "���������ؒ�������"
    Private Const STATUS_INSERT As String = "�ǉ�"
    Private Const STATUS_MODIFY As String = "�ύX"
    Private Const STATUS_DELETE As String = "�폜"
    Private Const MASTER_COLUMN_NAME_STATUS As String = "�O���b�h�\���p�X�e�[�^�X"
    Private Const STR_GETTING As String = "�擾���E�E�E"
    Private Const STR_MESSAGE_GET_DATA As String = "�f�[�^���擾���ł��B"

#End Region

#Region " �v���p�e�B"
    Public ReadOnly Property ReturnCd As String
        Get
            Return _rtnCd
        End Get
    End Property

#End Region

#Region " �����o�ϐ� "
    Dim _rtnCd As String = ""
    Dim _bindManager As BindingManagerBase '�o�C���h���
    Dim _dialogInitialPath As String
    Dim _updateFlg As Boolean
    Dim _Role1 As String
    '�ύX�O�f�[�^
    Dim _dtBeforeMaster As DataTable
#End Region

#Region "�R���X�g���N�^"
    Sub New(ByVal Role1 As String)

        MyBase.new()
        InitializeComponent()

        Me._Role1 = Role1

    End Sub
#End Region

#Region " �C�x���g�n���h�� "

    '--------------------------------------------------------
    '���\�b�h���FFrm_MasterUpdate_Load
    '�T    �v  �F��ʃ��[�h����
    '��    ��  �F��ʃ��[�h�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Frm_MasterUpdate_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try
            '�����\���p�̃f�[�^���擾
            Me.SetInitialData()

            Me.Text = CommonVariable.OBAMATITLE

        Catch ex As MuseException
            Me.Activate()
            Me.Cursor = Cursors.Default
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
            Me.Close()
        Catch ex As Exception
            Me.Activate()
            Me.Cursor = Cursors.Default
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
            Me.Close()
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FFrm_MasterUpdate_Closing
    '�T    �v  �F��ʃN���[�Y����
    '��    ��  �F��ʃN���[�Y�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Frm_MasterUpdate_Closing(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Closed


    End Sub

    '--------------------------------------------------------
    '���\�b�h���FCmb_MasterName_SelectedIndexChanged
    '�T    �v  �FCmb_MasterName�I������
    '��    ��  �FCmb_MasterName�I���������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Cmb_MasterName_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_MasterName.SelectedIndexChanged

        Try
            Dim ofm As New OioBamaCommmon.OioFileManage
            Dim strErrMsg As String
            If ofm.CheckExistsMdb(OioBamaCommmon.OioFileManage.enmMdbType.Master, CommonVariable.MdbPW, strErrMsg) = False Then
                Call MuseMessageBox.ShowError(strErrMsg, Me.Text)
                Exit Sub
            End If

            '��ʃ��C�A�E�g�ݒ�
            Me.Grp_CsvReadType.Visible = True
            Me.Rdo_CsvReadType_All.Enabled = True
            Me.Rdo_CsvReadType_Diff.Enabled = True
            Me.Btn_ReadCsv.Visible = True
            Me.Btn_OutputCsv.Visible = True
            Me.Btn_Clear.Visible = True
            Me.Btn_Delete.Visible = True
            Me.Btn_GetData.Visible = False
            Me.Btn_Update.Visible = True

            Select Case sender.Text
                Case ServicePacTable.TABLE_NAME
                    '��ServicePac�e�[�u���̏ꍇ
                    Me.Lbl_ServicePacComment.Visible = True
                    Me.Grp_CsvSource.Visible = True
                    Me.Rdo_CsvSource_Web.Visible = True
                    Me.Rdo_CsvSource_Slk.Visible = False
                    Me.Rdo_CsvSource_Web.Checked = True
                    Me.Cal_Holiday.Visible = False
                    Me.Btn_HolidayAdd.Visible = False
                    Me.Lbl_Holiday.Visible = False
                    Me.Grd_Master.Location = New System.Drawing.Point(28, 16)
                    Me.Grd_Master.Size = New System.Drawing.Size(788, 384)
                    Me.Lbl_RecCnt_Tiltle.Location = New System.Drawing.Point(28, 402)
                    Me.Lbl_RecCnt.Location = New System.Drawing.Point(60, 400)
                    Me.Btn_FirstRec.Location = New System.Drawing.Point(156, 400)
                    Me.Btn_LastRec.Location = New System.Drawing.Point(180, 400)
                    Me.Btn_Delete.Location = New System.Drawing.Point(28, 16)
                    Me.Btn_ClearSort.Location = New System.Drawing.Point(68, 16)
                    Me.chkOpenPrice.Visible = False
                    Me.chk_Wcat.Visible = False
                Case OpenPriceTable.TABLE_NAME
                    Me.Lbl_ServicePacComment.Visible = False
                    Me.Grp_CsvSource.Visible = False
                    Me.Cal_Holiday.Visible = False
                    Me.Btn_HolidayAdd.Visible = False
                    Me.Lbl_Holiday.Visible = False
                    Me.Grd_Master.Location = New System.Drawing.Point(28, 16)
                    Me.Grd_Master.Size = New System.Drawing.Size(788, 384)
                    Me.Lbl_RecCnt_Tiltle.Location = New System.Drawing.Point(28, 402)
                    Me.Lbl_RecCnt.Location = New System.Drawing.Point(60, 400)
                    Me.Btn_FirstRec.Location = New System.Drawing.Point(156, 400)
                    Me.Btn_LastRec.Location = New System.Drawing.Point(180, 400)
                    Me.Btn_Delete.Location = New System.Drawing.Point(28, 16)
                    Me.Btn_ClearSort.Location = New System.Drawing.Point(68, 16)
                    Me.chkOpenPrice.Visible = False
                    Me.chkOpenPrice.Checked = True
                    Me.Grp_CsvReadType.Visible = False
                    Me.Btn_ReadCsv.Visible = False
                    Me.Btn_Clear.Visible = False
                    Me.chk_Wcat.Visible = False
                Case WcatTable.TABLE_NAME
                    Me.Lbl_ServicePacComment.Visible = False
                    Me.Grp_CsvSource.Visible = False
                    Me.Cal_Holiday.Visible = False
                    Me.Btn_HolidayAdd.Visible = False
                    Me.Lbl_Holiday.Visible = False
                    Me.Grd_Master.Location = New System.Drawing.Point(28, 16)
                    Me.Grd_Master.Size = New System.Drawing.Size(788, 384)
                    Me.Lbl_RecCnt_Tiltle.Location = New System.Drawing.Point(28, 402)
                    Me.Lbl_RecCnt.Location = New System.Drawing.Point(60, 400)
                    Me.Btn_FirstRec.Location = New System.Drawing.Point(156, 400)
                    Me.Btn_LastRec.Location = New System.Drawing.Point(180, 400)
                    Me.Btn_Delete.Location = New System.Drawing.Point(28, 16)
                    Me.Btn_ClearSort.Location = New System.Drawing.Point(68, 16)
                    Me.chkOpenPrice.Visible = False
                    Me.chk_Wcat.Visible = False
                    Me.chk_Wcat.Checked = True
                    Me.Grp_CsvReadType.Visible = False
                    Me.Btn_ReadCsv.Visible = False
                    Me.Btn_Clear.Visible = False
                    'Req1692�FM_QCOSHW�e�[�u���ǉ� 2018/12 Str
                    'Case M_QCOSTable.TABLE_NAME,
                    '     M_AASHWTable.TABLE_NAME,
                    '     M_AASSWTable.TABLE_NAME,
                    '     X_SoftWareTable.TABLE_NAME,
                    '     M_PA_PRICETable.TABLE_NAME,
                    '     M_PA_MEDIATable.TABLE_NAME,
                    '     M_MEDIA_PRICETable.TABLE_NAME,
                    '     M_VLSTable.TABLE_NAME,
                    '     M_MVMSTable.TABLE_NAME,
                    '     BasicSelection.TABLE_NAME,
                    '     M_CISCOTable.TABLE_NAME,
                    '     M_AasHwBoxTable.TABLE_NAME
                Case M_QCOSTable.TABLE_NAME,
                     M_AASHWTable.TABLE_NAME,
                     M_AASSWTable.TABLE_NAME,
                     X_SoftWareTable.TABLE_NAME,
                     M_PA_PRICETable.TABLE_NAME,
                     M_PA_MEDIATable.TABLE_NAME,
                     M_MEDIA_PRICETable.TABLE_NAME,
                     M_VLSTable.TABLE_NAME,
                     M_MVMSTable.TABLE_NAME,
                     BasicSelection.TABLE_NAME,
                     M_CISCOTable.TABLE_NAME,
                     M_AasHwBoxTable.TABLE_NAME,
                     M_QCOSHWTable.TABLE_NAME
                    'Req1692�FM_QCOSHW�e�[�u���ǉ� 2018/12 End
                    Me.Lbl_ServicePacComment.Visible = False
                    Me.Grp_CsvSource.Visible = False
                    Me.Cal_Holiday.Visible = False
                    Me.Btn_HolidayAdd.Visible = False
                    Me.Lbl_Holiday.Visible = False
                    Me.Grd_Master.Location = New System.Drawing.Point(28, 16)
                    Me.Grd_Master.Size = New System.Drawing.Size(788, 384)
                    Me.Lbl_RecCnt_Tiltle.Location = New System.Drawing.Point(28, 402)
                    Me.Lbl_RecCnt.Location = New System.Drawing.Point(60, 400)
                    Me.Btn_FirstRec.Location = New System.Drawing.Point(156, 400)
                    Me.Btn_LastRec.Location = New System.Drawing.Point(180, 400)
                    Me.Btn_Delete.Location = New System.Drawing.Point(28, 16)
                    Me.Btn_ClearSort.Location = New System.Drawing.Point(68, 16)
                    Me.chkOpenPrice.Visible = False
                    Me.chk_Wcat.Visible = False
                    Me.Btn_ReadCsv.Visible = False
                    Me.Btn_Clear.Visible = False
                    Me.Btn_Delete.Visible = False
                    Me.Grp_CsvReadType.Visible = False
                    Me.Btn_GetData.Location = New System.Drawing.Point(584, 428)
                    Me.Btn_GetData.Visible = False
                Case M_CONTRACT_BASETable.TABLE_NAME,
                     M_CONTRACT_DETAILTable.TABLE_NAME,
                     M_PLANTable.TABLE_NAME,
                     M_CONTRACT_TEMP.TABLE_NAME
                    Me.Lbl_ServicePacComment.Visible = False
                    Me.Grp_CsvSource.Visible = False
                    Me.Cal_Holiday.Visible = False
                    Me.Btn_HolidayAdd.Visible = False
                    Me.Lbl_Holiday.Visible = False
                    Me.Grd_Master.Location = New System.Drawing.Point(28, 16)
                    Me.Grd_Master.Size = New System.Drawing.Size(788, 384)
                    Me.Lbl_RecCnt_Tiltle.Location = New System.Drawing.Point(28, 402)
                    Me.Lbl_RecCnt.Location = New System.Drawing.Point(60, 400)
                    Me.Btn_FirstRec.Location = New System.Drawing.Point(156, 400)
                    Me.Btn_LastRec.Location = New System.Drawing.Point(180, 400)
                    Me.Btn_Delete.Location = New System.Drawing.Point(28, 16)
                    Me.Btn_ClearSort.Location = New System.Drawing.Point(68, 16)
                    Me.chkOpenPrice.Visible = False
                    Me.chk_Wcat.Visible = False
                    Me.Btn_ReadCsv.Visible = False
                    Me.Btn_Clear.Visible = False
                    Me.Btn_Delete.Visible = False
                    Me.Grp_CsvReadType.Visible = False
                    Me.Btn_GetData.Location = New System.Drawing.Point(584, 428)
                    Me.Btn_GetData.Visible = False
                Case M_HISTORYTable.TABLE_NAME
                    Me.Lbl_ServicePacComment.Visible = False
                    Me.Grp_CsvSource.Visible = False
                    Me.Cal_Holiday.Visible = False
                    Me.Btn_HolidayAdd.Visible = False
                    Me.Lbl_Holiday.Visible = False
                    Me.Grd_Master.Location = New System.Drawing.Point(28, 16)
                    Me.Grd_Master.Size = New System.Drawing.Size(788, 384)
                    Me.Lbl_RecCnt_Tiltle.Location = New System.Drawing.Point(28, 402)
                    Me.Lbl_RecCnt.Location = New System.Drawing.Point(60, 400)
                    Me.Btn_FirstRec.Location = New System.Drawing.Point(156, 400)
                    Me.Btn_LastRec.Location = New System.Drawing.Point(180, 400)
                    Me.Btn_Delete.Location = New System.Drawing.Point(28, 16)
                    Me.Btn_ClearSort.Location = New System.Drawing.Point(68, 16)
                    Me.chkOpenPrice.Visible = False
                    Me.chk_Wcat.Visible = False
                    Me.Btn_ReadCsv.Visible = False
                    Me.Btn_Clear.Visible = False
                    Me.Btn_Delete.Visible = False
                    Me.Grp_CsvReadType.Visible = False
                    Me.Btn_GetData.Location = New System.Drawing.Point(584, 428)
                    Me.Btn_GetData.Visible = False
                    Me.Btn_Update.Visible = False
                Case BusinessTypeTable.TABLE_NAME
                    Me.Lbl_ServicePacComment.Visible = False
                    Me.Grp_CsvSource.Visible = False
                    Me.Cal_Holiday.Visible = False
                    Me.Btn_HolidayAdd.Visible = False
                    Me.Lbl_Holiday.Visible = False
                    Me.Grd_Master.Location = New System.Drawing.Point(28, 16)
                    Me.Grd_Master.Size = New System.Drawing.Size(788, 384)
                    Me.Lbl_RecCnt_Tiltle.Location = New System.Drawing.Point(28, 402)
                    Me.Lbl_RecCnt.Location = New System.Drawing.Point(60, 400)
                    Me.Btn_FirstRec.Location = New System.Drawing.Point(156, 400)
                    Me.Btn_LastRec.Location = New System.Drawing.Point(180, 400)
                    Me.Btn_Delete.Location = New System.Drawing.Point(28, 16)
                    Me.Btn_ClearSort.Location = New System.Drawing.Point(68, 16)
                    Me.chkOpenPrice.Visible = False
                    Me.chkOpenPrice.Checked = True
                    Me.Grp_CsvReadType.Visible = False
                    Me.Btn_ReadCsv.Visible = False
                    Me.Btn_Clear.Visible = False
                    Me.chk_Wcat.Visible = False
                Case Else
                    Me.Lbl_ServicePacComment.Visible = False
                    Me.Grp_CsvSource.Visible = False
                    Me.Cal_Holiday.Visible = False
                    Me.Btn_HolidayAdd.Visible = False
                    Me.Lbl_Holiday.Visible = False
                    Me.Grd_Master.Location = New System.Drawing.Point(28, 16)
                    Me.Grd_Master.Size = New System.Drawing.Size(788, 384)
                    Me.Lbl_RecCnt_Tiltle.Location = New System.Drawing.Point(28, 402)
                    Me.Lbl_RecCnt.Location = New System.Drawing.Point(60, 400)
                    Me.Btn_FirstRec.Location = New System.Drawing.Point(156, 400)
                    Me.Btn_LastRec.Location = New System.Drawing.Point(180, 400)
                    Me.Btn_Delete.Location = New System.Drawing.Point(28, 16)
                    Me.Btn_ClearSort.Location = New System.Drawing.Point(68, 16)
                    Me.Rdo_CsvReadType_All.Enabled = True
                    Me.Rdo_CsvReadType_Diff.Enabled = True
                    Me.chkOpenPrice.Visible = False
                    Me.chk_Wcat.Visible = False
            End Select

            '�O���b�h�Ƀ}�X�^�f�[�^�ݒ�
            Me.SetMasterData(sender.Text)
            Select Case Me.Cmb_MasterName.Text
                'Req1692�FM_QCOSHW�e�[�u���ǉ� 2018/12 Str
                'Case M_QCOSTable.TABLE_NAME,
                '     M_AASHWTable.TABLE_NAME,
                '     M_AASSWTable.TABLE_NAME,
                '     X_SoftWareTable.TABLE_NAME,
                '     M_PA_PRICETable.TABLE_NAME,
                '     M_PA_MEDIATable.TABLE_NAME,
                '     M_MEDIA_PRICETable.TABLE_NAME,
                '     M_VLSTable.TABLE_NAME,
                '     M_MVMSTable.TABLE_NAME,
                '     BasicSelection.TABLE_NAME,
                '     M_CISCOTable.TABLE_NAME,
                '     M_AasHwBoxTable.TABLE_NAME
                Case M_QCOSTable.TABLE_NAME,
                     M_AASHWTable.TABLE_NAME,
                     M_AASSWTable.TABLE_NAME,
                     X_SoftWareTable.TABLE_NAME,
                     M_PA_PRICETable.TABLE_NAME,
                     M_PA_MEDIATable.TABLE_NAME,
                     M_MEDIA_PRICETable.TABLE_NAME,
                     M_VLSTable.TABLE_NAME,
                     M_MVMSTable.TABLE_NAME,
                     BasicSelection.TABLE_NAME,
                     M_CISCOTable.TABLE_NAME,
                     M_AasHwBoxTable.TABLE_NAME,
                     M_QCOSHWTable.TABLE_NAME
                    'Req1692�FM_QCOSHW�e�[�u���ǉ� 2018/12 End
                    Me.Grd_Master.ReadOnly = True
                Case Else
                    Me.Grd_Master.ReadOnly = False
                    '�O���b�h�Ƀt�H�[�J�X�𓖂Ă�
                    Me.Grd_Master.Focus()
            End Select

            '�ύX�O�f�[�^�ۑ�
            Dim dt As DataTable
            dt = CType(Me.Grd_Master.DataSource, DataTable)
            If IsNothing(dt) = False Then
                _dtBeforeMaster = dt.Copy
            End If

        Catch ex As MuseException
            Me.Activate()
            Me.Cursor = Cursors.Default
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
            Me.Close()
        Catch ex As Exception
            Me.Activate()
            Me.Cursor = Cursors.Default
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
            Me.Close()
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Clear_Click
    '�T    �v  �FBtn_Clear�N���b�N����
    '��    ��  �FBtn_Clear�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click

        Try
            If Me.Cmb_MasterName.Text.Equals(String.Empty) Then
                Me.Cmb_MasterName.Focus()
                Throw New MuseException(Me.lbl_MasterName.Text & FileReader.GetMessage("MSG_0018"))
            End If

            If MuseMessageBox.ShowQuestion(FileReader.GetMessage("MSG_0040"), sender.Text) = DialogResult.OK Then
                '�O���b�h�Ƀ}�X�^�f�[�^�ݒ�
                Me.SetMasterData(Me.Cmb_MasterName.Text)
            End If

        Catch ex As MuseException
            Me.Activate()
            Me.Cursor = Cursors.Default
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            Me.Cursor = Cursors.Default
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_ReadCsv_Click
    '�T    �v  �FBtn_ReadCsv�N���b�N����
    '��    ��  �FBtn_ReadCsv�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_ReadCsv_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_ReadCsv.Click

        '�������_�C�A���O��`
        Dim waitDialog As New Frm_WaitDialog

        Try
            If Me.Cmb_MasterName.Text.Equals(String.Empty) Then
                Me.Cmb_MasterName.Focus()
                Throw New MuseException(Me.lbl_MasterName.Text & FileReader.GetMessage("MSG_0018"))
            End If

            Dim dialog As OpenFileDialog = New OpenFileDialog
            dialog.Filter = "csv files (*.csv)|*.csv"
            dialog.Multiselect = True '�����I���Ƃ���B

            ''Windows7�ɁuC:\Documents and Settings�v�̃t�H���_���Ȃ����߁A���[�U�[�����ɂ���B
            If CommonVariable.OSVERSION = CommonConstant.OS_WINDOWS7 Then
                dialog.InitialDirectory = "C:\Users"
            Else
                dialog.InitialDirectory = "C:\Documents and Settings"
            End If

            If dialog.ShowDialog() = DialogResult.OK Then
                Me.Refresh()
                Me.Cursor = Cursors.WaitCursor

                '�������_�C�A���O�\��
                waitDialog.Text = Me.STR_READING
                waitDialog.lbl_Message.Text = Me.STR_MESSAGE_READ_CSV
                waitDialog.Pic_Folder.Visible = True
                waitDialog.ProgressMin = 0
                waitDialog.ProgressMax = 3
                waitDialog.ProgressStep = 1
                waitDialog.ProgressValue = 0
                waitDialog.Show()
                waitDialog.Refresh()

                '==============================
                '���}�X�^�t�@�C��(CSV)�Ǎ�������
                '==============================
                Dim masterData As DataTable
                If Me.Rdo_CsvReadType_All.Checked = True Then
                    '���Ǎ��`���S���̏ꍇ
                    masterData = CType(Me.Grd_Master.DataSource, DataTable).Clone
                ElseIf Me.Rdo_CsvReadType_Diff.Checked = True Then
                    '���Ǎ��`�������̏ꍇ
                    masterData = CType(Me.Grd_Master.DataSource, DataTable)
                    '�p�t�H�[�}���X���ቺ����ׁA�f�[�^�\�[�X�̊��蓖�Ă���������B
                    Me.Grd_Master.DataSource = Nothing
                End If
                waitDialog.PerformStep()

                Select Case Me.Cmb_MasterName.Text
                    Case ServicePacTable.TABLE_NAME
                        '��ServicePac�e�[�u���̏ꍇ
                        If Me.Rdo_CsvSource_Web.Checked = True Then
                            '��WEB�f�[�^�Ǎ��̏ꍇ
                            Me.ReadServicePacWebCsv(dialog.FileNames, CType(masterData, ServicePacTable))
                        ElseIf Me.Rdo_CsvSource_Muse.Checked = True Then
                            Me.ReadCsv(dialog.FileNames, masterData)
                        End If
                    Case OpenPriceTable.TABLE_NAME
                        Call CsvReadOpenPrice(dialog.FileName.ToString, masterData)
                    Case WcatTable.TABLE_NAME
                        Call CsvReadWcat(dialog.FileName.ToString, masterData)
                    Case M_PLANTable.TABLE_NAME
                        Call Me.SetM_PlanData(dialog.FileName.ToString, masterData)
                    Case NonSBOTable.TABLE_NAME
                        Call CsvReadNonSBO(dialog.FileName.ToString, masterData)
                    Case M_GroupTable.TABLE_NAME
                        Call CsvReadM_Group(dialog.FileName.ToString, masterData)
                    Case BusinessTypeTable.TABLE_NAME
                        Call CsvReadBusinessType(dialog.FileName.ToString, masterData)
                    Case Else
                        Me.ReadCsv(dialog.FileNames, masterData)
                End Select
                waitDialog.PerformStep()

                '�X�e�[�^�X��ҏW
                Dim row As DataRow
                For Each row In masterData.Rows
                    If row.RowState = DataRowState.Added Then
                        If row.Item(Me.MASTER_COLUMN_NAME_STATUS).ToString().Equals(String.Empty) Then
                            row.Item(Me.MASTER_COLUMN_NAME_STATUS) = Me.STATUS_INSERT
                        End If
                    End If
                Next

                '�f�[�^�\�[�X�Ɋ��蓖��
                Me.Grd_Master.DataSource = masterData
                waitDialog.PerformStep()

                Me.Refresh()
                Me.Cursor = Cursors.Default

                '�����I�����b�Z�[�W�\��
                Me.Activate()
                MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0001"), sender.Text)

                Me._dialogInitialPath = Path.GetDirectoryName(dialog.FileName)
            End If

            waitDialog.Close()

            Me.Refresh()
            Me.Cursor = Cursors.Default

        Catch ex As MuseException
            Me.Activate()
            waitDialog.Close()
            Me.Cursor = Cursors.Default
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            waitDialog.Close()
            Me.Cursor = Cursors.Default
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_OutputCsv_Click
    '�T    �v  �FBtn_OutputCsv�N���b�N����
    '��    ��  �FBtn_OutputCsv�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_OutputCsv_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_OutputCsv.Click

        '�������_�C�A���O��`
        Dim waitDialog As New Frm_WaitDialog

        Try
            If Me.Cmb_MasterName.Text.Equals(String.Empty) Then
                Me.Cmb_MasterName.Focus()
                Throw New MuseException(Me.lbl_MasterName.Text & FileReader.GetMessage("MSG_0018"))
            End If

            Dim dialog As SaveFileDialog = New SaveFileDialog
            dialog.Filter = "csv files (*.csv)|*.csv"
            dialog.FileName = Me.Cmb_MasterName.Text
            ''Windows7�ɁuC:\Documents and Settings�v�̃t�H���_���Ȃ����߁A���[�U�[�����ɂ���B
            If CommonVariable.OSVERSION = CommonConstant.OS_WINDOWS7 Then
                dialog.InitialDirectory = "C:\Users"
            Else
                dialog.InitialDirectory = "C:\Documents and Settings"
            End If

            If dialog.ShowDialog() = DialogResult.OK Then
                Me.Refresh()
                Me.Cursor = Cursors.WaitCursor

                '�������_�C�A���O�\��
                waitDialog.Text = Me.STR_OUTPUTTING
                waitDialog.lbl_Message.Text = Me.STR_MESSAGE_OUTPUT_CSV
                waitDialog.Pic_Excel.Visible = True
                waitDialog.ProgressMin = 0
                waitDialog.ProgressMax = 2
                waitDialog.ProgressStep = 1
                waitDialog.ProgressValue = 0
                waitDialog.Show()
                waitDialog.Refresh()

                '==============================
                '���}�X�^�t�@�C��(CSV)�쐬������
                '==============================
                '�O���b�h�ɕ\������Ă���f�[�^�����[�N�e�[�u�����f����B
                Dim masterData As New DataTable
                masterData = CType(Me.Grd_Master.DataSource, DataTable).Copy()
                waitDialog.PerformStep()

                ''CSV�o�͑O�Ƀt�H�[�}�b�g��ύX����
                Call ChgFormatDataTable(masterData.TableName, masterData)

                Me.OutputCsv(dialog.FileName, masterData)
                waitDialog.PerformStep()

                waitDialog.Close()

                Me.Refresh()
                Me.Cursor = Cursors.Default

                '�����I�����b�Z�[�W�\��
                Me.Activate()
                MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0001"), sender.Text)
            End If

        Catch ex As MuseException
            Me.Activate()
            waitDialog.Close()
            Me.Cursor = Cursors.Default
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            waitDialog.Close()
            Me.Cursor = Cursors.Default
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Btn_GetData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_GetData.Click

        Dim waitDialog As New Frm_WaitDialog
        Dim masterData As DataTable

        Try
            If MuseMessageBox.ShowQuestion(FileReader.GetMessage("MSG_0408"), sender.Text) = DialogResult.OK Then
                Dim strId As String = ""
                Dim strPass As String = ""

                Dim frm As New Frm_IntraLogin
                frm.lblMsg.Text = "���[�U�[ID�ƃp�X���[�h����͂��Ă��������B"
                frm.txtUserId.Text = ""
                frm.ShowDialog()
                strId = frm.txtUserId.Text
                strPass = frm.txtPassword.Text
                If frm.ReturnEvent <> frm.btnOk.Text Then
                    frm.Close()
                    Exit Sub
                End If
                frm.Close()
                frm.Refresh()

                '�������_�C�A���O�\��
                waitDialog.Text = Me.STR_GETTING
                waitDialog.lbl_Message.Text = Me.STR_MESSAGE_GET_DATA
                waitDialog.Pic_Folder.Visible = True
                waitDialog.ProgressMin = 0
                waitDialog.ProgressMax = 2
                waitDialog.ProgressStep = 1
                waitDialog.ProgressValue = 0
                waitDialog.Show()
                waitDialog.Refresh()
                waitDialog.PerformStep()

                masterData = CType(Me.Grd_Master.DataSource, DataTable)
                masterData.Rows.Clear()
                '�p�t�H�[�}���X���ቺ����ׁA�f�[�^�\�[�X�̊��蓖�Ă���������B
                Me.Grd_Master.DataSource = Nothing


                '�}�X�^���O���b�h�ɐݒ肷��B
                Me.Grd_Master.DataSource = masterData

                Select Case Cmb_MasterName.Text
                    Case M_QCOSTable.TABLE_NAME
                        With Grd_Master.TableStyles(M_QCOSTable.TABLE_NAME)
                            .GridColumnStyles(M_QCOSTable.COLUMN_NAME_PRICE_S).Alignment = HorizontalAlignment.Right
                            .GridColumnStyles(M_QCOSTable.COLUMN_NAME_PRICE_M).Alignment = HorizontalAlignment.Right
                            .GridColumnStyles(M_QCOSTable.COLUMN_NAME_PRICE_3).Alignment = HorizontalAlignment.Right
                            .GridColumnStyles(M_QCOSTable.COLUMN_NAME_PRICE_8).Alignment = HorizontalAlignment.Right
                        End With
                    Case M_AASHWTable.TABLE_NAME
                        With Grd_Master.TableStyles(M_AASHWTable.TABLE_NAME)
                            .GridColumnStyles(M_AASHWTable.COLUMN_NAME_PRICE_5).Alignment = HorizontalAlignment.Right
                            .GridColumnStyles(M_AASHWTable.COLUMN_NAME_PRICE_0MC).Alignment = HorizontalAlignment.Right
                            .GridColumnStyles(M_AASHWTable.COLUMN_NAME_PRICE_08A).Alignment = HorizontalAlignment.Right
                            .GridColumnStyles(M_AASHWTable.COLUMN_NAME_PRICE_09A).Alignment = HorizontalAlignment.Right
                        End With
                    Case M_AASSWTable.TABLE_NAME
                        With Grd_Master.TableStyles(M_AASSWTable.TABLE_NAME)
                            .GridColumnStyles(M_AASSWTable.COLUMN_NAME_PRICE_0).Alignment = HorizontalAlignment.Right
                            .GridColumnStyles(M_AASSWTable.COLUMN_NAME_PRICE_02B).Alignment = HorizontalAlignment.Right
                        End With
                End Select

                waitDialog.PerformStep()
                waitDialog.Close()

                Me.Activate()
                MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0001"), sender.Text)
            End If

        Catch ex As MuseException
            Me.Activate()
            waitDialog.Close()
            Me.Cursor = Cursors.Default
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Select Case Cmb_MasterName.Text
                Case M_QCOSTable.TABLE_NAME,
                     M_AASHWTable.TABLE_NAME,
                     M_AASSWTable.TABLE_NAME,
                     X_SoftWareTable.TABLE_NAME,
                     M_PA_MEDIATable.TABLE_NAME,
                     M_PA_PRICETable.TABLE_NAME,
                     M_MEDIA_PRICETable.TABLE_NAME,
                     M_VLSTable.TABLE_NAME,
                     M_MVMSTable.TABLE_NAME,
                     BasicSelection.TABLE_NAME,
                     M_CISCOTable.TABLE_NAME,
                     M_AasHwBoxTable.TABLE_NAME
                    Me.Grd_Master.DataSource = masterData
            End Select
            Me.Activate()
            waitDialog.Close()
            Me.Cursor = Cursors.Default
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Update_Click
    '�T    �v  �FBtn_Update�N���b�N����
    '��    ��  �FBtn_Update�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Update_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Update.Click

        '�������_�C�A���O��`
        Dim waitDialog As New Frm_WaitDialog
        Dim waitDialog2 As New Frm_WaitDialog
        Dim masterData2 As DataTable

        Try
            If Me.Cmb_MasterName.Text.Equals(String.Empty) Then
                Me.Cmb_MasterName.Focus()
                Throw New MuseException(Me.lbl_MasterName.Text & FileReader.GetMessage("MSG_0018"))
            End If

            'WebService�ȊO�̃e�[�u����MasterMDB���݃`�F�b�N���s��
            Select Case Me.Cmb_MasterName.Text
                Case M_CONTRACT_BASETable.TABLE_NAME,
                    M_CONTRACT_DETAILTable.TABLE_NAME,
                    M_CONTRACT_TEMP.TABLE_NAME,
                    M_PLANTable.TABLE_NAME,
                    M_HISTORYTable.TABLE_NAME
                Case Else
                    Dim ofm As New OioBamaCommmon.OioFileManage
                    Dim strErrMsg As String
                    If ofm.CheckExistsMdb(OioBamaCommmon.OioFileManage.enmMdbType.Master, CommonVariable.MdbPW, strErrMsg) = False Then
                        Call MuseMessageBox.ShowError(strErrMsg, Me.Text)
                        Exit Sub
                    End If
            End Select

            ''���̓`�F�b�N
            If ChkDispDate(Cmb_MasterName.Text) = False Then
                Exit Sub
            End If

            Select Case Me.Cmb_MasterName.Text
                'Req1692�FM_QCOSHW�e�[�u���ǉ� 2018/12 Str
                'Case M_QCOSTable.TABLE_NAME,
                '     M_AASHWTable.TABLE_NAME,
                '     M_AASSWTable.TABLE_NAME,
                '     X_SoftWareTable.TABLE_NAME,
                '     M_PA_PRICETable.TABLE_NAME,
                '     M_PA_MEDIATable.TABLE_NAME,
                '     M_MEDIA_PRICETable.TABLE_NAME,
                '     M_VLSTable.TABLE_NAME,
                '     M_MVMSTable.TABLE_NAME,
                '     BasicSelection.TABLE_NAME,
                '     M_CISCOTable.TABLE_NAME,
                '     M_AasHwBoxTable.TABLE_NAME
                Case M_QCOSTable.TABLE_NAME,
                     M_AASHWTable.TABLE_NAME,
                     M_AASSWTable.TABLE_NAME,
                     X_SoftWareTable.TABLE_NAME,
                     M_PA_PRICETable.TABLE_NAME,
                     M_PA_MEDIATable.TABLE_NAME,
                     M_MEDIA_PRICETable.TABLE_NAME,
                     M_VLSTable.TABLE_NAME,
                     M_MVMSTable.TABLE_NAME,
                     BasicSelection.TABLE_NAME,
                     M_CISCOTable.TABLE_NAME,
                     M_AasHwBoxTable.TABLE_NAME,
                     M_QCOSHWTable.TABLE_NAME
                    'Req1692�FM_QCOSHW�e�[�u���ǉ� 2018/12 Str

                    '�u�f�[�^�擾�v���������s����
                    If MuseMessageBox.ShowQuestion(FileReader.GetMessage("MSG_0408"), sender.Text) = DialogResult.OK Then
                        Dim strId As String = ""
                        Dim strPass As String = ""

                        Dim frm As New Frm_IntraLogin
                        frm.lblMsg.Text = "���[�U�[ID�ƃp�X���[�h����͂��Ă��������B"
                        frm.txtUserId.Text = ""
                        frm.ShowDialog()
                        strId = frm.txtUserId.Text
                        strPass = frm.txtPassword.Text
                        If frm.ReturnEvent <> frm.btnOk.Text Then
                            frm.Close()
                            Exit Sub
                        End If
                        frm.Close()
                        frm.Refresh()

                        '�������_�C�A���O�\��
                        waitDialog2.Text = STR_GETTING
                        waitDialog2.lbl_Message.Text = STR_MESSAGE_GET_DATA
                        waitDialog2.Pic_Folder.Visible = True
                        waitDialog2.ProgressMin = 0
                        waitDialog2.ProgressMax = 2
                        waitDialog2.ProgressStep = 1
                        waitDialog2.ProgressValue = 0
                        waitDialog2.Show()
                        waitDialog2.Refresh()
                        waitDialog2.PerformStep()

                        masterData2 = CType(Me.Grd_Master.DataSource, DataTable)
                        masterData2.Rows.Clear()
                        '�p�t�H�[�}���X���ቺ����ׁA�f�[�^�\�[�X�̊��蓖�Ă���������B
                        Me.Grd_Master.DataSource = Nothing

                        Dim control As New AdminControl
                        Dim fLogin As Boolean = True
                        Select Case Cmb_MasterName.Text
                            Case M_QCOSTable.TABLE_NAME
                                Call control.GetMasterQcosData(strId, strPass, masterData2, fLogin)
                            Case M_AASHWTable.TABLE_NAME
                                Call control.GetMasterAasHwData(strId, strPass, masterData2, fLogin)
                            Case M_AASSWTable.TABLE_NAME
                                Call control.GetMasterAasSwData(strId, strPass, masterData2, fLogin)
                            Case X_SoftWareTable.TABLE_NAME
                                Call control.GetMasterXSoftwareData(strId, strPass, masterData2, fLogin)
                            Case M_PA_MEDIATable.TABLE_NAME
                                Call control.GetMasterPaMediaData(strId, strPass, masterData2, fLogin)
                            Case M_PA_PRICETable.TABLE_NAME
                                Call control.GetMasterPaPriceData(strId, strPass, masterData2, fLogin)
                            Case M_MEDIA_PRICETable.TABLE_NAME
                                Call control.GetMasterMediaPriceData(strId, strPass, masterData2, fLogin)
                            Case M_VLSTable.TABLE_NAME
                                Call control.GetMasterVlsData(strId, strPass, masterData2, fLogin)
                            Case M_MVMSTable.TABLE_NAME
                                Call control.GetMasterMvmsData(strId, strPass, masterData2, fLogin)
                            Case BasicSelection.TABLE_NAME
                                Call control.GetMasterBasicSelectionData(strId, strPass, masterData2, fLogin)
                            Case M_CISCOTable.TABLE_NAME
                                Call control.GetMasterCiscoData(strId, strPass, masterData2, fLogin)
                            Case M_AasHwBoxTable.TABLE_NAME
                                Call control.GetMasterAasHwBoxData(strId, strPass, masterData2, fLogin)
                                'Req1692�FM_QCOSHW�e�[�u���ǉ� 2018/12 Str
                            Case M_QCOSHWTable.TABLE_NAME
                                Call control.GetMasterQcosHwData(strId, strPass, masterData2, fLogin)
                                'Req1692�FM_QCOSHW�e�[�u���ǉ� 2018/12 Str
                        End Select

                        '���O�C���Ɏ��s���Ă���ꍇ�͏I��
                        If fLogin = False Then
                            waitDialog2.Close()
                            MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0518"), sender.Text)
                            Exit Sub
                        End If

                        '�}�X�^���O���b�h�ɐݒ肷��B
                        Me.Grd_Master.DataSource = masterData2

                        Select Case Cmb_MasterName.Text
                            Case M_QCOSTable.TABLE_NAME
                                With Grd_Master.TableStyles(M_QCOSTable.TABLE_NAME)
                                    .GridColumnStyles(M_QCOSTable.COLUMN_NAME_PRICE_S).Alignment = HorizontalAlignment.Right
                                    .GridColumnStyles(M_QCOSTable.COLUMN_NAME_PRICE_M).Alignment = HorizontalAlignment.Right
                                    .GridColumnStyles(M_QCOSTable.COLUMN_NAME_PRICE_3).Alignment = HorizontalAlignment.Right
                                    .GridColumnStyles(M_QCOSTable.COLUMN_NAME_PRICE_8).Alignment = HorizontalAlignment.Right
                                End With
                            Case M_AASHWTable.TABLE_NAME
                                With Grd_Master.TableStyles(M_AASHWTable.TABLE_NAME)
                                    .GridColumnStyles(M_AASHWTable.COLUMN_NAME_PRICE_5).Alignment = HorizontalAlignment.Right
                                    .GridColumnStyles(M_AASHWTable.COLUMN_NAME_PRICE_0MC).Alignment = HorizontalAlignment.Right
                                    .GridColumnStyles(M_AASHWTable.COLUMN_NAME_PRICE_08A).Alignment = HorizontalAlignment.Right
                                    .GridColumnStyles(M_AASHWTable.COLUMN_NAME_PRICE_09A).Alignment = HorizontalAlignment.Right
                                End With
                            Case M_AASSWTable.TABLE_NAME
                                With Grd_Master.TableStyles(M_AASSWTable.TABLE_NAME)
                                    .GridColumnStyles(M_AASSWTable.COLUMN_NAME_PRICE_0).Alignment = HorizontalAlignment.Right
                                    .GridColumnStyles(M_AASSWTable.COLUMN_NAME_PRICE_02B).Alignment = HorizontalAlignment.Right
                                End With
                            Case BasicSelection.TABLE_NAME
                                With Grd_Master.TableStyles(BasicSelection.TABLE_NAME)
                                    .GridColumnStyles(BasicSelection.COLUMN_NAME_0EA).Alignment = HorizontalAlignment.Right
                                    .GridColumnStyles(BasicSelection.COLUMN_NAME_0EB).Alignment = HorizontalAlignment.Right
                                    .GridColumnStyles(BasicSelection.COLUMN_NAME_0EC).Alignment = HorizontalAlignment.Right
                                    .GridColumnStyles(BasicSelection.COLUMN_NAME_0ED).Alignment = HorizontalAlignment.Right
                                    .GridColumnStyles(BasicSelection.COLUMN_NAME_0EE).Alignment = HorizontalAlignment.Right
                                    .GridColumnStyles(BasicSelection.COLUMN_NAME_0EF).Alignment = HorizontalAlignment.Right
                                End With
                        End Select

                        waitDialog2.PerformStep()
                        waitDialog2.Close()

                        Me.Activate()

                        '0���̏ꍇ�͏����I��
                        If Lbl_RecCnt.Text = "0 / 0" Then
                            MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0519"), sender.Text)

                            Exit Sub
                        End If

                        MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0001"), sender.Text)
                    Else
                        Exit Sub
                    End If

                Case OpenPriceTable.TABLE_NAME,
                    WcatTable.TABLE_NAME,
                    BusinessTypeTable.TABLE_NAME

                    '�uCSV�Ǎ��v���������s����
                    If Me.Cmb_MasterName.Text.Equals(String.Empty) Then
                        Me.Cmb_MasterName.Focus()
                        Throw New MuseException(Me.lbl_MasterName.Text & FileReader.GetMessage("MSG_0018"))
                    End If

                    Dim dialog As OpenFileDialog = New OpenFileDialog
                    dialog.Filter = "csv files (*.csv)|*.csv"
                    dialog.Multiselect = True '�����I���Ƃ���B

                    ''Windows7�ɁuC:\Documents and Settings�v�̃t�H���_���Ȃ����߁A���[�U�[�����ɂ���B
                    If CommonVariable.OSVERSION = CommonConstant.OS_WINDOWS7 Then
                        dialog.InitialDirectory = "C:\Users"
                    Else
                        dialog.InitialDirectory = "C:\Documents and Settings"
                    End If

                    If dialog.ShowDialog() = DialogResult.OK Then
                        Me.Refresh()
                        Me.Cursor = Cursors.WaitCursor

                        '�������_�C�A���O�\��
                        waitDialog2.Text = STR_READING
                        waitDialog2.lbl_Message.Text = STR_MESSAGE_READ_CSV
                        waitDialog2.Pic_Folder.Visible = True
                        waitDialog2.ProgressMin = 0
                        waitDialog2.ProgressMax = 3
                        waitDialog2.ProgressStep = 1
                        waitDialog2.ProgressValue = 0
                        waitDialog2.Show()
                        waitDialog2.Refresh()

                        '==============================
                        '���}�X�^�t�@�C��(CSV)�Ǎ�������
                        '==============================
                        Dim masterData As DataTable
                        If Me.Rdo_CsvReadType_All.Checked = True Then
                            '���Ǎ��`���S���̏ꍇ
                            masterData = CType(Me.Grd_Master.DataSource, DataTable).Clone
                        ElseIf Me.Rdo_CsvReadType_Diff.Checked = True Then
                            '���Ǎ��`�������̏ꍇ
                            masterData = CType(Me.Grd_Master.DataSource, DataTable)
                            '�p�t�H�[�}���X���ቺ����ׁA�f�[�^�\�[�X�̊��蓖�Ă���������B
                            Me.Grd_Master.DataSource = Nothing
                        End If

                        waitDialog2.PerformStep()

                        Select Case Me.Cmb_MasterName.Text
                            Case OpenPriceTable.TABLE_NAME
                                Call CsvReadOpenPrice(dialog.FileName.ToString, masterData)
                            Case WcatTable.TABLE_NAME
                                Call CsvReadWcat(dialog.FileName.ToString, masterData)
                            Case BusinessTypeTable.TABLE_NAME
                                Call CsvReadBusinessType(dialog.FileName.ToString, masterData)
                        End Select
                        waitDialog2.PerformStep()

                        '�X�e�[�^�X��ҏW
                        Dim row As DataRow
                        For Each row In masterData.Rows
                            If row.RowState = DataRowState.Added Then
                                If row.Item(MASTER_COLUMN_NAME_STATUS).ToString().Equals(String.Empty) Then
                                    row.Item(MASTER_COLUMN_NAME_STATUS) = STATUS_INSERT
                                End If
                            End If
                        Next

                        '�f�[�^�\�[�X�Ɋ��蓖��
                        Me.Grd_Master.DataSource = masterData
                        waitDialog2.PerformStep()

                        Me.Refresh()
                        Me.Cursor = Cursors.Default

                        waitDialog2.Close()

                        '0���̏ꍇ�͏����I��
                        If Lbl_RecCnt.Text = "0 / 0" Then
                            MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0519"), sender.Text)

                            Exit Sub
                        End If

                        '�����I�����b�Z�[�W�\��
                        Me.Activate()
                        MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0001"), sender.Text)

                        Me._dialogInitialPath = Path.GetDirectoryName(dialog.FileName)
                    Else
                        Exit Sub
                    End If

            End Select

            If MuseMessageBox.ShowQuestion(FileReader.GetMessage("MSG_0039"), sender.Text) = DialogResult.OK Then
                Me.Refresh()
                Me.Cursor = Cursors.WaitCursor

                '�������_�C�A���O�\��
                waitDialog.Text = Me.STR_UPDATING
                waitDialog.lbl_Message.Text = Me.STR_MESSAGE_UPDATE_TABLE
                waitDialog.Pic_Folder.Visible = True
                waitDialog.ProgressMin = 0
                waitDialog.ProgressMax = 3
                waitDialog.ProgressStep = 1
                waitDialog.ProgressValue = 0
                waitDialog.Show()
                waitDialog.Refresh()

                '==============================
                'WebService�Ŏ擾�ł���e�[�u���ɑ΂��ăL�[�̃`�F�b�N���s��
                '==============================
                Dim blnRet As Boolean
                blnRet = CheckWebData()
                If blnRet = False Then
                    Me.Activate()
                    waitDialog.Close()
                    Me.Cursor = Cursors.Default
                    Exit Sub
                End If

                '==============================
                '���}�X�^�X�V������
                '==============================
                Dim masterData As DataTable
                Dim row As DataRow
                masterData = CType(Me.Grd_Master.DataSource, DataTable)
                '�O���b�h�ɕ\������Ă���f�[�^�����[�N�e�[�u�����f����B
                '�폜���R�[�h�̔��f
                masterData.AcceptChanges()
                For Each row In masterData.Rows
                    Select Case Me.Cmb_MasterName.Text
                        Case M_CONTRACT_BASETable.TABLE_NAME,
                            M_CONTRACT_DETAILTable.TABLE_NAME,
                            M_CONTRACT_TEMP.TABLE_NAME,
                            M_PLANTable.TABLE_NAME
                            Dim strStatus As String = row.Item(Me.MASTER_COLUMN_NAME_STATUS).ToString()
                            If strStatus <> Me.STATUS_INSERT And strStatus <> Me.STATUS_MODIFY Then
                                row.Delete()
                            End If
                        Case Else
                            If row.Item(Me.MASTER_COLUMN_NAME_STATUS).ToString().Equals(Me.STATUS_DELETE) Then
                                row.Delete()
                            End If
                    End Select
                Next
                masterData.AcceptChanges()

                waitDialog.PerformStep()

                '�}�X�^�X�V
                Dim fError As Boolean = False
                Me.UpdateMasterData(masterData, fError)
                '��������̏ꍇ�͏����I��
                If fError = True Then
                    waitDialog.Close()
                    MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0520"), sender.Text)

                    '�O���b�h�Ƀ}�X�^�f�[�^�ݒ�
                    Me.SetMasterData(Me.Cmb_MasterName.Text)

                    Me.Cursor = Cursors.Default
                    Me._updateFlg = True

                    Exit Sub
                End If

                waitDialog.PerformStep()

                '�O���b�h�Ƀ}�X�^�f�[�^�ݒ�
                Me.SetMasterData(Me.Cmb_MasterName.Text)
                waitDialog.PerformStep()

                waitDialog.Close()

                Me.Refresh()
                Me.Cursor = Cursors.Default

                '�X�V�t���OOFF
                Me._updateFlg = True

                Dim dt As DataTable
                If IsNothing(masterData) = False Then
                    _dtBeforeMaster = masterData.Copy
                End If

                '�����I�����b�Z�[�W�\��
                Me.Activate()
                MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0001"), sender.Text)
            End If

        Catch ex As MuseException
            Me.Activate()
            waitDialog.Close()
            Me.Cursor = Cursors.Default
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            waitDialog.Close()
            Me.Cursor = Cursors.Default
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Serch_Click
    '�T    �v  �FBtn_Serch�N���b�N����
    '��    ��  �FBtn_Serch�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Serch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Serch.Click

        Try
            If IsNothing(Me.Grd_Master.DataSource) = True Then
                Exit Sub
            End If

            Dim rowIndex As Integer
            Dim colIndex As Integer
            Dim lastRowIndex As Integer
            '�ŏI���R�[�h�ԍ��擾
            lastRowIndex = Me._bindManager.Count() - 1
            colIndex = Me.Cmb_SerchColumn.SelectedIndex + 1 '�X�e�[�^�X�񂪂���ׁA1�v���X����B

            '�O���b�h������
            For rowIndex = 0 To lastRowIndex
                '�O����v����
                If Me.Grd_Master.Item(rowIndex, colIndex).ToString().StartsWith(Me.Txt_SerchString.Text) Then
                    Me.Grd_Master.Focus()
                    Me.Grd_Master.CurrentCell = New DataGridCell(rowIndex, colIndex)
                    Exit For
                End If
            Next

            If rowIndex = lastRowIndex + 1 Then
                '�������q�b�g���Ȃ������ꍇ
                MuseMessageBox.ShowWarning(FileReader.GetMessage("MSG_0041"), sender.Text)
                Me.Txt_SerchString.Focus()
            End If

        Catch ex As MuseException
            Me.Activate()
            Me.Cursor = Cursors.Default
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            Me.Cursor = Cursors.Default
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FGrd_Master_CurrentCellChanged
    '�T    �v  �FGrd_Master�I���s�ύX����
    '��    ��  �FGrd_Master�I���s�ύX�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Grd_Master_CurrentCellChanged(ByVal sender As System.Object, ByVal e As EventArgs) Handles Grd_Master.CurrentCellChanged

        Try
            If IsNothing(sender.DataSource) = True Then
                Exit Sub
            End If

            '�s���ݒ�
            Me.Lbl_RecCnt.Text = (sender.CurrentRowIndex + 1).ToString() & _
                                Space(1) & CommonConstant.STR_SLASH & Space(1) & _
                                Me._bindManager.Count.ToString()

        Catch ex As MuseException
            Me.Activate()
            Me.Cursor = Cursors.Default
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            Me.Cursor = Cursors.Default
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FGrd_Master_DataSourceChanged
    '�T    �v  �FGrd_Master�f�[�^�\�[�X�ύX����
    '��    ��  �FGrd_Master�f�[�^�\�[�X�ύX�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Grd_Master_DataSourceChanged(ByVal sender As System.Object, ByVal e As EventArgs) Handles Grd_Master.DataSourceChanged

        Try
            '�����N���A
            Me.Lbl_RecCnt.Text = String.Empty
            '�����p�R���{�J�������N���A
            Me.Cmb_SerchColumn.Items.Clear()
            '����������N���A
            Me.Txt_SerchString.Text = String.Empty
            '�o�C���h���N���A
            Me._bindManager = Nothing

            'NET Framework 1.1�̃o�O�ׁ̈A�O���b�h�e�[�u���X�^�C���N���A
            'http://support.microsoft.com/kb/890211/
            If sender.TableStyles.Count > 0 Then
                sender.TableStyles(0).GridColumnStyles.Clear()
                sender.TableStyles.Clear()
            End If

            If IsNothing(sender.DataSource) = False Then
                '�o�C���h���擾
                Me._bindManager = Me.Grd_Master.BindingContext(sender.DataSource, sender.DataMember)

                '�O���b�h��ł̍폜���֎~����
                Dim cm As CurrencyManager
                cm = CType(Me._bindManager, CurrencyManager)
                Dim dv As DataView = CType(cm.List, DataView)
                dv.AllowDelete = False

                'DataGridTableStyle�̐ݒ�
                Me.SetMasterDataGridTableStyle()

                '�s���ݒ�
                Me.Lbl_RecCnt.Text = (sender.CurrentRowIndex + 1).ToString() & _
                                    Space(1) & CommonConstant.STR_SLASH & Space(1) & _
                                    Me._bindManager.Count.ToString()

                '�����p�R���{�J�������ݒ�
                Dim col As DataColumn
                For Each col In CType(sender.DataSource, DataTable).Columns()
                    If Not col.ColumnName.Equals(Me.MASTER_COLUMN_NAME_STATUS) Then
                        Me.Cmb_SerchColumn.Items.Add(col.ColumnName)
                    End If
                Next
                Me.Cmb_SerchColumn.SelectedIndex = 0
            End If

        Catch ex As MuseException
            Me.Activate()
            Me.Cursor = Cursors.Default
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            Me.Cursor = Cursors.Default
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FGridCell_KeyDown
    '�T    �v  �FGridCell�L�[��������
    '��    ��  �FGridCell�L�[�����������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub GridCell_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs)

        Try
            Dim currentRow As DataRow
            currentRow = CType(Me._bindManager.Current, DataRowView).Row

            If Not currentRow.Item(Me.MASTER_COLUMN_NAME_STATUS).ToString().Equals(String.Empty) Then
                '�����ɃX�e�[�^�X�ɒl���ݒ肳��Ă���ꍇ�͏����𔲂���
                Exit Sub
            End If

            If currentRow.RowState = DataRowState.Detached Then
                '���V�K�쐬�̏ꍇ
                currentRow.Item(Me.MASTER_COLUMN_NAME_STATUS) = Me.STATUS_INSERT
            Else
                If Me.Grd_Master.ReadOnly = False Then
                    currentRow.Item(Me.MASTER_COLUMN_NAME_STATUS) = Me.STATUS_MODIFY
                End If
            End If

        Catch ex As MuseException
            Me.Activate()
            Me.Cursor = Cursors.Default
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            Me.Cursor = Cursors.Default
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_LastRec_Click
    '�T    �v  �FBtn_LastRec�N���b�N����
    '��    ��  �FBtn_LastRec�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_LastRec_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_LastRec.Click

        Try
            If IsNothing(Me.Grd_Master.DataSource) = True Then
                Exit Sub
            End If

            '�ŏI���R�[�h�Ɉړ�
            Me.Grd_Master.CurrentRowIndex = Me._bindManager.Count() - 1
            Me.Grd_Master.Focus()

        Catch ex As MuseException
            Me.Activate()
            Me.Cursor = Cursors.Default
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            Me.Cursor = Cursors.Default
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_FirstRec_Click
    '�T    �v  �FBtn_FirstRec�N���b�N����
    '��    ��  �FBtn_FirstRec�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_FirstRec_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_FirstRec.Click

        Try
            If IsNothing(Me.Grd_Master.DataSource) = True Then
                Exit Sub
            End If

            '�擪���R�[�h�Ɉړ�
            Me.Grd_Master.CurrentRowIndex = 0
            Me.Grd_Master.Focus()

        Catch ex As MuseException
            Me.Activate()
            Me.Cursor = Cursors.Default
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            Me.Cursor = Cursors.Default
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Delete_Click
    '�T    �v  �FBtn_Delete�N���b�N����
    '��    ��  �FBtn_Delete�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click

        Try
            If IsNothing(Me.Grd_Master.DataSource) = True Then
                Exit Sub
            End If

            Dim index As Integer
            Dim lastIndex As Integer
            Dim currentIndex As Integer
            Dim row As DataRow
            Dim rowList As New ArrayList

            '�ŏI���R�[�h�ԍ��擾
            lastIndex = Me._bindManager.Count() - 1
            '�J�[�\�����������Ă��郌�R�[�h�ԍ��擾
            currentIndex = Me.Grd_Master.CurrentRowIndex

            For index = 0 To lastIndex
                '�s���I������Ă��邩���ׂ�
                If Me.Grd_Master.IsSelected(index) = True Or currentIndex = index Then
                    '���I������Ă��ꍇ
                    '�I���s�ɃJ�[�\�����ړ�������B���\�[�g����Ă����ꍇ�̑Ή�
                    Me.Grd_Master.CurrentRowIndex = index
                    '�I���s����U���X�g�Ɋi�[���X�e�[�^�X�񂪃\�[�g����Ă����ꍇ�̑Ή�
                    rowList.Add(CType(Me._bindManager.Current, DataRowView).Row)
                End If
            Next

            '�J�[�\���ʒu�����ɖ߂�
            Me.Grd_Master.CurrentRowIndex = currentIndex

            For Each row In rowList
                If row.Item(Me.MASTER_COLUMN_NAME_STATUS).ToString().Equals(Me.STATUS_DELETE) Then
                    '���ɍ폜�ɂȂ��Ă����ꍇ�͉�������B
                    Select Case row.RowState
                        Case DataRowState.Added
                            row.Item(Me.MASTER_COLUMN_NAME_STATUS) = STATUS_INSERT
                        Case DataRowState.Modified
                            row.Item(Me.MASTER_COLUMN_NAME_STATUS) = STATUS_MODIFY
                        Case Else
                            row.Item(Me.MASTER_COLUMN_NAME_STATUS) = String.Empty
                    End Select
                Else
                    row.Item(Me.MASTER_COLUMN_NAME_STATUS) = Me.STATUS_DELETE
                End If
            Next

            Me.Grd_Master.Focus()

        Catch ex As MuseException
            Me.Activate()
            Me.Cursor = Cursors.Default
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            Me.Cursor = Cursors.Default
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_ClearSort_Click
    '�T    �v  �FBtn_ClearSort�N���b�N����
    '��    ��  �FBtn_ClearSort�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_ClearSort_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_ClearSort.Click

        Try
            If Me.Grd_Master.TableStyles.Count > 0 Then
                '�\�[�g����U�L�����Z������B
                Me.Grd_Master.TableStyles(0).AllowSorting = False
                Me.Grd_Master.TableStyles(0).AllowSorting = True
            End If

        Catch ex As MuseException
            Me.Activate()
            Me.Cursor = Cursors.Default
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            Me.Cursor = Cursors.Default
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FchkOpenPrice_CheckedChanged
    '�T    �v  �FchkOpenPrice_CheckedChanged����
    '��    ��  �FchkOpenPrice_CheckedChanged�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub chkOpenPrice_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkOpenPrice.CheckedChanged

        If chkOpenPrice.Checked = True Then
            'Req.1737 2019/03 Str
            'Me.Rdo_CsvReadType_All.Checked = False
            Me.Rdo_CsvReadType_All.Checked = True
            Me.Rdo_CsvReadType_All.Enabled = False
            'Me.Rdo_CsvReadType_Diff.Checked = True
            Me.Rdo_CsvReadType_Diff.Checked = False
            'Req.1737 2019/03 End
            Me.Rdo_CsvReadType_Diff.Enabled = False
        Else
            Me.Rdo_CsvReadType_All.Enabled = True
            Me.Rdo_CsvReadType_Diff.Enabled = True
        End If

    End Sub

    '--------------------------------------------------------
    '���\�b�h���Fchk_Wcat_CheckedChanged
    '�T    �v  �Fchk_Wcat_CheckedChanged����
    '��    ��  �Fchk_Wcat_CheckedChanged�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub chk_Wcat_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk_Wcat.CheckedChanged
        If chk_Wcat.Checked = True Then
            Me.Rdo_CsvReadType_All.Checked = True
            Me.Rdo_CsvReadType_All.Enabled = False
            Me.Rdo_CsvReadType_Diff.Checked = False
            Me.Rdo_CsvReadType_Diff.Enabled = False
        Else
            Me.Rdo_CsvReadType_All.Enabled = True
            Me.Rdo_CsvReadType_Diff.Enabled = True
        End If

    End Sub

    ''' <summary>
    ''' �@�\�F�E��Ɍ��ݎ�����\������
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub tmNow_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmNow.Tick

        lblNow.Text = Date.Now.ToString("yyyy/MM/dd HH:mm:ss")

    End Sub

#End Region

#Region " �v���C�x�[�g���\�b�h "

    '--------------------------------------------------------
    '���\�b�h���FSetInitialData
    '�T    �v  �F������ʐݒ菈��
    '��    ��  �F������ʐݒ菈�����s��
    '��    ��  �F�Ȃ�
    '�� �� �l  �F�Ȃ�
    '--------------------------------------------------------
    Private Sub SetInitialData()

        '==============================================================
        '���R���{�{�b�N�X�ɒl�ݒ聞
        '==============================================================
        Dim control As New AdminControl

        '*�R���{�{�b�N�X�ݒ�p�̃e�[�u�����`
        Dim comboTable As New DataTable
        comboTable.Columns.Add(Me.COMBOTABLE_COLUMN_NAME_TEXT, Type.GetType("System.String"))
        comboTable.Columns.Add(Me.COMBOTABLE_COLUMN_NAME_VALUE, Type.GetType("System.String"))
        '�}�X�^��
        Me.SetComboCODE(Me.Cmb_MasterName, control.GetCodeData(CommonConstant.CODE_CLASSCODE_MASTER_NAME, CodeTable.COLUMN_NAME_ITEMVALUE, CommonVariable.MdbPW), True)
        Me.Cmb_MasterName.Text = String.Empty

        '�V�X�e�����Ǎ�
        Dim info As SystemInfo = FileReader.ReadSystemInfo()
        If info.TestFlg = CommonConstant.ParamCheck.Yes Then
            '���ؗp�̏ꍇ
            Me.UCnt_Pal00012.BackColor = Color.DimGray
            Me.UCnt_Pal00012.BackColro2 = Color.Silver
            Me.UCnt_Pal00012.TitleText = Me.UCnt_Pal00012.TitleText & Space(1) & Me.STR_TESTING
        End If

        ''MNT�ȊO�̌����́A�X�V���݂������ł��Ȃ��B
        Me.Btn_Update.Enabled = Autority.ChkEnableAuthority(Me._Role1, Me.Name, Me.Btn_Update.Name)

        '�X�V�t���OOFF
        Me._updateFlg = False

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FSetComboCODE
    '�T    �v  �F�R���{�{�b�N�X�l�ݒ菈��
    '��    ��  �F�R���{�{�b�N�X�l�ݒ菈�����s��
    '��    ��  �FCmbName     �FComboBox
    '�@�@�@�@�@�FdataSource  �F�R�[�h�f�[�^
    '�@�@�@�@�@�FBoolean     �F��s�L��
    '�� �� �l  �F�Ȃ�
    '--------------------------------------------------------
    Private Sub SetComboCODE(ByRef CmbName As Windows.Forms.ComboBox, ByVal dataSource As CodeTable, ByVal blBlank As Boolean)

        If blBlank = True Then
            '��s�ǉ�
            dataSource.Rows.InsertAt(dataSource.NewRow, 0)
        End If

        '�R���{�{�b�N�X�ɒl���Z�b�g����B
        CmbName.DataSource = dataSource
        CmbName.DisplayMember = dataSource.COLUMN_NAME_ITEMVALUE
        CmbName.ValueMember = dataSource.COLUMN_NAME_ITEMCODE

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FSetMasterData
    '�T    �v  �F�}�X�^�f�[�^�ݒ菈��
    '��    ��  �F�}�X�^�f�[�^�ݒ菈�����s��
    '��    ��  �FmasterName  �F�}�X�^��
    '�� �� �l  �F�Ȃ�
    '--------------------------------------------------------
    Private Sub SetMasterData(ByVal masterName As String)

        Dim masterData As DataTable

        '�}�X�^�擾
        Dim control As New AdminControl
        masterData = control.GetMasterData(masterName,
                                           CommonVariable.MdbPW,
                                           CommonVariable.USERID,
                                           CommonVariable.USERPW)

        If IsNothing(masterData) = False Then
            '�}�X�^�ɃX�^�[�^�X��ǉ�
            Dim col As New DataColumn
            col.ColumnName = Me.MASTER_COLUMN_NAME_STATUS
            masterData.Columns.Add(col)
        End If

        '�}�X�^���O���b�h�ɐݒ肷��B
        Me.Grd_Master.DataSource = masterData

        Select Case masterName
            Case M_QCOSTable.TABLE_NAME
                With Grd_Master.TableStyles(M_QCOSTable.TABLE_NAME)
                    .GridColumnStyles(M_QCOSTable.COLUMN_NAME_PRICE_S).Alignment = HorizontalAlignment.Right
                    .GridColumnStyles(M_QCOSTable.COLUMN_NAME_PRICE_M).Alignment = HorizontalAlignment.Right
                    .GridColumnStyles(M_QCOSTable.COLUMN_NAME_PRICE_3).Alignment = HorizontalAlignment.Right
                    .GridColumnStyles(M_QCOSTable.COLUMN_NAME_PRICE_8).Alignment = HorizontalAlignment.Right

                    Dim cs1 As DataGridTextBoxColumn = CType(.GridColumnStyles(M_QCOSTable.COLUMN_NAME_PRICE_S), DataGridTextBoxColumn)
                    Dim cs2 As DataGridTextBoxColumn = CType(.GridColumnStyles(M_QCOSTable.COLUMN_NAME_PRICE_M), DataGridTextBoxColumn)
                    Dim cs3 As DataGridTextBoxColumn = CType(.GridColumnStyles(M_QCOSTable.COLUMN_NAME_PRICE_3), DataGridTextBoxColumn)
                    Dim cs4 As DataGridTextBoxColumn = CType(.GridColumnStyles(M_QCOSTable.COLUMN_NAME_PRICE_8), DataGridTextBoxColumn)
                    cs1.Format = "#0"
                    cs2.Format = "#0"
                    cs3.Format = "#0"
                    cs4.Format = "#0"
                End With
            Case M_AASHWTable.TABLE_NAME
                With Grd_Master.TableStyles(M_AASHWTable.TABLE_NAME)
                    .GridColumnStyles(M_AASHWTable.COLUMN_NAME_PRICE_5).Alignment = HorizontalAlignment.Right
                    .GridColumnStyles(M_AASHWTable.COLUMN_NAME_PRICE_0MC).Alignment = HorizontalAlignment.Right
                    .GridColumnStyles(M_AASHWTable.COLUMN_NAME_PRICE_08A).Alignment = HorizontalAlignment.Right
                    .GridColumnStyles(M_AASHWTable.COLUMN_NAME_PRICE_09A).Alignment = HorizontalAlignment.Right

                    Dim cs1 As DataGridTextBoxColumn = CType(.GridColumnStyles(M_AASHWTable.COLUMN_NAME_PRICE_5), DataGridTextBoxColumn)
                    Dim cs2 As DataGridTextBoxColumn = CType(.GridColumnStyles(M_AASHWTable.COLUMN_NAME_PRICE_0MC), DataGridTextBoxColumn)
                    Dim cs3 As DataGridTextBoxColumn = CType(.GridColumnStyles(M_AASHWTable.COLUMN_NAME_PRICE_08A), DataGridTextBoxColumn)
                    Dim cs4 As DataGridTextBoxColumn = CType(.GridColumnStyles(M_AASHWTable.COLUMN_NAME_PRICE_09A), DataGridTextBoxColumn)
                    cs1.Format = "#0"
                    cs2.Format = "#0"
                    cs3.Format = "#0"
                    cs4.Format = "#0"
                End With
            Case M_AASSWTable.TABLE_NAME
                With Grd_Master.TableStyles(M_AASSWTable.TABLE_NAME)
                    .GridColumnStyles(M_AASSWTable.COLUMN_NAME_PRICE_0).Alignment = HorizontalAlignment.Right
                    .GridColumnStyles(M_AASSWTable.COLUMN_NAME_PRICE_02B).Alignment = HorizontalAlignment.Right

                    Dim cs1 As DataGridTextBoxColumn = CType(.GridColumnStyles(M_AASSWTable.COLUMN_NAME_PRICE_0), DataGridTextBoxColumn)
                    Dim cs2 As DataGridTextBoxColumn = CType(.GridColumnStyles(M_AASSWTable.COLUMN_NAME_PRICE_02B), DataGridTextBoxColumn)
                    cs1.Format = "#0"
                    cs2.Format = "#0"
                End With
            Case X_SoftWareTable.TABLE_NAME

            Case BasicSelection.TABLE_NAME
                With Grd_Master.TableStyles(BasicSelection.TABLE_NAME)
                    .GridColumnStyles(BasicSelection.COLUMN_NAME_0EA).Alignment = HorizontalAlignment.Right
                    .GridColumnStyles(BasicSelection.COLUMN_NAME_0EB).Alignment = HorizontalAlignment.Right
                    .GridColumnStyles(BasicSelection.COLUMN_NAME_0EC).Alignment = HorizontalAlignment.Right
                    .GridColumnStyles(BasicSelection.COLUMN_NAME_0ED).Alignment = HorizontalAlignment.Right
                    .GridColumnStyles(BasicSelection.COLUMN_NAME_0EE).Alignment = HorizontalAlignment.Right
                    .GridColumnStyles(BasicSelection.COLUMN_NAME_0EF).Alignment = HorizontalAlignment.Right
                End With
        End Select
    End Sub

    '--------------------------------------------------------
    '���\�b�h���FOutputEstimate
    '�T    �v  �F���Ϗ��o�͏���
    '��    ��  �F���Ϗ����o�͂���
    '��    ��  �FwaitDialog�F�҂����
    '�� �� �l  �F��������
    '--------------------------------------------------------
    Public Sub OutputCsv(ByVal fileName As String, ByVal masterData As DataTable)

        Dim control As New AdminControl

        '==============================
        '��CSV�o�́�
        '==============================
        control.OutputMasterCsv(fileName, masterData)

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FReadCsv
    '�T    �v  �FCSV�Ǎ�����
    '��    ��  �FCSV��Ǎ���
    '��    ��  �FwaitDialog�F�҂����
    '�� �� �l  �F�Ȃ�
    '--------------------------------------------------------
    Public Sub ReadCsv(ByVal csvFileNames As String(), ByRef masterData As DataTable)

        Dim control As New AdminControl

        '==============================
        '��CSV�Ǎ���
        '==============================
        control.SetCsvMasterData(csvFileNames, masterData)

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FReadServicePacWebCsv
    '�T    �v  �FCSV�Ǎ�����
    '��    ��  �FCSV��Ǎ���
    '��    ��  �FwaitDialog�F�҂����
    '�� �� �l  �F�Ȃ�
    '--------------------------------------------------------
    Public Sub ReadServicePacWebCsv(ByVal csvFileNames As String(), ByRef servicePacData As ServicePacTable)

        Dim control As New AdminControl

        '==============================
        '��CSV�Ǎ���
        '==============================
        control.SetCsvServicePacWebData(csvFileNames,
                                        servicePacData,
                                        CommonVariable.MdbPW)

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FUpdateMaster
    '�T    �v  �F�}�X�^�X�V����
    '��    ��  �F�}�X�^���X�V����
    '��    ��  �FmasterData�F�}�X�^�f�[�^
    '�� �� �l  �F�Ȃ�
    '--------------------------------------------------------
    Public Sub UpdateMasterData(ByVal masterData As DataTable, ByRef fError As Boolean)

        Dim control As New AdminControl

        '==============================
        '���}�X�^�X�V��
        '==============================
        control.UpdateMasterData(CommonVariable.USERID,
                                 CommonVariable.USERPW,
                                 CommonVariable.MdbPW,
                                 masterData,
                                 fError)

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FSetMasterDataGridTableStyle
    '�T    �v  �F�}�X�^�f�[�^�O���b�h�X�^�C���ݒ菈��
    '��    ��  �F�}�X�^�f�[�^�O���b�h�X�^�C���ݒ菈�����s��
    '��    ��  �F�Ȃ�
    '�� �� �l  �F�Ȃ�
    '--------------------------------------------------------
    Private Sub SetMasterDataGridTableStyle()

        Dim ts As New DataGridTableStyle
        '�}�b�v�����w�肷��
        ts.MappingName = CType(Me.Grd_Master.DataSource, DataTable).TableName
        '�X�e�[�^�X��̍쐬
        Dim ucnt_GridCol As New UserControl.UCnt_MasterDataGridTextBoxColumn
        ucnt_GridCol.MappingName = Me.MASTER_COLUMN_NAME_STATUS
        ucnt_GridCol.HeaderText = String.Empty
        ucnt_GridCol.NullText = String.Empty
        ucnt_GridCol.TextBox.Enabled = False
        ucnt_GridCol.Alignment = HorizontalAlignment.Center
        ucnt_GridCol.Width = 40
        '�X�e�[�^�X����e�[�u���X�^�C���ɒǉ�����
        ts.GridColumnStyles.Add(ucnt_GridCol)

        Dim col As DataColumn
        Dim gridCol As DataGridTextBoxColumn
        For Each col In CType(Me.Grd_Master.DataSource, DataTable).Columns()
            If Not col.ColumnName.Equals(Me.MASTER_COLUMN_NAME_STATUS) Then
                gridCol = New DataGridTextBoxColumn
                gridCol.MappingName = col.ColumnName
                gridCol.HeaderText = col.ColumnName
                '�Z����ł�KeyDown�C�x���g�n���h����ǉ�
                AddHandler (gridCol.TextBox).KeyDown, AddressOf Me.GridCell_KeyDown
                '����e�[�u���X�^�C���ɒǉ�����
                ts.GridColumnStyles.Add(gridCol)
            End If
        Next
        '��s�ɐF������
        ts.BackColor = Color.Gainsboro
        '�e�[�u���X�^�C����DataGrid�ɒǉ�����
        Me.Grd_Master.TableStyles.Add(ts)

    End Sub

    ''' <summary>
    ''' �T�v�F
    ''' �@�\�F
    ''' </summary>
    ''' <param name="strFile"></param>
    ''' <remarks></remarks>
    Private Sub CsvReadOpenPrice(ByVal strFile As String, ByRef masterData As OpenPriceTable) 'DataTable)
        Try
            '�f�[�^�ݒ�
            Dim csvOpenPriceData As New CsvOpenPriceTable
            '===============================
            'CSV�Ǎ��i���[�N�e�[�u���Ǎ��j
            '===============================
            Dim srCsv As New System.IO.StreamReader(strFile, System.Text.Encoding.GetEncoding("shift_jis"))
            Dim intCnt As Integer = 1

            While srCsv.Peek() > -1
                '�P�s�Ǎ�
                Dim arrItem() As String
                arrItem = srCsv.ReadLine().Split(",")

                If intCnt > 1 And arrItem.Length = 7 Then

                    ''---------------------------------------
                    ''�ȉ��A�f�[�^�e�[�u���̒l���Z�b�g
                    ''---------------------------------------
                    ''����̏�2�P�^��ǉ�
                    Dim EFDT As String
                    EFDT = arrItem(5).Trim
                    If EFDT.Length > 2 Then
                        If CInt(EFDT.Substring(0, 2)) >= 50 Then
                            EFDT = "19" & EFDT
                        Else
                            EFDT = "20" & EFDT
                        End If
                    End If

                    ''MachinType,Model,Feature�͐擪0����
                    Dim machinType As String = ""
                    Dim models As String = ""
                    Dim feature As String = ""

                    If arrItem(0).ToString.Trim <> "" Then
                        machinType = arrItem(0).ToString.PadLeft(4, "0")
                    End If

                    If arrItem(1).ToString.Trim() <> "" Then
                        models = arrItem(1).ToString.PadLeft(3, "0")
                    End If
                    If arrItem(2).ToString.Trim <> "" Then
                        feature = arrItem(2).ToString.PadLeft(4, "0")
                    End If

                    Dim row As DataRow
                    row = csvOpenPriceData.NewRow
                    row.Item(CsvOpenPriceTable.COLUMN_NAME_MACHINETYPE) = machinType
                    row.Item(CsvOpenPriceTable.COLUMN_NAME_MODEL) = models
                    row.Item(CsvOpenPriceTable.COLUMN_NAME_FEATURE_CODE) = feature
                    row.Item(CsvOpenPriceTable.COLUMN_NAME_UCD) = arrItem(3)
                    row.Item(CsvOpenPriceTable.COLUMN_NAME_PRICE_SEQ) = arrItem(4)
                    row.Item(CsvOpenPriceTable.COLUMN_NAME_EF_DATE) = EFDT
                    row.Item(CsvOpenPriceTable.COLUMN_NAME_PRICE) = arrItem(6)

                    csvOpenPriceData.Rows.Add(row)

                End If

                intCnt = intCnt + 1

            End While

            ''CSV�����A�捞�ΏۊO�̃f�[�^�����O����B
            csvOpenPriceData = DelDistinctOpenPriceData(csvOpenPriceData)

            '�R�~�b�g
            csvOpenPriceData.AcceptChanges()

            srCsv.Close()
            '===============================
            '�}�b�`���O�X�V����
            '===============================

            Dim NewRow As DataRow
            ''CSV��񃋁[�v

            'Req.1737 �C���ɔ����ăp�t�H�[�}���X�����������ߏC�� 2019/03 Str
            Dim svType As String = ""
            Dim svModel As String = ""
            Dim svFtr As String = ""
            Dim strSort As String = ""

            strSort = CsvOpenPriceTable.COLUMN_NAME_MACHINETYPE & "," & _
                      CsvOpenPriceTable.COLUMN_NAME_MODEL & "," & _
                      CsvOpenPriceTable.COLUMN_NAME_FEATURE_CODE

            'For Each row As DataRow In csvOpenPriceData.Rows
            For Each row As DataRow In csvOpenPriceData.Select("", strSort)

                'Dim filterOpenPrice As New StringBuilder
                'filterOpenPrice.Remove(0, filterOpenPrice.Length())
                'filterOpenPrice.Append(CsvOpenPriceTable.COLUMN_NAME_MACHINETYPE)
                'filterOpenPrice.Append(CommonConstant.SQL_STR_EQUAL)
                'filterOpenPrice.Append(StringEdit.EncloseSingleQuotation(row.Item(CsvOpenPriceTable.COLUMN_NAME_MACHINETYPE)))
                'filterOpenPrice.Append(CommonConstant.SQL_STR_AND)
                'filterOpenPrice.Append(CsvOpenPriceTable.COLUMN_NAME_MODEL)
                'filterOpenPrice.Append(CommonConstant.SQL_STR_EQUAL)
                'filterOpenPrice.Append(StringEdit.EncloseSingleQuotation(row.Item(CsvOpenPriceTable.COLUMN_NAME_MODEL)))
                'filterOpenPrice.Append(CommonConstant.SQL_STR_AND)
                'filterOpenPrice.Append(CsvOpenPriceTable.COLUMN_NAME_FEATURE_CODE)
                'filterOpenPrice.Append(CommonConstant.SQL_STR_EQUAL)
                'filterOpenPrice.Append(StringEdit.EncloseSingleQuotation(row.Item(CsvOpenPriceTable.COLUMN_NAME_FEATURE_CODE)))

                ''machineType,model,featureCd���d�����Ȃ��f�[�^�̂ݍ����ǉ�
                'If masterData.Select(filterOpenPrice.ToString).Length = 0 Then
                If svType <> row.Item(CsvOpenPriceTable.COLUMN_NAME_MACHINETYPE) Or _
                   svModel <> row(CsvOpenPriceTable.COLUMN_NAME_MODEL) Or _
                   svFtr <> row.Item(CsvOpenPriceTable.COLUMN_NAME_FEATURE_CODE) Then
                    'Req.1737 �C���ɔ����ăp�t�H�[�}���X�����������ߏC�� 2019/03 End

                    NewRow = masterData.NewRow
                    NewRow.Item(OpenPriceTable.COLUMN_NAME_MACHINETYPE) = row.Item(CsvOpenPriceTable.COLUMN_NAME_MACHINETYPE)
                    NewRow.Item(OpenPriceTable.COLUMN_NAME_MODEL) = row(CsvOpenPriceTable.COLUMN_NAME_MODEL)
                    NewRow.Item(OpenPriceTable.COLUMN_NAME_FEATURECODE) = row.Item(CsvOpenPriceTable.COLUMN_NAME_FEATURE_CODE)
                    NewRow.Item(OpenPriceTable.COLUMN_NAME_REFERENCEPRICE) = 0
                    masterData.Rows.Add(NewRow)

                End If
                'Req.1737 �C���ɔ����ăp�t�H�[�}���X�����������ߏC�� 2019/03 Str

                svType = row.Item(CsvOpenPriceTable.COLUMN_NAME_MACHINETYPE)
                svModel = row(CsvOpenPriceTable.COLUMN_NAME_MODEL)
                svFtr = row.Item(CsvOpenPriceTable.COLUMN_NAME_FEATURE_CODE)

                'Req.1737 �C���ɔ����ăp�t�H�[�}���X�����������ߏC�� 2019/03 End
            Next

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical)
        Finally
        End Try

    End Sub

    ''' <summary>
    ''' �T�v�FOpenPrice.csv���A�捞�ݑΏۊO�̃f�[�^���폜����B
    '''       �@�d������machinType�Amodel�Afeature�̏����폜
    '''       �A�ŐV���t��EF_DATE�f�[�^�݂̂�L���f�[�^�Ƃ���B
    '''       �B�捞�ݑΏۊO�̃f�[�^���폜����B
    ''' �@�\�F
    ''' </summary>
    ''' <remarks></remarks>
    Private Function DelDistinctOpenPriceData(ByVal csvOpenPriceData As DataTable) As DataTable

        Dim rtnTable As DataTable
        rtnTable = csvOpenPriceData.Clone

        ''machinType�Amodel�Afeature��KeyTable���쐬
        Dim distinctKeyTable As DataTable
        Dim tempDataView As DataView
        tempDataView = csvOpenPriceData.DefaultView
        distinctKeyTable = tempDataView.ToTable(True, CsvOpenPriceTable.COLUMN_NAME_MACHINETYPE, CsvOpenPriceTable.COLUMN_NAME_MODEL, CsvOpenPriceTable.COLUMN_NAME_FEATURE_CODE)

        ''�@EF_DATE���ŐV���t�ȊO�̓��t���폜
        ''�A�@�̃f�[�^�̂����A���O�����ɓ��Ă͂܂�f�[�^���폜
        Dim filter As New StringBuilder
        Dim sort As New StringBuilder

        For Each keyRow As DataRow In distinctKeyTable.Rows

            ''Key�e�[�u������v������̂��擾
            filter.Remove(0, filter.Length)
            filter.Append(CsvOpenPriceTable.COLUMN_NAME_MACHINETYPE)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(keyRow.Item(CsvOpenPriceTable.COLUMN_NAME_MACHINETYPE)))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append(CsvOpenPriceTable.COLUMN_NAME_MODEL)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(keyRow.Item(CsvOpenPriceTable.COLUMN_NAME_MODEL)))
            filter.Append(CommonConstant.SQL_STR_AND)
            filter.Append(CsvOpenPriceTable.COLUMN_NAME_FEATURE_CODE)
            filter.Append(CommonConstant.SQL_STR_EQUAL)
            filter.Append(StringEdit.EncloseSingleQuotation(keyRow.Item(CsvOpenPriceTable.COLUMN_NAME_FEATURE_CODE)))

            ''EF_DATE���ŐV���t�擾
            sort.Remove(0, sort.Length)
            sort.Append(CsvOpenPriceTable.COLUMN_NAME_EF_DATE)
            sort.Append(CommonConstant.SQL_STR_DESC)

            Dim newData As String = ""
            Dim isFirst As Boolean = True
            Dim addRow As DataRow
            For Each row As DataRow In csvOpenPriceData.Select(filter.ToString, sort.ToString)

                ''�ŐV�̓��t���擾
                If isFirst Then
                    newData = row.Item(CsvOpenPriceTable.COLUMN_NAME_EF_DATE)
                    isFirst = False
                End If

                ''�ŐV�̓��t�ȊO�̏ꍇ�A�폜
                If newData <> row.Item(CsvOpenPriceTable.COLUMN_NAME_EF_DATE) Then
                    Continue For
                End If

                ''�ȉ��A���O����
                'Req.1737 2019/03 Str
                ' ''PriceSEQ���󔒈ȊO�̏ꍇ
                'If row.Item(CsvOpenPriceTable.COLUMN_NAME_PRICE_SEQ).ToString.Trim <> "" Then
                '    Continue For
                'End If
                'Req.1737 2019/03 End

                ''UNIT CODE��"F","D"�ȊO�̏ꍇ
                If row.Item(CsvOpenPriceTable.COLUMN_NAME_UCD).ToString.Trim <> "F" And _
                    row.Item(CsvOpenPriceTable.COLUMN_NAME_UCD).ToString.Trim <> "D" Then
                    Continue For
                End If

                ''Price��3����'999'�ȊO�̏ꍇ
                If row.Item(CsvOpenPriceTable.COLUMN_NAME_PRICE).ToString.Length < 3 Then
                    Continue For
                End If
                If row.Item(CsvOpenPriceTable.COLUMN_NAME_PRICE).ToString.Substring(row(CsvOpenPriceTable.COLUMN_NAME_PRICE).ToString.Length - 3, 3) <> "999" Then
                    Continue For
                End If

                addRow = rtnTable.NewRow
                addRow.Item(CsvOpenPriceTable.COLUMN_NAME_MACHINETYPE) = row.Item(CsvOpenPriceTable.COLUMN_NAME_MACHINETYPE)
                addRow.Item(CsvOpenPriceTable.COLUMN_NAME_MODEL) = row.Item(CsvOpenPriceTable.COLUMN_NAME_MODEL)
                addRow.Item(CsvOpenPriceTable.COLUMN_NAME_FEATURE_CODE) = row.Item(CsvOpenPriceTable.COLUMN_NAME_FEATURE_CODE)
                addRow.Item(CsvOpenPriceTable.COLUMN_NAME_UCD) = row.Item(CsvOpenPriceTable.COLUMN_NAME_UCD)
                addRow.Item(CsvOpenPriceTable.COLUMN_NAME_EF_DATE) = row.Item(CsvOpenPriceTable.COLUMN_NAME_EF_DATE)
                addRow.Item(CsvOpenPriceTable.COLUMN_NAME_PRICE) = row.Item(CsvOpenPriceTable.COLUMN_NAME_PRICE)
                rtnTable.Rows.Add(addRow)

            Next
        Next

        Return rtnTable

    End Function

    ''' <summary>
    ''' �T�v�F
    ''' �@�\�F
    ''' </summary>
    ''' <param name="strFile"></param>
    ''' <remarks></remarks>
    Private Sub CsvReadWcat(ByVal strFile As String,
       ByRef masterData As DataTable)

        Try

            '�f�[�^�ݒ�
            Dim row As DataRow
            Dim workTable As New WcatTable

            ''������
            masterData.Rows.Clear()

            '===============================
            'CSV�Ǎ��i���[�N�e�[�u���Ǎ��j
            '===============================
            Dim srCsv As New System.IO.StreamReader(strFile, System.Text.Encoding.GetEncoding("shift_jis"))
            Dim strWork As String
            Dim intCnt As Integer = 1

            While srCsv.Peek() > -1
                '�P�s�Ǎ�
                Dim arrItem() As String
                arrItem = srCsv.ReadLine().Split(",")

                If intCnt > 1 And arrItem.Length = 3 Then

                    ''MachineType,Model���f���̃Z�b�g
                    Dim machinType As String
                    Dim model As String
                    Dim wcat As String
                    machinType = arrItem(0)
                    model = arrItem(1)
                    wcat = arrItem(2)

                    ''------------------------------------------
                    ''�ȉ��A�捞�ΏۊO
                    ''------------------------------------------
                    ''MachineType+Model��7���𒴂���ꍇ
                    If machinType.Length + model.Length > 7 Then
                        Continue While
                    End If

                    ''7���ȏ�Ŋ��A�����ȊO�Ŏn�܂�ꍇ
                    If machinType.Length + model.Length = 7 And _
                       IsNumeric(machinType.Substring(0, 1)) = False Then
                        Continue While
                    End If

                    ''�ۏ؊��Ԃ�0���͋󔒂̏ꍇ
                    If wcat.Trim = "" Then
                        Continue While
                    End If
                    If IsNumeric(wcat) AndAlso _
                        CInt(wcat) = 0 Then
                        Continue While
                    End If

                    ''QCOS���i�ł��AMachineType7���ȊO�̏ꍇ
                    If model.Trim = "" And _
                        machinType.Length <> 7 Then
                        Continue While
                    End If

                    ''------------------------------------------
                    ''�ȉ��A�f�[�^�̃Z�b�g
                    ''------------------------------------------
                    ''QCOS���i��MachineType7�����S���{�R���ɕ���
                    If model.Trim = "" And _
                        machinType.Length = 7 Then
                        model = machinType.Substring(4, 3)
                        machinType = machinType.Substring(0, 4)
                    End If

                    ''���[������
                    machinType = machinType.PadLeft(4, "0")
                    model = model.PadLeft(3, "0")

                    row = masterData.NewRow
                    row.Item(WcatTable.COLUMN_NAME_MACHINETYPE) = machinType
                    row.Item(WcatTable.COLUMN_NAME_MODEL) = model
                    row.Item(WcatTable.COLUMN_NAME_WCAT) = wcat

                    masterData.Rows.Add(row)

                End If

                intCnt = intCnt + 1

            End While

            srCsv.Close()

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical)
        Finally
        End Try

    End Sub

    ''' <summary>
    ''' �T�v�F
    ''' �@�\�F
    ''' </summary>
    ''' <param name="strFile"></param>
    ''' <remarks></remarks>
    Private Sub CsvReadBusinessType(ByVal strFile As String,
       ByRef masterData As DataTable)

        Try

            '�f�[�^�ݒ�
            Dim row As DataRow
            Dim workTable As New BusinessTypeTable

            ''������
            masterData.Rows.Clear()

            '===============================
            'CSV�Ǎ��i���[�N�e�[�u���Ǎ��j
            '===============================
            Dim srCsv As New System.IO.StreamReader(strFile, System.Text.Encoding.GetEncoding("shift_jis"))
            Dim strWork As String
            Dim intCnt As Integer = 1

            While srCsv.Peek() > -1
                '�P�s�Ǎ�
                Dim arrItem() As String
                arrItem = srCsv.ReadLine().Split(",")

                '2017/08 �����C�j�V�����ύX Str
                'If intCnt > 1 And arrItem.Length = 5 Then
                If intCnt > 1 And arrItem.Length = 6 Then
                    '2017/08 �����C�j�V�����ύX end

                    ''MachineType,Model���f���̃Z�b�g
                    Dim BUSINESSTYPEDATA As String
                    Dim LOBID As String
                    Dim BU As String
                    Dim BRAND As String
                    Dim SUBBRAND As String
                    Dim BusinessType As String
                    BUSINESSTYPEDATA = arrItem(0)
                    LOBID = arrItem(1)
                    BU = arrItem(2)
                    BRAND = arrItem(3)
                    SUBBRAND = arrItem(4)
                    '2017/08 �����C�j�V�����ύX Str
                    Dim BILLINITIAL As String
                    BILLINITIAL = arrItem(5)
                    '2017/08 �����C�j�V�����ύX end

                    ''------------------------------------------
                    ''�ȉ��A�捞�ΏۊO
                    ''------------------------------------------

                    ''------------------------------------------
                    ''�ȉ��A�f�[�^�̃Z�b�g
                    ''------------------------------------------

                    row = masterData.NewRow
                    row.Item(BusinessTypeTable.COLUMN_NAME_BUSINESSTYPE) = BUSINESSTYPEDATA.ToString.Trim
                    row.Item(BusinessTypeTable.COLUMN_NAME_LOBID) = LOBID.ToString.Trim
                    row.Item(BusinessTypeTable.COLUMN_NAME_BU) = BU.ToString.Trim
                    row.Item(BusinessTypeTable.COLUMN_NAME_BRAND) = BRAND.ToString.Trim
                    row.Item(BusinessTypeTable.COLUMN_NAME_SUBBRAND) = SUBBRAND.ToString.Trim
                    '2017/08 �����C�j�V�����ύX Str
                    row.Item(BusinessTypeTable.COLUMN_NAME_BILLINITIAL) = BILLINITIAL.ToString.Trim
                    '2017/08 �����C�j�V�����ύX End

                    masterData.Rows.Add(row)

                End If

                intCnt = intCnt + 1

            End While

            srCsv.Close()

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical)
        Finally
        End Try

    End Sub

    ''' <summary>
    ''' �T �v�F���O�A�E�g�{�^��
    ''' �� ���F���O�A�E�g�{�^��
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Btn_LogOut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_LogOut.Click
        ''�Ԓl�Z�b�g�@�����O�A�E�g�{�^���������̂ݕԒl��Ԃ�
        Me._rtnCd = Me.Btn_LogOut.Name
        Me.Close()
    End Sub

    ''' <summary>
    ''' �T �v�F�X�V�O�`�F�b�N
    ''' �� ���F
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Function ChkDispDate(ByVal MasterName As String) As Boolean

        Dim masterData As DataTable
        Dim strWork As String

        ChkDispDate = False

        masterData = CType(Me.Grd_Master.DataSource, DataTable)
        For i As Integer = 0 To masterData.Rows.Count - 1
            Select Case MasterName
                Case M_CONTRACT_BASETable.TABLE_NAME
                    '-----------------------------------
                    '�_���{���
                    '-----------------------------------
                    'CPNO
                    strWork = masterData.Rows(i).Item(M_CONTRACT_BASETable.COLUMN_NAME_CPNO).ToString.Trim
                    If strWork.Length <> 6 Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0272"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If
                    '�S�p�`�F�b�N
                    If strWork.Length <> System.Text.Encoding.GetEncoding("Shift_JIS").GetByteCount(strWork) Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0056"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If

                    ''���q�l������
                    strWork = ExcelWrite.changeDBNullToString(masterData.Rows(i).Item(M_CONTRACT_BASETable.COLUMN_NAME_CUST_NAME))
                    If strWork.Trim = "" Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0440"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If
                    'WindowsOS��̧�ٖ��Ɏg�p�ł��Ȃ����̂��Z�b�g����Ă��邩���肷��
                    If ExcelWrite.ChkNGCharInFileNM(strWork) = False Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0413"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If
                    '�������Byte�������s��
                    If ExcelWrite.ChkByteByEncode(strWork, "UTF-8", 256) = False Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0413"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If
                    '�T�C�Y
                    If strWork.Length > 110 Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0413"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If

                    'PA Anniversary Date�̃R�[�h�`�F�b�N
                    strWork = masterData.Rows(i).Item(M_CONTRACT_BASETable.COLUMN_NAME_PA_ANV_DATE).ToString    '.Trim
                    If Len(strWork) >= 3 Then       '�R���ȏ����
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0480"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If
                    Select Case Mid(strWork, 1, 1)
                        Case "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K"
                            Select Case Mid(strWork, 2, 1)
                                Case " ", "", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C"
                                Case Else   '�Q���ڂ��͈͊O����
                                    MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0480"), Me.Text)
                                    Me.Grd_Master.Select()
                                    Me.Grd_Master.CurrentRowIndex = i
                                    Exit Function
                            End Select
                        Case Else           '�P���ڂ��͈͊O����
                            MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0480"), Me.Text)
                            Me.Grd_Master.Select()
                            Me.Grd_Master.CurrentRowIndex = i
                            Exit Function
                    End Select

                    ''START_YEAR�`�F�b�N
                    strWork = ExcelWrite.changeDBNullToString(masterData.Rows(i).Item(M_CONTRACT_BASETable.COLUMN_NAME_START_YEAR))
                    If Not IsNumeric(strWork) Or _
                      (Val(strWork) > 9999 Or Val(strWork) < 1000) Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0053"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If
                    ''START_MONTH�`�F�b�N
                    strWork = ExcelWrite.changeDBNullToString(masterData.Rows(i).Item(M_CONTRACT_BASETable.COLUMN_NAME_START_MONTH))
                    If Not IsNumeric(strWork) Or _
                      (Val(strWork) > 12 Or Val(strWork) < 1) Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0053"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If
                    ''END_YEAR�`�F�b�N
                    strWork = ExcelWrite.changeDBNullToString(masterData.Rows(i).Item(M_CONTRACT_BASETable.COLUMN_NAME_END_YEAR))
                    If Not IsNumeric(strWork) Or _
                      (Val(strWork) > 9999 Or Val(strWork) < 1000) Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0053"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If
                    ''END_MONTH�`�F�b�N
                    strWork = ExcelWrite.changeDBNullToString(masterData.Rows(i).Item(M_CONTRACT_BASETable.COLUMN_NAME_END_MONTH))
                    If Not IsNumeric(strWork) Or _
                      (Val(strWork) > 12 Or Val(strWork) < 1) Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0053"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If
                    ''EXCEL_START�`�F�b�N
                    strWork = ExcelWrite.changeDBNullToString(masterData.Rows(i).Item(M_CONTRACT_BASETable.COLUMN_NAME_EXCEL_START))
                    If Not IsDate(Mid(strWork, 1, 4) & "/" & Mid(strWork, 5, 2) & "/01") Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0531"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If

                Case M_CONTRACT_DETAILTable.TABLE_NAME
                    '-----------------------------------
                    '�_��ڍ׏��
                    '-----------------------------------
                    'CPNO
                    strWork = masterData.Rows(i).Item(M_CONTRACT_DETAILTable.COLUMN_NAME_CPNO).ToString.Trim
                    If strWork.Length <> 6 Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0272"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If
                    '�S�p�`�F�b�N
                    If strWork.Length <> System.Text.Encoding.GetEncoding("Shift_JIS").GetByteCount(strWork) Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0056"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If
                    '�_�񏇔�
                    If IsNumeric(masterData.Rows(i).Item(M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_NO)) = False Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0438"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If
                    ''�͈̓`�F�b�N
                    strWork = masterData.Rows(i).Item(M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_NO)
                    If Val(strWork) > 999 Or Val(strWork) < 0 Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0439"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If
                    strWork = masterData.Rows(i).Item(M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_NO).ToString
                    If Integer.Parse(strWork) > 999 Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0439"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If

                Case M_PLANTable.TABLE_NAME
                    '-----------------------------------
                    '�Č����
                    '-----------------------------------
                    'CPNO
                    strWork = masterData.Rows(i).Item(M_PLANTable.COLUMN_NAME_CPNO).ToString.Trim
                    If strWork.Length <> 6 Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0272"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If
                    '�S�p�`�F�b�N
                    If strWork.Length <> System.Text.Encoding.GetEncoding("Shift_JIS").GetByteCount(strWork) Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0056"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If

                    ''�Č��ԍ������l���ǂ����`�F�b�N
                    'LEVEL1
                    If IsNumeric(masterData.Rows(i).Item(M_PLANTable.COLUMN_NAME_LEVEL1)) = False Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0331"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If
                    'LEVEL2
                    If IsNumeric(masterData.Rows(i).Item(M_PLANTable.COLUMN_NAME_LEVEL2)) = False Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0331"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If
                    'LEVEL3
                    If IsNumeric(masterData.Rows(i).Item(M_PLANTable.COLUMN_NAME_LEVEL3)) = False Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0331"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If
                    'LEVEL4
                    If IsNumeric(masterData.Rows(i).Item(M_PLANTable.COLUMN_NAME_LEVEL4)) = False Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0331"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If
                    'PLAN_NAME
                    If masterData.Rows(i).Item(M_PLANTable.COLUMN_NAME_PLAN_NAME).ToString.Trim = "" Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0441"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If

                Case CodeTable.TABLE_NAME
                    '-----------------------------------
                    'CODEð���
                    '-----------------------------------
                    'ClassCode
                    If masterData.Rows(i).Item(CodeTable.COLUMN_NAME_CLASSCODE).ToString.Trim = "" Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0436"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If
                    'OderNo
                    If IsNumeric(masterData.Rows(i).Item(CodeTable.COLUMN_NAME_ORDERNO)) = False Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0437"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If
                Case M_CONTRACT_TEMP.TABLE_NAME
                    '-----------------------------------
                    '���_����ð���
                    '-----------------------------------
                    'CPNO
                    strWork = masterData.Rows(i).Item(M_CONTRACT_TEMP.COLUMN_NAME_CPNO).ToString.Trim
                    If strWork.Length <> 6 Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0272"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If
                    '�S�p�`�F�b�N
                    If strWork.Length <> System.Text.Encoding.GetEncoding("Shift_JIS").GetByteCount(strWork) Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0056"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If
                    'OUT_CONTRACT_NO
                    strWork = masterData.Rows(i).Item(M_CONTRACT_TEMP.COLUMN_NAME_OUT_CONTRACT_NO).ToString.Trim
                    If IsNumeric(strWork) = False Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0454"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If
                    If Val(strWork) > 999 Or Val(strWork) < 0 Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0533"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If

                    masterData.Rows(i).Item(M_CONTRACT_TEMP.COLUMN_NAME_OUT_CONTRACT_NO) = strWork.PadLeft(3, "0"c)
                    'IN_CONTRACT_NO
                    strWork = masterData.Rows(i).Item(M_CONTRACT_TEMP.COLUMN_NAME_IN_CONTRACT_NO).ToString.Trim
                    If IsNumeric(strWork) = False Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0455"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If
                    If Integer.Parse(strWork) < 800 Or Integer.Parse(strWork) > 989 Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0456"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If
                    If Val(strWork) > 999 Or Val(strWork) < 0 Then
                        MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0534"), Me.Text)
                        Me.Grd_Master.Select()
                        Me.Grd_Master.CurrentRowIndex = i
                        Exit Function
                    End If
                    masterData.Rows(i).Item(M_CONTRACT_TEMP.COLUMN_NAME_IN_CONTRACT_NO) = strWork.PadLeft(3, "0"c)
            End Select
        Next

        ChkDispDate = True

    End Function

    '--------------------------------------------------------
    '�T    �v  �FCsv�o�͎��̃t�H�[�}�b�g��ύX����B
    '��    ��  �F
    '--------------------------------------------------------
    Private Sub ChgFormatDataTable(ByVal TableNM As String, _
                                   ByRef masterData As DataTable)

        Select Case TableNM
            Case M_PLANTable.TABLE_NAME
                ''�Č����̂́u"�v�Ŋ���
                For Each row As DataRow In masterData.Rows
                    row.Item(M_PLANTable.COLUMN_NAME_PLAN_NAME) = """" & ExcelWrite.changeDBNullToString(row.Item(M_PLANTable.COLUMN_NAME_PLAN_NAME)) & """"
                Next
            Case M_MVMSTable.TABLE_NAME
                '�Č����̂́u"�v�Ŋ���
                For Each row As DataRow In masterData.Rows
                    row.Item(M_MVMSTable.COLUMN_NAME_PGMNMJ) = """" & ExcelWrite.changeDBNullToString(row.Item(M_MVMSTable.COLUMN_NAME_PGMNMJ)) & """"
                Next
            Case M_PA_MEDIATable.TABLE_NAME
                '�Č����̂́u"�v�Ŋ���
                For Each row As DataRow In masterData.Rows
                    row.Item(M_PA_MEDIATable.COLUMN_NAME_PROD_NAME) = """" & ExcelWrite.changeDBNullToString(row.Item(M_PA_MEDIATable.COLUMN_NAME_PROD_NAME)) & """"
                Next
            Case M_VLSTable.TABLE_NAME
                '�Č����̂́u"�v�Ŋ���
                For Each row As DataRow In masterData.Rows
                    row.Item(M_VLSTable.COLUMN_NAME_PRICE_PRODNAME) = """" & ExcelWrite.changeDBNullToString(row.Item(M_VLSTable.COLUMN_NAME_PRICE_PRODNAME)) & """"
                Next
            Case Else
        End Select

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FSetM_PlanData
    '�T    �v  �FCSV����l���擾���A�f�[�^�e�[�u���Ɋi�[����
    '��    ��  �F
    '--------------------------------------------------------
    Public Sub SetM_PlanData(ByVal csvFileName As String, ByRef masterData As DataTable)

        'CSV�t�@�C���Ǎ�
        Dim reader As New StreamReader(csvFileName, Encoding.GetEncoding(CommonConstant.ENCODE_SHIFT_JIS))

        Dim row As DataRow
        Dim col As DataColumn
        Dim strLine As String       '�P�s
        Dim strArray() As String     '�߂�z��
        Dim colIndex As Integer
        Dim colIndexList As New Hashtable '��ʒu�i�[�n�b�V���e�[�u��

        While (reader.Peek() > -1)
            '�ǂݍ���
            strLine = reader.ReadLine()
            '�J���}�����ŕ������A�z��֊i�[
            If SplitData(strLine, strArray) = False Then
                Exit Sub
            End If

            If colIndexList.Count = 0 Then
                For Each col In masterData.Columns
                    colIndex = Array.IndexOf(strArray, col.ColumnName)
                    If colIndex <> -1 Then
                        If colIndexList.Contains(col.ColumnName) = False Then
                            '���J���������i�[����Ă��Ȃ��ꍇ
                            colIndexList.Add(col.ColumnName, colIndex)
                        End If
                    End If
                Next
            Else
                '�e�[�u���Ƀf�[�^�ǉ�
                row = masterData.NewRow
                For Each col In masterData.Columns
                    If colIndexList.Contains(col.ColumnName) = True Then

                        colIndex = CType(colIndexList(col.ColumnName), Integer)
                        Select Case colIndex
                            Case CType(colIndexList(M_PLANTable.COLUMN_NAME_LEVEL1), Integer),
                                 CType(colIndexList(M_PLANTable.COLUMN_NAME_LEVEL2), Integer),
                                 CType(colIndexList(M_PLANTable.COLUMN_NAME_LEVEL3), Integer),
                                 CType(colIndexList(M_PLANTable.COLUMN_NAME_LEVEL4), Integer)
                                ''�Č��ԍ���0���߂ŕ\��
                                row.Item(col.ColumnName) = StringEdit.GetArrayValue(strArray, colIndex).PadLeft(2, "0")

                            Case CType(colIndexList(M_PLANTable.COLUMN_NAME_PLAN_NAME), Integer)
                                Dim planNM As String
                                Dim strLen As Integer
                                Dim endLen As Integer
                                planNM = StringEdit.GetArrayValue(strArray, colIndex).PadLeft(2, "0")
                                If planNM.Length >= 2 Then
                                    If planNM.Substring(0, 1) <> """" Then
                                        strLen = 0
                                    Else
                                        strLen = 1
                                    End If
                                    If planNM.Substring(planNM.Length - 1, 1) <> """" Then
                                        endLen = planNM.Length - strLen
                                    Else
                                        endLen = planNM.Length - strLen - 1
                                    End If
                                    planNM = planNM.Substring(strLen, endLen)
                                End If
                                row.Item(col.ColumnName) = planNM
                            Case Else
                                row.Item(col.ColumnName) = StringEdit.GetArrayValue(strArray, colIndex)

                        End Select

                    End If
                Next
                masterData.Rows.Add(row)
            End If
        End While

        '�t�@�C���̃N���[�Y
        reader.Close()

    End Sub


    ''' <summary>
    ''' �@�@�\�F�J���}��؂�̃f�[�^�𕪉�����
    ''' ���@���F�_�u���N�H�[�e�[�V�������̃J���}���Ή�����
    ''' </summary>
    ''' <param name="strData">���f�[�^</param>
    ''' <param name="strSplitData">������f�[�^</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function SplitData(ByVal strData As String, ByRef strSplitData() As String) As Boolean

        Const DELIMITA As String = ","
        Dim strSplitDelemita() As String        '
        Dim intCnt As Integer                   '
        Dim intIndex As Integer = 0             '
        Dim strWork As String                   '
        Dim intNextDataCtn As Integer           '
        Dim intStartCnt As Integer              '
        Dim intStepCnt As Integer               '
        Dim strComcatData As String             '
        Dim blnComcatData As Boolean            '

        SplitData = False

        '�J���}��؂�𕪉�����
        strSplitDelemita = strData.Split(DELIMITA)

        '���������f�[�^���`�F�b�N����
        For intCnt = 0 To strSplitDelemita.Length - 1
            '���[�Ƀ_�u���N�H�[�e�[�V���������邩
            If Microsoft.VisualBasic.Strings.Left(LTrim(strSplitDelemita(intCnt)), 1) = """" Then
                '�E�[�Ƀ_�u���N�H�[�e�[�V�������o��܂ŌJ��Ԃ�
                intStartCnt = intCnt + 1
                intStepCnt = 0
                strComcatData = ""
                blnComcatData = False
                For intNextDataCtn = intStartCnt To (strSplitDelemita.Length - 1)
                    '���̃f�[�^���܂����邩
                    If intNextDataCtn <= (strSplitDelemita.Length - 1) Then
                        '�E�[�Ƀ_�u���N�H�[�e�[�V���������邩
                        If Microsoft.VisualBasic.Strings.Right(RTrim(strSplitDelemita(intNextDataCtn)), 1) = """" Then
                            '���f�[�^�{�����f�[�^�{�J���}�{���f�[�^����������
                            strWork = strSplitDelemita(intCnt) & strComcatData & DELIMITA & strSplitDelemita(intNextDataCtn)
                            ReDim Preserve strSplitData(intIndex)
                            strSplitData(intIndex) = strWork.Replace("""", "")
                            intCnt = intCnt + intStepCnt + 1
                            intIndex = intIndex + 1
                            blnComcatData = True
                            Exit For
                        Else
                            strComcatData = strComcatData & DELIMITA & strSplitDelemita(intNextDataCtn)
                            intStepCnt = intStepCnt + 1
                        End If
                    End If
                Next

                '�E�[�Ƀf�[�^���Ȃ������ꍇ�A�ʏ�f�[�^�Ƃ��Ĉ���
                If blnComcatData = False Then
                    ReDim Preserve strSplitData(intIndex)
                    strSplitData(intIndex) = strSplitDelemita(intCnt)
                    intIndex = intIndex + 1
                End If
            Else
                '�_�u���N�H�[�e�[�V�������Ȃ��ꍇ
                ReDim Preserve strSplitData(intIndex)
                strSplitData(intIndex) = strSplitDelemita(intCnt)
                intIndex = intIndex + 1
            End If
        Next

        SplitData = True

    End Function

    ''' <summary>
    ''' �@�\�FWebService�Ŏ擾�ł���e�[�u���ɑ΂��ăL�[�̃`�F�b�N���s��
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckWebData() As Boolean

        Dim dt As DataTable
        Dim row As DataRow
        Dim rows() As DataRow
        Dim strTableName As String
        Dim strStatus As String
        Dim sbFilter As New StringBuilder
        Dim strWork As String

        CheckWebData = False

        Try
            dt = CType(Me.Grd_Master.DataSource, DataTable)

            '�啶�������������ON
            dt.CaseSensitive = True

            strTableName = Me.Cmb_MasterName.Text

            For Each row In dt.Rows
                sbFilter.Remove(0, sbFilter.Length())
                '�X�e�[�^�X�擾
                strStatus = row.Item(Me.MASTER_COLUMN_NAME_STATUS).ToString()
                If strStatus = Me.STATUS_INSERT Or strStatus = Me.STATUS_MODIFY Then
                    Select Case strTableName
                        Case M_CONTRACT_BASETable.TABLE_NAME
                            sbFilter.Append(M_CONTRACT_BASETable.COLUMN_NAME_CPNO)
                            sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
                            sbFilter.Append(StringEdit.EncloseSingleQuotation(row(M_CONTRACT_BASETable.COLUMN_NAME_CPNO)))
                        Case M_CONTRACT_DETAILTable.TABLE_NAME
                            sbFilter.Append(M_CONTRACT_DETAILTable.COLUMN_NAME_CPNO)
                            sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
                            sbFilter.Append(StringEdit.EncloseSingleQuotation(row(M_CONTRACT_DETAILTable.COLUMN_NAME_CPNO)))
                            sbFilter.Append(CommonConstant.SQL_STR_AND)
                            sbFilter.Append(M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_NO)
                            sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
                            sbFilter.Append(StringEdit.EncloseSingleQuotation(row(M_CONTRACT_DETAILTable.COLUMN_NAME_CONTRACT_NO)))
                        Case M_CONTRACT_TEMP.TABLE_NAME
                            sbFilter.Append(M_CONTRACT_TEMP.COLUMN_NAME_CPNO)
                            sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
                            sbFilter.Append(StringEdit.EncloseSingleQuotation(row(M_CONTRACT_TEMP.COLUMN_NAME_CPNO)))
                            sbFilter.Append(CommonConstant.SQL_STR_AND)
                            sbFilter.Append(M_CONTRACT_TEMP.COLUMN_NAME_OUT_CONTRACT_NO)
                            sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
                            sbFilter.Append(StringEdit.EncloseSingleQuotation(row(M_CONTRACT_TEMP.COLUMN_NAME_OUT_CONTRACT_NO)))
                            sbFilter.Append(CommonConstant.SQL_STR_AND)
                            sbFilter.Append(M_CONTRACT_TEMP.COLUMN_NAME_IN_CONTRACT_NO)
                            sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
                            sbFilter.Append(StringEdit.EncloseSingleQuotation(row(M_CONTRACT_TEMP.COLUMN_NAME_IN_CONTRACT_NO)))
                        Case M_PLANTable.TABLE_NAME
                            sbFilter.Append(M_PLANTable.COLUMN_NAME_CPNO)
                            sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
                            sbFilter.Append(StringEdit.EncloseSingleQuotation(row(M_PLANTable.COLUMN_NAME_CPNO)))
                            sbFilter.Append(CommonConstant.SQL_STR_AND)
                            sbFilter.Append(M_PLANTable.COLUMN_NAME_LEVEL1)
                            sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
                            sbFilter.Append(StringEdit.EncloseSingleQuotation(row(M_PLANTable.COLUMN_NAME_LEVEL1)))
                            sbFilter.Append(CommonConstant.SQL_STR_AND)
                            sbFilter.Append(M_PLANTable.COLUMN_NAME_LEVEL2)
                            sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
                            sbFilter.Append(StringEdit.EncloseSingleQuotation(row(M_PLANTable.COLUMN_NAME_LEVEL2)))
                            sbFilter.Append(CommonConstant.SQL_STR_AND)
                            sbFilter.Append(M_PLANTable.COLUMN_NAME_LEVEL3)
                            sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
                            sbFilter.Append(StringEdit.EncloseSingleQuotation(row(M_PLANTable.COLUMN_NAME_LEVEL3)))
                            sbFilter.Append(CommonConstant.SQL_STR_AND)
                            sbFilter.Append(M_PLANTable.COLUMN_NAME_LEVEL4)
                            sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
                            sbFilter.Append(StringEdit.EncloseSingleQuotation(row(M_PLANTable.COLUMN_NAME_LEVEL4)))
                            sbFilter.Append(CommonConstant.SQL_STR_AND)
                            sbFilter.Append(M_PLANTable.COLUMN_NAME_PLAN_NAME)
                            sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
                            sbFilter.Append(StringEdit.EncloseSingleQuotation(row(M_PLANTable.COLUMN_NAME_PLAN_NAME)))
                    End Select
                    If sbFilter.Length > 0 Then
                        '�L�[�d���`�F�b�N
                        rows = dt.Select(sbFilter.ToString)
                        If rows.Length > 1 Then
                            MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0434"), "CheckWebData")
                            Exit Function
                        End If

                        '�ύX�O�`�F�b�N
                        If strStatus = Me.STATUS_MODIFY Then
                            rows = _dtBeforeMaster.Select(sbFilter.ToString)
                            If rows.Length = 0 Then
                                MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0435"), "CheckWebData")
                                Exit Function
                            End If
                        End If
                    End If
                End If
            Next

            CheckWebData = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, "CheckWebData")

        End Try

    End Function

    ''' <summary>
    ''' �T�v�F
    ''' �@�\�F
    ''' </summary>
    ''' <param name="strFile"></param>
    ''' <remarks></remarks>
    Private Sub CsvReadNonSBO(ByVal strFile As String, ByRef masterData As DataTable)
        Try
            '�u�S���v�w��̏ꍇ�A�f�[�^������������B
            If Me.Rdo_CsvReadType_All.Checked = True Then
                masterData.Clear()
            End If

            '===============================
            'CSV�Ǎ��i���[�N�e�[�u���Ǎ��j
            '===============================
            Dim srCsv As New System.IO.StreamReader(strFile, System.Text.Encoding.GetEncoding("shift_jis"))
            Dim intCnt As Integer = 1

            While srCsv.Peek() > -1
                '�P�s�Ǎ�
                Dim arrItem() As String
                arrItem = srCsv.ReadLine().Split(",")

                If intCnt > 1 And arrItem.Length = 1 Then

                    Dim NewRow As DataRow

                    If Me.Rdo_CsvReadType_All.Checked = True Then
                        '���Ǎ��`���S���̏ꍇ
                        ''---------------------------------------
                        ''�f�[�^�e�[�u���̒l���Z�b�g
                        ''---------------------------------------
                        NewRow = masterData.NewRow
                        NewRow.Item(CsvNonSBOTable.COLUMN_NAME_MTDL) = arrItem(0)
                        NewRow.Item(Me.MASTER_COLUMN_NAME_STATUS) = Me.STATUS_INSERT

                        masterData.Rows.Add(NewRow)

                    ElseIf Me.Rdo_CsvReadType_Diff.Checked = True Then
                        '���Ǎ��`�������̏ꍇ

                        Dim filter As New StringBuilder

                        filter.Remove(0, filter.Length())
                        filter.Append(CsvNonSBOTable.COLUMN_NAME_MTDL)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(arrItem(0)))

                        'MTDL���d�����Ȃ��f�[�^�͐V�K�s�Ƃ��Ēǉ�
                        If masterData.Select(filter.ToString).Length = 0 Then

                            NewRow = masterData.NewRow
                            NewRow.Item(CsvM_GroupTable.COLUMN_NAME_MTDL) = arrItem(0)
                            NewRow.Item(Me.MASTER_COLUMN_NAME_STATUS) = Me.STATUS_INSERT
                            masterData.Rows.Add(NewRow)
                        End If
                    End If
                End If

                intCnt = intCnt + 1
            End While

            '�R�~�b�g
            masterData.AcceptChanges()

            srCsv.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical)

        Finally

        End Try

    End Sub

    ''' <summary>
    ''' �T�v�F
    ''' �@�\�F
    ''' </summary>
    ''' <param name="strFile"></param>
    ''' <remarks></remarks>
    Private Sub CsvReadM_Group(ByVal strFile As String, ByRef masterData As DataTable)
        Try
            '�u�S���v�w��̏ꍇ�A�f�[�^������������B
            If Me.Rdo_CsvReadType_All.Checked = True Then
                masterData.Clear()
            End If

            '===============================
            'CSV�Ǎ��i���[�N�e�[�u���Ǎ��j
            '===============================
            Dim srCsv As New System.IO.StreamReader(strFile, System.Text.Encoding.GetEncoding("shift_jis"))
            Dim intCnt As Integer = 1

            While srCsv.Peek() > -1
                '�P�s�Ǎ�
                Dim arrItem() As String
                arrItem = srCsv.ReadLine().Split(",")

                If intCnt > 1 And arrItem.Length = 3 Then

                    Dim NewRow As DataRow

                    If Me.Rdo_CsvReadType_All.Checked = True Then
                        '���Ǎ��`���S���̏ꍇ
                        ''---------------------------------------
                        ''�f�[�^�e�[�u���̒l���Z�b�g
                        ''---------------------------------------
                        NewRow = masterData.NewRow
                        NewRow.Item(CsvM_GroupTable.COLUMN_NAME_MTDL) = arrItem(0)
                        NewRow.Item(CsvM_GroupTable.COLUMN_NAME_SUBBRAND) = arrItem(1)
                        NewRow.Item(CsvM_GroupTable.COLUMN_NAME_GROUPCODE) = arrItem(2)
                        NewRow.Item(Me.MASTER_COLUMN_NAME_STATUS) = Me.STATUS_INSERT

                        masterData.Rows.Add(NewRow)

                    ElseIf Me.Rdo_CsvReadType_Diff.Checked = True Then
                        '���Ǎ��`�������̏ꍇ

                        Dim filter As New StringBuilder

                        filter.Remove(0, filter.Length())
                        filter.Append(CsvM_GroupTable.COLUMN_NAME_MTDL)
                        filter.Append(CommonConstant.SQL_STR_EQUAL)
                        filter.Append(StringEdit.EncloseSingleQuotation(arrItem(0)))

                        'MTDL���d�����Ȃ��f�[�^�͐V�K�s�Ƃ��Ēǉ�
                        If masterData.Select(filter.ToString).Length = 0 Then

                            NewRow = masterData.NewRow
                            NewRow.Item(CsvM_GroupTable.COLUMN_NAME_MTDL) = arrItem(0)
                            NewRow.Item(CsvM_GroupTable.COLUMN_NAME_SUBBRAND) = arrItem(1)
                            NewRow.Item(CsvM_GroupTable.COLUMN_NAME_GROUPCODE) = arrItem(2)
                            NewRow.Item(Me.MASTER_COLUMN_NAME_STATUS) = Me.STATUS_INSERT
                            masterData.Rows.Add(NewRow)

                        ElseIf masterData.Select(filter.ToString).Length = 1 Then
                            'MTDL���d������f�[�^�͒u��������
                            Dim row As DataRow
                            Dim wInt As Integer = 0

                            '��v�s������
                            For Each row In masterData.Rows
                                If row.Item(CsvM_GroupTable.COLUMN_NAME_MTDL) = arrItem(0) Then
                                    '�������ꂽ�s�ʒu�ɁA�V�K�s�Ƃ��đ}��
                                    NewRow = masterData.NewRow
                                    NewRow.Item(CsvM_GroupTable.COLUMN_NAME_MTDL) = arrItem(0)
                                    NewRow.Item(CsvM_GroupTable.COLUMN_NAME_SUBBRAND) = arrItem(1)
                                    NewRow.Item(CsvM_GroupTable.COLUMN_NAME_GROUPCODE) = arrItem(2)
                                    NewRow.Item(Me.MASTER_COLUMN_NAME_STATUS) = Me.STATUS_MODIFY
                                    masterData.Rows.InsertAt(NewRow, wInt)

                                    Exit For
                                End If

                                wInt = wInt + 1
                            Next

                            '�����s���폜
                            masterData.Rows.RemoveAt(wInt + 1)
                        End If
                    End If
                End If

                intCnt = intCnt + 1
            End While

            '�R�~�b�g
            masterData.AcceptChanges()

            srCsv.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical)

        Finally

        End Try

    End Sub
#End Region

End Class