﻿Imports System.Text
Imports System.IO
Imports System.IO.StreamReader
Imports System.Data
Imports System.Data.OleDb
Imports System.Net
Imports System.Xml
Imports Microsoft.Office.Interop
Imports MUSE.Utility
Imports MUSE.Utility.OioBamaCommmon
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.SharedClass.ExcelWrite
Imports MUSE.Utility.UserDataTable.Master
Imports MUSE.Controller
Imports MUSE.Utility.UserMessageBox
Imports MUSE.Utility.XmlClass.ConnectionInfo
Imports MUSE.Utility.XmlClass.SheetFoumulate

Public Class Frm_AsrAll

#Region "Structure"
    'ファイル構成
    Private Structure TYP_FILE_FORMATION
        Dim Path As String                          'パス
        Dim FileName As String                      'ファイル名
        Dim WriteUpdate As String                   '更新日
    End Structure

    '一覧表のデータ構成
    Private Structure TYP_CPNODATA
        Dim Checked As Boolean                      'チェック判定
        Dim CpNo As String                          'CPNO
        Dim CustomerName As String                  'お客様名
        Dim ContractStart As String                 '契約開始(yyyy/mm/dd)
        Dim ContractEnd As String                   '契約終了(yyyy/mm/dd)
        Dim FileFormation() As TYP_FILE_FORMATION   'ファイル構成
        Dim Db As String                            'DB有無
        'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
        Dim OutputState As String                   '出力状況
        Dim DbPsCount As Integer                    '契約済Paymentデータ件数
        Dim DbPsdCount As Integer                   '契約済詳細データ件数
        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
        Dim DataOk As Boolean                       'チェック後データ判定（True:正常  False:エラー）
        Dim ConvertFlg As Integer                   '変換後データ判定()
        Dim ErrMessage As String                    'エラーメッセージ
        Dim MdbOk As Boolean                        'チェック後契約締結済みMDB判定（True:正常  False:エラー）
        Dim ExcelStart As String                    'Excel開始年
        Dim PaymentPeriod As Integer                'Payment展開期間
    End Structure
#End Region

#Region "CONST"
    'フォルダ名
    Private Const DIR_BAT_OUTPUT As String = "Bat_Output"
    Private Const DIR_SEND As String = "SEND"
    Private Const DIR_RECV As String = "RECV"
    Private Const DIR_MDB As String = "Mdb"
    Private Const DIR_EXCEL As String = "EXCEL"
    Private Const DIR_ACT As String = "Act"
    Private Const DIR_DELIVERY As String = "Delivery"
    Private Const DIR_STANDARD As String = "StandardReport"
    Private Const DIR_INPUT_FILE As String = "Input"
    Private Const DIR_OUTPUT_FILE As String = "Output"
    Private Const DIR_UPDATE_FILE As String = "Update"
    Private Const DIR_SEND_LOWER As String = "Send"
    Private Const DIR_RECV_MAKE As String = "Recv_Make"
    Private Const DIR_RECV_UPDT As String = "Recv_Updt"
    Private Const DIR_LOG_FILE As String = "Log"
    Private Const DIR_SETTING_FILE As String = "Setting"
    Private Const DIR_REPORT_FILE As String = "Report"
    Private Const DIR_VERUP As String = "VersionUp"

    ''一覧の列位置
    Private Const CD_GRID_COL_CHECK As Integer = 0
    Private Const CD_GRID_COL_CPNO As Integer = 1
    Private Const CD_GRID_COL_CUSTNAME As Integer = 2
    Private Const CD_GRID_COL_DB As Integer = 3
    'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
    Private Const CD_GRID_COL_COMMENT As Integer = 4
    Private Const CD_GRID_COL_STANDARD_SET As Integer = 5
    Private Const CD_GRID_COL_STANDARD_REPORT As Integer = 6
    Private Const CD_GRID_COL_VERUP_EXCEL As Integer = 7
    Private Const CD_GRID_COL_VERUP_PS_CSV As Integer = 8
    Private Const CD_GRID_COL_VERUP_PS_PRICE_CSV As Integer = 9
    Private Const CD_GRID_COL_VERUP_DETAIL_CSV As Integer = 10
    Private Const CD_GRID_COL_MNG_ACT As Integer = 11
    Private Const CD_GRID_COL_MNG_DELIVERY As Integer = 12
    Private Const CD_GRID_COL_CONT_START As Integer = 13
    Private Const CD_GRID_COL_CONT_END As Integer = 14
    Private Const CD_GRID_COL_CONT_EXCEL_START As Integer = 15
    Private Const CD_GRID_COL_PAYMENT_PERIOD As Integer = 16
    'Private Const CD_GRID_COL_EXCEL As Integer = 4
    'Private Const CD_GRID_COL_MNG_OUT As Integer = 5
    'Private Const CD_GRID_COL_MNG_IN As Integer = 6
    'Private Const CD_GRID_COL_STANDARD_SET As Integer = 7
    'Private Const CD_GRID_COL_STANDARD_REPORT As Integer = 8
    'Private Const CD_GRID_COL_VERUP_EXCEL As Integer = 9
    'Private Const CD_GRID_COL_VERUP_PS_CSV As Integer = 10
    'Private Const CD_GRID_COL_VERUP_PS_PRICE_CSV As Integer = 11
    'Private Const CD_GRID_COL_VERUP_DETAIL_CSV As Integer = 12
    'Private Const CD_GRID_COL_MNG_ACT As Integer = 13
    'Private Const CD_GRID_COL_MNG_DELIVERY As Integer = 14
    'Private Const CD_GRID_COL_CONT_START As Integer = 15
    'Private Const CD_GRID_COL_CONT_END As Integer = 16
    'Private Const CD_GRID_COL_CONT_EXCEL_START As Integer = 17
    'Private Const CD_GRID_COL_PAYMENT_PERIOD As Integer = 18
    'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

    'タブ区分
    Private Const CD_TAB_IMPORT As Integer = 0
    Private Const CD_TAB_EXPORT As Integer = 1
    Private Const CD_TAB_STANDARD As Integer = 2
    Private Const CD_TAB_VERUP As Integer = 3
    'ボタン区分
    Private Const CD_BUTTON_IMPCSV As Integer = 4
    Private Const CD_BUTTON_EXPCSV As Integer = 5
    Private Const CD_BUTTON_CRTEXCEL As Integer = 6
    Private Const CD_BUTTON_REDEXCEL As Integer = 7
    'ファイルのチェック区分
    Private Const CD_FILECHECK_CSV As Integer = 0
    Private Const CD_FILECHECK_PAYMENT As Integer = 1
    Private Const CD_FILECHECK_MANAGEMENT_ACT As Integer = 2
    Private Const CD_FILECHECK_MANAGEMENT_DELIVERY As Integer = 3
    Private Const CD_FILECHECK_MDB As Integer = 4
    'ファイル構成の区分
    Private Const CD_FILEFROMATION_IMPORT_PS_CSV As Integer = 0     '
    Private Const CD_FILEFROMATION_PS As Integer = 1                '
    Private Const CD_FILEFROMATION_MANAGE_OUTPUT As Integer = 2     '
    Private Const CD_FILEFROMATION_MANAGE_INPUT As Integer = 3      '
    Private Const CD_FILEFROMATION_STD_SET As Integer = 4           '標準帳票設定
    Private Const CD_FILEFROMATION_VERUP_EXCEL As Integer = 5       '
    Private Const CD_FILEFROMATION_IMPORT_DETAIL_CSV As Integer = 6 '
    Private Const CD_FILEFROMATION_VERUP_PS_CSV As Integer = 7      '
    Private Const CD_FILEFROMATION_VERUP_PS_PRICE_CSV As Integer = 8 '
    Private Const CD_FILEFROMATION_VERUP_DETAIL_CSV As Integer = 9  '
    Private Const CD_FILEFROMATION_STD_REPORT As Integer = 10       '標準帳票出力EXCEL
    'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
    Private Const CD_FILEFROMATION_MANAGE_ACT As Integer = 11   '
    Private Const CD_FILEFROMATION_MANAGE_ACT_OFFER As Integer = 12 '
    Private Const CD_FILEFROMATION_MANAGE_DELIVERY As Integer = 13  '
    Private Const CD_FILEFROMATION_MAX As Integer = 14              '
    'Private Const CD_FILEFROMATION_MANAGE_ACT As Integer = 11       '
    'Private Const CD_FILEFROMATION_MANAGE_DELIVERY As Integer = 12  '
    'Private Const CD_FILEFROMATION_MAX As Integer = 13              '
    'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
    '戻り値
    Private Const CD_RET_OK As Integer = 0                          '正常
    Private Const CD_RET_SYSTEM_ERROR As Integer = -1               '異常
    Private Const CD_RET_CONTINUE As Integer = 1                    '処理続行
    Private Const CD_RET_STOP As Integer = 2                        '処理中断
    '表示
    Private Const CD_DISPDATA_FORMLOAD As Integer = 0               'フォームロード時
    Private Const CD_DISPDATA_RELOAD As Integer = 1                 '再表示時
    '
    Private Const CSV_PAYMENTLINE_CHECK_PAYMENTLINETITLEROW As Integer = 4
    Private Const CSV_PAYMENTLINEDETAIL_CHECK_DATAROW As Integer = 3

    Private Const EXCEL_PAYMNETSAMPLE_FILENAME As String = "PaymentLineSample.xlsm"
    Private Const EXCEL_PAYMNETDETAILSAMPLE_FILENAME As String = "PaymentLineDetailSample.xlsm"
    Private Const EXCEL_STD_REPORT_FILENAME As String = "標準帳表設定PS.xlsm"

    'PaymentLine データ開始行
    Private Const EXCEL_PAYMENTLINEDATE_OUTROW As Integer = 6
    '変換結果
    Private Const CD_CONVERT_BEFORE As Integer = 0          '変換前
    Private Const CD_CONVERT_OK As Integer = 1              '変換OK
    Private Const CD_CONVERT_ERROR As Integer = 2           '変換エラー
    Private Const CD_CONVERT_EXCLAMATION As Integer = 3     '警告
    Private Const CD_CONVERT_EXCLAMATION_NODATA As Integer = 4     '警告(0件)
    Private Const CD_CONVERT_OK_NODATA As Integer = 5       '変換OK(0件)
    Private Const CD_STROUT_STANDARD As Integer = 0         '標準帳票
    Private Const CD_STROUT_DATA_ALL As Integer = 1         '提供ﾃﾞｰﾀ（全ｶﾗﾑ）
    Private Const CD_STROUT_DATA_DEL As Integer = 2         '提供ﾃﾞｰﾀ（削除ｶﾗﾑ有）
#End Region

#Region "Variable"
    Private watcher As System.IO.FileSystemWatcher = Nothing
    Private typCpNo() As TYP_CPNODATA
    Public EventOn As Boolean
    Public LoginUserId As String
    Public LoginPassword As String
    Private OioBamaUrl As String
    Private isKb As String
    Private blnUpdateOk As Boolean
#End Region

#Region "Events"
    ''' <summary>
    ''' フォームロード
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub frmAsrAll_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim blnRet As Boolean

        ''' 処理：ボタン名称設定（一部）
        btnExportManageFileInputExplorer.Text = "入力フォルダ" & vbCrLf & "支援ファイル"
        'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
        btnExportPsExcelOutputExplorer.Text = "統合Payment" & vbCrLf & "出力フォルダ"
        btnExportPsCsvOutputExplorer.Text = "インポート用CSV" & vbCrLf & "出力フォルダ"
        '1720 str 
        'btnExcelToMdb.Text = "支援ファイル" & vbCrLf & "ｻｰﾊﾞｰｲﾝﾎﾟｰﾄ"
        btnExcelToMdb.Text = "支援ファイル" & vbCrLf & "ｻｰﾊﾞｰｴｸｽﾎﾟｰﾄ"
        '1720 end

        ' ''' 処理：OIO-BAMAサーバURLを画面に設定
        'Dim mmc As New MasterMdbControl
        'OioBamaUrl = mmc.GetMasterMbdPath.OioBama_Url & "index.jsp"
        ''画面に設定
        'lnkURL.Text = OioBamaUrl
        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

        ''' 処理：CPNO取得処理(GetCpNo())を呼び出す
        ''' 条件：処理結果判定
        ''' ケース：処理結果が異常の場合、処理を中断する
        blnRet = GetCpNo()
        If blnRet = False Then
            Exit Sub
        End If

        ''' 処理：作業フォルダコンボボックス設定処理(SetCboWorkDate())を呼び出す
        Call SetCboWorkDate()

#If DEBUG Then
#Else
        'Verupタブ非表示が出来ないため削除
        tabFile.TabPages.RemoveAt(CD_TAB_VERUP)
#End If

        ''' 処理：タブの制御設定処理(TabSelected())を呼び出す
        TabSelected()

        ''' 処理：ﾎﾞﾀﾝの制御設定処理(ButtonEnable())を呼び出す
        ButtonEnable()

        ''' 処理：ファイル情報取得表示（前処理(PreCheck())）を呼び出す
        Call PreCheck(False, "", CD_DISPDATA_FORMLOAD, "")

        ''' 処理：タブ幅設定
        tabFile.SizeMode = TabSizeMode.Fixed
        tabFile.ItemSize = New Size(170, 20)

#If DEBUG Then
        'バージョンアップ処理有効
        rdoVersion.Visible = True
#Else
        'バージョンアップ処理無効
        rdoVersion.Visible = False
#End If

        ''' 処理：タイトル表示
        Me.Text = CommonVariable.OBAMATITLE

        Me.EventOn = True

    End Sub


    ''' <summary>
    ''' 一覧表ダブルクリック
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub dvgCpno_CellDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dvgCpno.CellDoubleClick

        If dvgCpno.CurrentRow.Cells(0).Value = True Then
            dvgCpno.CurrentRow.Cells(0).Value = False
        Else
            dvgCpno.CurrentRow.Cells(0).Value = True
        End If

    End Sub

    ''' <summary>
    ''' ｲﾝﾎﾟｰﾄ用CSV変換ボタンクリック
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnCsvToMdb_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCsvToMdb.Click

        Dim blnRet As Boolean
        Dim strLogFileName As String = ""
        Dim blnImportOk As Boolean = True
        Dim strMsg As String

        Try
            ''' 処理：ログファイル名取得
            strLogFileName = GetLogFileName(CD_BUTTON_IMPCSV)
            ''' 処理：開始ログ出力
            ''' 　ログメッセージ：開始,インポート用CSV変換
            Call WriteLog(strLogFileName, "開始,インポート用CSV変換", True)

            '=======================================
            '前処理
            '=======================================
            ''' 処理：前処理(PreCheck())を呼び出す
            ''' 条件：処理結果判定
            ''' ケース：処理結果が異常の場合、ログを出力して処理を中断する
            ''' 　ログメッセージ：前処理（中断）,インポート用CSV変換
            blnRet = PreCheck(True, sender.name, CD_DISPDATA_RELOAD, strLogFileName)
            If blnRet = False Then
                Call WriteLog(strLogFileName, "前処理（中断）,インポート用CSV変換", True)
                Exit Sub
            End If

            '=======================================
            'インポート処理（CSV→MDB）
            '=======================================
            ''' 処理：インポート処理(MainCsvToMdb())を呼び出す
            ''' 条件：処理結果判定
            ''' ケース：処理結果が異常の場合、ログを出力して処理を中断する
            ''' 　ログメッセージ：インポート処理（中断）,インポート用CSV変換
            Dim oe As New OutputExcel
            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            blnRet = MainCsvToMdb(strLogFileName,
                                  OutputExcel.CD_PROC_NEW,
                                  -1,
                                  blnImportOk)
            'blnRet = MainCsvToMdb(strLogFileName, OutputExcel.CD_PROC_NEW, blnImportOk)
            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            If blnRet = False Then
                Call WriteLog(strLogFileName, "インポート処理（中断）,インポート用CSV変換", True)
                Exit Sub
            End If

            '=======================================
            '後処理
            '=======================================
            ''' 処理：後処理(PostCheck())を呼び出す
            ''' 条件：処理結果判定
            ''' ケース：処理結果が異常の場合、ログを出力して処理を中断する
            ''' 　ログメッセージ：後処理（中断）,インポート用CSV変換
            isKb = "インポート用CSV変換"
            blnRet = PostCheck(sender.name, strLogFileName)
            If blnRet = False Then
                Call WriteLog(strLogFileName, "後処理（中断）,インポート用CSV変換", True)
                Exit Sub
            End If

            ''' 処理：終了ログ出力
            ''' 　ログメッセージ：終了,インポート用CSV変換
            Call WriteLog(strLogFileName, "終了,インポート用CSV変換", True)
            ''' 条件：インポート結果判定
            ''' ケース：インポート結果が正常の場合、メッセージを表示する
            ''' 　メッセージ：ID:MSG_0391
            ''' 　　インポートを終了しました。
            ''' ケース：インポート結果が異常の場合、メッセージを表示する
            ''' 　メッセージ：ID:MSG_0392
            ''' 　　インポート中にエラーが発生しました。ログを確認してください。
            If blnImportOk = True Then
                strMsg = FileReader.GetMessage("MSG_0391")
            Else
                strMsg = FileReader.GetMessage("MSG_0392")
            End If
            MuseMessageBox.ShowInformation(strMsg, Me.Text)

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "btnCsvToMdb_Click")
            Call WriteLog(strLogFileName, "異常終了（中断）,インポート用CSV変換", True)

        End Try

    End Sub

    ''' <summary>
    ''' 管理ファイル作成ボタンクリック
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub bntMdbToExcel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bntMdbToExcel.Click

        Dim blnRet As Boolean
        Dim strLogFileName As String = ""
        Dim strLogTitle As String

        Try
            '''' 処理：ログファイル名取得
            strLogFileName = GetLogFileName(CD_BUTTON_CRTEXCEL)
            'ログタイトル
            strLogTitle = "支援ファイル作成"
            '''' 条件：処理区分判定
            '''' ケース：処理区分が実行支援の場合、ログタイトルを「支援ファイル作成（実行支援）」に設定
            '''' ケース：処理区分がﾃﾞﾘﾊﾞﾘ支援の場合、ログタイトルを「支援ファイル作成（ﾃﾞﾘﾊﾞﾘ支援）」に設定
            '''' ケース：処理区分が実行・ﾃﾞﾘﾊﾞﾘの場合、ログタイトルを「支援ファイル作成（実行・ﾃﾞﾘﾊﾞﾘ）」に設定
            If rdoAct.Checked = True Then
                strLogTitle = strLogTitle & "（実行支援）"
            ElseIf rdoDeliv.Checked = True Then
                strLogTitle = strLogTitle & "（ﾃﾞﾘﾊﾞﾘ支援）"
            ElseIf rdoBoth.Checked = True Then
                strLogTitle = strLogTitle & "（実行・ﾃﾞﾘﾊﾞﾘ）"
            End If

            '''' 処理：開始ログ出力
            '''' 　ログメッセージ：開始,ログタイトル
            Call WriteLog(strLogFileName, "開始," & strLogTitle, True)

            '=======================================
            '前処理
            '=======================================
            '''' 処理：前処理(PreCheck())を呼び出す
            '''' 条件：処理結果判定
            '''' ケース：処理結果が異常の場合、ログを出力して処理を中断する
            '''' 　ログメッセージ：前処理（中断）,ログタイトル
            blnRet = PreCheck(True, sender.name, CD_DISPDATA_RELOAD, strLogFileName)
            If blnRet = False Then
                Call WriteLog(strLogFileName, "前処理（中断）," & strLogTitle, True)
                Exit Sub
            End If

            '=======================================
            '画面入力チェック
            '=======================================
            '''' 処理：画面入力チェック(CheckDisplayItem())を呼び出す
            '''' 条件：処理結果判定
            '''' ケース：処理結果が異常の場合、ログを出力して処理を中断する
            '''' 　ログメッセージ：画面入力チェック（中断）,ログタイトル
            Dim strErrMsg As String = ""
            Call WriteLog(strLogFileName, "画面入力チェック（開始）," & strLogTitle, True)
            blnRet = CheckDisplayItem(strErrMsg)
            If blnRet = False Then
                Call WriteLog(strLogFileName, "画面入力チェック（中断）" & strErrMsg & "," & strLogTitle, True)
                Exit Sub
            End If
            Call WriteLog(strLogFileName, "画面入力チェック（終了）," & strLogTitle, True)

            '=======================================
            '作成処理
            '=======================================
            '''' 処理：管理ファイル作成処理(MainMakeAsrManage())を呼び出す
            '''' 条件：処理結果判定
            '''' ケース：処理結果が異常の場合、ログを出力して処理を中断する
            '''' 　ログメッセージ：作成処理（中断）,ログタイトル
            blnRet = MainMakeAsrManage(strLogFileName)
            If blnRet = False Then
                Call WriteLog(strLogFileName, "作成処理（中断）," & strLogTitle, True)
                Exit Sub
            End If

            '=======================================
            '後処理
            '=======================================
            '''' 処理：後処理(PostCheck())を呼び出す
            '''' 条件：処理結果判定
            '''' ケース：処理結果が異常の場合、ログを出力して処理を中断する
            '''' 　ログメッセージ：作成処理（中断）,ログタイトル
            isKb = "支援ファイル作成"
            blnRet = PostCheck(sender.name, strLogFileName)
            If blnRet = False Then
                Call WriteLog(strLogFileName, "後処理（中断）," & strLogTitle, True)
                Exit Sub
            End If

            '''' 処理：メッセージを表示
            '''' 　メッセージ：ID:MSG_0397
            '''' 　　管理ファイルを作成終了しました
            MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0397"), Me.Text)
            '''' 処理：終了ログ出力
            '''' 　ログメッセージ：終了,ログタイトル
            Call WriteLog(strLogFileName, "終了," & strLogTitle, True)

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "bntMdbToExcel_Click")
            Call WriteLog(strLogFileName, "異常終了（中断）," & strLogTitle, True)

        End Try

    End Sub

    ''' <summary>
    ''' 管理ファイル読込ボタン
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnExcelToMdb_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExcelToMdb.Click

        Dim blnRet As Boolean
        Dim strLogFileName As String = ""
        Dim strLogTitle As String

        Try
            ''' 処理：ログファイル名取得
            strLogFileName = GetLogFileName(CD_BUTTON_REDEXCEL)
            'ログタイトル
            strLogTitle = "支援ファイル読込"
            ''' 条件：処理区分判定
            ''' ケース：処理区分が実行支援の場合、ログタイトルを「支援ファイル読込（実行支援）」に設定
            ''' ケース：処理区分がﾃﾞﾘﾊﾞﾘ支援の場合、ログタイトルを「支援ファイル読込（ﾃﾞﾘﾊﾞﾘ支援）」に設定
            If rdoAct.Checked = True Then
                strLogTitle = strLogTitle & "（実行支援）"
            Else
                strLogTitle = strLogTitle & "（ﾃﾞﾘﾊﾞﾘ支援）"
            End If

            ''' 処理：開始ログ出力
            ''' 　ログメッセージ：開始,ログタイトル
            Call WriteLog(strLogFileName, "開始," & strLogTitle, True)

            '=======================================
            '前処理
            '=======================================
            ''' 処理：前処理(PreCheck())を呼び出す
            ''' 条件：処理結果判定
            ''' ケース：処理結果が異常の場合、ログを出力して処理を中断する
            ''' 　ログメッセージ：前処理（中断）,ログタイトル
            blnRet = PreCheck(True, sender.name, CD_DISPDATA_RELOAD, strLogFileName)
            If blnRet = False Then
                Call WriteLog(strLogFileName, "前処理（中断）," & strLogTitle, True)
                Exit Sub
            End If

            '=======================================
            '読込処理
            '=======================================
            ''' 処理：管理ファイル読込処理(MainLoadAsrManage())を呼び出す
            ''' 条件：処理結果判定
            ''' ケース：処理結果が異常の場合、ログを出力して処理を中断する
            ''' 　ログメッセージ：読込処理（中断）,ログタイトル
            blnRet = MainLoadAsrManage(strLogFileName)
            If blnRet = False Then
                Call WriteLog(strLogFileName, "読込処理（中断）," & strLogTitle, True)
                Exit Sub
            End If

            '=======================================
            '後処理
            '=======================================
            ''' 処理：後処理(PostCheck())を呼び出す
            ''' 条件：処理結果判定
            ''' ケース：処理結果が異常の場合、ログを出力して処理を中断する
            ''' 　ログメッセージ：作成処理（中断）,ログタイトル
            isKb = "支援ファイル読込"
            blnUpdateOk = True
            blnRet = PostCheck(sender.name, strLogFileName)
            If blnRet = False Then
                Call WriteLog(strLogFileName, "後処理（中断）," & strLogTitle, True)
                Exit Sub
            End If

            ''' 処理：メッセージを表示
            ''' 　メッセージ：ID:MSG_0393(OKのみ)
            ''' 　　管理ファイルをサーバーに反映しました。
            ''' 　メッセージ：ID:MSG_0517(NG有り)
            ''' 　　管理ファイルをサーバーに反映しました。反映出来なかったファイルについては、ログフォルダを確認して下さい。
            If blnUpdateOk = True Then
                MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0393"), Me.Text)
            Else
                MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0517"), Me.Text)
            End If

            ''' 処理：終了ログ出力
            ''' 　ログメッセージ：終了,ログタイトル
            Call WriteLog(strLogFileName, "終了," & strLogTitle, True)

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "btnExcelToMdb_Click")
            Call WriteLog(strLogFileName, "異常終了（中断）," & strLogTitle, True)

        End Try

    End Sub

    'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
    ' ''' <summary>
    ' ''' ｴｸｽﾎﾟｰﾄ用CSV変換ボタンクリック
    ' ''' </summary>
    ' ''' <param name="sender"></param>
    ' ''' <param name="e"></param>
    ' ''' <remarks></remarks>
    'Private Sub btnExcelToCsv_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExcelToCsv.Click

    '    Dim blnRet As Boolean
    '    Dim strLogFileName As String = ""
    '    Dim strLogTitle As String

    '    Try
    '        ''' 処理：ログファイル名取得
    '        strLogFileName = GetLogFileName(CD_BUTTON_EXPCSV)
    '        'ログタイトル
    '        strLogTitle = "エクスポート用CSV変換"
    '        ''' 条件：処理区分判定
    '        ''' ケース：処理区分が実行管理の場合、ログタイトルを「エクスポート用CSV変換（実行管理）」に設定
    '        ''' ケース：処理区分がﾃﾞﾘﾊﾞﾘ管理の場合、ログタイトルを「エクスポート用CSV変換（ﾃﾞﾘﾊﾞﾘ管理）」に設定
    '        If rdoAct.Checked = True Then
    '            strLogTitle = strLogTitle & "（実行支援）"
    '        Else
    '            strLogTitle = strLogTitle & "（ﾃﾞﾘﾊﾞﾘ支援）"
    '        End If

    '        ''' 処理：開始ログ出力
    '        ''' 　ログメッセージ：開始,ログタイトル
    '        Call WriteLog(strLogFileName, "開始," & strLogTitle, True)

    '        '=======================================
    '        '前処理
    '        '=======================================
    '        ''' 処理：前処理(PreCheck())を呼び出す
    '        ''' 条件：処理結果判定
    '        ''' ケース：処理結果が異常の場合、ログを出力して処理を中断する
    '        ''' 　ログメッセージ：前処理（中断）,ログタイトル
    '        blnRet = PreCheck(True, sender.name, CD_DISPDATA_RELOAD, strLogFileName)
    '        If blnRet = False Then
    '            Call WriteLog(strLogFileName, "前処理（中断）," & strLogTitle, True)
    '            Exit Sub
    '        End If

    '        '=======================================
    '        'エクスポート用CSV変換処理（EXCEL→CSV）
    '        '=======================================
    '        ''' 処理：管理ファイル読込処理(MainExcelToCsv())を呼び出す
    '        ''' 条件：処理結果判定
    '        ''' ケース：処理結果が異常の場合、ログを出力して処理を中断する
    '        ''' 　ログメッセージ：エクスポート用CSV変換処理（中断）,ログタイトル
    '        blnRet = MainExcelToCsv(strLogFileName)
    '        If blnRet = False Then
    '            Call WriteLog(strLogFileName, "エクスポート用CSV変換処理（中断）," & strLogTitle, True)
    '            Exit Sub
    '        End If

    '        '=======================================
    '        '後処理
    '        '=======================================
    '        ''' 処理：後処理(PostCheck())を呼び出す
    '        ''' 条件：処理結果判定
    '        ''' ケース：処理結果が異常の場合、ログを出力して処理を中断する
    '        ''' 　ログメッセージ：ログタイトル（中断）,ログタイトル
    '        isKb = "エクスポート用CSV変換"
    '        blnRet = PostCheck(sender.name, strLogFileName)
    '        If blnRet = False Then
    '            Call WriteLog(strLogFileName, "後処理（中断）," & strLogTitle, True)
    '            Exit Sub
    '        End If

    '        ''' 処理：メッセージを表示
    '        ''' 　メッセージ：ID:MSG_0395
    '        ''' 　　エクスポートを終了しました。
    '        MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0395"), Me.Text)
    '        ''' 処理：終了ログ出力
    '        ''' 　ログメッセージ：終了,ログタイトル
    '        Call WriteLog(strLogFileName, "終了," & strLogTitle, True)

    '    Catch ex As Exception
    '        MsgBox(ex.Message.ToString, vbCritical, "btnExcelToCsv_Click")
    '        Call WriteLog(strLogFileName, "異常終了（中断）," & strLogTitle, True)

    '    End Try

    'End Sub
    'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

    ''' <summary>
    ''' 標準帳票作成ボタンクリック
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnStdSetMake_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStdSetMake.Click

        Dim blnRet As Boolean
        Dim strLogFileName As String = ""
        Dim strLogTitle As String

        Try
            ''' 処理：ログファイル名取得
            strLogFileName = GetLogFileName(CD_TAB_STANDARD)
            ''' 処理：ログタイトルを「標準帳票作成」に設定
            strLogTitle = "標準帳票作成"

            ''' 処理：開始ログ出力
            ''' 　ログメッセージ：開始,標準帳票作成
            Call WriteLog(strLogFileName, "開始," & strLogTitle, True)

            '=======================================
            '前処理
            '=======================================
            ''' 処理：前処理(PreCheck())を呼び出す
            ''' 条件：処理結果判定
            ''' ケース：処理結果が異常の場合、ログを出力して処理を中断する
            ''' 　ログメッセージ：前処理（中断）,ログタイトル
            blnRet = PreCheck(True, sender.name, CD_DISPDATA_RELOAD, strLogFileName)
            If blnRet = False Then
                Call WriteLog(strLogFileName, "前処理（中断）," & strLogTitle, True)
                Exit Sub
            End If

            '=======================================
            '標準帳票作成処理
            '=======================================
            ''' 処理：標準帳票作成処理(MainStandardSetting())を呼び出す
            ''' 条件：処理結果判定
            ''' ケース：処理結果が異常の場合、ログを出力して処理を中断する
            ''' 　ログメッセージ：標準帳票作成（中断）,ログタイトル
            blnRet = MainStandardSetting(strLogFileName)
            If blnRet = False Then
                Call WriteLog(strLogFileName, "標準帳票作成（中断）," & strLogTitle, True)
                Exit Sub
            End If

            '=======================================
            '後処理
            '=======================================
            ''' 処理：後処理(PostCheck())を呼び出す
            ''' 条件：処理結果判定
            ''' ケース：処理結果が異常の場合、ログを出力して処理を中断する
            ''' 　ログメッセージ：作成処理（中断）,ログタイトル
            isKb = "標準帳票作成"
            blnRet = PostCheck(sender.name, strLogFileName)
            If blnRet = False Then
                Call WriteLog(strLogFileName, "後処理（中断）," & strLogTitle, True)
                Exit Sub
            End If

            ''' 処理：メッセージを表示
            ''' 　メッセージ：ID:MSG_0400
            ''' 　　標準帳票設定ファイルを出力しました。
            MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0400"), Me.Text)
            ''' 処理：終了ログ出力
            ''' 　ログメッセージ：終了,ログタイトル
            Call WriteLog(strLogFileName, "終了," & strLogTitle, True)

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "btnStdSetMake_Click")
            Call WriteLog(strLogFileName, "異常終了（中断）," & strLogTitle, True)

        End Try

    End Sub

    ''' <summary>
    ''' 標準帳票出力
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnStdOut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStdOut.Click,
                                                                                                    btnSubmittedDataAll.Click

        Dim blnRet As Boolean
        '一括処理画面における、統合Payment作成機能の変更対応 2017/12 Str
        Dim blnRet2 As Boolean
        '一括処理画面における、統合Payment作成機能の変更対応 2017/12 End
        Dim strLogFileName As String = ""
        Dim strLogTitle As String
        Dim intImportCd As Integer

        Try
            ''' 処理：ログファイル名取得
            strLogFileName = GetLogFileName(CD_TAB_STANDARD)
            'ログタイトル
            ''' 条件：処理区分判定
            ''' ケース：処理区分が実行管理の場合、ログタイトルを「標準帳票出力」に設定
            ''' ケース：処理区分がﾃﾞﾘﾊﾞﾘ管理の場合、ログタイトルを「ﾃﾞｰﾀ提供（全ﾃﾞｰﾀ）」に設定
            ''' ケース：処理区分がﾃﾞﾘﾊﾞﾘ管理の場合、ログタイトルを「ﾃﾞｰﾀ提供（削除ﾃﾞｰﾀ有）」に設定
            Select Case sender.name
                Case "btnStdOut"
                    strLogTitle = "標準帳票出力"
                    intImportCd = CD_STROUT_STANDARD
                Case "btnSubmittedDataAll"
                    '一括処理画面における、統合Payment作成機能の変更対応 2017/12 Str
                    'strLogTitle = "ﾃﾞｰﾀ提供（全ﾃﾞｰﾀ）"
                    strLogTitle = "ｲﾝﾎﾟｰﾄ用CSV変換 &ﾃﾞｰﾀ提供（全ﾃﾞｰﾀ）"
                    '一括処理画面における、統合Payment作成機能の変更対応 2017/12 End
                    intImportCd = CD_STROUT_DATA_ALL
            End Select

            ''' 処理：開始ログ出力
            ''' 　ログメッセージ：開始,ログタイトル
            Call WriteLog(strLogFileName, "開始," & strLogTitle, True)

            '一括処理画面における、統合Payment作成機能の変更対応 2017/12 Str
            'ｲﾝﾎﾟｰﾄ用CSV変換処理
            Select Case sender.name
                Case "btnStdOut"
                    '一括処理画面における、統合Payment作成機能の変更対応 2017/12 End
                    '=======================================
                    '前処理
                    '=======================================
                    ''' 処理：前処理(PreCheck())を呼び出す
                    ''' 条件：処理結果判定
                    ''' ケース：処理結果が異常の場合、ログを出力して処理を中断する
                    ''' 　ログメッセージ：前処理（中断）,ログタイトル
                    blnRet = PreCheck(True, sender.name, CD_DISPDATA_RELOAD, strLogFileName)
                    If blnRet = False Then
                        Call WriteLog(strLogFileName, "前処理（中断）," & strLogTitle, True)
                        Exit Sub
                    End If

                    '=======================================
                    '標準帳票出力処理
                    '=======================================
                    ''' 処理：標準帳票出力処理(MainStandardReport())を呼び出す
                    ''' 条件：処理結果判定
                    ''' ケース：処理結果が異常の場合、ログを出力して処理を中断する
                    ''' 　ログメッセージ：エクスポート用CSV変換処理（中断）,ログタイトル
                    blnRet = MainStandardReport(strLogFileName, strLogTitle, intImportCd)
                    If blnRet = False Then
                        Call WriteLog(strLogFileName, strLogTitle & "（中断）," & strLogTitle, True)
                        Exit Sub
                    End If

                    '=======================================
                    '後処理
                    '=======================================
                    ''' 処理：後処理(PostCheck())を呼び出す
                    ''' 条件：処理結果判定
                    ''' ケース：処理結果が異常の場合、ログを出力して処理を中断する
                    ''' 　ログメッセージ：ログタイトル（中断）,ログタイトル
                    isKb = "標準帳票出力"
                    blnRet = PostCheck(sender.name, strLogFileName)
                    If blnRet = False Then
                        Call WriteLog(strLogFileName, "後処理（中断）," & strLogTitle, True)
                        Exit Sub
                    End If

                    '一括処理画面における、統合Payment作成機能の変更対応 2017/12 Str
                Case "btnSubmittedDataAll"

                    '=======================================
                    '前処理
                    '=======================================
                    blnRet = PreCheck(True, sender.name, CD_DISPDATA_RELOAD, strLogFileName)
                    If blnRet = False Then
                        Call WriteLog(strLogFileName, "前処理（中断）," & strLogTitle, True)
                        Exit Sub
                    End If

                    '=======================================
                    'インポート処理（CSV→MDB）
                    '=======================================
                    Dim oe As New OutputExcel
                    blnRet = MainCsvToReport(strLogFileName,
                                             OutputExcel.CD_PROC_NEW,
                                             -1,
                                             blnRet2,
                                             intImportCd,
                                             strLogTitle)
                    If blnRet = False Then
                        Call WriteLog(strLogFileName, "インポート処理（中断）,インポート用CSV変換 &ﾃﾞｰﾀ提供（全ﾃﾞｰﾀ）", True)
                        Exit Sub
                    End If

                    '=======================================
                    '後処理
                    '=======================================
                    isKb = "インポート用CSV変換"
                    blnRet = PostCheck(sender.name, strLogFileName)
                    If blnRet = False Then
                        Call WriteLog(strLogFileName, "後処理（中断）,インポート用CSV変換 &ﾃﾞｰﾀ提供（全ﾃﾞｰﾀ）", True)
                        Exit Sub
                    End If
            End Select
            '一括処理画面における、統合Payment作成機能の変更対応 2017/12 End


            ''' 処理：メッセージを表示
            ''' 　メッセージ：ID:MSG_0401
            ''' 　　標準帳票で出力しました。
            MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0401"), Me.Text)
            ''' 処理：終了ログ出力
            ''' 　ログメッセージ：終了,ログタイトル
            Call WriteLog(strLogFileName, "終了," & strLogTitle, True)

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "btnStdOut_Click")
            Call WriteLog(strLogFileName, "異常終了（中断）," & strLogTitle, True)

        End Try

    End Sub

    ''' <summary>
    ''' 機能：ｴｸｽﾎﾟｰﾄ用CSV変換（バージョンアップ）
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnVerUpExcelToMdb_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnVerUpExcelToMdb.Click

        Dim blnRet As Boolean
        Dim strLogFileName As String = ""
        Dim strLogTitle As String

        Try
            'ログファイル名取得
            strLogFileName = GetLogFileName(CD_TAB_VERUP)
            'ログタイトル
            strLogTitle = "ｴｸｽﾎﾟｰﾄ用CSV変換（バージョンアップ）"

            '開始
            Call WriteLog(strLogFileName, "開始," & strLogTitle, True)

            '=======================================
            '前処理
            '=======================================
            blnRet = PreCheck(True, sender.name, CD_DISPDATA_RELOAD, strLogFileName)
            If blnRet = False Then
                Call WriteLog(strLogFileName, "前処理（中断）," & strLogTitle, True)
                Exit Sub
            End If

            '=======================================
            'エクスポート用CSV変換処理（EXCEL→CSV）
            '=======================================
            blnRet = MainVerUpExcelToCsv(strLogFileName)
            If blnRet = False Then
                Call WriteLog(strLogFileName, "エクスポート用CSV変換処理（バージョンアップ）（中断）," & strLogTitle, True)
                Exit Sub
            End If

            '=======================================
            '後処理
            '=======================================
            isKb = "エクスポート用CSV変換処理（バージョンアップ）"
            blnRet = PostCheck(sender.name, strLogFileName)
            If blnRet = False Then
                Call WriteLog(strLogFileName, "後処理（中断）," & strLogTitle, True)
                Exit Sub
            End If

            '終了
            MuseMessageBox.ShowInformation(FileReader.GetMessage("MSG_0395"), Me.Text)
            Call WriteLog(strLogFileName, "終了," & strLogTitle, True)

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "btnVerUpExcelToMdb_Click")
            Call WriteLog(strLogFileName, "異常終了（中断）," & strLogTitle, True)

        End Try
    End Sub

    ''' <summary>
    ''' CPNO選択全解除ボタンクリック
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnCpnoChkOff_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCpnoChkOff.Click

        Dim blnCheck As Boolean = True
        Dim strText As String

        ''' 条件：CONO全選択ボタンのキャプション判定
        ''' ケース：CONO全選択ボタンのキャプションが「CPNO全選択」の場合、キャプションを「CPNO全解除」に設定
        ''' ケース：上記以外の場合、キャプションを「CPNO全選択」に設定
        If btnCpnoChkOff.Text = "CPNO全選択" Then
            blnCheck = True
            strText = "CPNO全解除"
        Else
            blnCheck = False
            strText = "CPNO全選択"
        End If

        ''' 処理：全チェック設定(SetAllCheck())を呼び出す
        Call SetAllCheck(blnCheck)

        btnCpnoChkOff.Text = strText

    End Sub

    ''' <summary>
    ''' ログアウトボタンクリック
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnLogout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogout.Click

        ''' 処理：自画面を閉じる
        Me.Close()

    End Sub

    ''' <summary>
    ''' リフレッシュボタンクリック
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefresh.Click

        ''' ファイル情報取得表示（前処理(PreCheck())）を呼び出す
        Call PreCheck(False, "", CD_DISPDATA_RELOAD, "")

    End Sub

    'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
    ' ''' <summary>
    ' ''' リンククリック
    ' ''' </summary>
    ' ''' <param name="sender"></param>
    ' ''' <param name="e"></param>
    ' ''' <remarks></remarks>
    'Private Sub lnkURL_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkURL.LinkClicked

    '    ''' 処理：指定のURL（OIO-BAMAサーバー）へジャンプする
    '    lnkURL.LinkVisited = True
    '    System.Diagnostics.Process.Start(OioBamaUrl)

    'End Sub
    'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

    ''' <summary>
    ''' フォルダ表示
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub ClickFolder(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnImportManageFileOutputExplorer.Click,
                                                                                                btnExportManageFileInputExplorer.Click,
                                                                                                btnExportPsExcelOutputExplorer.Click,
                                                                                                btnExportPsCsvOutputExplorer.Click,
                                                                                                btnLogExplorer.Click,
                                                                                                btnStdSetMakeOutputExplorer.Click,
                                                                                                btnStdOutOutputExplorer.Click,
                                                                                                btnVerUpExcelExplorer.Click,
                                                                                                btnVerUpExportExplore.Click

        Dim strPath As String = ""
        Dim strFolder As String = ""
        Dim strYearMonth As String = GetWorkDate()
        Dim strPart As String = ""
        Dim blnRet As Boolean

        Try
            ''' 処理：フォルダ作成処理(CreateFolder())を呼び出す
            ''' 条件：処理結果判定
            ''' ケース：処理結果が異常の場合、処理を中断する
            blnRet = CreateFolder()
            If blnRet = False Then
                Exit Sub
            End If

            ''' 条件：処理区分判定
            ''' ケース：処理区分が実行管理の場合、実行管理のフォルダを設定
            ''' ケース：処理区分がﾃﾞﾘﾊﾞﾘ管理の場合、ﾃﾞﾘﾊﾞﾘ管理のフォルダを設定
            If rdoAct.Checked = True Then
                strPart = DIR_ACT
            Else
                strPart = DIR_DELIVERY
            End If

            ''' 処理：フォルダー設定
            '''   ボタン名                           処理区分        ﾌｫﾙﾀﾞ名
            '''   --------------------               -------------   ----------------------------------
            ''' 　支援ﾌｧｲﾙ作成出力ﾌｫﾙﾀﾞ　　　        実行支援        ./Bat\Excel\Act\作業年月\Output
            ''' 　                                   ﾃﾞﾘﾊﾞﾘ支援      ./Bat\Excel\Delivery\作業年月\Output
            '''                                      実行・ﾃﾞﾘﾊﾞﾘ    ./Bat\Excel\Act
            '''   ﾛｸﾞﾌｫﾙﾀﾞ                           実行支援        ./Bat\Excel\Act\作業年月\Log
            '''                                      ﾃﾞﾘﾊﾞﾘ支援      ./Bat\Excel\Delivery\作業年月\Log
            '''                                      実行・ﾃﾞﾘﾊﾞﾘ    ./Bat\Excel\Delivery\作業年月\Log
            '''                                      標準帳票        ./Bat\Excel\StandardReport\Log
            '''   支援ﾌｧｲﾙ読込入力ﾌｫﾙﾀﾞ(支援ﾌｨｱｲﾙ)   実行支援        ./Bat\Excel\Act\作業年月\Input
            '''                                      ﾃﾞﾘﾊﾞﾘ支援      ./Bat\Excel\Delivery\作業年月\Input
            '''   支援ﾌｧｲﾙ読込出力ﾌｫﾙﾀﾞ              実行支援        ./Bat\Excel\Act\作業年月\Update
            '''                                      ﾃﾞﾘﾊﾞﾘ支援      ./Bat\Excel\Delivery\作業年月\Update
            '''   支援ﾌｧｲﾙ読込ｴｸｽﾎﾟｰﾄ用CSV変換       実行支援        ./Bat\Excel\Act\作業年月\Send
            '''                                      ﾃﾞﾘﾊﾞﾘ支援      ./Bat\Excel\Delivery\作業年月\Send
            '''   標準帳票作成出力ﾌｫﾙﾀﾞ                              ./Bat\Excel\StandardReport\Setting
            '''   標準帳票出力出力ﾌｫﾙﾀﾞ                              ./Bat\Excel\StandardReport\Report

            If sender Is btnImportManageFileOutputExplorer And (rdoAct.Checked = True Or rdoDeliv.Checked = True) Then
                'デリバリor実行管理 管理ファイル作成出力フォルダ
                strFolder = DIR_BAT_OUTPUT & "\" & DIR_EXCEL & "\" & strPart & "\" & strYearMonth & "\" & DIR_OUTPUT_FILE
                'デリバリ・r実行管理 フォルダ
            ElseIf rdoBoth.Checked = True Then
                If sender Is btnImportManageFileOutputExplorer Then
                    strFolder = DIR_BAT_OUTPUT & "\" & DIR_EXCEL
                ElseIf sender Is btnLogExplorer Then
                    strFolder = DIR_BAT_OUTPUT & "\" & DIR_EXCEL & "\" & DIR_DELIVERY & "\" & strYearMonth & "\" & DIR_LOG_FILE
                End If
            ElseIf sender Is btnExportManageFileInputExplorer Then
                'デリバリor実行管理 管理ファイル読込入力フォルダ
                strFolder = DIR_BAT_OUTPUT & "\" & DIR_EXCEL & "\" & strPart & "\" & strYearMonth & "\" & DIR_INPUT_FILE
            ElseIf sender Is btnExportPsExcelOutputExplorer Then
                'デリバリor実行管理 管理ファイル読込出力フォルダ
                strFolder = DIR_BAT_OUTPUT & "\" & DIR_EXCEL & "\" & strPart & "\" & strYearMonth & "\" & DIR_UPDATE_FILE
            ElseIf sender Is btnExportPsCsvOutputExplorer Then
                'デリバリor実行管理 エクスポート用ＣＳＶ変換出力フォルダ
                If rdoAct.Checked = True Then
                    strFolder = DIR_BAT_OUTPUT & "\" & DIR_EXCEL & "\" & DIR_ACT & "\" & strYearMonth & "\" & DIR_SEND_LOWER
                Else
                    strFolder = DIR_BAT_OUTPUT & "\" & DIR_EXCEL & "\" & DIR_DELIVERY & "\" & strYearMonth & "\" & DIR_SEND_LOWER
                End If
            ElseIf sender Is btnLogExplorer And (rdoAct.Checked = True Or rdoDeliv.Checked = True) Then
                'デリバリor実行管理ログフォルダ
                strFolder = DIR_BAT_OUTPUT & "\" & DIR_EXCEL & "\" & strPart & "\" & strYearMonth & "\" & DIR_LOG_FILE
            ElseIf sender Is btnLogExplorer And rdoStandard.Checked = True Then
                '標準帳票ログフォルダ
                strFolder = DIR_BAT_OUTPUT & "\" & DIR_EXCEL & "\" & DIR_STANDARD & "\" & DIR_LOG_FILE
            ElseIf sender Is btnStdSetMakeOutputExplorer Then
                '標準帳票作成出力フォルダ
                strFolder = DIR_BAT_OUTPUT & "\" & DIR_EXCEL & "\" & DIR_STANDARD & "\" & DIR_SETTING_FILE
            ElseIf sender Is btnStdOutOutputExplorer Then
                '標準帳票出力出力フォルダ
                strFolder = DIR_BAT_OUTPUT & "\" & DIR_EXCEL & "\" & DIR_STANDARD & "\" & DIR_REPORT_FILE
            ElseIf sender Is btnVerUpExcelExplorer Then
                'バージョンアップEXCEL出力フォルダ
                strFolder = DIR_BAT_OUTPUT & "\" & DIR_VERUP & "\" & DIR_EXCEL
            ElseIf sender Is btnVerUpExportExplore Then
                'バージョンアップEXPORT出力フォルダ
                strFolder = DIR_BAT_OUTPUT & "\" & DIR_VERUP & "\" & DIR_SEND
            ElseIf sender Is btnLogExplorer And rdoVersion.Checked = True Then
                'バージョンアップログフォルダ
                strFolder = DIR_BAT_OUTPUT & "\" & DIR_VERUP & "\" & DIR_LOG_FILE
            End If

            ''' 処理：フォルダ設定のエクスプローラで開く
            strPath = FileManager.GetLocalFolderPath(strFolder)
            System.Diagnostics.Process.Start(strPath)

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "ClickFolder")

        End Try

    End Sub

    ''' <summary>
    ''' 一括処理ラジオボタンのチェンジイベント
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub ClickAsrRadio() Handles rdoAct.CheckedChanged,
                                        rdoDeliv.CheckedChanged,
                                        rdoBoth.CheckedChanged,
                                        rdoStandard.CheckedChanged,
                                        rdoVersion.CheckedChanged

        ''' 条件：イベント中判定
        ''' ケース:イベント中の場合、処理を中断する
        If Me.EventOn = False Then
            Exit Sub
        End If

        ''' 処理：タブの制御設定処理(TabSelected())を呼び出す
        Call TabSelected()

        ''' 処理：ファイル情報取得表示処理(前処理 PreCheck())を呼び出す
        Call PreCheck(False, "", CD_DISPDATA_RELOAD, "")

    End Sub

    ''' <summary>
    ''' タブ選択時
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub tabFile_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tabFile.SelectedIndexChanged

        If tabFile.SelectedIndex = CD_TAB_IMPORT And (rdoAct.Checked = True Or rdoBoth.Checked = True) Then
            grpAct.Enabled = True
        Else
            grpAct.Enabled = False
        End If

    End Sub

#End Region

#Region "Private"

    ''' <summary>
    ''' CPNO取得
    ''' </summary>
    ''' <returns>True:正常　False:異常</returns>
    ''' <remarks>DBからCPNOとお客様名を取得する</remarks>
    Private Function GetCpNo() As Boolean

        Dim dt As New M_CONTRACT_BASETable
        Dim blnRet As Boolean
        Dim strMsg As String
        Dim wc As New WebDb.WebDbCommon
        Dim row() As DataRow
        Dim strWhere As String
        Dim strOrderBy As String
        Dim intIndex As Integer = 0
        Dim strWork As String

        Try
            '認証設定
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW
            '契約基本情報取得
            ''' 処理：契約基本情報取得処理(WebDb.WebDbCommon.GetContractBaseData)を呼び出す
            ''' 条件：処理結果判定
            ''' ケース：処理結果が異常の場合、メッセージを表示して処理を中断する
            ''' 　メッセージ：Webサービスの返り値
            blnRet = wc.GetContractBaseData(dt, strMsg)
            If blnRet = False Then
                MsgBox(strMsg, vbCritical, "GetCpNo")
                Exit Function
            End If

            'フィルター
            ''' 処理：契約基本情報テーブルから一括処理対象のデータを抽出する
            strWhere = M_CONTRACT_BASETable.COLUMN_NAME_DISP_ASR_FLG & "= '0'"
            strOrderBy = M_CONTRACT_BASETable.COLUMN_NAME_CPNO
            row = dt.Select(strWhere, strOrderBy)

            '契約基本情報設定
            ReDim typCpNo(intIndex)
            ''' 繰返し_開始：抽出したデータがなくなるまで
            For intCnt As Integer = 0 To (row.Length - 1)
                intIndex = intIndex + 1
                ReDim Preserve typCpNo(intIndex)
                ReDim typCpNo(intIndex).FileFormation(CD_FILEFROMATION_MAX)
                typCpNo(intIndex).CpNo = row(intCnt).Item("CPNO")
                typCpNo(intIndex).CustomerName = row(intCnt).Item("CUST_NAME")
                typCpNo(intIndex).ContractStart = row(intCnt).Item(M_CONTRACT_BASETable.COLUMN_NAME_START_YEAR).ToString & "/" & row(intCnt).Item(M_CONTRACT_BASETable.COLUMN_NAME_START_MONTH).ToString & "/1"
                typCpNo(intIndex).ContractEnd = row(intCnt).Item(M_CONTRACT_BASETable.COLUMN_NAME_END_YEAR).ToString & "/" & row(intCnt).Item(M_CONTRACT_BASETable.COLUMN_NAME_END_MONTH).ToString & "/1"
                typCpNo(intIndex).ExcelStart = row(intCnt).Item(M_CONTRACT_BASETable.COLUMN_NAME_EXCEL_START).ToString.Substring(0, 4)
                strWork = row(intCnt).Item(M_CONTRACT_BASETable.COLUMN_NAME_PA_ANV_DATE).ToString.Trim
                Select Case strWork.Length
                    Case 1
                    Case 2
                        strWork = strWork.Substring(0, 1)
                    Case Else
                        strWork = "K"
                End Select
                If IsNumeric(strWork) = False Then
                    strWork = (Asc(strWork) - 55).ToString
                ElseIf strWork = "0" Then
                    strWork = "20"
                End If
                typCpNo(intIndex).PaymentPeriod = Integer.Parse(strWork)
            Next
            ''' 繰返し_終了:

            GetCpNo = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "GetCpNo")

        End Try

    End Function

    ''' <summary>
    ''' CPNO構造体を初期化
    ''' </summary>
    ''' <param name="blnSetIniAll">True:全初期化　False:一部初期化</param>
    ''' <returns>True:正常　False:異常</returns>
    ''' <remarks></remarks>
    Private Function SetIniCpnoStructure(ByVal blnSetIniAll As Boolean) As Boolean

        Dim intIndex As Integer
        Dim intCnt As Integer

        SetIniCpnoStructure = False

        Try
            ''' 処理：CPNO構造体を初期化（CPNO、お客様名、契約開始、契約終了以外）
            If typCpNo.Length > 0 Then
                For intIndex = 1 To typCpNo.Length - 1
                    With typCpNo(intIndex)
                        If blnSetIniAll = True Then
                            .Checked = False
                        End If
                        For intCnt = 0 To .FileFormation.Length - 1
                            .FileFormation(intCnt).Path = ""
                            .FileFormation(intCnt).FileName = ""
                            .FileFormation(intCnt).WriteUpdate = ""
                        Next
                        'START 変更管理#40（デリバリ実行支援簡略化対応)　2017/04 sugo
                        .DataOk = True
                        'END   変更管理#40（デリバリ実行支援簡略化対応)　2017/04 sugo
                        If blnSetIniAll = True Then
                            .Db = ""
                            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                            .OutputState = ""
                            .DbPsCount = 0
                            .DbPsdCount = 0
                            '.DataOk = True
                            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                            .ErrMessage = ""
                            .ConvertFlg = CD_CONVERT_BEFORE
                            .MdbOk = True
                        End If
                    End With
                Next
            End If


            SetIniCpnoStructure = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "SetIniCpnoStructure")

        End Try

    End Function


    ''' <summary>
    ''' 機能：一覧にデータを表示する
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    '一括処理画面における、統合Payment作成機能の変更対応 2017/12 Str
    Private Function DispData(ByVal intDispCd As Integer, _
                              ByVal strSenderName As String) As Integer
        'Private Function DispData(ByVal intDispCd As Integer) As Integer
        '一括処理画面における、統合Payment作成機能の変更対応 2017/12 End
        Dim intIndex As Integer
        Dim blnError As Boolean = False
        Dim intYesNo As Integer
        Dim dgvCol As DataGridViewColumn
        Dim dgvOrder As SortOrder
        Dim intCheckCnt As Integer = 0
        Dim intCheckNonFileCnt As Integer = 0
        Dim intCheckNonMDBCnt As Integer = 0
        Dim sortDirection As System.ComponentModel.ListSortDirection = System.ComponentModel.ListSortDirection.Ascending

        DispData = CD_RET_SYSTEM_ERROR

        Try
            dgvCol = dvgCpno.SortedColumn
            dgvOrder = dvgCpno.SortOrder
            dvgCpno.Rows.Clear()
            If typCpNo.Length > 0 Then
                For intIndex = 1 To typCpNo.Length - 1
                    With typCpNo(intIndex)
                        'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                        dvgCpno.Rows.Add(.Checked,
                                         .CpNo,
                                         .CustomerName,
                                         .Db,
                                         .OutputState,
                                         .FileFormation(CD_FILEFROMATION_STD_SET).FileName & " " & .FileFormation(CD_FILEFROMATION_STD_SET).WriteUpdate,
                                         .FileFormation(CD_FILEFROMATION_STD_REPORT).FileName & " " & .FileFormation(CD_FILEFROMATION_STD_REPORT).WriteUpdate,
                                         .FileFormation(CD_FILEFROMATION_VERUP_EXCEL).FileName & " " & .FileFormation(CD_FILEFROMATION_VERUP_EXCEL).WriteUpdate,
                                         .FileFormation(CD_FILEFROMATION_VERUP_PS_CSV).FileName & " " & .FileFormation(CD_FILEFROMATION_VERUP_PS_CSV).WriteUpdate,
                                         .FileFormation(CD_FILEFROMATION_VERUP_PS_PRICE_CSV).FileName & " " & .FileFormation(CD_FILEFROMATION_VERUP_PS_PRICE_CSV).WriteUpdate,
                                         .FileFormation(CD_FILEFROMATION_VERUP_DETAIL_CSV).FileName & " " & .FileFormation(CD_FILEFROMATION_VERUP_DETAIL_CSV).WriteUpdate,
                                         .FileFormation(CD_FILEFROMATION_MANAGE_ACT).FileName & " " & .FileFormation(CD_FILEFROMATION_MANAGE_ACT).WriteUpdate,
                                         .FileFormation(CD_FILEFROMATION_MANAGE_DELIVERY).FileName & " " & .FileFormation(CD_FILEFROMATION_MANAGE_DELIVERY).WriteUpdate,
                                         .ContractStart,
                                         .ContractEnd,
                                         .ExcelStart,
                                         .PaymentPeriod)
                        'dvgCpno.Rows.Add(.Checked,
                        '                    .CpNo,
                        '                    .CustomerName,
                        '                    .Db,
                        '                    .FileFormation(CD_FILEFROMATION_PS).FileName & " " & .FileFormation(CD_FILEFROMATION_PS).WriteUpdate,
                        '                    .FileFormation(CD_FILEFROMATION_MANAGE_OUTPUT).FileName & " " & .FileFormation(CD_FILEFROMATION_MANAGE_OUTPUT).WriteUpdate,
                        '                    .FileFormation(CD_FILEFROMATION_MANAGE_INPUT).FileName & " " & .FileFormation(CD_FILEFROMATION_MANAGE_INPUT).WriteUpdate,
                        '                    .FileFormation(CD_FILEFROMATION_STD_SET).FileName & " " & .FileFormation(CD_FILEFROMATION_STD_SET).WriteUpdate,
                        '                    .FileFormation(CD_FILEFROMATION_STD_REPORT).FileName & " " & .FileFormation(CD_FILEFROMATION_STD_REPORT).WriteUpdate,
                        '                    .FileFormation(CD_FILEFROMATION_VERUP_EXCEL).FileName & " " & .FileFormation(CD_FILEFROMATION_VERUP_EXCEL).WriteUpdate,
                        '                    .FileFormation(CD_FILEFROMATION_VERUP_PS_CSV).FileName & " " & .FileFormation(CD_FILEFROMATION_VERUP_PS_CSV).WriteUpdate,
                        '                    .FileFormation(CD_FILEFROMATION_VERUP_PS_PRICE_CSV).FileName & " " & .FileFormation(CD_FILEFROMATION_VERUP_PS_PRICE_CSV).WriteUpdate,
                        '                    .FileFormation(CD_FILEFROMATION_VERUP_DETAIL_CSV).FileName & " " & .FileFormation(CD_FILEFROMATION_VERUP_DETAIL_CSV).WriteUpdate,
                        '                    .FileFormation(CD_FILEFROMATION_MANAGE_ACT).FileName & " " & .FileFormation(CD_FILEFROMATION_MANAGE_ACT).WriteUpdate,
                        '                    .FileFormation(CD_FILEFROMATION_MANAGE_DELIVERY).FileName & " " & .FileFormation(CD_FILEFROMATION_MANAGE_DELIVERY).WriteUpdate,
                        '                    .ContractStart,
                        '                    .ContractEnd,
                        '                    .ExcelStart,
                        '                    .PaymentPeriod)
                        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                        If .Checked = False Or intDispCd = CD_DISPDATA_FORMLOAD Then
                            dvgCpno.Rows(intIndex - 1).DefaultCellStyle.BackColor = Color.Empty
                        Else
                            intCheckCnt = intCheckCnt + 1
                            'チェック有かつファイルなしデータの場合、背景色を黄色にする
                            If .Checked = True And .DataOk = False Then
                                dvgCpno.Rows(intIndex - 1).DefaultCellStyle.BackColor = Color.Yellow
                                blnError = True
                                intCheckNonFileCnt = intCheckNonFileCnt + 1
                            ElseIf .Checked = True And .MdbOk = False Then
                                '一括処理画面における、統合Payment作成機能の変更対応 2017/12 Str
                                If strSenderName <> "btnSubmittedDataAll" Then
                                    '一括処理画面における、統合Payment作成機能の変更対応 2017/12 End
                                    'チェック有かつMDBなしデータの場合、背景色を黄色にする
                                    dvgCpno.Rows(intIndex - 1).DefaultCellStyle.BackColor = Color.Yellow
                                    blnError = True
                                    intCheckNonMDBCnt = intCheckNonMDBCnt + 1
                                    '一括処理画面における、統合Payment作成機能の変更対応 2017/12 Str
                                End If
                                '一括処理画面における、統合Payment作成機能の変更対応 2017/12 End
                            ElseIf .ConvertFlg = CD_CONVERT_ERROR Then
                                dvgCpno.Rows(intIndex - 1).DefaultCellStyle.BackColor = Color.Red
                            ElseIf .ConvertFlg = CD_CONVERT_EXCLAMATION Or _
                                   .ConvertFlg = CD_CONVERT_EXCLAMATION_NODATA Then
                                dvgCpno.Rows(intIndex - 1).DefaultCellStyle.BackColor = Color.Yellow
                            Else
                                dvgCpno.Rows(intIndex - 1).DefaultCellStyle.BackColor = Color.Empty
                            End If
                        End If

                        If dvgCpno.Rows(intIndex - 1).DefaultCellStyle.BackColor <> Color.Empty And _
                           isKb = "支援ファイル読込" Then
                            blnUpdateOk = False
                            If dvgCpno.Rows(intIndex - 1).DefaultCellStyle.BackColor = Color.Red Then
                                File.Delete(.FileFormation(CD_FILEFROMATION_PS).Path & .FileFormation(CD_FILEFROMATION_PS).FileName)
                            Else
                                If dvgCpno.Rows(intIndex - 1).DefaultCellStyle.BackColor = Color.Yellow And _
                                   .ConvertFlg <> CD_CONVERT_EXCLAMATION And
                                   .DataOk = True Then
                                    File.Delete(.FileFormation(CD_FILEFROMATION_PS).Path & .FileFormation(CD_FILEFROMATION_PS).FileName)
                                End If
                            End If
                        End If

                        If dvgCpno.Rows(intIndex - 1).DefaultCellStyle.BackColor = Color.Empty And _
                           isKb = "支援ファイル読込" And _
                           .ConvertFlg = CD_CONVERT_OK_NODATA Then
                            File.Delete(.FileFormation(CD_FILEFROMATION_PS).Path & .FileFormation(CD_FILEFROMATION_PS).FileName)
                        End If
                    End With
                Next
            End If
            If Not dgvCol Is Nothing Then
                If dgvOrder = SortOrder.Ascending Then
                    sortDirection = System.ComponentModel.ListSortDirection.Ascending
                Else
                    sortDirection = System.ComponentModel.ListSortDirection.Descending
                End If
                dvgCpno.Sort(dgvCol, sortDirection)
            End If

            'エラーデータ有りの場合
            If blnError = True And intDispCd = CD_DISPDATA_RELOAD Then
                'チェックON数とファイル無数が同じ場合、処理を中断する
                If intCheckCnt = intCheckNonFileCnt Then
                    MuseMessageBox.ShowWarning(FileReader.GetMessage("MSG_0398"), Me.Text)
                    DispData = CD_RET_STOP
                    Exit Function
                ElseIf intCheckCnt = intCheckNonMDBCnt Then    '契約締結済みMDB存在チェック
                    'チェックON数と契約締結済みMDB無数が同じ場合、処理を中断する
                    MuseMessageBox.ShowWarning(FileReader.GetMessage("MSG_0433"), Me.Text)
                    DispData = CD_RET_STOP
                    Exit Function
                Else
                    'ファイル無が有る場合、処理を中断するかメッセージを表示する
                    intYesNo = MsgBox(FileReader.GetMessage("MSG_0394"), vbQuestion + vbYesNo, "")
                    If intYesNo = vbYes Then
                        DispData = CD_RET_STOP
                        Exit Function
                    End If
                End If
            End If

            DispData = CD_RET_OK

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "DispData")

        End Try

    End Function

    ''' <summary>
    ''' 機能：チェック状態取得
    ''' </summary>
    ''' <returns>True:正常　False:異常</returns>
    ''' <remarks></remarks>
    Private Function GetCheked(ByVal blnCheck As Boolean) As Boolean

        Dim intRowCnt As Integer
        Dim intMaxRow As Integer = dvgCpno.Rows.Count - 1
        Dim strCpno As String
        Dim intCnt As Integer
        Dim intMax As Integer = typCpNo.Length
        Dim intCheckedCnt As Integer = 0

        GetCheked = False

        Try
            For intRowCnt = 0 To intMaxRow
                strCpno = dvgCpno(CD_GRID_COL_CPNO, intRowCnt).Value
                For intCnt = 1 To intMax
                    If typCpNo(intCnt).CpNo = strCpno Then
                        typCpNo(intCnt).Checked = dvgCpno(CD_GRID_COL_CHECK, intRowCnt).Value
                        If typCpNo(intCnt).Checked = True Then
                            intCheckedCnt = intCheckedCnt + 1
                        End If
                        Exit For
                    End If
                Next
            Next

            If blnCheck = True And intCheckedCnt = 0 Then
                MuseMessageBox.ShowWarning(FileReader.GetMessage("MSG_0396"), Me.Text)
                Exit Function
            End If

            GetCheked = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "GetCheked")

        End Try

    End Function

    ''' <summary>
    ''' 機能：全チェック設定
    ''' </summary>
    ''' <param name="blnChecked"></param>
    ''' <remarks></remarks>
    Private Sub SetAllCheck(ByVal blnChecked As Boolean)

        Dim intCnt As Integer
        Dim intMaxRow As Integer = dvgCpno.Rows.Count - 1

        Try
            'データチェック設定
            For intCnt = 1 To typCpNo.Length - 1
                With typCpNo(intCnt)
                    .Checked = blnChecked
                    If blnChecked = False Then
                        .DataOk = True
                        .ErrMessage = ""
                    End If
                End With
            Next

            '表示チェック設定
            For intCnt = 0 To intMaxRow
                dvgCpno(CD_GRID_COL_CHECK, intCnt).Value = blnChecked
            Next

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "SetAllCheck")

        End Try

    End Sub

    ''' <summary>
    ''' 機能：前処理
    ''' </summary>
    ''' <param name="strObjectName"></param>
    ''' <param name="strLogFileName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function PreCheck(ByVal blnCheck As Boolean, ByVal strObjectName As String, ByVal intDispCd As Integer, ByVal strLogFileName As String) As Boolean

        Dim blnRet As Boolean
        Dim intRet As Integer

        PreCheck = False

        Try
            'CPNO構造体を初期化
            blnRet = SetIniCpnoStructure(True)
            If blnRet = False Then
                Exit Function
            End If

            'チェック状態取得
            blnRet = GetCheked(blnCheck)
            If blnRet = False Then
                Exit Function
            End If

            'フォルダ作成
            blnRet = CreateFolder()
            If blnRet = False Then
                Exit Function
            End If

            'ファイルチェック
            blnRet = CheckFile(strObjectName, True)
            If blnRet = False Then
                Exit Function
            End If

            'ﾃﾝﾌﾟﾚ更新
            blnRet = CopyGSATemplate()
            If blnRet = False Then
                Exit Function
            End If

            'データ表示
            '一括処理画面における、統合Payment作成機能の変更対応 2017/12 Str
            'intRet = DispData(intDispCd)
            intRet = DispData(intDispCd, strObjectName)
            '一括処理画面における、統合Payment作成機能の変更対応 2017/12 End
            If intRet = CD_RET_SYSTEM_ERROR Or intRet = CD_RET_STOP Then
                Exit Function
            End If

            PreCheck = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "PreCheck")

        End Try

    End Function

    ''' <summary>
    ''' 機能：後処理
    ''' </summary>
    ''' <param name="strObjectName"></param>
    ''' <param name="strLogFileName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function PostCheck(ByVal strObjectName As String, ByVal strLogFileName As String) As Boolean

        Dim blnRet As Boolean
        Dim intRet As Integer

        PostCheck = False

        Try
            'CPNO構造体を初期化
            blnRet = SetIniCpnoStructure(False)
            If blnRet = False Then
                Exit Function
            End If

            'ファイルチェック
            blnRet = CheckFile(strObjectName, False)
            If blnRet = False Then
                Exit Function
            End If

            'データ表示
            '一括処理画面における、統合Payment作成機能の変更対応 2017/12 Str
            'intRet = DispData(CD_DISPDATA_RELOAD)
            intRet = DispData(CD_DISPDATA_RELOAD, strObjectName)
            '一括処理画面における、統合Payment作成機能の変更対応 2017/12 End

            If intRet = CD_RET_SYSTEM_ERROR Or intRet = CD_RET_STOP Then
                Exit Function
            End If

            PostCheck = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "PostCheck")

        End Try

    End Function

    ''' <summary>
    ''' 機能：ファイルチェック
    ''' </summary>
    ''' <param name="strObjectName">実行ボタン名</param>
    ''' <param name="blnFileCheck">チェック判定有無区分</param>
    ''' <returns>True:正常　False:異常</returns>
    ''' <remarks></remarks>
    Private Function CheckFile(ByVal strObjectName As String, ByVal blnFileCheck As Boolean) As Boolean

        Dim intIndex As Integer
        Dim intMax As Integer = typCpNo.Length - 1
        Dim blnRet As Boolean

        CheckFile = False

        Try
            For intIndex = 1 To intMax
                '個別Paymentsheet
                blnRet = CheckExistPs(intIndex, strObjectName, blnFileCheck)
                If blnRet = False Then
                    Exit Function
                End If
                '管理ファイル（出力用）存在チェック
                blnRet = CheckExistManageFile(intIndex, DIR_OUTPUT_FILE, strObjectName, blnFileCheck)
                If blnRet = False Then
                    Exit Function
                End If
                '管理ファイル（読込用）存在チェック
                blnRet = CheckExistManageFile(intIndex, DIR_INPUT_FILE, strObjectName, blnFileCheck)
                If blnRet = False Then
                    Exit Function
                End If
                'DB存在チェック
                blnRet = CheckExistDb(intIndex, strObjectName, blnFileCheck)
                If blnRet = False Then
                    Exit Function
                End If
                '標準帳表設定ファイル存在チェック
                blnRet = CheckExistStandardSetting(intIndex, strObjectName, blnFileCheck)
                If blnRet = False Then
                    Exit Function
                End If
                '標準帳表出力EXCELファイル存在チェック
                blnRet = CheckExistStandardReport(intIndex, strObjectName, blnFileCheck)
                If blnRet = False Then
                    Exit Function
                End If
                'バージョンアップ(EXCEL)存在チェック
                blnRet = CheckExistVerUpExcelPs(intIndex, strObjectName, blnFileCheck)
                If blnRet = False Then
                    Exit Function
                End If
                'バージョンアップエクスポートV_PLINE(CSV)存在チェック
                blnRet = CheckExistVerUpCsvPs(intIndex, strObjectName, blnFileCheck)
                If blnRet = False Then
                    Exit Function
                End If
                'バージョンアップエクスポートT_PPRICE(CSV)存在チェック
                blnRet = CheckExistVerUpCsvPsPrice(intIndex, strObjectName, blnFileCheck)
                If blnRet = False Then
                    Exit Function
                End If
                'バージョンアップエクスポート詳細(CSV)存在チェック
                blnRet = CheckExistVerUpCsvDetail(intIndex, strObjectName, blnFileCheck)
                If blnRet = False Then
                    Exit Function
                End If
                '実行管理ファイル（全）（出力用）存在チェック
                blnRet = CheckExistManageOutputFile(intIndex, CD_FILEFROMATION_MANAGE_ACT, strObjectName, blnFileCheck)
                If blnRet = False Then
                    Exit Function
                End If
                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                '実行管理ファイル（連携）（出力用）存在チェック
                blnRet = CheckExistManageOutputFile(intIndex, CD_FILEFROMATION_MANAGE_ACT_OFFER, strObjectName, blnFileCheck)
                If blnRet = False Then
                    Exit Function
                End If
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                'デリバリファイル（出力用）存在チェック
                blnRet = CheckExistManageOutputFile(intIndex, CD_FILEFROMATION_MANAGE_DELIVERY, strObjectName, blnFileCheck)
                If blnRet = False Then
                    Exit Function
                End If
            Next

            CheckFile = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "CheckFile")

        End Try

    End Function

    ''' <summary>
    ''' 機能：テンプレファイルコピー
    ''' </summary>
    ''' <returns>True:正常　False:異常</returns>
    ''' <remarks></remarks>
    Private Function CopyGSATemplate() As Boolean

        ''初期化
        CopyGSATemplate = False

        ''実行/ﾃﾞﾘﾊﾞﾘのみ対象
        If Me.rdoAct.Checked = False And _
           Me.rdoDeliv.Checked = False And _
           Me.rdoBoth.Checked = False Then
            Return True
        End If

        ''ﾌｧｲﾙｺﾋﾟｰ
        Dim msg As String
        Dim ofm As New OioFileManage
        If ofm.CopyGSATmpFile(OioFileManage.enmTmpFileType.Payment, msg) = False Then
            Exit Function
        End If
        Return True

    End Function


    ''' <summary>
    ''' 機能：個別Paymentsheet
    ''' </summary>
    ''' <param name="intRow">行</param>
    ''' <param name="strObjectName">実行ボタン名</param>
    ''' <param name="blnFileCheck">チェック判定有無区分</param>
    ''' <returns>True:正常　False:異常</returns>
    ''' <remarks></remarks>
    Private Function CheckExistPs(ByVal intRow As Integer, ByVal strObjectName As String, ByVal blnFileCheck As Boolean) As Boolean

        Dim strPath As String = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT) & _
                                    DIR_EXCEL & "\"
        Dim strFiles() As String
        Dim strPsFile As String = ""
        Dim strPsdFile As String = ""
        Dim strFullPath As String = ""
        Dim arrSort As New ArrayList

        CheckExistPs = False

        Try
            If rdoAct.Checked = True Then
                strPath = strPath & DIR_ACT & "\"
            Else
                strPath = strPath & DIR_DELIVERY & "\"
            End If
            strPath = strPath & GetWorkDate() & "\" & DIR_UPDATE_FILE & "\"

            '個別Paymentsheet　ファイル名・更新時間取得
            strPsFile = typCpNo(intRow).CpNo & "_999_Payment*.xlsm"
            strFiles = Directory.GetFiles(strPath, strPsFile)
            If strFiles.Length > 0 Then
                arrSort.AddRange(strFiles)
                arrSort.Sort()
                typCpNo(intRow).FileFormation(CD_FILEFROMATION_PS).Path = strPath
                typCpNo(intRow).FileFormation(CD_FILEFROMATION_PS).FileName = Path.GetFileName(arrSort(arrSort.Count - 1).ToString)
                strFullPath = typCpNo(intRow).FileFormation(CD_FILEFROMATION_PS).Path & typCpNo(intRow).FileFormation(CD_FILEFROMATION_PS).FileName
                typCpNo(intRow).FileFormation(CD_FILEFROMATION_PS).WriteUpdate = File.GetLastWriteTime(strFullPath).ToString("yyyy/MM/dd HH:mm:ss")
                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                'Else
                '    If blnFileCheck = True And typCpNo(intRow).Checked = True And strObjectName = btnExcelToCsv.Name Then
                '        typCpNo(intRow).DataOk = False
                '        typCpNo(intRow).ErrMessage = typCpNo(intRow).ErrMessage & ",個別Paymentsheet"
                '    End If
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            End If

            CheckExistPs = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "CheckExistPs")

        End Try

    End Function

    ''' <summary>
    ''' 機能：管理ファイル存在チェック
    ''' </summary>
    ''' <param name="intRow">行</param>
    ''' <param name="strInOut">インプット・アウトプット区分</param>
    ''' <param name="strObjectName">実行ボタン名</param>
    ''' <param name="blnFileCheck">チェック判定有無区分</param>
    ''' <returns>True:正常　False:異常</returns>
    ''' <remarks></remarks>
    Private Function CheckExistManageFile(ByVal intRow As Integer, ByVal strInOut As String, ByVal strObjectName As String, ByVal blnFileCheck As Boolean) As Boolean

        Dim strPath As String = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT) & _
                                    DIR_EXCEL & "\"
        Dim strFile As String = ""
        Dim strFullPath As String = ""

        CheckExistManageFile = False

        Try
            If rdoAct.Checked = True Then
                strPath = strPath & DIR_ACT & "\" & _
                                    GetWorkDate() & "\" & _
                                    strInOut & "\"
                strFile = "実行支援_" & typCpNo(intRow).CpNo & "*_連携.xlsm"
            Else
                strPath = strPath & DIR_DELIVERY & "\" & _
                                    GetWorkDate() & "\" & _
                                    strInOut & "\"
                strFile = "Delivery_Export_" & typCpNo(intRow).CpNo & "*.xlsm"
            End If

            Dim strFiles() As String = Directory.GetFiles(strPath, strFile)
            If strFiles.Length > 0 Then
                Dim arrFiles As New ArrayList
                arrFiles.AddRange(strFiles)
                arrFiles.Sort()

                If strInOut = DIR_INPUT_FILE Then
                    typCpNo(intRow).FileFormation(CD_FILEFROMATION_MANAGE_INPUT).Path = strPath
                    typCpNo(intRow).FileFormation(CD_FILEFROMATION_MANAGE_INPUT).FileName = Path.GetFileName(arrFiles(arrFiles.Count - 1).ToString)
                    strFullPath = typCpNo(intRow).FileFormation(CD_FILEFROMATION_MANAGE_INPUT).Path & typCpNo(intRow).FileFormation(CD_FILEFROMATION_MANAGE_INPUT).FileName
                    typCpNo(intRow).FileFormation(CD_FILEFROMATION_MANAGE_INPUT).WriteUpdate = File.GetLastWriteTime(strFullPath).ToString("yyyy/MM/dd HH:mm:ss")
                Else
                    typCpNo(intRow).FileFormation(CD_FILEFROMATION_MANAGE_OUTPUT).Path = strPath
                    typCpNo(intRow).FileFormation(CD_FILEFROMATION_MANAGE_OUTPUT).FileName = Path.GetFileName(arrFiles(arrFiles.Count - 1).ToString)
                    strFullPath = typCpNo(intRow).FileFormation(CD_FILEFROMATION_MANAGE_OUTPUT).Path & typCpNo(intRow).FileFormation(CD_FILEFROMATION_MANAGE_OUTPUT).FileName
                    typCpNo(intRow).FileFormation(CD_FILEFROMATION_MANAGE_OUTPUT).WriteUpdate = File.GetLastWriteTime(strFullPath).ToString("yyyy/MM/dd HH:mm:ss")
                End If
            Else
                If blnFileCheck = True And _
                    typCpNo(intRow).Checked = True And _
                    strInOut = DIR_INPUT_FILE And _
                    strObjectName = btnExcelToMdb.Name Then
                    typCpNo(intRow).ErrMessage = typCpNo(intRow).ErrMessage & ",読込用管理ファイル"
                    typCpNo(intRow).DataOk = False
                    'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                    typCpNo(intRow).OutputState = "支援ファイルが存在しません"
                    'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                End If
            End If

            CheckExistManageFile = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "CheckExistManageFile")

        End Try

    End Function

    ''' <summary>
    ''' 機能：実行管理 or デリバリ管理ファイル（出力用）存在チェック
    ''' </summary>
    ''' <param name="intRow"></param>
    ''' <param name="intFileFormationIdx"></param>
    ''' <param name="strObjectName"></param>
    ''' <param name="blnFileCheck"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckExistManageOutputFile(ByVal intRow As Integer, ByVal intFileFormationIdx As Integer, ByVal strObjectName As String, ByVal blnFileCheck As Boolean) As Boolean

        Dim strPath As String = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT) & _
                                    DIR_EXCEL & "\"
        Dim strFile As String = ""
        Dim strFullPath As String = ""

        CheckExistManageOutputFile = False

        Try
            If intFileFormationIdx = CD_FILEFROMATION_MANAGE_ACT Then
                strPath = strPath & DIR_ACT & "\" & _
                                    GetWorkDate() & "\" & _
                                    DIR_OUTPUT_FILE & "\"
                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                strFile = "実行支援_" & typCpNo(intRow).CpNo & "*_全.xlsm"
            ElseIf intFileFormationIdx = CD_FILEFROMATION_MANAGE_ACT_OFFER Then
                strPath = strPath & DIR_ACT & "\" & _
                                    GetWorkDate() & "\" & _
                                    DIR_OUTPUT_FILE & "\"
                strFile = "実行支援_" & typCpNo(intRow).CpNo & "*_連携.xlsm"
                'strFile = "実行支援_" & typCpNo(intRow).CpNo & "*.xlsm"
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            ElseIf intFileFormationIdx = CD_FILEFROMATION_MANAGE_DELIVERY Then
                strPath = strPath & DIR_DELIVERY & "\" & _
                                    GetWorkDate() & "\" & _
                                    DIR_OUTPUT_FILE & "\"
                strFile = "Delivery_Export_" & typCpNo(intRow).CpNo & "*.xlsm"
            Else
                CheckExistManageOutputFile = True
                Exit Function
            End If

            Dim strFiles() As String = Directory.GetFiles(strPath, strFile)
            If strFiles.Length > 0 Then
                Dim arrFiles As New ArrayList
                arrFiles.AddRange(strFiles)
                arrFiles.Sort()

                typCpNo(intRow).FileFormation(intFileFormationIdx).Path = strPath
                typCpNo(intRow).FileFormation(intFileFormationIdx).FileName = Path.GetFileName(arrFiles(arrFiles.Count - 1).ToString)
                strFullPath = typCpNo(intRow).FileFormation(intFileFormationIdx).Path & typCpNo(intRow).FileFormation(CD_FILEFROMATION_MANAGE_OUTPUT).FileName
                typCpNo(intRow).FileFormation(intFileFormationIdx).WriteUpdate = File.GetLastWriteTime(strFullPath).ToString("yyyy/MM/dd HH:mm:ss")
            Else
                If blnFileCheck = True And _
                    typCpNo(intRow).Checked = True And _
                    strObjectName = btnExcelToMdb.Name And
                    rdoBoth.Checked = True Then
                    typCpNo(intRow).ErrMessage = typCpNo(intRow).ErrMessage & ",出力用（両方）支援ファイル"
                    typCpNo(intRow).DataOk = False
                End If
            End If

            CheckExistManageOutputFile = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "CheckExistManageOutputFile")

        End Try

    End Function

    ''' <summary>
    ''' 機能：ＤＢ存在チェック
    ''' </summary>
    ''' <param name="intRow">行</param>
    ''' <param name="strObjectName">実行ボタン名</param>
    ''' <param name="blnFileCheck">チェック判定有無区分</param>
    ''' <returns>True:正常　False:異常</returns>
    ''' <remarks></remarks>
    Private Function CheckExistDb(ByVal intRow As Integer, ByVal strObjectName As String, ByVal blnFileCheck As Boolean) As Boolean

        Dim blnRet As Boolean
        Dim strPath As String
        Dim strFullPath As String

        CheckExistDb = False

        Try
            If strObjectName = btnVersionUp.Name Or rdoVersion.Checked = True Then
                CheckExistDb = True
                Exit Function
            Else
                Dim mmc As New MasterMdbControl
                strPath = mmc.GetMasterMbdPath.Local_MasterMdb_FolderName
            End If
            strFullPath = strPath & typCpNo(intRow).CpNo & ".accdb"
            blnRet = File.Exists(strFullPath)
            If blnRet = True Then
                typCpNo(intRow).Db = File.GetLastWriteTime(strFullPath).ToString("yyyy/MM/dd HH:mm:ss")
            Else
                typCpNo(intRow).Db = ""
                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                If blnFileCheck = True And typCpNo(intRow).Checked = True And
                    (strObjectName = btnStdOut.Name Or
                     strObjectName = btnSubmittedDataAll.Name Or
                     strObjectName = btnVersionUp.Name) Then
                    'If blnFileCheck = True And typCpNo(intRow).Checked = True And
                    '    (strObjectName = bntMdbToExcel.Name Or
                    '     strObjectName = btnStdOut.Name Or
                    '     strObjectName = btnSubmittedDataAll.Name Or
                    '     strObjectName = btnVersionUp.Name) Then
                    'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                    typCpNo(intRow).MdbOk = False
                    typCpNo(intRow).ErrMessage = typCpNo(intRow).ErrMessage & ",ＤＢ"
                End If
            End If

            CheckExistDb = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "CheckExistDb")

        End Try

    End Function

    ''' <summary>
    ''' 機能：標準帳表設定ファイル存在チェック
    ''' </summary>
    ''' <param name="intRow">行</param>
    ''' <param name="strObjectName">実行ボタン名</param>
    ''' <param name="blnFileCheck">チェック判定有無区分</param>
    ''' <returns>True:正常　False:異常</returns>
    ''' <remarks></remarks>
    Private Function CheckExistStandardSetting(ByVal intRow As Integer, ByVal strObjectName As String, ByVal blnFileCheck As Boolean) As Boolean

        Dim strPath As String = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT) & _
                                    DIR_EXCEL & "\" & DIR_STANDARD & "\" & DIR_SETTING_FILE & "\"
        Dim strFile As String = ""
        Dim strFullPath As String = ""

        CheckExistStandardSetting = False

        Try
            strFile = "標準帳表設定PS_" & typCpNo(intRow).CpNo & "*.xlsm"

            Dim strFiles() As String = Directory.GetFiles(strPath, strFile)
            If strFiles.Length > 0 Then
                Dim arrFiles As New ArrayList
                arrFiles.AddRange(strFiles)
                arrFiles.Sort()
                With typCpNo(intRow).FileFormation(CD_FILEFROMATION_STD_SET)
                    .Path = strPath
                    .FileName = Path.GetFileName(arrFiles(arrFiles.Count - 1).ToString)
                    strFullPath = .Path & .FileName
                    .WriteUpdate = File.GetLastWriteTime(strFullPath).ToString("yyyy/MM/dd HH:mm:ss")
                End With
            Else
                If blnFileCheck = True And _
                    typCpNo(intRow).Checked = True And _
                    strObjectName = btnStdOut.Name Then
                    typCpNo(intRow).ErrMessage = typCpNo(intRow).ErrMessage & ",標準帳表設定ファイル"
                    typCpNo(intRow).DataOk = False
                End If
            End If

            CheckExistStandardSetting = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "CheckExistStandardSetting")

        End Try

    End Function

    ''' <summary>
    ''' 機能：標準帳表出力EXCELファイル存在チェック
    ''' </summary>
    ''' <param name="intRow">行</param>
    ''' <param name="strObjectName">実行ボタン名</param>
    ''' <param name="blnFileCheck">チェック判定有無区分</param>
    ''' <returns>True:正常　False:異常</returns>
    ''' <remarks></remarks>
    Private Function CheckExistStandardReport(ByVal intRow As Integer, ByVal strObjectName As String, ByVal blnFileCheck As Boolean) As Boolean

        Dim strPath As String = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT) & _
                                    DIR_EXCEL & "\" & DIR_STANDARD & "\" & DIR_REPORT_FILE & "\"
        Dim strFile As String = ""
        Dim strFullPath As String = ""

        CheckExistStandardReport = False

        Try
            strFile = "標準帳表PS(" & typCpNo(intRow).CpNo & "*.xlsm"

            Dim strFiles() As String = Directory.GetFiles(strPath, strFile)
            If strFiles.Length > 0 Then
                Dim arrFiles As New ArrayList
                arrFiles.AddRange(strFiles)
                arrFiles.Sort()
                With typCpNo(intRow).FileFormation(CD_FILEFROMATION_STD_REPORT)
                    .Path = strPath
                    .FileName = Path.GetFileName(arrFiles(arrFiles.Count - 1).ToString)
                    strFullPath = .Path & .FileName
                    .WriteUpdate = File.GetLastWriteTime(strFullPath).ToString("yyyy/MM/dd HH:mm:ss")
                End With
            End If

            CheckExistStandardReport = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "CheckExistStandardReport")

        End Try

    End Function

    ''' <summary>
    ''' 機能：バージョンアップ(EXCEL)存在チェック
    ''' </summary>
    ''' <param name="intRow"></param>
    ''' <param name="strObjectName"></param>
    ''' <param name="blnFileCheck"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckExistVerUpExcelPs(ByVal intRow As Integer, ByVal strObjectName As String, ByVal blnFileCheck As Boolean) As Boolean

        Dim strPath As String = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT) & _
                                    DIR_VERUP & "\" & DIR_EXCEL & "\"
        Dim strFiles() As String
        Dim strPsFile As String = ""
        Dim strPsdFile As String = ""
        Dim strFullPath As String = ""
        Dim arrSort As New ArrayList

        CheckExistVerUpExcelPs = False

        Try
            'Paymentsheet　ファイル名・更新時間取得
            strPsFile = typCpNo(intRow).CpNo & "_999_Payment" & "*.xlsm"
            strFiles = Directory.GetFiles(strPath, strPsFile)
            If strFiles.Length > 0 Then
                arrSort.AddRange(strFiles)
                arrSort.Sort()
                typCpNo(intRow).FileFormation(CD_FILEFROMATION_VERUP_EXCEL).Path = strPath
                typCpNo(intRow).FileFormation(CD_FILEFROMATION_VERUP_EXCEL).FileName = Path.GetFileName(arrSort(arrSort.Count - 1).ToString)
                strFullPath = typCpNo(intRow).FileFormation(CD_FILEFROMATION_VERUP_EXCEL).Path & typCpNo(intRow).FileFormation(CD_FILEFROMATION_VERUP_EXCEL).FileName
                typCpNo(intRow).FileFormation(CD_FILEFROMATION_VERUP_EXCEL).WriteUpdate = File.GetLastWriteTime(strFullPath).ToString("yyyy/MM/dd HH:mm:ss")
            End If

            CheckExistVerUpExcelPs = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "CheckExistVerUpExcelPs")

        End Try

    End Function

    ''' <summary>
    ''' 機能：バージョンアップエクスポートV_PLINE(CSV)存在チェック
    ''' </summary>
    ''' <param name="intRow"></param>
    ''' <param name="strObjectName"></param>
    ''' <param name="blnFileCheck"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckExistVerUpCsvPs(ByVal intRow As Integer, ByVal strObjectName As String, ByVal blnFileCheck As Boolean) As Boolean

        Dim strPath As String = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT) & _
                                    DIR_VERUP & "\" & DIR_SEND & "\"
        Dim strFiles() As String
        Dim strPsFile As String = ""
        Dim strPsdFile As String = ""
        Dim strFullPath As String = ""
        Dim arrSort As New ArrayList

        CheckExistVerUpCsvPs = False

        Try
            'Paymentsheet　ファイル名・更新時間取得
            strPsFile = typCpNo(intRow).CpNo & "_999_V_PLINE*.csv"
            strFiles = Directory.GetFiles(strPath, strPsFile)
            If strFiles.Length > 0 Then
                For intCnt As Integer = 0 To (strFiles.Length - 1)
                    If Path.GetFileName(strFiles(intCnt)).Length = 38 Then
                        arrSort.Add(strFiles(intCnt))
                    End If
                Next
                If arrSort.Count > 0 Then
                    arrSort.Sort()
                    typCpNo(intRow).FileFormation(CD_FILEFROMATION_VERUP_PS_CSV).Path = strPath
                    typCpNo(intRow).FileFormation(CD_FILEFROMATION_VERUP_PS_CSV).FileName = Path.GetFileName(arrSort(arrSort.Count - 1).ToString)
                    strFullPath = typCpNo(intRow).FileFormation(CD_FILEFROMATION_VERUP_PS_CSV).Path & typCpNo(intRow).FileFormation(CD_FILEFROMATION_VERUP_PS_CSV).FileName
                    typCpNo(intRow).FileFormation(CD_FILEFROMATION_VERUP_PS_CSV).WriteUpdate = File.GetLastWriteTime(strFullPath).ToString("yyyy/MM/dd HH:mm:ss")
                End If
            End If

            CheckExistVerUpCsvPs = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "CheckExistVerUpCsvPs")

        End Try

    End Function

    ''' <summary>
    ''' 機能：バージョンアップエクスポートT_PPRICE(CSV)存在チェック
    ''' </summary>
    ''' <param name="intRow"></param>
    ''' <param name="strObjectName"></param>
    ''' <param name="blnFileCheck"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckExistVerUpCsvPsPrice(ByVal intRow As Integer, ByVal strObjectName As String, ByVal blnFileCheck As Boolean) As Boolean

        Dim strPath As String = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT) & _
                                    DIR_VERUP & "\" & DIR_SEND & "\"
        Dim strFiles() As String
        Dim strPsFile As String = ""
        Dim strPsdFile As String = ""
        Dim strFullPath As String = ""
        Dim arrSort As New ArrayList

        CheckExistVerUpCsvPsPrice = False

        Try
            'Paymentsheet　ファイル名・更新時間取得
            strPsFile = typCpNo(intRow).CpNo & "_999_T_PPRICE*.csv"
            strFiles = Directory.GetFiles(strPath, strPsFile)
            If strFiles.Length > 0 Then
                For intCnt As Integer = 0 To (strFiles.Length - 1)
                    If Path.GetFileName(strFiles(intCnt)).Length = 39 Then
                        arrSort.Add(strFiles(intCnt))
                    End If
                Next
                If arrSort.Count > 0 Then
                    arrSort.Sort()
                    typCpNo(intRow).FileFormation(CD_FILEFROMATION_VERUP_PS_PRICE_CSV).Path = strPath
                    typCpNo(intRow).FileFormation(CD_FILEFROMATION_VERUP_PS_PRICE_CSV).FileName = Path.GetFileName(arrSort(arrSort.Count - 1).ToString)
                    strFullPath = typCpNo(intRow).FileFormation(CD_FILEFROMATION_VERUP_PS_PRICE_CSV).Path & typCpNo(intRow).FileFormation(CD_FILEFROMATION_VERUP_PS_PRICE_CSV).FileName
                    typCpNo(intRow).FileFormation(CD_FILEFROMATION_VERUP_PS_PRICE_CSV).WriteUpdate = File.GetLastWriteTime(strFullPath).ToString("yyyy/MM/dd HH:mm:ss")
                End If
            End If

            CheckExistVerUpCsvPsPrice = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "CheckExistVerUpCsvPsPrice")

        End Try

    End Function

    ''' <summary>
    ''' 機能：バージョンアップエクスポート詳細(CSV)存在チェック
    ''' </summary>
    ''' <param name="intRow"></param>
    ''' <param name="strObjectName"></param>
    ''' <param name="blnFileCheck"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckExistVerUpCsvDetail(ByVal intRow As Integer, ByVal strObjectName As String, ByVal blnFileCheck As Boolean) As Boolean

        Dim strPath As String = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT) & _
                                    DIR_VERUP & "\" & DIR_SEND & "\"
        Dim strFiles() As String
        Dim strPsFile As String = ""
        Dim strPsdFile As String = ""
        Dim strFullPath As String = ""
        Dim arrSort As New ArrayList

        CheckExistVerUpCsvDetail = False

        Try
            'Paymentsheet　ファイル名・更新時間取得
            strPsFile = typCpNo(intRow).CpNo & "_999_T_PLINE_DETAIL*.csv"
            strFiles = Directory.GetFiles(strPath, strPsFile)
            If strFiles.Length > 0 Then
                arrSort.AddRange(strFiles)
                arrSort.Sort()
                typCpNo(intRow).FileFormation(CD_FILEFROMATION_VERUP_DETAIL_CSV).Path = strPath
                typCpNo(intRow).FileFormation(CD_FILEFROMATION_VERUP_DETAIL_CSV).FileName = Path.GetFileName(arrSort(arrSort.Count - 1).ToString)
                strFullPath = typCpNo(intRow).FileFormation(CD_FILEFROMATION_VERUP_DETAIL_CSV).Path & typCpNo(intRow).FileFormation(CD_FILEFROMATION_VERUP_DETAIL_CSV).FileName
                typCpNo(intRow).FileFormation(CD_FILEFROMATION_VERUP_DETAIL_CSV).WriteUpdate = File.GetLastWriteTime(strFullPath).ToString("yyyy/MM/dd HH:mm:ss")
            End If

            CheckExistVerUpCsvDetail = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "CheckExistVerUpCsvDetail")

        End Try

    End Function

    ''' <summary>
    ''' 機能：フォルダ作成
    ''' </summary>
    ''' <returns>True:正常　False:異常</returns>
    ''' <remarks></remarks>
    Private Function CreateFolder() As Boolean

        Dim strPath As String = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT)
        Dim strYearMonth As String = cboWorkDate.Text.Substring(0, 4) & cboWorkDate.Text.Substring(5, 2)
        Dim strFolder() As String = {DIR_RECV, _
                                     DIR_SEND, _
                                     DIR_EXCEL & "\" & DIR_ACT & "\" & strYearMonth & "\" & DIR_INPUT_FILE, _
                                     DIR_EXCEL & "\" & DIR_ACT & "\" & strYearMonth & "\" & DIR_OUTPUT_FILE, _
                                     DIR_EXCEL & "\" & DIR_ACT & "\" & strYearMonth & "\" & DIR_UPDATE_FILE, _
                                     DIR_EXCEL & "\" & DIR_ACT & "\" & strYearMonth & "\" & DIR_LOG_FILE, _
                                     DIR_EXCEL & "\" & DIR_ACT & "\" & strYearMonth & "\" & DIR_SEND_LOWER, _
                                     DIR_EXCEL & "\" & DIR_ACT & "\" & strYearMonth & "\" & DIR_RECV_MAKE, _
                                     DIR_EXCEL & "\" & DIR_ACT & "\" & strYearMonth & "\" & DIR_RECV_UPDT, _
                                     DIR_EXCEL & "\" & DIR_DELIVERY & "\" & strYearMonth & "\" & DIR_INPUT_FILE, _
                                     DIR_EXCEL & "\" & DIR_DELIVERY & "\" & strYearMonth & "\" & DIR_OUTPUT_FILE, _
                                     DIR_EXCEL & "\" & DIR_DELIVERY & "\" & strYearMonth & "\" & DIR_UPDATE_FILE, _
                                     DIR_EXCEL & "\" & DIR_DELIVERY & "\" & strYearMonth & "\" & DIR_LOG_FILE, _
                                     DIR_EXCEL & "\" & DIR_DELIVERY & "\" & strYearMonth & "\" & DIR_SEND_LOWER, _
                                     DIR_EXCEL & "\" & DIR_DELIVERY & "\" & strYearMonth & "\" & DIR_RECV_MAKE, _
                                     DIR_EXCEL & "\" & DIR_DELIVERY & "\" & strYearMonth & "\" & DIR_RECV_UPDT, _
                                     DIR_EXCEL & "\" & DIR_STANDARD & "\" & DIR_SETTING_FILE, _
                                     DIR_EXCEL & "\" & DIR_STANDARD & "\" & DIR_REPORT_FILE, _
                                     DIR_EXCEL & "\" & DIR_STANDARD & "\" & DIR_LOG_FILE, _
                                     DIR_VERUP & "\" & DIR_MDB, _
                                     DIR_VERUP & "\" & DIR_EXCEL, _
                                     DIR_VERUP & "\" & DIR_RECV, _
                                     DIR_VERUP & "\" & DIR_SEND, _
                                     DIR_VERUP & "\" & DIR_LOG_FILE}

        Dim intCnt As Integer

        CreateFolder = False

        Try
            For intCnt = 0 To strFolder.Length - 1
                If Directory.Exists(strPath & strFolder(intCnt)) = False Then
                    Directory.CreateDirectory(strPath & strFolder(intCnt))
                End If
            Next

            CreateFolder = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "CreateFolder")

        End Try

    End Function

    ''' <summary>
    ''' 機能：ログ出力
    ''' </summary>
    ''' <param name="strLogFileName"></param>
    ''' <param name="strData"></param>
    ''' <param name="blnAppend"></param>
    ''' <remarks></remarks>
    Private Sub WriteLog(ByVal strLogFileName As String, ByVal strData As String, ByVal blnAppend As Boolean)

        Dim writer As StreamWriter
        Dim strOutLine As String
        Dim dtNow As DateTime = DateTime.Now
        Dim strPath As String

        Try
            strPath = Path.GetDirectoryName(strLogFileName)
            If Directory.Exists(strPath) = False Then
                Directory.CreateDirectory(strPath)
            End If
            writer = New StreamWriter(strLogFileName, blnAppend, Encoding.GetEncoding("shift-jis"))
            strOutLine = dtNow.ToString("yyyy/MM/dd HH:mm:ss") & "," & strData
            Debug.Print(strOutLine)
            writer.WriteLine(strOutLine)
            writer.Close()

        Catch ex As Exception
            Throw ex

        End Try

    End Sub

    ''' <summary>
    ''' 機能：ログファイル名取得
    ''' </summary>
    ''' <param name="intTabCd"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetLogFileName(ByVal intTabCd As Integer) As String

        Dim strLogPath As String = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT) & DIR_EXCEL & "\"
        Dim strTab As String = ""

        GetLogFileName = ""

        Try
            If intTabCd = CD_TAB_STANDARD Then
                strLogPath = strLogPath & DIR_STANDARD & "\" & DIR_LOG_FILE & "\"
                strTab = "STANDARD"
            ElseIf intTabCd = CD_TAB_VERUP Then
                strLogPath = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT) & DIR_VERUP & "\" & DIR_LOG_FILE & "\"
                strTab = "VERSIONUP"
            Else
                If rdoAct.Checked = True Then
                    strLogPath = strLogPath & DIR_ACT & "\"
                Else
                    strLogPath = strLogPath & DIR_DELIVERY & "\"
                End If
                strLogPath = strLogPath & GetWorkDate() & "\" & DIR_LOG_FILE & "\"
                Select Case intTabCd
                    Case CD_BUTTON_IMPCSV
                        strTab = "Recv"
                    Case CD_BUTTON_EXPCSV
                        strTab = "Send"
                    Case CD_BUTTON_CRTEXCEL
                        strTab = "Make"
                    Case CD_BUTTON_REDEXCEL
                        strTab = "Recv_Updt"
                End Select
            End If
            GetLogFileName = strLogPath & "LOG_" & strTab & "_" & Now.ToString("yyyyMMddHHmmss") & ".txt"

        Catch ex As Exception
            Throw ex

        End Try

    End Function

    ''' <summary>
    ''' 機能：インポート用CSV変換処理
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
    'Private Function MainCsvToMdb(ByVal strLogFileName As String, ByVal intProcCd As Integer, ByRef blnImportOk As Boolean) As Boolean
    Private Function MainCsvToMdb(ByVal strLogFileName As String,
                                  ByVal intProcCd As Integer,
                                  ByVal intCpnoIndex As Integer,
                                  ByRef blnImportOk As Boolean,
                                  Optional ByRef frmProcDialog As frmProcessDialog = Nothing) As Boolean
        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

        Dim intIndex As Integer
        Dim arrayWritePsLine As New ArrayList
        Dim arrayWriteDetailLine As New ArrayList
        Dim strDbPath As String = ""
        Dim strExcelStartYear As String = ""
        Dim ic As New ImportCsv
        Dim OUTERR As OutputErrorList
        Dim md As New CreateTempDb
        Dim intRet As Integer
        Dim blnRet As Boolean
        Dim strMsg As String = ""
        Dim frmWait As New Frm_WaitDialog
        Dim strSourceFileName As String
        Dim eam As New ExcelAsrManage
        Dim intFileMax As Integer = 0
        Dim intFileCnt As Integer = 0
        Dim strObamaUrl As String
        Dim cc As CookieContainer = New CookieContainer()       'クッキー設定
        Dim strCsvPsFileName(0 To 5) As String
        Dim strCsvPsPath As String = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT & "\" & DIR_RECV)
        Dim sc As New ServerCsv
        Dim oe As New OutputExcel
        'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
        Dim intCnt As Integer
        Dim intMax As Integer
        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

        MainCsvToMdb = False

        Try
            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            If frmProcDialog Is Nothing Then
                Call InitProgress(True, frmWait, intFileMax)
            Else
                Call ActiveProcDialog(frmProcDialog, 1)
                Call WriteLog(strLogFileName, "サーバーログイン", True)
            End If
            'Call InitProgress(True, frmWait, intFileMax)
            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

            '==============================================
            'サーバーログイン
            '==============================================
            intRet = sc.LoginServer(intProcCd, cc, strObamaUrl, strMsg)
            If intRet <> ServerCsv.RET_OK Then
                If intRet = ServerCsv.RET_SYS_ERROR Then
                    MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0402"), Me.Text)
                End If
                Exit Function
            End If
            Me.Update()
            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            If frmProcDialog Is Nothing Then
                frmWait.Update()
            End If
            'frmWait.Update()
            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

            If intProcCd = OutputExcel.CD_PROC_OLD Then
                strCsvPsPath = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT & "\" & DIR_VERUP & "\" & DIR_RECV)
            Else
                If rdoAct.Checked = True Then
                    strCsvPsPath = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT & "\" & DIR_EXCEL & "\" & DIR_ACT & "\" & GetWorkDate() & "\" & DIR_RECV_MAKE)
                Else
                    strCsvPsPath = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT & "\" & DIR_EXCEL & "\" & DIR_DELIVERY & "\" & GetWorkDate() & "\" & DIR_RECV_MAKE)
                End If
            End If

            blnImportOk = True
            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            intMax = 1
            If intCpnoIndex = -1 Then
                intMax = typCpNo.Length - 1
            End If
            For intCnt = 1 To intMax
                strMsg = ""
                If intCpnoIndex = -1 Then
                    intIndex = intCnt
                Else
                    intIndex = intCpnoIndex
                End If
                With typCpNo(intIndex)
                    'For intIndex = 1 To (typCpNo.Length - 1)
                    'strMsg = ""
                    'With typCpNo(intIndex)
                    'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                    If .Checked = True And .DataOk = True Then
                        OUTERR = New OutputErrorList
                        OUTERR.CpNo = .CpNo
                        OUTERR.ContractNo = ""
                        OUTERR.OutImportErrorList("START", "Import(一括)", , , , True)
                        '==============================================
                        'サーバ ーからCSVファイルを取得
                        '==============================================
                        With sc
                            .GetPsCsvFlg = True
                            .GetPsValCsvFlg = False
                            .GetPsRefCsvFlg = False
                            .GetDetailCsvFlg = True
                            .GetDetailValCsvFlg = False
                            .GetDetailRefCsvFlg = False
                        End With
                        intRet = sc.GetServerCsvs(.CpNo, "", "C", strObamaUrl, cc, strCsvPsPath, strCsvPsFileName, strMsg)
                        If intRet <> ServerCsv.RET_OK Then
                            typCpNo(intIndex).ConvertFlg = CD_CONVERT_ERROR
                            strMsg = .CpNo & "," & .CustomerName & "," & strMsg
                            Call WriteLog(strLogFileName, strMsg, True)
                            blnImportOk = False
                            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                            'Continue For
                            Exit Function
                            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                        End If
                        .FileFormation(CD_FILEFROMATION_IMPORT_PS_CSV).Path = strCsvPsPath
                        .FileFormation(CD_FILEFROMATION_IMPORT_PS_CSV).FileName = strCsvPsFileName(0)
                        .FileFormation(CD_FILEFROMATION_IMPORT_PS_CSV).WriteUpdate = File.GetLastWriteTime(strCsvPsPath & strCsvPsFileName(0)).ToString("yyyy/MM/dd HH:mm:ss")
                        .FileFormation(CD_FILEFROMATION_IMPORT_DETAIL_CSV).Path = strCsvPsPath
                        .FileFormation(CD_FILEFROMATION_IMPORT_DETAIL_CSV).FileName = strCsvPsFileName(3)
                        .FileFormation(CD_FILEFROMATION_IMPORT_DETAIL_CSV).WriteUpdate = File.GetLastWriteTime(strCsvPsPath & strCsvPsFileName(3)).ToString("yyyy/MM/dd HH:mm:ss")
                        CommonVariable.CPNO = .CpNo
                        CommonVariable.PaymentStart = CDate(.ExcelStart & "/1/1")
                        CommonVariable.ContractStart = .ContractStart
                        CommonVariable.ContractEnd = .ContractEnd

                        '==========================================
                        'データを配列に保存（Refresh、Validation以外）
                        '==========================================
                        'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                        If Not frmProcDialog Is Nothing Then
                            Call ActiveProcDialog(frmProcDialog, 2)
                            Call WriteLog(strLogFileName, "DBに保存", True)
                        End If
                        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                        OUTERR.OutImportErrorList(FileReader.GetMessage("MSG_0463"), "Import")
                        Dim alPsCreating As New ArrayList
                        Dim alPsCreated As New ArrayList
                        Dim alPsdCreating As New ArrayList
                        Dim alPsdCreated As New ArrayList
                        Dim alPsCreatingMdb As New ArrayList
                        Dim alPsdCreatingMdb As New ArrayList
                        Dim filePath As ImportCsv.ServerCsvPath
                        Dim importCount As ImportCsv.ImportCount
                        Dim importErrCount As ImportCsv.ImportErrCount
                        With filePath
                            .PSCsv = strCsvPsPath & strCsvPsFileName(0)
                            .DetailCsv = strCsvPsPath & strCsvPsFileName(3)
                        End With
                        blnRet = ic.GetCsvData(ImportCsv.CD_IMPORT_MDB,
                                               filePath,
                                               .PaymentPeriod,
                                               alPsCreating,
                                               alPsCreatingMdb,
                                               alPsCreated,
                                               alPsdCreating,
                                               alPsdCreatingMdb,
                                               alPsdCreated,
                                               importCount,
                                               importErrCount,
                                               OUTERR,
                                               False)
                        OUTERR.OutImportErrorList(FileReader.GetMessage("MSG_0464"), "Import")
                        If blnRet = True Then
                            '==========================================
                            'MDB保存
                            '==========================================
                            blnRet = ic.ImportDb(alPsCreated,
                                              alPsdCreated,
                                              .ExcelStart,
                                              importCount,
                                              OUTERR,
                                              False,
                                              False)
                            If blnRet = False Then
                                OUTERR.OutImportErrorList(FileReader.GetMessage("MSG_0338") & "MainCsvToMdb", "Import")
                            End If
                        End If

                        '==========================================
                        'ログ出力
                        '==========================================
                        strMsg = .CpNo & "," & .CustomerName & ","
                        If blnRet = False Then
                            .ConvertFlg = CD_CONVERT_ERROR
                            strMsg = strMsg & "インポート用CSV変換エラー"
                            blnImportOk = False
                        Else
                            .DbPsCount = importCount.MDBCount
                            .DbPsdCount = importCount.MDBDetailCount
                            strMsg = strMsg & "Payment:" & importCount.MDBCount.ToString.ToUpper & "件取込、"
                            strMsg = strMsg & "詳細:" & importCount.MDBDetailCount.ToString.ToUpper & "件取込"
                            '個別PSリネーム
                            strSourceFileName = .FileFormation(CD_FILEFROMATION_IMPORT_PS_CSV).Path & _
                                                .FileFormation(CD_FILEFROMATION_IMPORT_PS_CSV).FileName
                            Call eam.ReNameBKFile(strSourceFileName)
                            strSourceFileName = .FileFormation(CD_FILEFROMATION_IMPORT_DETAIL_CSV).Path & _
                                                .FileFormation(CD_FILEFROMATION_IMPORT_DETAIL_CSV).FileName
                            Call eam.ReNameBKFile(strSourceFileName)

                            .ConvertFlg = CD_CONVERT_OK
                        End If
                        Call WriteLog(strLogFileName, strMsg, True)
                        OUTERR.OutImportErrorList("END", "Import")
                        OUTERR = Nothing

                        intFileCnt = intFileCnt + 1
                        'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                        If frmProcDialog Is Nothing Then
                            Call ActiveProgress(frmWait, intFileCnt, intFileMax)
                        End If
                        'Call ActiveProgress(frmWait, intFileCnt, intFileMax)
                        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                    End If
                End With
            Next

            MainCsvToMdb = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "MainCsvToMdb")
            blnImportOk = False

        Finally
            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            If frmProcDialog Is Nothing Then
                Call EndProgress(frmWait)
            End If
            'Call EndProgress(frmWait)
            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

        End Try

    End Function

    ''' <summary>
    ''' 機能：作成処理
    ''' </summary>
    ''' <param name="strLogFileName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function MainMakeAsrManage(ByVal strLogFileName As String) As Boolean

        Dim intIndex As Integer
        Dim arrayWriteObjLine As New ArrayList
        Dim strDbPath As String = ""
        Dim strExcelStartYear As String = ""
        Dim OUTERR As New OutputErrorList
        Dim md As New CreateTempDb
        Dim eam As New ExcelAsrManage
        Dim strMsg As String = ""
        Dim strOutputPath As String
        Dim ofm As New OioFileManage
        'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
        'Dim frmWait As New Frm_WaitDialog
        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
        Dim intFileMax As Integer = 0
        Dim intFileCnt As Integer = 0
        Dim intContractStart As Integer
        Dim intContractEnd As Integer
        'Req.1702 実行支援レポート変更 2018/12 Str
        'Dim blnOutputSheet(3) As Boolean
        Dim blnOutputSheet(4) As Boolean
        'Req.1702 実行支援レポート変更 2018/12 End
        'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
        Dim frmProc As New frmProcessDialog
        Dim strRet As String
        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

        MainMakeAsrManage = False

        Try
            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            Dim strLblMsg() As String = {"",
                                         "",
                                         "",
                                         "処理"}
            Dim strLblProc() As String = {"　①サーバからデータ取得中",
                                          "　②DBに保存中",
                                          "　③支援ファイル作成中",
                                          "　④zipファイル作成中",
                                          "",
                                          "",
                                          "",
                                          ""}
            Call InitProcDialog(frmProc,
                                strLblMsg,
                                strLblProc,
                                intFileMax)
            'Call InitProgress(True, frmWait, intFileMax)
            'frmWait.Activate2(Me)
            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

            For intIndex = 1 To (typCpNo.Length - 1)
                With typCpNo(intIndex)
                    If .Checked = True And .DataOk = True Then
                        CommonVariable.CPNO = .CpNo
                        CommonVariable.CUSTOMERNAME = .CustomerName

                        'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                        Call ActiveProcDialogCountUp(frmProc, intFileCnt, intFileMax)
                        Call WriteLog(strLogFileName, "========= CPNO:" & CommonVariable.CPNO & "、" & CommonVariable.CUSTOMERNAME & "を処理中 =========", True)
                        Dim strFileActAll As String = ""
                        Dim strFileActOffer As String = ""
                        Dim strFileDelivery As String = ""

                        '========================================
                        'インポート処理（CSV→MDB）
                        '========================================
                        Dim blnRet As Boolean
                        Dim oe As New OutputExcel
                        Dim blnImportOk As Boolean = True
                        'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                        blnRet = MainCsvToMdb(strLogFileName,
                                              OutputExcel.CD_PROC_NEW,
                                              intIndex,
                                              blnImportOk,
                                              frmProc)
                        'blnRet = MainCsvToMdb(strLogFileName, OutputExcel.CD_PROC_NEW, blnImportOk)
                        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                        If blnRet = True Then
                            Call WriteLog(strLogFileName, FileReader.GetMessage("MSG_0391"), True)

                            Call ActiveProcDialog(frmProc, 3)
                            Call WriteLog(strLogFileName, "支援ファイル作成", True)
                            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

                            If rdoAct.Checked = True Or rdoBoth.Checked = True Then
                                '========================================
                                '実行管理作成
                                '========================================
                                strOutputPath = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT) & DIR_EXCEL & "\" & _
                                                    DIR_ACT & "\" & _
                                                    GetWorkDate() & "\" & _
                                                    DIR_OUTPUT_FILE & "\"
                                strMsg = ""
                                intContractStart = (CDate(.ContractStart).Year - 2000) * 12 + CDate(.ContractStart).Month
                                intContractEnd = (CDate(.ContractEnd).Year - 2000) * 12 + CDate(.ContractEnd).Month
                                blnOutputSheet(eam.CD_ACT_OUTPUT1) = cbSheet1.Checked
                                blnOutputSheet(eam.CD_ACT_OUTPUT2) = cbSheet2.Checked
                                blnOutputSheet(eam.CD_ACT_OUTPUT3) = cbSheet3.Checked
                                blnOutputSheet(eam.CD_ACT_OUTPUT4) = cbSheet4.Checked
                                'Req.1702 実行支援レポート変更 2018/12 Str
                                blnOutputSheet(eam.CD_ACT_OUTPUT5) = cbSheet5.Checked
                                'Req.1702 実行支援レポート変更 2018/12 End
                                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                                Call eam.OutputActExcel(strOutputPath,
                                                        intContractStart,
                                                        intContractEnd,
                                                        Integer.Parse(.ExcelStart),
                                                        Integer.Parse(.PaymentPeriod),
                                                        blnOutputSheet,
                                                        strFileActAll,
                                                        strFileActOffer,
                                                        strMsg)
                                'Call eam.OutputActExcel(strOutputPath,
                                '                        intContractStart,
                                '                        intContractEnd,
                                '                        Integer.Parse(.ExcelStart),
                                '                        Integer.Parse(.PaymentPeriod),
                                '                        blnOutputSheet,
                                '                        strMsg)
                                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                                'ログ出力
                                strMsg = .CpNo & "," & .CustomerName & "," & strMsg
                                Call WriteLog(strLogFileName, strMsg, True)

                            End If

                            If rdoDeliv.Checked = True Or rdoBoth.Checked = True Then
                                '========================================
                                'ﾃﾞﾘﾊﾞﾘ管理作成
                                '========================================
                                strOutputPath = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT) & DIR_EXCEL & "\" & _
                                                    DIR_DELIVERY & "\" & _
                                                    GetWorkDate() & "\" & _
                                                    DIR_OUTPUT_FILE & "\"
                                strMsg = ""
                                eam.TEMP_DERI_FILE_NAME = "PaymentLineDeliveryExportSample.xlsm"
                                eam.TEMP_DIR_PATH = FileManager.GetLocalFolderPath(CommonConstant.FOLDERNAME_TEMPLATE)
                                eam.DERI_OUT_DIR = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT) & DIR_EXCEL & "\" & _
                                                    DIR_DELIVERY & "\" & _
                                                    GetWorkDate() & "\" & _
                                                    DIR_OUTPUT_FILE & "\"
                                eam.ContractMDBPath = ofm.GetDataKeepMDBPath(CommonVariable.CPNO)
                                'ﾃﾞﾘﾊﾞﾘ管理作成処理
                                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                                Call eam.OutputDeriFile(.PaymentPeriod, strFileDelivery, strMsg)
                                'Call eam.OutputDeriFile(.PaymentPeriod, strMsg)
                                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                                'ログ出力
                                strMsg = .CpNo & "," & .CustomerName & "," & strMsg
                                Call WriteLog(strLogFileName, strMsg, True)
                            End If

                            intFileCnt = intFileCnt + 1
                            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                            'Call ActiveProgress(frmWait, intFileCnt, intFileMax)
                            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                        Else
                            Call WriteLog(strLogFileName, FileReader.GetMessage("MSG_0392"), True)
                            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                            'サーバからのデータ取得に失敗しました。
                            .OutputState = FileReader.GetMessage("MSG_0552")
                            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                        End If

                        'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                        If .OutputState = "" Then
                            '========================================
                            'ZIPﾌｧｲﾙ作成
                            '========================================
                            Call ActiveProcDialog(frmProc, 4)
                            Call WriteLog(strLogFileName, "zipファイル作成", True)
                            '実行支援ファイル(全)
                            Debug.Print("実行支援ファイル(全)")
                            strRet = CreateZip(strFileActAll)
                            If strRet <> "" Then
                                .OutputState = strRet
                                Call WriteLog(strLogFileName, strRet, True)
                                Continue For
                            End If
                            '実行支援ファイル(連携)
                            Debug.Print("実行支援ファイル(連携)")
                            strRet = CreateZip(strFileActOffer)
                            If strRet <> "" Then
                                .OutputState = strRet
                                Call WriteLog(strLogFileName, strRet, True)
                                Continue For
                            End If
                            'デリバリ支援ファイル
                            Debug.Print("デリバリ支援ファイル")
                            strRet = CreateZip(strFileDelivery)
                            If strRet <> "" Then
                                .OutputState = strRet
                                Call WriteLog(strLogFileName, strRet, True)
                                Continue For
                            End If

                            '========================================
                            '出力状況の設定
                            '========================================
                            '作成出来ませんでした。
                            Dim strOutputState As String = FileReader.GetMessage("MSG_0553")
                            If .DbPsCount = 0 Then
                                '契約済データがありません。
                                strOutputState = FileReader.GetMessage("MSG_0554")
                            Else
                                If rdoAct.Checked = True Then
                                    If strFileActAll <> "" Then
                                        '実行支援ファイルを作成しました。
                                        strOutputState = FileReader.GetMessage("MSG_0555")
                                    Else
                                        '出力データがありません。
                                        strOutputState = FileReader.GetMessage("MSG_0556")
                                    End If
                                ElseIf rdoDeliv.Checked = True Then
                                    If strFileDelivery <> "" Then
                                        'デリバリ支援ファイルを作成しました。
                                        strOutputState = FileReader.GetMessage("MSG_0557")
                                    End If
                                ElseIf rdoBoth.Checked = True Then
                                    If strFileActAll <> "" And
                                        strFileDelivery <> "" Then
                                        '実行・デリバリ支援ファイルを作成しました。
                                        strOutputState = FileReader.GetMessage("MSG_0558")
                                    ElseIf strFileActAll <> "" Then
                                        '実行支援ファイルを作成しました。
                                        strOutputState = FileReader.GetMessage("MSG_0555")
                                    ElseIf strFileDelivery <> "" Then
                                        'デリバリ支援ファイルを作成しました。
                                        strOutputState = FileReader.GetMessage("MSG_0557")
                                    End If
                                End If
                            End If
                            .OutputState = strOutputState
                            Call WriteLog(strLogFileName, strOutputState, True)
                        End If
                        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                    End If
                End With
            Next

            MainMakeAsrManage = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "MainMakeAsrManage")

        Finally
            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            frmProc.Close()
            'Call EndProgress(frmWait)
            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

        End Try

    End Function

    ''' <summary>
    ''' 機能：読込処理
    ''' </summary>
    ''' <param name="strLogFileName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function MainLoadAsrManage(ByVal strLogFileName As String) As Boolean

        Dim intIndex As Integer
        Dim arrayWriteObjLine As New ArrayList
        Dim strDbPath As String = ""
        Dim strExcelStartYear As String = ""
        Dim OUTERR As OutputErrorList
        Dim md As New CreateTempDb
        Dim blnRet As Boolean
        Dim intRet As Integer
        Dim eam As New ExcelAsrManage
        Dim strMsg As String = ""
        Dim ofm As New OioFileManage
        Dim intOutputCnt As Integer
        'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
        'Dim frmWait As New Frm_WaitDialog
        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
        Dim strCsvFileName As String
        Dim intFileMax As Integer = 0
        Dim intFileCnt As Integer = 0
        Dim strObamaUrl As String
        Dim cc As CookieContainer = New CookieContainer()       'クッキー設定
        Dim strCsvPsFileName(0 To 5) As String
        Dim strCsvPsPath As String
        If rdoAct.Checked = True Then
            strCsvPsPath = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT & "\" & DIR_EXCEL & "\" & DIR_ACT & "\" & GetWorkDate() & "\" & DIR_RECV_UPDT)
        Else
            strCsvPsPath = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT & "\" & DIR_EXCEL & "\" & DIR_DELIVERY & "\" & GetWorkDate() & "\" & DIR_RECV_UPDT)
        End If
        Dim sc As New ServerCsv
        Dim oe As New OutputExcel
        Dim ic As New ImportCsv
        'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
        Dim frmProc As New frmProcessDialog
        Dim strRet As String
        Dim strActFile As String
        Dim strDeliveryFile As String
        Dim strFileActOffer As String
        Dim strFileDelivery As String
        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

        MainLoadAsrManage = False

        Try
            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            '==============================================
            '処理中メッセージ初期化
            '==============================================
            Dim strLblMsg() As String = {"",
                                         "",
                                         "",
                                         "処理"}
            Dim strLblProc() As String = {"　①サーバからデータ取得中",
                                          "　②DBに保存中",
                                          "　③支援ファイル読込、統合Payment作成中",
                                          "　④インポート用CSV作成中",
                                          "　⑤サーバへインポート中",
                                          "　⑥zipファイル作成中",
                                          "",
                                          ""}
            Call InitProcDialog(frmProc,
                                strLblMsg,
                                strLblProc,
                                intFileMax)
            'Call InitProgress(True, frmWait, intFileMax)
            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

            '==============================================
            'サーバーログイン
            '==============================================
            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            Call WriteLog(strLogFileName, "サーバーログイン", True)
            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            intRet = sc.LoginServer(OutputExcel.CD_PROC_NEW, cc, strObamaUrl, strMsg)
            If intRet <> ServerCsv.RET_OK Then
                If intRet = ServerCsv.RET_SYS_ERROR Then
                    MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0402"), Me.Text)
                End If
                Exit Function
            End If
            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            'Me.Update()
            'frmWait.Update()
            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

            For intIndex = 1 To (typCpNo.Length - 1)
                strMsg = ""
                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                strActFile = ""
                strDeliveryFile = ""
                strFileActOffer = ""
                strFileDelivery = ""
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                With typCpNo(intIndex)
                    'チェックONかつファイルチェックOKなデータ
                    If .Checked = True And .DataOk = True Then
                        'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                        CommonVariable.CPNO = .CpNo
                        CommonVariable.CUSTOMERNAME = .CustomerName
                        Call ActiveProcDialogCountUp(frmProc, intFileCnt, intFileMax)
                        Call WriteLog(strLogFileName, "========= CPNO:" & CommonVariable.CPNO & "、" & CommonVariable.CUSTOMERNAME & "を処理中 =========", True)
                        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                        OUTERR = New OutputErrorList
                        OUTERR.CpNo = .CpNo
                        OUTERR.ContractNo = ""
                        OUTERR.OutImportErrorList("START", "支援ファイル読込(一括)", , , , True)
                        '==============================================
                        'サーバーからCSVファイルを取得
                        '==============================================
                        'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                        Call ActiveProcDialog(frmProc, 1)
                        Call WriteLog(strLogFileName, "サーバーからCSVファイルを取得", True)
                        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                        With sc
                            .GetPsCsvFlg = True
                            .GetPsValCsvFlg = False
                            .GetPsRefCsvFlg = False
                            .GetDetailCsvFlg = True
                            .GetDetailValCsvFlg = False
                            .GetDetailRefCsvFlg = False
                        End With
                        intRet = sc.GetServerCsvs(.CpNo, "", "C", strObamaUrl, cc, strCsvPsPath, strCsvPsFileName, strMsg)
                        If intRet <> ServerCsv.RET_OK Then
                            .ConvertFlg = CD_CONVERT_ERROR
                            strMsg = .CpNo & "," & .CustomerName & "," & strMsg
                            Call WriteLog(strLogFileName, strMsg, True)
                            Continue For
                        End If

                        .FileFormation(CD_FILEFROMATION_IMPORT_PS_CSV).Path = strCsvPsPath
                        .FileFormation(CD_FILEFROMATION_IMPORT_PS_CSV).FileName = strCsvPsFileName(0)
                        .FileFormation(CD_FILEFROMATION_IMPORT_PS_CSV).WriteUpdate = File.GetLastWriteTime(strCsvPsPath & strCsvPsFileName(0)).ToString("yyyy/MM/dd HH:mm:ss")
                        'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                        'CommonVariable.CPNO = .CpNo
                        'CommonVariable.CUSTOMERNAME = .CustomerName
                        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                        CommonVariable.PaymentStart = CDate(.ExcelStart & "/1/1")
                        CommonVariable.ContractStart = .ContractStart
                        CommonVariable.ContractEnd = .ContractEnd

                        '==========================================
                        'データを配列に保存（Refresh、Validation以外）
                        '==========================================
                        'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                        Call ActiveProcDialog(frmProc, 2)
                        Call WriteLog(strLogFileName, "DBに保存", True)
                        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                        OUTERR.OutImportErrorList(FileReader.GetMessage("MSG_0463"), "Import")
                        Dim alPsCreating As New ArrayList
                        Dim alPsCreated As New ArrayList
                        Dim alPsdCreating As New ArrayList
                        Dim alPsdCreated As New ArrayList
                        Dim alPsCreatingMdb As New ArrayList
                        Dim alPsdCreatingMdb As New ArrayList
                        Dim filePath As ImportCsv.ServerCsvPath
                        Dim importCount As ImportCsv.ImportCount
                        Dim importErrCount As ImportCsv.ImportErrCount
                        With filePath
                            .PSCsv = strCsvPsPath & strCsvPsFileName(0)
                            .DetailCsv = strCsvPsPath & strCsvPsFileName(3)
                        End With
                        blnRet = ic.GetCsvData(ImportCsv.CD_IMPORT_MDB,
                                            filePath,
                                            .PaymentPeriod,
                                            alPsCreating,
                                            alPsCreatingMdb,
                                            alPsCreated,
                                            alPsdCreating,
                                            alPsdCreatingMdb,
                                            alPsdCreated,
                                            importCount,
                                            importErrCount,
                                            OUTERR,
                                            False)
                        OUTERR.OutImportErrorList(FileReader.GetMessage("MSG_0464"), "Import")
                        If blnRet = True Then
                            '==========================================
                            'MDB保存
                            '==========================================
                            blnRet = ic.ImportDb(alPsCreated,
                                              alPsdCreated,
                                              .ExcelStart,
                                              importCount,
                                              OUTERR,
                                              False,
                                              False)
                            If blnRet = False Then
                                OUTERR.OutImportErrorList(FileReader.GetMessage("MSG_0338") & "MainCsvToMdb", "Import")
                                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                                'サーバからのデータ取得に失敗しました。
                                .OutputState = "サーバからのデータ取得に失敗しました"
                                Call WriteLog(strLogFileName, .OutputState, True)
                                Continue For
                            Else
                                .DbPsCount = importCount.MDBCount
                                .DbPsdCount = importCount.MDBDetailCount
                                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                            End If
                            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                        Else
                            'サーバからのデータ取得に失敗しました。
                            .OutputState = "サーバからのデータ取得に失敗しました"
                            Call WriteLog(strLogFileName, .OutputState, True)
                            Continue For
                            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                        End If
                        strCsvFileName = filePath.PSCsv

                        '=============================================
                        'Paymentline作成処理（DB → EXCEL）
                        '=============================================
                        Dim strPaymentFileName As String = ""
                        blnRet = DbToExcelPayment(intIndex, strPaymentFileName, strMsg)
                        If blnRet = False Then
                            .ConvertFlg = CD_CONVERT_ERROR
                            strMsg = .CpNo & "," & .CustomerName & "," & strMsg
                            Call WriteLog(strLogFileName, strMsg, True)
                            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                            'サーバからのデータ取得に失敗しました。
                            .OutputState = "サーバからのデータ取得に失敗しました"
                            Call WriteLog(strLogFileName, .OutputState, True)
                            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                            Continue For
                        End If
                        'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                        .FileFormation(CD_FILEFROMATION_PS).Path = Path.GetDirectoryName(strPaymentFileName) & "\"
                        .FileFormation(CD_FILEFROMATION_PS).FileName = Path.GetFileName(strPaymentFileName)
                        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

                        '=============================================
                        '管理ファイルをPaymentlineに反映
                        '=============================================
                        'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                        Call ActiveProcDialog(frmProc, 3)
                        Call WriteLog(strLogFileName, "支援ファイル読込、統合Payment作成", True)
                        intOutputCnt = 0
                        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                        strMsg = ""
                        If rdoAct.Checked = True Then
                            '実行管理読込
                            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                            strActFile = .FileFormation(CD_FILEFROMATION_MANAGE_INPUT).Path & _
                                         .FileFormation(CD_FILEFROMATION_MANAGE_INPUT).FileName
                            'intOutputCnt = 0
                            'Dim strActFile As String = .FileFormation(CD_FILEFROMATION_MANAGE_INPUT).Path & _
                            '                            .FileFormation(CD_FILEFROMATION_MANAGE_INPUT).FileName
                            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                            blnRet = eam.ImportActData(strActFile,
                                                       strPaymentFileName,
                                                       .PaymentPeriod,
                                                       intOutputCnt,
                                                       strMsg)
                            If blnRet = True Then
                                'BKファイル作成
                                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                                'Call eam.ReNameBKFile(strActFile)
                                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                                Call eam.ReNameBKFile(strCsvFileName)
                                .ConvertFlg = CD_CONVERT_OK
                            Else
                                .ConvertFlg = CD_CONVERT_ERROR
                            End If

                            strMsg = .CpNo & "," & .CustomerName & "," & strMsg
                            Call WriteLog(strLogFileName, strMsg, True)
                        Else
                            'ﾃﾞﾘﾊﾞﾘ管理読込
                            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                            strDeliveryFile = .FileFormation(CD_FILEFROMATION_MANAGE_INPUT).Path & _
                                              .FileFormation(CD_FILEFROMATION_MANAGE_INPUT).FileName
                            'Dim strDeliveryFile As String = .FileFormation(CD_FILEFROMATION_MANAGE_INPUT).Path & _
                            '                                .FileFormation(CD_FILEFROMATION_MANAGE_INPUT).FileName
                            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                            Dim derivaryCount As ExcelAsrManage.derivaryCount
                            Dim updFlgU As Boolean
                            Dim sheetChkFlg As Boolean          ''ワークシートの入力ﾁｪｯｸがOKになっているかどうか？
                            Dim isSuccess As Boolean
                            Dim msgKB As String

                            isSuccess = eam.deliveryReflection(.PaymentPeriod,
                                                               strDeliveryFile,
                                                               strPaymentFileName,
                                                               derivaryCount,
                                                               updFlgU,
                                                               sheetChkFlg)
                            If isSuccess = True Then
                                'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                                intOutputCnt = derivaryCount.InsertCount
                                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                                eam.GetExitMsg(strMsg, msgKB, strPaymentFileName, derivaryCount, updFlgU, sheetChkFlg)

                                strMsg = vbCrLf & strMsg
                                If msgKB = ExcelAsrManage.MSG_OK Then
                                    ''BKﾌｧｲﾙ作成
                                    'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                                    'Call eam.ReNameBKFile(strDeliveryFile)
                                    'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                                    Call eam.ReNameBKFile(strCsvFileName)
                                    '警告メッセージの場合に、取込件数によってFlgを変える
                                    If derivaryCount.InsertCount = 0 Then
                                        .ConvertFlg = CD_CONVERT_OK_NODATA
                                    Else
                                        .ConvertFlg = CD_CONVERT_OK
                                    End If
                                Else
                                    If msgKB = ExcelAsrManage.MSG_CRITICAL Then
                                        ''BKﾌｧｲﾙ作成
                                        'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                                        'Call eam.ReNameBKFile(strDeliveryFile)
                                        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                                        Call eam.ReNameBKFile(strCsvFileName)
                                        '警告メッセージの場合に、取込件数によってFlgを変える
                                        If derivaryCount.InsertCount = 0 Then
                                            .ConvertFlg = CD_CONVERT_EXCLAMATION_NODATA
                                        Else
                                            .ConvertFlg = CD_CONVERT_EXCLAMATION
                                        End If
                                    Else
                                        .ConvertFlg = CD_CONVERT_ERROR
                                    End If
                                End If
                            Else
                                .ConvertFlg = CD_CONVERT_ERROR
                            End If
                            strMsg = .CpNo & "," & .CustomerName & "," & strMsg & vbCrLf
                            Call WriteLog(strLogFileName, strMsg, True)
                        End If

                        '=============================================
                        'ダブり行削除
                        '=============================================
                        blnRet = DeleteDoubleLine(strPaymentFileName)

                        OUTERR.OutImportErrorList("END", "Import")
                        'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                        'OUTERR = Nothing
                        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

                        'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                        'START 変更管理#59（更新件数0件時にインポートしない対応）2019/04 ueda
                        If intOutputCnt <> 0 Then
                            'END 変更管理#59（更新件数0件時にインポートしない対応）2019/04 ueda
                            intFileCnt = intFileCnt + 1
                            '=============================================
                            'エクスポート用CSV変換処理
                            '=============================================
                            Call ActiveProcDialog(frmProc, 4)
                            Call WriteLog(strLogFileName, "インポート用CSV作成", True)
                            Dim strFilePsCsv As String = ""
                            Dim strFilePsdCsv As String = ""
                            blnRet = MainExcelToCsv(strLogFileName, intIndex, strFilePsCsv, strFilePsdCsv)
                            If blnRet = False Then
                                Exit Function
                            End If

                            '=============================================
                            'サーバーインポート処理
                            '=============================================
                            Call ActiveProcDialog(frmProc, 5)
                            Call WriteLog(strLogFileName, "サーバへインポート", True)
                            blnRet = sc.DirectServerCsvImport(strFilePsCsv,
                                                              strFilePsdCsv,
                                                              "K",
                                                              "F",
                                                              Nothing,
                                                              OUTERR)
                            If blnRet = True Then
                                '========================================
                                '支援ファイルのリネーム（BK_xxx）
                                '========================================
                                If strActFile <> "" Then
                                    Call eam.ReNameBKFile(strActFile, strFileActOffer)
                                End If
                                If strDeliveryFile <> "" Then
                                    Call eam.ReNameBKFile(strDeliveryFile, strFileDelivery)
                                End If

                                '========================================
                                'ZIPﾌｧｲﾙ作成
                                '========================================
                                If .OutputState = "" Then
                                    Call ActiveProcDialog(frmProc, 6)
                                    Call WriteLog(strLogFileName, "zipファイル作成", True)
                                    '実行支援ファイル(連携)
                                    Debug.Print("実行支援ファイル(連携)")
                                    strRet = CreateZip(strFileActOffer)
                                    If strRet <> "" Then
                                        .OutputState = strRet
                                        Call WriteLog(strLogFileName, strRet, True)
                                        Continue For
                                    End If
                                    'デリバリ支援ファイル
                                    Debug.Print("デリバリ支援ファイル")
                                    strRet = CreateZip(strFileDelivery)
                                    If strRet <> "" Then
                                        .OutputState = strRet
                                        Call WriteLog(strLogFileName, strRet, True)
                                        Continue For
                                    End If

                                    '========================================
                                    '出力状況の設定
                                    '========================================
                                    Dim strOutputState As String
                                    If .DbPsCount = 0 Then
                                        '契約済データがありません。
                                        strOutputState = FileReader.GetMessage("MSG_0554")
                                    Else
                                        If intOutputCnt = 0 Then
                                            '反映データがありません。
                                            strOutputState = FileReader.GetMessage("MSG_0562")
                                        Else
                                            'サーバに反映しました。
                                            strOutputState = FileReader.GetMessage("MSG_0559")
                                        End If
                                    End If
                                    .OutputState = strOutputState
                                    Call WriteLog(strLogFileName, strOutputState, True)
                                End If
                            Else
                                'サーバのインポートに失敗しました。
                                .OutputState = FileReader.GetMessage("MSG_0560")
                                Call WriteLog(strLogFileName, .OutputState, True)
                            End If
                            OUTERR = Nothing
                            'START 変更管理#59（更新件数0件時にインポートしない対応）2019/04 ueda
                        End If
                        'END 変更管理#59（更新件数0件時にインポートしない対応）2019/04 ueda
                    Else
                        If .DataOk = False Then
                            '支援ファイルが存在しません。
                            .OutputState = FileReader.GetMessage("MSG_0561")
                            Call WriteLog(strLogFileName, .OutputState, True)
                        End If

                        'intFileCnt = intFileCnt + 1

                        'Call ActiveProgress(frmWait, intFileCnt, intFileMax)
                        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                    End If

                End With
            Next

            MainLoadAsrManage = True

        Catch ex As Exception
            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            Call WriteLog(strLogFileName, ex.Message.ToString, True)
            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            MsgBox(ex.Message.ToString, vbCritical, "MainLoadAsrManage")

        Finally
            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            frmProc.Close()
            'Call EndProgress(frmWait)
            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

        End Try

    End Function

    ''' <summary>
    ''' 機能：エクスポート用CSV変換処理
    ''' </summary>
    ''' <param name="strLogFileName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
    Private Function MainExcelToCsv(ByVal strLogFileName As String,
                                    ByVal intCpnoIndex As Integer,
                                    Optional ByRef strFilePsCsv As String = "",
                                    Optional ByRef strFilePsdCsv As String = "") As Boolean
        'Private Function MainExcelToCsv(ByVal strLogFileName As String) As Boolean

        'Dim intIndex As Integer
        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
        Dim oc As New OutputCsv
        Dim intPsCnt As Integer
        Dim strNowDate As String = Now.ToString("yyyyMMdd_HHmmss")
        Dim strPsCsvPath As String
        Dim strPsCsvFileName As String
        Dim strTemplatePsdFileName As String
        Dim strPsdCsvFileName As String
        Dim strMsg As String
        'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
        'Dim frmWait As New Frm_WaitDialog
        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
        Dim eam As New ExcelAsrManage
        Dim ofm As New OioFileManage
        Dim intFileMax As Integer = 0
        Dim intFileCnt As Integer = 0

        MainExcelToCsv = False

        Try
            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            'Call InitProgress(True, frmWait, intFileMax)
            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

            strTemplatePsdFileName = ofm.GetLocalTemplateFolder & EXCEL_PAYMNETDETAILSAMPLE_FILENAME
            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            With typCpNo(intCpnoIndex)
                'For intIndex = 1 To (typCpNo.Length - 1)
                'With typCpNo(intIndex)
                'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                If .Checked = True And .DataOk = True Then
                    '==========================================
                    '個別PSエクスポート処理
                    '==========================================
                    intPsCnt = 0
                    If rdoAct.Checked = True Then
                        strPsCsvPath = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT & "\" & DIR_EXCEL & "\" & DIR_ACT & "\" & GetWorkDate() & "\" & DIR_SEND_LOWER)
                    Else
                        strPsCsvPath = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT & "\" & DIR_EXCEL & "\" & DIR_DELIVERY & "\" & GetWorkDate() & "\" & DIR_SEND_LOWER)
                    End If
                    strPsCsvFileName = ""

                    intPsCnt = oc.WriteCsv(.FileFormation(CD_FILEFROMATION_PS).Path & .FileFormation(CD_FILEFROMATION_PS).FileName, _
                                            .CustomerName, _
                                            .CpNo, _
                                            "999", _
                                            strPsCsvPath, _
                                            strPsCsvFileName, _
                                            strNowDate)
                    strMsg = .CpNo & "," & .CustomerName & ","
                    If intPsCnt = -1 Then
                        strMsg = strMsg & "個別PS：個別PSエクスポート処理エラー,"
                    Else
                        strMsg = strMsg & "個別PS：" & intPsCnt.ToString.ToUpper & "行出力,"
                    End If

                    '空の個別詳細ファイル作成
                    strPsdCsvFileName = strPsCsvFileName.Replace("Payment", "PaymentDetail")
                    Call CreateDetailCsv(strPsCsvPath, strPsdCsvFileName, .CpNo, strMsg)

                    Call WriteLog(strLogFileName, strMsg, True)

                    'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                    '戻り値用ファイル名セット
                    strFilePsCsv = strPsCsvPath & "\" & strPsCsvFileName
                    strFilePsdCsv = strPsCsvPath & "\" & strPsdCsvFileName
                    'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

                    'ファイルリネーム
                    If intPsCnt >= 0 Then
                        Call eam.ReNameBKFile(.FileFormation(CD_FILEFROMATION_PS).Path & .FileFormation(CD_FILEFROMATION_PS).FileName)
                        .ConvertFlg = CD_CONVERT_OK
                    Else
                        .ConvertFlg = CD_CONVERT_ERROR
                    End If

                    intFileCnt = intFileCnt + 1
                    'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                    'Call ActiveProgress(frmWait, intFileCnt, intFileMax)
                    'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
                End If
            End With
            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            'Next
            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

            MainExcelToCsv = True

        Catch ex As Exception
            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            Call WriteLog(strLogFileName, ex.Message.ToString & "(MainExcelToCsv)", True)
            'MsgBox(ex.Message.ToString, vbCritical, "MainExcelToCsv")
            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

        Finally
            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            'Call EndProgress(frmWait)
            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

        End Try

    End Function

    ''' <summary>
    ''' 機能：標準帳票作成処理
    ''' </summary>
    ''' <param name="strLogFileName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function MainStandardSetting(ByVal strLogFileName As String) As Boolean


        Dim intIndex As Integer
        Dim esp As New ExcelStandardPs
        Dim blnRet As Boolean
        Dim strMsg As String
        Dim frmWait As New Frm_WaitDialog
        Dim eam As New ExcelAsrManage
        Dim intFileMax As Integer = 0
        Dim intFileCnt As Integer = 0

        MainStandardSetting = False

        Try
            Call InitProgress(True, frmWait, intFileMax)

            For intIndex = 1 To (typCpNo.Length - 1)
                With typCpNo(intIndex)
                    If .Checked = True And .DataOk = True Then
                        '==========================================
                        '標準帳票作成処理
                        '==========================================
                        CommonVariable.CPNO = .CpNo
                        CommonVariable.CUSTOMERNAME = .CustomerName
                        CommonVariable.ContractStart = .ContractStart
                        CommonVariable.ContractEnd = .ContractEnd
                        CommonVariable.PaymentStart = CDate(.ExcelStart & "/1/1")
                        blnRet = esp.MakeStandardExcelPs(strMsg)

                        strMsg = .CpNo & "," & .CustomerName & ","
                        If blnRet = False Then
                            strMsg = strMsg & "標準帳票作成処理エラー,"
                        Else
                            strMsg = strMsg & "標準帳票作成"
                        End If

                        Call WriteLog(strLogFileName, strMsg, True)

                        intFileCnt = intFileCnt + 1
                        Call ActiveProgress(frmWait, intFileCnt, intFileMax)
                    End If
                End With
            Next

            MainStandardSetting = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "MainStandardSetting")

        Finally
            Call EndProgress(frmWait)

        End Try

    End Function

    ''' <summary>
    ''' 機能：帳票出力
    ''' </summary>
    ''' <param name="strLogFileName"></param>
    ''' <param name="strLogTitle"></param>
    ''' <param name="intImportCd"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function MainStandardReport(ByVal strLogFileName As String, ByVal strLogTitle As String, ByVal intImportCd As Integer) As Boolean

        Dim intIndex As Integer
        Dim esp As New ExcelStandardPs
        Dim blnRet As Boolean
        Dim strMsg As String
        Dim frmWait As New Frm_WaitDialog
        Dim eam As New ExcelAsrManage
        Dim intFileMax As Integer = 0
        Dim intFileCnt As Integer = 0
        Dim strStdExcelFileName As String
        Dim strSettingName As String
        Dim dtOutputDate As Date

        MainStandardReport = False

        Try
            Call InitProgress(True, frmWait, intFileMax)

            For intIndex = 1 To (typCpNo.Length - 1)
                With typCpNo(intIndex)
                    If .Checked = True And .DataOk = True Then
                        '共通設定
                        CommonVariable.CPNO = .CpNo
                        CommonVariable.CUSTOMERNAME = .CustomerName
                        CommonVariable.PaymentStart = CDate(.ExcelStart & "/1/1")
                        CommonVariable.ContractStart = .ContractStart
                        CommonVariable.ContractEnd = .ContractEnd
                        strStdExcelFileName = .FileFormation(CD_FILEFROMATION_STD_SET).Path & _
                                                .FileFormation(CD_FILEFROMATION_STD_SET).FileName
                        Select Case intImportCd
                            Case CD_STROUT_STANDARD
                                '==========================================
                                '標準帳票出力処理
                                '==========================================
                                blnRet = esp.OutputStdExcelPs(strStdExcelFileName, strMsg)
                            Case CD_STROUT_DATA_ALL, CD_STROUT_DATA_DEL
                                '==========================================
                                'ﾃﾞｰﾀ提供用出力処理
                                '==========================================
                                dtOutputDate = CDate(cboWorkDate.Text.Substring(0, 4) & "/" & cboWorkDate.Text.Substring(5, 2) & "/01")
                                blnRet = esp.OutputSubmittedData(intImportCd,
                                                                 CommonVariable.PaymentStart.ToString("yyyy"),
                                                                 dtOutputDate,
                                                                 Integer.Parse(.PaymentPeriod),
                                                                 strMsg)

                        End Select

                        If blnRet = False Then
                            strMsg = .CpNo & "," & .CustomerName & "," & strLogTitle & "処理エラー," & strMsg
                        Else
                            If intImportCd = CD_STROUT_STANDARD Then
                                strSettingName = "," & strLogTitle & ",(" & .FileFormation(CD_FILEFROMATION_STD_SET).FileName & ")"
                            Else
                                strSettingName = ""
                            End If
                            strMsg = .CpNo & "," & .CustomerName & strSettingName
                        End If

                        Call WriteLog(strLogFileName, strMsg, True)

                        intFileCnt = intFileCnt + 1
                        Call ActiveProgress(frmWait, intFileCnt, intFileMax)
                    End If
                End With
            Next

            MainStandardReport = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "MainStandardReport")

        Finally
            Call EndProgress(frmWait)

        End Try

    End Function

    ''' <summary>
    ''' 機能：エクスポート用CSV変換処理（バージョンアップ）
    ''' </summary>
    ''' <param name="strLogFileName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function MainVerUpExcelToCsv(ByVal strLogFileName As String) As Boolean

        Dim intIndex As Integer
        Dim evu As New ExcelVersionUp
        Dim intPsCnt As Integer
        Dim intDetailCnt As Integer
        Dim strNowDate As String = Now.ToString("yyyyMMdd_HHmmss")
        Dim strOutputPath As String
        Dim strTemplatePsdFileName As String
        Dim strMsg As String
        Dim frmWait As New Frm_WaitDialog
        Dim eam As New ExcelAsrManage
        Dim ofm As New OioFileManage
        Dim intFileMax As Integer = 0
        Dim intFileCnt As Integer = 0

        MainVerUpExcelToCsv = False

        Try
            Call InitProgress(True, frmWait, intFileMax)

            strTemplatePsdFileName = ofm.GetLocalTemplateFolder & EXCEL_PAYMNETDETAILSAMPLE_FILENAME
            For intIndex = 1 To (typCpNo.Length - 1)
                With typCpNo(intIndex)
                    If .Checked = True And .DataOk = True Then
                        '==========================================
                        'エクスポート処理
                        '==========================================
                        CommonVariable.CPNO = .CpNo
                        CommonVariable.CUSTOMERNAME = .CustomerName
                        CommonVariable.PaymentStart = CDate(.ExcelStart & "/1/1")
                        CommonVariable.PaymentPeriod = .PaymentPeriod
                        intPsCnt = 0
                        intDetailCnt = 0
                        strMsg = ""
                        strOutputPath = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT) & DIR_VERUP & "\" & DIR_SEND

                        evu.OutputVerUpExcelToCsv(.FileFormation(CD_FILEFROMATION_VERUP_EXCEL).Path & .FileFormation(CD_FILEFROMATION_VERUP_EXCEL).FileName,
                                                  strOutputPath,
                                                  intPsCnt,
                                                  intDetailCnt,
                                                  strMsg)

                        strMsg = .CpNo & "," & .CustomerName & "," & strMsg
                        If intPsCnt = -1 Or intDetailCnt = -1 Then
                            strMsg = strMsg & "エクスポート処理エラー,"
                        Else
                            strMsg = strMsg & "Payment：" & intPsCnt.ToString.ToUpper & "行出力、詳細：" & intDetailCnt.ToString & "行出力"
                        End If

                        Call WriteLog(strLogFileName, strMsg, True)

                        'ファイルリネーム
                        If intPsCnt >= 0 Then
                            Call eam.ReNameBKFile(.FileFormation(CD_FILEFROMATION_VERUP_EXCEL).Path & .FileFormation(CD_FILEFROMATION_VERUP_EXCEL).FileName)
                            .ConvertFlg = CD_CONVERT_OK
                        Else
                            .ConvertFlg = CD_CONVERT_ERROR
                        End If

                        intFileCnt = intFileCnt + 1
                        Call ActiveProgress(frmWait, intFileCnt, intFileMax)
                    End If
                End With
            Next

            MainVerUpExcelToCsv = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "MainVerUpExcelToCsv")

        Finally
            Call EndProgress(frmWait)

        End Try

    End Function

    ''' <summary>
    ''' 機能：
    ''' </summary>
    ''' <param name="intRow"></param>
    ''' <param name="strPaymentFileName"></param>
    ''' <param name="strMsg"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function DbToExcelPayment(ByVal intRow As Integer, ByRef strPaymentFileName As String, ByRef strMsg As String) As Boolean

        Dim ofm As New OioFileManage
        Dim strTemplatePSFileName As String
        Dim strAsrForlder As String
        Dim strPaymnetPath As String
        Dim strPaymentFileName2 As String
        Dim intPSCount As Integer = 0

        DbToExcelPayment = False

        Try
            '=========================================
            'Sampleをコピー
            '=========================================
            If rdoAct.Checked = True Then
                strAsrForlder = DIR_ACT
            Else
                strAsrForlder = DIR_DELIVERY
            End If
            strTemplatePSFileName = ofm.GetLocalTemplateFolder & EXCEL_PAYMNETSAMPLE_FILENAME
            strPaymnetPath = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT) & DIR_EXCEL & "\" & _
                                strAsrForlder & "\" & _
                                GetWorkDate() & "\" & _
                                DIR_UPDATE_FILE & "\"
            strPaymentFileName2 = typCpNo(intRow).CpNo & "_999_" & "Payment" & "_" & Now.ToString("yyyyMMdd_HHmmss") & ".xlsm"
            strPaymentFileName = strPaymnetPath & strPaymentFileName2
            File.Copy(strTemplatePSFileName, strPaymentFileName, True)

            DbToExcelPayment = True

        Catch ex As Exception
            strMsg = ex.Message.ToString

        End Try

    End Function

    ''' <summary>
    ''' 機能：空の個別詳細ファイル作成
    ''' </summary>
    ''' <param name="strPath">出力先パス</param>
    ''' <param name="strFileName">個別詳細ファイル名</param>
    ''' <param name="strCpNo">CPNO</param>
    ''' <param name="strMsg">メッセージ</param>
    ''' <remarks></remarks>
    Private Sub CreateDetailCsv(ByVal strPath As String, ByVal strFileName As String, ByVal strCpNo As String, ByRef strMsg As String)

        Dim strOutputLine As String
        Dim sw As StreamWriter

        Try
            sw = New StreamWriter(strPath & "\" & strFileName, False, Encoding.GetEncoding("shift-jis"))

            '１行目（ファイル名）
            sw.WriteLine(strFileName)
            '２行目（CPNO）
            sw.WriteLine(strCpNo)
            '３行目（データヘッダ）
            strOutputLine = "UPDATE_FLAG,LOCK_FLAG,VALID_FLAG,CONTRACT,FILE_NAME,FILE_NAME_SUFFIX,FILE_NAME_SUFFIX_INTR,SEQ,IDENTITY_FLAG,PROD_NO,PROD_NAME,WD_ANNT_DATE,WD_DATE,PRICE_CHG_DATE,MES_CATEGORY,MES_GROUP,SPECIAL_FEATURE,QTY,LIST_PRICE_PROPOSAL,LIST_PRICE,LIST_PRICE_TOTAL_PROPOSAL,LIST_PRICE_TOTAL,COST_RATE,COST,COST_TOTAL,COST_INPUT_DATE,HWMA_LIST_PRICE,HWMA_LIST_PRICE_TOTAL,HOURLY_SCALE,MA_EXT_SCALE,DP,HWMA_DP_LIST_PRICE,HWMA_DP_LIST_PRICE_TOTAL"
            sw.WriteLine(strOutputLine)
            '４行目（EOF,0）
            sw.WriteLine("EOF,0")

        Catch ex As Exception
            strMsg = ex.Message.ToString & "(CreateDetailCsv)"

        Finally
            If IsNothing(sw) = False Then
                sw.Close()
            End If

        End Try

    End Sub

    ''' <summary>
    ''' 機　能：作業フォルダコンボボックス設定
    ''' </summary>
    ''' <returns>True:正常　False:異常</returns>
    ''' <remarks></remarks>
    Private Function SetCboWorkDate() As Boolean

        Dim strFolders() As String
        Dim strPath As String
        Dim intCnt As Integer
        Dim arrYearMonth As New ArrayList
        Dim dtNow As Date = Now
        Dim strYearMonths() As String
        Dim strWork As String

        SetCboWorkDate = False

        Try
            '作成済み作業フォルダ名（年月）取得
            strPath = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT & "\" & DIR_EXCEL & "\" & DIR_ACT)
            If Directory.Exists(strPath) = True Then
                strFolders = Directory.GetDirectories(strPath)
                If strFolders.Length > 0 Then
                    For intCnt = 0 To (strFolders.Length - 1)
                        arrYearMonth.Add(Path.GetFileName(strFolders(intCnt)))
                    Next
                End If
            End If

            '現年月から＋２カ月まで設定
            arrYearMonth.Add(dtNow.ToString("yyyyMM"))
            arrYearMonth.Add(dtNow.AddMonths(1).ToString("yyyyMM"))
            arrYearMonth.Add(dtNow.AddMonths(2).ToString("yyyyMM"))

            arrYearMonth.Sort()

            '重複年月を取り除いてコンボボックスにセット
            cboWorkDate.Items.Clear()
            strYearMonths = DirectCast(arrYearMonth.ToArray(GetType(String)), String())
            strWork = strYearMonths(0)
            cboWorkDate.Items.Add(strWork.Substring(0, 4) & "年" & strWork.Substring(4) & "月")
            For intCnt = 1 To (strYearMonths.Length - 1)
                If strYearMonths(intCnt) <> strWork Then
                    cboWorkDate.Items.Add(strYearMonths(intCnt).Substring(0, 4) & "年" & strYearMonths(intCnt).Substring(4) & "月")
                End If
                strWork = strYearMonths(intCnt)
            Next

            'システム年月を表示
            cboWorkDate.Text = dtNow.ToString("yyyy年MM月")

            SetCboWorkDate = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "SetCboWorkDate")

        End Try

    End Function

    ''' <summary>
    ''' 機　能：ﾎﾞﾀﾝの有効/無効設定
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub ButtonEnable()

        Me.btnCsvToMdb.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.btnCsvToMdb.Name)
        Me.bntMdbToExcel.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.bntMdbToExcel.Name)
        Me.btnImportManageFileOutputExplorer.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.btnImportManageFileOutputExplorer.Name)
        Me.btnExportManageFileInputExplorer.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.btnExportManageFileInputExplorer.Name)
        Me.btnExcelToMdb.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.btnExcelToMdb.Name)
        Me.btnExportPsCsvOutputExplorer.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.btnExportPsCsvOutputExplorer.Name)
        'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
        'Me.btnExcelToCsv.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.btnExcelToCsv.Name)
        'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
        Me.btnStdSetMake.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.btnStdSetMake.Name)
        Me.btnStdSetMakeOutputExplorer.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.btnStdSetMakeOutputExplorer.Name)
        Me.btnStdOut.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.btnStdOut.Name)
        Me.btnStdOutOutputExplorer.Enabled = Autority.ChkEnableAuthority(CommonVariable.AUTHORITY, Me.Name, Me.btnStdOutOutputExplorer.Name)

    End Sub

    ''' <summary>
    ''' 機　能：作業フォルダ文字列
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetWorkDate() As String

        GetWorkDate = ""

        If cboWorkDate.Text <> "" Then
            GetWorkDate = cboWorkDate.Text.Substring(0, 4) & cboWorkDate.Text.Substring(5, 2)
        End If

    End Function

    ''' <summary>
    ''' 機　能：ダブリ行削除
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function DeleteDoubleLine(ByVal strPaymentFileName As String) As Boolean

        Dim arUpdateNo As New ArrayList
        Dim intRowCnt As Integer
        Dim blnUpdateFlg As Boolean = True
        Dim strLineNo As String

        Dim xlApp As New Excel.Application
        Dim xlBook As Excel.Workbook = Nothing
        Dim xlSheet As Excel.Worksheet = Nothing
        Dim xlCell As Excel.Range = Nothing
        Dim xlRange As Excel.Range = Nothing
        Dim targetRange As Excel.Range
        Dim sortRow1 As Excel.Range
        Dim sortRow2 As Excel.Range
        Dim objCellData(1, 4) As Object
        Dim intRowEnd As Integer

        DeleteDoubleLine = False

        Try
            'Excelオブジェクトの設定
            xlApp.EnableEvents = False
            xlBook = xlApp.Workbooks.Open(strPaymentFileName)
            xlApp.EnableEvents = True
            xlApp.DisplayAlerts = False
            xlSheet = xlBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)

            '最終行取得
            intRowEnd = ExcelWrite.GetLastRow(xlSheet, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)

            'ソート（更新フラグ、NO）
            targetRange = xlSheet.Rows(EXCEL_PAYMENTLINEDATE_OUTROW.ToString & ":" & intRowEnd.ToString)
            sortRow1 = xlSheet.Cells(EXCEL_PAYMENTLINEDATE_OUTROW, ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG)
            sortRow2 = xlSheet.Cells(EXCEL_PAYMENTLINEDATE_OUTROW, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)
            Call targetRange.Sort(Key1:=sortRow1, Key2:=sortRow2, Orientation:=Excel.XlSortOrientation.xlSortColumns)
            ExcelObjRelease.ReleaseExcelObj(sortRow1, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(sortRow2, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(targetRange, ExcelObjRelease.OBJECT_NOTHING)

            For intRowCnt = EXCEL_PAYMENTLINEDATE_OUTROW To intRowEnd
                '１行取得
                xlCell = xlSheet.Range("A" & intRowCnt.ToString & ":" & "D" & intRowCnt.ToString)
                objCellData = xlCell.Value
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

                '最終行判定（NO）
                If IsNothing(objCellData(1, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)) = True Then
                    Exit For
                End If
                If intRowCnt = EXCEL_PAYMENTLINEDATE_OUTROW And _
                    IsNothing(objCellData(1, ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG)) = True Then
                    Exit For
                End If

                '更新フラグ有のＮＯを格納
                If objCellData(1, ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG) = "U" Then
                    arUpdateNo.Add(objCellData(1, ExcelWrite.ExcelPaymentLineColumn.LINE_NO).ToString)
                Else
                    blnUpdateFlg = False
                End If

                If blnUpdateFlg = False Then
                    strLineNo = objCellData(1, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)
                    If arUpdateNo.IndexOf(strLineNo) >= 0 Then
                        '削除
                        xlCell = xlSheet.Range(intRowCnt.ToString & ":" & intRowCnt.ToString)
                        xlCell.Delete()
                        ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

                        intRowCnt = intRowCnt - 1
                    End If
                End If
            Next


            If rdoDeliv.Checked = True Then
                'ソート（NO）
                targetRange = xlSheet.Rows(EXCEL_PAYMENTLINEDATE_OUTROW.ToString & ":" & intRowEnd)
                sortRow1 = xlSheet.Cells(EXCEL_PAYMENTLINEDATE_OUTROW, ExcelWrite.ExcelPaymentLineColumn.LINE_NO)
                Call targetRange.Sort(Key1:=sortRow1, Orientation:=Excel.XlSortOrientation.xlSortColumns)
                ExcelObjRelease.ReleaseExcelObj(sortRow1, ExcelObjRelease.OBJECT_NOTHING)
                ExcelObjRelease.ReleaseExcelObj(targetRange, ExcelObjRelease.OBJECT_NOTHING)
            End If

            xlBook.Save()

            DeleteDoubleLine = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "DeleteDoubleLine")

        Finally
            ''エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBook) = False Then
                xlBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
            ''ガベージコレクトの起動
            GC.Collect()

        End Try

    End Function

    ''' <summary>
    ''' 機　能：Null値変換
    ''' </summary>
    ''' <param name="drData">OleDbDataReader</param>
    ''' <param name="strFieldName">カラム名</param>
    ''' <returns></returns>
    ''' <remarks>Null値の場合、空文字に変換</remarks>
    Private Function GetDbData(ByVal drData As OleDbDataReader, ByVal strFieldName As String) As String

        GetDbData = ""

        Try
            If IsDBNull(drData.Item(strFieldName)) = True Then
                GetDbData = ""
            Else
                GetDbData = drData.Item(strFieldName)
            End If

        Catch ex As Exception
            Throw ex
        End Try

    End Function

    ''' <summary>
    ''' 機　能：プログレスバー初期化
    ''' </summary>
    ''' <param name="frm"></param>
    ''' <remarks></remarks>
    Private Sub InitProgress(ByVal blnDataOkOn As Boolean, ByRef frm As Frm_WaitDialog, ByRef intMax As Integer)

        Dim intIndex As Integer
        Dim intStep As Integer

        intMax = 0
        '１処理当たりの増減値
        For intIndex = 1 To (typCpNo.Length - 1)
            If typCpNo(intIndex).Checked = True And ((blnDataOkOn = False) Or (blnDataOkOn = True And typCpNo(intIndex).DataOk = True)) Then
                intMax = intMax + 1
            End If
        Next
        If intMax = 0 Then
            intMax = 1
            intStep = 100
        Else
            intStep = Math.Truncate(100 / intMax)
        End If

        '設定
        With frm
            .Text = "作成中・・・"
            .Pic_Excel.Visible = True
            .lbl_Message.Text = "作成中です。(0/" & intMax.ToString & ")"
            .ProgressMin = 0
            .ProgressMax = 100
            .ProgressStep = intStep
            .ProgressValue = 0
            .Show()
            .Update()
        End With

    End Sub

    ''' <summary>
    ''' 機　能：プログレスバー加算
    ''' </summary>
    ''' <param name="frm"></param>
    ''' <remarks></remarks>
    Private Sub ActiveProgress(ByRef frm As Frm_WaitDialog, ByVal intCnt As Integer, ByVal intMax As Integer)

        With frm
            .lbl_Message.Text = "作成中です。(" & intCnt.ToString & "/" & intMax.ToString & ")"
            .ProgressValue = Math.Floor(100 / intMax * intCnt)
            .Update()
        End With

    End Sub

    ''' <summary>
    ''' 機　能：プログレスバー終了
    ''' </summary>
    ''' <param name="frm"></param>
    ''' <remarks></remarks>
    Private Sub EndProgress(ByRef frm As Frm_WaitDialog)

        With frm
            .ProgressValue = 100
            .Update()
            .Close()
        End With

    End Sub

    ''' <summary>
    ''' 機能：タブの制御設定
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub TabSelected()

        If rdoAct.Checked = True Or rdoDeliv.Checked = True Then
            tabImport.Enabled = True
            tabExport.Enabled = True
            tabStandard.Enabled = False
            tabVersion.Enabled = False
            tabFile.SelectedTab = tabImport
            If rdoAct.Checked = True Then
                grpAct.Enabled = True
            Else
                grpAct.Enabled = False
            End If

            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            dvgCpno.Columns(CD_GRID_COL_DB).Visible = False
            dvgCpno.Columns(CD_GRID_COL_COMMENT).Visible = True
            'dvgCpno.Columns(CD_GRID_COL_DB).Visible = True
            'dvgCpno.Columns(CD_GRID_COL_EXCEL).Visible = True
            'dvgCpno.Columns(CD_GRID_COL_MNG_OUT).Visible = True
            'dvgCpno.Columns(CD_GRID_COL_MNG_IN).Visible = True
            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            dvgCpno.Columns(CD_GRID_COL_STANDARD_SET).Visible = False
            dvgCpno.Columns(CD_GRID_COL_STANDARD_REPORT).Visible = False
            dvgCpno.Columns(CD_GRID_COL_VERUP_EXCEL).Visible = False
            dvgCpno.Columns(CD_GRID_COL_VERUP_PS_CSV).Visible = False
            dvgCpno.Columns(CD_GRID_COL_VERUP_PS_PRICE_CSV).Visible = False
            dvgCpno.Columns(CD_GRID_COL_VERUP_DETAIL_CSV).Visible = False
            dvgCpno.Columns(CD_GRID_COL_MNG_ACT).Visible = False
            dvgCpno.Columns(CD_GRID_COL_MNG_DELIVERY).Visible = False
            dvgCpno.Columns(CD_GRID_COL_CONT_START).Visible = False
            dvgCpno.Columns(CD_GRID_COL_CONT_END).Visible = False
            dvgCpno.Columns(CD_GRID_COL_CONT_EXCEL_START).Visible = False
            dvgCpno.Columns(CD_GRID_COL_PAYMENT_PERIOD).Visible = False

        ElseIf rdoBoth.Checked = True Then
            tabImport.Enabled = True
            tabExport.Enabled = False
            tabStandard.Enabled = False
            tabVersion.Enabled = False
            tabFile.SelectedTab = tabImport
            grpAct.Enabled = True

            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            dvgCpno.Columns(CD_GRID_COL_DB).Visible = False
            dvgCpno.Columns(CD_GRID_COL_COMMENT).Visible = True
            'dvgCpno.Columns(CD_GRID_COL_DB).Visible = True
            'dvgCpno.Columns(CD_GRID_COL_EXCEL).Visible = False
            'dvgCpno.Columns(CD_GRID_COL_MNG_OUT).Visible = False
            'dvgCpno.Columns(CD_GRID_COL_MNG_IN).Visible = False
            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            dvgCpno.Columns(CD_GRID_COL_STANDARD_SET).Visible = False
            dvgCpno.Columns(CD_GRID_COL_STANDARD_REPORT).Visible = False
            dvgCpno.Columns(CD_GRID_COL_VERUP_EXCEL).Visible = False
            dvgCpno.Columns(CD_GRID_COL_VERUP_PS_CSV).Visible = False
            dvgCpno.Columns(CD_GRID_COL_VERUP_PS_PRICE_CSV).Visible = False
            dvgCpno.Columns(CD_GRID_COL_VERUP_DETAIL_CSV).Visible = False
            'START 変更管理#38（PAデータ比較UAT対応)　2017/02 sugo
            dvgCpno.Columns(CD_GRID_COL_MNG_ACT).Visible = False
            dvgCpno.Columns(CD_GRID_COL_MNG_DELIVERY).Visible = False
            'dvgCpno.Columns(CD_GRID_COL_MNG_ACT).Visible = True
            'dvgCpno.Columns(CD_GRID_COL_MNG_DELIVERY).Visible = True
            'END   変更管理#38（PAデータ比較UAT対応)　2017/02 sugo
            dvgCpno.Columns(CD_GRID_COL_CONT_START).Visible = False
            dvgCpno.Columns(CD_GRID_COL_CONT_END).Visible = False
            dvgCpno.Columns(CD_GRID_COL_CONT_EXCEL_START).Visible = False
            dvgCpno.Columns(CD_GRID_COL_PAYMENT_PERIOD).Visible = False

        ElseIf rdoStandard.Checked = True Then
            tabImport.Enabled = False
            tabExport.Enabled = False
            tabStandard.Enabled = True
            tabVersion.Enabled = False
            tabFile.SelectedTab = tabStandard
            grpAct.Enabled = False

            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            dvgCpno.Columns(CD_GRID_COL_DB).Visible = False
            dvgCpno.Columns(CD_GRID_COL_COMMENT).Visible = True
            'dvgCpno.Columns(CD_GRID_COL_DB).Visible = True
            'dvgCpno.Columns(CD_GRID_COL_EXCEL).Visible = False
            'dvgCpno.Columns(CD_GRID_COL_MNG_OUT).Visible = False
            'dvgCpno.Columns(CD_GRID_COL_MNG_IN).Visible = False
            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            dvgCpno.Columns(CD_GRID_COL_STANDARD_SET).Visible = True
            dvgCpno.Columns(CD_GRID_COL_STANDARD_REPORT).Visible = True
            dvgCpno.Columns(CD_GRID_COL_VERUP_EXCEL).Visible = False
            dvgCpno.Columns(CD_GRID_COL_VERUP_PS_CSV).Visible = False
            dvgCpno.Columns(CD_GRID_COL_VERUP_PS_PRICE_CSV).Visible = False
            dvgCpno.Columns(CD_GRID_COL_VERUP_DETAIL_CSV).Visible = False
            dvgCpno.Columns(CD_GRID_COL_MNG_ACT).Visible = False
            dvgCpno.Columns(CD_GRID_COL_MNG_DELIVERY).Visible = False
            dvgCpno.Columns(CD_GRID_COL_CONT_START).Visible = False
            dvgCpno.Columns(CD_GRID_COL_CONT_END).Visible = False
            dvgCpno.Columns(CD_GRID_COL_CONT_EXCEL_START).Visible = False
            dvgCpno.Columns(CD_GRID_COL_PAYMENT_PERIOD).Visible = False

        ElseIf rdoVersion.Checked = True Then
            tabImport.Enabled = False
            tabExport.Enabled = False
            tabStandard.Enabled = False
            tabVersion.Enabled = True
            tabFile.SelectedTab = tabVersion
            grpAct.Enabled = False

            dvgCpno.Columns(CD_GRID_COL_DB).Visible = False
            'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            dvgCpno.Columns(CD_GRID_COL_COMMENT).Visible = False
            'dvgCpno.Columns(CD_GRID_COL_EXCEL).Visible = False
            'dvgCpno.Columns(CD_GRID_COL_MNG_OUT).Visible = False
            'dvgCpno.Columns(CD_GRID_COL_MNG_IN).Visible = False
            'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
            dvgCpno.Columns(CD_GRID_COL_STANDARD_SET).Visible = False
            dvgCpno.Columns(CD_GRID_COL_STANDARD_REPORT).Visible = False
            dvgCpno.Columns(CD_GRID_COL_VERUP_EXCEL).Visible = True
            dvgCpno.Columns(CD_GRID_COL_VERUP_PS_CSV).Visible = True
            dvgCpno.Columns(CD_GRID_COL_VERUP_PS_PRICE_CSV).Visible = True
            dvgCpno.Columns(CD_GRID_COL_VERUP_DETAIL_CSV).Visible = True
            dvgCpno.Columns(CD_GRID_COL_MNG_ACT).Visible = False
            dvgCpno.Columns(CD_GRID_COL_MNG_DELIVERY).Visible = False
            dvgCpno.Columns(CD_GRID_COL_CONT_START).Visible = False
            dvgCpno.Columns(CD_GRID_COL_CONT_END).Visible = False
            dvgCpno.Columns(CD_GRID_COL_CONT_EXCEL_START).Visible = False
            dvgCpno.Columns(CD_GRID_COL_PAYMENT_PERIOD).Visible = False

        End If

    End Sub

    ''' <summary>
    ''' 画面入力チェック
    ''' </summary>
    ''' <param name="strErrMsg"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckDisplayItem(ByRef strErrMsg As String) As Boolean

        Dim strMsg As String
        Dim intRet As Integer

        CheckDisplayItem = False

        Try
            '''' 条件
            '''' ケース：１つもチェックされていない場合、処理続行判定メッセージ表示する
            '''' 　メッセージ：ID:MSG_0493、MSG_0495
            '''' 　　１つもチェックされていません。
            '''' 　　連携ファイルが出力されませんがよろしいですか？
            'Req.1702 実行支援レポート変更 2018/12 Str
            'If cbSheet1.Checked = False And
            '   cbSheet2.Checked = False And
            '   cbSheet3.Checked = False And
            '   cbSheet4.Checked = False Then
            If cbSheet1.Checked = False And
               cbSheet2.Checked = False And
               cbSheet3.Checked = False And
               cbSheet4.Checked = False And
               cbsheet5.checked = False Then
                'Req.1702 実行支援レポート変更 2018/12 End
                strMsg = FileReader.GetMessage("MSG_0493") & vbCrLf & FileReader.GetMessage("MSG_0495")
                intRet = MsgBox(strMsg, MsgBoxStyle.Question + MsgBoxStyle.YesNo, Me.Text)
                If intRet = vbNo Then
                    Exit Function
                End If
            End If

            CheckDisplayItem = True

        Catch ex As Exception
            strErrMsg = ex.Message.ToString & "(CheckDisplayItem)"
        End Try

    End Function

    'START 変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo
    ''' <summary>
    ''' ZIPﾌｧｲﾙ作成
    ''' </summary>
    ''' <param name="strFile"></param>
    ''' <remarks></remarks>
    Private Function CreateZip(ByVal strFile As String) As String

        Dim zip As New Compression
        Dim strPathZip As String
        Dim strFileZip As String
        Dim strFiles(0) As String

        CreateZip = ""

        Try
            If strFile.Trim <> "" Then
                strFiles(0) = strFile
                strPathZip = Path.GetDirectoryName(strFile)
                strFileZip = Path.GetFileNameWithoutExtension(strFile) & ".zip"
                Call zip.CompressZip(strPathZip & "\" & strFileZip, strFiles)

            End If

        Catch ex As Exception
            CreateZip = ex.Message.ToString

        End Try

    End Function

    ''' <summary>
    ''' 処理中メッセージフォーム初期化
    ''' </summary>
    ''' <param name="frm">ﾌｫｰﾑ</param>
    ''' <param name="strLblMsg">ﾒｯｾｰｼﾞ（配列）</param>
    ''' <param name="strLblProc">処理内容（配列）</param>
    ''' <param name="intFileMax">処理最大件数</param>
    ''' <remarks></remarks>
    Private Sub InitProcDialog(ByRef frm As frmProcessDialog,
                               ByVal strLblMsg() As String,
                               ByVal strLblProc() As String,
                               ByRef intFileMax As Integer)

        Dim intCnt As Integer
        Dim lblMsg(0 To 3) As Label
        Dim lblProc(0 To 7) As Label

        intFileMax = 0
        '１処理当たりの増減値
        For intIndex As Integer = 1 To (typCpNo.Length - 1)
            If typCpNo(intIndex).Checked = True And typCpNo(intIndex).DataOk = True Then
                intFileMax = intFileMax + 1
            End If
        Next
        If intFileMax = 0 Then
            intFileMax = 1
        End If

        With frm
            lblMsg(0) = .lblMsg1
            lblMsg(1) = .lblMsg2
            lblMsg(2) = .lblMsg3
            lblMsg(3) = .lblMsg4
            lblProc(0) = .lblProc1
            lblProc(1) = .lblProc2
            lblProc(2) = .lblProc3
            lblProc(3) = .lblProc4
            lblProc(4) = .lblProc5
            lblProc(5) = .lblProc6
            lblProc(6) = .lblProc7
            lblProc(7) = .lblProc8
        End With

        For intCnt = 0 To 3
            lblMsg(intCnt).BorderStyle = BorderStyle.None
            lblMsg(intCnt).Text = strLblMsg(intCnt)
        Next
        For intCnt = 0 To 7
            lblProc(intCnt).BorderStyle = BorderStyle.None
            lblProc(intCnt).Text = strLblProc(intCnt)
        Next

        frm.Text = "処理中です（0/" & intFileMax.ToString & "）"

        With frm
            .Show(Me)
            .Update()
            .Activate()
        End With

    End Sub

    ''' <summary>
    ''' 処理中メッセージの文字色設定
    ''' </summary>
    ''' <param name="frm"></param>
    ''' <param name="intProcIdx"></param>
    ''' <remarks></remarks>
    Private Sub ActiveProcDialog(ByRef frm As frmProcessDialog, ByVal intProcIdx As Integer)

        Dim lblProc(0 To 7) As Label
        Dim intCnt As Integer

        With frm
            lblProc(0) = .lblProc1
            lblProc(1) = .lblProc2
            lblProc(2) = .lblProc3
            lblProc(3) = .lblProc4
            lblProc(4) = .lblProc5
            lblProc(5) = .lblProc6
            lblProc(6) = .lblProc7
            lblProc(7) = .lblProc8
        End With

        For intCnt = 0 To 7
            If intCnt = (intProcIdx - 1) Then
                lblProc(intCnt).ForeColor = Color.Red
            Else
                lblProc(intCnt).ForeColor = Color.Black
            End If
        Next
        frm.Update()
        frm.Activate()

    End Sub

    ''' <summary>
    ''' 処理中メッセージのカウントアップ
    ''' </summary>
    ''' <param name="frm"></param>
    ''' <param name="intFileCnt"></param>
    ''' <param name="intFileMax"></param>
    ''' <remarks></remarks>
    Private Sub ActiveProcDialogCountUp(ByRef frm As frmProcessDialog, ByVal intFileCnt As Integer, ByVal intFileMax As Integer)

        With frm
            .Text = "作成中です（" & intFileCnt.ToString & "/" & intFileMax.ToString & "）"
            .lblMsg1.Text = CommonVariable.CPNO & ":" & CommonVariable.CUSTOMERNAME
            .Update()
            .Activate()
        End With

    End Sub
    'END   変更管理#39（デリバリ実行支援簡略化対応)　2017/04 sugo

#If DEBUG Then
    ''' <summary>
    ''' 機能：現行CSVを２０年に変換
    ''' </summary>
    ''' <param name="strPath"></param>
    ''' <param name="strFileName"></param>
    ''' <remarks></remarks>
    Private Sub ChangePS12to20(ByVal strPath As String, ByRef strFileName As String)

        Dim sr As StreamReader
        Dim strLine As String
        Dim strSplitLine() As String
        Dim intRowCnt As Integer = 1
        Dim sw As StreamWriter
        Dim strOut As String
        Dim intCnt As Integer
        Dim intAddCnt As Integer
        Dim strFullPathFileName As String

        Try
            strFullPathFileName = strPath & strFileName
            sr = New StreamReader(strFullPathFileName, Encoding.GetEncoding("shift-jis"))
            strFileName = strFileName.Substring(0, 19) & Now.ToString("yyyyMMdd_HHmmss") & "_export.csv"
            sw = New StreamWriter(strPath & strFileName, False, Encoding.GetEncoding("shift-jis"))

            Do
                strLine = sr.ReadLine()

                If IsNothing(strLine) = True Then
                    Exit Do
                End If

                strOut = ""
                If strLine.IndexOf("EOF") = -1 Then
                    If intRowCnt = 1 Then
                        strOut = strFileName
                    ElseIf intRowCnt > 4 Then
                        Call SplitData(strLine, strSplitLine)
                        For intCnt = 0 To (strSplitLine.Length - 1)
                            If strSplitLine(intCnt).IndexOf(",") <> -1 Then
                                strOut = strOut & Chr(34) & strSplitLine(intCnt) & Chr(34) & ","
                            Else
                                strOut = strOut & strSplitLine(intCnt) & ","
                            End If
                            Select Case intCnt
                                Case ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR13 - 2           '111
                                    '年額展開13年目
                                    For intAddCnt = 1 To 8
                                        strOut = strOut & "0,"
                                    Next
                                Case ExcelWrite.CsvPaymentLineColumn.PRICE_YEAR12_MONTH1 + 2    '255
                                    '月額展開13年目
                                    For intAddCnt = 1 To 96
                                        strOut = strOut & "0,"
                                    Next
                            End Select
                        Next
                    Else
                        strOut = strLine
                    End If
                Else
                    strOut = strLine
                End If

                sw.WriteLine(strOut)

                intRowCnt = intRowCnt + 1
            Loop

            sw.Close()
            sr.Close()

        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Private Function SplitData(ByVal strData As String, ByRef strSplitData() As String) As Boolean

        Dim strSplitDelemita() As String        '
        Dim intCnt As Integer                   '
        Dim intIndex As Integer = 0             '
        Dim strWork As String                   '
        Dim intNextDataCtn As Integer           '
        Dim intStartCnt As Integer              '
        Dim intStepCnt As Integer               '
        Dim strComcatData As String             '
        Dim blnComcatData As Boolean            '

        SplitData = False

        '２個続きのダブルクォートを１つに変換する
        strWork = strData.Replace(Chr(34) & Chr(34), Chr(34))
        'カンマ区切りを分解する
        strSplitDelemita = strWork.Split(",")

        '分解したデータをチェックする
        For intCnt = 0 To strSplitDelemita.Length - 1
            '両端にダブルクォーテーションがあるか
            If Microsoft.VisualBasic.Left(LTrim(strSplitDelemita(intCnt)), 1) = Chr(34) Then
                '右端にダブルクォーテーションが出るまで繰り返す
                intStartCnt = intCnt
                intStepCnt = 0
                strComcatData = ""
                blnComcatData = False
                For intNextDataCtn = intStartCnt To (strSplitDelemita.Length - 1)
                    '次のデータがまだあるか
                    If intNextDataCtn <= (strSplitDelemita.Length - 1) Then
                        '右端にダブルクォーテーションがあるか
                        If Microsoft.VisualBasic.Right(RTrim(strSplitDelemita(intNextDataCtn)), 1) = Chr(34) Then
                            '現データ＋結合データ＋カンマ＋次データを結合する
                            If intNextDataCtn = intStartCnt Then
                                strWork = strSplitDelemita(intCnt)
                                intCnt = intCnt + intStepCnt
                            Else
                                strWork = strSplitDelemita(intCnt) & strComcatData & "," & strSplitDelemita(intNextDataCtn)
                                intCnt = intCnt + intStepCnt + 1
                            End If
                            ReDim Preserve strSplitData(intIndex)
                            '両端のダウブルクォート削除
                            strSplitData(intIndex) = strWork.Substring(1, strWork.Length - 2)
                            intIndex = intIndex + 1
                            blnComcatData = True
                            Exit For
                        Else
                            If intNextDataCtn <> intStartCnt Then
                                strComcatData = strComcatData & "," & strSplitDelemita(intNextDataCtn)
                                intStepCnt = intStepCnt + 1
                            End If
                        End If
                    End If
                Next

                '右端にデータがなかった場合、通常データとして扱う
                If blnComcatData = False Then
                    ReDim Preserve strSplitData(intIndex)
                    strSplitData(intIndex) = strSplitDelemita(intCnt)
                    intIndex = intIndex + 1
                End If
            Else
                'ダブルクォーテーションがない場合
                ReDim Preserve strSplitData(intIndex)
                strSplitData(intIndex) = strSplitDelemita(intCnt)
                intIndex = intIndex + 1
            End If
        Next

        SplitData = True

    End Function
#End If

    '一括処理画面における、統合Payment作成機能の変更対応 2017/12 Str
    ''' <summary>
    ''' 機能：インポート用CSV変換＆帳票出力処理
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function MainCsvToReport(ByVal strLogFileName As String,
                                     ByVal intProcCd As Integer,
                                     ByVal intCpnoIndex As Integer,
                                     ByRef blnImportOk As Boolean,
                                     ByVal intImportCd As Integer,
                                     ByVal strLogTitle As String,
                                     Optional ByRef frmProcDialog As frmProcessDialog = Nothing) As Boolean

        Dim intIndex As Integer
        Dim arrayWritePsLine As New ArrayList
        Dim arrayWriteDetailLine As New ArrayList
        Dim strDbPath As String = ""
        Dim strExcelStartYear As String = ""
        Dim ic As New ImportCsv
        Dim OUTERR As OutputErrorList
        Dim md As New CreateTempDb
        Dim intRet As Integer
        Dim blnRet As Boolean
        Dim strMsg As String = ""
        Dim frmWait As New Frm_WaitDialog
        Dim strSourceFileName As String
        Dim eam As New ExcelAsrManage
        Dim intFileMax As Integer = 0
        Dim intFileCnt As Integer = 0
        Dim strObamaUrl As String
        Dim cc As CookieContainer = New CookieContainer()       'クッキー設定
        Dim strCsvPsFileName(0 To 5) As String
        Dim strCsvPsPath As String = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT & "\" & DIR_RECV)
        Dim sc As New ServerCsv
        Dim oe As New OutputExcel
        Dim intCnt As Integer
        Dim intMax As Integer

        Dim strStdExcelFileName As String
        Dim dtOutputDate As Date
        Dim esp As New ExcelStandardPs
        Dim strSettingName As String

        MainCsvToReport = False

        Try
            If frmProcDialog Is Nothing Then
                Call InitProgress(True, frmWait, intFileMax)
            Else
                Call ActiveProcDialog(frmProcDialog, 1)
                Call WriteLog(strLogFileName, "サーバーログイン", True)
            End If

            '==============================================
            'サーバーログイン
            '==============================================
            intRet = sc.LoginServer(intProcCd, cc, strObamaUrl, strMsg)
            If intRet <> ServerCsv.RET_OK Then
                If intRet = ServerCsv.RET_SYS_ERROR Then
                    MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0402"), Me.Text)
                End If
                Exit Function
            End If
            Me.Update()
            If frmProcDialog Is Nothing Then
                frmWait.Update()
            End If

            If intProcCd = OutputExcel.CD_PROC_OLD Then
                strCsvPsPath = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT & "\" & DIR_VERUP & "\" & DIR_RECV)
            Else
                If rdoAct.Checked = True Then
                    strCsvPsPath = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT & "\" & DIR_EXCEL & "\" & DIR_ACT & "\" & GetWorkDate() & "\" & DIR_RECV_MAKE)
                Else
                    strCsvPsPath = FileManager.GetLocalFolderPath(DIR_BAT_OUTPUT & "\" & DIR_EXCEL & "\" & DIR_DELIVERY & "\" & GetWorkDate() & "\" & DIR_RECV_MAKE)
                End If
            End If

            blnImportOk = True
            intMax = 1
            If intCpnoIndex = -1 Then
                intMax = typCpNo.Length - 1
            End If
            For intCnt = 1 To intMax
                strMsg = ""
                If intCpnoIndex = -1 Then
                    intIndex = intCnt
                Else
                    intIndex = intCpnoIndex
                End If
                With typCpNo(intIndex)

                    If .Checked = True And .DataOk = True Then
                        OUTERR = New OutputErrorList
                        OUTERR.CpNo = .CpNo
                        OUTERR.ContractNo = ""
                        OUTERR.OutImportErrorList("START", "Import(一括)", , , , True)
                        '==============================================
                        'サーバ ーからCSVファイルを取得
                        '==============================================
                        With sc
                            .GetPsCsvFlg = True
                            .GetPsValCsvFlg = False
                            .GetPsRefCsvFlg = False
                            .GetDetailCsvFlg = True
                            .GetDetailValCsvFlg = False
                            .GetDetailRefCsvFlg = False
                        End With
                        intRet = sc.GetServerCsvs(.CpNo, "", "C", strObamaUrl, cc, strCsvPsPath, strCsvPsFileName, strMsg)
                        If intRet <> ServerCsv.RET_OK Then
                            typCpNo(intIndex).ConvertFlg = CD_CONVERT_ERROR
                            strMsg = .CpNo & "," & .CustomerName & "," & strMsg
                            Call WriteLog(strLogFileName, strMsg, True)
                            blnImportOk = False
                            Exit Function

                        End If
                        .FileFormation(CD_FILEFROMATION_IMPORT_PS_CSV).Path = strCsvPsPath
                        .FileFormation(CD_FILEFROMATION_IMPORT_PS_CSV).FileName = strCsvPsFileName(0)
                        .FileFormation(CD_FILEFROMATION_IMPORT_PS_CSV).WriteUpdate = File.GetLastWriteTime(strCsvPsPath & strCsvPsFileName(0)).ToString("yyyy/MM/dd HH:mm:ss")
                        .FileFormation(CD_FILEFROMATION_IMPORT_DETAIL_CSV).Path = strCsvPsPath
                        .FileFormation(CD_FILEFROMATION_IMPORT_DETAIL_CSV).FileName = strCsvPsFileName(3)
                        .FileFormation(CD_FILEFROMATION_IMPORT_DETAIL_CSV).WriteUpdate = File.GetLastWriteTime(strCsvPsPath & strCsvPsFileName(3)).ToString("yyyy/MM/dd HH:mm:ss")
                        CommonVariable.CPNO = .CpNo
                        CommonVariable.PaymentStart = CDate(.ExcelStart & "/1/1")
                        CommonVariable.ContractStart = .ContractStart
                        CommonVariable.ContractEnd = .ContractEnd

                        '==========================================
                        'データを配列に保存（Refresh、Validation以外）
                        '==========================================
                        If Not frmProcDialog Is Nothing Then
                            Call ActiveProcDialog(frmProcDialog, 2)
                            Call WriteLog(strLogFileName, "DBに保存", True)
                        End If
                        OUTERR.OutImportErrorList(FileReader.GetMessage("MSG_0463"), "Import")
                        Dim alPsCreating As New ArrayList
                        Dim alPsCreated As New ArrayList
                        Dim alPsdCreating As New ArrayList
                        Dim alPsdCreated As New ArrayList
                        Dim alPsCreatingMdb As New ArrayList
                        Dim alPsdCreatingMdb As New ArrayList
                        Dim filePath As ImportCsv.ServerCsvPath
                        Dim importCount As ImportCsv.ImportCount
                        Dim importErrCount As ImportCsv.ImportErrCount
                        With filePath
                            .PSCsv = strCsvPsPath & strCsvPsFileName(0)
                            .DetailCsv = strCsvPsPath & strCsvPsFileName(3)
                        End With
                        blnRet = ic.GetCsvData(ImportCsv.CD_IMPORT_MDB,
                                               filePath,
                                               .PaymentPeriod,
                                               alPsCreating,
                                               alPsCreatingMdb,
                                               alPsCreated,
                                               alPsdCreating,
                                               alPsdCreatingMdb,
                                               alPsdCreated,
                                               importCount,
                                               importErrCount,
                                               OUTERR,
                                               False)
                        OUTERR.OutImportErrorList(FileReader.GetMessage("MSG_0464"), "Import")
                        If blnRet = True Then
                            '==========================================
                            'MDB保存
                            '==========================================
                            blnRet = ic.ImportDb(alPsCreated,
                                              alPsdCreated,
                                              .ExcelStart,
                                              importCount,
                                              OUTERR,
                                              False,
                                              False)
                            If blnRet = False Then
                                OUTERR.OutImportErrorList(FileReader.GetMessage("MSG_0338") & "MainCsvToMdb", "Import")
                            End If
                        End If

                        '==========================================
                        'ログ出力
                        '==========================================
                        strMsg = .CpNo & "," & .CustomerName & ","
                        If blnRet = False Then
                            .ConvertFlg = CD_CONVERT_ERROR
                            strMsg = strMsg & "インポート用CSV変換エラー"
                            blnImportOk = False
                        Else
                            .DbPsCount = importCount.MDBCount
                            .DbPsdCount = importCount.MDBDetailCount
                            strMsg = strMsg & "Payment:" & importCount.MDBCount.ToString.ToUpper & "件取込、"
                            strMsg = strMsg & "詳細:" & importCount.MDBDetailCount.ToString.ToUpper & "件取込"
                            '個別PSリネーム
                            strSourceFileName = .FileFormation(CD_FILEFROMATION_IMPORT_PS_CSV).Path & _
                                                .FileFormation(CD_FILEFROMATION_IMPORT_PS_CSV).FileName
                            Call eam.ReNameBKFile(strSourceFileName)
                            strSourceFileName = .FileFormation(CD_FILEFROMATION_IMPORT_DETAIL_CSV).Path & _
                                                .FileFormation(CD_FILEFROMATION_IMPORT_DETAIL_CSV).FileName
                            Call eam.ReNameBKFile(strSourceFileName)

                            .ConvertFlg = CD_CONVERT_OK
                        End If
                        Call WriteLog(strLogFileName, strMsg, True)
                        OUTERR.OutImportErrorList("END", "Import")
                        OUTERR = Nothing

                        '共通設定
                        CommonVariable.CPNO = .CpNo
                        CommonVariable.CUSTOMERNAME = .CustomerName
                        CommonVariable.PaymentStart = CDate(.ExcelStart & "/1/1")
                        CommonVariable.ContractStart = .ContractStart
                        CommonVariable.ContractEnd = .ContractEnd
                        strStdExcelFileName = .FileFormation(CD_FILEFROMATION_STD_SET).Path & _
                                                .FileFormation(CD_FILEFROMATION_STD_SET).FileName
                        Select Case intImportCd
                            Case CD_STROUT_STANDARD
                                '==========================================
                                '標準帳票出力処理
                                '==========================================
                                blnRet = esp.OutputStdExcelPs(strStdExcelFileName, strMsg)
                            Case CD_STROUT_DATA_ALL, CD_STROUT_DATA_DEL
                                '==========================================
                                'ﾃﾞｰﾀ提供用出力処理
                                '==========================================
                                dtOutputDate = CDate(cboWorkDate.Text.Substring(0, 4) & "/" & cboWorkDate.Text.Substring(5, 2) & "/01")
                                blnRet = esp.OutputSubmittedData(intImportCd,
                                                                 CommonVariable.PaymentStart.ToString("yyyy"),
                                                                 dtOutputDate,
                                                                 Integer.Parse(.PaymentPeriod),
                                                                 strMsg)

                        End Select

                        If blnRet = False Then
                            strMsg = .CpNo & "," & .CustomerName & "," & strLogTitle & "処理エラー," & strMsg
                        Else
                            If intImportCd = CD_STROUT_STANDARD Then
                                strSettingName = "," & strLogTitle & ",(" & .FileFormation(CD_FILEFROMATION_STD_SET).FileName & ")"
                            Else
                                strSettingName = ""
                            End If
                            strMsg = .CpNo & "," & .CustomerName & strSettingName
                        End If

                        Call WriteLog(strLogFileName, strMsg, True)

                        intFileCnt = intFileCnt + 1
                        'ダイアログ更新
                        If frmProcDialog Is Nothing Then
                            Call ActiveProgress(frmWait, intFileCnt, intFileMax)
                        End If

                    End If
                End With
            Next

            MainCsvToReport = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "MainCsvToReport")
            blnImportOk = False

        Finally
            If frmProcDialog Is Nothing Then
                Call EndProgress(frmWait)
            End If

        End Try

    End Function
    '一括処理画面における、統合Payment作成機能の変更対応 2017/12 End

#End Region

End Class
