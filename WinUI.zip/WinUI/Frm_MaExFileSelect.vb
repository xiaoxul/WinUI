Imports System.Text
Imports System.IO
Imports System.Reflection
Imports MUSE.Utility
Imports MUSE.Utility.UserMessageBox
Imports MUSE.Utility.UserException
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.XmlClass.Parameter

'==========================================================================
'�N���X���FFrm_MaExFileSelect
'�T    �v�FFrm_MaExFileSelect�N���X
'��    ���F�֘A�t�@�C���w����
'��    ���F[Ver1.0]  2008/01/24  ���� �i
'==========================================================================
Public Class Frm_MaExFileSelect
    Inherits System.Windows.Forms.Form

#Region " Windows �t�H�[�� �f�U�C�i�Ő������ꂽ�R�[�h "

    Public Sub New()
        MyBase.New()

        ' ���̌Ăяo���� Windows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
        InitializeComponent()

        ' InitializeComponent() �Ăяo���̌�ɏ�������ǉ����܂��B

    End Sub

    ' Form �́A�R���|�[�l���g�ꗗ�Ɍ㏈�������s���邽�߂� dispose ���I�[�o�[���C�h���܂��B
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    ' Windows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
    Private components As System.ComponentModel.IContainer

    ' ���� : �ȉ��̃v���V�[�W���́AWindows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
    'Windows �t�H�[�� �f�U�C�i���g���ĕύX���Ă��������B  
    ' �R�[�h �G�f�B�^���g���ĕύX���Ȃ��ł��������B
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Lst_File_eBS_Mainte As System.Windows.Forms.ListBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Btn_Ref_eBS_Mainte As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Clear_eBS_Mainte As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Cancel As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Ok As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Lst_File_Inventry As System.Windows.Forms.ListBox
    Friend WithEvents Btn_Clear_Inventry As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Ref_Inventry As MUSE.UserControl.UCnt_Btn0001
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Lst_File_eBS_Mainte = New System.Windows.Forms.ListBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Btn_Ref_eBS_Mainte = New MUSE.UserControl.UCnt_Btn0001()
        Me.Lst_File_Inventry = New System.Windows.Forms.ListBox()
        Me.Btn_Clear_Inventry = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Clear_eBS_Mainte = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Ref_Inventry = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Cancel = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Ok = New MUSE.UserControl.UCnt_Btn0001()
        Me.GroupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Label4)
        Me.GroupBox5.Controls.Add(Me.Lst_File_eBS_Mainte)
        Me.GroupBox5.Controls.Add(Me.Label5)
        Me.GroupBox5.Controls.Add(Me.Btn_Ref_eBS_Mainte)
        Me.GroupBox5.Controls.Add(Me.Lst_File_Inventry)
        Me.GroupBox5.Controls.Add(Me.Btn_Clear_Inventry)
        Me.GroupBox5.Controls.Add(Me.Btn_Clear_eBS_Mainte)
        Me.GroupBox5.Controls.Add(Me.Btn_Ref_Inventry)
        Me.GroupBox5.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.GroupBox5.Location = New System.Drawing.Point(34, 10)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(487, 330)
        Me.GroupBox5.TabIndex = 4
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "�֘A�t�@�C���w��"
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label4.Location = New System.Drawing.Point(39, 25)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(196, 20)
        Me.Label4.TabIndex = 49
        Me.Label4.Text = "���C���x���g��(GENESIS)"
        '
        'Lst_File_eBS_Mainte
        '
        Me.Lst_File_eBS_Mainte.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Lst_File_eBS_Mainte.HorizontalScrollbar = True
        Me.Lst_File_eBS_Mainte.ItemHeight = 15
        Me.Lst_File_eBS_Mainte.Location = New System.Drawing.Point(39, 195)
        Me.Lst_File_eBS_Mainte.Name = "Lst_File_eBS_Mainte"
        Me.Lst_File_eBS_Mainte.Size = New System.Drawing.Size(403, 79)
        Me.Lst_File_eBS_Mainte.TabIndex = 6
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label5.Location = New System.Drawing.Point(39, 175)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(196, 20)
        Me.Label5.TabIndex = 51
        Me.Label5.Text = "��e-BS (�ێ�)"
        '
        'Btn_Ref_eBS_Mainte
        '
        Me.Btn_Ref_eBS_Mainte.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Ref_eBS_Mainte.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Ref_eBS_Mainte.ForeColor = System.Drawing.Color.White
        Me.Btn_Ref_eBS_Mainte.Location = New System.Drawing.Point(230, 280)
        Me.Btn_Ref_eBS_Mainte.Name = "Btn_Ref_eBS_Mainte"
        Me.Btn_Ref_eBS_Mainte.Size = New System.Drawing.Size(100, 40)
        Me.Btn_Ref_eBS_Mainte.TabIndex = 7
        Me.Btn_Ref_eBS_Mainte.Text = "�Q��"
        Me.Btn_Ref_eBS_Mainte.UseVisualStyleBackColor = False
        '
        'Lst_File_Inventry
        '
        Me.Lst_File_Inventry.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Lst_File_Inventry.HorizontalScrollbar = True
        Me.Lst_File_Inventry.ItemHeight = 15
        Me.Lst_File_Inventry.Location = New System.Drawing.Point(39, 45)
        Me.Lst_File_Inventry.Name = "Lst_File_Inventry"
        Me.Lst_File_Inventry.Size = New System.Drawing.Size(403, 79)
        Me.Lst_File_Inventry.TabIndex = 3
        '
        'Btn_Clear_Inventry
        '
        Me.Btn_Clear_Inventry.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Clear_Inventry.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Clear_Inventry.ForeColor = System.Drawing.Color.White
        Me.Btn_Clear_Inventry.Location = New System.Drawing.Point(342, 130)
        Me.Btn_Clear_Inventry.Name = "Btn_Clear_Inventry"
        Me.Btn_Clear_Inventry.Size = New System.Drawing.Size(100, 40)
        Me.Btn_Clear_Inventry.TabIndex = 5
        Me.Btn_Clear_Inventry.Text = "�N���A"
        Me.Btn_Clear_Inventry.UseVisualStyleBackColor = False
        '
        'Btn_Clear_eBS_Mainte
        '
        Me.Btn_Clear_eBS_Mainte.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Clear_eBS_Mainte.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Clear_eBS_Mainte.ForeColor = System.Drawing.Color.White
        Me.Btn_Clear_eBS_Mainte.Location = New System.Drawing.Point(342, 280)
        Me.Btn_Clear_eBS_Mainte.Name = "Btn_Clear_eBS_Mainte"
        Me.Btn_Clear_eBS_Mainte.Size = New System.Drawing.Size(100, 40)
        Me.Btn_Clear_eBS_Mainte.TabIndex = 8
        Me.Btn_Clear_eBS_Mainte.Text = "�N���A"
        Me.Btn_Clear_eBS_Mainte.UseVisualStyleBackColor = False
        '
        'Btn_Ref_Inventry
        '
        Me.Btn_Ref_Inventry.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Ref_Inventry.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Ref_Inventry.ForeColor = System.Drawing.Color.White
        Me.Btn_Ref_Inventry.Location = New System.Drawing.Point(230, 130)
        Me.Btn_Ref_Inventry.Name = "Btn_Ref_Inventry"
        Me.Btn_Ref_Inventry.Size = New System.Drawing.Size(100, 40)
        Me.Btn_Ref_Inventry.TabIndex = 4
        Me.Btn_Ref_Inventry.Text = "�Q��"
        Me.Btn_Ref_Inventry.UseVisualStyleBackColor = False
        '
        'Btn_Cancel
        '
        Me.Btn_Cancel.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Cancel.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Cancel.ForeColor = System.Drawing.Color.White
        Me.Btn_Cancel.Location = New System.Drawing.Point(364, 385)
        Me.Btn_Cancel.Name = "Btn_Cancel"
        Me.Btn_Cancel.Size = New System.Drawing.Size(157, 55)
        Me.Btn_Cancel.TabIndex = 6
        Me.Btn_Cancel.Text = "Cancel"
        Me.Btn_Cancel.UseVisualStyleBackColor = False
        '
        'Btn_Ok
        '
        Me.Btn_Ok.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Ok.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Ok.ForeColor = System.Drawing.Color.White
        Me.Btn_Ok.Location = New System.Drawing.Point(185, 385)
        Me.Btn_Ok.Name = "Btn_Ok"
        Me.Btn_Ok.Size = New System.Drawing.Size(157, 55)
        Me.Btn_Ok.TabIndex = 5
        Me.Btn_Ok.Text = "OK"
        Me.Btn_Ok.UseVisualStyleBackColor = False
        '
        'Frm_MaExFileSelect
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(416, 389)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.Btn_Cancel)
        Me.Controls.Add(Me.Btn_Ok)
        Me.Name = "Frm_MaExFileSelect"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "�֘A�t�@�C���w��"
        Me.GroupBox5.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region " �����o�ϐ� "

    Dim _inputFile As MaEx_InputFileList
    Dim inventryList As New ArrayList
    Dim eBSMainteList As New ArrayList
    Dim _dialogInitialPath As String

#End Region

#Region " �v���p�e�B "

    Public WriteOnly Property InputFile() As MaEx_InputFileList
        Set(ByVal Value As MaEx_InputFileList)
            Me._inputFile = Value
        End Set
    End Property

    Public Property DialogInitialPath() As String
        Get
            Return Me._dialogInitialPath
        End Get
        Set(ByVal Value As String)
            Me._dialogInitialPath = Value
        End Set
    End Property

#End Region

#Region " �C�x���g�n���h��"

    '--------------------------------------------------------
    '���\�b�h���FFrm_X_FileSelect_Load
    '�T    �v  �F��ʃ��[�h����
    '��    ��  �F��ʃ��[�h�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Frm_MaExFileSelect_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try
            '��ʐݒ�
            Me.SetInitialData()

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
            Me.Close()
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
            Me.Close()
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Ref_Inventry_Click
    '�T    �v  �FBtn_Ref_Inventry�N���b�N����
    '��    ��  �FBtn_Ref_Inventry�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Ref_Inventry_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Ref_Inventry.Click

        Try
            Dim dialog As OpenFileDialog = New OpenFileDialog
            dialog.Filter = "������� ̧�� (*.xlsm)|*.xlsm"
            dialog.Multiselect = True

            dialog.InitialDirectory = GetFileSeletctDialogInitialPath()

            If dialog.ShowDialog() = DialogResult.OK Then
                Dim fileName As String = dialog.FileName

                For Each fileName In dialog.FileNames

                    Me.Lst_File_Inventry.Items.Add(Path.GetFileName(fileName))
                    Me.inventryList.Add(fileName)
                    Me._dialogInitialPath = Path.GetDirectoryName(dialog.FileName)
                Next

            End If

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Clear_Inventry_Click
    '�T    �v  �FBtn_Clear_Inventry�N���b�N����
    '��    ��  �FBtn_Clear_Inventry�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Clear_Inventry_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear_Inventry.Click

        Try
            Dim index As Integer

            index = Me.Lst_File_Inventry.SelectedIndex
            If index <> -1 Then
                '�w�肵���t�@�C�����X�g�{�b�N�X�N���A
                Me.Lst_File_Inventry.Items.RemoveAt(index)
                Me.inventryList.RemoveAt(index)
            Else
                '�t�@�C�����X�g�{�b�N�X�̑S�Ă̍��ڃN���A
                Me.Lst_File_Inventry.Items.Clear()
                Me.inventryList.Clear()
            End If

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Ref_eBS_Mainte_Click
    '�T    �v  �FBtn_Ref_eBS_Mainte�N���b�N����
    '��    ��  �FBtn_Ref_eBS_Mainte�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Ref_eBS_Mainte_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Ref_eBS_Mainte.Click

        Try
            Dim dialog As OpenFileDialog = New OpenFileDialog
            dialog.InitialDirectory = GetFileSeletctDialogInitialPath()
            dialog.Filter = "csv files (*.csv)|*.csv"
            dialog.Multiselect = True

            If dialog.ShowDialog() = DialogResult.OK Then
                Dim fileName As String = dialog.FileName
                For Each fileName In dialog.FileNames
                    Me.Lst_File_eBS_Mainte.Items.Add(Path.GetFileName(fileName))
                    Me.eBSMainteList.Add(fileName)
                Next
            End If

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Clear_eBS_Mainte_Click
    '�T    �v  �FBtn_Clear_eBS_Mainte�N���b�N����
    '��    ��  �FBtn_Clear_eBS_Mainte�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Clear_eBS_Mainte_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear_eBS_Mainte.Click

        Try
            Dim index As Integer

            index = Me.Lst_File_eBS_Mainte.SelectedIndex
            If index <> -1 Then
                '�w�肵���t�@�C�����X�g�{�b�N�X�N���A
                Me.Lst_File_eBS_Mainte.Items.RemoveAt(index)
                Me.eBSMainteList.RemoveAt(index)
            Else
                '�t�@�C�����X�g�{�b�N�X�̑S�Ă̍��ڃN���A
                Me.Lst_File_eBS_Mainte.Items.Clear()
                Me.eBSMainteList.Clear()
            End If

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Ok_Click
    '�T    �v  �FBtn_Ok�N���b�N����
    '��    ��  �FBtn_Ok�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Ok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Ok.Click

        Try
            '�t�@�C�����X�g�f�[�^�ݒ�
            Me.SetFileListData()

            '��ʂ����
            Me.Close()

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Cancel_Click
    '�T    �v  �FBtn_Cancel�N���b�N����
    '��    ��  �FBtn_Cancel�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Cancel.Click

        Try
            '��ʂ����
            Me.Close()

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

#End Region

#Region " �v���C�x�[�g���\�b�h "

    '--------------------------------------------------------
    '���\�b�h���FSetFileList
    '�T    �v  �F��ʓ��͒l�擾����
    '��    ��  �F��ʓ��͒l�擾�������s��
    '��    ��  �F�Ȃ�
    '�� �� �l  �F��ʓ��͒l
    '--------------------------------------------------------
    Private Sub SetInitialData()

        Dim fileNames As String()
        Dim fileName As String

        '==============================
        '���C���x���g����
        '==============================
        fileNames = Me._inputFile.Inventry.Split(CommonConstant.STR_SLASH)
        For Each fileName In fileNames
            If Not fileName.Equals(String.Empty) Then
                Me.Lst_File_Inventry.Items.Add(Path.GetFileName(fileName))
                Me.inventryList.Add(fileName)
            End If
        Next

        '==============================
        '��eBS(�ێ�)��
        '==============================
        fileNames = Me._inputFile.eBS_Mainte.Split(CommonConstant.STR_SLASH)
        For Each fileName In fileNames
            If Not fileName.Equals(String.Empty) Then
                Me.Lst_File_eBS_Mainte.Items.Add(Path.GetFileName(fileName))
                Me.eBSMainteList.Add(fileName)
            End If
        Next

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FSetFileListData
    '�T    �v  �F��ʓ��͒l�擾����
    '��    ��  �F��ʓ��͒l�擾�������s��
    '��    ��  �F�Ȃ�
    '�� �� �l  �F��ʓ��͒l
    '--------------------------------------------------------
    Private Sub SetFileListData()

        Dim fileName As String
        Dim inventryFileName As New StringBuilder
        Dim eBSMainteFileName As New StringBuilder

        '==============================
        '���C���x���g����
        '==============================
        For Each fileName In Me.inventryList
            If inventryFileName.Length > 0 Then
                inventryFileName.Append(CommonConstant.STR_SLASH)
            End If
            inventryFileName.Append(fileName)
        Next
        Me._inputFile.Inventry = inventryFileName.ToString()

        '==============================
        '��eBS(�ێ�)��
        '==============================
        For Each fileName In Me.eBSMainteList
            If eBSMainteFileName.Length > 0 Then
                eBSMainteFileName.Append(CommonConstant.STR_SLASH)
            End If
            eBSMainteFileName.Append(fileName)
        Next
        Me._inputFile.eBS_Mainte = eBSMainteFileName.ToString()

    End Sub

    ''' <summary>
    ''' �T  �v�F�Q�ƃ{�^���̃t�@�C���I���_�C�A�����O�{�b�N�X�̏����ʒu���w�肷��B
    ''' ��  ���FConfig\�Y���t�H���_���f�t�H���g�ʒu
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetFileSeletctDialogInitialPath() As String

        Dim strCpNo As String = CommonVariable.CPNO.Trim.PadLeft(8, "0")
        Dim strContractNO As String = CommonVariable.CONTRACTNO.ToString().PadLeft(3, "0c")
        Dim strPath As String

        GetFileSeletctDialogInitialPath = ""

        strPath = CommonConstant.FOLDERNAME_CONFIG & "\" & strCpNo & "_" & strContractNO
        Return FileManager.GetLocalFolderPath(strPath)

    End Function

#End Region

End Class
