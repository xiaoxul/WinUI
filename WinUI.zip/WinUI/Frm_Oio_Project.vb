Imports System.Text
Imports System.IO
Imports System.Reflection
Imports System.Data.OleDb
Imports MUSE.Utility
Imports MUSE.Utility.SharedClass
Imports MUSE.Utility.UserDataSet
Imports MUSE.Utility.UserDataTable.Master
Imports MUSE.Utility.UserDataTable.Transaction
Imports MUSE.Utility.UserDataTable.Work
Imports MUSE.Utility.UserMessageBox
Imports MUSE.Utility.UserException
Imports MUSE.Utility.XmlClass.Parameter
Imports MUSE.Utility.XmlClass.SystemInfo
Imports MUSE.Controller
Imports MUSE.Utility.OioBamaCommmon
Imports System.Runtime.InteropServices
'==========================================================================
'�N���X���FFrm_Oio_Project
'�T    �v�FFrm_Oio_Project�N���X
'��    ���FFrm_Oio_Project���
'��    ���F[Ver1.0]  2007/06/18  �����@���K
'==========================================================================
Public Class Frm_Oio_Project
    Inherits System.Windows.Forms.Form

#Region " Windows �t�H�[�� �f�U�C�i�Ő������ꂽ�R�[�h "

    Public Sub New()
        MyBase.New()

        ' ���̌Ăяo���� Windows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
        InitializeComponent()

        ' InitializeComponent() �Ăяo���̌�ɏ�������ǉ����܂��B

    End Sub

    ' Form �́A�R���|�[�l���g�ꗗ�Ɍ㏈�������s���邽�߂� dispose ���I�[�o�[���C�h���܂��B
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    ' Windows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
    Private components As System.ComponentModel.IContainer

    ' ���� : �ȉ��̃v���V�[�W���́AWindows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
    'Windows �t�H�[�� �f�U�C�i���g���ĕύX���Ă��������B  
    ' �R�[�h �G�f�B�^���g���ĕύX���Ȃ��ł��������B
    Friend WithEvents UCnt_Pal00011 As UserControl.UCnt_Pal0001
    Friend WithEvents UCnt_Btn00012 As UserControl.UCnt_Btn0001
    Friend WithEvents UCnt_Btn00013 As UserControl.UCnt_Btn0001
    Friend WithEvents UCnt_Pal00012 As UserControl.UCnt_Pal0001
    Friend WithEvents Btn_Close As UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Ref_Config As UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Clear_Config As UserControl.UCnt_Btn0001
    Friend WithEvents Btn_SelectRelationFile As UserControl.UCnt_Btn0001
    Friend WithEvents Rdo_MainteOthersSaleSvc As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_MainteOthersSaleMainte As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_MainteOthersSale As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_MainteTimeMonSun24h As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_MainteTimeMonSun18h As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_MainteTimeMonSun12h As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_MainteTimeMonSat12h As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_MainteAmountAnnual As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_MainteAmountMonthly As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_SvcTypeSuperServicePlus As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_SvcTypeRepair As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_SvcTerm5Years As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_SvcTerm4Years As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_SvcTerm3Years As System.Windows.Forms.RadioButton
    Friend WithEvents Grp_SvcPacType As System.Windows.Forms.GroupBox
    Friend WithEvents Grp_SvcPacTerm As System.Windows.Forms.GroupBox
    Friend WithEvents Grp_MainteOthers As System.Windows.Forms.GroupBox
    Friend WithEvents Grp_MainteTime As System.Windows.Forms.GroupBox
    Friend WithEvents Grp_MainteAmount As System.Windows.Forms.GroupBox
    Friend WithEvents Tab_Main As System.Windows.Forms.TabControl
    Friend WithEvents Rdo_SvcTerm2Years As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_SvcTerm1Year As System.Windows.Forms.RadioButton
    Friend WithEvents Tab_X As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Btn_X_SelectRelationFile As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Clear_X As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Ref_X As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Lst_File_X As System.Windows.Forms.ListBox
    Friend WithEvents Tab_zSW As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents Btn_Clear_Zsw As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Lst_File_Zsw As System.Windows.Forms.ListBox
    Friend WithEvents Btn_Ref_Zsw As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Dp_StartTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents Dp_Introduction As System.Windows.Forms.DateTimePicker
    Friend WithEvents Dp_EndTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Grp_InputFile As System.Windows.Forms.GroupBox
    Friend WithEvents Tab_Pa As System.Windows.Forms.TabPage
    Friend WithEvents Tab_Iasc As System.Windows.Forms.TabPage
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Txt_Pa_NO As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Pa_InputData1 As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Pa_InputData2 As System.Windows.Forms.TextBox
    Friend WithEvents Btn_Up_Config As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Btn_Down_Config As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Txt_Iasc_InputData As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents Rdo_x_DescriptionTarget_mdb As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_x_DescriptionTarget_eBs As System.Windows.Forms.RadioButton
    Friend WithEvents Cmb_Pa_Anniversary As System.Windows.Forms.ComboBox
    Friend WithEvents Tab_Cisco As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Btn_Clear_Cisco As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Lst_File_Cisco As System.Windows.Forms.ListBox
    Friend WithEvents Btn_Ref_Cisco As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents lblSuffixNo As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents lblContractName As System.Windows.Forms.Label
    Friend WithEvents lblCPNO As System.Windows.Forms.Label
    Friend WithEvents lblContractNo As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Dp_PayEnd As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Dp_PayStart As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents lblPlanNo As System.Windows.Forms.Label
    Friend WithEvents Grp_MainteSystem As System.Windows.Forms.GroupBox
    Friend WithEvents Rdo_MainteSystemMaps As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_MainteSystemChis As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_x_DescriptionTarget_Master As System.Windows.Forms.RadioButton
    Friend WithEvents cmbPlanNO As System.Windows.Forms.ComboBox
    Friend WithEvents Btn_Ref_Config_Swma As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents Btn_Clear_Fma As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Lst_File_Fma As System.Windows.Forms.ListBox
    Friend WithEvents Btn_Ref_Fma As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents GroupBox11 As System.Windows.Forms.GroupBox
    Friend WithEvents Rdo_AAS_DescriptionTarget_Master As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_AAS_DescriptionTarget_eBs As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox12 As System.Windows.Forms.GroupBox
    Friend WithEvents Rdo_Mvms_Display As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_Mvms_Notes As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents Txt_Mvms_InputData As System.Windows.Forms.TextBox
    Friend WithEvents Rdo_SvcTypeBasicSelection As System.Windows.Forms.RadioButton
    Friend WithEvents grpCisco As System.Windows.Forms.GroupBox
    Friend WithEvents rbBFull As System.Windows.Forms.RadioButton
    Friend WithEvents rbBHalf As System.Windows.Forms.RadioButton
    Friend WithEvents rbBMid As System.Windows.Forms.RadioButton
    Friend WithEvents rbBBase As System.Windows.Forms.RadioButton
    Friend WithEvents rbAFull As System.Windows.Forms.RadioButton
    Friend WithEvents rbAHalf As System.Windows.Forms.RadioButton
    Friend WithEvents rbAMid As System.Windows.Forms.RadioButton
    Friend WithEvents rbABase As System.Windows.Forms.RadioButton
    Friend WithEvents dgv_File_Config As System.Windows.Forms.DataGridView
    Friend WithEvents colFile As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colQty As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents chkzSwNoChange As System.Windows.Forms.CheckBox
    Friend WithEvents Btn_OK As MUSE.UserControl.UCnt_Btn0001
    Friend WithEvents Grp_IsatDate As System.Windows.Forms.GroupBox
    Friend WithEvents Rdo_UseIsat As System.Windows.Forms.RadioButton
    Friend WithEvents Rdo_UseClient As System.Windows.Forms.RadioButton
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Cmb_ChargeLevel As System.Windows.Forms.ComboBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Grp_InputFile = New System.Windows.Forms.GroupBox()
        Me.dgv_File_Config = New System.Windows.Forms.DataGridView()
        Me.colFile = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colQty = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Btn_Ref_Config_Swma = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_SelectRelationFile = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Clear_Config = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Ref_Config = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Up_Config = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Down_Config = New MUSE.UserControl.UCnt_Btn0001()
        Me.Grp_MainteOthers = New System.Windows.Forms.GroupBox()
        Me.Rdo_MainteOthersSaleSvc = New System.Windows.Forms.RadioButton()
        Me.Rdo_MainteOthersSaleMainte = New System.Windows.Forms.RadioButton()
        Me.Rdo_MainteOthersSale = New System.Windows.Forms.RadioButton()
        Me.Grp_MainteTime = New System.Windows.Forms.GroupBox()
        Me.Rdo_MainteTimeMonSun24h = New System.Windows.Forms.RadioButton()
        Me.Rdo_MainteTimeMonSun18h = New System.Windows.Forms.RadioButton()
        Me.Rdo_MainteTimeMonSun12h = New System.Windows.Forms.RadioButton()
        Me.Rdo_MainteTimeMonSat12h = New System.Windows.Forms.RadioButton()
        Me.Grp_MainteAmount = New System.Windows.Forms.GroupBox()
        Me.Rdo_MainteAmountAnnual = New System.Windows.Forms.RadioButton()
        Me.Rdo_MainteAmountMonthly = New System.Windows.Forms.RadioButton()
        Me.Tab_Main = New System.Windows.Forms.TabControl()
        Me.Tab_X = New System.Windows.Forms.TabPage()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.Rdo_x_DescriptionTarget_Master = New System.Windows.Forms.RadioButton()
        Me.Rdo_x_DescriptionTarget_mdb = New System.Windows.Forms.RadioButton()
        Me.Rdo_x_DescriptionTarget_eBs = New System.Windows.Forms.RadioButton()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Btn_X_SelectRelationFile = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_Clear_X = New MUSE.UserControl.UCnt_Btn0001()
        Me.Lst_File_X = New System.Windows.Forms.ListBox()
        Me.Btn_Ref_X = New MUSE.UserControl.UCnt_Btn0001()
        Me.Tab_Iasc = New System.Windows.Forms.TabPage()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Txt_Iasc_InputData = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Tab_Pa = New System.Windows.Forms.TabPage()
        Me.Cmb_ChargeLevel = New System.Windows.Forms.ComboBox()
        Me.Txt_Pa_NO = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Txt_Pa_InputData1 = New System.Windows.Forms.TextBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Txt_Pa_InputData2 = New System.Windows.Forms.TextBox()
        Me.Cmb_Pa_Anniversary = New System.Windows.Forms.ComboBox()
        Me.Tab_zSW = New System.Windows.Forms.TabPage()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.chkzSwNoChange = New System.Windows.Forms.CheckBox()
        Me.Btn_Clear_Zsw = New MUSE.UserControl.UCnt_Btn0001()
        Me.Lst_File_Zsw = New System.Windows.Forms.ListBox()
        Me.Btn_Ref_Zsw = New MUSE.UserControl.UCnt_Btn0001()
        Me.Tab_Cisco = New System.Windows.Forms.TabPage()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Btn_Clear_Cisco = New MUSE.UserControl.UCnt_Btn0001()
        Me.Lst_File_Cisco = New System.Windows.Forms.ListBox()
        Me.Btn_Ref_Cisco = New MUSE.UserControl.UCnt_Btn0001()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.GroupBox12 = New System.Windows.Forms.GroupBox()
        Me.Rdo_Mvms_Display = New System.Windows.Forms.RadioButton()
        Me.Rdo_Mvms_Notes = New System.Windows.Forms.RadioButton()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.Txt_Mvms_InputData = New System.Windows.Forms.TextBox()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.Btn_Clear_Fma = New MUSE.UserControl.UCnt_Btn0001()
        Me.Lst_File_Fma = New System.Windows.Forms.ListBox()
        Me.Btn_Ref_Fma = New MUSE.UserControl.UCnt_Btn0001()
        Me.Grp_SvcPacType = New System.Windows.Forms.GroupBox()
        Me.Rdo_SvcTypeBasicSelection = New System.Windows.Forms.RadioButton()
        Me.Rdo_SvcTypeSuperServicePlus = New System.Windows.Forms.RadioButton()
        Me.Rdo_SvcTypeRepair = New System.Windows.Forms.RadioButton()
        Me.Grp_SvcPacTerm = New System.Windows.Forms.GroupBox()
        Me.Rdo_SvcTerm3Years = New System.Windows.Forms.RadioButton()
        Me.Rdo_SvcTerm5Years = New System.Windows.Forms.RadioButton()
        Me.Rdo_SvcTerm4Years = New System.Windows.Forms.RadioButton()
        Me.Rdo_SvcTerm2Years = New System.Windows.Forms.RadioButton()
        Me.Rdo_SvcTerm1Year = New System.Windows.Forms.RadioButton()
        Me.Dp_StartTime = New System.Windows.Forms.DateTimePicker()
        Me.Dp_Introduction = New System.Windows.Forms.DateTimePicker()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Dp_EndTime = New System.Windows.Forms.DateTimePicker()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.lblSuffixNo = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.lblContractName = New System.Windows.Forms.Label()
        Me.lblCPNO = New System.Windows.Forms.Label()
        Me.lblContractNo = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Dp_PayEnd = New System.Windows.Forms.DateTimePicker()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Dp_PayStart = New System.Windows.Forms.DateTimePicker()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.lblPlanNo = New System.Windows.Forms.Label()
        Me.Grp_MainteSystem = New System.Windows.Forms.GroupBox()
        Me.Rdo_MainteSystemMaps = New System.Windows.Forms.RadioButton()
        Me.Rdo_MainteSystemChis = New System.Windows.Forms.RadioButton()
        Me.cmbPlanNO = New System.Windows.Forms.ComboBox()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.Rdo_AAS_DescriptionTarget_Master = New System.Windows.Forms.RadioButton()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.Rdo_AAS_DescriptionTarget_eBs = New System.Windows.Forms.RadioButton()
        Me.grpCisco = New System.Windows.Forms.GroupBox()
        Me.rbBFull = New System.Windows.Forms.RadioButton()
        Me.rbBHalf = New System.Windows.Forms.RadioButton()
        Me.rbBMid = New System.Windows.Forms.RadioButton()
        Me.rbBBase = New System.Windows.Forms.RadioButton()
        Me.rbAFull = New System.Windows.Forms.RadioButton()
        Me.rbAHalf = New System.Windows.Forms.RadioButton()
        Me.rbAMid = New System.Windows.Forms.RadioButton()
        Me.rbABase = New System.Windows.Forms.RadioButton()
        Me.UCnt_Pal00012 = New MUSE.UserControl.UCnt_Pal0001()
        Me.Btn_Close = New MUSE.UserControl.UCnt_Btn0001()
        Me.Btn_OK = New MUSE.UserControl.UCnt_Btn0001()
        Me.Grp_IsatDate = New System.Windows.Forms.GroupBox()
        Me.Rdo_UseIsat = New System.Windows.Forms.RadioButton()
        Me.Rdo_UseClient = New System.Windows.Forms.RadioButton()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Grp_InputFile.SuspendLayout()
        CType(Me.dgv_File_Config, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Grp_MainteOthers.SuspendLayout()
        Me.Grp_MainteTime.SuspendLayout()
        Me.Grp_MainteAmount.SuspendLayout()
        Me.Tab_Main.SuspendLayout()
        Me.Tab_X.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.Tab_Iasc.SuspendLayout()
        Me.Tab_Pa.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.Tab_zSW.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.Tab_Cisco.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.GroupBox12.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.Grp_SvcPacType.SuspendLayout()
        Me.Grp_SvcPacTerm.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.Grp_MainteSystem.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        Me.grpCisco.SuspendLayout()
        Me.Grp_IsatDate.SuspendLayout()
        Me.SuspendLayout()
        '
        'Grp_InputFile
        '
        Me.Grp_InputFile.Controls.Add(Me.dgv_File_Config)
        Me.Grp_InputFile.Controls.Add(Me.Btn_Ref_Config_Swma)
        Me.Grp_InputFile.Controls.Add(Me.Btn_SelectRelationFile)
        Me.Grp_InputFile.Controls.Add(Me.Btn_Clear_Config)
        Me.Grp_InputFile.Controls.Add(Me.Btn_Ref_Config)
        Me.Grp_InputFile.Controls.Add(Me.Btn_Up_Config)
        Me.Grp_InputFile.Controls.Add(Me.Btn_Down_Config)
        Me.Grp_InputFile.Location = New System.Drawing.Point(15, 166)
        Me.Grp_InputFile.Margin = New System.Windows.Forms.Padding(2)
        Me.Grp_InputFile.Name = "Grp_InputFile"
        Me.Grp_InputFile.Padding = New System.Windows.Forms.Padding(2)
        Me.Grp_InputFile.Size = New System.Drawing.Size(575, 283)
        Me.Grp_InputFile.TabIndex = 5
        Me.Grp_InputFile.TabStop = False
        Me.Grp_InputFile.Text = "�Ǎ��t�@�C���w��"
        '
        'dgv_File_Config
        '
        Me.dgv_File_Config.AllowUserToAddRows = False
        Me.dgv_File_Config.AllowUserToResizeRows = False
        Me.dgv_File_Config.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_File_Config.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colFile, Me.colQty})
        Me.dgv_File_Config.Location = New System.Drawing.Point(15, 22)
        Me.dgv_File_Config.Margin = New System.Windows.Forms.Padding(2)
        Me.dgv_File_Config.MultiSelect = False
        Me.dgv_File_Config.Name = "dgv_File_Config"
        Me.dgv_File_Config.RowHeadersVisible = False
        Me.dgv_File_Config.RowTemplate.Height = 21
        Me.dgv_File_Config.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgv_File_Config.Size = New System.Drawing.Size(518, 216)
        Me.dgv_File_Config.TabIndex = 73
        '
        'colFile
        '
        Me.colFile.HeaderText = "�t�@�C����"
        Me.colFile.Name = "colFile"
        Me.colFile.ReadOnly = True
        Me.colFile.Width = 390
        '
        'colQty
        '
        Me.colQty.HeaderText = "����"
        Me.colQty.Name = "colQty"
        Me.colQty.Width = 80
        '
        'Btn_Ref_Config_Swma
        '
        Me.Btn_Ref_Config_Swma.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Ref_Config_Swma.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Ref_Config_Swma.ForeColor = System.Drawing.Color.White
        Me.Btn_Ref_Config_Swma.Location = New System.Drawing.Point(216, 244)
        Me.Btn_Ref_Config_Swma.Margin = New System.Windows.Forms.Padding(2)
        Me.Btn_Ref_Config_Swma.Name = "Btn_Ref_Config_Swma"
        Me.Btn_Ref_Config_Swma.Size = New System.Drawing.Size(76, 32)
        Me.Btn_Ref_Config_Swma.TabIndex = 72
        Me.Btn_Ref_Config_Swma.Text = "�P��SWMA"
        Me.Btn_Ref_Config_Swma.UseVisualStyleBackColor = False
        '
        'Btn_SelectRelationFile
        '
        Me.Btn_SelectRelationFile.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_SelectRelationFile.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_SelectRelationFile.ForeColor = System.Drawing.Color.White
        Me.Btn_SelectRelationFile.Location = New System.Drawing.Point(382, 244)
        Me.Btn_SelectRelationFile.Margin = New System.Windows.Forms.Padding(2)
        Me.Btn_SelectRelationFile.Name = "Btn_SelectRelationFile"
        Me.Btn_SelectRelationFile.Size = New System.Drawing.Size(75, 32)
        Me.Btn_SelectRelationFile.TabIndex = 2
        Me.Btn_SelectRelationFile.Text = "�֘A�t�@�C���w��"
        Me.Btn_SelectRelationFile.UseVisualStyleBackColor = False
        '
        'Btn_Clear_Config
        '
        Me.Btn_Clear_Config.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Clear_Config.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Clear_Config.ForeColor = System.Drawing.Color.White
        Me.Btn_Clear_Config.Location = New System.Drawing.Point(466, 244)
        Me.Btn_Clear_Config.Margin = New System.Windows.Forms.Padding(2)
        Me.Btn_Clear_Config.Name = "Btn_Clear_Config"
        Me.Btn_Clear_Config.Size = New System.Drawing.Size(75, 32)
        Me.Btn_Clear_Config.TabIndex = 3
        Me.Btn_Clear_Config.Text = "�N���A"
        Me.Btn_Clear_Config.UseVisualStyleBackColor = False
        '
        'Btn_Ref_Config
        '
        Me.Btn_Ref_Config.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Ref_Config.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Ref_Config.ForeColor = System.Drawing.Color.White
        Me.Btn_Ref_Config.Location = New System.Drawing.Point(298, 244)
        Me.Btn_Ref_Config.Margin = New System.Windows.Forms.Padding(2)
        Me.Btn_Ref_Config.Name = "Btn_Ref_Config"
        Me.Btn_Ref_Config.Size = New System.Drawing.Size(75, 32)
        Me.Btn_Ref_Config.TabIndex = 1
        Me.Btn_Ref_Config.Text = "�Q��"
        Me.Btn_Ref_Config.UseVisualStyleBackColor = False
        '
        'Btn_Up_Config
        '
        Me.Btn_Up_Config.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Up_Config.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Up_Config.ForeColor = System.Drawing.Color.White
        Me.Btn_Up_Config.Location = New System.Drawing.Point(542, 192)
        Me.Btn_Up_Config.Margin = New System.Windows.Forms.Padding(2)
        Me.Btn_Up_Config.Name = "Btn_Up_Config"
        Me.Btn_Up_Config.Size = New System.Drawing.Size(26, 24)
        Me.Btn_Up_Config.TabIndex = 70
        Me.Btn_Up_Config.Text = "��"
        Me.Btn_Up_Config.UseVisualStyleBackColor = False
        '
        'Btn_Down_Config
        '
        Me.Btn_Down_Config.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Down_Config.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Down_Config.ForeColor = System.Drawing.Color.White
        Me.Btn_Down_Config.Location = New System.Drawing.Point(542, 216)
        Me.Btn_Down_Config.Margin = New System.Windows.Forms.Padding(2)
        Me.Btn_Down_Config.Name = "Btn_Down_Config"
        Me.Btn_Down_Config.Size = New System.Drawing.Size(26, 24)
        Me.Btn_Down_Config.TabIndex = 71
        Me.Btn_Down_Config.Text = "��"
        Me.Btn_Down_Config.UseVisualStyleBackColor = False
        '
        'Grp_MainteOthers
        '
        Me.Grp_MainteOthers.Controls.Add(Me.Rdo_MainteOthersSaleSvc)
        Me.Grp_MainteOthers.Controls.Add(Me.Rdo_MainteOthersSaleMainte)
        Me.Grp_MainteOthers.Controls.Add(Me.Rdo_MainteOthersSale)
        Me.Grp_MainteOthers.Location = New System.Drawing.Point(16, 458)
        Me.Grp_MainteOthers.Margin = New System.Windows.Forms.Padding(2)
        Me.Grp_MainteOthers.Name = "Grp_MainteOthers"
        Me.Grp_MainteOthers.Padding = New System.Windows.Forms.Padding(2)
        Me.Grp_MainteOthers.Size = New System.Drawing.Size(200, 125)
        Me.Grp_MainteOthers.TabIndex = 6
        Me.Grp_MainteOthers.TabStop = False
        Me.Grp_MainteOthers.Text = "�ێ炻�̑�"
        '
        'Rdo_MainteOthersSaleSvc
        '
        Me.Rdo_MainteOthersSaleSvc.Location = New System.Drawing.Point(13, 58)
        Me.Rdo_MainteOthersSaleSvc.Margin = New System.Windows.Forms.Padding(2)
        Me.Rdo_MainteOthersSaleSvc.Name = "Rdo_MainteOthersSaleSvc"
        Me.Rdo_MainteOthersSaleSvc.Size = New System.Drawing.Size(164, 21)
        Me.Rdo_MainteOthersSaleSvc.TabIndex = 2
        Me.Rdo_MainteOthersSaleSvc.Text = "����+SvcPac"
        '
        'Rdo_MainteOthersSaleMainte
        '
        Me.Rdo_MainteOthersSaleMainte.Location = New System.Drawing.Point(13, 38)
        Me.Rdo_MainteOthersSaleMainte.Margin = New System.Windows.Forms.Padding(2)
        Me.Rdo_MainteOthersSaleMainte.Name = "Rdo_MainteOthersSaleMainte"
        Me.Rdo_MainteOthersSaleMainte.Size = New System.Drawing.Size(164, 19)
        Me.Rdo_MainteOthersSaleMainte.TabIndex = 1
        Me.Rdo_MainteOthersSaleMainte.Text = "����+�ێ�"
        '
        'Rdo_MainteOthersSale
        '
        Me.Rdo_MainteOthersSale.Checked = True
        Me.Rdo_MainteOthersSale.Location = New System.Drawing.Point(13, 18)
        Me.Rdo_MainteOthersSale.Margin = New System.Windows.Forms.Padding(2)
        Me.Rdo_MainteOthersSale.Name = "Rdo_MainteOthersSale"
        Me.Rdo_MainteOthersSale.Size = New System.Drawing.Size(164, 21)
        Me.Rdo_MainteOthersSale.TabIndex = 0
        Me.Rdo_MainteOthersSale.TabStop = True
        Me.Rdo_MainteOthersSale.Text = "�����̂�"
        '
        'Grp_MainteTime
        '
        Me.Grp_MainteTime.Controls.Add(Me.Rdo_MainteTimeMonSun24h)
        Me.Grp_MainteTime.Controls.Add(Me.Rdo_MainteTimeMonSun18h)
        Me.Grp_MainteTime.Controls.Add(Me.Rdo_MainteTimeMonSun12h)
        Me.Grp_MainteTime.Controls.Add(Me.Rdo_MainteTimeMonSat12h)
        Me.Grp_MainteTime.Location = New System.Drawing.Point(418, 462)
        Me.Grp_MainteTime.Margin = New System.Windows.Forms.Padding(2)
        Me.Grp_MainteTime.Name = "Grp_MainteTime"
        Me.Grp_MainteTime.Padding = New System.Windows.Forms.Padding(2)
        Me.Grp_MainteTime.Size = New System.Drawing.Size(166, 104)
        Me.Grp_MainteTime.TabIndex = 8
        Me.Grp_MainteTime.TabStop = False
        Me.Grp_MainteTime.Text = "�ێ玞�ԑ�"
        '
        'Rdo_MainteTimeMonSun24h
        '
        Me.Rdo_MainteTimeMonSun24h.Location = New System.Drawing.Point(13, 78)
        Me.Rdo_MainteTimeMonSun24h.Margin = New System.Windows.Forms.Padding(2)
        Me.Rdo_MainteTimeMonSun24h.Name = "Rdo_MainteTimeMonSun24h"
        Me.Rdo_MainteTimeMonSun24h.Size = New System.Drawing.Size(107, 19)
        Me.Rdo_MainteTimeMonSun24h.TabIndex = 3
        Me.Rdo_MainteTimeMonSun24h.Text = "��-��24H"
        '
        'Rdo_MainteTimeMonSun18h
        '
        Me.Rdo_MainteTimeMonSun18h.Location = New System.Drawing.Point(13, 58)
        Me.Rdo_MainteTimeMonSun18h.Margin = New System.Windows.Forms.Padding(2)
        Me.Rdo_MainteTimeMonSun18h.Name = "Rdo_MainteTimeMonSun18h"
        Me.Rdo_MainteTimeMonSun18h.Size = New System.Drawing.Size(107, 21)
        Me.Rdo_MainteTimeMonSun18h.TabIndex = 2
        Me.Rdo_MainteTimeMonSun18h.Text = "��-��18H"
        '
        'Rdo_MainteTimeMonSun12h
        '
        Me.Rdo_MainteTimeMonSun12h.Location = New System.Drawing.Point(13, 38)
        Me.Rdo_MainteTimeMonSun12h.Margin = New System.Windows.Forms.Padding(2)
        Me.Rdo_MainteTimeMonSun12h.Name = "Rdo_MainteTimeMonSun12h"
        Me.Rdo_MainteTimeMonSun12h.Size = New System.Drawing.Size(107, 19)
        Me.Rdo_MainteTimeMonSun12h.TabIndex = 1
        Me.Rdo_MainteTimeMonSun12h.Text = "��-��12H"
        '
        'Rdo_MainteTimeMonSat12h
        '
        Me.Rdo_MainteTimeMonSat12h.Checked = True
        Me.Rdo_MainteTimeMonSat12h.Location = New System.Drawing.Point(13, 18)
        Me.Rdo_MainteTimeMonSat12h.Margin = New System.Windows.Forms.Padding(2)
        Me.Rdo_MainteTimeMonSat12h.Name = "Rdo_MainteTimeMonSat12h"
        Me.Rdo_MainteTimeMonSat12h.Size = New System.Drawing.Size(107, 21)
        Me.Rdo_MainteTimeMonSat12h.TabIndex = 0
        Me.Rdo_MainteTimeMonSat12h.TabStop = True
        Me.Rdo_MainteTimeMonSat12h.Text = "��-�y12H"
        '
        'Grp_MainteAmount
        '
        Me.Grp_MainteAmount.Controls.Add(Me.Rdo_MainteAmountAnnual)
        Me.Grp_MainteAmount.Controls.Add(Me.Rdo_MainteAmountMonthly)
        Me.Grp_MainteAmount.Location = New System.Drawing.Point(242, 462)
        Me.Grp_MainteAmount.Margin = New System.Windows.Forms.Padding(2)
        Me.Grp_MainteAmount.Name = "Grp_MainteAmount"
        Me.Grp_MainteAmount.Padding = New System.Windows.Forms.Padding(2)
        Me.Grp_MainteAmount.Size = New System.Drawing.Size(152, 48)
        Me.Grp_MainteAmount.TabIndex = 7
        Me.Grp_MainteAmount.TabStop = False
        Me.Grp_MainteAmount.Text = "�ێ���z"
        '
        'Rdo_MainteAmountAnnual
        '
        Me.Rdo_MainteAmountAnnual.Location = New System.Drawing.Point(84, 18)
        Me.Rdo_MainteAmountAnnual.Margin = New System.Windows.Forms.Padding(2)
        Me.Rdo_MainteAmountAnnual.Name = "Rdo_MainteAmountAnnual"
        Me.Rdo_MainteAmountAnnual.Size = New System.Drawing.Size(55, 21)
        Me.Rdo_MainteAmountAnnual.TabIndex = 1
        Me.Rdo_MainteAmountAnnual.Text = "�N�z"
        '
        'Rdo_MainteAmountMonthly
        '
        Me.Rdo_MainteAmountMonthly.Checked = True
        Me.Rdo_MainteAmountMonthly.Location = New System.Drawing.Point(13, 18)
        Me.Rdo_MainteAmountMonthly.Margin = New System.Windows.Forms.Padding(2)
        Me.Rdo_MainteAmountMonthly.Name = "Rdo_MainteAmountMonthly"
        Me.Rdo_MainteAmountMonthly.Size = New System.Drawing.Size(58, 21)
        Me.Rdo_MainteAmountMonthly.TabIndex = 0
        Me.Rdo_MainteAmountMonthly.TabStop = True
        Me.Rdo_MainteAmountMonthly.Text = "���z"
        '
        'Tab_Main
        '
        Me.Tab_Main.Controls.Add(Me.Tab_X)
        Me.Tab_Main.Controls.Add(Me.Tab_Iasc)
        Me.Tab_Main.Controls.Add(Me.Tab_Pa)
        Me.Tab_Main.Controls.Add(Me.Tab_zSW)
        Me.Tab_Main.Controls.Add(Me.Tab_Cisco)
        Me.Tab_Main.Controls.Add(Me.TabPage4)
        Me.Tab_Main.Controls.Add(Me.TabPage5)
        Me.Tab_Main.Location = New System.Drawing.Point(596, 166)
        Me.Tab_Main.Margin = New System.Windows.Forms.Padding(2)
        Me.Tab_Main.Multiline = True
        Me.Tab_Main.Name = "Tab_Main"
        Me.Tab_Main.SelectedIndex = 0
        Me.Tab_Main.Size = New System.Drawing.Size(336, 424)
        Me.Tab_Main.TabIndex = 12
        '
        'Tab_X
        '
        Me.Tab_X.BackColor = System.Drawing.SystemColors.Control
        Me.Tab_X.Controls.Add(Me.GroupBox9)
        Me.Tab_X.Controls.Add(Me.GroupBox1)
        Me.Tab_X.Location = New System.Drawing.Point(4, 22)
        Me.Tab_X.Margin = New System.Windows.Forms.Padding(2)
        Me.Tab_X.Name = "Tab_X"
        Me.Tab_X.Size = New System.Drawing.Size(328, 398)
        Me.Tab_X.TabIndex = 4
        Me.Tab_X.Text = "QCOS"
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.Rdo_x_DescriptionTarget_Master)
        Me.GroupBox9.Controls.Add(Me.Rdo_x_DescriptionTarget_mdb)
        Me.GroupBox9.Controls.Add(Me.Rdo_x_DescriptionTarget_eBs)
        Me.GroupBox9.Location = New System.Drawing.Point(10, 185)
        Me.GroupBox9.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox9.Size = New System.Drawing.Size(113, 59)
        Me.GroupBox9.TabIndex = 22
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "���i�ް��擾��"
        '
        'Rdo_x_DescriptionTarget_Master
        '
        Me.Rdo_x_DescriptionTarget_Master.Checked = True
        Me.Rdo_x_DescriptionTarget_Master.Location = New System.Drawing.Point(10, 36)
        Me.Rdo_x_DescriptionTarget_Master.Margin = New System.Windows.Forms.Padding(2)
        Me.Rdo_x_DescriptionTarget_Master.Name = "Rdo_x_DescriptionTarget_Master"
        Me.Rdo_x_DescriptionTarget_Master.Size = New System.Drawing.Size(92, 20)
        Me.Rdo_x_DescriptionTarget_Master.TabIndex = 2
        Me.Rdo_x_DescriptionTarget_Master.TabStop = True
        Me.Rdo_x_DescriptionTarget_Master.Text = "���iϽ�"
        '
        'Rdo_x_DescriptionTarget_mdb
        '
        Me.Rdo_x_DescriptionTarget_mdb.Enabled = False
        Me.Rdo_x_DescriptionTarget_mdb.Location = New System.Drawing.Point(13, 78)
        Me.Rdo_x_DescriptionTarget_mdb.Margin = New System.Windows.Forms.Padding(2)
        Me.Rdo_x_DescriptionTarget_mdb.Name = "Rdo_x_DescriptionTarget_mdb"
        Me.Rdo_x_DescriptionTarget_mdb.Size = New System.Drawing.Size(92, 19)
        Me.Rdo_x_DescriptionTarget_mdb.TabIndex = 1
        Me.Rdo_x_DescriptionTarget_mdb.Text = "�X�y�b�N����"
        Me.Rdo_x_DescriptionTarget_mdb.Visible = False
        '
        'Rdo_x_DescriptionTarget_eBs
        '
        Me.Rdo_x_DescriptionTarget_eBs.Location = New System.Drawing.Point(13, 16)
        Me.Rdo_x_DescriptionTarget_eBs.Margin = New System.Windows.Forms.Padding(2)
        Me.Rdo_x_DescriptionTarget_eBs.Name = "Rdo_x_DescriptionTarget_eBs"
        Me.Rdo_x_DescriptionTarget_eBs.Size = New System.Drawing.Size(92, 20)
        Me.Rdo_x_DescriptionTarget_eBs.TabIndex = 0
        Me.Rdo_x_DescriptionTarget_eBs.Text = "e-BS"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Btn_X_SelectRelationFile)
        Me.GroupBox1.Controls.Add(Me.Btn_Clear_X)
        Me.GroupBox1.Controls.Add(Me.Lst_File_X)
        Me.GroupBox1.Controls.Add(Me.Btn_Ref_X)
        Me.GroupBox1.Location = New System.Drawing.Point(10, 8)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Size = New System.Drawing.Size(307, 164)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "�Ǎ��t�@�C���w��"
        '
        'Btn_X_SelectRelationFile
        '
        Me.Btn_X_SelectRelationFile.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_X_SelectRelationFile.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_X_SelectRelationFile.ForeColor = System.Drawing.Color.White
        Me.Btn_X_SelectRelationFile.Location = New System.Drawing.Point(130, 124)
        Me.Btn_X_SelectRelationFile.Margin = New System.Windows.Forms.Padding(2)
        Me.Btn_X_SelectRelationFile.Name = "Btn_X_SelectRelationFile"
        Me.Btn_X_SelectRelationFile.Size = New System.Drawing.Size(75, 32)
        Me.Btn_X_SelectRelationFile.TabIndex = 2
        Me.Btn_X_SelectRelationFile.Text = "�֘A�t�@�C���w��"
        Me.Btn_X_SelectRelationFile.UseVisualStyleBackColor = False
        '
        'Btn_Clear_X
        '
        Me.Btn_Clear_X.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Clear_X.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Clear_X.ForeColor = System.Drawing.Color.White
        Me.Btn_Clear_X.Location = New System.Drawing.Point(214, 124)
        Me.Btn_Clear_X.Margin = New System.Windows.Forms.Padding(2)
        Me.Btn_Clear_X.Name = "Btn_Clear_X"
        Me.Btn_Clear_X.Size = New System.Drawing.Size(75, 32)
        Me.Btn_Clear_X.TabIndex = 3
        Me.Btn_Clear_X.Text = "�N���A"
        Me.Btn_Clear_X.UseVisualStyleBackColor = False
        '
        'Lst_File_X
        '
        Me.Lst_File_X.HorizontalScrollbar = True
        Me.Lst_File_X.ItemHeight = 12
        Me.Lst_File_X.Location = New System.Drawing.Point(15, 20)
        Me.Lst_File_X.Margin = New System.Windows.Forms.Padding(2)
        Me.Lst_File_X.Name = "Lst_File_X"
        Me.Lst_File_X.Size = New System.Drawing.Size(276, 88)
        Me.Lst_File_X.TabIndex = 0
        '
        'Btn_Ref_X
        '
        Me.Btn_Ref_X.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Ref_X.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Ref_X.ForeColor = System.Drawing.Color.White
        Me.Btn_Ref_X.Location = New System.Drawing.Point(46, 124)
        Me.Btn_Ref_X.Margin = New System.Windows.Forms.Padding(2)
        Me.Btn_Ref_X.Name = "Btn_Ref_X"
        Me.Btn_Ref_X.Size = New System.Drawing.Size(75, 32)
        Me.Btn_Ref_X.TabIndex = 1
        Me.Btn_Ref_X.Text = "�Q��"
        Me.Btn_Ref_X.UseVisualStyleBackColor = False
        '
        'Tab_Iasc
        '
        Me.Tab_Iasc.Controls.Add(Me.Label15)
        Me.Tab_Iasc.Controls.Add(Me.Label20)
        Me.Tab_Iasc.Controls.Add(Me.Label11)
        Me.Tab_Iasc.Controls.Add(Me.Txt_Iasc_InputData)
        Me.Tab_Iasc.Controls.Add(Me.Label14)
        Me.Tab_Iasc.Location = New System.Drawing.Point(4, 22)
        Me.Tab_Iasc.Margin = New System.Windows.Forms.Padding(2)
        Me.Tab_Iasc.Name = "Tab_Iasc"
        Me.Tab_Iasc.Size = New System.Drawing.Size(328, 398)
        Me.Tab_Iasc.TabIndex = 7
        Me.Tab_Iasc.Text = "VLS"
        '
        'Label15
        '
        Me.Label15.BackColor = System.Drawing.SystemColors.Control
        Me.Label15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label15.Location = New System.Drawing.Point(21, 16)
        Me.Label15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(71, 20)
        Me.Label15.TabIndex = 77
        Me.Label15.Text = "���i�ԍ�"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label20
        '
        Me.Label20.BackColor = System.Drawing.SystemColors.Control
        Me.Label20.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label20.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label20.Location = New System.Drawing.Point(226, 16)
        Me.Label20.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(63, 20)
        Me.Label20.TabIndex = 80
        Me.Label20.Text = "������"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.SystemColors.Control
        Me.Label11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label11.Location = New System.Drawing.Point(92, 16)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(101, 20)
        Me.Label11.TabIndex = 79
        Me.Label11.Text = "�V�X�e����"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Txt_Iasc_InputData
        '
        Me.Txt_Iasc_InputData.Location = New System.Drawing.Point(21, 36)
        Me.Txt_Iasc_InputData.Margin = New System.Windows.Forms.Padding(2)
        Me.Txt_Iasc_InputData.Multiline = True
        Me.Txt_Iasc_InputData.Name = "Txt_Iasc_InputData"
        Me.Txt_Iasc_InputData.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Txt_Iasc_InputData.Size = New System.Drawing.Size(287, 341)
        Me.Txt_Iasc_InputData.TabIndex = 76
        Me.Txt_Iasc_InputData.WordWrap = False
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.SystemColors.Control
        Me.Label14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label14.Location = New System.Drawing.Point(194, 16)
        Me.Label14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(33, 20)
        Me.Label14.TabIndex = 78
        Me.Label14.Text = "����"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Tab_Pa
        '
        Me.Tab_Pa.Controls.Add(Me.Cmb_ChargeLevel)
        Me.Tab_Pa.Controls.Add(Me.Txt_Pa_NO)
        Me.Tab_Pa.Controls.Add(Me.Label1)
        Me.Tab_Pa.Controls.Add(Me.Label5)
        Me.Tab_Pa.Controls.Add(Me.Label6)
        Me.Tab_Pa.Controls.Add(Me.TabControl1)
        Me.Tab_Pa.Controls.Add(Me.Cmb_Pa_Anniversary)
        Me.Tab_Pa.Location = New System.Drawing.Point(4, 22)
        Me.Tab_Pa.Margin = New System.Windows.Forms.Padding(2)
        Me.Tab_Pa.Name = "Tab_Pa"
        Me.Tab_Pa.Size = New System.Drawing.Size(328, 398)
        Me.Tab_Pa.TabIndex = 6
        Me.Tab_Pa.Text = "PA"
        '
        'Cmb_ChargeLevel
        '
        Me.Cmb_ChargeLevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_ChargeLevel.ItemHeight = 12
        Me.Cmb_ChargeLevel.Location = New System.Drawing.Point(142, 15)
        Me.Cmb_ChargeLevel.Margin = New System.Windows.Forms.Padding(2)
        Me.Cmb_ChargeLevel.Name = "Cmb_ChargeLevel"
        Me.Cmb_ChargeLevel.Size = New System.Drawing.Size(60, 20)
        Me.Cmb_ChargeLevel.TabIndex = 73
        '
        'Txt_Pa_NO
        '
        Me.Txt_Pa_NO.Location = New System.Drawing.Point(142, 64)
        Me.Txt_Pa_NO.Margin = New System.Windows.Forms.Padding(2)
        Me.Txt_Pa_NO.Name = "Txt_Pa_NO"
        Me.Txt_Pa_NO.Size = New System.Drawing.Size(169, 19)
        Me.Txt_Pa_NO.TabIndex = 68
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(21, 40)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(118, 20)
        Me.Label1.TabIndex = 72
        Me.Label1.Text = "�A�j�o�[�T���[�E�f�[�g"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(21, 16)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(118, 20)
        Me.Label5.TabIndex = 71
        Me.Label5.Text = "�������x��"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(21, 64)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(118, 20)
        Me.Label6.TabIndex = 70
        Me.Label6.Text = "PA�ԍ�"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.ItemSize = New System.Drawing.Size(0, 17)
        Me.TabControl1.Location = New System.Drawing.Point(16, 89)
        Me.TabControl1.Margin = New System.Windows.Forms.Padding(2)
        Me.TabControl1.Multiline = True
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(294, 287)
        Me.TabControl1.TabIndex = 66
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.SystemColors.Control
        Me.TabPage2.Controls.Add(Me.Label7)
        Me.TabPage2.Controls.Add(Me.Label4)
        Me.TabPage2.Controls.Add(Me.Label3)
        Me.TabPage2.Controls.Add(Me.Txt_Pa_InputData1)
        Me.TabPage2.Location = New System.Drawing.Point(4, 21)
        Me.TabPage2.Margin = New System.Windows.Forms.Padding(2)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Size = New System.Drawing.Size(286, 262)
        Me.TabPage2.TabIndex = 5
        Me.TabPage2.Text = "�p�^�[��1"
        Me.TabPage2.Visible = False
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.SystemColors.Control
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label7.Location = New System.Drawing.Point(88, 14)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(113, 19)
        Me.Label7.TabIndex = 79
        Me.Label7.Text = "�V�X�e����"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label4.Location = New System.Drawing.Point(202, 14)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(46, 19)
        Me.Label4.TabIndex = 78
        Me.Label4.Text = "����"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label3.Location = New System.Drawing.Point(16, 14)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(72, 19)
        Me.Label3.TabIndex = 77
        Me.Label3.Text = "���i�ԍ�"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Txt_Pa_InputData1
        '
        Me.Txt_Pa_InputData1.Location = New System.Drawing.Point(16, 36)
        Me.Txt_Pa_InputData1.Margin = New System.Windows.Forms.Padding(2)
        Me.Txt_Pa_InputData1.Multiline = True
        Me.Txt_Pa_InputData1.Name = "Txt_Pa_InputData1"
        Me.Txt_Pa_InputData1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Txt_Pa_InputData1.Size = New System.Drawing.Size(253, 211)
        Me.Txt_Pa_InputData1.TabIndex = 76
        Me.Txt_Pa_InputData1.WordWrap = False
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.Label8)
        Me.TabPage3.Controls.Add(Me.Label9)
        Me.TabPage3.Controls.Add(Me.Label10)
        Me.TabPage3.Controls.Add(Me.Txt_Pa_InputData2)
        Me.TabPage3.Location = New System.Drawing.Point(4, 21)
        Me.TabPage3.Margin = New System.Windows.Forms.Padding(2)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(286, 262)
        Me.TabPage3.TabIndex = 6
        Me.TabPage3.Text = "�p�^�[��2"
        Me.TabPage3.Visible = False
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.SystemColors.Control
        Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label8.Location = New System.Drawing.Point(134, 14)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(113, 19)
        Me.Label8.TabIndex = 83
        Me.Label8.Text = "�V�X�e����"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.SystemColors.Control
        Me.Label9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label9.Location = New System.Drawing.Point(88, 14)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(46, 19)
        Me.Label9.TabIndex = 82
        Me.Label9.Text = "����"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.SystemColors.Control
        Me.Label10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label10.Location = New System.Drawing.Point(16, 14)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(72, 19)
        Me.Label10.TabIndex = 81
        Me.Label10.Text = "���i�ԍ�"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Txt_Pa_InputData2
        '
        Me.Txt_Pa_InputData2.Location = New System.Drawing.Point(16, 36)
        Me.Txt_Pa_InputData2.Margin = New System.Windows.Forms.Padding(2)
        Me.Txt_Pa_InputData2.Multiline = True
        Me.Txt_Pa_InputData2.Name = "Txt_Pa_InputData2"
        Me.Txt_Pa_InputData2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Txt_Pa_InputData2.Size = New System.Drawing.Size(253, 211)
        Me.Txt_Pa_InputData2.TabIndex = 80
        Me.Txt_Pa_InputData2.WordWrap = False
        '
        'Cmb_Pa_Anniversary
        '
        Me.Cmb_Pa_Anniversary.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Pa_Anniversary.ItemHeight = 12
        Me.Cmb_Pa_Anniversary.Location = New System.Drawing.Point(142, 40)
        Me.Cmb_Pa_Anniversary.Margin = New System.Windows.Forms.Padding(2)
        Me.Cmb_Pa_Anniversary.Name = "Cmb_Pa_Anniversary"
        Me.Cmb_Pa_Anniversary.Size = New System.Drawing.Size(60, 20)
        Me.Cmb_Pa_Anniversary.TabIndex = 72
        '
        'Tab_zSW
        '
        Me.Tab_zSW.BackColor = System.Drawing.SystemColors.Control
        Me.Tab_zSW.Controls.Add(Me.GroupBox7)
        Me.Tab_zSW.Location = New System.Drawing.Point(4, 22)
        Me.Tab_zSW.Margin = New System.Windows.Forms.Padding(2)
        Me.Tab_zSW.Name = "Tab_zSW"
        Me.Tab_zSW.Size = New System.Drawing.Size(328, 398)
        Me.Tab_zSW.TabIndex = 5
        Me.Tab_zSW.Text = "zSW"
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.chkzSwNoChange)
        Me.GroupBox7.Controls.Add(Me.Btn_Clear_Zsw)
        Me.GroupBox7.Controls.Add(Me.Lst_File_Zsw)
        Me.GroupBox7.Controls.Add(Me.Btn_Ref_Zsw)
        Me.GroupBox7.Location = New System.Drawing.Point(10, 8)
        Me.GroupBox7.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox7.Size = New System.Drawing.Size(307, 164)
        Me.GroupBox7.TabIndex = 5
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "�Ǎ��t�@�C���w��"
        '
        'chkzSwNoChange
        '
        Me.chkzSwNoChange.AutoSize = True
        Me.chkzSwNoChange.Location = New System.Drawing.Point(15, 133)
        Me.chkzSwNoChange.Margin = New System.Windows.Forms.Padding(2)
        Me.chkzSwNoChange.Name = "chkzSwNoChange"
        Me.chkzSwNoChange.Size = New System.Drawing.Size(84, 16)
        Me.chkzSwNoChange.TabIndex = 4
        Me.chkzSwNoChange.Text = "�ύX���捞"
        Me.chkzSwNoChange.UseVisualStyleBackColor = True
        '
        'Btn_Clear_Zsw
        '
        Me.Btn_Clear_Zsw.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Clear_Zsw.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Clear_Zsw.ForeColor = System.Drawing.Color.White
        Me.Btn_Clear_Zsw.Location = New System.Drawing.Point(214, 124)
        Me.Btn_Clear_Zsw.Margin = New System.Windows.Forms.Padding(2)
        Me.Btn_Clear_Zsw.Name = "Btn_Clear_Zsw"
        Me.Btn_Clear_Zsw.Size = New System.Drawing.Size(75, 32)
        Me.Btn_Clear_Zsw.TabIndex = 3
        Me.Btn_Clear_Zsw.Text = "�N���A"
        Me.Btn_Clear_Zsw.UseVisualStyleBackColor = False
        '
        'Lst_File_Zsw
        '
        Me.Lst_File_Zsw.HorizontalScrollbar = True
        Me.Lst_File_Zsw.ItemHeight = 12
        Me.Lst_File_Zsw.Location = New System.Drawing.Point(15, 20)
        Me.Lst_File_Zsw.Margin = New System.Windows.Forms.Padding(2)
        Me.Lst_File_Zsw.Name = "Lst_File_Zsw"
        Me.Lst_File_Zsw.Size = New System.Drawing.Size(276, 88)
        Me.Lst_File_Zsw.TabIndex = 0
        '
        'Btn_Ref_Zsw
        '
        Me.Btn_Ref_Zsw.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Ref_Zsw.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Ref_Zsw.ForeColor = System.Drawing.Color.White
        Me.Btn_Ref_Zsw.Location = New System.Drawing.Point(130, 124)
        Me.Btn_Ref_Zsw.Margin = New System.Windows.Forms.Padding(2)
        Me.Btn_Ref_Zsw.Name = "Btn_Ref_Zsw"
        Me.Btn_Ref_Zsw.Size = New System.Drawing.Size(75, 32)
        Me.Btn_Ref_Zsw.TabIndex = 1
        Me.Btn_Ref_Zsw.Text = "�Q��"
        Me.Btn_Ref_Zsw.UseVisualStyleBackColor = False
        '
        'Tab_Cisco
        '
        Me.Tab_Cisco.Controls.Add(Me.GroupBox2)
        Me.Tab_Cisco.Location = New System.Drawing.Point(4, 22)
        Me.Tab_Cisco.Margin = New System.Windows.Forms.Padding(2)
        Me.Tab_Cisco.Name = "Tab_Cisco"
        Me.Tab_Cisco.Size = New System.Drawing.Size(328, 398)
        Me.Tab_Cisco.TabIndex = 8
        Me.Tab_Cisco.Text = "CISCO"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Btn_Clear_Cisco)
        Me.GroupBox2.Controls.Add(Me.Lst_File_Cisco)
        Me.GroupBox2.Controls.Add(Me.Btn_Ref_Cisco)
        Me.GroupBox2.Location = New System.Drawing.Point(10, 8)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Size = New System.Drawing.Size(307, 164)
        Me.GroupBox2.TabIndex = 5
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "�Ǎ��t�@�C���w��"
        '
        'Btn_Clear_Cisco
        '
        Me.Btn_Clear_Cisco.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Clear_Cisco.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Clear_Cisco.ForeColor = System.Drawing.Color.White
        Me.Btn_Clear_Cisco.Location = New System.Drawing.Point(214, 124)
        Me.Btn_Clear_Cisco.Margin = New System.Windows.Forms.Padding(2)
        Me.Btn_Clear_Cisco.Name = "Btn_Clear_Cisco"
        Me.Btn_Clear_Cisco.Size = New System.Drawing.Size(75, 32)
        Me.Btn_Clear_Cisco.TabIndex = 3
        Me.Btn_Clear_Cisco.Text = "�N���A"
        Me.Btn_Clear_Cisco.UseVisualStyleBackColor = False
        '
        'Lst_File_Cisco
        '
        Me.Lst_File_Cisco.HorizontalScrollbar = True
        Me.Lst_File_Cisco.ItemHeight = 12
        Me.Lst_File_Cisco.Location = New System.Drawing.Point(15, 20)
        Me.Lst_File_Cisco.Margin = New System.Windows.Forms.Padding(2)
        Me.Lst_File_Cisco.Name = "Lst_File_Cisco"
        Me.Lst_File_Cisco.Size = New System.Drawing.Size(276, 88)
        Me.Lst_File_Cisco.TabIndex = 0
        '
        'Btn_Ref_Cisco
        '
        Me.Btn_Ref_Cisco.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Ref_Cisco.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Ref_Cisco.ForeColor = System.Drawing.Color.White
        Me.Btn_Ref_Cisco.Location = New System.Drawing.Point(130, 124)
        Me.Btn_Ref_Cisco.Margin = New System.Windows.Forms.Padding(2)
        Me.Btn_Ref_Cisco.Name = "Btn_Ref_Cisco"
        Me.Btn_Ref_Cisco.Size = New System.Drawing.Size(75, 32)
        Me.Btn_Ref_Cisco.TabIndex = 1
        Me.Btn_Ref_Cisco.Text = "�Q��"
        Me.Btn_Ref_Cisco.UseVisualStyleBackColor = False
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.GroupBox12)
        Me.TabPage4.Controls.Add(Me.GroupBox6)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Margin = New System.Windows.Forms.Padding(2)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(2)
        Me.TabPage4.Size = New System.Drawing.Size(328, 398)
        Me.TabPage4.TabIndex = 10
        Me.TabPage4.Text = "MVMS"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'GroupBox12
        '
        Me.GroupBox12.Controls.Add(Me.Rdo_Mvms_Display)
        Me.GroupBox12.Controls.Add(Me.Rdo_Mvms_Notes)
        Me.GroupBox12.Location = New System.Drawing.Point(10, 11)
        Me.GroupBox12.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox12.Name = "GroupBox12"
        Me.GroupBox12.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox12.Size = New System.Drawing.Size(307, 46)
        Me.GroupBox12.TabIndex = 9
        Me.GroupBox12.TabStop = False
        Me.GroupBox12.Text = "�o�ׁE�����N���@�擾"
        '
        'Rdo_Mvms_Display
        '
        Me.Rdo_Mvms_Display.AutoSize = True
        Me.Rdo_Mvms_Display.Location = New System.Drawing.Point(107, 22)
        Me.Rdo_Mvms_Display.Margin = New System.Windows.Forms.Padding(2)
        Me.Rdo_Mvms_Display.Name = "Rdo_Mvms_Display"
        Me.Rdo_Mvms_Display.Size = New System.Drawing.Size(47, 16)
        Me.Rdo_Mvms_Display.TabIndex = 1
        Me.Rdo_Mvms_Display.Text = "���"
        Me.Rdo_Mvms_Display.UseVisualStyleBackColor = True
        '
        'Rdo_Mvms_Notes
        '
        Me.Rdo_Mvms_Notes.AutoSize = True
        Me.Rdo_Mvms_Notes.Checked = True
        Me.Rdo_Mvms_Notes.Location = New System.Drawing.Point(15, 22)
        Me.Rdo_Mvms_Notes.Margin = New System.Windows.Forms.Padding(2)
        Me.Rdo_Mvms_Notes.Name = "Rdo_Mvms_Notes"
        Me.Rdo_Mvms_Notes.Size = New System.Drawing.Size(53, 16)
        Me.Rdo_Mvms_Notes.TabIndex = 0
        Me.Rdo_Mvms_Notes.TabStop = True
        Me.Rdo_Mvms_Notes.Text = "Notes"
        Me.Rdo_Mvms_Notes.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.Txt_Mvms_InputData)
        Me.GroupBox6.Location = New System.Drawing.Point(10, 71)
        Me.GroupBox6.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox6.Size = New System.Drawing.Size(307, 298)
        Me.GroupBox6.TabIndex = 8
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Notes��̈Č��ԍ�"
        '
        'Txt_Mvms_InputData
        '
        Me.Txt_Mvms_InputData.Location = New System.Drawing.Point(19, 17)
        Me.Txt_Mvms_InputData.Margin = New System.Windows.Forms.Padding(2)
        Me.Txt_Mvms_InputData.Multiline = True
        Me.Txt_Mvms_InputData.Name = "Txt_Mvms_InputData"
        Me.Txt_Mvms_InputData.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Txt_Mvms_InputData.Size = New System.Drawing.Size(271, 266)
        Me.Txt_Mvms_InputData.TabIndex = 77
        Me.Txt_Mvms_InputData.WordWrap = False
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.GroupBox8)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Margin = New System.Windows.Forms.Padding(2)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(2)
        Me.TabPage5.Size = New System.Drawing.Size(328, 398)
        Me.TabPage5.TabIndex = 11
        Me.TabPage5.Text = "FMA"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.Btn_Clear_Fma)
        Me.GroupBox8.Controls.Add(Me.Lst_File_Fma)
        Me.GroupBox8.Controls.Add(Me.Btn_Ref_Fma)
        Me.GroupBox8.Location = New System.Drawing.Point(10, 8)
        Me.GroupBox8.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox8.Size = New System.Drawing.Size(307, 164)
        Me.GroupBox8.TabIndex = 6
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "�Ǎ��t�@�C���w��"
        '
        'Btn_Clear_Fma
        '
        Me.Btn_Clear_Fma.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Clear_Fma.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Clear_Fma.ForeColor = System.Drawing.Color.White
        Me.Btn_Clear_Fma.Location = New System.Drawing.Point(214, 124)
        Me.Btn_Clear_Fma.Margin = New System.Windows.Forms.Padding(2)
        Me.Btn_Clear_Fma.Name = "Btn_Clear_Fma"
        Me.Btn_Clear_Fma.Size = New System.Drawing.Size(75, 32)
        Me.Btn_Clear_Fma.TabIndex = 3
        Me.Btn_Clear_Fma.Text = "�N���A"
        Me.Btn_Clear_Fma.UseVisualStyleBackColor = False
        '
        'Lst_File_Fma
        '
        Me.Lst_File_Fma.HorizontalScrollbar = True
        Me.Lst_File_Fma.ItemHeight = 12
        Me.Lst_File_Fma.Location = New System.Drawing.Point(15, 20)
        Me.Lst_File_Fma.Margin = New System.Windows.Forms.Padding(2)
        Me.Lst_File_Fma.Name = "Lst_File_Fma"
        Me.Lst_File_Fma.Size = New System.Drawing.Size(276, 88)
        Me.Lst_File_Fma.TabIndex = 0
        '
        'Btn_Ref_Fma
        '
        Me.Btn_Ref_Fma.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Ref_Fma.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Ref_Fma.ForeColor = System.Drawing.Color.White
        Me.Btn_Ref_Fma.Location = New System.Drawing.Point(130, 124)
        Me.Btn_Ref_Fma.Margin = New System.Windows.Forms.Padding(2)
        Me.Btn_Ref_Fma.Name = "Btn_Ref_Fma"
        Me.Btn_Ref_Fma.Size = New System.Drawing.Size(75, 32)
        Me.Btn_Ref_Fma.TabIndex = 1
        Me.Btn_Ref_Fma.Text = "�Q��"
        Me.Btn_Ref_Fma.UseVisualStyleBackColor = False
        '
        'Grp_SvcPacType
        '
        Me.Grp_SvcPacType.Controls.Add(Me.Rdo_SvcTypeBasicSelection)
        Me.Grp_SvcPacType.Controls.Add(Me.Rdo_SvcTypeSuperServicePlus)
        Me.Grp_SvcPacType.Controls.Add(Me.Rdo_SvcTypeRepair)
        Me.Grp_SvcPacType.Location = New System.Drawing.Point(418, 574)
        Me.Grp_SvcPacType.Margin = New System.Windows.Forms.Padding(2)
        Me.Grp_SvcPacType.Name = "Grp_SvcPacType"
        Me.Grp_SvcPacType.Padding = New System.Windows.Forms.Padding(2)
        Me.Grp_SvcPacType.Size = New System.Drawing.Size(166, 88)
        Me.Grp_SvcPacType.TabIndex = 10
        Me.Grp_SvcPacType.TabStop = False
        Me.Grp_SvcPacType.Text = "SVCPAC���"
        '
        'Rdo_SvcTypeBasicSelection
        '
        Me.Rdo_SvcTypeBasicSelection.Location = New System.Drawing.Point(13, 58)
        Me.Rdo_SvcTypeBasicSelection.Margin = New System.Windows.Forms.Padding(2)
        Me.Rdo_SvcTypeBasicSelection.Name = "Rdo_SvcTypeBasicSelection"
        Me.Rdo_SvcTypeBasicSelection.Size = New System.Drawing.Size(147, 21)
        Me.Rdo_SvcTypeBasicSelection.TabIndex = 3
        Me.Rdo_SvcTypeBasicSelection.Text = "�ް����ڸ���(��{)"
        '
        'Rdo_SvcTypeSuperServicePlus
        '
        Me.Rdo_SvcTypeSuperServicePlus.Location = New System.Drawing.Point(13, 38)
        Me.Rdo_SvcTypeSuperServicePlus.Margin = New System.Windows.Forms.Padding(2)
        Me.Rdo_SvcTypeSuperServicePlus.Name = "Rdo_SvcTypeSuperServicePlus"
        Me.Rdo_SvcTypeSuperServicePlus.Size = New System.Drawing.Size(130, 19)
        Me.Rdo_SvcTypeSuperServicePlus.TabIndex = 2
        Me.Rdo_SvcTypeSuperServicePlus.Text = "���߰���޽��׽"
        '
        'Rdo_SvcTypeRepair
        '
        Me.Rdo_SvcTypeRepair.Checked = True
        Me.Rdo_SvcTypeRepair.Location = New System.Drawing.Point(13, 18)
        Me.Rdo_SvcTypeRepair.Margin = New System.Windows.Forms.Padding(2)
        Me.Rdo_SvcTypeRepair.Name = "Rdo_SvcTypeRepair"
        Me.Rdo_SvcTypeRepair.Size = New System.Drawing.Size(130, 21)
        Me.Rdo_SvcTypeRepair.TabIndex = 0
        Me.Rdo_SvcTypeRepair.TabStop = True
        Me.Rdo_SvcTypeRepair.Text = "�ݻ�ďC��"
        '
        'Grp_SvcPacTerm
        '
        Me.Grp_SvcPacTerm.Controls.Add(Me.Rdo_SvcTerm3Years)
        Me.Grp_SvcPacTerm.Controls.Add(Me.Rdo_SvcTerm5Years)
        Me.Grp_SvcPacTerm.Controls.Add(Me.Rdo_SvcTerm4Years)
        Me.Grp_SvcPacTerm.Controls.Add(Me.Rdo_SvcTerm2Years)
        Me.Grp_SvcPacTerm.Controls.Add(Me.Rdo_SvcTerm1Year)
        Me.Grp_SvcPacTerm.Location = New System.Drawing.Point(242, 574)
        Me.Grp_SvcPacTerm.Margin = New System.Windows.Forms.Padding(2)
        Me.Grp_SvcPacTerm.Name = "Grp_SvcPacTerm"
        Me.Grp_SvcPacTerm.Padding = New System.Windows.Forms.Padding(2)
        Me.Grp_SvcPacTerm.Size = New System.Drawing.Size(152, 88)
        Me.Grp_SvcPacTerm.TabIndex = 9
        Me.Grp_SvcPacTerm.TabStop = False
        Me.Grp_SvcPacTerm.Text = "SVCPAC����"
        '
        'Rdo_SvcTerm3Years
        '
        Me.Rdo_SvcTerm3Years.Checked = True
        Me.Rdo_SvcTerm3Years.Location = New System.Drawing.Point(13, 60)
        Me.Rdo_SvcTerm3Years.Margin = New System.Windows.Forms.Padding(2)
        Me.Rdo_SvcTerm3Years.Name = "Rdo_SvcTerm3Years"
        Me.Rdo_SvcTerm3Years.Size = New System.Drawing.Size(58, 20)
        Me.Rdo_SvcTerm3Years.TabIndex = 2
        Me.Rdo_SvcTerm3Years.TabStop = True
        Me.Rdo_SvcTerm3Years.Text = "3�N��"
        '
        'Rdo_SvcTerm5Years
        '
        Me.Rdo_SvcTerm5Years.Location = New System.Drawing.Point(84, 40)
        Me.Rdo_SvcTerm5Years.Margin = New System.Windows.Forms.Padding(2)
        Me.Rdo_SvcTerm5Years.Name = "Rdo_SvcTerm5Years"
        Me.Rdo_SvcTerm5Years.Size = New System.Drawing.Size(58, 20)
        Me.Rdo_SvcTerm5Years.TabIndex = 4
        Me.Rdo_SvcTerm5Years.Text = "5�N��"
        '
        'Rdo_SvcTerm4Years
        '
        Me.Rdo_SvcTerm4Years.Location = New System.Drawing.Point(84, 20)
        Me.Rdo_SvcTerm4Years.Margin = New System.Windows.Forms.Padding(2)
        Me.Rdo_SvcTerm4Years.Name = "Rdo_SvcTerm4Years"
        Me.Rdo_SvcTerm4Years.Size = New System.Drawing.Size(58, 20)
        Me.Rdo_SvcTerm4Years.TabIndex = 3
        Me.Rdo_SvcTerm4Years.Text = "4�N��"
        '
        'Rdo_SvcTerm2Years
        '
        Me.Rdo_SvcTerm2Years.Location = New System.Drawing.Point(13, 40)
        Me.Rdo_SvcTerm2Years.Margin = New System.Windows.Forms.Padding(2)
        Me.Rdo_SvcTerm2Years.Name = "Rdo_SvcTerm2Years"
        Me.Rdo_SvcTerm2Years.Size = New System.Drawing.Size(58, 20)
        Me.Rdo_SvcTerm2Years.TabIndex = 1
        Me.Rdo_SvcTerm2Years.Text = "2�N��"
        '
        'Rdo_SvcTerm1Year
        '
        Me.Rdo_SvcTerm1Year.Location = New System.Drawing.Point(13, 20)
        Me.Rdo_SvcTerm1Year.Margin = New System.Windows.Forms.Padding(2)
        Me.Rdo_SvcTerm1Year.Name = "Rdo_SvcTerm1Year"
        Me.Rdo_SvcTerm1Year.Size = New System.Drawing.Size(58, 20)
        Me.Rdo_SvcTerm1Year.TabIndex = 0
        Me.Rdo_SvcTerm1Year.Text = "1�N��"
        '
        'Dp_StartTime
        '
        Me.Dp_StartTime.CustomFormat = "yyyy�NM��"
        Me.Dp_StartTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dp_StartTime.Location = New System.Drawing.Point(552, 56)
        Me.Dp_StartTime.Margin = New System.Windows.Forms.Padding(2)
        Me.Dp_StartTime.Name = "Dp_StartTime"
        Me.Dp_StartTime.Size = New System.Drawing.Size(98, 19)
        Me.Dp_StartTime.TabIndex = 3
        '
        'Dp_Introduction
        '
        Me.Dp_Introduction.CustomFormat = "yyyy�NM��"
        Me.Dp_Introduction.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dp_Introduction.Location = New System.Drawing.Point(421, 141)
        Me.Dp_Introduction.Margin = New System.Windows.Forms.Padding(2)
        Me.Dp_Introduction.Name = "Dp_Introduction"
        Me.Dp_Introduction.Size = New System.Drawing.Size(98, 19)
        Me.Dp_Introduction.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(456, 60)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(92, 16)
        Me.Label2.TabIndex = 59
        Me.Label2.Text = "OIO���ԊJ�n"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(356, 146)
        Me.Label18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(53, 12)
        Me.Label18.TabIndex = 57
        Me.Label18.Text = "�o�הN��"
        '
        'Dp_EndTime
        '
        Me.Dp_EndTime.CustomFormat = "yyyy�NM��"
        Me.Dp_EndTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dp_EndTime.Location = New System.Drawing.Point(754, 56)
        Me.Dp_EndTime.Margin = New System.Windows.Forms.Padding(2)
        Me.Dp_EndTime.Name = "Dp_EndTime"
        Me.Dp_EndTime.Size = New System.Drawing.Size(98, 19)
        Me.Dp_EndTime.TabIndex = 4
        '
        'Label12
        '
        Me.Label12.Location = New System.Drawing.Point(666, 60)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(84, 16)
        Me.Label12.TabIndex = 62
        Me.Label12.Text = "OIO���ԏI��"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Controls.Add(Me.lblSuffixNo)
        Me.GroupBox3.Controls.Add(Me.Label17)
        Me.GroupBox3.Controls.Add(Me.lblContractName)
        Me.GroupBox3.Controls.Add(Me.lblCPNO)
        Me.GroupBox3.Controls.Add(Me.lblContractNo)
        Me.GroupBox3.Controls.Add(Me.Label19)
        Me.GroupBox3.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(13, 50)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox3.Size = New System.Drawing.Size(920, 86)
        Me.GroupBox3.TabIndex = 265
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "�_����"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label16.Location = New System.Drawing.Point(6, 64)
        Me.Label16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(70, 12)
        Me.Label16.TabIndex = 53
        Me.Label16.Text = "�_�񏇔Ԗ�"
        '
        'lblSuffixNo
        '
        Me.lblSuffixNo.AutoSize = True
        Me.lblSuffixNo.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblSuffixNo.Location = New System.Drawing.Point(140, 78)
        Me.lblSuffixNo.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblSuffixNo.Name = "lblSuffixNo"
        Me.lblSuffixNo.Size = New System.Drawing.Size(0, 12)
        Me.lblSuffixNo.TabIndex = 54
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label17.Location = New System.Drawing.Point(6, 26)
        Me.Label17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(104, 12)
        Me.Label17.TabIndex = 51
        Me.Label17.Text = "���q�l���iCPNO�j"
        '
        'lblContractName
        '
        Me.lblContractName.AutoSize = True
        Me.lblContractName.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblContractName.Location = New System.Drawing.Point(140, 59)
        Me.lblContractName.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblContractName.Name = "lblContractName"
        Me.lblContractName.Size = New System.Drawing.Size(0, 12)
        Me.lblContractName.TabIndex = 54
        '
        'lblCPNO
        '
        Me.lblCPNO.AutoSize = True
        Me.lblCPNO.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblCPNO.Location = New System.Drawing.Point(140, 21)
        Me.lblCPNO.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblCPNO.Name = "lblCPNO"
        Me.lblCPNO.Size = New System.Drawing.Size(0, 12)
        Me.lblCPNO.TabIndex = 52
        '
        'lblContractNo
        '
        Me.lblContractNo.AutoSize = True
        Me.lblContractNo.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblContractNo.Location = New System.Drawing.Point(140, 40)
        Me.lblContractNo.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblContractNo.Name = "lblContractNo"
        Me.lblContractNo.Size = New System.Drawing.Size(0, 12)
        Me.lblContractNo.TabIndex = 54
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label19.Location = New System.Drawing.Point(6, 45)
        Me.Label19.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(57, 12)
        Me.Label19.TabIndex = 53
        Me.Label19.Text = "�_�񏇔�"
        '
        'Dp_PayEnd
        '
        Me.Dp_PayEnd.CustomFormat = "yyyy�NM��"
        Me.Dp_PayEnd.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dp_PayEnd.Location = New System.Drawing.Point(832, 141)
        Me.Dp_PayEnd.Margin = New System.Windows.Forms.Padding(2)
        Me.Dp_PayEnd.Name = "Dp_PayEnd"
        Me.Dp_PayEnd.Size = New System.Drawing.Size(98, 19)
        Me.Dp_PayEnd.TabIndex = 73
        '
        'Label24
        '
        Me.Label24.Location = New System.Drawing.Point(743, 145)
        Me.Label24.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(84, 16)
        Me.Label24.TabIndex = 75
        Me.Label24.Text = "�����N���I��"
        '
        'Dp_PayStart
        '
        Me.Dp_PayStart.CustomFormat = "yyyy�NM��"
        Me.Dp_PayStart.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dp_PayStart.Location = New System.Drawing.Point(630, 141)
        Me.Dp_PayStart.Margin = New System.Windows.Forms.Padding(2)
        Me.Dp_PayStart.Name = "Dp_PayStart"
        Me.Dp_PayStart.Size = New System.Drawing.Size(98, 19)
        Me.Dp_PayStart.TabIndex = 72
        '
        'Label25
        '
        Me.Label25.Location = New System.Drawing.Point(533, 145)
        Me.Label25.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(92, 16)
        Me.Label25.TabIndex = 74
        Me.Label25.Text = "�����N���J�n"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(26, 145)
        Me.Label26.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(53, 12)
        Me.Label26.TabIndex = 266
        Me.Label26.Text = "�Č��ԍ�"
        '
        'lblPlanNo
        '
        Me.lblPlanNo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPlanNo.Location = New System.Drawing.Point(87, 141)
        Me.lblPlanNo.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblPlanNo.Name = "lblPlanNo"
        Me.lblPlanNo.Size = New System.Drawing.Size(252, 19)
        Me.lblPlanNo.TabIndex = 268
        '
        'Grp_MainteSystem
        '
        Me.Grp_MainteSystem.Controls.Add(Me.Rdo_MainteSystemMaps)
        Me.Grp_MainteSystem.Controls.Add(Me.Rdo_MainteSystemChis)
        Me.Grp_MainteSystem.Location = New System.Drawing.Point(242, 517)
        Me.Grp_MainteSystem.Margin = New System.Windows.Forms.Padding(2)
        Me.Grp_MainteSystem.Name = "Grp_MainteSystem"
        Me.Grp_MainteSystem.Padding = New System.Windows.Forms.Padding(2)
        Me.Grp_MainteSystem.Size = New System.Drawing.Size(152, 48)
        Me.Grp_MainteSystem.TabIndex = 9
        Me.Grp_MainteSystem.TabStop = False
        Me.Grp_MainteSystem.Text = "�ێ�V�X�e��"
        '
        'Rdo_MainteSystemMaps
        '
        Me.Rdo_MainteSystemMaps.Location = New System.Drawing.Point(84, 18)
        Me.Rdo_MainteSystemMaps.Margin = New System.Windows.Forms.Padding(2)
        Me.Rdo_MainteSystemMaps.Name = "Rdo_MainteSystemMaps"
        Me.Rdo_MainteSystemMaps.Size = New System.Drawing.Size(64, 21)
        Me.Rdo_MainteSystemMaps.TabIndex = 1
        Me.Rdo_MainteSystemMaps.Text = "MAPS"
        '
        'Rdo_MainteSystemChis
        '
        Me.Rdo_MainteSystemChis.Checked = True
        Me.Rdo_MainteSystemChis.Location = New System.Drawing.Point(13, 18)
        Me.Rdo_MainteSystemChis.Margin = New System.Windows.Forms.Padding(2)
        Me.Rdo_MainteSystemChis.Name = "Rdo_MainteSystemChis"
        Me.Rdo_MainteSystemChis.Size = New System.Drawing.Size(58, 21)
        Me.Rdo_MainteSystemChis.TabIndex = 0
        Me.Rdo_MainteSystemChis.TabStop = True
        Me.Rdo_MainteSystemChis.Text = "CHIS"
        '
        'cmbPlanNO
        '
        Me.cmbPlanNO.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbPlanNO.FormattingEnabled = True
        Me.cmbPlanNO.Location = New System.Drawing.Point(87, 140)
        Me.cmbPlanNO.Margin = New System.Windows.Forms.Padding(2)
        Me.cmbPlanNO.Name = "cmbPlanNO"
        Me.cmbPlanNO.Size = New System.Drawing.Size(253, 20)
        Me.cmbPlanNO.TabIndex = 2
        '
        'GroupBox11
        '
        Me.GroupBox11.Controls.Add(Me.Rdo_AAS_DescriptionTarget_Master)
        Me.GroupBox11.Controls.Add(Me.RadioButton2)
        Me.GroupBox11.Controls.Add(Me.Rdo_AAS_DescriptionTarget_eBs)
        Me.GroupBox11.Location = New System.Drawing.Point(15, 592)
        Me.GroupBox11.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox11.Size = New System.Drawing.Size(113, 59)
        Me.GroupBox11.TabIndex = 23
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "�ێ痿���擾��"
        '
        'Rdo_AAS_DescriptionTarget_Master
        '
        Me.Rdo_AAS_DescriptionTarget_Master.Checked = True
        Me.Rdo_AAS_DescriptionTarget_Master.Location = New System.Drawing.Point(10, 36)
        Me.Rdo_AAS_DescriptionTarget_Master.Margin = New System.Windows.Forms.Padding(2)
        Me.Rdo_AAS_DescriptionTarget_Master.Name = "Rdo_AAS_DescriptionTarget_Master"
        Me.Rdo_AAS_DescriptionTarget_Master.Size = New System.Drawing.Size(92, 20)
        Me.Rdo_AAS_DescriptionTarget_Master.TabIndex = 2
        Me.Rdo_AAS_DescriptionTarget_Master.TabStop = True
        Me.Rdo_AAS_DescriptionTarget_Master.Text = "���iϽ�"
        '
        'RadioButton2
        '
        Me.RadioButton2.Enabled = False
        Me.RadioButton2.Location = New System.Drawing.Point(13, 78)
        Me.RadioButton2.Margin = New System.Windows.Forms.Padding(2)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(92, 19)
        Me.RadioButton2.TabIndex = 1
        Me.RadioButton2.Text = "�X�y�b�N����"
        Me.RadioButton2.Visible = False
        '
        'Rdo_AAS_DescriptionTarget_eBs
        '
        Me.Rdo_AAS_DescriptionTarget_eBs.Location = New System.Drawing.Point(13, 16)
        Me.Rdo_AAS_DescriptionTarget_eBs.Margin = New System.Windows.Forms.Padding(2)
        Me.Rdo_AAS_DescriptionTarget_eBs.Name = "Rdo_AAS_DescriptionTarget_eBs"
        Me.Rdo_AAS_DescriptionTarget_eBs.Size = New System.Drawing.Size(92, 20)
        Me.Rdo_AAS_DescriptionTarget_eBs.TabIndex = 0
        Me.Rdo_AAS_DescriptionTarget_eBs.Text = "e-BS"
        '
        'grpCisco
        '
        Me.grpCisco.Controls.Add(Me.rbBFull)
        Me.grpCisco.Controls.Add(Me.rbBHalf)
        Me.grpCisco.Controls.Add(Me.rbBMid)
        Me.grpCisco.Controls.Add(Me.rbBBase)
        Me.grpCisco.Controls.Add(Me.rbAFull)
        Me.grpCisco.Controls.Add(Me.rbAHalf)
        Me.grpCisco.Controls.Add(Me.rbAMid)
        Me.grpCisco.Controls.Add(Me.rbABase)
        Me.grpCisco.Location = New System.Drawing.Point(242, 460)
        Me.grpCisco.Margin = New System.Windows.Forms.Padding(2)
        Me.grpCisco.Name = "grpCisco"
        Me.grpCisco.Padding = New System.Windows.Forms.Padding(2)
        Me.grpCisco.Size = New System.Drawing.Size(218, 126)
        Me.grpCisco.TabIndex = 269
        Me.grpCisco.TabStop = False
        Me.grpCisco.Text = "CISCO���޽����"
        '
        'rbBFull
        '
        Me.rbBFull.AutoSize = True
        Me.rbBFull.Location = New System.Drawing.Point(118, 90)
        Me.rbBFull.Margin = New System.Windows.Forms.Padding(2)
        Me.rbBFull.Name = "rbBFull"
        Me.rbBFull.Size = New System.Drawing.Size(76, 16)
        Me.rbBFull.TabIndex = 7
        Me.rbBFull.Text = "ESB FULL"
        Me.rbBFull.UseVisualStyleBackColor = True
        '
        'rbBHalf
        '
        Me.rbBHalf.AutoSize = True
        Me.rbBHalf.Location = New System.Drawing.Point(118, 68)
        Me.rbBHalf.Margin = New System.Windows.Forms.Padding(2)
        Me.rbBHalf.Name = "rbBHalf"
        Me.rbBHalf.Size = New System.Drawing.Size(78, 16)
        Me.rbBHalf.TabIndex = 6
        Me.rbBHalf.Text = "ESB HALF"
        Me.rbBHalf.UseVisualStyleBackColor = True
        '
        'rbBMid
        '
        Me.rbBMid.AutoSize = True
        Me.rbBMid.Location = New System.Drawing.Point(118, 44)
        Me.rbBMid.Margin = New System.Windows.Forms.Padding(2)
        Me.rbBMid.Name = "rbBMid"
        Me.rbBMid.Size = New System.Drawing.Size(69, 16)
        Me.rbBMid.TabIndex = 5
        Me.rbBMid.Text = "ESB MID"
        Me.rbBMid.UseVisualStyleBackColor = True
        '
        'rbBBase
        '
        Me.rbBBase.AutoSize = True
        Me.rbBBase.Location = New System.Drawing.Point(118, 22)
        Me.rbBBase.Margin = New System.Windows.Forms.Padding(2)
        Me.rbBBase.Name = "rbBBase"
        Me.rbBBase.Size = New System.Drawing.Size(79, 16)
        Me.rbBBase.TabIndex = 4
        Me.rbBBase.Text = "ESB BASE"
        Me.rbBBase.UseVisualStyleBackColor = True
        '
        'rbAFull
        '
        Me.rbAFull.AutoSize = True
        Me.rbAFull.Location = New System.Drawing.Point(21, 90)
        Me.rbAFull.Margin = New System.Windows.Forms.Padding(2)
        Me.rbAFull.Name = "rbAFull"
        Me.rbAFull.Size = New System.Drawing.Size(76, 16)
        Me.rbAFull.TabIndex = 3
        Me.rbAFull.Text = "ESA FULL"
        Me.rbAFull.UseVisualStyleBackColor = True
        '
        'rbAHalf
        '
        Me.rbAHalf.AutoSize = True
        Me.rbAHalf.Location = New System.Drawing.Point(21, 68)
        Me.rbAHalf.Margin = New System.Windows.Forms.Padding(2)
        Me.rbAHalf.Name = "rbAHalf"
        Me.rbAHalf.Size = New System.Drawing.Size(78, 16)
        Me.rbAHalf.TabIndex = 2
        Me.rbAHalf.Text = "ESA HALF"
        Me.rbAHalf.UseVisualStyleBackColor = True
        '
        'rbAMid
        '
        Me.rbAMid.AutoSize = True
        Me.rbAMid.Location = New System.Drawing.Point(21, 44)
        Me.rbAMid.Margin = New System.Windows.Forms.Padding(2)
        Me.rbAMid.Name = "rbAMid"
        Me.rbAMid.Size = New System.Drawing.Size(69, 16)
        Me.rbAMid.TabIndex = 1
        Me.rbAMid.Text = "ESA MID"
        Me.rbAMid.UseVisualStyleBackColor = True
        '
        'rbABase
        '
        Me.rbABase.AutoSize = True
        Me.rbABase.Checked = True
        Me.rbABase.Location = New System.Drawing.Point(21, 22)
        Me.rbABase.Margin = New System.Windows.Forms.Padding(2)
        Me.rbABase.Name = "rbABase"
        Me.rbABase.Size = New System.Drawing.Size(79, 16)
        Me.rbABase.TabIndex = 0
        Me.rbABase.TabStop = True
        Me.rbABase.Text = "ESA BASE"
        Me.rbABase.UseVisualStyleBackColor = True
        '
        'UCnt_Pal00012
        '
        Me.UCnt_Pal00012.BackColor = System.Drawing.Color.Teal
        Me.UCnt_Pal00012.BackColro2 = System.Drawing.Color.PaleTurquoise
        Me.UCnt_Pal00012.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UCnt_Pal00012.ForeColor = System.Drawing.Color.White
        Me.UCnt_Pal00012.Location = New System.Drawing.Point(0, 0)
        Me.UCnt_Pal00012.Margin = New System.Windows.Forms.Padding(2)
        Me.UCnt_Pal00012.Name = "UCnt_Pal00012"
        Me.UCnt_Pal00012.Size = New System.Drawing.Size(947, 44)
        Me.UCnt_Pal00012.TabIndex = 7
        Me.UCnt_Pal00012.TitleText = "OIO BAMA Client  �\�����Ǎ�"
        '
        'Btn_Close
        '
        Me.Btn_Close.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_Close.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Close.ForeColor = System.Drawing.Color.White
        Me.Btn_Close.Location = New System.Drawing.Point(814, 606)
        Me.Btn_Close.Margin = New System.Windows.Forms.Padding(2)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(118, 43)
        Me.Btn_Close.TabIndex = 23
        Me.Btn_Close.Text = "Cancel"
        Me.Btn_Close.UseVisualStyleBackColor = False
        '
        'Btn_OK
        '
        Me.Btn_OK.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btn_OK.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_OK.ForeColor = System.Drawing.Color.White
        Me.Btn_OK.Location = New System.Drawing.Point(683, 605)
        Me.Btn_OK.Margin = New System.Windows.Forms.Padding(2)
        Me.Btn_OK.Name = "Btn_OK"
        Me.Btn_OK.Size = New System.Drawing.Size(118, 43)
        Me.Btn_OK.TabIndex = 271
        Me.Btn_OK.Text = "OK"
        Me.Btn_OK.UseVisualStyleBackColor = False
        '
        'Grp_IsatDate
        '
        Me.Grp_IsatDate.Controls.Add(Me.Label13)
        Me.Grp_IsatDate.Controls.Add(Me.Rdo_UseIsat)
        Me.Grp_IsatDate.Controls.Add(Me.Rdo_UseClient)
        Me.Grp_IsatDate.Location = New System.Drawing.Point(0, 553)
        Me.Grp_IsatDate.Name = "Grp_IsatDate"
        Me.Grp_IsatDate.Size = New System.Drawing.Size(283, 93)
        Me.Grp_IsatDate.TabIndex = 273
        Me.Grp_IsatDate.TabStop = False
        Me.Grp_IsatDate.Text = "�T�[�r�X�J�n���E�I�����̎擾���@"
        '
        'Rdo_UseIsat
        '
        Me.Rdo_UseIsat.AutoSize = True
        Me.Rdo_UseIsat.Location = New System.Drawing.Point(38, 42)
        Me.Rdo_UseIsat.Name = "Rdo_UseIsat"
        Me.Rdo_UseIsat.Size = New System.Drawing.Size(173, 16)
        Me.Rdo_UseIsat.TabIndex = 1
        Me.Rdo_UseIsat.TabStop = True
        Me.Rdo_UseIsat.Text = "ISAT���σt�@�C���̓��t��D��"
        Me.Rdo_UseIsat.UseVisualStyleBackColor = True
        '
        'Rdo_UseClient
        '
        Me.Rdo_UseClient.AutoSize = True
        Me.Rdo_UseClient.Location = New System.Drawing.Point(38, 20)
        Me.Rdo_UseClient.Name = "Rdo_UseClient"
        Me.Rdo_UseClient.Size = New System.Drawing.Size(120, 16)
        Me.Rdo_UseClient.TabIndex = 0
        Me.Rdo_UseClient.TabStop = True
        Me.Rdo_UseClient.Text = "Client�̓��t��D��"
        Me.Rdo_UseClient.UseVisualStyleBackColor = True
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.HeaderText = "�t�@�C����"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Width = 390
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.HeaderText = "����"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Width = 80
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(52, 61)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(201, 12)
        Me.Label13.TabIndex = 2
        Me.Label13.Text = "�i�N�z�����̃f�[�^�ɂ͑Ή����Ă��܂���j"
        '
        'Frm_Oio_Project
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.AutoSize = True
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(949, 669)
        Me.Controls.Add(Me.Grp_IsatDate)
        Me.Controls.Add(Me.Btn_OK)
        Me.Controls.Add(Me.GroupBox11)
        Me.Controls.Add(Me.cmbPlanNO)
        Me.Controls.Add(Me.Grp_MainteSystem)
        Me.Controls.Add(Me.lblPlanNo)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.Dp_PayEnd)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Dp_PayStart)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Dp_EndTime)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Dp_StartTime)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Grp_SvcPacType)
        Me.Controls.Add(Me.Grp_SvcPacTerm)
        Me.Controls.Add(Me.UCnt_Pal00012)
        Me.Controls.Add(Me.Btn_Close)
        Me.Controls.Add(Me.Tab_Main)
        Me.Controls.Add(Me.Grp_InputFile)
        Me.Controls.Add(Me.Grp_MainteAmount)
        Me.Controls.Add(Me.Grp_MainteOthers)
        Me.Controls.Add(Me.Grp_MainteTime)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Dp_Introduction)
        Me.Controls.Add(Me.grpCisco)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.MaximizeBox = False
        Me.Name = "Frm_Oio_Project"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "OIO BAMA Client"
        Me.Grp_InputFile.ResumeLayout(False)
        CType(Me.dgv_File_Config, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Grp_MainteOthers.ResumeLayout(False)
        Me.Grp_MainteTime.ResumeLayout(False)
        Me.Grp_MainteAmount.ResumeLayout(False)
        Me.Tab_Main.ResumeLayout(False)
        Me.Tab_X.ResumeLayout(False)
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.Tab_Iasc.ResumeLayout(False)
        Me.Tab_Iasc.PerformLayout()
        Me.Tab_Pa.ResumeLayout(False)
        Me.Tab_Pa.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.Tab_zSW.ResumeLayout(False)
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.Tab_Cisco.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        Me.GroupBox12.ResumeLayout(False)
        Me.GroupBox12.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.GroupBox8.ResumeLayout(False)
        Me.Grp_SvcPacType.ResumeLayout(False)
        Me.Grp_SvcPacTerm.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.Grp_MainteSystem.ResumeLayout(False)
        Me.GroupBox11.ResumeLayout(False)
        Me.grpCisco.ResumeLayout(False)
        Me.grpCisco.PerformLayout()
        Me.Grp_IsatDate.ResumeLayout(False)
        Me.Grp_IsatDate.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

#Region " �萔 "

    '������
    Private Const COMBOTABLE_COLUMN_NAME_TEXT = "text"
    Private Const COMBOTABLE_COLUMN_NAME_VALUE = "value"
    Private Const STR_SINGLE_SWMA = "�y�P��SWMA�z"
    Private Const STR_TESTING As String = "���������ؒ�������"

#End Region

#Region " �����o�ϐ� "
    Dim _project As OioProject
    Dim masterDataSet As DataSet
    Dim htFileList As New Hashtable
    Dim htSwma_FileList As New Hashtable
    Dim htMa_FileList As New Hashtable
    Dim htX_FileList As New Hashtable
    Dim htZsw_FileList As New Hashtable
    Dim htMaEx_FileList As New Hashtable
    Dim htCisco_FileList As New Hashtable
    Dim m_IgnoreEvent As Boolean
    Dim m_dialogInitialPath As String
    Dim htFMA_FileList As New Hashtable             'FMA
    Dim htMaIsat_FileList As New Hashtable
    Private _psLine As New OioProject
#End Region

#Region " �v���p�e�B "

    Public Property Project() As OioProject
        Get
            Return Me._project
        End Get
        Set(ByVal Value As OioProject)
            Me._project = Value
        End Set
    End Property

#End Region

#Region "�R���X�g���N�^"
    Sub New(ByVal psLine As OioProject)
        InitializeComponent()
        Me._psLine = psLine
    End Sub
#End Region

#Region " �C�x���g�n���h�� "

    '--------------------------------------------------------
    '���\�b�h���FFrm_Oio_Load
    '�T    �v  �F��ʃ��[�h����
    '��    ��  �F��ʃ��[�h�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Frm_Oio_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try
            '==============================
            '������������
            '==============================
            '�C�x���g�����t���O��������
            m_IgnoreEvent = False

            '���s���{Version
            Me.Text = CommonVariable.OBAMATITLE

            '�����\���p�̃f�[�^��ݒ�
            Me.SetInitialData()
            '�v���W�F�N�g�̃f�[�^��ݒ�
            Me.SetProjectData()
            '�Č��֘A�����\��
            Call initFrmPlanInfo()

            '�V�X�e�����Ǎ�
            Dim info As SystemInfo = FileReader.ReadSystemInfo()
            If info.TestFlg = CommonConstant.ParamCheck.Yes Then
                '���ؗp�̏ꍇ
                Me.UCnt_Pal00012.BackColor = Color.DimGray
                Me.UCnt_Pal00012.BackColro2 = Color.Silver
                Me.UCnt_Pal00012.TitleText = Me.UCnt_Pal00012.TitleText.Replace(Space(1) & Me.STR_TESTING, String.Empty) & Space(1) & Me.STR_TESTING
            End If

        Catch ex As MuseException
            Me.Activate()
            Me.Cursor = Cursors.Default
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
            Me.Close()
        Catch ex As Exception
            Me.Activate()
            Me.Cursor = Cursors.Default
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
            Me.Close()
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_OK_Click
    '�T    �v  �FBtn_OK�N���b�N����
    '��    ��  �FBtn_OK�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_OK.Click

        Try
            '==============================
            '���p�����[�^�t�@�C���쐬������
            '==============================
            '��ʓ��͒l�擾
            If Not Me.GetInputValue() Then
                Return
            End If

            '����1�t�@�C���I���`�F�b�N
            'AAS,MA,SystemX,Cisco�Ƀt�@�C�����I������Ă��Ȃ��ꍇ�A�m�s�Ƃ̃`�F�b�N�͂��Ȃ�
            If Me.htFileList.Count = 0 And _
                Me.htMa_FileList.Count = 0 And _
                Me.htX_FileList.Count = 0 And _
                Me.htCisco_FileList.Count = 0 And _
                Me.htFMA_FileList.Count = 0 And _
                Me.htZsw_FileList.Count = 0 Then
            Else
                Dim isExistItem1 As Boolean = False
                Dim i As Integer
                If Me._psLine.isNLine = False Then
                    isExistItem1 = True
                End If
                For i = 0 To Me.htFileList.Count - 1
                    If Me._psLine.FileName = Path.GetFileName(CType(Me.htFileList.Item(i), InputFileList).Config) Then
                        isExistItem1 = True
                    End If
                    '�P��SWMA�̃`�F�b�N���W�b�N�ǉ�
                    If Me._psLine.FileName = Path.GetFileName(CType(Me.htFileList.Item(i), InputFileList).SWMA) Then
                        isExistItem1 = True
                    End If
                Next

                ''E-BS�t�@�C������"/"��؂�ŕ�������
                For i = 0 To Me.htMa_FileList.Count - 1
                    Dim eBSNM() As String
                    eBSNM = CType(Me.htMa_FileList.Item(i), Ma_InputFileList).eBS_Mainte.Split(CommonConstant.STR_SLASH)
                    For j As Integer = 0 To eBSNM.Length - 1
                        If Me._psLine.FileName = Path.GetFileName(eBSNM(j)) Then
                            isExistItem1 = True
                        End If
                    Next
                Next
                For i = 0 To Me.htX_FileList.Count - 1
                    If Me._psLine.FileName = Path.GetFileName(CType(Me.htX_FileList.Item(i), X_InputFileList).Excel) Then
                        isExistItem1 = True
                    End If
                Next
                For i = 0 To Me.htCisco_FileList.Count - 1
                    If Path.GetFileNameWithoutExtension(Me._psLine.FileName) = Path.GetFileNameWithoutExtension(CType(Me.htCisco_FileList.Item(i), Cisco_InputFileList).eBS_Sale) Then
                        isExistItem1 = True
                    End If
                Next
                For i = 0 To Me.htFMA_FileList.Count - 1
                    If Me._psLine.FileName = Path.GetFileName(CType(Me.htFMA_FileList.Item(i), FMA_InputFileList).Word) Then
                        isExistItem1 = True
                    End If
                Next
                For i = 0 To Me.htZsw_FileList.Count - 1
                    If Me._psLine.FileName = Path.GetFileName(CType(Me.htZsw_FileList.Item(i), Zsw_InputFileList).HtmlFile) Then
                        isExistItem1 = True
                    End If
                Next

                ''�Ăяo������ʂɂāu���\���v��I�������Ƃ��̏���
                For i = 0 To Me.htMaEx_FileList.Count - 1
                    If Me._psLine.FileName = Path.GetFileName(CType(Me.htMaEx_FileList.Item(i), MaEx_InputFileList).Excel) Then
                        isExistItem1 = True
                    End If
                Next
                For i = 0 To Me.htMaIsat_FileList.Count - 1
                    If Me._psLine.FileName = Path.GetFileName(CType(Me.htMaIsat_FileList.Item(i), MaIsat_InputFileList).Excel) Then
                        isExistItem1 = True
                    End If
                Next
                If Not isExistItem1 Then
                    MuseMessageBox.ShowError(Me._psLine.FileName + FileReader.GetMessage("MSG_0080"), Me.Text)
                    Return
                End If
            End If

            '��ʂ����
            Me.Close()

        Catch ex As MuseException
            Me.Activate()
            Me.Cursor = Cursors.Default
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            Me.Cursor = Cursors.Default
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Ref_Config_Click
    '�T    �v  �FBtn_Ref_Config�N���b�N����
    '��    ��  �FBtn_Ref_Config�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Ref_Config_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Ref_Config.Click, Btn_Ref_Config_Swma.Click

        Try
            Dim dialog As OpenFileDialog = New OpenFileDialog

            Dim strFilter As String
            Select Case Me.Project.ProjectType
                Case CommonConstant.ParamProjectType.MaIsat
                    strFilter = "ISAT����̧�� (*.xlsx)|*.xlsx"
                Case CommonConstant.ParamProjectType.MaEx
                    strFilter = "���\��̧�� (*.xlsm)|*.xlsm"
                Case Else
                    strFilter = "csv files (*.csv)|*.csv"
            End Select
            dialog.Filter = strFilter

            dialog.Multiselect = True
            dialog.InitialDirectory = GetFileSeletctDialogInitialPath()

            If dialog.ShowDialog() = DialogResult.OK Then
                Dim fileName = dialog.FileName
                Dim relationNo As Integer

                Dim nIdx As Integer
                Dim arrCnt As Integer = 1
                Me._psLine.Items.Clear()

                For Each fileName In dialog.FileNames

                    Me._psLine.Items.Add(arrCnt, Path.GetFileName(fileName))
                    arrCnt += 1

                    '==============================
                    '�ʏ��Config�t�@�C���Ǎ���
                    '==============================
                    If Me.Project.ProjectType = CommonConstant.ParamProjectType.Std Then

                        '���X�g�{�b�N�X�Ƀt�@�C�����ݒ�
                        If sender.name = "Btn_Ref_Config_Swma" Then
                            '�P��SWMA�Ƀ`�F�b�N������ꍇ�F�P��SWMA�̕����O��
                            dgv_File_Config.Rows.Add(Me.STR_SINGLE_SWMA & Space(1) & Path.GetFileName(fileName), 1)
                        Else
                            dgv_File_Config.Rows.Add(Path.GetFileName(fileName), 1)
                        End If
                        relationNo = dgv_File_Config.Rows.Count - 1
                        dgv_File_Config.Rows(relationNo).Selected = True

                        '�t�@�C�����X�g�e�[�u���ɒl�ݒ�
                        Dim inputFile As New InputFileList
                        If sender.name = "Btn_Ref_Config_Swma" Then
                            '�P��SWMA�Ƀ`�F�b�N������ꍇ
                            inputFile.Config = String.Empty
                            inputFile.SWMA = fileName
                        Else
                            inputFile.Config = fileName
                            inputFile.SWMA = String.Empty
                        End If
                        inputFile.eBS_Sale = String.Empty
                        inputFile.eBS_Mainte = String.Empty

                        Me.htFileList.Add(relationNo, inputFile)

                        '==============================
                        '����MA���\���t�@�C���Ǎ���
                        '==============================
                    ElseIf Me.Project.ProjectType = CommonConstant.ParamProjectType.MaEx Then
                        '���X�g�{�b�N�X�Ƀt�@�C�����ݒ�
                        dgv_File_Config.Rows.Add(Path.GetFileName(fileName), 1)
                        relationNo = dgv_File_Config.Rows.Count - 1
                        dgv_File_Config.Rows(relationNo).Selected = True

                        '�t�@�C�����X�g�e�[�u���ɒl�ݒ�
                        Dim maExInputFile As New MaEx_InputFileList
                        maExInputFile.Excel = fileName
                        maExInputFile.Inventry = String.Empty
                        maExInputFile.eBS_Mainte = String.Empty

                        Me.htMaEx_FileList.Add(relationNo, maExInputFile)

                        '==============================
                        ''����MAISAT����̧�ٓǍ���
                        '==============================
                    ElseIf Me.Project.ProjectType = CommonConstant.ParamProjectType.MaIsat Then
                        '���X�g�{�b�N�X�Ƀt�@�C�����ݒ�
                        dgv_File_Config.Rows.Add(Path.GetFileName(fileName), 1)
                        relationNo = dgv_File_Config.Rows.Count - 1
                        dgv_File_Config.Rows(relationNo).Selected = True

                        '�t�@�C�����X�g�e�[�u���ɒl�ݒ�
                        Dim maisatInputFile As New MaIsat_InputFileList
                        maisatInputFile.Excel = fileName

                        Me.htMaIsat_FileList.Add(relationNo, maisatInputFile)
                    End If
                Next

            End If

        Catch ex As MuseException
            Me.Activate()
            Me.Cursor = Cursors.Default
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            Me.Cursor = Cursors.Default
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_SelectRelationFile_Click
    '�T    �v  �FBtn_SelectRelationFile�N���b�N����
    '��    ��  �FBtn_SelectRelationFile�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_SelectRelationFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_SelectRelationFile.Click

        Try

            Dim relationNo As Integer
            relationNo = dgv_File_Config.SelectedRows(0).Index

            If relationNo = -1 Then
                Throw New MuseException(FileReader.GetMessage("MSG_0002"))
            End If

            '�ʏ��Config�Ǎ���
            If Me.Project.ProjectType = CommonConstant.ParamProjectType.Std Then

                '==============================
                '���֘A�t�@�C���I����ʕ\����
                '==============================
                Dim fileSelect As New Frm_FileSelect
                fileSelect.InputFile = Me.htFileList(relationNo)
                If CType(Me.htFileList(relationNo), InputFileList).Config.Equals(String.Empty) Then
                    fileSelect.Pnl_Swma.Visible = False
                    fileSelect.Pnl_Ebs_Mainte.Visible = False
                    fileSelect.Grp_FileType.Visible = False
                End If

                fileSelect.DialogInitialPath = GetFileSeletctDialogInitialPath()
                fileSelect.ShowDialog()

                '����MA���\���t�@�C���Ǎ���
            ElseIf Me.Project.ProjectType = CommonConstant.ParamProjectType.MaEx Then
                Dim maExFileSelect As New Frm_MaExFileSelect
                maExFileSelect.InputFile = Me.htMaEx_FileList(relationNo)
                maExFileSelect.DialogInitialPath = GetFileSeletctDialogInitialPath()
                maExFileSelect.ShowDialog()
            End If

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Clear_Config_Click
    '�T    �v  �FBtn_Clear_Config�N���b�N����
    '��    ��  �FBtn_Clear_Config�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Clear_Config_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear_Config.Click
        Try
            Dim relationNo As Integer

            If dgv_File_Config.Rows.Count = 0 Then
                Exit Sub
            End If

            relationNo = dgv_File_Config.SelectedRows(0).Index
            If relationNo <> -1 Then
                If MuseMessageBox.ShowWarningQuestion(FileReader.GetMessage("MSG_0009"), sender.Text) = DialogResult.Cancel Then
                    dgv_File_Config.Select()
                    Exit Sub
                End If
                '�w�肵���t�@�C�����X�g�{�b�N�X�N���A
                dgv_File_Config.Rows.RemoveAt(relationNo)
                '�n�b�V���e�[�u���ĕҏW
                Dim index As Integer
                If Me.Project.ProjectType = CommonConstant.ParamProjectType.Std Then
                    For index = 0 To Me.htFileList.Count - 1
                        If index >= relationNo Then
                            '����̒l����
                            Me.htFileList(index) = Me.htFileList(index + 1)
                        End If
                    Next
                    '��ԍŌ�̒l���폜
                    Me.htFileList.Remove(Me.htFileList.Count - 1)
                ElseIf Me.Project.ProjectType = CommonConstant.ParamProjectType.MaEx Then
                    For index = 0 To Me.htMaEx_FileList.Count - 1
                        If index >= relationNo Then
                            '����̒l����
                            Me.htMaEx_FileList(index) = Me.htMaEx_FileList(index + 1)
                        End If
                    Next
                    '��ԍŌ�̒l���폜
                    Me.htMaEx_FileList.Remove(Me.htMaEx_FileList.Count - 1)

                ElseIf Me.Project.ProjectType = CommonConstant.ParamProjectType.MaIsat Then
                    For index = 0 To Me.htMaIsat_FileList.Count - 1
                        If index >= relationNo Then
                            '����̒l����
                            Me.htMaIsat_FileList(index) = Me.htMaIsat_FileList(index + 1)
                        End If
                    Next
                    '��ԍŌ�̒l���폜
                    Me.htMaIsat_FileList.Remove(Me.htMaIsat_FileList.Count - 1)
                End If
            Else
                If MuseMessageBox.ShowWarningQuestion(FileReader.GetMessage("MSG_0010"), sender.Text) = DialogResult.Cancel Then
                    dgv_File_Config.Select()
                    Exit Sub
                End If

                '�t�@�C�����X�g�{�b�N�X�̑S�Ă̍��ڃN���A
                dgv_File_Config.Rows.Clear()
                If Me.Project.ProjectType = CommonConstant.ParamProjectType.Std Then
                    Me.htFileList.Clear()
                ElseIf Me.Project.ProjectType = CommonConstant.ParamProjectType.MaEx Then
                    Me.htMaEx_FileList.Clear()
                ElseIf Me.Project.ProjectType = CommonConstant.ParamProjectType.MaIsat Then
                    Me.htMaIsat_FileList.Clear()
                End If
            End If

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Up_Config_Click
    '�T    �v  �FBtn_Up_Config�N���b�N����
    '��    ��  �FBtn_Up_Config�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Up_Config_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Up_Config.Click

        Try
            Dim relationNo As Integer
            If dgv_File_Config.Rows.Count = 0 Then
                Exit Sub
            End If
            relationNo = dgv_File_Config.SelectedRows(0).Index

            If relationNo = -1 Or relationNo = 0 Then
                Exit Sub
            End If

            '==============================
            '�����X�g�{�b�N�X�ĕҏW��
            '==============================
            Dim strItem As String
            Dim intQty As Integer
            '1��̒l��ޔ�
            strItem = dgv_File_Config.Rows(relationNo - 1).Cells(0).Value
            intQty = dgv_File_Config.Rows(relationNo - 1).Cells(1).Value
            dgv_File_Config.Rows(relationNo - 1).Cells(0).Value = dgv_File_Config.Rows(relationNo).Cells(0).Value
            dgv_File_Config.Rows(relationNo - 1).Cells(1).Value = dgv_File_Config.Rows(relationNo).Cells(1).Value
            dgv_File_Config.Rows(relationNo).Cells(0).Value = strItem
            dgv_File_Config.Rows(relationNo).Cells(1).Value = intQty
            dgv_File_Config.Rows(relationNo - 1).Selected = True

            '==============================
            '���n�b�V���e�[�u���ĕҏW��
            '==============================
            If Me.Project.ProjectType = CommonConstant.ParamProjectType.Std Then
                Dim inputFile As InputFileList
                '1��̒l��ޔ�
                inputFile = Me.htFileList(relationNo - 1)
                Me.htFileList(relationNo - 1) = Me.htFileList(relationNo)
                Me.htFileList(relationNo) = inputFile
            ElseIf Me.Project.ProjectType = CommonConstant.ParamProjectType.MaEx Then
                Dim maExInputFile As MaEx_InputFileList
                '1��̒l��ޔ�
                maExInputFile = Me.htMaEx_FileList(relationNo - 1)
                Me.htMaEx_FileList(relationNo - 1) = Me.htMaEx_FileList(relationNo)
                Me.htMaEx_FileList(relationNo) = maExInputFile
            ElseIf Me.Project.ProjectType = CommonConstant.ParamProjectType.MaIsat Then
                Dim maIsatInputFile As MaIsat_InputFileList
                '1��̒l��ޔ�
                maIsatInputFile = Me.htMaIsat_FileList(relationNo - 1)
                Me.htMaIsat_FileList(relationNo - 1) = Me.htMaIsat_FileList(relationNo)
                Me.htMaIsat_FileList(relationNo) = maIsatInputFile
            End If

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Down_Config_Click
    '�T    �v  �FBtn_Down_Config�N���b�N����
    '��    ��  �FBtn_Down_Config�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Down_Config_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Down_Config.Click

        Try
            Dim relationNo As Integer
            If dgv_File_Config.Rows.Count = 0 Then
                Exit Sub
            End If
            relationNo = dgv_File_Config.SelectedRows(0).Index

            If relationNo = -1 Or relationNo = dgv_File_Config.Rows.Count - 1 Then
                Exit Sub
            End If

            '==============================
            '�����X�g�{�b�N�X�ĕҏW��
            '==============================
            Dim item As String
            Dim strItem As String
            Dim intQty As Integer
            '1���̒l��ޔ�
            strItem = dgv_File_Config.Rows(relationNo + 1).Cells(0).Value
            intQty = dgv_File_Config.Rows(relationNo + 1).Cells(1).Value
            dgv_File_Config.Rows(relationNo + 1).Cells(0).Value = dgv_File_Config.Rows(relationNo).Cells(0).Value
            dgv_File_Config.Rows(relationNo + 1).Cells(1).Value = dgv_File_Config.Rows(relationNo).Cells(1).Value
            dgv_File_Config.Rows(relationNo).Cells(0).Value = strItem
            dgv_File_Config.Rows(relationNo).Cells(1).Value = intQty
            dgv_File_Config.Rows(relationNo + 1).Selected = True

            '==============================
            '���n�b�V���e�[�u���ĕҏW��
            '==============================
            If Me.Project.ProjectType = CommonConstant.ParamProjectType.Std Then
                Dim inputFile As InputFileList
                '1���̒l��ޔ�
                inputFile = Me.htFileList(relationNo + 1)
                Me.htFileList(relationNo + 1) = Me.htFileList(relationNo)
                Me.htFileList(relationNo) = inputFile
            ElseIf Me.Project.ProjectType = CommonConstant.ParamProjectType.MaEx Then
                Dim maExInputFile As MaEx_InputFileList
                '1���̒l��ޔ�
                maExInputFile = Me.htMaEx_FileList(relationNo + 1)
                Me.htMaEx_FileList(relationNo + 1) = Me.htMaEx_FileList(relationNo)
                Me.htMaEx_FileList(relationNo) = maExInputFile
            ElseIf Me.Project.ProjectType = CommonConstant.ParamProjectType.MaIsat Then
                Dim maIsatInputFile As MaIsat_InputFileList
                '1���̒l��ޔ�
                maIsatInputFile = Me.htMaIsat_FileList(relationNo + 1)
                Me.htMaIsat_FileList(relationNo + 1) = Me.htMaIsat_FileList(relationNo)
                Me.htMaIsat_FileList(relationNo) = maIsatInputFile
            End If

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Ref_X_Click
    '�T    �v  �FBtn_Ref_X�N���b�N����
    '��    ��  �FBtn_Ref_X�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Ref_X_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Ref_X.Click

        Try
            Dim dialog As OpenFileDialog = New OpenFileDialog
            dialog.Filter = "Excel files (*.xls;*.xlsx;*.xlsm)|*.xls;*.xlsx;*.xlsm"

            dialog.Multiselect = True
            dialog.InitialDirectory = GetFileSeletctDialogInitialPath()

            If dialog.ShowDialog() = DialogResult.OK Then
                Dim fileName = dialog.FileName
                Dim relationNo As Integer

                For Each fileName In dialog.FileNames

                    '���X�g�{�b�N�X�Ƀt�@�C�����ݒ�
                    relationNo = Me.Lst_File_X.Items.Add(Path.GetFileName(fileName))
                    Me.Lst_File_X.SelectedIndex = relationNo

                    '==============================
                    '���t�@�C�����X�g�e�[�u���ɒl�ݒ聞
                    '==============================
                    Dim x_InputFile As New X_InputFileList
                    x_InputFile.Excel = fileName
                    x_InputFile.eBS_Sale = String.Empty
                    x_InputFile.eBS_Mainte = String.Empty

                    Me.htX_FileList.Add(relationNo, x_InputFile)
                Next

            End If

        Catch ex As MuseException
            Me.Activate()
            Me.Cursor = Cursors.Default
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            Me.Cursor = Cursors.Default
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_SelectRelationFile_Click
    '�T    �v  �FBtn_SelectRelationFile�N���b�N����
    '��    ��  �FBtn_SelectRelationFile�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_X_SelectRelationFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_X_SelectRelationFile.Click

        Try
            Dim relationNo As Integer
            relationNo = Me.Lst_File_X.SelectedIndex

            If relationNo = -1 Then
                Throw New MuseException(FileReader.GetMessage("MSG_0002"))
            End If

            '==============================
            '���֘A�t�@�C���I����ʕ\����
            '==============================
            Dim x_FileSelect As New Frm_X_FileSelect
            x_FileSelect.InputFile = Me.htX_FileList(relationNo)
            x_FileSelect.DialogInitialPath = GetFileSeletctDialogInitialPath()
            x_FileSelect.ShowDialog()

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Clear_X_Click
    '�T    �v  �FBtn_Clear_X�N���b�N����
    '��    ��  �FBtn_Clear_X�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Clear_X_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear_X.Click

        Try
            Dim relationNo As Integer

            If Me.Lst_File_X.Items.Count = 0 Then
                Exit Sub
            End If

            relationNo = Me.Lst_File_X.SelectedIndex
            If relationNo <> -1 Then
                If MuseMessageBox.ShowWarningQuestion(FileReader.GetMessage("MSG_0009"), sender.Text) = DialogResult.Cancel Then
                    Me.Lst_File_X.Select()
                    Exit Sub
                End If
                '�w�肵���t�@�C�����X�g�{�b�N�X�N���A
                Me.Lst_File_X.Items.RemoveAt(relationNo)
                '�n�b�V���e�[�u���ĕҏW
                Dim index As Integer
                For index = 0 To Me.htX_FileList.Count - 1
                    If index >= relationNo Then
                        '����̒l����
                        Me.htX_FileList(index) = Me.htX_FileList(index + 1)
                    End If
                Next
                '��ԍŌ�̒l���폜
                Me.htX_FileList.Remove(Me.htX_FileList.Count - 1)
            Else
                If MuseMessageBox.ShowWarningQuestion(FileReader.GetMessage("MSG_0010"), sender.Text) = DialogResult.Cancel Then
                    Me.Lst_File_X.Select()
                    Exit Sub
                End If
                '�t�@�C�����X�g�{�b�N�X�̑S�Ă̍��ڃN���A
                Me.Lst_File_X.Items.Clear()
                Me.htX_FileList.Clear()
            End If

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Ref_Cisco_Click
    '�T    �v  �FBtn_Ref_Cisco�N���b�N����
    '��    ��  �FBtn_Ref_Cisco�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Ref_Cisco_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Ref_Cisco.Click

        Try
            Dim dialog As OpenFileDialog = New OpenFileDialog
            dialog.Filter = "csv files (*.csv)|*.csv"

            dialog.Multiselect = True
            dialog.InitialDirectory = GetFileSeletctDialogInitialPath()

            If dialog.ShowDialog() = DialogResult.OK Then
                Dim fileName = dialog.FileName
                Dim relationNo As Integer

                For Each fileName In dialog.FileNames

                    '���X�g�{�b�N�X�Ƀt�@�C�����ݒ�
                    relationNo = Me.Lst_File_Cisco.Items.Add(Path.GetFileName(fileName))
                    Me.Lst_File_Cisco.SelectedIndex = relationNo

                    '==============================
                    '���t�@�C�����X�g�e�[�u���ɒl�ݒ聞
                    '==============================
                    Dim cisco_InputFile As New Cisco_InputFileList
                    cisco_InputFile.eBS_Sale = fileName

                    Me.htCisco_FileList.Add(relationNo, cisco_InputFile)
                    Me.m_dialogInitialPath = Path.GetDirectoryName(dialog.FileName)
                Next

            End If

        Catch ex As MuseException
            Me.Activate()
            Me.Cursor = Cursors.Default
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            Me.Cursor = Cursors.Default
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Clear_Cisco_Click
    '�T    �v  �FBtn_Clear_Cisco�N���b�N����
    '��    ��  �FBtn_Clear_Cisco�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Clear_Cisco_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear_Cisco.Click

        Try
            Dim relationNo As Integer

            If Me.Lst_File_Cisco.Items.Count = 0 Then
                Exit Sub
            End If

            relationNo = Me.Lst_File_Cisco.SelectedIndex
            If relationNo <> -1 Then
                If MuseMessageBox.ShowWarningQuestion(FileReader.GetMessage("MSG_0009"), sender.Text) = DialogResult.Cancel Then
                    Me.Lst_File_Cisco.Select()
                    Exit Sub
                End If
                '�w�肵���t�@�C�����X�g�{�b�N�X�N���A
                Me.Lst_File_Cisco.Items.RemoveAt(relationNo)
                '�n�b�V���e�[�u���ĕҏW
                Dim index As Integer
                For index = 0 To Me.htCisco_FileList.Count - 1
                    If index >= relationNo Then
                        '����̒l����
                        Me.htCisco_FileList(index) = Me.htCisco_FileList(index + 1)
                    End If
                Next
                '��ԍŌ�̒l���폜
                Me.htCisco_FileList.Remove(Me.htCisco_FileList.Count - 1)
            Else
                If MuseMessageBox.ShowWarningQuestion(FileReader.GetMessage("MSG_0010"), sender.Text) = DialogResult.Cancel Then
                    Me.Lst_File_Cisco.Select()
                    Exit Sub
                End If
                '�t�@�C�����X�g�{�b�N�X�̑S�Ă̍��ڃN���A
                Me.Lst_File_Cisco.Items.Clear()
                Me.htCisco_FileList.Clear()
            End If

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FBtn_Close_Click
    '�T    �v  �FBtn_Close�N���b�N����
    '��    ��  �FBtn_Close�N���b�N�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click

        Try
            '��ʂ����
            Me.Close()

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FRdo_MainteOthersSale_CheckedChanged
    '�T    �v  �FRdo_MainteOthersSale�`�F�b�N�`�F���W����
    '��    ��  �FRdo_MainteOthersSale�`�F�b�N�`�F���W�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Rdo_MainteOthersSale_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Rdo_MainteOthersSale.CheckedChanged

        Try
            If sender.Checked = True Then
                Me.Grp_MainteAmount.Visible = False
                Me.Grp_MainteTime.Visible = False
                Me.Grp_SvcPacTerm.Visible = False
                Me.Grp_SvcPacType.Visible = False
            End If

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FRdo_MainteOthersSaleMainte_CheckedChanged
    '�T    �v  �FRdo_MainteOthersSaleMainte�`�F�b�N�`�F���W����
    '��    ��  �FRdo_MainteOthersSaleMainte�`�F�b�N�`�F���W�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Rdo_MainteOthersSaleMainte_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Rdo_MainteOthersSaleMainte.CheckedChanged

        Try
            If sender.Checked = True Then
                Me.Grp_MainteAmount.Visible = True
                Me.Grp_MainteTime.Visible = True
                Me.Grp_SvcPacTerm.Visible = False
                Me.Grp_SvcPacType.Visible = False
            End If

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FRdo_MainteOthersSaleSvc_CheckedChanged
    '�T    �v  �FRdo_MainteOthersSaleSvc�`�F�b�N�`�F���W����
    '��    ��  �FRdo_MainteOthersSaleSvc�`�F�b�N�`�F���W�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Rdo_MainteOthersSaleSvc_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Rdo_MainteOthersSaleSvc.CheckedChanged

        Try
            If sender.Checked = True Then
                Me.Grp_MainteAmount.Visible = True
                Me.Grp_MainteTime.Visible = True
                Me.Grp_SvcPacTerm.Visible = True
                Me.Grp_SvcPacType.Visible = True
            End If

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FRdo_MainteOthersSaleSvcSsuite_CheckedChanged
    '�T    �v  �FRdo_MainteOthersSaleSvcSsuite�`�F�b�N�`�F���W����
    '��    ��  �FRdo_MainteOthersSaleSvcSsuite�`�F�b�N�`�F���W�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Rdo_MainteOthersSaleSvcSsuite_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Try
            If sender.Checked = True Then
                Me.Grp_MainteAmount.Visible = True
                Me.Grp_MainteTime.Visible = True
                Me.Grp_SvcPacTerm.Visible = True
                Me.Grp_SvcPacType.Visible = True
            End If

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FDp_Introduction_ValueChanged
    '�T    �v  �FDp_Introduction�o�����[�`�F���W����
    '��    ��  �FDp_Introduction�o�����[�`�F���W�������s��
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Dp_Introduction_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Dp_Introduction.ValueChanged

        '�C�x���g�����t���O��ON�̏ꍇ�������Ȃ�
        If m_IgnoreEvent Then
            Exit Sub
        End If
        Try
            Dim introductionDate As DateTime

            introductionDate = CType(sender.Text, DateTime)

            Me.Dp_StartTime.Text = introductionDate.AddMonths(1).ToString("yyyy�NMM��")

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    Private Sub Dp_StartTime_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dp_StartTime.ValueChanged

        Try
            Dim IntroductionDate As DateTime
            Dim StartDate As DateTime
            Dim EndDate As DateTime

            IntroductionDate = CType(Me.Dp_Introduction.Text, DateTime)
            StartDate = CType(sender.Text, DateTime)
            EndDate = CType(Me.Dp_EndTime.Text, DateTime)

            If StartDate < IntroductionDate Then
                m_IgnoreEvent = True
                Me.Dp_Introduction.Text = StartDate.ToString("yyyy�NMM��")
                m_IgnoreEvent = False
            End If

            If StartDate.AddYears(3).AddMonths(-1) > EndDate Then
                Me.Dp_EndTime.Text = StartDate.AddYears(3).AddMonths(-1).ToString("yyyy�NMM��")
            End If


        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    Private Sub Dp_EndTime_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dp_EndTime.ValueChanged

        Try
            Dim StartDate As DateTime
            Dim EndDate As DateTime

            StartDate = CType(Me.Dp_StartTime.Text, DateTime)
            EndDate = CType(sender.Text, DateTime)

            If StartDate >= EndDate Then
                Me.Dp_EndTime.Text = StartDate.AddMonths(1).ToString("yyyy�NMM��")
                Me.Dp_EndTime.Enabled = False
                Me.Dp_EndTime.Enabled = True
            End If


        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FRdo_MainteSystemMaps_CheckedChanged
    '�T    �v  �FRdo_MainteSystemMaps�ύX����
    '��    ��  �F
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Rdo_MainteSystemMaps_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Rdo_MainteSystemMaps.CheckedChanged

        ''���iϽ��́AChis�̂ݑI���\
        If sender.Checked = True Then
            Rdo_x_DescriptionTarget_eBs.Checked = False
            Rdo_x_DescriptionTarget_Master.Enabled = True
        Else
            Rdo_x_DescriptionTarget_Master.Enabled = True
        End If

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FRdo_x_DescriptionTarget_eBs_CheckedChanged
    '�T    �v  �FRdo_x_DescriptionTarget_eBs�ύX����
    '��    ��  �F
    '��    ��  �F
    '�� �� �l  �F
    '--------------------------------------------------------
    Private Sub Rdo_x_DescriptionTarget_eBs_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Rdo_x_DescriptionTarget_eBs.CheckedChanged
        If sender.checked = True Then
            Btn_X_SelectRelationFile.Enabled = True
        Else
            Btn_X_SelectRelationFile.Enabled = False
        End If
    End Sub

    Private Sub Btn_Ref_Fma_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Ref_Fma.Click

        Dim dialog As OpenFileDialog = New OpenFileDialog

        Try
            ''' �����F�R�����_�C�A���O�����ݒ�
            dialog.Filter = "doc files (*.doc)|*.doc"
            dialog.Multiselect = True
            dialog.InitialDirectory = GetFileSeletctDialogInitialPath()

            ''' �����F�R�����_�C�A���O�\��
            ''' �����F�{�^������
            ''' �P�[�X�FOK�{�^���̏ꍇ�A�ȉ��̏������s��
            If dialog.ShowDialog() = DialogResult.OK Then
                Dim fileName = dialog.FileName
                Dim relationNo As Integer

                For Each fileName In dialog.FileNames

                    '���X�g�{�b�N�X�Ƀt�@�C�����ݒ�
                    relationNo = Me.Lst_File_Fma.Items.Add(Path.GetFileName(fileName))
                    Me.Lst_File_Fma.SelectedIndex = relationNo

                    '==============================
                    '���t�@�C�����X�g�e�[�u���ɒl�ݒ聞
                    '==============================
                    Dim fma_InputFile As New FMA_InputFileList
                    fma_InputFile.Word = fileName

                    Me.htFMA_FileList.Add(relationNo, fma_InputFile)

                    '���͒l��_project�ɕۑ�
                    ReDim Preserve Me._project.FmaInputFile(relationNo)
                    Me._project.FmaInputFile(relationNo) = fma_InputFile

                    Me.m_dialogInitialPath = Path.GetDirectoryName(dialog.FileName)
                Next
            End If

        Catch ex As MuseException
            Me.Activate()
            Me.Cursor = Cursors.Default
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            Me.Cursor = Cursors.Default
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    Private Sub Btn_Clear_Fma_Click(sender As System.Object, e As System.EventArgs) Handles Btn_Clear_Fma.Click
        Dim relationNo As Integer

        Try

            If Me.Lst_File_Fma.Items.Count = 0 Then
                Exit Sub
            End If

            relationNo = Me.Lst_File_Fma.SelectedIndex
            If relationNo <> -1 Then
                If MuseMessageBox.ShowWarningQuestion(FileReader.GetMessage("MSG_0009"), sender.Text) = DialogResult.Cancel Then
                    Me.Lst_File_Fma.Select()
                    Exit Sub
                End If
                '�w�肵���t�@�C�����X�g�{�b�N�X�N���A
                Me.Lst_File_Fma.Items.RemoveAt(relationNo)
                '�n�b�V���e�[�u���ĕҏW
                Dim index As Integer
                For index = 0 To Me.htFMA_FileList.Count - 1
                    If index >= relationNo Then
                        '����̒l����
                        Me.htFMA_FileList(index) = Me.htFMA_FileList(index + 1)
                    End If
                Next
                '��ԍŌ�̒l���폜
                Me.htFMA_FileList.Remove(Me.htFMA_FileList.Count - 1)
            Else
                If MuseMessageBox.ShowWarningQuestion(FileReader.GetMessage("MSG_0010"), sender.Text) = DialogResult.Cancel Then
                    Me.Lst_File_Fma.Select()
                    Exit Sub
                End If
                '�t�@�C�����X�g�{�b�N�X�̑S�Ă̍��ڃN���A
                Me.Lst_File_Fma.Items.Clear()
                Me.htFMA_FileList.Clear()
            End If

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    ''' <summary>
    ''' �@�\�FzSW�̎Q�����݂�د�
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Btn_Ref_Zsw_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Ref_Zsw.Click

        Dim dialog As OpenFileDialog = New OpenFileDialog

        Try
            dialog.Filter = "zSW files (*.html;*.htm)|*.html;*.htm"
            dialog.Multiselect = True
            dialog.InitialDirectory = GetFileSeletctDialogInitialPath()

            If dialog.ShowDialog() = DialogResult.OK Then
                Dim fileName As String = dialog.FileName
                Dim relationNo As Integer

                For Each fileName In dialog.FileNames

                    '���X�g�{�b�N�X�Ƀt�@�C�����ݒ�
                    relationNo = Me.Lst_File_Zsw.Items.Add(Path.GetFileName(fileName))
                    Me.Lst_File_Zsw.SelectedIndex = relationNo

                    '==============================
                    '���t�@�C�����X�g�e�[�u���ɒl�ݒ聞
                    '==============================
                    Dim Zsw_InputFile As New Zsw_InputFileList
                    Zsw_InputFile.HtmlFile = fileName
                    Me.htZsw_FileList.Add(relationNo, Zsw_InputFile)
                Next
            End If

        Catch ex As MuseException
            Me.Activate()
            Me.Cursor = Cursors.Default
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            Me.Cursor = Cursors.Default
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    ''' <summary>
    ''' �@�\�FzSW�̸ر���݂�د�
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Btn_Clear_Zsw_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear_Zsw.Click

        Try
            Dim relationNo As Integer

            If Me.Lst_File_Zsw.Items.Count = 0 Then
                Exit Sub
            End If

            relationNo = Me.Lst_File_Zsw.SelectedIndex
            If relationNo <> -1 Then
                If MuseMessageBox.ShowWarningQuestion(FileReader.GetMessage("MSG_0009"), sender.Text) = DialogResult.Cancel Then
                    Me.Lst_File_Zsw.Select()
                    Exit Sub
                End If
                '�w�肵���t�@�C�����X�g�{�b�N�X�N���A
                Me.Lst_File_Zsw.Items.RemoveAt(relationNo)
                '�n�b�V���e�[�u���ĕҏW
                Dim index As Integer
                For index = 0 To Me.htZsw_FileList.Count - 1
                    If index >= relationNo Then
                        '����̒l����
                        Me.htZsw_FileList(index) = Me.htZsw_FileList(index + 1)
                    End If
                Next
                '��ԍŌ�̒l���폜
                Me.htZsw_FileList.Remove(Me.htZsw_FileList.Count - 1)
            Else
                If MuseMessageBox.ShowWarningQuestion(FileReader.GetMessage("MSG_0010"), sender.Text) = DialogResult.Cancel Then
                    Me.Lst_File_Zsw.Select()
                    Exit Sub
                End If
                '�t�@�C�����X�g�{�b�N�X�̑S�Ă̍��ڃN���A
                Me.Lst_File_Zsw.Items.Clear()
                Me.htZsw_FileList.Clear()
            End If

        Catch ex As MuseException
            Me.Activate()
            MuseMessageBox.ShowWarning(ex.Message, sender.Text)
        Catch ex As Exception
            Me.Activate()
            FileWriter.WriteErrorLog(ex)
            MuseMessageBox.ShowError(ex.Message, MethodInfo.GetCurrentMethod.Name)
        End Try

    End Sub

    ''' <summary>
    ''' �@�\�F
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub dgv_File_Config_CellValidating(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellValidatingEventArgs) Handles dgv_File_Config.CellValidating

        Dim dgv As DataGridView = DirectCast(sender, DataGridView)
        Dim strValue As String = e.FormattedValue.ToString()

        If dgv.Columns(e.ColumnIndex).Name = "colQty" Then
            If strValue = "" Then
                MsgBox("���ʂ����͂���Ă��܂���B", MsgBoxStyle.Critical, "")
                dgv.CancelEdit()
                e.Cancel = True
            End If
            If strValue = "0" Then
                dgv.CancelEdit()
                e.Cancel = True
            End If
        End If
    End Sub

    ''' <summary>
    ''' �@�\�F
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub dgv_File_Config_EditingControlShowing(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewEditingControlShowingEventArgs) Handles dgv_File_Config.EditingControlShowing

        '�\������Ă���R���g���[����DataGridViewTextBoxEditingControl�����ׂ�
        If TypeOf e.Control Is DataGridViewTextBoxEditingControl Then
            Dim dgv As DataGridView = CType(sender, DataGridView)

            '�ҏW�̂��߂ɕ\������Ă���R���g���[�����擾
            Dim tb As DataGridViewTextBoxEditingControl = CType(e.Control, DataGridViewTextBoxEditingControl)

            '�C�x���g�n���h�����폜
            RemoveHandler tb.KeyPress, AddressOf dataGridViewTextBox_KeyPress

            '�Y������񂩒��ׂ�
            If dgv.CurrentCell.OwningColumn.Name = "colQty" Then
                'KeyPress�C�x���g�n���h����ǉ�
                AddHandler tb.KeyPress, AddressOf dataGridViewTextBox_KeyPress
            End If
        End If
    End Sub

    ''' <summary>
    ''' �@�\�FDataGridView�pKeyPress�C�x���g�n���h��
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub dataGridViewTextBox_KeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs)

        '0�`9�ƁA�o�b�N�X�y�[�X�ȊO�̎��́A�C�x���g���L�����Z������
        If (e.KeyChar < "0"c OrElse "9"c < e.KeyChar) AndAlso e.KeyChar <> ControlChars.Back Then
            e.Handled = True
        End If

    End Sub

#End Region

#Region " �v���C�x�[�g���\�b�h "
    '--------------------------------------------------------
    '���\�b�h���FSetInitialData
    '�T    �v  �F��������
    '��    ��  �F�����������s��
    '��    ��  �F�Ȃ�
    '�� �� �l  �F�Ȃ�
    '--------------------------------------------------------
    Private Sub SetInitialData()

        Me.Tab_Main.SelectedTab = Tab_X

        '�O���[�v�{�b�N�X�ɏ����l�ݒ�
        Me.Grp_MainteAmount.Visible = False
        Me.Grp_MainteTime.Visible = False
        Me.Grp_SvcPacTerm.Visible = False
        Me.Grp_SvcPacType.Visible = False

        '���W�I�{�^���ɏ����l�ݒ�
        Me.Rdo_MainteAmountAnnual.Enabled = False
        Me.Rdo_MainteAmountMonthly.Checked = True
        Me.Rdo_MainteOthersSaleMainte.Checked = True
        Me.Rdo_MainteTimeMonSun24h.Checked = True
        Me.Rdo_SvcTerm3Years.Checked = True
        Me.Rdo_SvcTypeRepair.Checked = True

        '*�R���{�{�b�N�X�ݒ�p�̃e�[�u�����`
        Dim comboTable As New DataTable
        comboTable.Columns.Add(Me.COMBOTABLE_COLUMN_NAME_TEXT, Type.GetType("System.String"))
        comboTable.Columns.Add(Me.COMBOTABLE_COLUMN_NAME_VALUE, Type.GetType("System.String"))

        '�`�F�b�N�{�b�N�X�ɏ�����
        Me.chkzSwNoChange.Checked = False

        '==============================================================
        '���R���{�{�b�N�X�ɒl�ݒ聞
        '==============================================================
        'PA�A�j�o�[�T���[�E�f�[�g
        Me.SetCombo(Me.Cmb_Pa_Anniversary, Me.GetPaAnniversaryTable(comboTable))
        'PA�������x��
        Dim control As New OioControl
        control.StartUpPath = Application.StartupPath
        Me.SetComboCODE(Me.Cmb_ChargeLevel, control.GetCodeData(CommonConstant.CODE_CLASSCODE_CHARGELEVEL, CommonVariable.MdbPW), True)
        '�_�����\��
        lblCPNO.Text = CommonVariable.CUSTOMERNAME.Replace("&", "&&") & "(" & CommonVariable.CPNO & ")"
        lblContractNo.Text = CommonVariable.CONTRACTNO.ToString().PadLeft(3, "0c")
        lblContractName.Text = CommonVariable.CONTRACTNONAME.Replace("&", "&&")

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FGetPaAnniversaryTable
    '�T    �v  �FPa_Anniversary�e�[�u���擾����
    '��    ��  �FPa_Anniversary�e�[�u���擾�������s��
    '��    ��  �FcomboTable �F�R���{�{�b�N�X�ݒ�p�e�[�u��
    '�� �� �l  �FPA�A�j�o�[�T���[�E�f�[�g
    '--------------------------------------------------------
    Private Function GetPaAnniversaryTable(ByVal comboTable As DataTable) As DataTable

        Dim comboRow As DataRow
        Dim i As Integer

        comboTable = comboTable.Clone

        For i = 1 To DateTime.MaxValue.Month
            comboRow = comboTable.NewRow
            comboRow.Item(Me.COMBOTABLE_COLUMN_NAME_VALUE) = i
            comboRow.Item(COMBOTABLE_COLUMN_NAME_TEXT) = i
            comboTable.Rows.Add(comboRow)
        Next

        Return comboTable

    End Function

    '--------------------------------------------------------
    '���\�b�h���FSetCombo
    '�T    �v  �F�R���{�{�b�N�X�l�ݒ菈��
    '��    ��  �F�R���{�{�b�N�X�l�ݒ菈�����s��
    '��    ��  �FCmbName     �FComboBox
    '�@�@�@�@�@�FdataSource  �F�f�[�^��
    '�� �� �l  �F�Ȃ�
    '--------------------------------------------------------
    Private Sub SetCombo(ByRef CmbName As Windows.Forms.ComboBox, ByVal dataSource As DataTable)

        '�R���{�{�b�N�X�ɒl���Z�b�g����B
        CmbName.DataSource = dataSource
        CmbName.DisplayMember = Me.COMBOTABLE_COLUMN_NAME_TEXT
        CmbName.ValueMember = Me.COMBOTABLE_COLUMN_NAME_VALUE

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FSetComboCODE
    '�T    �v  �F�R���{�{�b�N�X�l�ݒ菈��
    '��    ��  �F�R���{�{�b�N�X�l�ݒ菈�����s��
    '��    ��  �FCmbName     �FComboBox
    '�@�@�@�@�@�FdataSource  �F�R�[�h�f�[�^
    '�@�@�@�@�@�FBoolean     �F��s�L��
    '�� �� �l  �F�Ȃ�
    '--------------------------------------------------------
    Private Sub SetComboCODE(ByRef CmbName As Windows.Forms.ComboBox, ByVal dataSource As CodeTable, ByVal blBlank As Boolean)

        If blBlank = True Then
            '��s�ǉ�
            dataSource.Rows.InsertAt(dataSource.NewRow, 0)
        End If

        '�R���{�{�b�N�X�ɒl���Z�b�g����B
        CmbName.DataSource = dataSource
        CmbName.DisplayMember = dataSource.COLUMN_NAME_ITEMVALUE
        CmbName.ValueMember = dataSource.COLUMN_NAME_ITEMCODE

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FSetProjectData
    '�T    �v  �F��ʓ��͒l�ݒ菈��
    '��    ��  �F��ʓ��͒l�ݒ菈�����s��
    '��    ��  �F�Ȃ�
    '�� �� �l  �F�Ȃ�
    '--------------------------------------------------------
    Private Function SetProjectData()

        '==============================================================
        '�����ʍ��ځ�
        '==============================================================
        '�����AOIO���ԊJ�n�AOIO���ԏI���̂����ꂩ�̒l���Ȃ���Γ����𒆐S�Ƃ����Œ�l��ݒ�
        If Me._project.Introduction Is Nothing Then
            Dim CurDate As DateTime = DateTime.Now
            '����
            Me.Dp_Introduction.Text = CurDate.ToString("yyyy�NMM��")
            'OIO���ԊJ�n
            Me.Dp_StartTime.Text = CurDate.AddMonths(1).ToString("yyyy�NMM��")
            'OIO���ԏI��
            Me.Dp_EndTime.Text = CurDate.AddYears(3).ToString("yyyy�NMM��")
            '�����AOIO���ԊJ�n�AOIO���ԏI���̂�������l������ꍇ�͂��̒l�����̂܂ܐݒ�

        Else
            '����
            Me.Dp_Introduction.Text = Me._project.Introduction
            'OIO���ԊJ�n
            Me.Dp_StartTime.Text = Me._project.StartTime
            'OIO���ԏI��
            Me.Dp_EndTime.Text = Me._project.EndTime
            Me.Dp_PayEnd.Text = Me._project.PayEndTime
        End If
        '�v���W�F�N�g���
        Select Case Me._project.ProjectType
            Case CommonConstant.ParamProjectType.Std
                Me.Grp_InputFile.Visible = True
                Me.grpCisco.Visible = False
                Me.Tab_Main.Visible = True
                Me.dgv_File_Config.Columns(1).ReadOnly = False
                'Req.1614 Isat�捞���W�b�N�ύX 2018/03 Str
                Grp_IsatDate.Visible = False
                'Req.1614 Isat�捞���W�b�N�ύX 2018/03 End
            Case CommonConstant.ParamProjectType.MaIsat
                Me.Tab_Main.Visible = False
                Me.Grp_InputFile.Visible = True
                Me.Grp_MainteOthers.Visible = False
                Me.GroupBox11.Visible = False
                Me.Grp_MainteAmount.Visible = False
                Me.Grp_MainteSystem.Visible = False
                Me.Grp_SvcPacTerm.Visible = False
                Me.grpCisco.Visible = False
                Me.Grp_MainteTime.Visible = False
                Me.Grp_SvcPacType.Visible = False
                Me.Btn_Ref_Config_Swma.Visible = False
                Me.Btn_SelectRelationFile.Visible = False
                Me.Grp_InputFile.Text = "ISAT���σt�@�C���w��"
                Me.dgv_File_Config.Columns(1).ReadOnly = True

                'Req.1614 Isat�捞���W�b�N�ύX 2018/03 Str
                Grp_IsatDate.Visible = True
                If Me.Width > 1274 Then
                    Grp_IsatDate.Left = 1000
                    Grp_IsatDate.Top = 300
                ElseIf Me.Width > 957 Then
                    Grp_IsatDate.Left = 800
                    Grp_IsatDate.Top = 240
                Else
                    Grp_IsatDate.Left = 600
                    Grp_IsatDate.Top = 180
                End If

                Rdo_UseIsat.Checked = True
                'Req.1614 Isat�捞���W�b�N�ύX 2018/03 End
                'Req.1723 Str
                Label13.Text = ""
                'Req.1723 End

            Case CommonConstant.ParamProjectType.MaEx
                Me.Tab_Main.Visible = False
                Me.Grp_InputFile.Visible = True
                Me.Grp_MainteOthers.Visible = False
                Me.GroupBox11.Visible = False
                Me.Grp_MainteAmount.Visible = False
                Me.Grp_MainteSystem.Visible = False
                Me.Grp_SvcPacTerm.Visible = False
                Me.grpCisco.Visible = True
                Me.Grp_MainteTime.Visible = True
                'Req.1605 2017/12 Str
                'Me.Grp_MainteTime.Location = New Point(16, 458)
                Grp_MainteTime.Left = 22
                'Req.1605 2017/12 End
                Me.Grp_SvcPacType.Visible = False
                Me.Btn_Ref_Config_Swma.Visible = False
                Me.Btn_SelectRelationFile.Visible = True
                Me.Grp_InputFile.Text = "���\���t�@�C���w��"
                Me.dgv_File_Config.Columns(1).ReadOnly = True
                'Req.1614 Isat�捞���W�b�N�ύX 2018/03 Str
                Grp_IsatDate.Visible = False
                'Req.1614 Isat�捞���W�b�N�ύX 2018/03 End
        End Select
        'Input�t�@�C����(Config)
        Dim relationNo As Integer
        If IsNothing(Me._project.InputFile) = False Then
            If Me.Project.ProjectType = CommonConstant.ParamProjectType.Std Then
                Dim inputFile As InputFileList
                For Each inputFile In Me._project.InputFile
                    Me.htFileList.Add(relationNo, inputFile)
                    If Not inputFile.Config.Equals(String.Empty) Then
                        dgv_File_Config.Rows.Add(Path.GetFileName(inputFile.Config), inputFile.InputQuantity)
                    Else
                        dgv_File_Config.Rows.Add(Me.STR_SINGLE_SWMA & Space(1) & Path.GetFileName(inputFile.SWMA), inputFile.InputQuantity)
                    End If
                    relationNo += 1
                Next
            ElseIf Me.Project.ProjectType = CommonConstant.ParamProjectType.MaEx Then
                Dim maExInputFile As MaEx_InputFileList
                For Each maExInputFile In Me._project.MaEx_InputFile
                    Me.htMaEx_FileList.Add(relationNo, maExInputFile)
                    dgv_File_Config.Rows.Add(Path.GetFileName(maExInputFile.Excel), 1)
                    relationNo += 1
                Next
            ElseIf Me.Project.ProjectType = CommonConstant.ParamProjectType.MaIsat Then
                Dim maIsatInputFile As MaIsat_InputFileList
                For Each maIsatInputFile In Me._project.MaIsat_InputFile
                    Me.htMaIsat_FileList.Add(relationNo, maIsatInputFile)
                    dgv_File_Config.Rows.Add(Path.GetFileName(maIsatInputFile.Excel), 1)
                    relationNo += 1
                Next
            End If
        End If
        'Input�t�@�C����(MA)
        If IsNothing(Me._project.Ma_InputFile) = False Then
            relationNo = 0
            Dim ma_InputFile As Ma_InputFileList
            For Each ma_InputFile In Me._project.Ma_InputFile
                Me.htMa_FileList.Add(relationNo, ma_InputFile)
                relationNo += 1
            Next
        End If
        'Input�t�@�C����(System x)
        If IsNothing(Me._project.X_InputFile) = False Then
            relationNo = 0
            Dim x_InputFile As X_InputFileList
            For Each x_InputFile In Me._project.X_InputFile
                Me.htX_FileList.Add(relationNo, x_InputFile)
                Me.Lst_File_X.Items.Add(Path.GetFileName(x_InputFile.Excel))
                relationNo += 1
            Next
        End If
        'Input�t�@�C����(CISCO)
        If IsNothing(Me._project.CiscoInputFile) = False Then
            relationNo = 0
            Dim cisco_InputFile As Cisco_InputFileList
            For Each cisco_InputFile In Me._project.CiscoInputFile
                Me.htCisco_FileList.Add(relationNo, cisco_InputFile)
                Me.Lst_File_Cisco.Items.Add(Path.GetFileName(cisco_InputFile.eBS_Sale))
                relationNo += 1
            Next
        End If
        'FMA
        If IsNothing(Me._project.FmaInputFile) = False Then
            relationNo = 0
            Dim fma_InputFile As FMA_InputFileList
            For Each fma_InputFile In Me._project.FmaInputFile
                Me.htFMA_FileList.Add(relationNo, fma_InputFile)
                Me.Lst_File_Fma.Items.Add(Path.GetFileName(fma_InputFile.Word))
                relationNo += 1
            Next
        End If
        'zSW
        If IsNothing(Me._project.zSWInputFile) = False Then
            relationNo = 0
            Dim zswInputFile As Zsw_InputFileList
            For Each zswInputFile In Me._project.zSWInputFile
                Me.htZsw_FileList.Add(relationNo, zswInputFile)
                Me.Lst_File_Zsw.Items.Add(Path.GetFileName(zswInputFile.HtmlFile))
                relationNo += 1
            Next
        End If
        If Me._project.zSW_NoChange = CommonConstant.ParamzSwType.CheckON Then
            Me.chkzSwNoChange.Checked = True
        Else
            Me.chkzSwNoChange.Checked = False
        End If

        '�ێ炻�̑�
        Select Case Me._project.Mainte_Others
            Case CommonConstant.ParamMainteOthers.Sale
                Me.Rdo_MainteOthersSale.Checked = True
            Case CommonConstant.ParamMainteOthers.SaleMainte
                Me.Rdo_MainteOthersSaleMainte.Checked = True
            Case CommonConstant.ParamMainteOthers.SaleSvc
                Me.Rdo_MainteOthersSaleSvc.Checked = True
        End Select
        '�ێ���z
        Select Case Me._project.Mainte_Amount
            Case CommonConstant.ParamMainteAmount.Monthly
                Me.Rdo_MainteAmountMonthly.Checked = True
            Case CommonConstant.ParamMainteAmount.Annual
                Me.Rdo_MainteAmountAnnual.Checked = True
        End Select

        Select Case Me._project.MainteSystem
            Case CommonConstant.ParamMaintSystem.Chis
                Me.Rdo_MainteSystemChis.Checked = True
            Case CommonConstant.ParamMaintSystem.Maps
                Me.Rdo_MainteSystemMaps.Checked = True
        End Select

        '�ێ玞�ԑ�
        Select Case Me._project.Mainte_Time
            Case CommonConstant.ParamMainteTime.MonSat12h
                Me.Rdo_MainteTimeMonSat12h.Checked = True
            Case CommonConstant.ParamMainteTime.MonSun12h
                Me.Rdo_MainteTimeMonSun12h.Checked = True
            Case CommonConstant.ParamMainteTime.MonSun18h
                Me.Rdo_MainteTimeMonSun18h.Checked = True
            Case CommonConstant.ParamMainteTime.MonSun24h
                Me.Rdo_MainteTimeMonSun24h.Checked = True
        End Select
        'SVCPAC����
        Select Case Me._project.Svc_Tearm
            Case CommonConstant.ParamSvcTerm.Year1
                Me.Rdo_SvcTerm1Year.Checked = True
            Case CommonConstant.ParamSvcTerm.Years2
                Me.Rdo_SvcTerm2Years.Checked = True
            Case CommonConstant.ParamSvcTerm.Years3
                Me.Rdo_SvcTerm3Years.Checked = True
            Case CommonConstant.ParamSvcTerm.Years4
                Me.Rdo_SvcTerm4Years.Checked = True
            Case CommonConstant.ParamSvcTerm.Years5
                Me.Rdo_SvcTerm5Years.Checked = True
        End Select
        'SVCPAC���
        Select Case Me._project.Svc_Type
            Case CommonConstant.ParamSvcType.Repair
                Me.Rdo_SvcTypeRepair.Checked = True
            Case CommonConstant.ParamSvcType.SuperServicePlus
                Me.Rdo_SvcTypeSuperServicePlus.Checked = True
            Case CommonConstant.ParamSvcType.BasicSelection
                Me.Rdo_SvcTypeBasicSelection.Checked = True
        End Select
        Select Case Me._project.CiscoSvcLevel
            Case CommonConstant.ParamCiscoSvcLevel.EsaBase
                Me.rbABase.Checked = True
            Case CommonConstant.ParamCiscoSvcLevel.EsaMid
                Me.rbAMid.Checked = True
            Case CommonConstant.ParamCiscoSvcLevel.EsaHalf
                Me.rbAHalf.Checked = True
            Case CommonConstant.ParamCiscoSvcLevel.EsaFull
                Me.rbAFull.Checked = True
            Case CommonConstant.ParamCiscoSvcLevel.EsbBase
                Me.rbBBase.Checked = True
            Case CommonConstant.ParamCiscoSvcLevel.EsbMid
                Me.rbBMid.Checked = True
            Case CommonConstant.ParamCiscoSvcLevel.EsbHalf
                Me.rbBHalf.Checked = True
            Case CommonConstant.ParamCiscoSvcLevel.EsbFull
                Me.rbBFull.Checked = True
        End Select
        '���i���̎擾��
        Select Case Me._project.X_DescriptionTarget
            Case CommonConstant.ParamDescriptionTarget.Ebs
                Me.Rdo_x_DescriptionTarget_eBs.Checked = True
            Case CommonConstant.ParamDescriptionTarget.Mdb
                Me.Rdo_x_DescriptionTarget_mdb.Checked = True
            Case CommonConstant.ParamDescriptionTarget.Master
                Me.Rdo_x_DescriptionTarget_Master.Checked = True
        End Select
        '��PA/IASC��
        '���x��
        If Not Me._project.Pa_Level Is Nothing Then
            Me.Cmb_ChargeLevel.Text = Me._project.Pa_Level
        Else
            Me.Cmb_ChargeLevel.Text = CommonVariable.PALEVEL
        End If

        '�A�j�o�[�T���[
        If Not Me._project.Pa_Anniversary Is Nothing Then
            Me.Cmb_Pa_Anniversary.SelectedValue = Me._project.Pa_Anniversary
        Else
            Me.Cmb_Pa_Anniversary.SelectedValue = CommonVariable.ANNIVERSARY
        End If
        'PA�ԍ�
        Me.Txt_Pa_NO.Text = Me._project.Pa_NO
        '���̓f�[�^1
        Me.Txt_Pa_InputData1.Text = Me._project.Pa_InputData1
        '���̓f�[�^2
        Me.Txt_Pa_InputData2.Text = Me._project.Pa_InputData2
        '��IASC��
        '���̓f�[�^
        Me.Txt_Iasc_InputData.Text = Me._project.Iasc_InputData

        'SYSTEM X �֘A�t�@�C���w��{�^��
        If Rdo_x_DescriptionTarget_Master.Checked = True Then
            Btn_X_SelectRelationFile.Enabled = False
        Else
            Btn_X_SelectRelationFile.Enabled = True
        End If

        'MVMS
        Select Case Me._project.Mvms_Target
            Case CommonConstant.ParamMvmsTarget.Notes
                Me.Rdo_Mvms_Notes.Checked = True
            Case CommonConstant.ParamMvmsTarget.Display
                Me.Rdo_Mvms_Display.Checked = True
        End Select
        Me.Txt_Mvms_InputData.Text = Me._project.Mvms_InputData

    End Function

    '--------------------------------------------------------
    '���\�b�h���FGetInputValue
    '�T    �v  �F��ʓ��͒l�擾����
    '��    ��  �F��ʓ��͒l�擾�������s��
    '��    ��  �F�Ȃ�
    '�� �� �l  �F�Ȃ�
    '--------------------------------------------------------
    Private Function GetInputValue() As Boolean

        GetInputValue = True

        '==============================================================
        '�����ʍ��ځ�
        '==============================================================
        Dim arPlan() As String
        If Me._psLine.isNLine = True Then
            If Me.lblPlanNo.Text.Trim <> "" Then
                arPlan = Me.lblPlanNo.Text.Split("_")
            Else
                MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0070"), Me.Text)
                Return False
            End If
        Else
            If Me.cmbPlanNO.Text <> "" Then
                arPlan = Me.cmbPlanNO.Text.Split("_")
            Else
                MuseMessageBox.ShowError(FileReader.GetMessage("MSG_0070"), Me.Text)
                Return False
            End If
        End If

        '�v���W�F�N�g��
        Me._project.ProjectName = arPlan(1)
        '����
        Me._project.Introduction = Me.Dp_Introduction.Text
        'OIO���ԊJ�n
        Me._project.StartTime = Me.Dp_StartTime.Text
        'OIO���ԏI��
        Me._project.EndTime = Me.Dp_EndTime.Text
        'SYSTEM�����Œ��1�ݒ�
        Me._project.SystemQuantity = 1
        '���i������
        Me._project.DescriptionLanguage = 1
        'CPNO
        Me._project.CpNo = CommonVariable.CPNO
        '�_�񏇔�
        Me._project.ContractNo = lblContractNo.Text
        '�����J�n�N��
        Me._project.PayStartTime = Format(Me.Dp_PayStart.Value, "yyyy/MM")
        '�����I���N��
        Me._project.PayEndTime = Format(Me.Dp_PayEnd.Value, "yyyy/MM")
        '�Č��ԍ�
        Me._project.PlanNo = arPlan(0)
        If Me.Rdo_MainteSystemChis.Checked = True Then
            Me._project.MainteSystem = CommonConstant.ParamMaintSystem.Chis
        Else
            Me._project.MainteSystem = CommonConstant.ParamMaintSystem.Maps
        End If

        Dim relationNo As Integer
        'Input�t�@�C����(Config)
        Dim inputFiles(Me.htFileList.Count - 1) As InputFileList
        For relationNo = 0 To Me.htFileList.Count - 1
            inputFiles(relationNo) = New InputFileList
            inputFiles(relationNo) = Me.htFileList(relationNo)
            inputFiles(relationNo).InputQuantity = dgv_File_Config.Rows(relationNo).Cells(1).Value
        Next
        Me._project.InputFile = inputFiles
        'Input�t�@�C����(����MA���\��)
        Dim maEx_InputFiles(Me.htMaEx_FileList.Count - 1) As MaEx_InputFileList
        For relationNo = 0 To Me.htMaEx_FileList.Count - 1
            maEx_InputFiles(relationNo) = New MaEx_InputFileList
            maEx_InputFiles(relationNo) = Me.htMaEx_FileList(relationNo)
        Next
        Me._project.MaEx_InputFile = maEx_InputFiles
        'Input�t�@�C����(����MAISAT����)
        Dim maIsat_InputFiles(Me.htMaIsat_FileList.Count - 1) As MaIsat_InputFileList
        For relationNo = 0 To Me.htMaIsat_FileList.Count - 1
            maIsat_InputFiles(relationNo) = New MaIsat_InputFileList
            maIsat_InputFiles(relationNo) = Me.htMaIsat_FileList(relationNo)
        Next
        Me._project.MaIsat_InputFile = maIsat_InputFiles
        'Input�t�@�C����(MA)
        Dim ma_InputFiles(Me.htMa_FileList.Count - 1) As Ma_InputFileList
        For relationNo = 0 To Me.htMa_FileList.Count - 1
            ma_InputFiles(relationNo) = New Ma_InputFileList
            ma_InputFiles(relationNo) = Me.htMa_FileList(relationNo)
        Next
        Me._project.Ma_InputFile = ma_InputFiles
        'Input�t�@�C����(System x)
        Dim x_InputFiles(Me.htX_FileList.Count - 1) As X_InputFileList
        For relationNo = 0 To Me.htX_FileList.Count - 1
            x_InputFiles(relationNo) = New X_InputFileList
            x_InputFiles(relationNo) = Me.htX_FileList(relationNo)
        Next
        Me._project.X_InputFile = x_InputFiles
        'Input�t�@�C����(System z�\�t�g�E�F�A)
        Dim zSw_InputFiles(Me.htZsw_FileList.Count - 1) As Zsw_InputFileList
        For relationNo = 0 To Me.htZsw_FileList.Count - 1
            zSw_InputFiles(relationNo) = New Zsw_InputFileList
            zSw_InputFiles(relationNo) = Me.htZsw_FileList(relationNo)
        Next
        Me._project.zSWInputFile = zSw_InputFiles
        If chkzSwNoChange.Checked = True Then
            Me._project.zSW_NoChange = CommonConstant.ParamzSwType.CheckON
        Else
            Me._project.zSW_NoChange = CommonConstant.ParamzSwType.CheckOFF
        End If
        'Input�t�@�C����(CISCO)
        Dim cisco_InputFiles(Me.htCisco_FileList.Count - 1) As Cisco_InputFileList
        For relationNo = 0 To Me.htCisco_FileList.Count - 1
            cisco_InputFiles(relationNo) = New Cisco_InputFileList
            cisco_InputFiles(relationNo) = Me.htCisco_FileList(relationNo)
        Next
        Me._project.CiscoInputFile = cisco_InputFiles
        '�ێ炻�̑�
        If Me.Rdo_MainteOthersSale.Checked = True Then
            Me._project.Mainte_Others = CommonConstant.ParamMainteOthers.Sale
        ElseIf Me.Rdo_MainteOthersSaleMainte.Checked = True Then
            Me._project.Mainte_Others = CommonConstant.ParamMainteOthers.SaleMainte
        ElseIf Me.Rdo_MainteOthersSaleSvc.Checked = True Then
            Me._project.Mainte_Others = CommonConstant.ParamMainteOthers.SaleSvc
        End If


        '�ێ���z
        If Me.Grp_MainteAmount.Visible = True Then
            If Me.Rdo_MainteAmountMonthly.Checked = True Then
                Me._project.Mainte_Amount = CommonConstant.ParamMainteAmount.Monthly
            ElseIf Me.Rdo_MainteAmountAnnual.Checked = True Then
                Me._project.Mainte_Amount = CommonConstant.ParamMainteAmount.Annual
            End If
        Else
            Me._project.Mainte_Amount = Nothing
        End If

        ''�ێ�V�X�e��
        If Me.Rdo_MainteSystemChis.Checked = True Then
            Me._project.MainteSystem = CommonConstant.ParamMaintSystem.Chis
        ElseIf Rdo_MainteSystemMaps.Checked = True Then
            Me._project.MainteSystem = CommonConstant.ParamMaintSystem.Maps
        End If

        '�ێ玞�ԑ�
        If Me.Grp_MainteTime.Visible = True Then
            If Me.Rdo_MainteTimeMonSat12h.Checked = True Then
                Me._project.Mainte_Time = CommonConstant.ParamMainteTime.MonSat12h
                Me._project.MainteLevel = Me.Rdo_MainteTimeMonSat12h.Text
            ElseIf Me.Rdo_MainteTimeMonSun12h.Checked = True Then
                Me._project.Mainte_Time = CommonConstant.ParamMainteTime.MonSun12h
                Me._project.MainteLevel = Me.Rdo_MainteTimeMonSun12h.Text
            ElseIf Me.Rdo_MainteTimeMonSun18h.Checked = True Then
                Me._project.Mainte_Time = CommonConstant.ParamMainteTime.MonSun18h
                Me._project.MainteLevel = Me.Rdo_MainteTimeMonSun18h.Text
            ElseIf Me.Rdo_MainteTimeMonSun24h.Checked = True Then
                Me._project.Mainte_Time = CommonConstant.ParamMainteTime.MonSun24h
                Me._project.MainteLevel = Me.Rdo_MainteTimeMonSun24h.Text
            End If
        Else
            Me._project.Mainte_Time = Nothing
            Me._project.MainteLevel = Nothing
        End If
        'SVCPAC����
        If Me.Grp_SvcPacTerm.Visible = True Then
            If Me.Rdo_SvcTerm1Year.Checked = True Then
                Me._project.Svc_Tearm = CommonConstant.ParamSvcTerm.Year1
            ElseIf Me.Rdo_SvcTerm2Years.Checked = True Then
                Me._project.Svc_Tearm = CommonConstant.ParamSvcTerm.Years2
            ElseIf Me.Rdo_SvcTerm3Years.Checked = True Then
                Me._project.Svc_Tearm = CommonConstant.ParamSvcTerm.Years3
            ElseIf Me.Rdo_SvcTerm4Years.Checked = True Then
                Me._project.Svc_Tearm = CommonConstant.ParamSvcTerm.Years4
            ElseIf Me.Rdo_SvcTerm5Years.Checked = True Then
                Me._project.Svc_Tearm = CommonConstant.ParamSvcTerm.Years5
            End If
        Else
            Me._project.Svc_Tearm = Nothing
        End If
        'SVCPAC���
        If Me.Grp_SvcPacType.Visible = True Then
            If Me.Rdo_SvcTypeRepair.Checked = True Then
                Me._project.Svc_Type = CommonConstant.ParamSvcType.Repair
            ElseIf Me.Rdo_SvcTypeSuperServicePlus.Checked = True Then
                Me._project.Svc_Type = CommonConstant.ParamSvcType.SuperServicePlus
            ElseIf Me.Rdo_SvcTypeBasicSelection.Checked = True Then
                Me._project.Svc_Type = CommonConstant.ParamSvcType.BasicSelection
            End If
        Else
            Me._project.Svc_Type = Nothing
        End If
        If grpCisco.Visible = True Then
            If Me.rbABase.Checked = True Then
                Me._project.CiscoSvcLevel = CommonConstant.ParamCiscoSvcLevel.EsaBase
            ElseIf Me.rbAMid.Checked = True Then
                Me._project.CiscoSvcLevel = CommonConstant.ParamCiscoSvcLevel.EsaMid
            ElseIf Me.rbAHalf.Checked = True Then
                Me._project.CiscoSvcLevel = CommonConstant.ParamCiscoSvcLevel.EsaHalf
            ElseIf Me.rbAFull.Checked = True Then
                Me._project.CiscoSvcLevel = CommonConstant.ParamCiscoSvcLevel.EsaFull
            ElseIf Me.rbBBase.Checked = True Then
                Me._project.CiscoSvcLevel = CommonConstant.ParamCiscoSvcLevel.EsbBase
            ElseIf Me.rbBMid.Checked = True Then
                Me._project.CiscoSvcLevel = CommonConstant.ParamCiscoSvcLevel.EsbMid
            ElseIf Me.rbBHalf.Checked = True Then
                Me._project.CiscoSvcLevel = CommonConstant.ParamCiscoSvcLevel.EsbHalf
            ElseIf Me.rbBFull.Checked = True Then
                Me._project.CiscoSvcLevel = CommonConstant.ParamCiscoSvcLevel.EsbFull
            End If
        End If
        '���i���̎擾��
        If Me.Rdo_x_DescriptionTarget_eBs.Checked = True Then
            Me._project.X_DescriptionTarget = CommonConstant.ParamDescriptionTarget.Ebs
        ElseIf Me.Rdo_x_DescriptionTarget_Master.Checked = True Then
            Me._project.X_DescriptionTarget = CommonConstant.ParamDescriptionTarget.Master
        End If
        If Me.Rdo_AAS_DescriptionTarget_eBs.Checked = True Then
            Me._project.AAS_DescriptionTarget = CommonConstant.ParamDescriptionTarget.Ebs
        ElseIf Me.Rdo_AAS_DescriptionTarget_Master.Checked = True Then
            Me._project.AAS_DescriptionTarget = CommonConstant.ParamDescriptionTarget.Master
        End If

        '��PA��
        '���x��
        Me._project.Pa_Level = Me.Cmb_ChargeLevel.Text
        '�A�j�o�[�T���[
        Me._project.Pa_Anniversary = Me.Cmb_Pa_Anniversary.SelectedValue
        'PA�ԍ�
        Me._project.Pa_NO = Me.Txt_Pa_NO.Text
        '���̓f�[�^1
        Me._project.Pa_InputData1 = Me.Txt_Pa_InputData1.Text
        '���̓f�[�^2
        Me._project.Pa_InputData2 = Me.Txt_Pa_InputData2.Text
        '��IASC��
        '���̓f�[�^
        Me._project.Iasc_InputData = Me.Txt_Iasc_InputData.Text
        'MVMS
        If Me.Rdo_Mvms_Notes.Checked = True Then
            Me._project.Mvms_Target = CommonConstant.ParamMvmsTarget.Notes
        ElseIf Me.Rdo_Mvms_Display.Checked = True Then
            Me._project.Mvms_Target = CommonConstant.ParamMvmsTarget.Display
        End If
        Me._project.Mvms_InputData = Me.Txt_Mvms_InputData.Text

        'Req.1614 Isat�捞���W�b�N�ύX 2018/03 Str
        'ISAT
        If Me.Rdo_UseClient.Checked = True Then
            Me._project.UseIsat = IsatTable.CD_USECLIENT
        ElseIf Me.Rdo_UseIsat.Checked = True Then
            Me._project.UseIsat = IsatTable.CD_USEISAT
        End If
        'Req.1614 Isat�捞���W�b�N�ύX 2018/03 End

    End Function

    '------------------------------------
    '�T �v�F�Č��֘A�����\��
    '�� ���F
    '------------------------------------
    Private Sub initFrmPlanInfo()

        Me._project.isNLine = Me._psLine.isNLine
        Me._project.FileName = Me._psLine.FileName
        If Me._psLine.isNLine = True Then
            Me.cmbPlanNO.Visible = False
            Call ShowRelationPlan()
        Else
            ''�l���
            lblPlanNo.Visible = False
            Call SetCbItemPlan()
            '1647 str
            'Dp_Introduction.Value = Date.Parse(Me._psLine.IntroductYM)
            'Dp_PayStart.Text = Date.Parse(Me._psLine.PayStartTime)
            'Dp_PayEnd.Text = Date.Parse(Me._psLine.PayEndTime)
            If Me._project.Project_Kbn = 1 Then
                Dp_Introduction.Value = Now.ToString("yyyy/MM")
                Dp_PayStart.Text = Now.AddMonths(1).ToString("yyyy/MM")
                '1647 �s���C��str
                'Dp_PayEnd.Text = Now.AddYears(3).ToString("yyyy/MM")
                Dp_PayEnd.Text = Date.Parse(Me._psLine.InitPayEndTime)
                '1647 �s���C��end
            Else
                Dp_Introduction.Value = Date.Parse(Me._psLine.IntroductYM)
                Dp_PayStart.Text = Date.Parse(Me._psLine.PayStartTime)
                Dp_PayEnd.Text = Date.Parse(Me._psLine.PayEndTime)
            End If

            '1647 end
            ''�K�{���͈��@���w�i�F=���F
            cmbPlanNO.BackColor = Color.Yellow
        End If

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FShowRelationPlan
    '�T    �v  �F�Č��֘A�����\��
    '��    ��  �F�Č��֘A�����\������
    '��    ��  �F�Ȃ�
    '�� �� �l  �F�Ȃ�
    '--------------------------------------------------------
    Private Sub ShowRelationPlan()
        Dim isMatchPlanNo As Boolean = False
        Dim indexItem As Integer = 0
        Dim arrPlan() As String
        Dim strPlanNoMod As String = String.Empty

        '�Č��ԍ����Z�b�g
        '�Č��ԍ��ɑO0�t��
        If Me._psLine.PlanNo IsNot Nothing Then
            arrPlan = Me._psLine.PlanNo.Split(".")
            If arrPlan(0).Length < 2 Then
                arrPlan(0) = "0" + arrPlan(0)
            End If
            If arrPlan(1).Length < 2 Then
                arrPlan(1) = "0" + arrPlan(1)
            End If
            If arrPlan(2).Length < 2 Then
                arrPlan(2) = "0" + arrPlan(2)
            End If
            If arrPlan(3).Length < 2 Then
                arrPlan(3) = "0" + arrPlan(3)
            End If

            SetLblPlan(arrPlan(0), arrPlan(1), arrPlan(2), arrPlan(3))

        End If

        If Me._psLine.IntroductYM IsNot Nothing Then
            '�����N�����Z�b�g
            Me.Dp_Introduction.Value = Date.Parse(Me._psLine.IntroductYM)
        End If

        If Me._psLine.PayStartTime IsNot Nothing Then
            '�����J�n�N�����Z�b�g
            Me.Dp_PayStart.Value = Date.Parse(Me._psLine.PayStartTime)
        End If

        If Me._psLine.PayEndTime IsNot Nothing Then
            '�����I���N�����Z�b�g
            If Not IsNothing(_project.PayEndTime) AndAlso _project.PayEndTime.Trim.Length > 0 Then
                Me.Dp_PayEnd.Value = Date.Parse(Me._project.PayEndTime)
            Else
                Me.Dp_PayEnd.Value = Date.Parse(Me._psLine.PayEndTime)
            End If

        End If

    End Sub

    '--------------------------------------------------------
    '���\�b�h���FSetCbItemPlan
    '�T    �v  �F�Č������ޯ�����
    '��    ��  �F
    '--------------------------------------------------------
    Private Sub SetCbItemPlan()

        Dim blnRet As Boolean
        Dim strMsg As String = ""
        Dim wc As New WebDb.WebDbCommon
        Dim Table As New M_PLANTable

        Try
            '�F�ؐݒ�
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW

            '�Č����擾
            blnRet = wc.GetPlanData(CommonVariable.CPNO, Table, strMsg)
            If blnRet = False Then
                MsgBox(strMsg, MsgBoxStyle.Critical, "SetCbItemPlan")
                Exit Sub
            End If

            ''�����ޯ�����
            cmbPlanNO.Items.Clear()
            Dim i As Integer
            Dim strPlanNo As String
            Dim isPlanExist As Boolean = False
            Dim chkValue As String
            chkValue = Me._psLine.PlanNo & "_" & Me._psLine.ProjectName
            Dim strOrderBy As String = "LEVEL1,LEVEL2,LEVEL3,LEVEL4"
            For Each row As DataRow In Table.Select(Nothing, strOrderBy)
                strPlanNo = row(M_PLANTable.COLUMN_NAME_LEVEL1).ToString() & "." &
                            row(M_PLANTable.COLUMN_NAME_LEVEL2).ToString() & "." &
                            row(M_PLANTable.COLUMN_NAME_LEVEL3).ToString() & "." &
                            row(M_PLANTable.COLUMN_NAME_LEVEL4).ToString()
                If chkValue = strPlanNo & "_" & row(M_PLANTable.COLUMN_NAME_PLAN_NAME).ToString() Then
                    isPlanExist = True
                End If
                Me.cmbPlanNO.Items.Add(strPlanNo & "_" & row(M_PLANTable.COLUMN_NAME_PLAN_NAME).ToString())
            Next
            ''�����l
            If isPlanExist = True Then
                strPlanNo = Me._psLine.PlanNo
                Me.cmbPlanNO.Text = strPlanNo & "_" & Me._psLine.ProjectName
            Else
                If Me.cmbPlanNO.Items.Count > 0 Then
                    Me.cmbPlanNO.SelectedIndex = 0
                End If
            End If

            Me._psLine.PlanNo = strPlanNo

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "SetCbItemPlan")
        End Try

    End Sub

    ''' <summary>
    ''' �T    �v  �F���x���ɒl���Z�b�g
    ''' </summary>
    ''' <param name="level1"></param>
    ''' <param name="level2"></param>
    ''' <param name="level3"></param>
    ''' <param name="level4"></param>
    ''' <remarks></remarks>
    Private Sub SetLblPlan(ByVal level1 As String, ByVal level2 As String, ByVal level3 As String, ByVal level4 As String)

        Dim strMsg As String = ""
        Dim blnRet As Boolean
        Dim wc As WebDb.WebDbCommon
        Dim dt As New M_PLANTable
        Dim strWhere As String = ""
        Dim strPlanNo As String

        Try
            '�F�ؐݒ�
            wc.IntraId = CommonVariable.USERID
            wc.IntraPass = CommonVariable.USERPW

            '�Č����擾
            blnRet = wc.GetPlanData(CommonVariable.CPNO, dt, strMsg)
            If blnRet = False Then
                Throw New Exception(strMsg)
                Exit Sub
            End If

            'LEVEL1,LEVEL2,LEVEL3,LEVEL4
            strWhere = strWhere & "LEVEL1 ='" & level1 & "' AND "
            strWhere = strWhere & "LEVEL2 ='" & level2 & "' AND "
            strWhere = strWhere & "LEVEL3 ='" & level3 & "' AND "
            strWhere = strWhere & "LEVEL4 ='" & level4 & "'"

            Dim rows() As DataRow = dt.Select(strWhere)

            strPlanNo = level1 & "." & level2 & "." & level3 & "." & level4
            If rows.Length > 0 Then
                strPlanNo = strPlanNo & "_" & rows(0).Item(M_PLANTable.COLUMN_NAME_PLAN_NAME).ToString
            End If
            Me.lblPlanNo.Text = strPlanNo

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "SetLblPlan")
        End Try

    End Sub

    ''' <summary>
    ''' �T  �v�F�Q�ƃ{�^���̃t�@�C���I���_�C�A�����O�{�b�N�X�̏����ʒu���w�肷��B
    ''' ��  ���FConfig\�Y���t�H���_���f�t�H���g�ʒu
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetFileSeletctDialogInitialPath() As String

        Dim strCpNo As String = CommonVariable.CPNO.Trim.PadLeft(8, "0")
        Dim strContractNO As String = CommonVariable.CONTRACTNO.ToString().PadLeft(3, "0c")
        Dim strPath As String

        GetFileSeletctDialogInitialPath = ""

        strPath = CommonConstant.FOLDERNAME_CONFIG & "\" & strCpNo & "_" & strContractNO
        Return FileManager.GetLocalFolderPath(strPath)

    End Function

#End Region

End Class