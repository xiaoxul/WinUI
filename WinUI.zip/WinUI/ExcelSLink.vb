﻿Imports System.IO
Imports System.Text
Imports System.Data.OleDb
Imports Microsoft.Office.Interop
Imports MUSE.Utility
Imports MUSE.Utility.OioBamaCommmon
Imports MUSE.Utility.SharedClass

Public Class ExcelSLink

#Region "Const"

    '------------------------------------------
    'Excel関連
    '------------------------------------------
    Private Const EXCEL_MAX_ROW As Integer = 65536      'EXCELの最終行
    Private Const EXCEL_COL_SLINK_DATA_SLINKNO As Integer = 1
    Private Const EXCEL_COL_SLINK_DATA_WORKNO As Integer = 2
    Private Const EXCEL_ROWDATA_START_SLINK_DATA As Integer = 8
    Private Const EXCEL_ROW_SLINK_TEMPLATE As Integer = 4
    Private Const EXCEL_ROWDATA_START_SLINK_BASE As Integer = 2
    Private Const EXCEL_ROWDATA_START_SLINK_PRICING As Integer = 2

    Private Const CD_REF_DATE_BILLING As Integer = 0
    Private Const CD_REF_DATE_PAYMENT As Integer = 1
    Private Const STR_REF_DATE_BILLING As String = "Billing Dateを元に反映"
    Private Const STR_REF_DATE_PAYMENT As String = "Payment Dateを元に反映"
    Private Const STR_REF_Annuity As String = "Annuityデータ"
    '変更管理#43 ATOP対応 Str
    Private Const STR_REF_ATOP As String = "ATOPデータ"
    'Req.1581 MENU取込対応 2017/12 Str
    Private Const STR_REF_MENU As String = "MENUデータ"
    Private Const STR_REF_BILLING As String = "Billing Date"
    Private Const STR_REF_PAYMENT As String = "Payment Date"
    'Req.1581 MENU取込対応 2017/12 End

    Private fErr As Boolean = False

#End Region

#Region "Enum"
    'ﾃﾞｰﾀ取得用ｼｰﾄ
    Private Enum EXCEL_COL_SLINK_DATA
        SLinkNo = 1
        WorkNo
        Suffix
        Status
        BaseCnt
        WorkCnt
        SammaryCnt
        ConstCnt
        MenuCnt
        OemCnt
        Dummy
        Ref
        Check
        Dummy2
        PayMethod
        SvcStartDate
        SvcEndDate
        SvcTermCondition
        PayPeriod
        Price
        Cost
        Service
        CntrNo
        CntrName
        CntrTitle
        SvcName
        PricingType
        BusinessType
        SvcStart
        SvcEnd
        Revenue
        Aprvl
        BU
        Brand
        SubBrand
        DivideNo
        DivideYears
    End Enum

    '取得結果(基本情報)
    Private Enum EXCEL_COL_SLINK_BASE
        SLinkNo = 1
        WorkNo
        Suffix
        CntrStatus
        CntrCustNo
        CntrCustName
        CntrTitle
        ServiceName
        PricingType
        BusinessType
        SvcStartDate
        SvcEndDate
        RevenueAmount
        AprvlCost
        BU
        Brand
        SubBrand
        DivideNo
    End Enum

    '取得結果(Pricing)
    Private Enum EXCEL_COL_SLINK_PRICING
        SLinkNo = 1
        WorkSeqno
        PricingType
        BillingDate
        PaymentDate
        BillingAmount
        InvoiceText
        DivideCheck
        DivideNo
    End Enum

#End Region

#Region "Inner Class"

    'Paymentデータ
    Private Class PSExcelDataTable
        Inherits DataTable

        Public Sub New()

            Me.TableName = "PSExcelDataTable"

            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02, Type.GetType("System.String"))

            Me.Columns.Add("ExcelRow", Type.GetType("System.Int32"))
        End Sub
    End Class

    'ﾃﾞｰﾀ取得用ｼｰﾄ
    Private Class SLinkDataExcelDataTable
        Inherits DataTable

        Public Sub New()

            Me.TableName = "SLinkDataExcelDataTable"

            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.SLinkNo, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.WorkNo, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.Suffix, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.Status, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.BaseCnt, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.WorkCnt, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.SammaryCnt, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.ConstCnt, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.MenuCnt, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.OemCnt, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.Dummy, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.Ref, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.Check, Type.GetType("System.String"))
            Me.Columns.Add("ExcelRow", Type.GetType("System.Int32"))
            Me.Columns.Add("IntWorkNo", Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.Dummy2, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.PayMethod, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.SvcStartDate, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.SvcEndDate, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.SvcTermCondition, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.PayPeriod, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.Price, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.Cost, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.Service, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.CntrNo, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.CntrName, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.CntrTitle, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.SvcName, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.PricingType, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.BusinessType, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.SvcStart, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.SvcEnd, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.Revenue, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.Aprvl, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.BU, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.Brand, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.SubBrand, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.DivideNo, Type.GetType("System.Int32"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_DATA.DivideYears, Type.GetType("System.Int32"))
        End Sub
    End Class

    '取得結果(基本情報)
    Private Class SLinkBaseExcelDataTable
        Inherits DataTable

        Public Sub New()

            Me.TableName = "SLinkBaseExcelDataTable"

            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_BASE.SLinkNo, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_BASE.WorkNo, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_BASE.Suffix, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_BASE.CntrStatus, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_BASE.CntrCustNo, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_BASE.CntrCustName, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_BASE.CntrTitle, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_BASE.ServiceName, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_BASE.PricingType, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_BASE.BusinessType, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_BASE.SvcStartDate, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_BASE.SvcEndDate, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_BASE.RevenueAmount, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_BASE.AprvlCost, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_BASE.BU, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_BASE.Brand, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_BASE.SubBrand, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_BASE.DivideNo, Type.GetType("System.Int32"))

            Me.Columns.Add("ExcelRow", Type.GetType("System.Int32"))
        End Sub
    End Class

    '取得結果(Pricing)
    Private Class SLinkPricingExcelDataTable
        Inherits DataTable

        Public Sub New()

            Me.TableName = "SLinkPricingExcelDataTable"

            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_PRICING.SLinkNo, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_PRICING.WorkSeqno, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_PRICING.PricingType, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_PRICING.BillingDate, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_PRICING.PaymentDate, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_PRICING.BillingAmount, Type.GetType("System.Int64"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_PRICING.InvoiceText, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_PRICING.DivideCheck, Type.GetType("System.String"))
            Me.Columns.Add("CellNM" & EXCEL_COL_SLINK_PRICING.DivideNo, Type.GetType("System.Int32"))

            Me.Columns.Add("ExcelRow", Type.GetType("System.Int32"))
        End Sub
    End Class

#End Region

#Region "Structure"
    Private Structure PricngData
        Dim YearMonth As String
        Dim intAmount As Double
    End Structure

    Private Structure SLinkData
        Dim SLinkNo As String
        Dim WorkNo As String
        Dim Refrect As String
    End Structure
#End Region

#Region "Variable"
    Dim WS1PayPeriod As Integer     'WS1シートの保有年数。取込み時にDBの保有年数ではなくPSﾌｧｲﾙの保有年数を使用する。
#End Region

#Region "Public"

    ''' <summary>
    ''' 機能：S-LinkデータPayment反映処理
    ''' </summary>
    ''' <param name="strPSFileName"></param>
    ''' <param name="strSlinkFileName"></param>
    ''' <param name="intOutputCnt"></param>
    ''' <param name="waitDialog"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function InputSlink(ByVal strPSFileName As String,
                               ByVal strSlinkFileName As String,
                               ByRef intOutputCnt As Integer,
                               ByRef waitDialog As Frm_WaitDialog) As Boolean

        Dim blnRet As Boolean
        Dim PsData As PSExcelDataTable
        Dim SLinkData As SLinkDataExcelDataTable
        Dim SLinkBase As SLinkBaseExcelDataTable
        Dim SLinkPricing As SLinkPricingExcelDataTable
        Dim ew As New ExcelWrite
        Dim strDelRow() As String
        Dim xlApp As New Excel.Application
        Dim xlPsBook As Excel.Workbook
        Dim xlPsSheet As Excel.Worksheet
        Dim xlWs1Sheet As Excel.Worksheet

        InputSlink = False

        Try
            fErr = False

            Debug.Print(Now.ToString("HH:mm:ss") & "　開始")
            xlApp.EnableEvents = False
            xlApp.DisplayAlerts = False

            '------------------------------------------
            'Payment読込
            '------------------------------------------
            xlPsBook = xlApp.Workbooks.Open(strPSFileName)
            xlPsSheet = xlPsBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)
            'WS1シートの保有年数取得  　※cpno/strYearの戻り値は不要なのでdummyの変数を宣言
            Dim dummyCpno, rtnMsg As String
            Dim dummyYear As Integer
            xlWs1Sheet = xlPsBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_WS1)
            rtnMsg = ExcelWrite.GetWS1PayPeriod(strPSFileName, dummyCpno, dummyYear, Me.WS1PayPeriod)
            If rtnMsg <> "" Then Throw New Exception(rtnMsg)

            'Excelのオートフィルタを初期化
            Call ew.CrearAutoFilter(xlPsSheet)

            'Paymentの必要な項目のみ読込（項目１、項目２、Excel行位置）
            blnRet = GetPsData(strPSFileName, xlPsSheet, PsData)
            If blnRet = False Then
                Exit Function
            End If

            '------------------------------------------
            'S-Linkデータ取得用ファイル読込
            '------------------------------------------
            blnRet = GetSlinkData(strSlinkFileName, xlApp, SLinkData, SLinkBase, SLinkPricing, intOutputCnt)
            If blnRet = False Then
                Exit Function
            ElseIf intOutputCnt = 0 Then
                InputSlink = True
                Exit Function
            End If
            waitDialog.PerformStep()

            '------------------------------------------
            '削除データ検索
            '------------------------------------------
            blnRet = GetDeleteDataRow(PsData, SLinkData, strDelRow)
            If blnRet = False Then
                Exit Function
            End If
            waitDialog.PerformStep()

            '------------------------------------------
            'Payment出力
            '------------------------------------------
            blnRet = SlinkReflection(strSlinkFileName, strDelRow, SLinkData, SLinkBase, SLinkPricing, xlPsSheet)
            If blnRet = False Then
                Exit Function
            End If
            ExcelObjRelease.ReleaseExcelObj(xlPsSheet, ExcelObjRelease.OBJECT_NOTHING)
            waitDialog.PerformStep()

            'Bookの保存(別名保存のマクロをキックする)
            '※VBActNMListに統合
            Call ExcelWrite.KickVBABookSave(xlApp, xlPsBook, ExcelWrite.VBActNMList.SLINK取込, CommonVariable.USERID, CommonVariable.USERPW)

            Debug.Print(Now.ToString("HH:mm:ss") & "　終了")

            If fErr = True Then
                '取込時エラーがあれば、警告メッセージを出す
                MsgBox(FileReader.GetMessage("MSG_0540"), MsgBoxStyle.Exclamation)
            End If

            InputSlink = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "InputSlink")

        Finally
            'エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlWs1Sheet, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPsSheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlPsBook) = False Then
                xlPsBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlPsBook, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlPsBook, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()
        End Try

    End Function

    ''' <summary>
    ''' 機能：S-Linkデータ作成
    ''' </summary>
    ''' <param name="strPSFileName"></param>
    ''' <param name="intPsCount"></param>
    ''' <param name="strMsg"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function OutputSlink(ByVal strPSFileName As String,
                                ByRef intPsCount As Integer,
                                ByRef strMsg As String) As Boolean

        Dim blnRet As Boolean
        Dim PsData As PSExcelDataTable
        Dim SLinkData As SLinkDataExcelDataTable
        Dim ew As New ExcelWrite
        Dim strDestFile As String = ""
        Dim xlApp As New Excel.Application
        Dim xlPsBook As Excel.Workbook
        Dim xlPsSheet As Excel.Worksheet

        OutputSlink = False

        Try
            '------------------------------------------
            'Payment読込
            '------------------------------------------
            xlApp.EnableEvents = False
            xlPsBook = xlApp.Workbooks.Open(strPSFileName)
            xlPsSheet = xlPsBook.Worksheets(ExcelWrite.EXCEL_PAYMENTLINEDATE_PAYMENTSHEET)

            'Excelのオートフィルタを初期化
            Call ew.CrearAutoFilter(xlPsSheet)

            'Paymentの必要な項目のみ読込（項目１、項目２、Excel行位置）
            blnRet = GetPsData(strPSFileName, xlPsSheet, PsData)
            If blnRet = False Then
                Exit Function
            End If
            ''1543 S-Link連携ファイルの作成機能変更 START
            'intPsCount = PsData.Rows.Count
            'If intPsCount = 0 Then
            '    OutputSlink = True
            '    Exit Function
            'End If
            ''1543 S-Link連携ファイルの作成機能変更 END
            ExcelObjRelease.ReleaseExcelObj(xlPsSheet, ExcelObjRelease.OBJECT_NOTHING)
            xlPsBook.Close(False)
            ExcelObjRelease.ReleaseExcelObj(xlPsBook, ExcelObjRelease.OBJECT_NOTHING)

            '------------------------------------------
            'フォルダ作成、テンプレートコピー
            '------------------------------------------
            blnRet = MakeFolderFileCopy(strDestFile)
            If blnRet = False Then
                Exit Function
            End If

            '------------------------------------------
            'S-LINKデータ出力
            '------------------------------------------
            blnRet = OutputSlinkData(strDestFile, PsData, xlApp)
            If blnRet = False Then
                Exit Function
            End If

            OutputSlink = True

        Catch ex As Exception
            strMsg = ex.Message.ToString & "(OutputSlink)"

        Finally
            xlApp.EnableEvents = True
            'エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlPsSheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlPsBook) = False Then
                xlPsBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlPsBook, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlApp) = False Then
                xlApp.Quit()
            End If
            ExcelObjRelease.ReleaseExcelObj(xlApp, ExcelObjRelease.OBJECT_NOTHING)

        End Try

    End Function

#End Region

#Region "Private"

#Region "共通"
    ''' <summary>
    ''' 機能：Paymentの必要な項目のみ読込（項目１、項目２、Excel行位置）と最大LINE_NO取得
    ''' ※S-LINKかつ数量が０以上のデータ
    ''' </summary>
    ''' <param name="strPSFileName"></param>
    ''' <param name="xlSheet"></param>
    ''' <param name="PsData"></param>
    ''' <param name="strMaxLineNo"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetPsData(ByVal strPSFileName As String,
                               ByVal xlSheet As Excel.Worksheet,
                               ByRef PsData As PSExcelDataTable) As Boolean

        Dim xlRange As Excel.Range
        Dim intRowCnt As Integer
        Dim intColIndex As Integer
        Dim strQty As String
        Dim strWork As String

        GetPsData = False

        Try
            PsData = New PSExcelDataTable

            For intRowCnt = ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW To EXCEL_MAX_ROW

                xlRange = xlSheet.Range(ExcelWrite.EXCEL_PAYMENT_LINE_RANGE.Replace("@", intRowCnt.ToString))

                'EOF判定
                If ExcelWrite.changeDBNullToString(xlRange(1, ExcelWrite.ExcelPaymentLineColumn.LINE_NO).Value) = "" Then
                    Exit For
                End If

                'ロックフラグ
                If ExcelWrite.changeDBNullToString(xlRange(1, ExcelWrite.ExcelPaymentLineColumn.LOCK_FLAG).Value).Trim = "C" Then
                    Continue For
                End If

                'S-LINKのみ読込
                If ExcelWrite.changeDBNullToString(xlRange(1, ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD).Value) <> "22" Then
                    Continue For
                End If

                strQty = ExcelWrite.changeDBNullToString(xlRange(1, ExcelWrite.ExcelPaymentLineColumn.QTY).Value)
                If IsNumeric(strQty) Then
                    If Integer.Parse(strQty) < 0 Then
                        Continue For
                    End If
                End If

                'Paymentの値をセットする
                Dim row As DataRow
                row = PsData.NewRow

                '項目１（S-Link）
                intColIndex = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01
                row("CellNM" & intColIndex) = ExcelWrite.changeDBNullToString(xlRange(1, intColIndex).Value)
                '項目２（Work番号）
                intColIndex = ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02
                strWork = ExcelWrite.changeDBNullToString(xlRange(1, intColIndex).Value)
                If IsNumeric(strWork) = True Then
                    row("CellNM" & intColIndex) = CInt(strWork)
                Else
                    row("CellNM" & intColIndex) = strWork
                End If
                row("ExcelRow") = intRowCnt

                PsData.Rows.Add(row)

                ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            Next

            GetPsData = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "GetPsData")

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            GC.Collect()

        End Try

    End Function

#End Region

#Region "作成関連"
    ''' <summary>
    ''' 機能：フォルダ作成、テンプレートコピー
    ''' </summary>
    ''' <param name="strDestFile"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function MakeFolderFileCopy(ByRef strDestFile As String) As Boolean

        Const STR_FOLDER As String = "S-Linkデータ取得"

        Dim strFolder As String = STR_FOLDER & "_" & Now.ToString("yyyyMMdd_HHmmss")
        Dim ofm As New OioFileManage
        Dim strSourceFile As String

        MakeFolderFileCopy = False

        Try
            '-----------------------------
            'フォルダ
            '-----------------------------
            strFolder = ofm.GetLocalOutputCPNOFolder(CommonVariable.CPNO, CommonVariable.CONTRACTNO) & strFolder & "\"
            If Directory.Exists(strFolder) = False Then
                Directory.CreateDirectory(strFolder)
            End If
            If Directory.Exists(strFolder & "S-Link依頼ﾌｧｲﾙ\") = False Then
                Directory.CreateDirectory(strFolder & "S-Link依頼ﾌｧｲﾙ\")
            End If
            If Directory.Exists(strFolder & "S-Link結果ﾌｧｲﾙ\") = False Then
                Directory.CreateDirectory(strFolder & "S-Link結果ﾌｧｲﾙ\")
            End If

            '-----------------------------
            'Templateコピー
            '-----------------------------
            strDestFile = strFolder & "S-Link依頼ﾌｧｲﾙ\" & "S-Linkﾃﾞｰﾀ取得_" & CommonVariable.CPNO & "_" & Now.ToString("yyyyMMdd_HHmm") & ".xlsm"
            strSourceFile = ofm.GetLocalSLinlkTemplatePath

            File.Copy(strSourceFile, strDestFile)

            MakeFolderFileCopy = True

        Catch ex As Exception
            Throw ex

        End Try

    End Function

    ''' <summary>
    ''' 機能：S-LINKデータ出力
    ''' </summary>
    ''' <param name="strDestFile"></param>
    ''' <param name="PsData"></param>
    ''' <param name="xlApp"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function OutputSlinkData(ByVal strDestFile As String,
                                     ByVal PsData As PSExcelDataTable,
                                     ByVal xlApp As Excel.Application) As Boolean

        Dim intCnt As Integer
        Dim strRange As String
        Dim objCellData(,) As Object
        Dim PsUniqueData As DataTable
        Dim blnRet As Boolean
        Dim xlBook As Excel.Workbook
        Dim xlSheet As Excel.Worksheet
        Dim xlCell As Excel.Range = Nothing
        Dim xlRange As Excel.Range

        OutputSlinkData = False

        Try
            xlBook = xlApp.Workbooks.Open(strDestFile)
            xlSheet = xlBook.Worksheets(ExcelWrite.EXCEL_SHEET_SLINK_DATA)

            '-----------------------------
            '重複データグループ化
            '-----------------------------
            PsUniqueData = PsData.DefaultView.ToTable(True,
                                                      "CellNm" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01,
                                                      "CellNm" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02)

            '-----------------------------
            '罫線作成
            '-----------------------------
            '罫線設定
            Const DIVISION_LINES As Integer = 1000
            Dim intPsCount = PsUniqueData.Rows.Count
            Dim intSho As Integer = intPsCount \ DIVISION_LINES
            Dim intAmari As Integer = intPsCount Mod DIVISION_LINES

            xlSheet.Rows(EXCEL_ROW_SLINK_TEMPLATE.ToString).Hidden = False

            ''1543 S-Link連携ファイルの作成機能変更 START
            If intPsCount = 0 Then
                intSho = 0
                intAmari = 5
            End If
            ''1543 S-Link連携ファイルの作成機能変更 END

            For intCnt = 1 To intSho
                strRange = EXCEL_ROW_SLINK_TEMPLATE.ToString & ":" & EXCEL_ROW_SLINK_TEMPLATE.ToString
                xlCell = xlSheet.Range(strRange)
                xlCell.Copy()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                strRange = (EXCEL_ROWDATA_START_SLINK_DATA + (intCnt - 1) * DIVISION_LINES).ToString() & ":" & (EXCEL_ROWDATA_START_SLINK_DATA + intCnt * DIVISION_LINES - 1).ToString()
                xlCell = xlSheet.Range(strRange)
                xlCell.PasteSpecial()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            Next
            If intAmari <> 0 Then
                strRange = EXCEL_ROW_SLINK_TEMPLATE.ToString & ":" & EXCEL_ROW_SLINK_TEMPLATE.ToString
                xlCell = xlSheet.Range(strRange)
                xlCell.Copy()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                strRange = (EXCEL_ROWDATA_START_SLINK_DATA + (intSho * DIVISION_LINES)).ToString() & ":" & (EXCEL_ROWDATA_START_SLINK_DATA + (intSho * DIVISION_LINES + intAmari) - 1).ToString()
                xlCell = xlSheet.Range(strRange)
                xlCell.PasteSpecial()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            End If

            xlSheet.Rows(EXCEL_ROW_SLINK_TEMPLATE.ToString).Hidden = True

            '-----------------------------
            'データ出力\
            '-----------------------------
            strRange = "B" & EXCEL_ROWDATA_START_SLINK_DATA.ToString & ":C" & (EXCEL_ROWDATA_START_SLINK_DATA + intPsCount - 1).ToString
            blnRet = ExcelWrite.GetCellValue(xlSheet, strRange, objCellData)

            intCnt = 1
            For Each row As DataRow In PsUniqueData.Select
                objCellData(intCnt, 1) = GetDbData(row, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01)
                objCellData(intCnt, 2) = GetDbData(row, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02)
                intCnt = intCnt + 1
            Next
            strRange = "B" & EXCEL_ROWDATA_START_SLINK_DATA.ToString & ":C" & (EXCEL_ROWDATA_START_SLINK_DATA + intPsCount - 1).ToString
            xlCell = xlSheet.Range(strRange)
            xlCell.Value = objCellData
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            xlBook.Save()

            OutputSlinkData = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "OutputSlinkData")

        Finally
            'エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBook) = False Then
                xlBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Function

#End Region

#Region "読込関連"

    ''' <summary>
    ''' 機能：S-Linkデータ取得用ファイル読込
    ''' </summary>
    ''' <param name="strSlinkFileName"></param>
    ''' <param name="xlApp"></param>
    ''' <param name="SLinkData"></param>
    ''' <param name="SLinkBase"></param>
    ''' <param name="SLinkPricing"></param>
    ''' <param name="intOutputCnt"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetSlinkData(ByVal strSlinkFileName As String,
                                  ByVal xlApp As Excel.Application,
                                  ByRef SLinkData As SLinkDataExcelDataTable,
                                  ByRef SLinkBase As SLinkBaseExcelDataTable,
                                  ByRef SLinkPricing As SLinkPricingExcelDataTable,
                                  ByRef intOutputCnt As Integer) As Boolean

        Dim ew As New ExcelWrite
        Dim intRowCnt As Integer
        Dim intColCnt As Integer
        Dim strRange As String
        Dim strWork As String

        Dim xlBook As Excel.Workbook
        Dim xlSheet As Excel.Worksheet
        Dim xlRange As Excel.Range

        GetSlinkData = False

        Try
            xlBook = xlApp.Workbooks.Open(strSlinkFileName)

            '先にAnnuityかどうかを取得する必要があるため、先にデータ取得用シートを読む
            '------------------------------------------
            'ﾃﾞｰﾀ取得用ｼｰﾄ読込
            '------------------------------------------
            SLinkData = New SLinkDataExcelDataTable
            xlSheet = xlBook.Worksheets(ExcelWrite.EXCEL_SHEET_SLINK_DATA)
            'Excelのオートフィルタを初期化
            Call ew.CrearAutoFilter(xlSheet)

            Dim wInt1 As Integer = 0
            Dim SData() As SLinkData

            For intRowCnt = EXCEL_ROWDATA_START_SLINK_DATA To EXCEL_MAX_ROW
                strRange = "A@:M@"
                xlRange = xlSheet.Range(strRange.Replace("@", intRowCnt.ToString))

                'EOF判定
                If ExcelWrite.changeDBNullToString(xlRange(1, EXCEL_COL_SLINK_DATA.SLinkNo + 1).Value) = "" Then
                    Exit For
                End If

                wInt1 = wInt1 + 1
                ReDim Preserve SData(wInt1)

                SData(wInt1 - 1).SLinkNo = xlRange(1, EXCEL_COL_SLINK_DATA.SLinkNo + 1).value
                SData(wInt1 - 1).WorkNo = xlRange(1, EXCEL_COL_SLINK_DATA.WorkNo + 1).value
                SData(wInt1 - 1).Refrect = xlRange(1, EXCEL_COL_SLINK_DATA.Ref + 1).value
            Next

            '先に分割数を取得する必要があるため、さらにデータ取得用とPricingの処理順序入れ替えを実施。
            '------------------------------------------
            '取得結果(Pricing)読込
            '------------------------------------------
            SLinkPricing = New SLinkPricingExcelDataTable
            xlSheet = xlBook.Worksheets(ExcelWrite.EXCEL_SHEET_SLINK_PRICING)
            'Excelのオートフィルタを初期化
            Call ew.CrearAutoFilter(xlSheet)

            Dim DivideNo As Integer         '同一ID内分割連番
            Dim PreDivide As String         '前回分割 する/しない
            Dim PreSlinkNo As String = ""   '前回SLinkNo
            Dim PreWorkNo As String = ""    '前回WorkNo
            Dim PreOemYM As String = ""     '前回PricingType="OEM"の年月を保持
            Dim wDivNo As Integer           '分割数
            Dim wStr As String = ""         'For DEBUG
            Dim row As DataRow
            Dim wYearCnt As Integer         '年分割数
            Dim wDate As String
            Dim wLng As Long

            For intRowCnt = EXCEL_ROWDATA_START_SLINK_PRICING To EXCEL_MAX_ROW
                strRange = "A@:H@"
                xlRange = xlSheet.Range(strRange.Replace("@", intRowCnt.ToString))

                'EOF判定
                If ExcelWrite.changeDBNullToString(xlRange(1, EXCEL_COL_SLINK_PRICING.SLinkNo).Value) = "" Then
                    Exit For
                End If

                row = SLinkPricing.NewRow

                For intColCnt = EXCEL_COL_SLINK_PRICING.SLinkNo To EXCEL_COL_SLINK_PRICING.DivideCheck
                    If intColCnt = EXCEL_COL_SLINK_PRICING.BillingDate Or intColCnt = EXCEL_COL_SLINK_PRICING.PaymentDate Then
                        strWork = ExcelWrite.changeDBNullToString(xlRange(1, intColCnt).Value).Trim
                        If IsDate(strWork) = True Then
                            row("CellNM" & intColCnt) = Date.Parse(strWork).ToString("yyyy/MM/01")
                        Else
                            row("CellNM" & intColCnt) = strWork
                        End If
                    ElseIf intColCnt = EXCEL_COL_SLINK_PRICING.BillingAmount Then
                        row("CellNM" & intColCnt) = xlRange(1, intColCnt).Value
                    Else
                        row("CellNM" & intColCnt) = ExcelWrite.changeDBNullToString(xlRange(1, intColCnt).Value).Trim
                    End If
                Next

                '分割Noの取得
                If row("CellNM" & EXCEL_COL_SLINK_PRICING.SLinkNo) = PreSlinkNo And _
                   row("CellNM" & EXCEL_COL_SLINK_PRICING.WorkSeqno) = PreWorkNo And _
                   isAnnuity(SData, row("CellNM" & EXCEL_COL_SLINK_PRICING.SLinkNo), _
                                    row("CellNM" & EXCEL_COL_SLINK_PRICING.WorkSeqno)) = False Then
                    '今回分割="する" → 分割Noを繰り上げ
                    If row("CellNM" & EXCEL_COL_SLINK_PRICING.DivideCheck) = "する" Or _
                      (row("CellNM" & EXCEL_COL_SLINK_PRICING.PricingType) = "OEM" And _
                       CDate(row("CellNM" & EXCEL_COL_SLINK_PRICING.BillingDate)).ToString("yyyy/MM") <> PreOemYM) Then
                        DivideNo = DivideNo + 1
                    Else
                        '前回分割="する" → 分割Noを繰り上げ
                        If PreDivide = "する" Then
                            DivideNo = DivideNo + 1
                        End If
                    End If
                Else
                    'SLinkNo,WorkNoキーブレイク → 分割No初期化
                    DivideNo = 1
                    PreOemYM = ""
                End If

                row("CellNM" & EXCEL_COL_SLINK_PRICING.DivideNo) = DivideNo

                '今回の値保存
                PreSlinkNo = row("CellNM" & EXCEL_COL_SLINK_PRICING.SLinkNo)
                PreWorkNo = row("CellNM" & EXCEL_COL_SLINK_PRICING.WorkSeqno)
                PreDivide = row("CellNM" & EXCEL_COL_SLINK_PRICING.DivideCheck)
                PreOemYM = CDate(row("CellNM" & EXCEL_COL_SLINK_PRICING.BillingDate)).ToString("yyyy/MM")

                'Excelの行番号
                row("ExcelRow") = intRowCnt

                SLinkPricing.Rows.Add(row)
            Next

            '------------------------------------------
            'ﾃﾞｰﾀ取得用ｼｰﾄ読込
            '------------------------------------------
            SLinkData = New SLinkDataExcelDataTable
            xlSheet = xlBook.Worksheets(ExcelWrite.EXCEL_SHEET_SLINK_DATA)
            'Excelのオートフィルタを初期化
            Call ew.CrearAutoFilter(xlSheet)

            For intRowCnt = EXCEL_ROWDATA_START_SLINK_DATA To EXCEL_MAX_ROW
                strRange = "A@:AJ@"
                xlRange = xlSheet.Range(strRange.Replace("@", intRowCnt.ToString))

                'EOF判定
                If ExcelWrite.changeDBNullToString(xlRange(1, EXCEL_COL_SLINK_DATA.SLinkNo + 1).Value) = "" Then
                    Exit For
                End If

                'Req.1581 MENU取込対応 2017/12 Str
                '変更管理#43 ATOP対応 Str
                'If xlRange(1, EXCEL_COL_SLINK_DATA.Ref + 1).value = STR_REF_Annuity Or _
                '   xlRange(1, EXCEL_COL_SLINK_DATA.Ref + 1).value = STR_REF_ATOP Then
                If xlRange(1, EXCEL_COL_SLINK_DATA.Ref + 1).value = STR_REF_Annuity Or _
                    xlRange(1, EXCEL_COL_SLINK_DATA.Ref + 1).value = STR_REF_ATOP Or _
                    xlRange(1, EXCEL_COL_SLINK_DATA.Ref + 1).value = STR_REF_MENU Then
                    'If xlRange(1, EXCEL_COL_SLINK_DATA.Ref + 1).value = STR_REF_Annuity Then
                    '変更管理#43 ATOP対応 End
                    'Req.1581 MENU取込対応 2017/12 End
                    'Annuity分割(年で分割あり) =========================================
                    '分割年数取得
                    If xlRange(1, EXCEL_COL_SLINK_DATA.PayMethod + 1).value = "年額" Then
                        wYearCnt = GetYears(xlRange(1, EXCEL_COL_SLINK_DATA.SvcStartDate + 1).Value, _
                                            xlRange(1, EXCEL_COL_SLINK_DATA.SvcEndDate + 1).Value)
                    Else
                        wYearCnt = 1
                    End If
                    If IsDate(xlRange(1, EXCEL_COL_SLINK_DATA.SvcStartDate + 1).Value) Then
                        wDate = CDate(xlRange(1, EXCEL_COL_SLINK_DATA.SvcStartDate + 1).Value).ToString("yyyy/MM/dd")
                    End If

                    If wYearCnt = 0 Then
                        '日付が逆転→エラーあり
                        fErr = True
                    End If

                    '分割年数分のレコードを作成する
                    For ii As Integer = 1 To wYearCnt
                        row = SLinkData.NewRow

                        For intColCnt = EXCEL_COL_SLINK_DATA.SLinkNo To EXCEL_COL_SLINK_DATA.SubBrand
                            row("CellNM" & intColCnt) = ExcelWrite.changeDBNullToString(xlRange(1, intColCnt + 1).Value).Trim
                        Next

                        'Excelの行番号
                        row("ExcelRow") = intRowCnt

                        'Req.1581 MENU取込対応 2017/12 Str
                        '変更管理#43 ATOP対応 Str
                        'If xlRange(1, EXCEL_COL_SLINK_DATA.Ref + 1).value = STR_REF_Annuity Or _
                        '    xlRange(1, EXCEL_COL_SLINK_DATA.Ref + 1).value = STR_REF_ATOP Then
                        If xlRange(1, EXCEL_COL_SLINK_DATA.Ref + 1).value = STR_REF_Annuity Or _
                           xlRange(1, EXCEL_COL_SLINK_DATA.Ref + 1).value = STR_REF_ATOP Or _
                           xlRange(1, EXCEL_COL_SLINK_DATA.Ref + 1).value = STR_REF_MENU Then
                            'If xlRange(1, EXCEL_COL_SLINK_DATA.Ref + 1).value = STR_REF_Annuity Then
                            '変更管理#43 ATOP対応 End
                            'Req.1581 MENU取込対応 2017/12 End
                            If xlRange(1, EXCEL_COL_SLINK_DATA.PayMethod + 1).value = "年額" Then
                                row("CellNM" & EXCEL_COL_SLINK_DATA.SvcStartDate) = wDate
                                row("CellNM" & EXCEL_COL_SLINK_DATA.SvcEndDate) = CDate(wDate).AddYears(1).AddDays(-1).ToString("yyyy/MM/dd")
                            Else
                                row("CellNM" & EXCEL_COL_SLINK_DATA.SvcStartDate) = wDate

                                Dim wD As Date
                                If IsDate(xlRange(1, EXCEL_COL_SLINK_DATA.SvcEndDate + 1).Value) Then
                                    If IsDate(xlRange(1, EXCEL_COL_SLINK_DATA.SvcEndDate + 1).Value) Then
                                        '当月末日でセット
                                        '変更管理#43 ATOP対応 Str
                                        If xlRange(1, EXCEL_COL_SLINK_DATA.Ref + 1).value = STR_REF_Annuity Then
                                            row("CellNM" & EXCEL_COL_SLINK_DATA.SvcEndDate) = _
                                                CDate(CDate(xlRange(1, EXCEL_COL_SLINK_DATA.SvcEndDate + 1).Value).ToString("yyyy/MM/01")).AddMonths(1).AddDays(-1).ToString("yyyy/MM/dd")
                                        Else
                                            row("CellNM" & EXCEL_COL_SLINK_DATA.SvcEndDate) = _
                                                CDate(CDate(xlRange(1, EXCEL_COL_SLINK_DATA.SvcEndDate + 1).Value)).ToString("yyyy/MM/dd")
                                        End If
                                        'row("CellNM" & EXCEL_COL_SLINK_DATA.SvcEndDate) = _
                                        '    CDate(CDate(xlRange(1, EXCEL_COL_SLINK_DATA.SvcEndDate + 1).Value))
                                        '変更管理#43 ATOP対応 End
                                    Else
                                        row("CellNM" & EXCEL_COL_SLINK_DATA.SvcEndDate) = CDate(xlRange(1, EXCEL_COL_SLINK_DATA.SvcEndDate + 1).Value).ToString("yyyy/MM/dd")
                                    End If
                                Else
                                    '日付で無い時は、とりあえずそのままセット
                                    row("CellNM" & EXCEL_COL_SLINK_DATA.SvcEndDate) = xlRange(1, EXCEL_COL_SLINK_DATA.SvcEndDate + 1).Value
                                End If
                            End If
                        End If

                        row("CellNM" & EXCEL_COL_SLINK_DATA.DivideNo) = 1
                        row("CellNM" & EXCEL_COL_SLINK_DATA.DivideYears) = wYearCnt

                        If IsNumeric(ExcelWrite.changeDBNullToString(xlRange(1, EXCEL_COL_SLINK_DATA.WorkNo + 1).Value).Trim) = True Then
                            row("IntWorkNo") = CInt(ExcelWrite.changeDBNullToString(xlRange(1, EXCEL_COL_SLINK_DATA.WorkNo + 1).Value).Trim)
                        Else
                            row("IntWorkNo") = ExcelWrite.changeDBNullToString(xlRange(1, EXCEL_COL_SLINK_DATA.WorkNo + 1).Value).Trim
                        End If

                        SLinkData.Rows.Add(row)

                        '開始年を１年繰り上げる
                        If IsDate(wDate) Then
                            wDate = CDate(wDate).AddYears(1).ToString("yyyy/MM/dd")
                        End If
                    Next

                    '作成年数が0(日付逆転)の場合は、削除用にレコードを作成する
                    If wYearCnt = 0 Then
                        row = SLinkData.NewRow

                        For intColCnt = EXCEL_COL_SLINK_DATA.SLinkNo To EXCEL_COL_SLINK_DATA.SubBrand
                            row("CellNM" & intColCnt) = ExcelWrite.changeDBNullToString(xlRange(1, intColCnt + 1).Value).Trim
                        Next

                        'Excelの行番号
                        row("ExcelRow") = intRowCnt

                        row("CellNM" & EXCEL_COL_SLINK_DATA.DivideNo) = 1
                        row("CellNM" & EXCEL_COL_SLINK_DATA.DivideYears) = wYearCnt

                        SLinkData.Rows.Add(row)
                    End If

                Else
                    '通常分割(Pricingシート指定) =======================================

                    'Pricingから分割数取得
                    wDivNo = GetDivNo(xlRange(1, EXCEL_COL_SLINK_DATA.SLinkNo + 1).Value, _
                                      xlRange(1, EXCEL_COL_SLINK_DATA.WorkNo + 1).Value, _
                                      SLinkPricing)

                    '分割数分のレコードを作成する
                    For ii As Integer = 1 To wDivNo
                        wLng = 0

                        'Paymentの値をセットする
                        row = SLinkData.NewRow
                        For intColCnt = EXCEL_COL_SLINK_DATA.SLinkNo To EXCEL_COL_SLINK_DATA.SubBrand
                            row("CellNM" & intColCnt) = ExcelWrite.changeDBNullToString(xlRange(1, intColCnt + 1).Value).Trim
                        Next

                        'Excelの行番号
                        row("ExcelRow") = intRowCnt

                        If IsNumeric(ExcelWrite.changeDBNullToString(xlRange(1, EXCEL_COL_SLINK_DATA.WorkNo + 1).Value).Trim) = True Then
                            row("IntWorkNo") = CInt(ExcelWrite.changeDBNullToString(xlRange(1, EXCEL_COL_SLINK_DATA.WorkNo + 1).Value).Trim)
                        Else
                            row("IntWorkNo") = ExcelWrite.changeDBNullToString(xlRange(1, EXCEL_COL_SLINK_DATA.WorkNo + 1).Value).Trim
                        End If

                        row("CellNM" & EXCEL_COL_SLINK_DATA.DivideNo) = ii
                        SLinkData.Rows.Add(row)
                    Next
                End If
            Next
            intOutputCnt = SLinkData.Rows.Count

            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)

            GetSlinkData = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "GetSlinkData")

        Finally
            'エクセルオブジェクトの解放
            ExcelObjRelease.ReleaseExcelObj(xlRange, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlSheet, ExcelObjRelease.OBJECT_NOTHING)
            If IsNothing(xlBook) = False Then
                xlBook.Close(False)
            End If
            ExcelObjRelease.ReleaseExcelObj(xlBook, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()

        End Try

    End Function

    ''' <summary>
    ''' 機能：削除データ検索
    ''' </summary>
    ''' <param name="PsData"></param>
    ''' <param name="SLinkData"></param>
    ''' <param name="strDelRow"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetDeleteDataRow(ByVal PsData As PSExcelDataTable,
                                      ByVal SLinkData As SLinkDataExcelDataTable,
                                      ByRef strDelRow() As String) As Boolean

        Dim intIndex As Integer = 0
        Dim alDelRow As New ArrayList
        Dim strWork As String
        Dim strSLinkNo As String
        Dim strWorkNo As String

        GetDeleteDataRow = False

        Try
            'S-LINKデータ繰り返し
            For Each rowSlink As DataRow In SLinkData.Select(Nothing, "ExcelRow")
                strSLinkNo = GetDbData(rowSlink, EXCEL_COL_SLINK_DATA.SLinkNo)
                strWork = GetDbData(rowSlink, EXCEL_COL_SLINK_DATA.WorkNo)
                If IsNumeric(strWork) = True Then
                    strWorkNo = CInt(strWork)
                Else
                    strWorkNo = strWork
                End If

                Dim sbFilter As New StringBuilder
                sbFilter.Remove(0, sbFilter.Length)
                'S-LINK番号
                sbFilter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                sbFilter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01)
                sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
                sbFilter.Append(StringEdit.EncloseSingleQuotation(strSLinkNo))
                'Work番号
                If strWorkNo.Trim <> "" Then
                    sbFilter.Append(CommonConstant.SQL_STR_AND)
                    sbFilter.Append("CellNM" & ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02)
                    sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
                    sbFilter.Append(StringEdit.EncloseSingleQuotation(strWorkNo))
                End If
                sbFilter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                'Debug.Print(sbFilter.ToString)

                'Paymentデータ繰り返し
                For Each rowPs As DataRow In PsData.Select(sbFilter.ToString, "ExcelRow")
                    alDelRow.Add(rowPs("ExcelRow").ToString.PadLeft(7, "0"c))
                Next
            Next

            '重複行削除
            alDelRow.Sort()
            For intIndex = 0 To (alDelRow.Count - 1)
                If intIndex > (alDelRow.Count - 1) Then
                    Exit For
                End If
                If strWork = alDelRow(intIndex).ToString Then
                    alDelRow.RemoveAt(intIndex)
                    intIndex = intIndex - 1
                Else
                    strWork = alDelRow(intIndex).ToString
                End If
            Next
            strDelRow = DirectCast(alDelRow.ToArray(GetType(String)), String())

            GetDeleteDataRow = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "GetDeleteDataRow")

        End Try

    End Function

    ''' <summary>
    ''' 機能：Payment出力
    ''' </summary>
    ''' <param name="strSlinkFileName"></param>
    ''' <param name="strDelRow"></param>
    ''' <param name="SLinkData"></param>
    ''' <param name="SLinkBase"></param>
    ''' <param name="SLinkPricing"></param>
    ''' <param name="xlSheet"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function SlinkReflection(ByVal strSlinkFileName As String,
                                     ByVal strDelRow() As String,
                                     ByVal SLinkData As SLinkDataExcelDataTable,
                                     ByVal SLinkBase As SLinkBaseExcelDataTable,
                                     ByVal SLinkPricing As SLinkPricingExcelDataTable,
                                     ByRef xlSheet As Excel.Worksheet) As Boolean

        Dim blnRet As Boolean
        Dim intRowCnt As Integer
        Dim strRange As String
        Dim xlCell As Excel.Range = Nothing

        SlinkReflection = False

        Try
            '------------------------------------------
            'Paymentの一致するデータを削除
            '------------------------------------------
            '※
            If Not strDelRow Is Nothing Then
                For intRowCnt = (strDelRow.Length - 1) To 0 Step -1
                    strRange = Integer.Parse(strDelRow(intRowCnt)).ToString & ":" & Integer.Parse(strDelRow(intRowCnt)).ToString
                    'Debug.Print(strRange)
                    xlCell = xlSheet.Range(strRange)
                    xlCell.Delete()
                    ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                Next
            End If

            '------------------------------------------
            '追加行作成
            '------------------------------------------
            blnRet = AddPaymentLine(strSlinkFileName, SLinkData, SLinkBase, SLinkPricing, xlSheet)
            If blnRet = False Then
                Exit Function
            End If

            SlinkReflection = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "GetDeleteDataRow")

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

        End Try

    End Function

    ''' <summary>
    ''' 機能：追加行作成
    ''' </summary>
    ''' <param name="strSlinkFileName"></param>
    ''' <param name="SLinkData"></param>
    ''' <param name="SLinkBase"></param>
    ''' <param name="SLinkPricing"></param>
    ''' <param name="xlSheet"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function AddPaymentLine(ByVal strSlinkFileName As String,
                                    ByVal SLinkData As SLinkDataExcelDataTable,
                                    ByVal SLinkBase As SLinkBaseExcelDataTable,
                                    ByVal SLinkPricing As SLinkPricingExcelDataTable,
                                    ByRef xlSheet As Excel.Worksheet) As Boolean

        Dim periodMonth As Integer = 12 * Me.WS1PayPeriod
        Dim COL_MAX As Integer = ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL + periodMonth
        Dim COL_TITLE As String = ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG) & "5" & ":" &
                                  ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL + periodMonth) & "5"
        Dim COL_AREA As String = ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.UPDATE_FLAG) & "@" & ":" &
                                    ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL + periodMonth) & "@"

        Dim intLineRow As Integer
        Dim blnRet As Boolean
        Dim objCellFormula(1, COL_MAX) As Object
        Dim objCellData(1, COL_MAX) As Object
        Dim objCellYearMonth(1, COL_MAX) As Object
        Dim strRange As String
        Dim intColCnt As Integer
        Dim intLineNo As Integer = 0
        Dim strWork As String
        Dim strSLinkNo As String
        Dim strWorkNo As String
        Dim intRefCd As Integer = CD_REF_DATE_PAYMENT
        Dim strStartDate As String
        Dim strEndDate As String
        Dim strPricingType As String
        Dim intCnt As Integer
        Dim intPsCount As Integer
        Dim strPayDate As String
        Dim strFileName As String
        Dim lngWorkLineNo As Long
        Dim xlCell As Excel.Range = Nothing
        Dim xlEntireRow As Excel.Range = Nothing
        Dim objCellLineNo(,) As Object
        Dim ErrCnt As Integer = 0
        Dim RecCnt As Integer = 0

        AddPaymentLine = False

        Try
            '------------------------------------
            '出力位置とLINE_NO取得
            '------------------------------------
            'ﾛｯｸFLGからNOまでのデータを取得する
            strRange = ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.CsvPaymentLineColumn.LOCK_FLAG) & ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW.ToString &
                       ":" &
                       ExcelWrite.chgExcelColumnIdxToChar(ExcelWrite.CsvPaymentLineColumn.LINE_NO) & EXCEL_MAX_ROW.ToString
            blnRet = ExcelWrite.GetCellValue(xlSheet, strRange, objCellLineNo)
            For intCnt = 1 To (EXCEL_MAX_ROW - 6)
                'NOから最終行を判定する
                strWork = ExcelWrite.changeDBNullToString(objCellLineNo(intCnt, 3))
                If strWork.Trim = "" Then
                    Exit For
                End If
                '契約済みデータは対象外
                If ExcelWrite.changeDBNullToString(objCellLineNo(intCnt, 1)) = "C" Then
                    Continue For
                End If

                If IsNumeric(strWork) = True Then
                    lngWorkLineNo = Long.Parse(strWork)
                    If intLineNo < lngWorkLineNo Then
                        intLineNo = lngWorkLineNo
                    End If
                End If
            Next
            intLineRow = intCnt - 1 + ExcelWrite.EXCEL_PAYMENTLINEDATE_OUTROW
            If intLineNo = 0 Then
                intLineNo = Integer.Parse(CommonVariable.CONTRACTNO.ToString & "00000")
            End If

            '反映件数確定のため事前エラーチェック
            For Each rowBase As DataRow In SLinkData.Select()
                'Req.1581 MENU取込対応 2017/12 Str
                '変更管理#43 ATOP対応 Str
                'If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Or _
                '    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_ATOP Then
                If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Or _
                    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_ATOP Or _
                    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_MENU Then
                    'If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Then
                    '変更管理#43 ATOP対応 End
                    'Req.1581 MENU取込対応 2017/12 End
                    If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.PayMethod) <> "一括" And _
                       GetDbData(rowBase, EXCEL_COL_SLINK_DATA.PayMethod) <> "年額" And _
                       GetDbData(rowBase, EXCEL_COL_SLINK_DATA.PayMethod) <> "月額" Then
                        '支払方法が「一括」、「月額」、「年額」以外
                        fErr = True
                        ErrCnt = ErrCnt + 1
                    Else
                        If IsDate(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcStartDate)) And _
                           IsDate(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcEndDate)) Then
                            If CDate(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcStartDate)).ToString("yyyy/MM/dd") > _
                               CDate(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcEndDate)).ToString("yyyy/MM/dd") Then
                                'サービス期間開始＞サービス期間終了
                                fErr = True
                                ErrCnt = ErrCnt + 1
                            End If
                        Else
                            'サービス期間が日付以外
                            fErr = True
                            ErrCnt = ErrCnt + 1
                        End If
                    End If
                End If
            Next

            '------------------------------------
            'サンプル行（２行目）コピー
            '------------------------------------
            intPsCount = SLinkData.Rows.Count - ErrCnt
            'データ行表示
            strRange = ExcelWrite.EXCEL_PAYMENTLINE_TMPROW.ToString & ":" & ExcelWrite.EXCEL_PAYMENTLINE_TMPROW.ToString
            xlCell = xlSheet.Range(strRange)
            xlEntireRow = xlCell.EntireRow
            xlEntireRow.Hidden = False
            ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)
            '罫線設定
            Const DIVISION_LINES As Integer = 1000
            Dim intSho As Integer = intPsCount \ DIVISION_LINES
            Dim intAmari As Integer = intPsCount Mod DIVISION_LINES

            For intCnt = 1 To intSho
                strRange = ExcelWrite.EXCEL_PAYMENTLINE_TMPROW.ToString & ":" & ExcelWrite.EXCEL_PAYMENTLINE_TMPROW.ToString
                xlCell = xlSheet.Range(strRange)
                xlCell.Copy()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                strRange = (intLineRow + (intCnt - 1) * DIVISION_LINES).ToString() & ":" & (intLineRow + intCnt * DIVISION_LINES - 1).ToString()
                xlCell = xlSheet.Range(strRange)
                xlCell.Insert()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            Next
            If intAmari <> 0 Then
                strRange = ExcelWrite.EXCEL_PAYMENTLINE_TMPROW.ToString & ":" & ExcelWrite.EXCEL_PAYMENTLINE_TMPROW.ToString
                xlCell = xlSheet.Range(strRange)
                xlCell.Copy()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                strRange = (intLineRow + (intSho * DIVISION_LINES)).ToString() & ":" & (intLineRow + (intSho * DIVISION_LINES + intAmari) - 1).ToString()
                xlCell = xlSheet.Range(strRange)
                xlCell.Insert()
                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
            End If
            'データ行非表示
            strRange = ExcelWrite.EXCEL_PAYMENTLINE_TMPROW.ToString & ":" & ExcelWrite.EXCEL_PAYMENTLINE_TMPROW.ToString
            xlCell = xlSheet.Range(strRange)
            xlEntireRow = xlCell.EntireRow
            xlEntireRow.Hidden = True
            ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)

            '月額展開の年月行取得
            blnRet = ExcelWrite.GetCellValue(xlSheet, COL_TITLE, objCellYearMonth)

            strFileName = Path.GetFileName(strSlinkFileName)

            '------------------------------------
            'データセット
            '------------------------------------
            Debug.Print(Now.ToString("HH:mm:ss") & "　開始データセット")
            '取得結果(基本情報)繰り返し
            For Each rowBase As DataRow In SLinkData.Select(Nothing, "ExcelRow,CellNM" & EXCEL_COL_SLINK_DATA.DivideNo)
                intLineNo = intLineNo + 1

                '１行取得：計算式
                strRange = (COL_AREA).Replace("@", intLineRow.ToString)
                blnRet = GetCellFormula(xlSheet, strRange, objCellData)

                '支払開始終了日取得
                strSLinkNo = ExcelWrite.changeDBNullToString(rowBase("CellNM" & EXCEL_COL_SLINK_DATA.SLinkNo))
                strWorkNo = ExcelWrite.changeDBNullToString(rowBase("CellNM" & EXCEL_COL_SLINK_DATA.WorkNo))
                strPricingType = GetDbData(rowBase, EXCEL_COL_SLINK_DATA.PricingType).Trim

                Dim wDivNo As Integer
                Dim ListPrice As Long = 0
                wDivNo = Val(rowBase("CellNM" & EXCEL_COL_SLINK_DATA.DivideNo))
                blnRet = GetPayDate(strSLinkNo, _
                                    strWorkNo, _
                                    strPricingType, _
                                    SLinkData, _
                                    SLinkPricing, _
                                    strStartDate, _
                                    strEndDate, _
                                    intRefCd, _
                                    wDivNo, _
                                    RecCnt)

                If blnRet = False Then
                    Exit Function
                End If

                'データセット
                '有効無効
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.VALID_FLAG) = "Y"
                'NO
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.LINE_NO) = intLineNo.ToString
                'ﾌｧｲﾙ名
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.FILE_NAME) = strFileName
                '契約順番
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.CONTRACT) = CommonVariable.CONTRACTNO
                '価格承認申請
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.ST_APPROVAL) = "-"
                'BU
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.BU) = GetDbData(rowBase, EXCEL_COL_SLINK_DATA.BU)
                'Brand
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.BRAND) = GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Brand)
                'SubBrand
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.BRAND_SUB) = GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SubBrand)
                'ﾊﾟﾀｰﾝNO
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PATTERN_CD) = "22"
                'ﾊﾟﾀｰﾝ名称
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PATTERN) = "S-Link"
                '項目1
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM01) = strSLinkNo
                '項目2
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM02) = strWorkNo
                '項目3
                strWork = GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcName)
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM03) = strWork.Trim
                '項目6
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM06) = GetDbData(rowBase, EXCEL_COL_SLINK_DATA.BusinessType)
                '項目7
                '変更管理#43 ATOP対応 Str
                If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Then
                    objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM07) = "Annuity"
                Else
                    If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_ATOP Then
                        objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM07) = "ATOP"

                        'Req.1581 MENU取込対応 2017/12 Str
                    ElseIf GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_MENU Then
                        If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.PayMethod) = "年額" Or _
                           GetDbData(rowBase, EXCEL_COL_SLINK_DATA.PayMethod) = "月額" Then
                            objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM07) = STR_REF_BILLING
                        ElseIf GetDbData(rowBase, EXCEL_COL_SLINK_DATA.PayMethod) = "一括" Then
                            objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM07) = STR_REF_PAYMENT
                        End If
                        'Req.1581 MENU取込対応 2017/12 End
                    Else
                        objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM07) = GetRefNm(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SLinkNo), _
                                                                                                 GetDbData(rowBase, EXCEL_COL_SLINK_DATA.WorkNo), _
                                                                                                 SLinkData)
                    End If
                End If
                'If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Then
                '    objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM07) = "Annuity"
                'Else
                '    objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM07) = GetRefNm(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SLinkNo), _
                '                                                                             GetDbData(rowBase, EXCEL_COL_SLINK_DATA.WorkNo), _
                '                                                                             SLinkData)
                'End If
                '変更管理#43 ATOP対応 End
                '項目10
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM10) = strFileName
                '項目11
                'Req.1581 MENU取込対応 2017/12 Str
                '変更管理#43 ATOP対応 Str
                'If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Or _
                '    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_ATOP Then
                If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Or _
                    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_ATOP Or _
                    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_MENU Then
                    'If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Then
                    '変更管理#43 ATOP対応 End
                    'Req.1581 MENU取込対応 2017/12 End
                    objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11) = GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcStartDate)
                Else
                    strWork = GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcStart)
                    If IsDate(strWork) = True Then
                        strWork = Date.Parse(strWork).ToString("yyyy/MM/dd")
                    End If
                    objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM11) = strWork
                End If
                '項目12
                'Req.1581 MENU取込対応 2017/12 Str
                '変更管理#43 ATOP対応 Str
                'If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Or _
                '    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_ATOP Then
                If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Or _
                    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_ATOP Or _
                    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_MENU Then
                    'If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Then
                    '変更管理#43 ATOP対応 End
                    'Req.1581 MENU取込対応 2017/12 End
                    objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12) = GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcEndDate)
                Else
                    strWork = GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcEnd)
                    If IsDate(strWork) = True Then
                        strWork = Date.Parse(strWork).ToString("yyyy/MM/dd")
                    End If
                    objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PROD_ITEM12) = strWork
                End If
                '数量
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.QTY) = 1
                '導入年月
                '変更管理#43 ATOP対応 Str
                If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Then
                    objCellData(1, ExcelWrite.ExcelPaymentLineColumn.INST_DATE) = DateSerial(Year(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcStartDate)), Month(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcStartDate)), 1)
                    'objCellData(1, ExcelWrite.ExcelPaymentLineColumn.INST_DATE) = GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcStartDate)
                    '変更管理#43 ATOP対応 End
                Else
                    'Req.1581 MENU取込対応 2017/12 Str
                    '変更管理#43 ATOP対応 Str
                    'If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_ATOP Then
                    If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_ATOP Or _
                        GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_MENU Then
                        'Req.1581 MENU取込対応 2017/12 End
                        If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.PayMethod) = "一括" Then
                            objCellData(1, ExcelWrite.ExcelPaymentLineColumn.INST_DATE) = DateSerial(Year(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcEndDate)), Month(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcEndDate)), 1)
                        Else
                            objCellData(1, ExcelWrite.ExcelPaymentLineColumn.INST_DATE) = DateSerial(Year(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcStartDate)), Month(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcStartDate)), 1)
                        End If
                    Else
                        '変更管理#43 ATOP対応 End
                        strWork = strStartDate
                        If IsDate(strWork) = True Then
                            strWork = Date.Parse(strWork).ToString("yyyy/MM/01")
                        End If
                        objCellData(1, ExcelWrite.ExcelPaymentLineColumn.INST_DATE) = strWork
                    End If
                End If
                '元本計算開始年月
                '変更管理#43 ATOP対応 Str
                If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Then
                    objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE) = DateSerial(Year(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcStartDate)), Month(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcStartDate)), 1)
                    'objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE) = GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcStartDate)
                    '変更管理#43 ATOP対応 End
                Else
                    '変更管理#43 ATOP対応 Str
                    'Req.1581 MENU取込対応 2017/12 Str
                    'If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_ATOP Then
                    If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_ATOP Or _
                        GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_MENU Then
                        'Req.1581 MENU取込対応 2017/12 End
                        If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.PayMethod) = "一括" Then
                            objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE) = DateSerial(Year(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcEndDate)), Month(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcEndDate)), 1)
                        Else
                            objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE) = DateSerial(Year(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcStartDate)), Month(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcStartDate)), 1)
                        End If
                    Else
                        objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_START_DATE) = strStartDate
                    End If
                End If
                '元本計算終了年月
                'Req.1581 MENU取込対応 2017/12 Str
                '変更管理#43 ATOP対応 Str
                'If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Or _
                '    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_ATOP Then
                If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Or _
                    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_ATOP Or _
                    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_MENU Then
                    'If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Then
                    '変更管理#43 ATOP対応 End
                    'Req.1581 MENU取込対応 2017/12 End
                    If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.PayMethod) = "年額" Then
                        '変更管理#43 ATOP対応 Str
                        objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE) = DateSerial(Year(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcStartDate)), Month(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcStartDate)), 1)
                        'objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE) = GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcStartDate)
                        '変更管理#43 ATOP対応 End
                    Else
                        '変更管理#43 ATOP対応 Str
                        If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.PayMethod) = "一括" Then
                            If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Then
                                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE) = DateSerial(Year(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcStartDate)), Month(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcStartDate)), 1)
                            Else
                                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE) = DateSerial(Year(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcEndDate)), Month(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcEndDate)), 1)
                            End If
                        Else
                            objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE) = DateSerial(Year(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcEndDate)), Month(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcEndDate)), 1)
                        End If
                        '変更管理#43 ATOP対応 End
                    End If
                Else
                    objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_END_DATE) = strEndDate
                End If
                'Payment展開
                'Req.1581 MENU取込対応 2017/12 Str
                '変更管理#43 ATOP対応 Str
                'If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Or _
                '    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_ATOP Then
                If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Or _
                    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_ATOP Or _
                    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_MENU Then
                    'If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Then
                    '変更管理#43 ATOP対応 End
                    'Req.1581 MENU取込対応 2017/12 End
                    objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_FLAG) = ""
                Else
                    If RecCnt = 1 Then
                        objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_FLAG) = ""
                    Else
                        If strStartDate = strEndDate Then
                            objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_FLAG) = ""
                        Else
                            objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_FLAG) = "変則"
                        End If
                    End If
                End If
                '支払方法
                'Req.1581 MENU取込対応 2017/12 Str
                '変更管理#43 ATOP対応 Str
                'If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Or _
                '    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_ATOP Then
                If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Or _
                    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_ATOP Or _
                    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_MENU Then
                    'If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Then
                    '変更管理#43 ATOP対応 End
                    'Req.1581 MENU取込対応 2017/12 End
                    objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD) = GetDbData(rowBase, EXCEL_COL_SLINK_DATA.PayMethod)
                Else
                    If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.PricingType) = "OEM" Then
                        objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD) = "一括"
                    Else
                        If RecCnt = 1 Then
                            objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD) = "一括"
                        Else
                            If strStartDate = strEndDate Then
                                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD) = "変則"
                            Else
                                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_METHOD) = "変則"
                            End If
                        End If
                    End If
                End If
                'Listprice単価(提案時)
                'Req.1581 MENU取込対応 2017/12 Str
                '変更管理#43 ATOP対応 Str
                'If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Or _
                '    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_ATOP Then
                If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Or _
                    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_ATOP Or _
                    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_MENU Then
                    'If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Then
                    '変更管理#43 ATOP対応 End
                    'Req.1581 MENU取込対応 2017/12 End
                    If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.PayMethod) = "年額" Then
                        'MVMS S-Link化対応 str
                        'objCellData(1, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL) = Val(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Price))
                        If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.BusinessType) = "JP7V" Then
                            objCellData(1, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL) = Val(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Price)) * 12
                        Else
                            objCellData(1, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL) = Val(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Price))
                        End If
                        'MVMS S-Link化対応 end
                        'Req.1581 MENU取込対応 2018/09 Str
                    ElseIf GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_MENU And _
                           GetDbData(rowBase, EXCEL_COL_SLINK_DATA.PayMethod) = "月額" Then
                        objCellData(1, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL) = GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Price)
                        'Req.1581 MENU取込対応 2018/09 End
                    Else
                        objCellData(1, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL) = GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Revenue)
                    End If
                Else
                    objCellData(1, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL) = GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Revenue)
                End If
                'Listprice単価(ﾘﾌﾚｯｼｭ)
                'Req.1581 MENU取込対応 2017/12 Str
                '変更管理#43 ATOP対応 Str
                'If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Or _
                '    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_ATOP Then
                If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Or _
                    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_ATOP Or _
                    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_MENU Then
                    'If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Then
                    '変更管理#43 ATOP対応 End
                    'Req.1581 MENU取込対応 2017/12 End
                    If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.PayMethod) = "年額" Then
                        'MVMS S-Link化対応 str
                        'objCellData(1, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH) = Val(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Price))
                        If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.BusinessType) = "JP7V" Then
                            objCellData(1, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH) = Val(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Price)) * 12
                        Else
                            objCellData(1, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH) = Val(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Price))
                        End If
                        'MVMS S-Link化対応 end
                        'Req.1581 MENU取込対応 2018/09 Str
                    ElseIf GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_MENU And _
                           GetDbData(rowBase, EXCEL_COL_SLINK_DATA.PayMethod) = "月額" Then
                        objCellData(1, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH) = GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Price)
                        'Req.1581 MENU取込対応 2018/09 End
                    Else
                        objCellData(1, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH) = GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Revenue)
                    End If
                Else
                    objCellData(1, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH) = GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Revenue)
                End If

                'COST単価＆Cost%
                'Req.1581 MENU取込対応 2017/12 Str
                '変更管理#43 ATOP対応 Str
                'If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Or _
                '    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_ATOP Then
                If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Or _
                    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_ATOP Or _
                    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_MENU Then
                    'If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Then
                    '変更管理#43 ATOP対応 End
                    'Req.1581 MENU取込対応 2017/12 End
                    If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.PayMethod) = "年額" Then
                        'MVMS S-Link化対応 str
                        'objCellData(1, ExcelWrite.ExcelPaymentLineColumn.COST) = Val(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Cost))
                        If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.BusinessType) = "JP7V" Then
                            objCellData(1, ExcelWrite.ExcelPaymentLineColumn.COST) = Val(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Cost)) * 12
                        Else
                            objCellData(1, ExcelWrite.ExcelPaymentLineColumn.COST) = Val(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Cost))
                        End If
                        'MVMS S-Link化対応 end
                    Else
                        objCellData(1, ExcelWrite.ExcelPaymentLineColumn.COST) = GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Cost)
                    End If
                Else
                    If Val(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.DivideNo)) = 1 Then
                        objCellData(1, ExcelWrite.ExcelPaymentLineColumn.COST_RATE) = ""
                        objCellData(1, ExcelWrite.ExcelPaymentLineColumn.COST) = GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Aprvl)
                    Else
                        objCellData(1, ExcelWrite.ExcelPaymentLineColumn.COST_RATE) = "0"
                        objCellData(1, ExcelWrite.ExcelPaymentLineColumn.COST) = "0"
                    End If
                End If

                'COST入力日
                objCellData(1, ExcelWrite.ExcelPaymentLineColumn.COST_INPUT_DATE) = Now.ToString("yyyy/MM/dd")
                ''月額展開
                'Req.1581 MENU取込対応 2017/12 Str
                '変更管理#43 ATOP対応 Str
                'If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Or _
                '    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_ATOP Then
                If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Or _
                    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_ATOP Or _
                    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_MENU Then
                    'If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Then
                    '変更管理#43 ATOP対応 End
                    'Req.1581 MENU取込対応 2017/12 End
                    'Template式をそのまま利用
                Else
                    blnRet = GetMonthToPricingData(strSLinkNo, _
                                                   strWorkNo, _
                                                   strPricingType, _
                                                   intRefCd, _
                                                   objCellYearMonth, _
                                                   SLinkPricing, _
                                                   objCellData, _
                                                   GetDbData(rowBase, EXCEL_COL_SLINK_DATA.DivideNo), _
                                                   ListPrice,
                                                   objCellData(1, ExcelWrite.ExcelPaymentLineColumn.PAY_FLAG))
                End If
                'Req.1581 MENU取込対応 2017/12 Str
                '変更管理#43 ATOP対応 Str
                'If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Or _
                '    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_ATOP Then
                If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Or _
                    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_ATOP Or _
                    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_MENU Then
                    'If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Then
                    '変更管理#43 ATOP対応 End
                    'Req.1581 MENU取込対応 2017/12 End
                    'セット済み
                Else
                    'Listprice単価(提案時)
                    objCellData(1, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_PROPOSAL) = ListPrice
                    'Listprice単価(ﾘﾌﾚｯｼｭ)
                    objCellData(1, ExcelWrite.ExcelPaymentLineColumn.LIST_PRICE_REFLESH) = ListPrice
                End If

                If blnRet = False Then
                    Exit Function
                End If
                'Req.1581 MENU取込対応 2017/12 Str
                '変更管理#43 ATOP対応 Str
                'If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Or _
                '    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_ATOP Then
                If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Or _
                    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_ATOP Or _
                    GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_MENU Then
                    'If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_Annuity Then
                    '変更管理#43 ATOP対応 End
                    'Req.1581 MENU取込対応 2017/12 End
                    If GetDbData(rowBase, EXCEL_COL_SLINK_DATA.PayMethod) = "一括" Or _
                       GetDbData(rowBase, EXCEL_COL_SLINK_DATA.PayMethod) = "年額" Or _
                       GetDbData(rowBase, EXCEL_COL_SLINK_DATA.PayMethod) = "月額" Then
                        If IsDate(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcStartDate)) And _
                           IsDate(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcEndDate)) Then
                            If CDate(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcStartDate)).ToString("yyyy/MM/dd") <= _
                               CDate(GetDbData(rowBase, EXCEL_COL_SLINK_DATA.SvcEndDate)).ToString("yyyy/MM/dd") Then
                                strRange = (COL_AREA).Replace("@", intLineRow.ToString)
                                xlCell = xlSheet.Range(strRange)
                                xlCell.Value = objCellData
                                ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)
                                intLineRow = intLineRow + 1
                            End If
                        End If
                    End If
                Else
                    strRange = (COL_AREA).Replace("@", intLineRow.ToString)
                    xlCell = xlSheet.Range(strRange)
                    xlCell.Value = objCellData
                    ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

                    intLineRow = intLineRow + 1
                End If

            Next
            Debug.Print(Now.ToString("HH:mm:ss") & "　終了始データセット")

            AddPaymentLine = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "AddPaymentLine")

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlEntireRow, ExcelObjRelease.OBJECT_NOTHING)
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

        End Try

    End Function

    ''' <summary>
    ''' 機能：支払開始終了日取得
    ''' </summary>
    ''' <param name="strSlinkNo"></param>
    ''' <param name="strWorkNo"></param>
    ''' <param name="strPricingType"></param>
    ''' <param name="SLinkData"></param>
    ''' <param name="SLinkPricing"></param>
    ''' <param name="strStartDate"></param>
    ''' <param name="strEndDate"></param>
    ''' <param name="intRefCd"></param>
    ''' <param name="DivNo"></param>
    ''' <param name="RecCnt"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetPayDate(ByVal strSlinkNo As String,
                                ByVal strWorkNo As String,
                                ByVal strPricingType As String,
                                ByVal SLinkData As SLinkDataExcelDataTable,
                                ByVal SLinkPricing As SLinkPricingExcelDataTable,
                                ByRef strStartDate As String,
                                ByRef strEndDate As String,
                                ByRef intRefCd As Integer, _
                                ByVal DivNo As Integer, _
                                ByRef RecCnt As Integer) As Boolean

        Dim blnRet As Boolean
        Dim sbFilter As New StringBuilder
        Dim intRowCnt As Long = 0
        Dim strWork As String
        Dim intFieldNo As Integer
        Dim strSort As String

        GetPayDate = False

        Try
            '------------------------------
            '反映方法取得
            '------------------------------
            blnRet = GetRefCd(strSlinkNo, strWorkNo, SLinkData, intRefCd)
            If blnRet = False Then
                Exit Function
            End If

            '------------------------------
            '支払年月最小最大取得
            '------------------------------
            'S-LINK番号
            sbFilter.Remove(0, sbFilter.Length)
            sbFilter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            sbFilter.Append("CellNM" & EXCEL_COL_SLINK_PRICING.SLinkNo)
            sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
            sbFilter.Append(StringEdit.EncloseSingleQuotation(strSlinkNo))
            sbFilter.Append(CommonConstant.SQL_STR_AND)
            'Work番号
            sbFilter.Append("CellNM" & EXCEL_COL_SLINK_PRICING.WorkSeqno)
            sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
            sbFilter.Append(StringEdit.EncloseSingleQuotation(strWorkNo))
            sbFilter.Append(CommonConstant.SQL_STR_AND)
            sbFilter.Append("CellNM" & EXCEL_COL_SLINK_PRICING.DivideNo)
            sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
            sbFilter.Append(CStr(DivNo))
            sbFilter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

            '取得結果(Pricing)データ繰り返し
            If intRefCd = CD_REF_DATE_BILLING Or strPricingType = "OEM" Then
                intFieldNo = EXCEL_COL_SLINK_PRICING.BillingDate
                strSort = "CellNM" & EXCEL_COL_SLINK_PRICING.BillingDate
            Else
                intFieldNo = EXCEL_COL_SLINK_PRICING.PaymentDate
                strSort = "CellNM" & EXCEL_COL_SLINK_PRICING.PaymentDate
            End If

            For Each rowPricing As DataRow In SLinkPricing.Select(sbFilter.ToString, strSort)
                intRowCnt = intRowCnt + 1

                If intRowCnt = 1 Then
                    strWork = GetDbData(rowPricing, intFieldNo)
                    If IsDate(strWork) = True Then
                        strWork = Date.Parse(strWork).ToString("yyyy/MM/01")
                    End If
                    strStartDate = strWork
                End If
                strWork = GetDbData(rowPricing, intFieldNo)
                If IsDate(strWork) = True Then
                    strWork = Date.Parse(strWork).ToString("yyyy/MM/01")
                End If
                strEndDate = strWork
            Next

            '------------------------------
            '同一SLink,WorkNoの件数カウント
            '------------------------------
            RecCnt = 0
            'S-LINK番号
            sbFilter.Remove(0, sbFilter.Length)
            sbFilter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            sbFilter.Append("CellNM" & EXCEL_COL_SLINK_PRICING.SLinkNo)
            sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
            sbFilter.Append(StringEdit.EncloseSingleQuotation(strSlinkNo))
            sbFilter.Append(CommonConstant.SQL_STR_AND)
            'Work番号
            sbFilter.Append("CellNM" & EXCEL_COL_SLINK_PRICING.WorkSeqno)
            sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
            sbFilter.Append(StringEdit.EncloseSingleQuotation(strWorkNo))
            sbFilter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

            RecCnt = SLinkPricing.Select(sbFilter.ToString).Length

            GetPayDate = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "GetPayDate")

        End Try

    End Function

    ''' <summary>
    ''' 機能：反映方法取得
    ''' </summary>
    ''' <param name="strSlinkNo"></param>
    ''' <param name="strWorkNo"></param>
    ''' <param name="SLinkData"></param>
    ''' <param name="intRefCd"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetRefCd(ByVal strSlinkNo As String,
                              ByVal strWorkNo As String,
                              ByVal SLinkData As SLinkDataExcelDataTable,
                              ByRef intRefCd As Integer) As Boolean

        Dim sbFilter As New StringBuilder

        GetRefCd = False

        Try
            intRefCd = -1

            '------------------------------
            'S-LINK番号、Work番号(Null以外)で検索
            '------------------------------
            'S-LINK番号
            sbFilter.Remove(0, sbFilter.Length)
            sbFilter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            sbFilter.Append("CellNM" & EXCEL_COL_SLINK_DATA.SLinkNo)
            sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
            sbFilter.Append(StringEdit.EncloseSingleQuotation(strSlinkNo))
            sbFilter.Append(CommonConstant.SQL_STR_AND)
            'Work番号
            If IsNumeric(strWorkNo) = True Then
                strWorkNo = Integer.Parse(strWorkNo).ToString
            End If

            sbFilter.Append("IntWorkNo")
            sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
            sbFilter.Append(StringEdit.EncloseSingleQuotation(strWorkNo))
            sbFilter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

            'S-LINKデータ繰り返し
            For Each rowSLink As DataRow In SLinkData.Select(sbFilter.ToString, "ExcelRow")
                If GetDbData(rowSLink, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_DATE_PAYMENT Then
                    intRefCd = CD_REF_DATE_PAYMENT
                Else
                    intRefCd = CD_REF_DATE_BILLING
                End If
                GetRefCd = True
                Exit Function
            Next

            '------------------------------
            'S-LINK番号、Work番号(Null)で検索
            '------------------------------
            sbFilter.Remove(0, sbFilter.Length)
            'S-LINK番号
            sbFilter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            sbFilter.Append("CellNM" & EXCEL_COL_SLINK_DATA.SLinkNo)
            sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
            sbFilter.Append(StringEdit.EncloseSingleQuotation(strSlinkNo))
            sbFilter.Append(CommonConstant.SQL_STR_AND)
            'Work番号
            sbFilter.Append("CellNM" & EXCEL_COL_SLINK_DATA.WorkNo)
            sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
            sbFilter.Append(StringEdit.EncloseSingleQuotation(""))
            sbFilter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

            'S-LINKデータ繰り返し
            For Each rowSLink As DataRow In SLinkData.Select(sbFilter.ToString, "ExcelRow")
                If GetDbData(rowSLink, EXCEL_COL_SLINK_DATA.Ref) = STR_REF_DATE_PAYMENT Then
                    intRefCd = CD_REF_DATE_PAYMENT
                Else
                    intRefCd = CD_REF_DATE_BILLING
                End If
                Exit For
            Next

            GetRefCd = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "GetRefCd")

        End Try

    End Function

    ''' <summary>
    ''' 機能：各月額展開金額取得
    ''' </summary>
    ''' <param name="strSLinkNo"></param>
    ''' <param name="strWorkNo"></param>
    ''' <param name="strPricingType"></param>
    ''' <param name="intRefCd"></param>
    ''' <param name="objCellYearMonth"></param>
    ''' <param name="SLinkPricing"></param>
    ''' <param name="objCellData"></param>
    ''' <param name="DivideNo"></param>
    ''' <param name="ListPrice"></param>
    ''' <param name="PayFlag"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetMonthToPricingData(ByVal strSLinkNo As String,
                                           ByVal strWorkNo As String,
                                           ByVal strPricingType As String,
                                           ByVal intRefCd As Integer,
                                           ByVal objCellYearMonth(,) As Object,
                                           ByVal SLinkPricing As SLinkPricingExcelDataTable,
                                           ByRef objCellData(,) As Object, _
                                           ByVal DivideNo As Integer, _
                                           ByRef ListPrice As Long, _
                                           ByVal PayFlag As String) As Boolean

        Dim sbFilter As New StringBuilder
        Dim strWork As String
        Dim pd() As PricngData
        Dim intIndex As Integer
        Dim intDate As Integer
        Dim intAmount As Integer
        Dim intCnt As Integer
        Dim intYearMonthCnt As Integer

        GetMonthToPricingData = False

        Try
            '------------------------------
            '月額展開金額初期化
            '------------------------------
            Dim periodMonth As Integer = Me.WS1PayPeriod * 12
            For intCnt = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1 To ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL + periodMonth
                If PayFlag <> "" Then
                    objCellData(1, intCnt) = 0
                End If
            Next

            intIndex = 0
            ReDim pd(intIndex)

            sbFilter.Remove(0, sbFilter.Length)
            If strPricingType = "OEM" Then
                'S-LINK番号
                sbFilter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                sbFilter.Append("CellNM" & EXCEL_COL_SLINK_PRICING.SLinkNo)
                sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
                sbFilter.Append(StringEdit.EncloseSingleQuotation(strSLinkNo))
                sbFilter.Append(CommonConstant.SQL_STR_AND)
                'Work番号
                sbFilter.Append("CellNM" & EXCEL_COL_SLINK_PRICING.WorkSeqno)
                sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
                sbFilter.Append(StringEdit.EncloseSingleQuotation(strWorkNo))
                '分割No
                sbFilter.Append(CommonConstant.SQL_STR_AND)
                sbFilter.Append("CellNM" & EXCEL_COL_SLINK_PRICING.DivideNo)
                sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
                sbFilter.Append(CStr(DivideNo))

                sbFilter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

                strWork = ""
                intAmount = 0
                For Each row As DataRow In SLinkPricing.Select(sbFilter.ToString, "CellNM" & EXCEL_COL_SLINK_PRICING.BillingDate)

                    If strWork <> GetDbData(row, EXCEL_COL_SLINK_PRICING.BillingDate) Then
                        intIndex = intIndex + 1
                        ReDim Preserve pd(intIndex)
                        pd(intIndex).YearMonth = GetDbData(row, EXCEL_COL_SLINK_PRICING.BillingDate)
                        If intIndex <> 1 Then
                            '１つ前に代入
                            pd(intIndex - 1).intAmount = intAmount
                        End If

                        strWork = pd(intIndex).YearMonth
                        intAmount = 0
                    End If
                    intAmount = intAmount + GetDbData(row, EXCEL_COL_SLINK_PRICING.BillingAmount)

                    ListPrice = ListPrice + GetDbData(row, EXCEL_COL_SLINK_PRICING.BillingAmount)
                Next
                If intIndex <> 0 Then
                    pd(intIndex).intAmount = intAmount
                End If

            Else
                'S-LINK番号
                sbFilter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
                sbFilter.Append("CellNM" & EXCEL_COL_SLINK_PRICING.SLinkNo)
                sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
                sbFilter.Append(StringEdit.EncloseSingleQuotation(strSLinkNo))
                sbFilter.Append(CommonConstant.SQL_STR_AND)
                'Work番号
                sbFilter.Append("CellNM" & EXCEL_COL_SLINK_PRICING.WorkSeqno)
                sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
                sbFilter.Append(StringEdit.EncloseSingleQuotation(strWorkNo))
                '分割No
                sbFilter.Append(CommonConstant.SQL_STR_AND)
                sbFilter.Append("CellNM" & EXCEL_COL_SLINK_PRICING.DivideNo)
                sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
                sbFilter.Append(CStr(DivideNo))

                sbFilter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
                '月額展開日付
                If intRefCd = CD_REF_DATE_PAYMENT Then
                    intDate = EXCEL_COL_SLINK_PRICING.PaymentDate
                Else
                    intDate = EXCEL_COL_SLINK_PRICING.BillingDate
                End If

                For Each row As DataRow In SLinkPricing.Select(sbFilter.ToString, "CellNM" & intDate.ToString)
                    intIndex = intIndex + 1
                    ReDim Preserve pd(intIndex)

                    With pd(intIndex)
                        .YearMonth = GetDbData(row, intDate)
                        .intAmount = GetDbData(row, EXCEL_COL_SLINK_PRICING.BillingAmount)
                    End With

                    ListPrice = ListPrice + GetDbData(row, EXCEL_COL_SLINK_PRICING.BillingAmount)
                Next

            End If

            '------------------------------
            '月額展開金額設定
            '------------------------------
            If PayFlag <> "" Then
                If pd.Length > 1 Then
                    For intCnt = 1 To (pd.Length - 1)
                        For intYearMonthCnt = ExcelWrite.ExcelPaymentLineColumn.PRICE_YEAR1_MONTH1 To ExcelWrite.ExcelPaymentLineColumn.PAST_PRICE_TOTAL + periodMonth
                            If pd(intCnt).YearMonth = Date.Parse(objCellYearMonth(1, intYearMonthCnt)).ToString("yyyy/MM/dd") Then
                                objCellData(1, intYearMonthCnt) = objCellData(1, intYearMonthCnt) + pd(intCnt).intAmount
                                Exit For
                            End If
                        Next
                    Next
                End If
            End If

            GetMonthToPricingData = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "GetMonthToPricingData")

        End Try

    End Function

    ''' <summary>
    ''' 機能：データテーブルのデータ取得
    ''' </summary>
    ''' <param name="dr"></param>
    ''' <param name="intFieldNo"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetDbData(ByVal dr As DataRow, ByVal intFieldNo As Integer) As String

        GetDbData = ""

        Try
            GetDbData = ExcelWrite.changeDBNullToString(dr("CellNM" & intFieldNo.ToString))

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "GetDbData")

        End Try

    End Function

    ''' <summary>
    ''' 機　能：セル式取得
    ''' </summary>
    ''' <param name="xlSheet"></param>
    ''' <param name="strRange"></param>
    ''' <param name="ExcelFormula"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetCellFormula(ByVal xlSheet As Excel.Worksheet, ByVal strRange As String, ByRef ExcelFormula(,) As Object) As Boolean

        Dim xlCell As Excel.Range = Nothing

        GetCellFormula = False

        Try
            xlCell = xlSheet.Range(strRange)
            ExcelFormula = xlCell.Formula

            GetCellFormula = True

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "GetCellFormula")

        Finally
            ExcelObjRelease.ReleaseExcelObj(xlCell, ExcelObjRelease.OBJECT_NOTHING)

            GC.Collect()
        End Try

    End Function

    ''' <summary>
    ''' 機能：反映方法取得
    ''' </summary>
    ''' <param name="strSlinkNo"></param>
    ''' <param name="strWorkNo"></param>
    ''' <param name="SLinkData"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetRefNm(ByVal strSlinkNo As String,
                              ByVal strWorkNo As String,
                              ByVal SLinkData As SLinkDataExcelDataTable) As String

        Dim sbFilter As New StringBuilder

        Const PaymentDate As String = "Payment Date"
        Const BillingDate As String = "Billing Date"

        GetRefNm = ""

        Try
            '------------------------------
            'S-LINK番号、Work番号(Null以外)で検索
            '------------------------------
            'S-LINK番号
            sbFilter.Remove(0, sbFilter.Length)
            sbFilter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            sbFilter.Append("CellNM" & EXCEL_COL_SLINK_DATA.SLinkNo)
            sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
            sbFilter.Append(StringEdit.EncloseSingleQuotation(strSlinkNo))
            sbFilter.Append(CommonConstant.SQL_STR_AND)
            'Work番号
            If IsNumeric(strWorkNo) = True Then
                strWorkNo = Integer.Parse(strWorkNo).ToString
            End If

            sbFilter.Append("IntWorkNo")
            sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
            sbFilter.Append(StringEdit.EncloseSingleQuotation(strWorkNo))
            sbFilter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)
            ''MsgBox(sbFilter.ToString)
            'S-LINKデータ繰り返し
            For Each rowSLink As DataRow In SLinkData.Select(sbFilter.ToString, "ExcelRow")
                If GetDbData(rowSLink, EXCEL_COL_SLINK_DATA.Ref).Trim = "" Then
                    '未選択の時はBillingDateをセットする。
                    GetRefNm = BillingDate
                Else
                    Select Case GetDbData(rowSLink, EXCEL_COL_SLINK_DATA.Ref)
                        Case STR_REF_DATE_BILLING
                            GetRefNm = BillingDate
                        Case STR_REF_DATE_PAYMENT
                            GetRefNm = PaymentDate
                        Case Else
                            GetRefNm = BillingDate
                    End Select
                End If
                Exit Function
            Next

            '------------------------------
            'S-LINK番号、Work番号(Null)で検索
            '------------------------------
            sbFilter.Remove(0, sbFilter.Length)
            'S-LINK番号
            sbFilter.Append(CommonConstant.STR_LEFT_PARENTHESIS)
            sbFilter.Append("CellNM" & EXCEL_COL_SLINK_DATA.SLinkNo)
            sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
            sbFilter.Append(StringEdit.EncloseSingleQuotation(strSlinkNo))
            sbFilter.Append(CommonConstant.SQL_STR_AND)
            'Work番号
            sbFilter.Append("CellNM" & EXCEL_COL_SLINK_DATA.WorkNo)
            sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
            sbFilter.Append(StringEdit.EncloseSingleQuotation(""))
            sbFilter.Append(CommonConstant.STR_RIGHT_PARENTHESIS)

            'S-LINKデータ繰り返し
            For Each rowSLink As DataRow In SLinkData.Select(sbFilter.ToString, "ExcelRow")
                If GetDbData(rowSLink, EXCEL_COL_SLINK_DATA.Ref).Trim = "" Then
                    '未選択の時はBillingDateをセットする。
                    GetRefNm = BillingDate
                Else
                    Select Case GetDbData(rowSLink, EXCEL_COL_SLINK_DATA.Ref)
                        Case STR_REF_DATE_BILLING
                            GetRefNm = BillingDate
                        Case STR_REF_DATE_PAYMENT
                            GetRefNm = PaymentDate
                        Case Else
                            GetRefNm = BillingDate
                    End Select
                End If
                Exit Function
            Next

            GetRefNm = ""

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "GetRefCd")

        End Try

    End Function

    ''' <summary>
    ''' 機能：当該SLinkNo,WorkNoの分割数を取得する
    ''' </summary>
    ''' <param name="strSlinkNo"></param>
    ''' <param name="strWorkNo"></param>
    ''' <param name="SLinkData"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetDivNo(ByVal SlinkNo As String,
                              ByVal WorkNo As String,
                              ByVal PricingData As SLinkPricingExcelDataTable) As Integer

        Dim sbFilter As New StringBuilder
        Dim wInt As Integer

        GetDivNo = 1

        Try
            '------------------------------
            'S-LINK番号、Work番号で検索
            '------------------------------
            sbFilter.Remove(0, sbFilter.Length)
            sbFilter.Append("CellNM" & EXCEL_COL_SLINK_DATA.SLinkNo)
            sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
            sbFilter.Append(StringEdit.EncloseSingleQuotation(SlinkNo))
            sbFilter.Append(CommonConstant.SQL_STR_AND)
            sbFilter.Append("CellNM" & EXCEL_COL_SLINK_DATA.WorkNo)
            sbFilter.Append(CommonConstant.SQL_STR_EQUAL)
            sbFilter.Append(StringEdit.EncloseSingleQuotation(WorkNo))

            'Pricingデータ繰り返し
            For Each row As DataRow In PricingData.Select(sbFilter.ToString)
                wInt = row("CellNM" & EXCEL_COL_SLINK_PRICING.DivideNo)
                If wInt > GetDivNo Then
                    '該当する中で最大値を取得する
                    GetDivNo = wInt
                End If
            Next

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "GetDivNo")
        End Try

    End Function

    ''---------------------------------------------------------------
    ''概 要：期間内年数取得
    ''説 明：開始年を基準に、終了年を超えるまでの年数を取得する。
    ''引 数：StartYMD:開始年
    ''       EndYMD:終了年
    ''戻り値：期間内年数(切り上げ)
    ''---------------------------------------------------------------
    Private Function GetYears(ByVal StartYMD As String, _
                              ByVal EndYMD As String) As Integer
        Dim StartDate As Date
        Dim EndDate As Date

        GetYears = 0

        'If StartYMD = "" Then
        '    '日付でない→エラーあり
        '    fErr = True
        '    Exit Function
        'End If
        If Not IsDate(StartYMD) Then
            '日付でない→エラーあり
            fErr = True
            Exit Function
        End If
        'If EndYMD = "" Then
        '    '日付でない→エラーあり
        '    fErr = True
        '    Exit Function
        'End If
        If Not IsDate(EndYMD) Then
            '日付でない→エラーあり
            fErr = True
            Exit Function
        End If

        '日付変数に変換
        StartDate = CDate(StartYMD)
        EndDate = CDate(EndYMD)

        While StartDate <= EndDate
            '１年後を取得する。
            StartDate = StartDate.AddYears(1)

            GetYears = GetYears + 1
        End While

    End Function

    ''' <summary>
    ''' 機能：当該SLinkNo,WorkNoがAnnuity行かどうかを判定する。
    ''' </summary>
    ''' <param name="SLinkData">予めセット済みのSLinkData</param>
    ''' <param name="strSlinkNo">検索するSLinkNo</param>
    ''' <param name="strWorkNo">検索するWorkNo</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function isAnnuity(ByVal SData() As SLinkData,
                               ByVal SLinkNo As String,
                               ByVal WorkNo As String) As Boolean
        Dim wInt As Integer

        isAnnuity = False

        Try
            '------------------------------
            'S-LINK番号、Work番号で検索
            '------------------------------
            For wInt = 0 To UBound(SData)
                If SData(wInt).SLinkNo = SLinkNo And _
                   SData(wInt).WorkNo = WorkNo Then
                    '変更管理#43 ATOP対応 Str
                    If SData(wInt).Refrect = STR_REF_Annuity Or _
                        SData(wInt).Refrect = STR_REF_ATOP Then
                        'If SData(wInt).Refrect = STR_REF_Annuity Then
                        '変更管理#43 ATOP対応 End
                        isAnnuity = True
                    Else
                        isAnnuity = False
                    End If
                End If
            Next

        Catch ex As Exception
            MsgBox(ex.Message.ToString, vbCritical, "isAnnuity")
        End Try

    End Function

#End Region

#End Region

End Class
